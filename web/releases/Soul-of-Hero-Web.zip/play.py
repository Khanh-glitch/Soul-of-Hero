from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

# Keep the origin (and therefore the save slot) stable between sessions.
url = 'http://127.0.0.1:4173/'
handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent / 'game'))
try:
    server = ThreadingHTTPServer(('127.0.0.1', 4173), handler)
except OSError:
    raise SystemExit('Port 4173 is already in use. Close the other server and try again.')
with server:
    print(url, flush=True)
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
