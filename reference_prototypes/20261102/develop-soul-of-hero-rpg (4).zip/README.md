# Soul of Hero — browser island survival RPG

A solo, offline-first, top-down pixel action RPG built with React, Vite, TypeScript and Canvas 2D.
The world is a 192×192-tile island rendered at 640×360 logical pixels and scaled by whole-number steps.

## Run

```bash
npm install
npm run dev       # development server
npm run build     # production build → dist/index.html (one self-contained file, no network needed)
npx vitest run    # automated invariant tests (see IMPLEMENTATION_EVIDENCE.md)
```

`npm test` is not wired: package.json is controlled by the harness and was not edited by hand.

Add `?qa=1` to the URL to show the QA clock. It is labelled **UNVERIFIED**, is never real elapsed time, and never produces verified records.

## Controls

| Input | Action |
| --- | --- |
| WASD / arrows | Move |
| Shift | Sprint (uses stamina) |
| Mouse | Aim anywhere (true 360°); hold left click to attack or chop |
| Right click | Eat the selected hotbar food, or cancel build placement |
| Space | Dodge roll (brief invulnerability) |
| Q | Whirl (melee, full-circle sweep) |
| F | Ember Core cast (charge is spent only when the blast lands) |
| E | Interact with the nearest thing; hold E at the evacuation dock to board the skiff |
| 1–8 | Hotbar |
| I | Pack, equipment, chest / furnace / death bag transfers |
| C | Craft (workbench recipes need a bench nearby) |
| B | Build: choose a piece, then left-click owned ground |
| R | Study desk: learn recipes from blueprints or specimens |
| M | Map (only what you have walked is revealed) |
| Tab | Skills |
| Esc | Menu: save, records, options, abandon, save-and-quit |

## What the game does

- **Island**: deterministic from one seed. Coastlines with bays, rivers that run from the highlands into the sea, mountain passes cut by roads, bridges over rivers and fords, marsh, tundra and snow in the north, desert in the south-east, and the Slagworks in the east.
- **Starts**: Pinewood Clearing, Reed Marsh Edge, Harbor Cove, Highland Glen, or a random safe landing.
- **Survival**: HP, stamina, hunger, warmth and toxin. Standing under a roof is shelter. Hunger can never kill you while sheltered (minimum 1 HP). Death leaves a single recoverable bag where you fell and respawns you in the same run.
- **Combat**: windup, contact and recovery phases with hit-stop, knockback and telegraphs. Seven creature types, with wolves that only follow footprints you left recently. Six Elders with latent and awakened forms and nine attack pattern families.
- **Economy**: everything is physical. Items sit in the pack, equipment slots, the ground, death bags, chests, carts or furnace slots. Harvest eligibility depends on the tool. Recipes are run-local. Furnaces burn fuel only while work is paid for. Output waits in its slot.
- **Building**: 15 structure types on claimed land (Home Stake). Walls can be broken by boars. Reclaim returns materials; containers must be emptied first.
- **Ragnarok**: the Sealed Vault opens only in the last 72 real hours and only once per run. Physical Ragnarok Cash buys an Escrow Chest from the trade-post vendor. Depositing it on owned land secures cash to your profile. Evacuation, abandoning and expiry are three separate ways to end a run; each wipes run-local data exactly once. The profile keeps only secured cash, achievements and history.
- **Persistence**: versioned saves in IndexedDB, committed in one transaction. Falls back to localStorage. Unreadable saves are quarantined, not overwritten. Reopening settles elapsed time chronologically.

## Architecture

| File | Role |
| --- | --- |
| `src/game/state.ts` | Authoritative state and the only dispatcher: `dispatch(state, intent) → committed state + receipt`, or a rejection with no partial effects |
| `src/game/sim.ts` | Realtime movement, combat, AI and VFX state. Economic results are dispatched, never applied directly |
| `src/game/engine.ts` | 60 fps loop, 1 Hz settlement tick, input, saves and UI snapshots |
| `src/game/world/world.ts` | Deterministic island generation, roads, POIs, spawns |
| `src/game/art/` | Original pixel art generated in code (ground autotiles, props, characters, creatures, Elders, icons) |
| `src/game/render.ts` | Canvas presentation: viewport culling, y-sorting, roof occlusion, telegraphs, weather, light |
| `src/game/data/catalog.ts` + `balance.v1.json` | Catalogs and editable balance, each marked with its canon status |
| `src/App.tsx`, `src/ui/Game.tsx`, `src/index.css` | React shell: title flow, HUD, panels, pixel UI |

## Canon and status markers

The Gameplay Bible at the public GitHub raw URL was fetched and used for design authority. Excerpts were read for the invariants, the run clock, the K1–K8 owners and the C01–C24 contracts; the full text was not ingested. Gold original art was not available, so no Gold fidelity is claimed (`GOLD_SOURCE_NOT_AVAILABLE`).

Balance values are marked `LOCKED_CANON`, `PROPOSED_MECHANISM`, `TUNABLE_BALANCE` or `NEEDS_MEASUREMENT` in `balance.v1.json`. Nothing has been play-tested for balance yet.

See `IMPLEMENTATION_EVIDENCE.md` for coverage and gaps, and `PROVENANCE.md` for asset and dependency licenses.
