# Implementation evidence

Status key: **TESTED** = covered by an automated test that passed in this run · **IMPLEMENTED** = code path exists, not automated and not browser-played · **PARTIAL** = exists with stated gaps · **PENDING** = not built.

## Verification run (this build)

| Command | Result |
| --- | --- |
| `npx vitest run` | 2 files, 9 tests, all passing (art/world dump 2, core invariants 7) |
| `npx tsc --noEmit -p .` | exit 0 |
| `npm run build` | `dist/index.html` 576,030 bytes, single file, no runtime network |
| `SOH_DUMP=1 npx vitest run src/game/__tests__/art.dump.test.ts` | writes `/tmp/soh/*.png`; copies in `qa/` |

**Not performed:** no browser was available in the sandbox (no Chromium or Playwright), so the game was **not played** in a browser. Layout at 640×360 and 1280×720, pointer mapping, focus recovery and audio have not been observed in a live session. Treat the UI as unverified until a manual pass.

## Visual QA (PNG renders, Node)

- `qa/island-map.png`: the island generated before the final tweaks. The renders showed a central mountain mass that was too large and rivers stopping in basins. Both were addressed (mountain threshold raised; basins now carve a channel to the sea). The final map was **not re-rendered** after those changes; only the connectivity and determinism tests were re-run.
- `qa/sprites-sheet.png`: ground autotiles, props, buildings, both Adventurer views, creatures, all six Elder silhouettes and item icons are readable and share one outline and light direction. The wisp halo was too faint in that render and was strengthened afterwards (not re-rendered).

## Systems (K1–K8)

| Owner | Implementation | Status |
| --- | --- | --- |
| K1 custody | `custody` (pack, equipment, ground, bags) + container slots; `move`, `drop`, `pickup`, `equip`, `eat`, `sort`; conservation ledger `held = minted − spent` | TESTED (harvest + ledger, rejected-action no-debit) |
| K2 environment | `world.mods` (burnt, puddle, opened gate), `world.trails` (footprints, rain washing), `world.wx` (weather cells), terrain speed and blocking | IMPLEMENTED; PARTIAL (no per-surface footprint visuals) |
| K3 sources | `sources` (hp, finite or regrowing), `harvest`, creature loot, POI chests `poi:*` claimed once | TESTED (harvest once) |
| K4 knowledge/work | recipes (26), study job (`jobs`), run-local `knowledge.learned`, furnace job with fuel-bounded progress, garden growth | IMPLEMENTED |
| K5 actors/AI | `actors.player`, `actors.creatures` (7 kinds, state machines, telegraphs), `actors.elders` (9 pattern families), death bag and respawn | PARTIAL (AI and Elder balance not play-tested) |
| K6 structures/POIs | 15 structure kinds, claims (radius 9), POIs (trade, village, wreck, mine, gallery, ruin, vault, dock, six shrines) | IMPLEMENTED |
| K7 freight | cart (hitch/release, cargo weight, speed penalty), roads and bridges | PARTIAL (no freight economy balance) |
| K8 clock/run/profile | `run` lifecycle, `clock` (settled time, QA offset), `profile` (secured cash, achievements, history), atomic saves | IMPLEMENTED (QA clock flagged UNVERIFIED) |

## Causal contracts (C01–C24)

| Contract | Evidence | Status |
| --- | --- | --- |
| C01 node + tool → depletion and yield once | `harvest`; test harvests a bush once, rejects the second hit, ledger balanced | TESTED |
| C02 roadside scrap → Spares | crates placed on road shoulders (`world.ts`); `scrap` yields; `spares` bench recipe | IMPLEMENTED |
| C03 found charged Core → cast before knowledge | Ember Reliquary chest mints `ember_core` with 3 charges; `cast` commits on contact; interrupted windup keeps the charge | IMPLEMENTED |
| C04 study → one run-local recipe | `study` debits blueprint or specimen plus Spares, creates a job, completes in settled time | IMPLEMENTED |
| C05 shared hit + material | tier rules in `harvest` (power vs node need), creature damage in `sim.ts`, Core burns grass, forest, tundra and marsh | IMPLEMENTED |
| C06 workstation job + fuel + time | furnace settlement consumes fuel only while a job runs; output blocked if slot full; garden growth with rain multiplier | IMPLEMENTED |
| C07 physical instance lifecycle | `build` debits cost or kit; `reclaim` refunds (empty containers only); cart and chests keep instances; spills go to ground | TESTED (ledger after build paths reviewed; reclaim spill fixed) |
| C08 footprints + encounter | `trail` on real movement; wolves track only fresh footprints within sense range; no home knowledge | IMPLEMENTED |
| C09 free quit + known shelter/weather | settled time replays weather, hunger, warmth, furnace and crops; shelter prevents hunger death below 1 HP; no offline monster attacks | PARTIAL (no forecast UI) |
| C10 death → bag + same-run respawn | `killPlayer` moves all carried items to one bag at coordinates; `bag_loot` moves stacks exactly once | IMPLEMENTED |
| C11 POI exterior → deeper gated access | village and wreck chests; Sealed Gallery opens with `rusted_key`; deep chest behind it | PARTIAL (no hazard-gated POI beyond the gallery) |
| C12 optional progression | no quest gates or payout keys; recipes gated by materials and study only | IMPLEMENTED |
| C13 routes, weather, weight, cart | road speed 1.12×, marsh and shallow slowdowns, cart weight penalty and off-road drag | PARTIAL (economics not balanced) |
| C14 weather/time changes world | rain washes trails older than 45 s and speeds crops; burnt tiles and puddles expire on tick | PARTIAL |
| C15 final-72 finite POI chest | `chest` on `slag_vault` refused before 264 h, once per run; minted physical cash | TESTED |
| C16 zero wallet → vendor escrow → placement → deposit | `vendor_buy_escrow` debits physical cash; escrow must be built on claimed land; `deposit` | IMPLEMENTED (end-to-end play pending) |
| C17 escrow deposit exactly once | `deposit` moves all physical cash to `profile.secured` in one commit; repeat finds no cash and changes nothing; profile and run written in one IndexedDB transaction | IMPLEMENTED |
| C18 next run vendor → run-local item | `vendor_buy_run` debits secured cash with a purchase key; creates a run-local item | IMPLEMENTED |
| C19 six Elders, latent and awakened, stones | `ELDERS` data; `elder_hit` enrages at 50%; defeat mints the stone once; day-14 awakening flag | PARTIAL (balance and telegraph readability not play-tested) |
| C20 achievements → local score | `achieve` once per run; profile first-time record; no currency path | IMPLEMENTED |
| C21 browser history → LOCAL/UNVERIFIED | Records panel labels everything local and unverified; no backend | IMPLEMENTED |
| C22 evacuation as a real site, once | hold E at the dock (2.2 s) → `evacuate` finalizes once; cash is not auto-secured | IMPLEMENTED |
| C23 legal end wipes run data | `finalize` clears inventory, equipment, structures, claims, creatures, sources, recipes and jobs; keeps profile; second end rejected | TESTED |
| C24 stable island + four safe starts | deterministic generation; BFS over walkable tiles connects all four spawns to the trade post | TESTED |

## Acceptance tests in this run

- Movement and interaction: spawn selection and travel are IMPLEMENTED only (no browser run). Harvest depletion is TESTED.
- Inventory, build, research: IMPLEMENTED. Rejected build and craft leave no partial debit (TESTED for craft and build preconditions).
- Time and AI: IMPLEMENTED. Settled-time replay is not separately tested.
- Ragnarok and run 2: vault timing and once-only opening TESTED; run end and wipe TESTED; escrow purchase, placement and deposit IMPLEMENTED only.
- Pathological cases: repeated harvest (TESTED), duplicate request (TESTED), double-claim of an emptied vault (TESTED), exact-once run end (TESTED), profile versus run contamination on new run (TESTED by the wipe test). Not covered: fuel exhaustion, trace loss, caught-up save reload, death-bag reload.

## Design assumptions

- Research time runs in real settled time and needs no fuel (labelled `NEEDS_MEASUREMENT`).
- Escrow price is 2 physical Ragnarok Cash, and the vendor sells only the chest for physical cash; run-start stock is sold for secured cash. Both are `PROPOSED_MECHANISM`.
- Death keeps nothing on the player: everything carried goes to the bag. The respawn point is the last bed or the spawn.
- Creatures are not simulated while the game is closed (no offline raids).

## Known gaps (honest)

- No browser playtest; UI layout, focus recovery and audio are unverified in a live session.
- `npm test` is not wired (`npx vitest run` is the command).
- Creature and Elder balance, telegraph readability and difficulty are not tuned.
- No weather forecast UI; only current weather is shown.
- Roof occlusion is an alpha fade near the player, not per-tile wall occlusion.
- Elder "awakened" differs by palette and aura, not by a fully separate silhouette.
- Sound is fully synthesized (WebAudio); not mixed or tuned by ear.
- Profile purchases and deposits use per-run keys; no cross-device sync or verification exists, by design.
- Gold original art is not available: no fidelity is claimed (`GOLD_SOURCE_NOT_AVAILABLE`).
