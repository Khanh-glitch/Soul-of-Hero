# Provenance and licenses

## Original art and audio

- **Pixel art**: generated in code (`src/game/art/pix.ts`, `src/game/art/sprites.ts`). No third-party sprites, tilesets or sound files are bundled. Every ground tile, prop, building, character, creature, Elder and icon is produced by procedural masks and shading written for this project. Ownership: this project.
- **Sound**: synthesized at runtime with WebAudio oscillators and noise (`src/game/audio.ts`). No audio files.
- **Gold originals**: not used and not available (`GOLD_SOURCE_NOT_AVAILABLE`).

## Fonts (bundled locally)

| Asset | Package | License |
| --- | --- | --- |
| Press Start 2P | `@fontsource/press-start-2p` | SIL Open Font License 1.1 (see `node_modules/@fontsource/press-start-2p/LICENSE`) |
| VT323 | `@fontsource/vt323` | SIL Open Font License 1.1 (see `node_modules/@fontsource/vt323/LICENSE`) |

Both fonts are included in the built `dist/index.html`. The build makes no runtime network request.

## Design sources

- **Soul of Hero Gameplay Bible** (`CURRENT_PRODUCT_CONTRACT.md`) read from the public GitHub raw URL during this build. Excerpts were used for invariants. The document is not copied into the project and not redistributed. Its license terms were not checked in this run; no code or text from it is reproduced beyond identifiers and short paraphrases in comments.

## Software dependencies

Direct dependencies from `package.json` and their intended licenses. Each was not individually re-verified against its package file in this run; check `node_modules/<package>/LICENSE` before redistribution.

| Package | Use | Expected license |
| --- | --- | --- |
| react, react-dom | UI | MIT |
| vite, @vitejs/plugin-react | build and dev server | MIT |
| vite-plugin-singlefile | single-file build | MIT |
| tailwindcss, @tailwindcss/vite | CSS toolchain | MIT |
| typescript | type checking | Apache-2.0 |
| vitest | tests | MIT |
| clsx, tailwind-merge | existing utilities (`src/utils/cn.ts`) | MIT |
| @types/react, @types/react-dom, @types/node | type definitions | MIT |
| @fontsource/press-start-2p, @fontsource/vt323 | fonts | OFL-1.1 (LICENSE files present in node_modules; their contents were not re-read in this run) |

## Not used

No external pixel-art packs, no CDN scripts, no remote fonts, no remote APIs, no secrets and no paid services.
