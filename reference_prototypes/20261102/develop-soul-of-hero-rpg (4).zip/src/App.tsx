// Root shell: canvas stage with integer scaling, title flow (adventurer → landing → run), records, options.
import { useEffect, useReducer, useRef, useState } from 'react';
import '@fontsource/press-start-2p/400.css';
import '@fontsource/vt323/400.css';
import { Engine } from './game/engine';
import { ELDERS, SPAWNS, BAL } from './game/data/catalog';
import { getWorld } from './game/world/world';
import { pixCanvas, minimapCanvas, VIEW_W, VIEW_H } from './game/render';
import { heroSprite } from './game/art/sprites';
import { Game, RecordsView } from './ui/Game';

type Gender = 'male' | 'female';
type Sub = 'main' | 'gender' | 'spawn' | 'records' | 'options';

const calcScale = (): number => {
  const raw = Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H);
  return raw >= 1 ? Math.floor(raw) : Math.max(0.5, Number(raw.toFixed(2)));
};

function Preview({ gender }: { gender: Gender }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, 16, 24);
    g.drawImage(pixCanvas(heroSprite({ gender, facing: 'down', frame: 0, moving: false }).p), 0, 0);
  }, [gender]);
  return <canvas ref={ref} width={16} height={24} className="preview" aria-hidden="true" />;
}

function SpawnThumb({ x, y }: { x: number; y: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, 48, 48);
    const m = minimapCanvas(getWorld());
    g.drawImage(m, Math.max(0, x - 24), Math.max(0, y - 24), 48, 48, 0, 0, 48, 48);
  }, [x, y]);
  return <canvas ref={ref} width={48} height={48} className="thumb" aria-hidden="true" />;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [eng, setEng] = useState<Engine | null>(null);
  const [, bump] = useReducer((x: number) => x + 1, 0);
  const [scale, setScale] = useState<number>(calcScale);
  const [sub, setSub] = useState<Sub>('main');
  const [gender, setGender] = useState<Gender>('male');
  const [volume, setVolume] = useState(0.6);

  useEffect(() => {
    const on = () => setScale(calcScale());
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);

  useEffect(() => {
    const e = new Engine(canvasRef.current!);
    setEng(e);
    const off = e.subscribe(bump);
    e.start();
    void e.boot();
    return () => {
      off();
      e.stop();
    };
  }, []);

  const W = VIEW_W * scale, H = VIEW_H * scale;
  const ui = eng?.ui;
  const snap = eng ? eng.snapshot() : null;
  const inGame = ui?.screen === 'game';
  const hasActive = !!snap && snap.state.run.status === 'active';
  const last = snap && snap.state.run.id > 0 && snap.state.run.status === 'ended' ? snap.state.run : null;

  return (
    <div className="stage">
      <div className="stage-inner" style={{ width: W, height: H }}>
        <canvas ref={canvasRef} width={VIEW_W} height={VIEW_H} className="world-canvas" style={{ width: W, height: H }} aria-label="Soul of Hero game world" />
        <div className="overlay" style={{ zoom: scale }}>
          {eng && !inGame && (
            <div className="title">
              <div className="logo">SOUL OF HERO</div>
              <div className="tag">A solo island survival RPG · 14-day Ragnarok runs</div>
              {!ui?.ready && <div className="dim">Waking the island…</div>}
              {sub === 'main' && ui?.ready && (
                <div className="menu-col">
                  {hasActive && <button className="pxbtn big" onClick={() => eng.continueRun()}>Continue run {snap!.state.run.id} · day {snap!.phase.day}</button>}
                  <button className="pxbtn big" onClick={() => setSub('gender')}>{hasActive ? 'Start a different run' : 'New run'}</button>
                  <button className="pxbtn" onClick={() => setSub('records')}>Records (browser-local)</button>
                  <button className="pxbtn" onClick={() => setSub('options')}>Options</button>
                  {last && <div className="last dim">Last run #{last.id}: {last.outcome ?? 'ended'} · score {last.score} · secured cash {snap!.state.profile.secured}</div>}
                  {ui.notes.map((n, i) => <div key={i} className="warn">{n}</div>)}
                  <div className="dim small">Saves are local (IndexedDB). Nothing is sent online. {eng.ui.qa ? 'QA clock enabled.' : ''}</div>
                </div>
              )}
              {sub === 'gender' && (
                <div className="pick">
                  <h2>Choose your Adventurer</h2>
                  <div className="cards">
                    {(['male', 'female'] as Gender[]).map((g) => (
                      <button key={g} className={`card pxp${gender === g ? ' on' : ''}`} onClick={() => setGender(g)} aria-pressed={gender === g}>
                        <Preview gender={g} />
                        <b>{g === 'male' ? 'Male Adventurer' : 'Female Adventurer'}</b>
                        <span className="dim">{g === 'male' ? 'Steady swing; teal tunic; heavier pack.' : 'Quicker roll and lighter step; plum tunic.'}</span>
                      </button>
                    ))}
                  </div>
                  <div className="row-btns">
                    <button className="pxbtn" onClick={() => setSub('main')}>Back</button>
                    <button className="pxbtn big" onClick={() => setSub('spawn')}>Next: choose a landing</button>
                  </div>
                </div>
              )}
              {sub === 'spawn' && (
                <div className="pick">
                  <h2>Where do you wash ashore?</h2>
                  <div className="cards spawns">
                    {SPAWNS.map((sp) => {
                      const w = getWorld().spawns[sp.id];
                      return (
                        <button key={sp.id} className="card pxp" onClick={() => eng.newRun(sp.id, gender)}>
                          <SpawnThumb x={w.x} y={w.y} />
                          <b>{sp.name}</b>
                          <span className="dim">{sp.blurb}</span>
                        </button>
                      );
                    })}
                    <button className="card pxp" onClick={() => eng.newRun(SPAWNS[Math.floor(Math.random() * SPAWNS.length)].id, gender)}>
                      <b>Surprise me</b>
                      <span className="dim">A random safe landing among the four starts.</span>
                    </button>
                  </div>
                  <div className="row-btns">
                    <button className="pxbtn" onClick={() => setSub('gender')}>Back</button>
                  </div>
                </div>
              )}
              {sub === 'records' && (
                <div className="pick">
                  <h2>Records</h2>
                  <RecordsView profile={snap!.state.profile} onClose={() => setSub('main')} />
                </div>
              )}
              {sub === 'options' && (
                <div className="pick">
                  <h2>Options</h2>
                  <label className="vol">Sound volume <input type="range" min={0} max={1} step={0.05} value={volume} onChange={(e) => { setVolume(Number(e.target.value)); eng.audio.setVolume(Number(e.target.value)); }} /></label>
                  <button className="pxbtn" onClick={() => { eng.audio.setMuted(!eng.audio.muted); bump(); }}>{eng.audio.muted ? 'Unmute' : 'Mute'}</button>
                  <p className="dim small">Ragnarok window: last {BAL.run.ragnarokHours} real hours of a {BAL.run.maxHours}-hour run. Elders: {ELDERS.map((e) => e.name).join(', ')}.</p>
                  <button className="pxbtn" onClick={() => setSub('main')}>Back</button>
                </div>
              )}
            </div>
          )}
          {eng && inGame && snap && <Game engine={eng} snap={snap} />}
        </div>
      </div>
    </div>
  );
}
