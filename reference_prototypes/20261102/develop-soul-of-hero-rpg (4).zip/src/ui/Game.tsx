// In-game HUD and panels. Panels submit intents to the engine and read snapshots; they never mutate world state.
import { useEffect, useRef, useState } from 'react';
import type { Engine } from '../game/engine';
import { ITEMS, RECIPES, STRUCTS, RUN_STOCK, BAL, ACH } from '../game/data/catalog';
import { invCap, cashCount, Loc, Maybe, Structure, RUN_MS, Profile, countInv } from '../game/state';
import { pixCanvas, minimapCanvas } from '../game/render';
import { iconPix, heroSprite } from '../game/art/sprites';
import { getWorld } from '../game/world/world';

export type Snap = ReturnType<Engine['snapshot']>;

const pct = (v: number, max: number): string => `${Math.max(0, Math.min(100, (v / max) * 100))}%`;
const hms = (ms: number): string => {
  const t = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(t / 3600)).padStart(2, '0')}:${String(Math.floor((t % 3600) / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
};

function Icon({ id, px = 16 }: { id: string; px?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, 16, 16);
    g.drawImage(pixCanvas(iconPix(id)), 0, 0);
  }, [id]);
  return <canvas ref={ref} width={16} height={16} className="icon" style={{ width: px, height: px }} aria-hidden="true" />;
}

function Portrait({ gender }: { gender: 'male' | 'female' }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, 16, 24);
    g.drawImage(pixCanvas(heroSprite({ gender, facing: 'down', frame: 0, moving: false }).p), 0, 0);
  }, [gender]);
  return <canvas ref={ref} width={16} height={24} className="portrait" aria-label="Adventurer" />;
}

function Win({ title, onClose, children, wide = false }: { title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={`win pxp${wide ? ' wide' : ''}`} role="dialog" aria-label={title}>
      <div className="win-title">
        <span>{title}</span>
        <button className="pxbtn small" onClick={onClose} aria-label="Close panel">X</button>
      </div>
      <div className="win-body">{children}</div>
    </div>
  );
}

function Bar({ label, v, max, color }: { label: string; v: number; max: number; color: string }) {
  return (
    <div className="bar-row">
      <span className="bar-label">{label}</span>
      <div className="pxbar"><i style={{ width: pct(v, max), background: color }} /></div>
    </div>
  );
}

function Hud({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  const p = s.actors.player;
  const ph = snap.phase;
  const hot = snap.ui.hot;
  const core = s.custody.inv.find((x) => x && x.item === 'ember_core');
  const cart = p.hitched ? Object.values(s.entities.structures).find((x) => x.id === p.hitched) : undefined;
  const cw = cart ? (cart.slots ?? []).reduce((a, sl) => a + (sl ? ITEMS[sl.item].w * sl.qty : 0), 0) : 0;
  const h = Math.floor(ph.clockH), m = Math.floor((ph.clockH - h) * 60);
  const left = ph.leftMs;
  const wxLabel: Record<string, string> = { clear: 'Clear', cloudy: 'Overcast', rain: 'Rain', storm: 'Storm', fog: 'Fog' };
  const danger = p.hp < 30;
  return (
    <>
      <div className="hud-tl">
        <div className="vitals pxp">
          <Portrait gender={s.run.gender} />
          <div className="bars">
            <Bar label="HP" v={p.hp} max={p.maxHp} color="#e8483a" />
            <Bar label="STA" v={p.stamina} max={100} color="#7fe07a" />
            <Bar label="FOOD" v={p.hunger} max={100} color="#e0b35a" />
            <Bar label="WARM" v={p.warmth} max={100} color="#7fd6ff" />
            {p.toxin > 1 && <Bar label="TOXIN" v={p.toxin} max={100} color="#9be05c" />}
          </div>
        </div>
        <div className="toasts" aria-live="polite">
          {snap.ui.toasts.map((t) => <div key={t.id} className="toast">{t.text}</div>)}
        </div>
      </div>
      <div className="hud-tr pxp">
        <div className="hud-line"><b>Day {ph.day}</b> · {String(h).padStart(2, '0')}:{String(m).padStart(2, '0')} · {ph.phase}</div>
        <div className="hud-line">Run {Math.floor(ph.hours)}h / {RUN_MS / 3600000}h · {wxLabel[s.world.wx] ?? s.world.wx}</div>
        <div className="hud-line dim">{engine.live.lastRegion || 'Wilds'}{s.custody.inv.some((x) => x && x.item === 'ragnarok_cash') ? ` · Cash ${cashCount(s)} (unsecured)` : ''}</div>
        {ph.ragnarok && <div className="hud-line danger">RAGNAROK · {hms(left)} left</div>}
      </div>
      {snap.ui.buildKind && (
        <div className="build-banner pxp">BUILD: {STRUCTS[snap.ui.buildKind]?.name} · left-click to place · right-click or Esc to cancel</div>
      )}
      <div className="hotbar">
        {Array.from({ length: 8 }, (_, i) => {
          const sl = s.custody.inv[i];
          return (
            <button key={i} className={`slot${hot === i ? ' sel' : ''}`} onClick={() => { engine.ui.hot = i; engine.dispatch({ type: 'sort' }); }} aria-label={`Hotbar ${i + 1}${sl ? ` ${ITEMS[sl.item].name}` : ''}`}>
              <span className="key">{i + 1}</span>
              {sl && <Icon id={sl.item} px={16} />}
              {sl && sl.qty > 1 && <span className="qty">{sl.qty}</span>}
            </button>
          );
        })}
      </div>
      <div className="hud-bl pxp">
        <div className="hud-line">{s.custody.equip.weapon ? <><Icon id={s.custody.equip.weapon.item} /> {ITEMS[s.custody.equip.weapon.item].name}</> : 'Bare hands'}</div>
        <div className="hud-line">Q whirl · F Core{core ? ` (${core.charges ?? 0})` : ' (none)'} · Space roll</div>
        {cart && <div className="hud-line">Cart pulled · cargo {cw.toFixed(0)} wt</div>}
      </div>
      <div className="hud-br dim">WASD move · Shift sprint · click attack · E use · I bag · C craft · B build · R study · M map · Tab skills · Esc menu</div>
      {danger && <div className="danger-vignette" />}
    </>
  );
}

function Grid({ slots, mk, sel, onPick, onAlt, label }: { slots: Maybe[]; mk: (i: number) => Loc; sel: Loc | null; onPick: (l: Loc, sl: Maybe) => void; onAlt: (l: Loc, sl: Maybe) => void; label: string }) {
  return (
    <div className="grid-wrap">
      <div className="grid-label">{label}</div>
      <div className="grid">
        {slots.map((sl, i) => {
          const loc = mk(i);
          const picked = sel && JSON.stringify(sel) === JSON.stringify(loc);
          return (
            <button key={i} className={`slot${picked ? ' sel' : ''}`} onClick={() => onPick(loc, sl)} onContextMenu={(e) => { e.preventDefault(); onAlt(loc, sl); }} aria-label={sl ? `${ITEMS[sl.item].name} ×${sl.qty}` : 'Empty slot'}>
              {sl && <Icon id={sl.item} px={16} />}
              {sl && sl.qty > 1 && <span className="qty">{sl.qty}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function InvPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  const target = snap.ui.target;
  const [sel, setSel] = useState<Loc | null>(null);
  const cap = invCap(s);
  const move = (from: Loc, to: Loc) => {
    engine.dispatch({ type: 'move', from, to });
    setSel(null);
  };
  const pick = (loc: Loc, sl: Maybe) => {
    if (sel) move(sel, loc);
    else if (sl) setSel(loc);
  };
  const alt = (loc: Loc, sl: Maybe) => {
    if (!sl) return;
    const d = ITEMS[sl.item];
    if (loc.k === 'inv') {
      if (d.food || d.heal || d.cure) engine.dispatch({ type: 'eat', i: loc.i });
      else if (d.slot) engine.dispatch({ type: 'equip', i: loc.i });
    } else if (loc.k === 'eq') engine.dispatch({ type: 'unequip', slot: loc.slot });
    else setSel(loc);
  };
  let right: React.ReactNode = null;
  if (target?.startsWith('bag:')) {
    const bid = target.slice(4);
    const b = s.custody.bags.find((x) => x.id === bid);
    right = b ? <Grid label={`Death bag · ${b.slots.length} stacks`} slots={b.slots} mk={(i) => ({ k: 'bag', id: bid, i })} sel={sel} onPick={pick} onAlt={alt} /> : <p className="dim">This bag has been recovered.</p>;
    if (b) right = <>{right}<button className="pxbtn" onClick={() => engine.dispatch({ type: 'bag_loot', id: bid })}>Recover all</button></>;
  } else if (target) {
    const st: Structure | undefined = s.entities.structures[target];
    if (st?.kind === 'chest' || st?.kind === 'furnace') {
      right = st.kind === 'chest'
        ? <Grid label="Storage chest" slots={st.slots ?? []} mk={(i) => ({ k: 'st', id: st.id, slot: 'slots', i })} sel={sel} onPick={pick} onAlt={alt} />
        : (
          <div className="furnace">
            <div className="grid-label">Furnace · {st.burn && st.burn > 0 ? `burning ${Math.ceil(st.burn)}s` : 'cold'}</div>
            <div className="furn-row">
              <span>Fuel</span><button className={`slot${sel && sel.k === 'st' && sel.slot === 'fuel' ? ' sel' : ''}`} onClick={() => pick({ k: 'st', id: st.id, slot: 'fuel' }, st.fuel ?? null)}>{st.fuel && <Icon id={st.fuel.item} />}{st.fuel && st.fuel.qty > 1 && <span className="qty">{st.fuel.qty}</span>}</button>
              <span>Ore / meat</span><button className={`slot${sel && sel.k === 'st' && sel.slot === 'input' ? ' sel' : ''}`} onClick={() => pick({ k: 'st', id: st.id, slot: 'input' }, st.input ?? null)}>{st.input && <Icon id={st.input.item} />}{st.input && st.input.qty > 1 && <span className="qty">{st.input.qty}</span>}</button>
              <span>Output</span><button className={`slot${sel && sel.k === 'st' && sel.slot === 'output' ? ' sel' : ''}`} onClick={() => pick({ k: 'st', id: st.id, slot: 'output' }, st.output ?? null)}>{st.output && <Icon id={st.output.item} />}{st.output && st.output.qty > 1 && <span className="qty">{st.output.qty}</span>}</button>
            </div>
            {st.job && <div className="bar-row"><span className="bar-label">Work</span><div className="pxbar"><i style={{ width: pct(st.job.progress, st.job.need), background: '#ff8a3d' }} /></div></div>}
            <p className="dim small-note">Fuel burns only while work is paid for. Output waits in its slot; nothing completes after the fire dies.</p>
          </div>
        );
    } else if (st) {
      right = <p className="dim">{STRUCTS[st.kind]?.name ?? st.kind} stores nothing.</p>;
    }
  }
  return (
    <Win title={`Pack · ${cap} slots${s.custody.equip.pack ? ' (field pack)' : ''}`} onClose={() => engine.setPanel(null)} wide>
      <div className="split">
        <div>
          <Grid label="Carried" slots={s.custody.inv.slice(0, cap)} mk={(i) => ({ k: 'inv', i })} sel={sel} onPick={pick} onAlt={alt} />
          <div className="equip-row">
            {(['weapon', 'armor', 'pack'] as const).map((k) => {
              const sl = s.custody.equip[k];
              const loc: Loc = { k: 'eq', slot: k };
              const picked = sel && sel.k === 'eq' && sel.slot === k;
              return (
                <button key={k} className={`slot wide-slot${picked ? ' sel' : ''}`} onClick={() => pick(loc, sl)} onContextMenu={(e) => { e.preventDefault(); alt(loc, sl); }} aria-label={`${k} slot`}>
                  <span className="key">{k}</span>
                  {sl && <Icon id={sl.item} px={16} />}
                  {sl && <span className="qty">{ITEMS[sl.item].name.split(' ')[0]}</span>}
                </button>
              );
            })}
          </div>
          <div className="row-btns">
            <button className="pxbtn" onClick={() => engine.dispatch({ type: 'sort' })}>Sort</button>
            <button className="pxbtn" disabled={!sel || sel.k !== 'inv'} onClick={() => { if (sel && sel.k === 'inv') engine.dispatch({ type: 'drop', i: sel.i }); setSel(null); }}>Drop</button>
            <button className="pxbtn" disabled={!sel} onClick={() => setSel(null)}>Cancel</button>
          </div>
          <p className="dim small-note">Click one thing, then click where it goes. Right-click eats, equips or unequips. Chests, carts and furnaces are reached by walking up to them.</p>
        </div>
        <div>{right}</div>
      </div>
      {sel && <div className="sel-info">Selected: {(() => {
        const sl = sel.k === 'inv' ? s.custody.inv[sel.i] : sel.k === 'eq' ? s.custody.equip[sel.slot] : null;
        return sl ? `${ITEMS[sl.item].name} — ${ITEMS[sl.item].desc}` : 'Choose a destination.';
      })()}</div>}
    </Win>
  );
}

function CraftPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  const near = Object.values(s.entities.structures).some((st) => st.kind === 'workbench' && Math.hypot(st.tx * 16 + 8 - s.actors.player.x, st.ty * 16 + 8 - s.actors.player.y) <= 64);
  return (
    <Win title={`Craft · ${near ? 'workbench in reach' : 'hand crafting only'}`} onClose={() => engine.setPanel(null)} wide>
      <div className="list">
        {RECIPES.filter((r) => r.st !== 'furn').map((r) => {
          const known = r.known || s.knowledge.learned.includes(r.id);
          const need = r.inp.map(([i, q]) => ({ i, q, have: countInv(s, i) }));
          const ok = known && need.every((x) => x.have >= x.q) && (r.st !== 'bench' || near);
          const why = !known ? 'Study a blueprint at a desk to learn this.' : r.st === 'bench' && !near ? 'Needs a workbench nearby.' : need.find((x) => x.have < x.q) ? 'Missing materials.' : '';
          return (
            <div key={r.id} className={`row${known ? '' : ' locked'}`}>
              <Icon id={r.out[0]} />
              <div className="row-main">
                <b>{r.name}</b> <span className="dim">{r.st === 'bench' ? 'bench' : 'hand'}</span>
                <div className="cost">{need.map((x) => <span key={x.i} className={x.have >= x.q ? 'ok' : 'bad'}>{ITEMS[x.i].name} {x.have}/{x.q}</span>)}</div>
                {!ok && why && <div className="why">{why}</div>}
              </div>
              <button className="pxbtn small" disabled={!ok} onClick={() => engine.dispatch({ type: 'craft', recipe: r.id })}>Craft</button>
            </div>
          );
        })}
      </div>
      <p className="dim small-note">Furnace recipes (charcoal, smelting, cooking) run from a furnace’s own input and fuel slots.</p>
    </Win>
  );
}

function BuildPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  return (
    <Win title="Build · choose a piece, then click owned ground" onClose={() => engine.setPanel(null)} wide>
      <div className="list">
        {Object.entries(STRUCTS).map(([k, d]) => {
          const kit = d.cost.length === 0 && d.kit;
          const have = kit ? countInv(s, d.kit!) : 0;
          const ok = kit ? have > 0 : d.cost.every(([i, q]) => countInv(s, i) >= q);
          return (
            <div key={k} className="row">
              <Icon id={d.kit && ITEMS[d.kit] ? d.kit : 'plank'} />
              <div className="row-main">
                <b>{d.name}</b> <span className="dim">{d.desc}</span>
                <div className="cost">{kit ? <span className={have ? 'ok' : 'bad'}>Needs {ITEMS[d.kit!].name} ({have})</span> : d.cost.map(([i, q]) => <span key={i} className={countInv(s, i) >= q ? 'ok' : 'bad'}>{ITEMS[i].name} {countInv(s, i)}/{q}</span>)}</div>
              </div>
              <button className="pxbtn small" disabled={!ok} onClick={() => { engine.ui.buildKind = k; engine.setPanel(null); }}>Place</button>
            </div>
          );
        })}
      </div>
    </Win>
  );
}

function ResearchPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  const target = snap.ui.target;
  const desk = target ? s.entities.structures[target] : undefined;
  const job = desk ? Object.values(s.jobs).find((j) => j.desk === desk.id) : undefined;
  return (
    <Win title="Study desk · blueprints and specimens" onClose={() => engine.setPanel(null)} wide>
      {!desk && <p className="dim">Stand at a study desk and press E.</p>}
      {job && <div className="bar-row"><span className="bar-label">Study</span><div className="pxbar"><i style={{ width: pct(job.progress, job.need), background: '#7fd6ff' }} /></div></div>}
      <div className="list">
        {RECIPES.filter((r) => r.study).map((r) => {
          const known = r.known || s.knowledge.learned.includes(r.id);
          const cost = r.study!;
          const alt = r.studyAlt ?? [];
          const have = cost.every(([i, q]) => countInv(s, i) >= q);
          const haveAlt = alt.length > 0 && alt.every(([i, q]) => countInv(s, i) >= q);
          return (
            <div key={r.id} className={`row${known ? ' locked' : ''}`}>
              <Icon id={r.out[0]} />
              <div className="row-main">
                <b>{r.name}</b> {known && <span className="ok">learned this run</span>}
                <div className="cost">{cost.map(([i, q]) => <span key={i} className={countInv(s, i) >= q ? 'ok' : 'bad'}>{ITEMS[i].name} {countInv(s, i)}/{q}</span>)}</div>
                {alt.length > 0 && <div className="dim small-note">or {alt.map(([i, q]) => `${ITEMS[i].name} ×${q}`).join(' + ')}</div>}
              </div>
              <button className="pxbtn small" disabled={known || !desk || !!job || !(have || haveAlt)} onClick={() => desk && engine.dispatch({ type: 'study', desk: desk.id, recipe: r.id, now: engine.now() })}>Study</button>
            </div>
          );
        })}
      </div>
      <p className="dim small-note">Studying is run-local: the recipe is lost when the run ends. Work progresses with real elapsed time, even when the game is closed.</p>
    </Win>
  );
}

function MapPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const s = snap.state;
  useEffect(() => {
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    const w = getWorld();
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, 192, 192);
    g.drawImage(minimapCanvas(w), 0, 0);
    for (let cell = 0; cell < 576; cell++) {
      if (s.world.discovered[cell] === '1') continue;
      g.fillStyle = 'rgba(8,6,14,0.86)';
      g.fillRect((cell % 24) * 8, Math.floor(cell / 24) * 8, 8, 8);
    }
    for (const poi of w.pois) {
      if (poi.kind === 'chest' || (poi.kind === 'shrine' && poi.elder && s.actors.elders[poi.elder]?.defeated)) continue;
      const cell = Math.floor(poi.y / 8) * 24 + Math.floor(poi.x / 8);
      if (s.world.discovered[cell] !== '1') continue;
      g.fillStyle = poi.kind === 'shrine' ? '#c58cff' : poi.kind === 'trade' ? '#ffd27a' : poi.kind === 'dock' ? '#7fe07a' : '#ff5ad2';
      g.fillRect(poi.x - 2, poi.y - 2, 4, 4);
    }
    for (const c2 of s.world.claims) { g.fillStyle = '#7fe07a'; g.fillRect(c2.tx - 1, c2.ty - 1, 3, 3); }
    for (const b of s.custody.bags) { g.fillStyle = '#e0b35a'; g.fillRect(Math.floor(b.x / 16) - 1, Math.floor(b.y / 16) - 1, 3, 3); }
    const px = Math.floor(s.actors.player.x / 16), py = Math.floor(s.actors.player.y / 16);
    g.fillStyle = '#ffffff';
    g.fillRect(px - 2, py - 2, 5, 5);
    g.fillStyle = '#e8483a';
    g.fillRect(px - 1, py - 1, 3, 3);
  }, [s.world.discovered, s.world.claims.length, s.custody.bags.length, s.actors.player.x, s.actors.player.y, s.actors.elders]);
  return (
    <Win title="Map · what you have walked" onClose={() => engine.setPanel(null)}>
      <canvas ref={ref} width={192} height={192} className="map" aria-label="Island map" />
      <div className="legend dim small-note">White: you · red-gold: bags · green: home stakes · gold: trade post · cyan: green shrine glows · fog hides unvisited ground. Elders and chests stay hidden until you find them.</div>
    </Win>
  );
}

function VendorPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  const cash = cashCount(s);
  return (
    <Win title="Trade post vendor" onClose={() => engine.setPanel(null)} wide>
      <div className="list">
        <div className="row">
          <Icon id="escrow" />
          <div className="row-main">
            <b>Escrow Chest</b> <span className="dim">Physical Ragnarok Cash only. Place it inside owned land, then deposit.</span>
            <div className="cost"><span className={cash >= BAL.escrow.chestPriceCash ? 'ok' : 'bad'}>{BAL.escrow.chestPriceCash} Ragnarok Cash in pack ({cash})</span></div>
          </div>
          <button className="pxbtn small" onClick={() => engine.dispatch({ type: 'vendor_buy_escrow' })}>Buy</button>
        </div>
        {RUN_STOCK.map((st) => (
          <div key={st.item} className="row">
            <Icon id={st.item} />
            <div className="row-main">
              <b>{ITEMS[st.item].name}</b> <span className="dim">{ITEMS[st.item].desc}</span>
              <div className="cost"><span className={s.profile.secured >= st.price ? 'ok' : 'bad'}>{st.price} secured cash · you hold {s.profile.secured}</span></div>
            </div>
            <button className="pxbtn small" onClick={() => engine.dispatch({ type: 'vendor_buy_run', item: st.item, req: `buy-${st.item}-${Date.now()}` })}>Buy</button>
          </div>
        ))}
      </div>
      <p className="dim small-note">Secured cash never leaves your profile to pay for anything but stock here. Deposit cash at your escrow chest to secure it; nothing is credited automatically.</p>
    </Win>
  );
}

function MenuPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const [confirm, setConfirm] = useState(false);
  const elapsedH = snap.phase.hours;
  const toRag = Math.max(0, BAL.run.maxHours - BAL.run.ragnarokHours - elapsedH);
  return (
    <Win title="Menu" onClose={() => engine.setPanel(null)}>
      <div className="menu">
        <button className="pxbtn" onClick={() => engine.setPanel(null)}>Resume</button>
        <button className="pxbtn" onClick={() => { void engine.saveNow(); engine.toast('Saved locally.'); }}>Save now</button>
        <button className="pxbtn" onClick={() => engine.setPanel('records')}>Records (local)</button>
        <button className="pxbtn" onClick={() => engine.audio.setMuted(!engine.audio.muted)}>{engine.audio.muted ? 'Unmute' : 'Mute'} sound</button>
        <label className="vol">Volume <input type="range" min={0} max={1} step={0.05} defaultValue={engine.audio.volume} onChange={(e) => engine.audio.setVolume(Number(e.target.value))} /></label>
        {!confirm ? <button className="pxbtn danger" onClick={() => setConfirm(true)}>Abandon run…</button> : (
          <div className="confirm">
            <p>Abandoning ends this run. Unsecured cash, gear, home and studies are lost. Records are kept.</p>
            <button className="pxbtn danger" onClick={() => { engine.abandon(); }}>Yes, abandon</button>
            <button className="pxbtn" onClick={() => setConfirm(false)}>Keep playing</button>
          </div>
        )}
        <button className="pxbtn" onClick={() => engine.toTitle()}>Save and quit to title</button>
        {engine.ui.qa && (
          <div className="qa">
            <div className="qa-title">QA CLOCK · UNVERIFIED · not real elapsed time</div>
            <button className="pxbtn small" onClick={() => engine.qaJump(1)}>+1 hour</button>
            <button className="pxbtn small" onClick={() => engine.qaJump(24)}>+1 day</button>
            <button className="pxbtn small" onClick={() => engine.qaJump(toRag + 0.01)}>Jump to Ragnarok</button>
            <button className="pxbtn small" onClick={() => engine.qaJump(72)}>+72 h</button>
          </div>
        )}
      </div>
    </Win>
  );
}

export function RecordsView({ profile, onClose }: { profile: Profile; onClose?: () => void }) {
  const best = [...profile.history].sort((a, b) => b.score - a.score).slice(0, 5);
  return (
    <div className="records">
      <div className="dim">Browser-local history. Not verified and not a worldwide ranking. Score never becomes currency.</div>
      <div className="kv"><span>Secured Ragnarok Cash</span><b>{profile.secured}</b></div>
      <div className="kv"><span>Runs started</span><b>{profile.runs}</b></div>
      <div className="section">Achievements</div>
      <div className="ach">
        {Object.entries(ACH).map(([k, a]) => <span key={k} className={profile.ach[k] ? 'ok' : 'dim'}>{profile.ach[k] ? '◆' : '◇'} {a.name} ({a.pts})</span>)}
      </div>
      <div className="section">Best local runs</div>
      {best.length === 0 && <p className="dim">No finished runs yet.</p>}
      {best.map((r) => (
        <div key={r.id} className="kv"><span>Run {r.id} · {r.outcome} · {r.spawn}</span><b>{r.score} pts · {r.stones}/6 stones</b></div>
      ))}
      {onClose && <button className="pxbtn" onClick={onClose}>Back</button>}
    </div>
  );
}

function ResultsPanel({ engine, snap }: { engine: Engine; snap: Snap }) {
  const s = snap.state;
  const r = s.run;
  const lost = s.custody.inv.filter((x) => x && x.item === 'ragnarok_cash').reduce((a, x) => a + (x?.qty ?? 0), 0);
  const text: Record<string, string> = {
    evacuated: 'You boarded the evacuation skiff. The run ends here with what you secured.',
    abandoned: 'You abandoned the run.',
    expired: 'The 14-day run reached its end.',
    none: 'No run in progress.'
  };
  return (
    <Win title="Run finished" onClose={() => engine.setPanel(null)}>
      <p>{text[r.outcome ?? 'none'] ?? 'The run is over.'}</p>
      <div className="kv"><span>Run</span><b>#{r.id}</b></div>
      <div className="kv"><span>Local score</span><b>{r.score}</b></div>
      <div className="kv"><span>Secured Ragnarok Cash (profile)</span><b>{s.profile.secured}</b></div>
      {lost > 0 && <p className="bad">{lost} unsecured cash was lost with the run. Deposit it at an escrow chest next time.</p>}
      <p className="dim small-note">Everything run-local (items, recipes, home, bags, stones) has been wiped. The profile keeps only secured cash, achievements and history.</p>
      <div className="row-btns">
        <button className="pxbtn" onClick={() => engine.toTitle()}>Back to title</button>
        <button className="pxbtn" onClick={() => engine.setPanel('records')}>Records</button>
      </div>
    </Win>
  );
}

export function Game({ engine, snap }: { engine: Engine; snap: Snap }) {
  const panel = snap.ui.panel;
  return (
    <>
      <Hud engine={engine} snap={snap} />
      {panel === 'inv' && <InvPanel engine={engine} snap={snap} />}
      {panel === 'craft' && <CraftPanel engine={engine} snap={snap} />}
      {panel === 'build' && <BuildPanel engine={engine} snap={snap} />}
      {panel === 'research' && <ResearchPanel engine={engine} snap={snap} />}
      {panel === 'map' && <MapPanel engine={engine} snap={snap} />}
      {panel === 'vendor' && <VendorPanel engine={engine} snap={snap} />}
      {panel === 'menu' && <MenuPanel engine={engine} snap={snap} />}
      {panel === 'results' && <ResultsPanel engine={engine} snap={snap} />}
      {panel === 'records' && (
        <Win title="Records · browser-local" onClose={() => engine.setPanel(null)} wide>
          <RecordsView profile={snap.state.profile} />
        </Win>
      )}
      {panel === 'skills' && (
        <Win title="Skills" onClose={() => engine.setPanel(null)}>
          <div className="list">
            <div className="row"><b>Dodge roll · Space</b><span className="dim">Brief invulnerability; costs stamina.</span></div>
            <div className="row"><b>Whirl · Q</b><span className="dim">Full-circle sweep with a melee weapon; hits everything near you. 3.2 s cooldown.</span></div>
            <div className="row"><b>Ember Core · F</b><span className="dim">Needs a charged Core. Burns grass, forest and marsh, and scorches roots. The charge is spent only when the blast lands; interrupted casts keep it.</span></div>
            <div className="row"><b>Longbow · click</b><span className="dim">Shoots arrows where you aim, 360°. Arrows are consumed.</span></div>
          </div>
        </Win>
      )}
      {panel === 'bag' && null}
      {panel === 'chest' && null}
    </>
  );
}


