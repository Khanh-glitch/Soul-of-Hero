// Canvas 2D presentation at 640×360 logical pixels. Crisp integer scaling is applied by CSS (image-rendering: pixelated).
// Ground is culled to the viewport and cached per autotile key; entities are y-sorted; telegraphs and VFX are drawn
// as pixel primitives so nothing blurs into vector-looking shapes.
import { Pix, C } from './art/pix';
import { groundPix, groundKey, edgeSides, objPix, structPix, heroSprite, creatureSprite, elderSprite, weaponSprite, iconPix, DIGITS, Sprite } from './art/sprites';
import { ITEMS, STRUCTS, CREATURES, BAL } from './data/catalog';
import { MAP_W, MAP_H, TILE, tkey, hash2, clamp } from './core/rng';
import { T, O, World, regionAt } from './world/world';
import { GameState, effObj, phaseInfo, daylight, Structure } from './state';
import { Live } from './sim';

export const VIEW_W = 640;
export const VIEW_H = 360;

const canvasOf = new WeakMap<Pix, HTMLCanvasElement>();
export function pixCanvas(p: Pix): HTMLCanvasElement {
  let c = canvasOf.get(p);
  if (c) return c;
  c = document.createElement('canvas');
  c.width = p.w;
  c.height = p.h;
  const g = c.getContext('2d')!;
  const img = g.createImageData(p.w, p.h);
  new Uint32Array(img.data.buffer).set(p.d);
  g.putImageData(img, 0, 0);
  canvasOf.set(p, c);
  return c;
}

const tileCache = new Map<number, HTMLCanvasElement>();
function tileCanvas(t: number, v: number, frame: number, sides: number[]): HTMLCanvasElement {
  const key = groundKey(t, v, frame, sides);
  let c = tileCache.get(key);
  if (!c) {
    c = pixCanvas(groundPix(t, v, frame, sides));
    tileCache.set(key, c);
  }
  return c;
}

let shrineIdx: Map<number, string> | null = null;
let shrineFor: World | null = null;
function shrineAt(w: World, k: number): string | undefined {
  if (shrineFor !== w || !shrineIdx) {
    shrineIdx = new Map();
    for (const p of w.pois) if (p.elder) shrineIdx.set(tkey(p.x, p.y), p.elder);
    shrineFor = w;
  }
  return shrineIdx.get(k);
}

/** Minimap rendered once per world; used by the map panel and spawn cards. */
let mini: HTMLCanvasElement | null = null;
export function minimapCanvas(w: World): HTMLCanvasElement {
  if (mini) return mini;
  const c = document.createElement('canvas');
  c.width = MAP_W;
  c.height = MAP_H;
  const g = c.getContext('2d')!;
  const img = g.createImageData(MAP_W, MAP_H);
  const d = new Uint32Array(img.data.buffer);
  const col: Record<number, number> = {
    [T.DEEP]: C('#1f4f78'), [T.SHALLOW]: C('#3e8fb0'), [T.SAND]: C('#e0c27a'), [T.GRASS]: C('#5d9b3e'), [T.FOREST]: C('#3c6d31'),
    [T.ROAD]: C('#a4774a'), [T.HILL]: C('#6f7d56'), [T.CLIFF]: C('#5b5652'), [T.MOUNTAIN]: C('#6e6a72'), [T.MARSH]: C('#4f5b3a'),
    [T.SNOW]: C('#e9f2f8'), [T.TUNDRA]: C('#7f9c88'), [T.DESERT]: C('#dc9a55'), [T.SCORCH]: C('#3f3129'), [T.SLAG]: C('#3b3536'),
    [T.BRIDGE]: C('#8b5a2b'), [T.RIVER]: C('#2b6f98'), [T.COBBLE]: C('#6f6b68'), [T.FLOOR]: C('#4a4256'), [T.CAVE]: C('#2e2a36'), [T.PIER]: C('#a07444')
  };
  for (let i = 0; i < MAP_W * MAP_H; i++) {
    let c2 = col[w.terrain[i]] ?? C('#ff00ff');
    if (w.obj[i] === O.OAK || w.obj[i] === O.PINE) c2 = C('#1f4a22');
    if (w.obj[i] === O.ROCK || w.obj[i] === O.IRON) c2 = C('#7b7f86');
    d[i] = c2;
  }
  g.putImageData(img, 0, 0);
  mini = c;
  return c;
}

function pxLine(g: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, col: string, a = 1): void {
  const n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, y1 - y0)));
  g.fillStyle = col;
  g.globalAlpha = a;
  for (let i = 0; i <= n; i++) g.fillRect(Math.round(x0 + ((x1 - x0) * i) / n), Math.round(y0 + ((y1 - y0) * i) / n), 1, 1);
  g.globalAlpha = 1;
}

function pxRing(g: CanvasRenderingContext2D, cx: number, cy: number, r: number, col: string, step = 3, a = 1): void {
  const n = Math.max(12, Math.round(r * 6));
  g.fillStyle = col;
  g.globalAlpha = a;
  for (let k = 0; k < n; k += step) {
    const ang = (k / n) * Math.PI * 2;
    g.fillRect(Math.round(cx + Math.cos(ang) * r), Math.round(cy + Math.sin(ang) * r), 1, 1);
  }
  g.globalAlpha = 1;
}

function pxText(g: CanvasRenderingContext2D, text: string, x: number, y: number, col: string, a = 1): void {
  g.fillStyle = col;
  g.globalAlpha = a;
  let ox = 0;
  for (const ch of text) {
    const rows = DIGITS[ch] ?? DIGITS[' '];
    for (let r = 0; r < 5; r++) for (let b = 0; b < 3; b++) if ((rows[r] >> (2 - b)) & 1) g.fillRect(x + ox + b, y + r, 1, 1);
    ox += 4;
  }
  g.globalAlpha = 1;
}

export interface DrawUi {
  buildKind?: string | null;
  buildTile?: { tx: number; ty: number } | null;
  buildValid?: boolean;
  prompt?: string;
  promptX?: number;
  promptY?: number;
  banner?: string;
  bannerA?: number;
  hold?: number;
  showDeath?: { x: number; y: number } | null;
}

function groundPass(g: CanvasRenderingContext2D, w: World, cx: number, cy: number, now: number, s: GameState | null): void {
  const frame = Math.floor(now / 260) % 4;
  const tx0 = Math.max(0, Math.floor(cx / TILE)), tx1 = Math.min(MAP_W - 1, Math.floor((cx + VIEW_W) / TILE));
  const ty0 = Math.max(0, Math.floor(cy / TILE)), ty1 = Math.min(MAP_H - 1, Math.floor((cy + VIEW_H) / TILE));
  const tAt = (x: number, y: number): number => (x < 0 || y < 0 || x >= MAP_W || y >= MAP_H ? T.DEEP : w.terrain[y * MAP_W + x]);
  for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
    const k = ty * MAP_W + tx;
    const t = w.terrain[k];
    const sides = edgeSides(t, [tAt(tx, ty - 1), tAt(tx + 1, ty), tAt(tx, ty + 1), tAt(tx - 1, ty)]);
    g.drawImage(tileCanvas(t, w.variant[k], frame, sides), tx * TILE - cx, ty * TILE - cy);
    const m = s?.world.mods[k];
    if (m?.burnt) {
      g.fillStyle = 'rgba(28,12,6,0.5)';
      g.fillRect(tx * TILE - cx, ty * TILE - cy, TILE, TILE);
      if (hash2(tx, ty, Math.floor(now / 400)) > 0.8) g.fillStyle = '#ff7a2a', g.fillRect(tx * TILE - cx + 6, ty * TILE - cy + 6, 2, 2);
    }
    if (m?.puddle) {
      const b = (Math.floor(now / 180) + tx) % 3;
      g.fillStyle = 'rgba(127,214,60,0.55)';
      g.fillRect(tx * TILE - cx + 3 + b, ty * TILE - cy + 5, 3, 2);
    }
  }
  if (s) {
    for (const st of Object.values(s.entities.structures)) {
      if (st.kind !== 'floor' && st.kind !== 'garden') continue;
      if (st.tx < tx0 || st.tx > tx1 || st.ty < ty0 || st.ty > ty1) continue;
      const sp = structPix(st.kind, { growth: st.plant ? Math.round(st.plant.growth * 3) : 0 });
      g.drawImage(pixCanvas(sp.p), st.tx * TILE - cx, st.ty * TILE - cy);
    }
  }
}

interface Drawable { y: number; draw: (g: CanvasRenderingContext2D) => void }

function drawSprite(g: CanvasRenderingContext2D, sp: Sprite, x: number, y: number, cx: number, cy: number, flip = false, alpha = 1): void {
  g.globalAlpha = alpha;
  const dx = Math.round(x - sp.ax - cx), dy = Math.round(y - sp.ay - cy);
  if (flip) {
    g.save();
    g.translate(Math.round(x - cx), 0);
    g.scale(-1, 1);
    g.drawImage(pixCanvas(sp.p), -Math.round(sp.ax), dy);
    g.restore();
  } else {
    g.drawImage(pixCanvas(sp.p), dx, dy);
  }
  g.globalAlpha = 1;
}

/** Draws the scene (ground, props, entities, FX, weather, light). `s` is null on the title backdrop. */
export function drawScene(g: CanvasRenderingContext2D, w: World, s: GameState | null, L: Live | null, now: number, ui: DrawUi): void {
  const shake = L ? L.shake : 0;
  const sx = (Math.random() - 0.5) * shake * 2, sy = (Math.random() - 0.5) * shake * 2;
  const focusX = L ? L.cam.x : 96 * TILE, focusY = L ? L.cam.y : 96 * TILE;
  const cx = clamp(Math.round(focusX - VIEW_W / 2 + sx), 0, MAP_W * TILE - VIEW_W);
  const cy = clamp(Math.round(focusY - VIEW_H / 2 + sy), 0, MAP_H * TILE - VIEW_H);
  g.fillStyle = '#0b1a2a';
  g.fillRect(0, 0, VIEW_W, VIEW_H);
  groundPass(g, w, cx, cy, now, s);

  const items: Drawable[] = [];
  const tx0 = Math.max(0, Math.floor(cx / TILE) - 2), tx1 = Math.min(MAP_W - 1, Math.floor((cx + VIEW_W) / TILE) + 1);
  const ty0 = Math.max(0, Math.floor(cy / TILE) - 3), ty1 = Math.min(MAP_H - 1, Math.floor((cy + VIEW_H) / TILE) + 1);
  const frame = Math.floor(now / 200);
  for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
    const k = ty * MAP_W + tx;
    const o = s ? effObj(s, k) : w.obj[k];
    if (!o) continue;
    const sp = objPix(o, w.variant[k], o === O.SHRINE ? shrineAt(w, k) : undefined);
    if (!sp) continue;
    const X = tx * TILE + sp.fw * 8, Y = ty * TILE + sp.fh * 16;
    items.push({ y: Y, draw: (gg) => drawSprite(gg, sp, X, Y, cx, cy) });
  }
  if (s) {
    for (const st of Object.values(s.entities.structures)) {
      if (st.kind === 'floor' || st.kind === 'roof' || st.kind === 'garden') continue;
      if (st.tx < tx0 || st.tx > tx1 || st.ty < ty0 || st.ty > ty1) continue;
      const sp = structPix(st.kind, structOpts(st, frame, s, now));
      const X = st.tx * TILE + 8, Y = st.ty * TILE + 16;
      items.push({ y: Y, draw: (gg) => drawSprite(gg, sp, X, Y, cx, cy) });
    }
    for (const gi of s.custody.ground) {
      if (gi.x < cx - 16 || gi.x > cx + VIEW_W + 16 || gi.y < cy - 16 || gi.y > cy + VIEW_H + 16) continue;
      const bob = Math.round(Math.sin(now / 240 + gi.x) * 1);
      const ic = iconPix(gi.item);
      items.push({ y: gi.y, draw: (gg) => {
        gg.fillStyle = 'rgba(0,0,0,0.25)';
        gg.fillRect(Math.round(gi.x - cx) - 5, Math.round(gi.y - cy) + 2, 10, 2);
        gg.drawImage(pixCanvas(ic), Math.round(gi.x - cx) - 8, Math.round(gi.y - cy) - 13 + bob);
      } });
    }
    for (const b of s.custody.bags) {
      const ic = iconPix('backpack');
      items.push({ y: b.y, draw: (gg) => {
        gg.fillStyle = 'rgba(0,0,0,0.3)';
        gg.fillRect(Math.round(b.x - cx) - 6, Math.round(b.y - cy) + 2, 12, 2);
        gg.drawImage(pixCanvas(ic), Math.round(b.x - cx) - 8, Math.round(b.y - cy) - 12);
        gg.fillStyle = '#e0b35a';
        gg.fillRect(Math.round(b.x - cx) - 1, Math.round(b.y - cy) - 14, 2, 2);
      } });
    }
    for (const e of ELDER_LIST) {
      const shrine = w.pois.find((q) => q.elder === e.id);
      const es = s.actors.elders[e.id];
      if (!shrine || !es || es.defeated) continue;
      const X = shrine.x * TILE + 8, Y = shrine.y * TILE + 26;
      if (X < cx - 40 || X > cx + VIEW_W + 40 || Y < cy - 60 || Y > cy + VIEW_H + 20) continue;
      const sp = elderSprite(e.id, es.awakened, frame);
      items.push({ y: Y, draw: (gg) => {
        if (es.awakened) {
          gg.globalAlpha = 0.35 + Math.sin(now / 300) * 0.12;
          gg.fillStyle = e.palette[0];
          gg.beginPath();
          gg.arc(X - cx, Y - 20 - cy, 26, 0, Math.PI * 2);
          gg.fill();
          gg.globalAlpha = 1;
        }
        drawSprite(gg, sp, X, Y, cx, cy);
        const hpf = es.hp / es.maxHp;
        gg.fillStyle = '#000';
        gg.fillRect(X - cx - 20, Y - 62 - cy, 40, 3);
        gg.fillStyle = e.palette[0];
        gg.fillRect(X - cx - 20, Y - 62 - cy, Math.round(40 * hpf), 3);
      } });
    }
    for (const cr of s.actors.creatures) {
      if (cr.x < cx - 24 || cr.x > cx + VIEW_W + 24 || cr.y < cy - 40 || cr.y > cy + VIEW_H + 24) continue;
      const a = L?.ai[cr.id];
      const mode = a?.mode ?? 'idle';
      const pose = mode === 'alert' || mode === 'rest' ? 'squash' : mode === 'hop' ? 'stretch' : mode === 'crouch' || mode === 'stalk' ? 'crouch' : mode === 'snort' || mode === 'charge' ? 'snort' : mode === 'draw' || mode === 'loose' ? 'draw' : mode === 'raise' || mode === 'snap' ? 'raise' : mode === 'pulse' ? 'glow' : mode === 'dive' || mode === 'swoop' ? 'flap' : 'idle';
      const sp = creatureSprite({ kind: cr.kind, frame, pose });
      const hop = mode === 'hop' && a ? -Math.sin((1 - a.t / 0.36) * Math.PI) * 6 : 0;
      const X = cr.x, Y = cr.y + hop;
      const flip = cr.kind === 'wolf' || cr.kind === 'boar' || cr.kind === 'archer' ? s.actors.player.x < cr.x : false;
      const def = CREATURES[cr.kind];
      items.push({ y: cr.y, draw: (gg) => {
        drawSprite(gg, sp, X, Y, cx, cy, flip);
        if (cr.hp < def.hp) {
          gg.fillStyle = '#000';
          gg.fillRect(Math.round(X - cx) - 7, Math.round(Y - cy) - sp.p.h - 3, 14, 3);
          gg.fillStyle = '#e8483a';
          gg.fillRect(Math.round(X - cx) - 7, Math.round(Y - cy) - sp.p.h - 3, Math.round((14 * Math.max(0, cr.hp)) / def.hp), 3);
        }
        if (mode === 'stun') {
          gg.fillStyle = '#ffd34d';
          gg.fillRect(Math.round(X - cx) - 4 + (frame % 2), Math.round(Y - cy) - sp.p.h - 6, 2, 2);
          gg.fillRect(Math.round(X - cx) + 3, Math.round(Y - cy) - sp.p.h - 7, 2, 2);
        }
      } });
    }
    // Player.
    const p = s.actors.player;
    const eq = s.custody.equip;
    const armor = eq.armor ? (ITEMS[eq.armor.item].col === 'iron' ? 'iron' : 'hide') : 'none';
    const facing = (['down', 'up', 'left', 'right'] as const)[L?.facing ?? 0];
    const hs = heroSprite({ gender: s.run.gender, facing, frame: Math.floor(L?.walk ?? 0) % 2, moving: !!L?.moving, armor, pack: !!eq.pack, flash: (L?.flash ?? 0) > 0.5 });
    const blink = (L?.iframes ?? 0) > 0 && Math.floor(now / 70) % 2 === 0;
    items.push({ y: p.y, draw: (gg) => {
      gg.fillStyle = 'rgba(0,0,0,0.3)';
      gg.fillRect(Math.round(p.x - cx) - 5, Math.round(p.y - cy) - 1, 10, 3);
      if (!blink) drawSprite(gg, hs, p.x, p.y, cx, cy);
      if (eq.weapon && L) drawWeapon(gg, s, L, p.x, p.y, cx, cy);
      if (ui.showDeath) drawNow(gg, ui.showDeath, cx, cy);
    } });
    if (s.actors.player.hitched) {
      const cart = Object.values(s.entities.structures).find((q) => q.id === s.actors.player.hitched);
      if (cart) {
        const X = p.x + 10, Y = p.y + 6;
        items.push({ y: Y - 1, draw: (gg) => drawSprite(gg, structPix('cart'), X, Y, cx, cy) });
      }
    }
  }
  items.sort((a, b) => a.y - b.y);
  for (const it of items) it.draw(g);
  if (s && L) drawEffects(g, s, L, cx, cy, now);
  if (s) {
    for (const st of Object.values(s.entities.structures)) {
      if (st.kind !== 'roof') continue;
      if (st.tx < tx0 || st.tx > tx1 || st.ty < ty0 || st.ty > ty1) continue;
      const near = Math.abs(st.tx * TILE + 8 - s.actors.player.x) < 20 && Math.abs(st.ty * TILE + 8 - s.actors.player.y) < 20;
      drawSprite(g, structPix('roof'), st.tx * TILE + 8, st.ty * TILE + 16, cx, cy, false, near ? 0.45 : 0.92);
    }
    drawWeather(g, s, now, cx, cy);
    drawLight(g, s, L, cx, cy, now);
  }
  drawHud(g, ui, now, cx, cy, s);
}

const ELDER_LIST = [
  { id: 'frost', palette: ['#bfeaff', '#5aa7d6', '#24476a'] as [string, string, string] },
  { id: 'ember', palette: ['#ffd27a', '#ff6a2c', '#5a1d12'] as [string, string, string] },
  { id: 'mire', palette: ['#c8ff7a', '#4f8f3a', '#1e3a22'] as [string, string, string] },
  { id: 'stone', palette: ['#e8dcc2', '#8f8578', '#3b3430'] as [string, string, string] },
  { id: 'tide', palette: ['#c9fbff', '#2ca9c0', '#103c4a'] as [string, string, string] },
  { id: 'grove', palette: ['#f0d6ff', '#8c59b8', '#2d1a40'] as [string, string, string] }
];

function structOpts(st: Structure, frame: number, s: GameState, now: number): { open?: boolean; frame?: number; growth?: number; lit?: boolean } {
  void now;
  if (st.kind === 'door') return { open: !!st.open };
  if (st.kind === 'furnace') return { frame, lit: (st.burn ?? 0) > 0 };
  if (st.kind === 'torch_post') return { frame };
  if (st.kind === 'escrow_chest') return { lit: s.profile.secured >= 0 };
  return {};
}

function drawNow(g: CanvasRenderingContext2D, at: { x: number; y: number }, cx: number, cy: number): void {
  void at; void cx; void cy; void g;
}

function drawWeapon(g: CanvasRenderingContext2D, s: GameState, L: Live, px: number, py: number, cx: number, cy: number): void {
  const wpn = s.custody.equip.weapon!;
  const def = ITEMS[wpn.item];
  const A = L.atk;
  let ang = L.aim;
  if (A.kind === 'swing' || A.kind === 'spin') {
    if (A.phase === 'windup') ang = A.ang - 1.1 + (A.time / Math.max(0.01, A.dur[0])) * 0.9;
    else if (A.phase === 'contact') ang = A.ang - 0.2 + (A.time / Math.max(0.01, A.dur[1])) * 1.6 - 0.8 + 0.8;
    else if (A.phase === 'recover') ang = A.ang + (A.time / Math.max(0.01, A.dur[2])) * 0.25;
    if (A.kind === 'spin' && A.phase === 'contact') ang = A.ang + (A.time / Math.max(0.01, A.dur[1])) * Math.PI * 2;
  }
  const gx = px + Math.cos(L.aim) * 2, gy = py - 9 + Math.sin(L.aim) * 2;
  if (A.phase === 'contact' && A.kind === 'swing') {
    // Pixel swing arc: dots at the reach radius along the swept angles.
    const reach = (def.reach ?? 20) + 4;
    const steps = 18;
    for (let i = 0; i < steps; i++) {
      const a = ang - 0.9 + (i / steps) * 1.8;
      g.fillStyle = i > steps * 0.6 ? '#ffffff' : '#c9e8ff';
      g.globalAlpha = 0.25 + (i / steps) * 0.6;
      g.fillRect(Math.round(px + Math.cos(a) * reach - cx), Math.round(py - 8 + Math.sin(a) * reach - cy), 2, 1);
    }
    g.globalAlpha = 1;
  }
  const ws = weaponSprite(wpn.item);
  g.save();
  g.translate(Math.round(gx - cx), Math.round(gy - cy));
  g.rotate(ang);
  g.drawImage(pixCanvas(ws.p), -ws.ax, -ws.ay);
  g.restore();
}

function drawEffects(g: CanvasRenderingContext2D, s: GameState, L: Live, cx: number, cy: number, now: number): void {
  void now;
  for (const h of L.haz) {
    const hx = Math.round(h.x - cx), hy = Math.round(h.y - cy);
    const armed = h.warn <= 0;
    if (h.k === 'puddle') {
      if (!armed) {
        g.fillStyle = 'rgba(90,150,40,0.45)';
        for (let yy = -h.r; yy <= h.r; yy += 2) for (let xx = -h.r; xx <= h.r; xx += 2) if (xx * xx + yy * yy <= h.r * h.r && (xx + yy) % 4 === 0) g.fillRect(hx + xx, hy + yy, 2, 2);
      } else pxRing(g, hx, hy, h.r, h.col, 2, 0.8);
    } else if (h.k === 'lane' || h.k === 'dash') {
      const x2 = Math.round(h.x2 - cx), y2 = Math.round(h.y2 - cy);
      if (!armed) pxLine(g, hx, hy, x2, y2, h.col, 0.8 + Math.sin(L.t * 30) * 0.2);
      else {
        pxLine(g, hx, hy, x2, y2, '#ffffff', 0.9);
        pxLine(g, hx + 1, hy, x2 + 1, y2, h.col, 0.9);
        pxLine(g, hx, hy + 1, x2, y2 + 1, h.col, 0.9);
      }
    } else if (h.k === 'root') {
      if (!armed) pxRing(g, hx, hy, h.r, h.col, 2, 0.8);
      else for (let k = 0; k < 6; k++) pxLine(g, hx + Math.cos(k) * 8, hy + Math.sin(k) * 8, hx + Math.cos(k) * 12, hy - 14 + Math.sin(k * 2) * 3, h.col, 0.9);
    } else if (h.k === 'beam') {
      const ex = Math.round(h.x + Math.cos(h.ang) * h.r - cx), ey = Math.round(h.y + Math.sin(h.ang) * h.r - cy);
      pxLine(g, hx, hy, ex, ey, '#ffffff', 0.85);
      pxLine(g, hx, hy + 1, ex, ey + 1, h.col, 0.7);
    } else if (h.k === 'ring') {
      pxRing(g, hx, hy, Math.max(2, h.r), h.col, 2, 0.9);
      if (armed) pxRing(g, hx, hy, Math.max(2, h.r - 3), '#ffffff', 3, 0.6);
    }
  }
  for (const pr of L.proj) {
    const x = Math.round(pr.x - cx), y = Math.round(pr.y - cy);
    if (pr.kind === 'arrow') {
      const ang = Math.atan2(pr.vy, pr.vx);
      pxLine(g, x - Math.cos(ang) * 5, y - Math.sin(ang) * 5, x, y, pr.from === 'player' ? '#e6dcc4' : '#f2ead3', 1);
      g.fillStyle = '#9aa3ad';
      g.fillRect(x, y, 1, 1);
    } else {
      g.globalAlpha = 0.35;
      g.fillStyle = pr.col;
      g.fillRect(x - 2, y - 2, 4, 4);
      g.globalAlpha = 1;
      g.fillStyle = pr.col;
      g.fillRect(x - 1, y - 1, 2, 2);
      g.fillStyle = '#ffffff';
      g.fillRect(x, y, 1, 1);
    }
  }
  for (const f of L.fx) {
    const a = Math.max(0, f.life / f.max);
    const x = Math.round(f.x - cx), y = Math.round(f.y - cy);
    if (f.k === 'text') {
      pxText(g, f.txt, x - Math.floor(f.txt.length * 2), y, f.col, Math.min(1, a * 1.5));
    } else if (f.k === 'ring') {
      g.globalAlpha = a;
      g.fillStyle = f.col;
      g.fillRect(x, y, 1, 1);
      g.globalAlpha = 1;
    } else if (f.k === 'dust') {
      g.globalAlpha = a * 0.7;
      g.fillStyle = f.col;
      g.fillRect(x, y, f.s + 1, f.s + 1);
      g.globalAlpha = 1;
    } else if (f.k === 'pop') {
      g.globalAlpha = a;
      g.fillStyle = f.col;
      g.fillRect(x - 1, y - 1, 2, 2);
      g.globalAlpha = 1;
    } else {
      g.globalAlpha = Math.min(1, a * 1.4);
      g.fillStyle = f.col;
      g.fillRect(x, y, f.k === 'ember' ? 1 : 1, 1);
      g.globalAlpha = 1;
    }
  }
  void s;
}

function drawWeather(g: CanvasRenderingContext2D, s: GameState, now: number, cx: number, cy: number): void {
  const wx = s.world.wx;
  const north = s.actors.player.y < 26 * TILE;
  if (wx === 'rain' || wx === 'storm') {
    g.globalAlpha = wx === 'storm' ? 0.55 : 0.4;
    g.fillStyle = north ? '#ffffff' : '#9fc4e0';
    for (let i = 0; i < (wx === 'storm' ? 120 : 80); i++) {
      const x = (i * 37 + now * 0.35) % (VIEW_W + 40) - 20, y = (i * 53 + now * 0.9) % (VIEW_H + 20) - 10;
      g.fillRect(Math.round(x), Math.round(y), 1, 3);
    }
    g.globalAlpha = 1;
  } else if (wx === 'fog') {
    g.fillStyle = 'rgba(200,210,220,0.22)';
    for (let i = 0; i < 4; i++) g.fillRect(((i * 170 + now * 0.02) % (VIEW_W + 200)) - 100, 40 + i * 70, 220, 46);
  }
  if (north && (wx === 'rain' || wx === 'storm')) {
    g.fillStyle = '#ffffff';
    for (let i = 0; i < 60; i++) g.fillRect(Math.round((i * 61 + now * 0.05) % VIEW_W), Math.round((i * 29 + now * 0.08) % VIEW_H), 1, 1);
  }
  if (wx === 'storm' && Math.floor(now / 2600) % 3 === 0 && now % 2600 < 110) {
    g.fillStyle = 'rgba(230,240,255,0.35)';
    g.fillRect(0, 0, VIEW_W, VIEW_H);
  }
  void cx; void cy;
}

function drawLight(g: CanvasRenderingContext2D, s: GameState, L: Live | null, cx: number, cy: number, now: number): void {
  const light = daylight(s, now);
  const wx = s.world.wx;
  const storm = wx === 'storm' ? 0.12 : wx === 'rain' ? 0.06 : wx === 'cloudy' ? 0.05 : 0;
  const dark = clamp((1 - light) * 0.78 + storm, 0, 0.84);
  const ph = phaseInfo(s, now);
  if (ph.ragnarok) {
    g.fillStyle = `rgba(150,30,14,${0.14 + Math.sin(now / 1400) * 0.03})`;
    g.fillRect(0, 0, VIEW_W, VIEW_H);
    for (let i = 0; i < 26; i++) {
      const x = (i * 41 + now * 0.02) % VIEW_W, y = (i * 23 + now * 0.04) % VIEW_H;
      g.fillStyle = i % 3 ? '#4a4048' : '#ff8a3d';
      g.globalAlpha = 0.7;
      g.fillRect(Math.round(x), Math.round(y), 1, 1);
    }
    g.globalAlpha = 1;
  }
  if (dark < 0.03) return;
  const lc = lightCanvas();
  const lg = lc.getContext('2d')!;
  lg.globalCompositeOperation = 'source-over';
  lg.clearRect(0, 0, VIEW_W, VIEW_H);
  lg.fillStyle = `rgba(10,14,34,${dark})`;
  lg.fillRect(0, 0, VIEW_W, VIEW_H);
  lg.globalCompositeOperation = 'destination-out';
  const hole = (x: number, y: number, r: number, a: number) => {
    const grd = lg.createRadialGradient(x, y, 0, x, y, r);
    grd.addColorStop(0, `rgba(0,0,0,${a})`);
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    lg.fillStyle = grd;
    lg.fillRect(x - r, y - r, r * 2, r * 2);
  };
  if (L) hole(s.actors.player.x - cx, s.actors.player.y - cy - 6, 62, 1);
  for (const st of Object.values(s.entities.structures)) {
    if (st.kind === 'torch_post' || (st.kind === 'furnace' && (st.burn ?? 0) > 0)) {
      const x = st.tx * TILE + 8 - cx, y = st.ty * TILE + 4 - cy;
      if (x < -60 || y < -60 || x > VIEW_W + 60 || y > VIEW_H + 60) continue;
      hole(x, y, 46 + Math.sin(now / 90 + st.tx) * 3, 0.9);
    }
  }
  if (s.custody.equip.weapon?.item === 'lantern' || s.custody.inv.some((x) => x && x.item === 'lantern' && (ph.light < 0.5))) hole(s.actors.player.x - cx, s.actors.player.y - cy, 52, 0.9);
  lg.globalCompositeOperation = 'source-over';
  g.drawImage(lc, 0, 0);
  for (const st of Object.values(s.entities.structures)) {
    if (st.kind !== 'torch_post' && !(st.kind === 'furnace' && (st.burn ?? 0) > 0)) continue;
    const x = st.tx * TILE + 8 - cx, y = st.ty * TILE + 4 - cy;
    const grd = g.createRadialGradient(x, y, 0, x, y, 30);
    grd.addColorStop(0, 'rgba(255,170,80,0.32)');
    grd.addColorStop(1, 'rgba(255,170,80,0)');
    g.fillStyle = grd;
    g.fillRect(x - 30, y - 30, 60, 60);
  }
}

let lightCv: HTMLCanvasElement | null = null;
function lightCanvas(): HTMLCanvasElement {
  if (!lightCv) {
    lightCv = document.createElement('canvas');
    lightCv.width = VIEW_W;
    lightCv.height = VIEW_H;
  }
  return lightCv;
}

function drawHud(g: CanvasRenderingContext2D, ui: DrawUi, now: number, cx: number, cy: number, s: GameState | null): void {
  void now; void s;
  if (ui.buildKind && ui.buildTile) {
    const def = STRUCTS[ui.buildKind];
    const x = ui.buildTile.tx * TILE - cx, y = ui.buildTile.ty * TILE - cy;
    g.globalAlpha = 0.55;
    g.fillStyle = ui.buildValid ? '#7fe07a' : '#e8483a';
    g.fillRect(x, y, TILE, TILE);
    g.globalAlpha = 0.85;
    if (def) {
      const sp = structPix(ui.buildKind);
      g.drawImage(pixCanvas(sp.p), x + 8 - sp.ax, y + 16 - sp.ay);
    }
    g.globalAlpha = 1;
  }
  if (ui.hold && ui.hold > 0 && s) {
    const x = s.actors.player.x - cx - 20, y = s.actors.player.y - cy - 24;
    g.fillStyle = '#0a0812';
    g.fillRect(x, y, 40, 4);
    g.fillStyle = '#7fe07a';
    g.fillRect(x, y, 40 * clamp(ui.hold, 0, 1), 4);
  }
  if (ui.prompt && ui.promptX !== undefined && ui.promptY !== undefined) {
    g.font = "8px 'Press Start 2P', monospace";
    const tw = Math.ceil(g.measureText(ui.prompt).width) + 10;
    const x = Math.round(ui.promptX - cx - tw / 2), y = Math.round(ui.promptY - cy - 26);
    g.fillStyle = 'rgba(14,10,26,0.9)';
    g.fillRect(x, y, tw, 13);
    g.fillStyle = '#e0b35a';
    g.fillRect(x, y, tw, 1);
    g.fillRect(x, y + 12, tw, 1);
    g.fillStyle = '#fff1d6';
    g.fillText(ui.prompt, x + 5, y + 9);
  }
  if (ui.banner && ui.bannerA && ui.bannerA > 0) {
    g.globalAlpha = Math.min(1, ui.bannerA);
    g.fillStyle = 'rgba(14,10,26,0.8)';
    g.fillRect(VIEW_W / 2 - 110, 28, 220, 16);
    g.fillStyle = '#ffd27a';
    g.font = "8px 'Press Start 2P', monospace";
    const tw = g.measureText(ui.banner).width;
    g.fillText(ui.banner, VIEW_W / 2 - tw / 2, 39);
    g.globalAlpha = 1;
  }
  // Danger vignette: always a soft darkening, redder when hurt.
  const gr = g.createRadialGradient(VIEW_W / 2, VIEW_H / 2, 140, VIEW_W / 2, VIEW_H / 2, 360);
  gr.addColorStop(0, 'rgba(0,0,0,0)');
  gr.addColorStop(1, `rgba(20,4,8,${s && s.actors.player.hp < 30 ? 0.55 + Math.sin(now / 200) * 0.1 : 0.28})`);
  g.fillStyle = gr;
  g.fillRect(0, 0, VIEW_W, VIEW_H);
}

/** Title backdrop: a slow pan over the island with no state dependencies. */
export function drawBackdrop(g: CanvasRenderingContext2D, w: World, t: number): void {
  const x = 96 * TILE + Math.sin(t / 9000) * 260 - VIEW_W / 2;
  const y = 92 * TILE + Math.cos(t / 12000) * 80 - VIEW_H / 2;
  const cxA = clamp(Math.round(x), 0, MAP_W * TILE - VIEW_W), cyA = clamp(Math.round(y), 0, MAP_H * TILE - VIEW_H);
  g.fillStyle = '#0b1a2a';
  g.fillRect(0, 0, VIEW_W, VIEW_H);
  groundPass(g, w, cxA, cyA, t, null);
  for (let ty = Math.floor(cyA / TILE); ty <= Math.floor((cyA + VIEW_H) / TILE) + 1 && ty < MAP_H; ty++) for (let tx = Math.floor(cxA / TILE); tx <= Math.floor((cxA + VIEW_W) / TILE) + 1 && tx < MAP_W; tx++) {
    const k = ty * MAP_W + tx;
    const o = w.obj[k];
    const sp = o ? objPix(o, w.variant[k]) : null;
    if (sp) drawSprite(g, sp, tx * TILE + sp.fw * 8, ty * TILE + sp.fh * 16, cxA, cyA);
  }
  g.fillStyle = 'rgba(12,8,30,0.42)';
  g.fillRect(0, 0, VIEW_W, VIEW_H);
  void hero;
}
const hero = 0;
export { regionAt, BAL };
