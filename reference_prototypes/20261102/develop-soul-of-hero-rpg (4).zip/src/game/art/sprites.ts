// Original pixel art, generated at native resolution. Every sprite is built from masks + edge-aware shading,
// so outlines, rim light and shadows stay consistent across the whole game.
import { Pix, Mask, C, mixC, paintMask, fillMask, shadow, dottedRing, Pal } from './pix';
import { hash2 } from '../core/rng';
import { T, O } from '../world/world';
import { ITEMS } from '../data/catalog';

export interface Sprite {
  p: Pix;
  /** Anchor point inside the sprite that is placed at the world anchor (feet, footprint bottom-centre, …). */
  ax: number;
  ay: number;
  /** Footprint in tiles, used for objects. */
  fw: number;
  fh: number;
  c?: HTMLCanvasElement;
}

const memo = new Map<string, Sprite>();
function memoSprite(key: string, make: () => Sprite): Sprite {
  let s = memo.get(key);
  if (!s) {
    s = make();
    memo.set(key, s);
  }
  return s;
}
const S = (p: Pix, ax: number, ay: number, fw = 1, fh = 1): Sprite => ({ p, ax, ay, fw, fh });

// ---------------------------------------------------------------- ground
export function groupOf(t: number): number {
  switch (t) {
    case T.DEEP: case T.SHALLOW: case T.RIVER: return 1;
    case T.SAND: return 2;
    case T.MARSH: return 6;
    case T.GRASS: case T.FOREST: case T.HILL: return 3;
    case T.TUNDRA: case T.SNOW: return 5;
    case T.DESERT: case T.SCORCH: case T.SLAG: return 7;
    default: return 4;
  }
}
const prioOf = (g: number): number => [0, 3, 1, 2, 2, 2, 2, 2][g] ?? 0;
const HARD = new Set<number>([T.MOUNTAIN, T.CLIFF, T.BRIDGE, T.PIER, T.COBBLE, T.FLOOR, T.CAVE, T.ROAD]);
const GROUP_COL: Record<number, number> = {
  1: C('#2e6f98'), 2: C('#e0c27a'), 3: C('#4f8a3a'), 4: C('#8e7a64'), 5: C('#dfeaf2'), 6: C('#4f5a3a'), 7: C('#d2904c')
};

/** For each side (N,E,S,W) returns the neighbouring group that should bleed into this tile, or 0. */
export function edgeSides(t: number, nbr: [number, number, number, number]): [number, number, number, number] {
  const g = groupOf(t);
  const out: [number, number, number, number] = [0, 0, 0, 0];
  for (let s = 0; s < 4; s++) {
    const gn = groupOf(nbr[s]);
    if (g === 1) {
      if (gn !== 1) out[s] = gn === 2 ? 2 : 9; // 9 = foam only
    } else if (!HARD.has(t) && gn !== g && prioOf(gn) > prioOf(g)) {
      out[s] = gn;
    }
  }
  return out;
}

export function groundKey(t: number, v: number, frame: number, sides: number[]): number {
  let k = t;
  k = k * 4 + v;
  k = k * 4 + (groupOf(t) === 1 ? frame : 0);
  for (const s of sides) k = k * 16 + s;
  return k;
}

function paintWater(p: Pix, t: number, v: number, frame: number): void {
  const deep = t === T.DEEP, river = t === T.RIVER;
  const base = deep ? C('#1f4f78') : river ? C('#2b6f98') : C('#3e8fb0');
  const hi = deep ? C('#4f92b8') : C('#8fd6e0');
  const lo = deep ? C('#17405f') : C('#2f7ea0');
  p.rect(0, 0, 15, 15, base);
  for (const y of [1, 4, 7, 10, 13]) {
    const shift = (frame * 3 + y * 2 + v * 5) % 8;
    for (let x = 0; x < 16; x++) {
      const k = (x + shift + (y >> 1)) % 8;
      if (k < 3) p.set(x, y, hi);
    }
  }
  for (const y of [3, 6, 9, 12, 15]) {
    for (let x = 0; x < 16; x++) if ((x * 5 + y + frame * 2 + v) % 11 === 0) p.set(x, y, lo);
  }
  if (river) for (let y = 0; y < 16; y += 3) for (let x = 0; x < 16; x++) if (((x + frame * 4) & 7) === 0 && hash2(x, y, 11) > 0.4) p.set(x, y, hi);
}

function paintGround(p: Pix, t: number, v: number): void {
  const h = (x: number, y: number, k = 0) => hash2(x, y, t * 131 + v * 17 + k);
  switch (t) {
    case T.SAND: {
      p.rect(0, 0, 15, 15, C('#e0c27a'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        if (((y * 3 + v) % 5 === 0) && h(x, y) > 0.35 && x < 13) { p.set(x, y, C('#efd896')); p.set(x + 1, y, C('#efd896')); }
        if (h(x, y, 2) > 0.93) p.set(x, y, C('#c9a862'));
      }
      if (h(3, 3, 9) > 0.5) p.set(4, 3, C('#b89a66'));
      break;
    }
    case T.GRASS: case T.FOREST: case T.HILL: {
      const forest = t === T.FOREST;
      const base = forest ? C('#3c6d31') : t === T.HILL ? C('#6f7d56') : C('#5d9b3e');
      p.rect(0, 0, 15, 15, base);
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const r = h(x, y);
        if (r < 0.1) p.set(x, y, forest ? C('#2f5a26') : C('#4d8634'));
        else if (r > 0.9) p.set(x, y, forest ? C('#4f8a3e') : C('#79b34d'));
      }
      for (let k = 0; k < 3; k++) {
        const tx = 1 + Math.floor(h(k, 1) * 13), ty = 2 + Math.floor(h(k, 2) * 12);
        p.set(tx - 1, ty, C('#3c6e2a')); p.set(tx, ty - 1, C('#8fcc5c')); p.set(tx + 1, ty, C('#3c6e2a'));
      }
      if (forest) {
        for (let k = 0; k < 6; k++) p.set(Math.floor(h(k, 5) * 16), Math.floor(h(k, 6) * 16), h(k, 7) > 0.5 ? C('#8a5e2e') : C('#b8772e'));
        for (let k = 0; k < 2; k++) { const bx = Math.floor(h(k, 8) * 13), by = Math.floor(h(k, 9) * 13); p.rect(bx, by, bx + 2, by + 1, C('#2a4d22')); }
      } else if (t === T.HILL) {
        for (let k = 0; k < 6; k++) { const bx = Math.floor(h(k, 4) * 15), by = Math.floor(h(k, 6) * 15); p.set(bx, by, C('#9aa0a4')); p.set(bx + 1, by, C('#6b7074')); }
      } else if (h(2, 2, 3) > 0.7) {
        const fx = Math.floor(h(5, 5) * 14) + 1, fy = Math.floor(h(6, 6) * 14) + 1;
        p.set(fx, fy, h(1, 1) > 0.5 ? C('#fff3c4') : C('#ffffff')); p.set(fx, fy + 1, C('#3c6e2a'));
      }
      break;
    }
    case T.TUNDRA: {
      p.rect(0, 0, 15, 15, C('#7f9c88'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const r = h(x, y);
        if (r < 0.12) p.set(x, y, C('#6c8a78'));
        else if (r > 0.93) p.set(x, y, C('#c4dcdc'));
        else if (r > 0.88) p.set(x, y, C('#a3b08a'));
      }
      break;
    }
    case T.SNOW: {
      p.rect(0, 0, 15, 15, C('#e9f2f8'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const r = h(x, y);
        if (r < 0.1) p.set(x, y, C('#c3d5e3'));
        else if (r > 0.97) p.set(x, y, C('#ffffff'));
      }
      break;
    }
    case T.MARSH: {
      p.rect(0, 0, 15, 15, C('#4f5b3a'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if (h(x, y) < 0.08) p.set(x, y, C('#3a4429'));
      for (let k = 0; k < 2; k++) {
        const px = Math.floor(h(k, 3) * 12), py = Math.floor(h(k, 4) * 12);
        p.rect(px, py, px + 2, py + 1, C('#2f5a5b')); p.set(px, py, C('#5f8f8a'));
      }
      p.set(Math.floor(h(9, 9) * 14), Math.floor(h(8, 8) * 14), C('#6f8f3a'));
      break;
    }
    case T.DESERT: {
      p.rect(0, 0, 15, 15, C('#dc9a55'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        if (((y + (x >> 3)) % 6 === 0) && h(x, y) > 0.3) p.set(x, y, C('#ecb97a'));
        else if (h(x, y, 1) > 0.94) p.set(x, y, C('#b97a3e'));
      }
      if (h(4, 4, 5) > 0.4) p.set(9, 9, C('#c08040')), p.set(10, 9, C('#c08040'));
      break;
    }
    case T.SCORCH: {
      p.rect(0, 0, 15, 15, C('#3f3129'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const r = h(x, y);
        if (r < 0.1) p.set(x, y, C('#5a4a3e'));
        else if (r > 0.985) p.set(x, y, C('#c4602a'));
      }
      break;
    }
    case T.SLAG: {
      p.rect(0, 0, 15, 15, C('#3b3536'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if (h(x, y) < 0.1) p.set(x, y, C('#2c2729'));
      for (let k = 0; k < 4; k++) {
        const sx = Math.floor(h(k, 12) * 12), sy = Math.floor(h(k, 13) * 14);
        p.line(sx, sy, sx + 3, sy + 1, C('#e8632a'));
      }
      p.rect(3, 9, 4, 10, C('#7fd13a')); p.set(4, 9, C('#c4f29a'));
      break;
    }
    case T.ROAD: {
      p.rect(0, 0, 15, 15, C('#a4774a'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const r = h(x, y);
        if (r < 0.08) p.set(x, y, C('#7a5232'));
        else if (r > 0.92) p.set(x, y, C('#c49766'));
      }
      for (let y = 0; y < 16; y += 2) { p.set(4, y, C('#8f6640')); p.set(11, y + 1, C('#8f6640')); }
      break;
    }
    case T.COBBLE: {
      p.rect(0, 0, 15, 15, C('#6f6b68'));
      for (let by = 0; by < 4; by++) for (let bx = 0; bx < 4; bx++) {
        const off = by % 2 ? 2 : 0;
        const x0 = ((bx * 4 + off) % 16), y0 = by * 4;
        const shade = [C('#8e8a86'), C('#9b968f'), C('#848080')][Math.floor(h(bx, by) * 3)];
        p.rect(x0, y0, Math.min(15, x0 + 2), Math.min(15, y0 + 2), shade);
        p.rect(Math.min(15, x0 + 3), y0, Math.min(15, x0 + 3), Math.min(15, y0 + 2), shade);
      }
      break;
    }
    case T.FLOOR: {
      p.rect(0, 0, 15, 15, C('#4a4256'));
      for (let y = 0; y < 16; y += 4) p.line(0, y, 15, y, C('#3d3649'));
      p.line(7, 0, 7, 15, C('#5b5270'));
      p.set(7, 7, C('#7b6fb5')); p.set(8, 8, C('#7b6fb5'));
      break;
    }
    case T.BRIDGE: case T.PIER: {
      const base = t === T.PIER ? C('#a07444') : C('#8b5a2b');
      const seam = t === T.PIER ? C('#7e5530') : C('#6e4420');
      p.rect(0, 0, 15, 15, base);
      for (let x = 0; x < 16; x += 4) p.rect(x, 0, x, 15, seam);
      p.set(1, 3, C('#c9a06a')); p.set(9, 11, C('#c9a06a'));
      break;
    }
    case T.CAVE: {
      p.rect(0, 0, 15, 15, C('#2e2a36'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const r = h(x, y); if (r < 0.12) p.set(x, y, C('#3d3847')); else if (r > 0.94) p.set(x, y, C('#221e2a')); }
      break;
    }
    case T.MOUNTAIN: case T.CLIFF: {
      const cliff = t === T.CLIFF;
      p.rect(0, 0, 15, 15, cliff ? C('#5b5652') : C('#6e6a72'));
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
        const r = h(x, y);
        if (r < 0.07) p.set(x, y, cliff ? C('#4a4541') : C('#4d4a52'));
        else if (r > 0.93) p.set(x, y, cliff ? C('#7a736d') : C('#8c8891'));
      }
      if (cliff) {
        for (let y = 3; y < 16; y += 4) p.line(0, y, 15, y, C('#4a4541'));
        p.rect(0, 0, 15, 0, C('#7a736d'));
        p.rect(0, 15, 15, 15, C('#3a3634'));
      } else {
        for (let k = 0; k < 3; k++) { const sx = Math.floor(h(k, 14) * 12), sy = Math.floor(h(k, 15) * 12); p.line(sx, sy, sx + 2, sy + 3, C('#4d4a52')); }
      }
      break;
    }
    default:
      p.rect(0, 0, 15, 15, C('#5d9b3e'));
  }
}

/** Ground tile at native 16×16. `sides` describes bleeding neighbours (see edgeSides). */
export function groundPix(t: number, v: number, frame: number, sides: number[]): Pix {
  const p = new Pix(16, 16);
  paintGround(p, t, v);
  if (groupOf(t) === 1) paintWater(p, t, v, frame);
  const band = (s: number, col: number, dith: boolean) => {
    for (let k = 0; k < 2; k++) {
      for (let i = 0; i < 16; i++) {
        let x = 0, y = 0;
        if (s === 0) { x = i; y = k; }
        else if (s === 1) { x = 15 - k; y = i; }
        else if (s === 2) { x = i; y = 15 - k; }
        else { x = k; y = i; }
        const r = hash2(x, y, 41 + s);
        if (k === 0 ? (dith ? (x + y) % 2 === 0 : true) : r > 0.45) p.set(x, y, col);
      }
    }
  };
  for (let s = 0; s < 4; s++) {
    const g = sides[s];
    if (!g) continue;
    if (groupOf(t) === 1) {
      if (g === 9) {
        // Foam: animated crests along the shoreline.
        for (let i = 0; i < 16; i++) {
          const f = (i + frame * 3) % 5;
          const x = s === 1 ? 14 : s === 3 ? 1 : i, y = s === 0 ? 1 : s === 2 ? 14 : i;
          if (s === 1 || s === 3) { if (f < 2) p.set(x, i, C('#e4f8fb')); }
          else if (f < 3) p.set(x, y, C('#e4f8fb'));
          if (f === 0) p.set(s === 1 ? 13 : s === 3 ? 2 : i, s === 0 ? 2 : s === 2 ? 13 : i, C('#bfe9f0'));
        }
        continue;
      }
      if (g === 2) band(s, GROUP_COL[2], true);
      for (let i = 0; i < 16; i++) {
        const f = (i + frame * 3) % 5;
        if (f < 2) {
          if (s === 0) p.set(i, 1, C('#e4f8fb')); else if (s === 2) p.set(i, 14, C('#e4f8fb'));
          else if (s === 1) p.set(14, i, C('#e4f8fb')); else p.set(1, i, C('#e4f8fb'));
        }
      }
      continue;
    }
    band(s, GROUP_COL[g] ?? C('#777777'), true);
  }
  return p;
}

// ---------------------------------------------------------------- objects
const PAL_BARK = { base: C('#6b4a2b'), hi: C('#8a6238'), lo: C('#3f2a18'), ol: C('#1e140c') };
const PAL_LEAF = { base: C('#3f7a33'), hi: C('#78b85a'), lo: C('#1f4a22'), ol: C('#14301a'), mid: C('#5a9a45') };
const PAL_PINE = { base: C('#2e5f47'), hi: C('#4f8a68'), lo: C('#183a2c'), ol: C('#0f2620'), mid: C('#3c7457') };
const PAL_ROCK = { base: C('#7b7f86'), hi: C('#a9aeb5'), lo: C('#4a4e56'), ol: C('#23262c'), mid: C('#6a6e75') };
const PAL_BUSH = { base: C('#3f7a33'), hi: C('#6aa84e'), lo: C('#1f4a22'), ol: C('#14301a') };
const PAL_WOOD = { base: C('#9b6b3a'), hi: C('#c08a52'), lo: C('#5e3d20'), ol: C('#2a1a0e') };
const PAL_STONE = { base: C('#9a9ea3'), hi: C('#c8ccd2'), lo: C('#5a5f66'), ol: C('#2b2e33') };
const PAL_HOUSE = { base: C('#d9b98f'), hi: C('#efd4ac'), lo: C('#b58b63'), ol: C('#4a3020') };
const PAL_ROOF = { base: C('#9b3e33'), hi: C('#c4564a'), lo: C('#6a2620'), ol: C('#2e1410') };
const PAL_IRON = { base: C('#4a4f57'), hi: C('#6d737c'), lo: C('#2b2f35'), ol: C('#14161a') };

function oakPix(variant: number): Sprite {
  return memoSprite(`oak${variant}`, () => {
    const p = new Pix(32, 40);
    shadow(p, 16, 37, 12, 3, 0.36);
    const trunk = new Mask(32, 40).rect(14, 22, 17, 38).rect(12, 34, 19, 38);
    paintMask(p, trunk, PAL_BARK, { speck: 0.2, seed: variant, outline: false });
    const cm = new Mask(32, 40).ell(16, 13, 13, 10.5).ell(8.5, 12, 7.5, 7).ell(23.5, 12, 7.5, 7).ell(16, 6.5, 8, 6);
    if (variant % 2) cm.ell(12, 22, 6, 4).ell(21, 22, 5.5, 3.5); else cm.ell(10, 21, 6.5, 4.5).ell(22, 21, 6, 4);
    paintMask(p, cm, PAL_LEAF, { speck: 0.3, seed: 7 + variant });
    for (let y = 2; y < 26; y++) for (let x = 2; x < 30; x++) {
      if (!cm.get(x, y)) continue;
      const r = hash2(x, y, 99 + variant);
      if (r > 0.93) p.set(x, y, C('#9ad870'));
      else if (r < 0.05) p.set(x, y, C('#1d4220'));
    }
    fillMask(p, new Mask(32, 40), 0, 0);
    return S(p, 16, 38);
  });
}

function pinePix(variant: number): Sprite {
  return memoSprite(`pine${variant}`, () => {
    const p = new Pix(24, 40);
    shadow(p, 12, 37, 9, 2.5, 0.36);
    p.rect(11, 30, 12, 38, PAL_BARK.base);
    const m = new Mask(24, 40);
    m.poly([[12, 1], [4, 14], [20, 14]]);
    m.or(new Mask(24, 40).poly([[12, 7], [3, 23], [21, 23]]));
    m.or(new Mask(24, 40).poly([[12, 15], [1, 31], [23, 31]]));
    paintMask(p, m, PAL_PINE, { speck: 0.25, seed: variant });
    for (let y = 2; y < 30; y++) for (let x = 3; x < 21; x++) if (m.get(x, y) && hash2(x, y, 4 + variant) > 0.92) p.set(x, y, C('#6aa67f'));
    return S(p, 12, 37);
  });
}

function deadPix(variant: number): Sprite {
  return memoSprite(`dead${variant}`, () => {
    const p = new Pix(20, 28);
    shadow(p, 10, 26, 5, 1.6, 0.3);
    const m = new Mask(20, 28).seg(10, 26, 10, 8, 1.7).seg(10, 15, 4, 9, 1).seg(10, 19, 15, 13, 1).seg(10, 10, 14, 3, 0.9);
    if (variant % 2) m.seg(10, 12, 5, 4, 0.8);
    paintMask(p, m, { base: C('#7a6a58'), hi: C('#9a8a74'), lo: C('#4f4436'), ol: C('#2a2219') }, { speck: 0.2, seed: variant });
    return S(p, 10, 26);
  });
}

function rockPix(iron: boolean, variant: number): Sprite {
  return memoSprite(`rock${iron ? 'i' : 'r'}${variant}`, () => {
    const p = new Pix(20, 16);
    shadow(p, 10, 14, 8.5, 2, 0.34);
    const m = new Mask(20, 16).ell(10, 9, 8.2, 6.2).ell(5.5, 10.5, 4, 4).ell(15, 11, 3.6, 3.8);
    if (variant % 2) m.sub(new Mask(20, 16).rect(14, 2, 19, 6));
    paintMask(p, m, iron ? { base: C('#6e6660'), hi: C('#918880'), lo: C('#3f3a36'), ol: C('#1d1a18') } : PAL_ROCK, { speck: 0.18, seed: 3 + variant });
    p.line(7, 8, 9, 11, PAL_ROCK.lo);
    p.line(12, 6, 13, 8, PAL_ROCK.lo);
    if (iron) {
      for (let y = 3; y < 14; y++) for (let x = 3; x < 17; x++) {
        if (!m.get(x, y)) continue;
        const r = hash2(x, y, 20 + variant);
        if (r > 0.82) p.set(x, y, C('#a9562c'));
        else if (r < 0.04) p.set(x, y, C('#e7b08a'));
      }
    } else {
      p.set(4, 6, C('#4f7a3a')); p.set(5, 5, C('#4f7a3a')); p.set(6, 5, C('#5f8a4a'));
    }
    return S(p, 10, 15);
  });
}

function bushPix(variant: number): Sprite {
  return memoSprite(`bush${variant}`, () => {
    const p = new Pix(20, 16);
    shadow(p, 10, 14, 7, 1.8, 0.3);
    const m = new Mask(20, 16).ell(5, 9, 4.5, 4).ell(10, 7, 5, 5).ell(15, 9, 4.5, 4).ell(10, 11, 6, 4);
    paintMask(p, m, PAL_BUSH, { speck: 0.2, seed: 40 + variant });
    if (variant % 2 === 0) {
      for (const [bx, by] of [[6, 8], [11, 6], [14, 10], [9, 11], [4, 11]]) {
        p.set(bx, by, C('#d33d4a')); p.set(bx + 1, by, C('#d33d4a')); p.set(bx, by - 1, C('#ffb3b8'));
      }
    }
    return S(p, 10, 15);
  });
}

function reedPix(variant: number): Sprite {
  return memoSprite(`reed${variant}`, () => {
    const p = new Pix(12, 20);
    for (let k = 0; k < 4; k++) {
      const x = 1 + k * 3 + (variant % 2), top = 2 + Math.floor(hash2(k, variant, 5) * 7);
      p.line(x, 19, x + (k % 2 ? 1 : -1), top, C('#7ea25a'));
      p.line(x + 1, 19, x + 1 + (k % 2 ? 1 : -1), top + 2, C('#5f8a3e'));
      p.set(x + (k % 2 ? 1 : -1), top - 1, C('#7b5a2e'));
      p.set(x + (k % 2 ? 1 : -1), top, C('#7b5a2e'));
    }
    return S(p, 6, 19);
  });
}

function mushPix(variant: number): Sprite {
  return memoSprite(`mush${variant}`, () => {
    const p = new Pix(12, 8);
    p.rect(5, 4, 6, 7, C('#efe2c6'));
    p.set(5, 7, C('#c8b894'));
    const cap = new Mask(12, 8).ell(6, 3.5, 5, 3.2);
    paintMask(p, cap, { base: C('#c8443d'), hi: C('#e8685e'), lo: C('#7a2420'), ol: C('#3a1210') }, { speck: 0.05 });
    p.set(4, 2, C('#fff4e8')); p.set(8, 3, C('#fff4e8'));
    if (variant % 2) p.set(7, 1, C('#fff4e8'));
    return S(p, 6, 7);
  });
}

function cactusPix(variant: number): Sprite {
  return memoSprite(`cactus${variant}`, () => {
    const p = new Pix(12, 24);
    shadow(p, 6, 22, 4, 1.4, 0.3);
    const m = new Mask(12, 24).ell(6, 12, 3.4, 10).rect(2, 9, 4, 13).rect(8, 11, 10, 15).ell(3, 9, 1.4, 1.4).ell(9, 7, 1.4, 1.4);
    paintMask(p, m, { base: C('#5f9a4a'), hi: C('#8fc46e'), lo: C('#3b6a2e'), ol: C('#1f3a18') }, { speck: 0.2, seed: variant });
    p.set(6, 2, C('#e6568c')); p.set(5, 3, C('#e6568c'));
    return S(p, 6, 22);
  });
}

function crateSprite(): Sprite {
  return memoSprite('crate', () => {
    const p = new Pix(16, 16);
    shadow(p, 8, 14, 6, 1.6, 0.3);
    const m = new Mask(16, 16).rect(2, 4, 13, 14);
    paintMask(p, m, PAL_WOOD, { speck: 0.12, seed: 9 });
    for (let x = 3; x <= 12; x++) { p.set(x, 8, PAL_WOOD.lo); p.set(x, 11, PAL_WOOD.lo); }
    p.rect(2, 6, 13, 6, C('#3c3f44')); p.rect(2, 12, 13, 12, C('#3c3f44'));
    p.set(7, 9, C('#c9b37a')); p.set(9, 9, C('#c9b37a'));
    return S(p, 8, 14);
  });
}

function wreckSprite(): Sprite {
  return memoSprite('wreck', () => {
    const p = new Pix(36, 26);
    shadow(p, 18, 23, 15, 2.2, 0.32);
    const hull = new Mask(36, 26).poly([[2, 12], [9, 23], [27, 23], [34, 11], [29, 9], [6, 9]]);
    paintMask(p, hull, { base: C('#6b4a2b'), hi: C('#8a6238'), lo: C('#3f2a18'), ol: C('#1e140c') }, { speck: 0.15, seed: 2 });
    for (let x = 6; x < 30; x += 4) p.line(x, 10, x - 2, 21, C('#3f2a18'));
    p.line(18, 9, 16, 1, C('#7a5a34')); p.line(16, 1, 22, 0, C('#7a5a34'));
    for (const [rx, ry] of [[10, 14], [23, 17], [27, 12]]) { p.set(rx, ry, C('#8c4a2a')); p.set(rx + 1, ry, C('#8c4a2a')); }
    return S(p, 18, 24, 2, 2);
  });
}

function pillarSprite(variant: number): Sprite {
  return memoSprite(`pillar${variant}`, () => {
    const p = new Pix(12, 28);
    shadow(p, 6, 26, 6, 1.6, 0.3);
    const m = new Mask(12, 28).rect(3, 5, 8, 25).rect(1, 24, 10, 27);
    for (let x = 3; x <= 8; x += 2) m.m[5 * 12 + x] = 0;
    m.m[4 * 12 + 4] = 0;
    paintMask(p, m, PAL_STONE, { speck: 0.14, seed: 30 + variant });
    p.line(5, 10, 6, 18, PAL_STONE.lo); p.line(7, 20, 6, 24, PAL_STONE.lo);
    p.rect(2, 6, 3, 6, C('#4f7a3a'));
    return S(p, 6, 27);
  });
}

function houseSprite(): Sprite {
  return memoSprite('house', () => {
    const p = new Pix(36, 40);
    shadow(p, 18, 35, 16, 2.4, 0.3);
    const walls = new Mask(36, 40).rect(3, 20, 32, 33);
    paintMask(p, walls, PAL_HOUSE, { speck: 0.06, seed: 6 });
    for (let y = 22; y <= 33; y += 3) for (let x = 4; x <= 31; x++) if (walls.get(x, y)) p.set(x, y, PAL_HOUSE.lo);
    const roof = new Mask(36, 40).poly([[0, 22], [18, 4], [35, 22], [35, 25], [0, 25]]);
    paintMask(p, roof, PAL_ROOF, { speck: 0.02, seed: 8 });
    for (let y = 8; y < 24; y += 3) for (let x = 2; x < 34; x++) if (roof.get(x, y) && ((x + (y >> 2)) % 4 === 0)) p.set(x, y, PAL_ROOF.lo);
    p.rect(24, 6, 28, 14, C('#8a8a88'));
    p.rect(24, 6, 28, 6, C('#5e5e5c'));
    p.rect(15, 26, 20, 33, C('#4e2f1a'));
    p.set(19, 30, C('#e0b35a'));
    p.rect(6, 23, 10, 27, C('#9fd6e6')); p.rect(25, 23, 29, 27, C('#9fd6e6'));
    p.rect(8, 23, 8, 27, C('#5b3a22')); p.rect(27, 23, 27, 27, C('#5b3a22'));
    return S(p, 18, 34, 2, 2);
  });
}

function tradePostSprite(): Sprite {
  return memoSprite('trade', () => {
    const p = new Pix(52, 40);
    shadow(p, 26, 35, 24, 2.6, 0.3);
    const body = new Mask(52, 40).rect(4, 18, 47, 33);
    paintMask(p, body, PAL_HOUSE, { speck: 0.05, seed: 12 });
    p.rect(2, 13, 49, 17, C('#5e3d20')); p.rect(2, 13, 49, 13, C('#7a5230'));
    for (let x = 4; x < 48; x += 4) p.rect(x, 20, x + 1, 25, (x / 4) % 2 ? C('#b5483a') : C('#f1e6c8'));
    p.rect(3, 26, 48, 26, C('#6b4a2b'));
    p.rect(15, 11, 36, 18, C('#d9a441')); p.rect(15, 11, 36, 11, C('#f0c96a'));
    p.rect(20, 14, 31, 15, C('#7a5230'));
    p.rect(10, 28, 41, 33, C('#7a5230')); p.rect(10, 28, 41, 28, C('#9b6b3a'));
    p.rect(12, 30, 16, 33, C('#e0b35a')); p.rect(36, 30, 40, 33, C('#e0b35a'));
    return S(p, 26, 34, 3, 2);
  });
}

function vaultSprite(): Sprite {
  return memoSprite('vault', () => {
    const p = new Pix(52, 40);
    shadow(p, 26, 35, 24, 2.6, 0.3);
    const body = new Mask(52, 40).rect(3, 9, 48, 33);
    paintMask(p, body, { base: C('#5a6068'), hi: C('#7d858f'), lo: C('#353a40'), ol: C('#1a1d21') }, { speck: 0.08, seed: 13 });
    const door = new Mask(52, 40).ell(26, 22, 10, 10);
    paintMask(p, door, { base: C('#3a4048'), hi: C('#56606b'), lo: C('#20242a'), ol: C('#0f1114') }, { speck: 0.05, seed: 14 });
    dottedRing(p, 26, 22, 6, C('#ff8a3d'), 2);
    p.set(26, 22, C('#ffd27a'));
    for (let x = 3; x <= 48; x += 6) for (let y = 30; y <= 33; y++) p.set(x + (y % 2), y, (x / 6) % 2 ? C('#e0b35a') : C('#2a2a2a'));
    for (const [rx, ry] of [[6, 12], [45, 12], [6, 30], [45, 30]]) p.set(rx, ry, C('#c9ccd2'));
    return S(p, 26, 34, 3, 2);
  });
}

function wellSprite(): Sprite {
  return memoSprite('well', () => {
    const p = new Pix(16, 16);
    shadow(p, 8, 14, 7, 1.8, 0.3);
    const ring = new Mask(16, 16).ell(8, 9, 7, 5).sub(new Mask(16, 16).ell(8, 9, 4.5, 2.8));
    paintMask(p, ring, PAL_STONE, { speck: 0.2, seed: 15 });
    const water = new Mask(16, 16).ell(8, 9, 4.5, 2.8);
    paintMask(p, water, { base: C('#2a6a96'), hi: C('#4f92b8'), lo: C('#1d4c6e'), ol: C('#14324a') }, { speck: 0.1, seed: 16, outline: false });
    p.set(6, 8, C('#bfe9f0'));
    return S(p, 8, 14);
  });
}

function mineSprite(): Sprite {
  return memoSprite('mine', () => {
    const p = new Pix(36, 28);
    shadow(p, 18, 26, 15, 2, 0.3);
    const mouth = new Mask(36, 28).ell(18, 18, 13, 9);
    paintMask(p, mouth, { base: C('#1b1620'), hi: C('#2d2634'), lo: C('#0e0b12'), ol: C('#5a4a3a') }, { speck: 0.05, seed: 17 });
    const posts = new Mask(36, 28).rect(6, 10, 8, 26).rect(28, 10, 30, 26).rect(6, 8, 30, 10);
    paintMask(p, posts, PAL_WOOD, { speck: 0.1, seed: 18 });
    for (const [rx, ry] of [[3, 24], [33, 22], [4, 14], [31, 15]]) { p.set(rx, ry, PAL_ROCK.hi); p.set(rx + 1, ry, PAL_ROCK.base); }
    return S(p, 18, 27, 2, 2);
  });
}

function shrineSprite(elder: string, pal: [string, string, string]): Sprite {
  return memoSprite(`shrine${elder}`, () => {
    const p = new Pix(32, 40);
    shadow(p, 16, 37, 12, 2.4, 0.34);
    const base = new Mask(32, 40).rect(8, 27, 23, 36);
    paintMask(p, base, PAL_STONE, { speck: 0.14, seed: 19 });
    p.rect(6, 24, 25, 27, C('#8b8793'));
    const crystal = new Mask(32, 40).poly([[16, 4], [22, 17], [16, 30], [10, 17]]);
    paintMask(p, crystal, { base: C(pal[1]), hi: C(pal[0]), lo: C(pal[2]), ol: C('#101018'), mid: C(pal[0]) }, { speck: 0.15, seed: 21 });
    p.set(16, 10, C('#ffffff')); p.set(15, 12, C('#ffffff'));
    for (const [rx, ry] of [[10, 30], [21, 30], [14, 33], [19, 33]]) p.set(rx, ry, C(pal[0]));
    return S(p, 16, 36, 2, 2);
  });
}

function runeSprite(): Sprite {
  return memoSprite('rune', () => {
    const p = new Pix(8, 8);
    p.line(2, 1, 2, 6, C('#9fe9ff')); p.line(2, 3, 5, 3, C('#9fe9ff')); p.set(5, 2, C('#9fe9ff')); p.set(5, 6, C('#9fe9ff'));
    p.set(4, 5, C('#4fb8d0'));
    return S(p, 4, 7);
  });
}

function doorGallerySprite(): Sprite {
  return memoSprite('gallerydoor', () => {
    const p = new Pix(16, 24);
    shadow(p, 8, 22, 6, 1.6, 0.3);
    const m = new Mask(16, 24).rect(2, 4, 13, 23);
    paintMask(p, m, PAL_IRON, { speck: 0.08, seed: 22 });
    p.rect(2, 9, 13, 10, PAL_IRON.lo); p.rect(2, 17, 13, 18, PAL_IRON.lo);
    p.rect(7, 12, 8, 15, C('#0b0b10')); p.set(7, 11, C('#e0b35a')); p.set(8, 11, C('#e0b35a'));
    return S(p, 8, 23);
  });
}

function dockPostSprite(): Sprite {
  return memoSprite('dockpost', () => {
    const p = new Pix(8, 16);
    p.rect(2, 2, 5, 15, C('#7a5230')); p.rect(2, 2, 2, 15, C('#9b6b3a'));
    dottedRing(p, 4, 4, 2, C('#c8a06a'), 1);
    return S(p, 4, 15);
  });
}

function skiffSprite(): Sprite {
  return memoSprite('skiff', () => {
    const p = new Pix(40, 24);
    shadow(p, 20, 22, 17, 2, 0.3);
    const hull = new Mask(40, 24).poly([[2, 10], [9, 21], [31, 21], [38, 10]]);
    paintMask(p, hull, PAL_WOOD, { speck: 0.1, seed: 23 });
    p.line(20, 10, 20, 0, C('#7a5230'));
    p.line(20, 1, 30, 9, C('#e6dcc4')); p.line(20, 1, 12, 9, C('#e6dcc4'));
    p.rect(8, 13, 32, 13, C('#5e3d20'));
    return S(p, 20, 22, 2, 2);
  });
}

function flowerSprite(variant: number): Sprite {
  return memoSprite(`flower${variant}`, () => {
    const p = new Pix(8, 8);
    const pet = [C('#ffe36e'), C('#ff9bd2'), C('#f7f0ff')][variant % 3];
    p.line(4, 7, 4, 4, C('#3f7a33'));
    p.set(3, 3, pet); p.set(5, 3, pet); p.set(4, 2, pet); p.set(4, 4, C('#e0b35a'));
    p.set(3, 6, C('#3f7a33'));
    return S(p, 4, 7);
  });
}

function vendorIcon(): Sprite {
  return heroSprite({ gender: 'vendor', facing: 'down', frame: 0, moving: false });
}

/** Object sprites keyed by base-layer object kind (see O in world.ts). */
export function objPix(o: number, variant: number, elder?: string): Sprite | null {
  switch (o) {
    case O.OAK: return oakPix(variant);
    case O.PINE: return pinePix(variant);
    case O.DEAD: return deadPix(variant);
    case O.ROCK: return rockPix(false, variant);
    case O.IRON: return rockPix(true, variant);
    case O.BUSH: return bushPix(variant);
    case O.REED: return reedPix(variant);
    case O.MUSH: return mushPix(variant);
    case O.CACTUS: return cactusPix(variant);
    case O.CRATE: return crateSprite();
    case O.WRECK: return wreckSprite();
    case O.PILLAR: return pillarSprite(variant);
    case O.HOUSE: return houseSprite();
    case O.WELL: return wellSprite();
    case O.TRADE: return tradePostSprite();
    case O.VAULT: return vaultSprite();
    case O.CHEST: return structPix('chest');
    case O.MINE: return mineSprite();
    case O.SHRINE: {
      const pal = ELDER_PAL[elder ?? 'frost'] ?? ELDER_PAL.frost;
      return shrineSprite(elder ?? 'frost', pal);
    }
    case O.DOOR: return doorGallerySprite();
    case O.RUNE: return runeSprite();
    case O.DOCKPOST: return dockPostSprite();
    case O.SKIFF: return skiffSprite();
    case O.FLOWER: return flowerSprite(variant);
    case O.VENDOR: return vendorIcon();
    default: return null;
  }
}

// ---------------------------------------------------------------- player-built structures
export function structPix(kind: string, opt: { open?: boolean; frame?: number; growth?: number; lit?: boolean } = {}): Sprite {
  const key = `st:${kind}:${opt.open ? 1 : 0}:${opt.frame ?? 0}:${opt.growth ?? 0}:${opt.lit ? 1 : 0}`;
  return memoSprite(key, () => {
    const p = new Pix(16, 16);
    switch (kind) {
      case 'floor': {
        p.rect(0, 0, 15, 15, C('#a77a4c'));
        for (let y = 0; y < 16; y += 4) { p.line(0, y, 15, y, C('#7d5632')); p.line(0, y + 1, 15, y + 1, C('#b98c5e')); }
        p.set(3, 2, C('#5e3d20')); p.set(12, 9, C('#5e3d20'));
        return S(p, 8, 16);
      }
      case 'wall_wood': {
        const m = new Mask(16, 16).rect(0, 0, 15, 15);
        paintMask(p, m, PAL_WOOD, { speck: 0.05, seed: 24, outline: true });
        for (let x = 3; x < 16; x += 4) p.line(x, 1, x, 14, PAL_WOOD.lo);
        p.rect(1, 3, 1, 3, C('#3c3f44')); p.rect(14, 3, 14, 3, C('#3c3f44')); p.rect(1, 12, 1, 12, C('#3c3f44')); p.rect(14, 12, 14, 12, C('#3c3f44'));
        return S(p, 8, 16);
      }
      case 'wall_stone': {
        const m = new Mask(16, 16).rect(0, 0, 15, 15);
        paintMask(p, m, PAL_STONE, { speck: 0.1, seed: 25 });
        for (const y of [4, 9, 14]) p.line(0, y, 15, y, PAL_STONE.lo);
        for (const [x, y0] of [[5, 0], [11, 0], [3, 5], [9, 5], [13, 5], [5, 10], [11, 10]]) p.line(x, y0, x, y0 + 3, PAL_STONE.lo);
        return S(p, 8, 16);
      }
      case 'door': {
        const frame = new Mask(16, 16).rect(0, 0, 15, 15);
        paintMask(p, frame, PAL_STONE, { speck: 0.05, seed: 26 });
        if (opt.open) {
          p.rect(1, 1, 5, 14, C('#3a2615'));
          p.rect(6, 1, 14, 14, C('#0c0a0a'));
          return S(p, 8, 16);
        }
        p.rect(2, 1, 13, 14, C('#8a5a2e'));
        for (let x = 3; x < 13; x += 3) p.line(x, 1, x, 14, C('#6a4220'));
        p.rect(2, 1, 13, 1, C('#b07a44'));
        p.rect(11, 7, 12, 9, C('#e0b35a'));
        return S(p, 8, 16);
      }
      case 'roof': {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
          const row = Math.floor(y / 4), off = row % 2 ? 4 : 0;
          const inRow = (y % 4) === 3;
          const c = inRow ? C('#6a2620') : (((x + off) % 8) < 1 ? C('#6a2620') : hash2(x, y, 28) > 0.5 ? C('#c4564a') : C('#9b3e33'));
          p.set(x, y, c);
        }
        p.line(0, 0, 15, 0, C('#d77a6a'));
        return S(p, 8, 16);
      }
      case 'bed': {
        p.rect(1, 2, 14, 5, C('#7a5230'));
        p.rect(0, 4, 15, 15, C('#7a5230'));
        p.rect(2, 6, 13, 14, C('#c43d3d'));
        p.rect(2, 6, 13, 6, C('#e05a5a'));
        p.rect(3, 4, 12, 6, C('#f4eee0'));
        p.rect(2, 13, 13, 14, C('#8f2d2d'));
        return S(p, 8, 16);
      }
      case 'chest': case 'chest_poi': {
        const m = new Mask(16, 16).rect(1, 4, 14, 14);
        paintMask(p, m, PAL_WOOD, { speck: 0.08, seed: 27 });
        p.rect(1, 8, 14, 8, C('#3c3f44'));
        p.rect(1, 4, 14, 5, C('#b07a44'));
        p.rect(7, 7, 8, 9, C('#c9b37a'));
        return S(p, 8, 16);
      }
      case 'workbench': {
        p.rect(1, 7, 14, 9, C('#a77a4c')); p.rect(1, 7, 14, 7, C('#c99a66'));
        p.rect(2, 10, 3, 15, C('#6b4a2b')); p.rect(12, 10, 13, 15, C('#6b4a2b'));
        p.rect(4, 4, 6, 5, C('#9aa0a6')); p.rect(9, 3, 10, 6, C('#8a5a2e'));
        p.line(4, 6, 6, 4, C('#e0e4ea'));
        return S(p, 8, 16);
      }
      case 'furnace': {
        const m = new Mask(16, 24).rect(1, 4, 14, 23);
        paintMask(p, m, PAL_STONE, { speck: 0.14, seed: 29 });
        p.rect(4, 13, 11, 19, C('#2a1a12'));
        const f = opt.frame ?? 0;
        const fire = [C('#ff8a3d'), C('#ffb347'), C('#ffd27a')];
        for (let k = 0; k < 4; k++) p.set(5 + k * 2, 18 - ((f + k) % 3), fire[(f + k) % 3]);
        p.set(7, 17, C('#fff1a6')); p.set(8, 16, C('#fff1a6'));
        p.rect(1, 4, 14, 5, C('#9aa0a6')); p.rect(6, 8, 9, 10, C('#4a4f57'));
        return S(p, 8, 23);
      }
      case 'research_desk': {
        p.rect(1, 8, 14, 10, C('#7a5230')); p.rect(1, 8, 14, 8, C('#9b6b3a'));
        p.rect(2, 11, 3, 15, C('#4a3018')); p.rect(12, 11, 13, 15, C('#4a3018'));
        p.rect(5, 6, 8, 7, C('#2c5fa0')); p.rect(5, 6, 8, 6, C('#5a8ed0'));
        p.set(11, 5, C('#fff1a6')); p.set(11, 4, C('#ffb347'));
        return S(p, 8, 16);
      }
      case 'garden': {
        p.rect(0, 0, 15, 15, C('#4a2f1c'));
        for (let y = 0; y < 16; y += 3) p.line(0, y, 15, y, C('#3a2314'));
        const g = opt.growth ?? 0;
        if (g > 0) for (let k = 0; k < 4; k++) {
          const x = 2 + k * 3, h2 = 2 + Math.min(g, 3) * 2;
          p.line(x, 14, x, 14 - h2, C('#5fae4a'));
          if (g >= 3) p.set(x, 13 - h2, C('#ffd27a'));
        }
        return S(p, 8, 16);
      }
      case 'torch_post': {
        p.rect(7, 8, 8, 23, C('#7a5230')); p.rect(5, 22, 10, 23, C('#5a3a20'));
        p.rect(4, 6, 11, 8, C('#3c3f44'));
        const f = opt.frame ?? 0;
        p.set(7, 5 - (f % 2), C('#ffb347')); p.set(8, 4 - ((f + 1) % 2), C('#ffd27a')); p.set(8, 5, C('#fff1a6'));
        return S(p, 8, 23);
      }
      case 'escrow_chest': {
        const m = new Mask(16, 16).rect(1, 4, 14, 14);
        paintMask(p, m, { base: C('#5b3a8c'), hi: C('#7b5ab0'), lo: C('#3a2366'), ol: C('#1a0f30') }, { speck: 0.06, seed: 31 });
        p.rect(1, 8, 14, 8, C('#d9b35a'));
        p.rect(1, 4, 14, 4, C('#7b5ab0'));
        p.rect(7, 7, 8, 9, C(opt.lit ? '#ffd27a' : '#c9a03a'));
        p.set(7, 8, C('#fff1a6'));
        return S(p, 8, 16);
      }
      case 'cart': {
        const w = new Mask(20, 16).rect(2, 5, 17, 11);
        const pp = new Pix(20, 16);
        paintMask(pp, w, PAL_WOOD, { speck: 0.1, seed: 33 });
        for (const [x, y] of [[4, 11], [14, 11]]) { dottedRing(pp, x, y, 3, C('#3c2a1a'), 1); pp.set(x, y, C('#3c2a1a')); pp.set(x - 1, y, C('#2a1a0e')); }
        pp.rect(4, 2, 7, 4, C('#c9a06a')); pp.rect(10, 1, 13, 4, C('#b5894f'));
        return S(pp, 10, 15, 1, 1);
      }
      case 'claim_marker': {
        p.rect(7, 2, 8, 15, C('#7a5230'));
        for (let y = 3; y <= 7; y++) for (let x = 9; x <= 14; x++) if (x - 9 <= (7 - y) * 2 + 1) p.set(x, y, C('#c83a3a'));
        p.set(10, 4, C('#d9a441'));
        return S(p, 8, 16);
      }
      default:
        p.rect(1, 1, 14, 14, C('#777777'));
        return S(p, 8, 16);
    }
  });
}

// ---------------------------------------------------------------- hero
export interface HeroOpts {
  gender: 'male' | 'female' | 'vendor';
  facing: 'down' | 'up' | 'left' | 'right';
  frame: number;
  moving: boolean;
  armor?: 'none' | 'hide' | 'iron';
  pack?: boolean;
  flash?: boolean;
  lean?: number;
}

const HERO_PAL = {
  male: { skin: { base: C('#f1c196'), hi: C('#ffe2c4'), lo: C('#d4976c'), ol: C('#2a1a12') }, hair: { base: C('#4a2f1f'), hi: C('#7a5434'), lo: C('#2e1c12'), ol: C('#1a100a') }, tunic: { base: C('#2f7f7a'), hi: C('#4fb0a6'), lo: C('#1d5350'), ol: C('#0f2b29') } },
  female: { skin: { base: C('#f1c196'), hi: C('#ffe2c4'), lo: C('#d4976c'), ol: C('#2a1a12') }, hair: { base: C('#b5542c'), hi: C('#e07a44'), lo: C('#7a3218'), ol: C('#3a1608') }, tunic: { base: C('#a23c5a'), hi: C('#d26a86'), lo: C('#6a2440'), ol: C('#2f0f1c') } },
  vendor: { skin: { base: C('#e9b48a'), hi: C('#ffd9b5'), lo: C('#c8875e'), ol: C('#2a1a12') }, hair: { base: C('#8a8a8a'), hi: C('#b4b4b4'), lo: C('#555555'), ol: C('#222222') }, tunic: { base: C('#7a5a34'), hi: C('#9a7448'), lo: C('#4a3420'), ol: C('#21160c') } }
};
const PANTS = { base: C('#3d3b6b'), hi: C('#5a589a'), lo: C('#262449'), ol: C('#14132a') };
const BOOT = { base: C('#3a2a20'), hi: C('#5a4030'), lo: C('#241810'), ol: C('#0e0805') };
const BELT = { base: C('#6b4a2b'), hi: C('#8a6238'), lo: C('#3f2a18'), ol: C('#1e140c') };
const HIDE = { base: C('#8a5a3c'), hi: C('#b07a52'), lo: C('#5a3824'), ol: C('#22150c') };
const IRONA = { base: C('#8c949e'), hi: C('#d3dae2'), lo: C('#5c6470'), ol: C('#1c2026') };

export function heroPix(o: HeroOpts): Pix {
  const p = new Pix(16, 24);
  const side = o.facing === 'left' || o.facing === 'right';
  const back = o.facing === 'up';
  const pal = HERO_PAL[o.gender];
  const bob = o.moving && o.frame % 2 ? -1 : 0;
  const lean = o.lean ?? 0;
  const dx = lean, dy = bob;
  const legA = o.moving ? o.frame % 2 === 0 : true;
  shadow(p, 8, 22.5, 5, 1.5, 0.38);
  const parts: [Mask, Pal][] = [];
  const legs = new Mask(16, 24);
  if (side) {
    const lx = o.facing === 'right' ? -1 : 1;
    legs.rect(6 + lx, 18, 7 + lx, legA ? 21 : 22).rect(8 - lx, 18, 9 - lx, legA ? 22 : 21);
  } else {
    legs.rect(5, 18, 7, legA ? 21 : 22).rect(8, 18, 10, legA ? 22 : 21);
  }
  parts.push([legs, PANTS]);
  const boots = new Mask(16, 24);
  if (side) {
    const lx = o.facing === 'right' ? -1 : 1;
    boots.rect(6 + lx, legA ? 22 : 23, 7 + lx, legA ? 22 : 23).rect(8 - lx, legA ? 23 : 22, 9 - lx, legA ? 23 : 22);
  } else boots.rect(5, legA ? 22 : 23, 7, legA ? 22 : 23).rect(8, legA ? 23 : 22, 10, legA ? 23 : 22);
  if (o.gender === 'female') {
    const skirt = new Mask(16, 24).poly([[4, 16 + dy], [11, 16 + dy], [13, 20], [2, 20]]);
    parts.push([skirt, pal.tunic]);
  }
  parts.push([boots, BOOT]);
  // torso
  const torso = new Mask(16, 24);
  if (side) torso.ell(8 + dx, 15 + dy, 3.6, 3.7).rect(5 + dx, 13 + dy, 10 + dx, 18 + dy);
  else torso.ell(8 + dx, 15 + dy, 4.6, 3.6).rect(4 + dx, 13 + dy, 11 + dx, 18 + dy);
  const tunic = o.armor === 'iron' ? IRONA : o.armor === 'hide' ? HIDE : pal.tunic;
  if (o.pack) {
    const packM = back ? new Mask(16, 24).rect(4, 12 + dy, 11, 18 + dy) : new Mask(16, 24).rect(2, 12 + dy, 3, 17 + dy).rect(12, 12 + dy, 13, 17 + dy);
    parts.push([packM, BELT]);
  }
  parts.push([torso, tunic]);
  // arms
  const arms = new Mask(16, 24);
  if (side) arms.rect(9 + dx, 13 + dy, 10 + dx, 18 + dy);
  else arms.rect(2 + dx, 13 + dy, 3 + dx, 18 + dy).rect(12 + dx, 13 + dy, 13 + dx, 18 + dy);
  parts.push([arms, tunic]);
  const hands = new Mask(16, 24);
  if (side) hands.rect(9 + dx, 19 + dy, 10 + dx, 20 + dy);
  else hands.rect(2 + dx, 19 + dy, 3 + dx, 20 + dy).rect(12 + dx, 19 + dy, 13 + dx, 20 + dy);
  parts.push([hands, pal.skin]);
  // head
  const head = new Mask(16, 24).ell(8 + dx, 6.5 + dy, 4.2, 4.6);
  const hair = new Mask(16, 24);
  if (o.gender === 'female') {
    hair.or(head.clone().and(new Mask(16, 24).rect(0, 0, 15, 5)));
    hair.or(new Mask(16, 24).rect(2 + dx, 5 + dy, 4 + dx, 11 + dy)).or(new Mask(16, 24).rect(11 + dx, 5 + dy, 13 + dx, 11 + dy));
    if (back) hair.or(new Mask(16, 24).rect(4 + dx, 5 + dy, 11 + dx, 12 + dy));
  } else if (o.gender === 'vendor') {
    hair.or(head.clone().and(new Mask(16, 24).rect(0, 0, 15, 4)));
  } else {
    hair.or(head.clone().and(new Mask(16, 24).rect(0, 0, 15, 4)));
    hair.or(new Mask(16, 24).rect(3 + dx, 5 + dy, 4 + dx, 7 + dy)).or(new Mask(16, 24).rect(11 + dx, 5 + dy, 12 + dx, 7 + dy));
  }
  if (side) hair.and(new Mask(16, 24).rect(0, 0, o.facing === 'right' ? 9 : 15, 23).or(new Mask(16, 24)));
  if (back && o.gender !== 'female') { hair.or(head.clone()); }
  const face = head.clone();
  face.sub(hair);
  if (o.gender === 'vendor') face.sub(new Mask(16, 24).rect(0, 0, 15, 2));
  parts.push([face, pal.skin]);
  parts.push([hair, pal.hair]);
  if (o.gender === 'female' && !back) parts.push([new Mask(16, 24).rect(11 + dx, 4 + dy, 12 + dx, 4 + dy), { base: C('#e0b35a'), hi: C('#fff1a6'), lo: C('#a0762a'), ol: C('#3a2a10') }]);
  if (o.gender === 'vendor' && !back) parts.push([new Mask(16, 24).rect(1 + dx, 2 + dy, 14 + dx, 3 + dy), { base: C('#5a4a34'), hi: C('#7a6a4a'), lo: C('#3a2e20'), ol: C('#1a140c') }]);
  // scarf (gold) and belt
  if (!back) parts.push([new Mask(16, 24).rect(6 + dx, 11 + dy, 9 + dx, 12 + dy), { base: C('#d9a441'), hi: C('#f0c96a'), lo: C('#a0762a'), ol: C('#4a3010') }]);
  parts.push([new Mask(16, 24).rect(4 + dx, 17 + dy, 11 + dx, 17 + dy), BELT]);
  // paint each part (fill only), then one unified outline
  const union = new Mask(16, 24);
  for (const [m, pl] of parts) {
    paintMask(p, m, pl, { speck: 0.06, seed: 77, outline: false, ox: 0, oy: 0 });
    union.or(m);
  }
  // face features
  if (!back && !o.flash) {
    if (side) {
      const ex = o.facing === 'right' ? 9 + dx : 6 + dx;
      p.set(ex, 6 + dy, C('#ffffff')); p.set(ex, 7 + dy, C('#23161c')); p.set(ex, 8 + dy, C('#23161c'));
      p.set(ex + (o.facing === 'right' ? 1 : -1), 9 + dy, pal.skin.lo);
    } else {
      p.set(6 + dx, 6 + dy, C('#ffffff')); p.set(6 + dx, 7 + dy, C('#23161c'));
      p.set(9 + dx, 6 + dy, C('#ffffff')); p.set(9 + dx, 7 + dy, C('#23161c'));
      p.set(7 + dx, 10 + dy, C('#b86a4e')); p.set(8 + dx, 10 + dy, C('#b86a4e'));
    }
  }
  // unified outline on the silhouette
  for (let y = 0; y < 24; y++) for (let x = 0; x < 16; x++) {
    if (union.get(x, y)) continue;
    if (union.get(x - 1, y) || union.get(x + 1, y) || union.get(x, y - 1) || union.get(x, y + 1)) p.set(x, y, C('#24140e'));
  }
  if (o.flash) {
    for (let i = 0; i < p.d.length; i++) {
      const c = p.d[i];
      if (c >>> 24) p.d[i] = mixC(c, C('#ffffff', c >>> 24), 0.75);
    }
  }
  return p;
}

export function heroSprite(o: HeroOpts): Sprite {
  const key = `hero:${o.gender}:${o.facing}:${o.frame}:${o.moving ? 1 : 0}:${o.armor ?? 'none'}:${o.pack ? 1 : 0}:${o.flash ? 1 : 0}:${o.lean ?? 0}`;
  return memoSprite(key, () => S(heroPix(o), 8, 23));
}

// ---------------------------------------------------------------- creatures
export interface CreatureOpts { kind: string; frame: number; pose: 'idle' | 'squash' | 'stretch' | 'crouch' | 'snort' | 'raise' | 'draw' | 'flap' | 'glow' }

export function creatureSprite(o: CreatureOpts): Sprite {
  const key = `cr:${o.kind}:${o.frame}:${o.pose}`;
  return memoSprite(key, () => {
    switch (o.kind) {
      case 'slime': {
        const p = new Pix(18, 14);
        const sq = o.pose === 'squash' ? 1 : o.pose === 'stretch' ? -1 : 0;
        const rx = 6.4 + sq * 0.9, ry = 4.8 - sq * 1.2 + (o.frame % 2 ? 0.3 : 0);
        shadow(p, 9, 13, rx * 0.9, 1.3, 0.34);
        const m = new Mask(18, 14).ell(9, 9.2, rx, ry);
        paintMask(p, m, { base: C('#6ccf5a'), hi: C('#b2f29a'), lo: C('#2f8a3a'), ol: C('#173f1c'), mid: C('#8fe27a') }, { speck: 0.14, seed: 3 });
        const cx = 9 + (o.frame % 2 ? 0 : 0);
        p.rect(cx - 3, 7, cx - 2, 8, C('#ffffff')); p.rect(cx + 1, 7, cx + 2, 8, C('#ffffff'));
        p.set(cx - 2, 8, C('#1b1b1b')); p.set(cx + 2, 8, C('#1b1b1b'));
        p.set(cx - 4, 5, C('#ffffff')); p.set(cx - 3, 4, C('#ffffff'));
        return S(p, 9, 13);
      }
      case 'wolf': {
        const p = new Pix(26, 18);
        const dy = o.pose === 'crouch' ? 2 : 0;
        shadow(p, 12, 16, 9, 1.6, 0.34);
        const bodyM = new Mask(26, 18).ell(11, 10 + dy, 8, 4.4).ell(20, 7 + dy, 3.8, 3.5).ell(23.5, 8.5 + dy, 2.6, 1.7);
        bodyM.poly([[18, 4 + dy], [19, 0 + dy], [21, 4 + dy]]);
        bodyM.seg(3, 8 + dy, 0, 3 + dy, 1.2).seg(0, 3 + dy, -1, 1 + dy, 0.5);
        const legsM = new Mask(26, 18);
        const a = o.frame % 2;
        legsM.rect(7, 13 + dy, 8, a ? 16 : 15).rect(10, 13 + dy, 11, a ? 15 : 16).rect(15, 13 + dy, 16, a ? 15 : 16).rect(18, 13 + dy, 19, a ? 16 : 15);
        paintMask(p, legsM, { base: C('#5a5048'), hi: C('#7a6e62'), lo: C('#342e28'), ol: C('#1a1613') }, { speck: 0.05, seed: 2, outline: false });
        paintMask(p, bodyM, { base: C('#8a8076'), hi: C('#b0a698'), lo: C('#4a4238'), ol: C('#241f1a'), mid: C('#9c9284') }, { speck: 0.2, seed: 4 });
        p.set(19, 6 + dy, C('#ffd34d')); p.set(24, 8 + dy, C('#14110f'));
        p.set(12, 9 + dy, C('#5a5048')); p.set(14, 8 + dy, C('#5a5048'));
        return S(p, 13, 16);
      }
      case 'boar': {
        const p = new Pix(28, 18);
        const dy = o.pose === 'snort' ? 1 : 0;
        shadow(p, 13, 16, 10, 1.6, 0.34);
        const m = new Mask(28, 18).ell(12, 9 + dy, 9, 5.4).ell(22, 11 + dy, 4.6, 4).ell(26, 12 + dy, 2, 2);
        for (let k = 0; k < 6; k++) m.rect(6 + k * 2, 3 + dy, 6 + k * 2, 4 + dy, 1);
        const legs = new Mask(28, 18).rect(6, 13, 7, 16).rect(10, 13, 11, 16).rect(16, 13, 17, 16).rect(20, 13, 21, 16);
        paintMask(p, legs, { base: C('#5a3824'), hi: C('#7a5030'), lo: C('#3a2214'), ol: C('#1a0e08') }, { speck: 0.05, seed: 5, outline: false });
        paintMask(p, m, { base: C('#8a5a3c'), hi: C('#b07a52'), lo: C('#5a3824'), ol: C('#22150c'), mid: C('#9a6a48') }, { speck: 0.22, seed: 6 });
        p.set(22, 8 + dy, C('#14110f')); p.set(23, 7 + dy, C('#ffffff'));
        p.line(24, 13 + dy, 27, 11 + dy, C('#f2ead3')); p.set(24, 12 + dy, C('#f2ead3'));
        p.set(25, 14 + dy, C('#2a1a12')); p.set(26, 13 + dy, C('#2a1a12'));
        return S(p, 14, 16);
      }
      case 'bat': {
        const p = new Pix(18, 12);
        const up = o.frame % 2 === 0;
        const wings = new Mask(18, 12);
        if (up) wings.poly([[9, 5], [1, 1], [3, 7], [6, 6], [9, 8]]).poly([[9, 5], [17, 1], [15, 7], [12, 6], [9, 8]]);
        else wings.poly([[9, 6], [1, 8], [3, 11], [6, 9], [9, 9]]).poly([[9, 6], [17, 8], [15, 11], [12, 9], [9, 9]]);
        paintMask(p, wings, { base: C('#5f4b78'), hi: C('#7f6a98'), lo: C('#3a2e4a'), ol: C('#1d1526') }, { speck: 0.1, seed: 8 });
        const body = new Mask(18, 12).ell(9, 6, 2.6, 2.8);
        paintMask(p, body, { base: C('#3a2e4a'), hi: C('#5f4b78'), lo: C('#241a30'), ol: C('#110b18') }, { speck: 0.05, seed: 9 });
        p.set(8, 5, C('#ff5a5a')); p.set(10, 5, C('#ff5a5a'));
        return S(p, 9, 9);
      }
      case 'archer': {
        const p = new Pix(16, 24);
        shadow(p, 8, 22, 4, 1.3, 0.3);
        const bone = { base: C('#d9d0b4'), hi: C('#f6f0de'), lo: C('#9d937a'), ol: C('#3a332a') };
        const skull = new Mask(16, 24).ell(7, 5, 3.4, 3.6).rect(5, 8, 9, 9);
        paintMask(p, skull, bone, { speck: 0.05, seed: 10 });
        p.rect(5, 5, 6, 6, C('#1a1612')); p.rect(8, 5, 9, 6, C('#1a1612'));
        p.line(7, 8, 7, 14, bone.lo); for (let y = 10; y <= 13; y += 2) p.line(4, y, 10, y, bone.lo);
        p.line(7, 14, 5, 22, bone.base); p.line(7, 14, 9, 22, bone.base);
        p.line(7, 10, 2, 16, bone.base); p.line(7, 10, 11, 14 + (o.pose === 'draw' ? -2 : 0), bone.base);
        const bowX = 14;
        p.line(bowX, 4, bowX + 1, 12, C('#7a5230')); p.line(bowX + 1, 12, bowX, 20, C('#7a5230'));
        p.line(bowX, 4, bowX, 20, C('#e6e0d0'));
        if (o.pose === 'draw') p.line(bowX, 12, 10, 12, C('#c6b08a'));
        return S(p, 8, 23);
      }
      case 'crab': {
        const p = new Pix(22, 14);
        const up = o.pose === 'raise' ? -2 : 0;
        shadow(p, 11, 13, 7, 1.2, 0.3);
        const body = new Mask(22, 14).ell(11, 8, 6, 3.4);
        const claws = new Mask(22, 14).ell(4, 5 + up, 2.6, 2.4).ell(18, 5 + up, 2.6, 2.4);
        paintMask(p, claws, { base: C('#d6543c'), hi: C('#f08a66'), lo: C('#8f2f22'), ol: C('#3a120c') }, { speck: 0.05, seed: 11 });
        paintMask(p, body, { base: C('#d6543c'), hi: C('#f08a66'), lo: C('#8f2f22'), ol: C('#3a120c'), mid: C('#e0664a') }, { speck: 0.14, seed: 12 });
        p.line(9, 6, 9, 3, C('#c2452f')); p.set(9, 2, C('#ffffff')); p.set(13, 2, C('#ffffff')); p.line(13, 6, 13, 3, C('#c2452f'));
        p.set(9, 2, C('#ffffff')); p.set(13, 2, C('#ffffff'));
        for (let k = 0; k < 3; k++) { p.line(6 + k, 10, 4 - k, 13, C('#5a1c14')); p.line(15 - k, 10, 17 + k, 13, C('#5a1c14')); }
        return S(p, 11, 13);
      }
      case 'wisp': {
        const p = new Pix(14, 14);
        const r = 6.5 + (o.frame % 2 ? 0.6 : 0);
        for (let y = 0; y < 14; y++) for (let x = 0; x < 14; x++) {
          const d = Math.hypot(x + 0.5 - 7, y + 0.5 - 7) / r;
          if (d > 1) continue;
          const a = Math.pow(1 - d, 1.4) * 0.95;
          if (a > 0.08) p.blend(x, y, C('#7ff6e0'), a);
        }
        const core = new Mask(14, 14).ell(7, 7, 2.5, 2.5);
        paintMask(p, core, { base: C('#e9fff9'), hi: C('#ffffff'), lo: C('#a0fff0'), ol: C('#2aa89a') }, { speck: 0, seed: 1 });
        return S(p, 7, 7);
      }
      default:
        return S(new Pix(8, 8), 4, 4);
    }
  });
}

// ---------------------------------------------------------------- elders
export const ELDER_PAL: Record<string, [string, string, string]> = {
  frost: ['#bfeaff', '#5aa7d6', '#24476a'],
  ember: ['#ffd27a', '#ff6a2c', '#5a1d12'],
  mire: ['#c8ff7a', '#4f8f3a', '#1e3a22'],
  stone: ['#e8dcc2', '#8f8578', '#3b3430'],
  tide: ['#c9fbff', '#2ca9c0', '#103c4a'],
  grove: ['#f0d6ff', '#8c59b8', '#2d1a40'],
  shrine_glow: ['#ffffff', '#ffffff', '#ffffff']
};

export function elderSprite(id: string, awakened: boolean, frame: number): Sprite {
  const key = `elder:${id}:${awakened ? 1 : 0}:${frame % 2}`;
  return memoSprite(key, () => {
    const pal = ELDER_PAL[id] ?? ELDER_PAL.frost;
    const p = new Pix(48, 52);
    const bob = frame % 2 ? -1 : 0;
    shadow(p, 24, 50, 15, 3, 0.4);
    const hi = C(pal[0]), mid = C(pal[1]), lo = C(pal[2]);
    const bright = awakened ? 1 : 0;
    switch (id) {
      case 'frost': {
        const robe = new Mask(48, 52).poly([[12, 50], [16, 24 + bob], [32, 24 + bob], [36, 50]]).ell(24, 24 + bob, 9, 4);
        paintMask(p, robe, { base: C('#24476a'), hi: C('#3d6e96'), lo: C('#15283e'), ol: C('#0a1420') }, { speck: 0.1, seed: 2 });
        const head = new Mask(48, 52).ell(24, 16 + bob, 5, 5.2);
        paintMask(p, head, { base: C('#dff4ff'), hi: C('#ffffff'), lo: C('#8fc4e0'), ol: C('#1c3450') }, { speck: 0.05, seed: 3 });
        for (const s of [-1, 1]) {
          p.line(24 + s * 3, 12 + bob, 24 + s * 10, 3 + bob, hi); p.line(24 + s * 10, 3 + bob, 24 + s * 14, 0 + bob, hi);
          p.line(24 + s * 7, 7 + bob, 24 + s * 13, 6 + bob, mid); p.line(24 + s * 6, 9 + bob, 24 + s * 9, 13 + bob, mid);
        }
        for (let k = 0; k < 8; k++) { const x = 13 + k * 3, y = 32 + ((k * 7) % 12); p.set(x, y, hi); }
        p.set(21, 15 + bob, lo); p.set(27, 15 + bob, lo); p.set(22, 15 + bob, hi); p.set(26, 15 + bob, hi);
        if (bright) for (let k = 0; k < 6; k++) p.set(12 + k * 4, 46 - (k % 3) * 3, hi);
        break;
      }
      case 'ember': {
        const cloak = new Mask(48, 52).ell(24, 34 + bob, 11, 15);
        paintMask(p, cloak, { base: C('#3e2016'), hi: C('#5a2e20'), lo: C('#24110b'), ol: C('#0b0604') }, { speck: 0.12, seed: 5 });
        const head = new Mask(48, 52).ell(24, 18 + bob, 5, 5.4);
        paintMask(p, head, { base: C('#f2c58a'), hi: C('#ffe4bc'), lo: C('#b47a46'), ol: C('#2a130a') }, { speck: 0.04, seed: 6 });
        const crown = new Mask(48, 52).poly([[16, 14 + bob], [18, 4 + bob], [22, 11 + bob], [24, 0 + bob], [27, 11 + bob], [30, 4 + bob], [32, 14 + bob]]);
        paintMask(p, crown, { base: C(pal[1]), hi: C(pal[0]), lo: C(pal[2]), ol: C('#2a0c04') }, { speck: 0.2, seed: 7 });
        p.set(24, 7 + bob, C('#ffffff')); p.set(24, 5 + bob, C('#ffffff'));
        p.set(21, 18 + bob, C('#ffd27a')); p.set(27, 18 + bob, C('#ffd27a'));
        for (let k = 0; k < 9; k++) p.set(12 + k * 3, 42 - (k % 4) * 4 + (frame % 2), k % 2 ? C('#ff6a2c') : C('#ffd27a'));
        if (bright) for (let y = 30; y < 50; y += 4) p.set(14 + (y % 8), y, C('#ffb347'));
        break;
      }
      case 'mire': {
        const mound = new Mask(48, 52).ell(24, 36 + bob, 15, 12);
        paintMask(p, mound, { base: C('#2f5a2c'), hi: C('#4f8f3a'), lo: C('#16301a'), ol: C('#081308') }, { speck: 0.2, seed: 8 });
        const head = new Mask(48, 52).ell(24, 22 + bob, 6.4, 6.4);
        paintMask(p, head, { base: C('#4f8f3a'), hi: C('#7fbf5a'), lo: C('#1e3a22'), ol: C('#0a1a0c') }, { speck: 0.1, seed: 9 });
        for (let k = 0; k < 12; k++) {
          const x = 14 + k * 2 + (k % 3), y0 = 12 + bob + (k % 2);
          p.line(x, y0, x + (k % 2 ? 2 : -2), y0 + 10 + (k % 4), C('#7fbf5a'));
        }
        p.rect(20, 21 + bob, 21, 22 + bob, C(pal[0])); p.rect(26, 21 + bob, 27, 22 + bob, C(pal[0]));
        for (let k = 0; k < 4; k++) p.line(12 + k * 8, 44, 10 + k * 8 + (k % 2) * 3, 51, C('#24411e'));
        if (bright) for (let k = 0; k < 6; k++) p.set(10 + k * 5, 47 - (k % 2), C('#c8ff7a'));
        break;
      }
      case 'stone': {
        const shoulders = new Mask(48, 52).ell(11, 24 + bob, 6, 5).ell(37, 24 + bob, 6, 5);
        paintMask(p, shoulders, { base: C('#7a7268'), hi: C('#a69c8e'), lo: C('#4a443c'), ol: C('#1a1714') }, { speck: 0.2, seed: 10 });
        const body = new Mask(48, 52).ell(24, 34 + bob, 14, 15);
        paintMask(p, body, { base: C('#8f8578'), hi: C('#b3a897'), lo: C('#4d463e'), ol: C('#1a1714') }, { speck: 0.2, seed: 11 });
        const head = new Mask(48, 52).ell(24, 15 + bob, 8, 7);
        paintMask(p, head, { base: C('#9a9084'), hi: C('#c4b9a8'), lo: C('#514a40'), ol: C('#1a1714') }, { speck: 0.2, seed: 12 });
        p.line(18, 40, 22, 48, C('#3a332c')); p.line(28, 36, 33, 46, C('#3a332c')); p.line(20, 22, 30, 26, C('#3a332c'));
        p.rect(20, 14 + bob, 22, 16 + bob, C(pal[0])); p.rect(26, 14 + bob, 28, 16 + bob, C(pal[0]));
        dottedRing(p, 24, 35 + bob, 4, C(pal[0]), 2);
        if (bright) for (let x = 10; x < 38; x += 5) p.set(x, 48 + ((x / 5) % 2), C(pal[0]));
        break;
      }
      case 'tide': {
        const fan = new Mask(48, 52).poly([[24, 30 + bob], [4, 50], [14, 51], [24, 40], [34, 51], [44, 50]]);
        paintMask(p, fan, { base: C('#1e7f94'), hi: C('#3ec2d4'), lo: C('#0e4b5a'), ol: C('#06222a') }, { speck: 0.15, seed: 13 });
        const torso = new Mask(48, 52).ell(24, 26 + bob, 6, 8);
        paintMask(p, torso, { base: C('#bff3f4'), hi: C('#ffffff'), lo: C('#7fc9d2'), ol: C('#103c4a') }, { speck: 0.05, seed: 14 });
        const head = new Mask(48, 52).ell(24, 15 + bob, 5, 5.4);
        paintMask(p, head, { base: C('#e6fbff'), hi: C('#ffffff'), lo: C('#8fd4de'), ol: C('#103c4a') }, { speck: 0.04, seed: 15 });
        const crown = new Mask(48, 52).poly([[16, 11 + bob], [18, 4 + bob], [21, 9 + bob], [24, 2 + bob], [27, 9 + bob], [30, 4 + bob], [32, 11 + bob]]);
        paintMask(p, crown, { base: C('#f0a58a'), hi: C('#ffd0b8'), lo: C('#a85a44'), ol: C('#3a1a12') }, { speck: 0.1, seed: 16 });
        p.set(21, 15 + bob, C(pal[0])); p.set(27, 15 + bob, C(pal[0]));
        for (let k = 0; k < 6; k++) p.line(6 + k * 6, 47, 9 + k * 6, 40 + (k % 2), C('#7ff3ff'));
        if (bright) for (let k = 0; k < 8; k++) p.set(4 + k * 5, 26 + (k % 2) * 6, C('#c9fbff'));
        break;
      }
      case 'grove': {
        const trunk = new Mask(48, 52).rect(19, 26, 29, 50);
        paintMask(p, trunk, { base: C('#4a3a4e'), hi: C('#6a5670'), lo: C('#28202c'), ol: C('#0e0a12') }, { speck: 0.2, seed: 17 });
        for (let y = 28; y < 50; y += 5) p.line(20, y, 28, y + 2, C('#2a202e'));
        const crown = new Mask(48, 52).ell(24, 12 + bob, 14, 11).ell(10, 22 + bob, 6, 5).ell(38, 22 + bob, 6, 5);
        paintMask(p, crown, { base: C('#3f2a4a'), hi: C(pal[0]), lo: C('#241628'), ol: C('#0c0612'), mid: C('#5a3a6a') }, { speck: 0.25, seed: 18 });
        for (let k = 0; k < 10; k++) p.set(12 + ((k * 7) % 26), 6 + ((k * 5) % 14) + bob, C(pal[1]));
        const face = new Mask(48, 52).ell(24, 22 + bob, 4, 3.6);
        paintMask(p, face, { base: C('#1f1428'), hi: C('#3a2a4a'), lo: C('#0c0612'), ol: C('#0c0612') }, { speck: 0, seed: 19 });
        p.set(22, 21 + bob, C(pal[0])); p.set(26, 21 + bob, C(pal[0]));
        p.line(18, 40, 6, 36, C('#4a3a4e')); p.line(30, 40, 42, 36, C('#4a3a4e'));
        if (bright) for (let k = 0; k < 5; k++) p.set(6 + k * 8, 6 + (k % 2) * 3, C(pal[0]));
        break;
      }
      default:
        break;
    }
    return S(p, 24, 50, 3, 2);
  });
}

// ---------------------------------------------------------------- held weapons
export function weaponSprite(itemId: string): Sprite {
  return memoSprite(`wpn:${itemId}`, () => {
    const it = ITEMS[itemId];
    const p = new Pix(24, 8);
    const col = it?.col === 'iron' ? C('#c9d0d8') : it?.col === 'stone' ? C('#a9a6a0') : C('#d8dce2');
    const shaft = C('#8a5a2e');
    const icon = it?.icon ?? 'knife';
    if (icon === 'spear') {
      p.line(0, 4, 22, 4, shaft); p.line(0, 3, 22, 3, shaft);
      p.set(22, 4, col); p.set(23, 4, col); p.set(21, 3, col); p.set(21, 5, col);
    } else if (icon === 'axe') {
      p.line(0, 4, 16, 4, shaft);
      fillMask(p, new Mask(24, 8).poly([[14, 0], [22, 1], [22, 7], [14, 8]]), col, C('#2a2e34'));
    } else if (icon === 'pick') {
      p.line(0, 4, 17, 4, shaft);
      p.line(16, 0, 20, 1, col); p.line(20, 1, 23, 4, col); p.line(16, 8, 20, 7, col); p.line(20, 7, 23, 4, col);
    } else {
      p.rect(0, 3, 4, 5, C('#6b4a2b'));
      fillMask(p, new Mask(24, 8).poly([[4, 2], [19, 3], [22, 4], [19, 5], [4, 6]]), col, C('#2a2e34'));
    }
    return S(p, 2, 4);
  });
}

// ---------------------------------------------------------------- item icons (16×16)
export function iconPix(itemId: string): Pix {
  const it = ITEMS[itemId];
  const key = `icon:${itemId}`;
  const cached = memo.get(key);
  if (cached) return cached.p;
  const p = new Pix(16, 16);
  const ic = it?.icon ?? 'box';
  const col = it?.col === 'iron' ? C('#c9d0d8') : it?.col === 'stone' ? C('#a9a6a0') : it?.col === 'hide' ? C('#9a6a4a') : it?.col?.startsWith('#') ? C(it.col) : C('#b08a5a');
  const ol = C('#1c1420');
  const f = (m: Mask, c: number) => fillMask(p, m, c, ol);
  switch (ic) {
    case 'log': f(new Mask(16, 16).rect(2, 5, 13, 10), C('#8a5a2e')); p.rect(2, 5, 2, 10, C('#c9a06a')); p.rect(13, 5, 13, 10, C('#6b4a2b')); p.line(5, 7, 10, 7, C('#6b4a2b')); break;
    case 'stone': f(new Mask(16, 16).ell(8, 9, 6, 4.8), C('#8f949b')); p.rect(5, 6, 7, 6, C('#c5cad1')); p.rect(9, 10, 11, 10, C('#5a5f66')); break;
    case 'fiber': for (let k = 0; k < 4; k++) { p.line(3 + k * 2, 13, 9 + k * 2, 2 + k, C('#9bbf5a')); p.line(4 + k * 2, 13, 10 + k * 2, 2 + k, C('#5f8a3e')); } break;
    case 'plank': f(new Mask(16, 16).rect(2, 4, 13, 11), C('#b08048')); p.line(3, 7, 12, 7, C('#7a5230')); p.line(3, 10, 12, 10, C('#7a5230')); break;
    case 'rope': f(new Mask(16, 16).ell(8, 8, 6, 6).sub(new Mask(16, 16).ell(8, 8, 3, 3)), C('#c9a06a')); p.set(12, 3, C('#e3c08c')); break;
    case 'cloth': f(new Mask(16, 16).rect(3, 3, 12, 12), C('#e8dcc0')); for (let k = 5; k < 13; k += 3) { p.line(k, 3, k, 12, C('#c7b893')); p.line(3, k, 12, k, C('#c7b893')); } break;
    case 'hide': f(new Mask(16, 16).ell(8, 8, 6, 5), C('#8a5a3c')); for (let k = 0; k < 4; k++) p.set(4 + k * 2, 6 + (k % 2) * 4, C('#e0c49a')); break;
    case 'scrap': f(new Mask(16, 16).ell(8, 8, 5.5, 5.5).sub(new Mask(16, 16).ell(8, 8, 2, 2)), C('#9a6a4a')); p.set(8, 2, C('#c08a5a')); p.set(14, 8, C('#c08a5a')); p.set(2, 8, C('#c08a5a')); break;
    case 'spare': f(new Mask(16, 16).ell(8, 8, 5.5, 5.5).sub(new Mask(16, 16).ell(8, 8, 2, 2)), C('#d9b15a')); p.set(7, 7, C('#fff1a6')); break;
    case 'ore': f(new Mask(16, 16).ell(8, 9, 6, 5), C('#5a5450')); for (const [x, y] of [[5, 7], [9, 10], [7, 11], [11, 6]]) p.set(x, y, C('#e0743a')); break;
    case 'ingot': f(new Mask(16, 16).poly([[3, 11], [5, 6], [11, 6], [13, 11]]), C('#c8ccd2')); p.line(5, 7, 10, 7, C('#ffffff')); break;
    case 'char': f(new Mask(16, 16).rect(3, 5, 12, 11), C('#2a2a2e')); p.line(4, 6, 11, 6, C('#4a4a52')); break;
    case 'herb': p.line(8, 13, 8, 6, C('#3f7a33')); f(new Mask(16, 16).ell(5, 7, 3, 2), C('#5fae4a')); f(new Mask(16, 16).ell(11, 6, 3, 2), C('#5fae4a')); break;
    case 'gel': f(new Mask(16, 16).ell(8, 9, 5.5, 4.5), C('#7fe07a')); p.set(6, 7, C('#e8ffe0')); break;
    case 'specimen': f(new Mask(16, 16).rect(4, 5, 11, 14), C('#9ff3ff')); p.rect(5, 2, 10, 4, C('#8a5a2e')); p.rect(6, 8, 9, 12, C('#4fd6e8')); break;
    case 'bp': f(new Mask(16, 16).rect(3, 3, 12, 13), C('#eadbb0')); p.line(5, 6, 10, 6, C('#a08a5a')); p.line(5, 9, 10, 9, C('#a08a5a')); p.rect(7, 11, 8, 12, C('#c83a3a')); break;
    case 'seed': f(new Mask(16, 16).ell(8, 9, 3, 4), C('#8a6a3a')); p.line(8, 5, 8, 2, C('#5fae4a')); p.set(9, 3, C('#5fae4a')); break;
    case 'turnip': f(new Mask(16, 16).ell(8, 10, 5, 4.5), C('#f0ecff')); p.rect(6, 6, 10, 7, C('#a070c0')); p.line(8, 5, 8, 2, C('#5fae4a')); p.line(8, 3, 4, 1, C('#5fae4a')); break;
    case 'berry': for (const [x, y] of [[5, 9], [10, 9], [8, 6], [8, 12]]) f(new Mask(16, 16).ell(x, y, 2.4, 2.4), C('#d33d4a')); p.set(4, 8, C('#ffb3b8')); p.set(9, 5, C('#ffb3b8')); break;
    case 'mush': f(new Mask(16, 16).ell(8, 6, 6, 4), C('#c8443d')); p.rect(6, 9, 9, 13, C('#efe2c6')); p.set(5, 5, C('#fff4e8')); p.set(10, 4, C('#fff4e8')); break;
    case 'rawmeat': f(new Mask(16, 16).ell(7, 8, 5, 4), C('#c4505a')); f(new Mask(16, 16).ell(12, 11, 2, 2), C('#f2ead3')); break;
    case 'meat': f(new Mask(16, 16).ell(8, 8, 5.5, 4.5), C('#9a5a34')); for (let k = 0; k < 3; k++) p.line(5 + k * 2, 6, 7 + k * 2, 10, C('#4a2a18')); break;
    case 'ration': f(new Mask(16, 16).rect(3, 5, 12, 11), C('#c9b27a')); p.line(3, 8, 12, 8, C('#8a6a3a')); p.line(8, 5, 8, 11, C('#8a6a3a')); break;
    case 'bandage': f(new Mask(16, 16).ell(8, 8, 5.5, 5.5).sub(new Mask(16, 16).ell(8, 8, 2, 2)), C('#f4f4f4')); p.rect(7, 5, 8, 11, C('#c83a3a')); p.rect(5, 7, 11, 8, C('#c83a3a')); break;
    case 'potion': f(new Mask(16, 16).rect(7, 2, 9, 6), C('#cfe6ff')); p.rect(7, 2, 9, 2, C('#b5894f')); f(new Mask(16, 16).ell(8, 10, 5, 4.5), C('#cfe6ff')); p.rect(5, 10, 11, 12, C('#3f8fd6')); break;
    case 'arrow': p.line(2, 13, 12, 3, C('#c6b08a')); p.line(12, 3, 13, 2, C('#9aa3ad')); p.set(13, 2, C('#c4ccd4')); p.line(2, 13, 4, 14, C('#c83a3a')); break;
    case 'torch': p.rect(7, 6, 8, 14, C('#7a5230')); fillMask(p, new Mask(16, 16).poly([[6, 7], [8, 1], [10, 7]]), C('#ffb347'), ol); p.set(8, 4, C('#fff1a6')); break;
    case 'lantern': f(new Mask(16, 16).rect(4, 5, 11, 14), C('#6b6f78')); p.rect(6, 7, 9, 12, C('#ffd27a')); p.rect(7, 2, 8, 4, C('#3c3f44')); break;
    case 'knife': p.rect(2, 12, 4, 14, C('#6b4a2b')); fillMask(p, new Mask(16, 16).poly([[4, 12], [12, 3], [14, 5], [6, 14]]), col, ol); break;
    case 'axe': p.line(3, 13, 10, 6, C('#8a5a2e')); fillMask(p, new Mask(16, 16).poly([[7, 3], [14, 2], [14, 8], [10, 8]]), col, ol); break;
    case 'pick': p.line(3, 13, 11, 5, C('#8a5a2e')); fillMask(p, new Mask(16, 16).poly([[3, 4], [8, 2], [14, 4], [10, 6]]), col, ol); break;
    case 'spear': p.line(2, 14, 12, 4, C('#8a5a2e')); fillMask(p, new Mask(16, 16).poly([[11, 2], [14, 5], [12, 6]]), col, ol); break;
    case 'bow': p.line(4, 2, 11, 8, C('#8a5a2e')); p.line(11, 8, 4, 14, C('#8a5a2e')); p.line(4, 2, 4, 14, C('#e6e0d0')); break;
    case 'armor': fillMask(p, new Mask(16, 16).poly([[3, 4], [6, 2], [10, 2], [13, 4], [13, 14], [3, 14]]), col, ol); p.line(8, 4, 8, 13, C('#00000040')); break;
    case 'pack': f(new Mask(16, 16).rect(3, 4, 12, 14), C('#8a5a3c')); p.line(3, 8, 12, 8, C('#5a3824')); p.rect(6, 2, 9, 3, C('#6b4a2b')); break;
    case 'claim': p.rect(7, 3, 8, 14, C('#7a5230')); fillMask(p, new Mask(16, 16).poly([[8, 3], [14, 5], [8, 8]]), C('#c83a3a'), ol); break;
    case 'escrow': f(new Mask(16, 16).rect(2, 6, 13, 13), C('#5b3a8c')); p.rect(2, 9, 13, 9, C('#d9b35a')); p.set(7, 10, C('#fff1a6')); break;
    case 'cartkit': f(new Mask(16, 16).ell(8, 9, 5, 5).sub(new Mask(16, 16).ell(8, 9, 2, 2)), C('#7a5230')); p.line(8, 4, 8, 14, C('#c9a06a')); p.line(3, 9, 13, 9, C('#c9a06a')); break;
    case 'core': f(new Mask(16, 16).ell(8, 8, 5.5, 5.5), C('#ff8a3d')); f(new Mask(16, 16).ell(8, 8, 2.5, 2.5), C('#fff1a6')); dottedRing(p, 8, 8, 7, C('#ffb347'), 2); break;
    case 'cash': f(new Mask(16, 16).ell(8, 10, 5.5, 3), C('#e8b84a')); f(new Mask(16, 16).ell(8, 7, 5.5, 3), C('#f4d77a')); p.set(8, 7, C('#7a4a10')); p.set(7, 8, C('#7a4a10')); break;
    case 'key': f(new Mask(16, 16).ell(5, 8, 3.5, 3.5).sub(new Mask(16, 16).ell(5, 8, 1.2, 1.2)), C('#d9b35a')); p.rect(8, 7, 13, 8, C('#d9b35a')); p.rect(11, 9, 12, 11, C('#d9b35a')); break;
    case 'estone': fillMask(p, new Mask(16, 16).poly([[8, 2], [13, 6], [11, 13], [5, 13], [3, 6]]), col, ol); p.set(7, 5, C('#ffffff')); p.set(8, 4, C('#ffffff')); break;
    default: f(new Mask(16, 16).rect(3, 3, 12, 12), C('#999999'));
  }
  memo.set(key, S(p, 8, 8));
  return p;
}

/** Simple bitmap digits for crisp in-world numbers (3×5). */
export const DIGITS: Record<string, number[]> = {
  '0': [7, 5, 5, 5, 7], '1': [2, 6, 2, 2, 7], '2': [7, 1, 7, 4, 7], '3': [7, 1, 3, 1, 7], '4': [5, 5, 7, 1, 1],
  '5': [7, 4, 7, 1, 7], '6': [7, 4, 7, 5, 7], '7': [7, 1, 2, 2, 2], '8': [7, 5, 7, 5, 7], '9': [7, 5, 7, 1, 7],
  '!': [2, 2, 2, 0, 2], '-': [0, 0, 7, 0, 0], ' ': [0, 0, 0, 0, 0], 'x': [5, 5, 2, 5, 5]
};

