// Pixel buffer, masks and edge-aware shading. DOM-free so the same art runs in the browser and in Vitest PNG dumps.
import { hash2 } from '../core/rng';

/** Packs #rrggbb (and alpha) into ABGR little-endian order used by ImageData. */
export function C(hex: string, a = 255): number {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return (((a & 255) << 24) | (b << 16) | (g << 8) | r) >>> 0;
}

export function mixC(a: number, b: number, t: number): number {
  const k = Math.max(0, Math.min(1, t));
  const ar = a & 255, ag = (a >> 8) & 255, ab = (a >> 16) & 255, aa = (a >>> 24) & 255;
  const br = b & 255, bg = (b >> 8) & 255, bb = (b >> 16) & 255, ba = (b >>> 24) & 255;
  const r = Math.round(ar + (br - ar) * k), g = Math.round(ag + (bg - ag) * k);
  const bl = Math.round(ab + (bb - ab) * k), al = Math.round(aa + (ba - aa) * k);
  return (((al & 255) << 24) | (bl << 16) | (g << 8) | r) >>> 0;
}

export function shadeC(c: number, k: number): number {
  const r = Math.min(255, Math.round((c & 255) * k));
  const g = Math.min(255, Math.round(((c >> 8) & 255) * k));
  const b = Math.min(255, Math.round(((c >> 16) & 255) * k));
  return (((c >>> 24) << 24) | (b << 16) | (g << 8) | r) >>> 0;
}

export function withAlpha(c: number, a: number): number {
  return (((Math.round(Math.max(0, Math.min(1, a)) * 255)) << 24) | (c & 0xffffff)) >>> 0;
}

export class Pix {
  readonly w: number;
  readonly h: number;
  readonly d: Uint32Array;
  constructor(w: number, h: number) {
    this.w = w;
    this.h = h;
    this.d = new Uint32Array(w * h);
  }
  set(x: number, y: number, c: number): void {
    if (x >= 0 && y >= 0 && x < this.w && y < this.h) this.d[y * this.w + x] = c;
  }
  get(x: number, y: number): number {
    return x >= 0 && y >= 0 && x < this.w && y < this.h ? this.d[y * this.w + x] : 0;
  }
  /** Source-over blend with a packed colour and alpha 0..1. */
  blend(x: number, y: number, c: number, a = 1): void {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    const i = y * this.w + x;
    const dst = this.d[i];
    const da = (dst >>> 24) / 255;
    const oa = a + da * (1 - a);
    if (oa <= 0) return;
    const sr = c & 255, sg = (c >> 8) & 255, sb = (c >> 16) & 255;
    const dr = dst & 255, dg = (dst >> 8) & 255, db = (dst >> 16) & 255;
    const r = Math.round((sr * a + dr * da * (1 - a)) / oa);
    const g = Math.round((sg * a + dg * da * (1 - a)) / oa);
    const b = Math.round((sb * a + db * da * (1 - a)) / oa);
    this.d[i] = (((Math.round(oa * 255)) << 24) | (b << 16) | (g << 8) | r) >>> 0;
  }
  rect(x0: number, y0: number, x1: number, y1: number, c: number): void {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) this.set(x, y, c);
  }
  /** Bresenham line in a solid colour. */
  line(x0: number, y0: number, x1: number, y1: number, c: number): void {
    let dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (let guard = 0; guard < 4096; guard++) {
      this.set(x0, y0, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
    dx = 0; dy = 0;
  }
  clone(): Pix {
    const p = new Pix(this.w, this.h);
    p.d.set(this.d);
    return p;
  }
  /** Writes `src` onto this buffer at (ox,oy) with source-over alpha. */
  stamp(src: Pix, ox: number, oy: number): void {
    for (let y = 0; y < src.h; y++) for (let x = 0; x < src.w; x++) {
      const c = src.d[y * src.w + x];
      const a = (c >>> 24) / 255;
      if (a > 0) this.blend(ox + x, oy + y, c, a);
    }
  }
}

export class Mask {
  readonly w: number;
  readonly h: number;
  readonly m: Uint8Array;
  constructor(w: number, h: number) {
    this.w = w;
    this.h = h;
    this.m = new Uint8Array(w * h);
  }
  get(x: number, y: number): boolean {
    return x >= 0 && y >= 0 && x < this.w && y < this.h && this.m[y * this.w + x] === 1;
  }
  /** Filled ellipse tested on pixel centres. */
  ell(cx: number, cy: number, rx: number, ry: number, v = 1): this {
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
      if (dx * dx + dy * dy <= 1) this.m[y * this.w + x] = v;
    }
    return this;
  }
  rect(x0: number, y0: number, x1: number, y1: number, v = 1): this {
    for (let y = Math.max(0, y0); y <= Math.min(this.h - 1, y1); y++) for (let x = Math.max(0, x0); x <= Math.min(this.w - 1, x1); x++) this.m[y * this.w + x] = v;
    return this;
  }
  /** Even-odd polygon fill on pixel centres. */
  poly(pts: number[][], v = 1): this {
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      const px = x + 0.5, py = y + 0.5;
      let inside = false;
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
        const [xi, yi] = pts[i], [xj, yj] = pts[j];
        if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) inside = !inside;
      }
      if (inside) this.m[y * this.w + x] = v;
    }
    return this;
  }
  /** Thick segment (distance ≤ r from the segment). */
  seg(x0: number, y0: number, x1: number, y1: number, r: number, v = 1): this {
    const minX = Math.floor(Math.min(x0, x1) - r - 1), maxX = Math.ceil(Math.max(x0, x1) + r + 1);
    const minY = Math.floor(Math.min(y0, y1) - r - 1), maxY = Math.ceil(Math.max(y0, y1) + r + 1);
    const vx = x1 - x0, vy = y1 - y0;
    const len2 = vx * vx + vy * vy || 1;
    for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
      if (x < 0 || y < 0 || x >= this.w || y >= this.h) continue;
      const px = x + 0.5 - x0, py = y + 0.5 - y0;
      const t = Math.max(0, Math.min(1, (px * vx + py * vy) / len2));
      const dx = px - t * vx, dy = py - t * vy;
      if (dx * dx + dy * dy <= r * r) this.m[y * this.w + x] = v;
    }
    return this;
  }
  or(o: Mask): this {
    for (let i = 0; i < this.m.length; i++) if (o.m[i]) this.m[i] = 1;
    return this;
  }
  sub(o: Mask): this {
    for (let i = 0; i < this.m.length; i++) if (o.m[i]) this.m[i] = 0;
    return this;
  }
  and(o: Mask): this {
    for (let i = 0; i < this.m.length; i++) if (!o.m[i]) this.m[i] = 0;
    return this;
  }
  shift(dx: number, dy: number): Mask {
    const r = new Mask(this.w, this.h);
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) if (this.get(x, y)) r.m[(y + dy) * this.w + x + dx] = 1 * ((y + dy) >= 0 && (x + dx) >= 0 && (y + dy) < this.h && (x + dx) < this.w ? 1 : 0);
    return r;
  }
  clone(): Mask {
    const r = new Mask(this.w, this.h);
    r.m.set(this.m);
    return r;
  }
  count(): number {
    let n = 0;
    for (let i = 0; i < this.m.length; i++) n += this.m[i];
    return n;
  }
}

/** Distance (4-neighbourhood, capped at 4) from each inside pixel to the nearest outside pixel. */
export function edgeDistance(m: Mask): Uint8Array {
  const out = new Uint8Array(m.w * m.h);
  for (let i = 0; i < out.length; i++) out[i] = m.m[i] ? 4 : 0;
  for (let pass = 0; pass < 3; pass++) {
    for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
      const i = y * m.w + x;
      if (!m.m[i]) continue;
      let best = out[i];
      const nb = [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]];
      for (const [nx, ny] of nb) {
        if (nx < 0 || ny < 0 || nx >= m.w || ny >= m.h) { best = 1; break; }
        const ni = ny * m.w + nx;
        if (!m.m[ni]) { best = 1; break; }
        best = Math.min(best, out[ni] + 1);
      }
      out[i] = Math.min(4, best);
    }
  }
  return out;
}

export interface Pal {
  base: number;
  hi: number;
  lo: number;
  ol: number;
  mid?: number;
}

/**
 * Paints a mask with light from the top-left: 1px rim highlights on top/left, shadows on bottom/right,
 * a second-band mid tone, speckled interior and a one-pixel outline.
 */
export function paintMask(p: Pix, m: Mask, pal: Pal, opt: { speck?: number; seed?: number; ox?: number; oy?: number; outline?: boolean } = {}): void {
  const dist = edgeDistance(m);
  const speck = opt.speck ?? 0.1;
  const seed = opt.seed ?? 0;
  const ox = opt.ox ?? 0, oy = opt.oy ?? 0;
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = y * m.w + x;
    if (!m.m[i]) continue;
    const d = dist[i];
    const up = m.get(x, y - 1), dn = m.get(x, y + 1), lf = m.get(x - 1, y), rt = m.get(x + 1, y);
    let c = pal.base;
    if (d <= 1) {
      const lightSide = !up || !lf;
      const darkSide = !dn || !rt;
      if (lightSide && !darkSide) c = pal.hi;
      else if (darkSide && !lightSide) c = pal.lo;
      else if (lightSide && darkSide) c = pal.mid ?? pal.base;
    } else if (d === 2) {
      const lightSide = !up || !lf;
      const darkSide = !dn || !rt;
      if (lightSide && !darkSide) c = pal.mid ?? pal.hi;
      else if (darkSide && !lightSide) c = mixC(pal.base, pal.lo, 0.5);
    } else {
      const h = hash2(x + ox, y + oy, seed);
      if (h < speck * 0.5) c = pal.hi;
      else if (h > 1 - speck * 0.5) c = pal.lo;
    }
    p.set(x, y, c);
  }
  if (opt.outline !== false) {
    for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
      if (m.m[y * m.w + x]) continue;
      if (m.get(x - 1, y) || m.get(x + 1, y) || m.get(x, y - 1) || m.get(x, y + 1)) p.set(x, y, pal.ol);
    }
  }
}

/** Flat fill with a single outline – used for icons and small props. */
export function fillMask(p: Pix, m: Mask, c: number, ol: number): void {
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) if (m.m[y * m.w + x]) p.set(x, y, c);
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    if (m.m[y * m.w + x]) continue;
    if (m.get(x - 1, y) || m.get(x + 1, y) || m.get(x, y - 1) || m.get(x, y + 1)) p.set(x, y, ol);
  }
}

/** Soft elliptical shadow drawn as dithered alpha so it reads as pixel art. */
export function shadow(p: Pix, cx: number, cy: number, rx: number, ry: number, a = 0.32): void {
  for (let y = 0; y < p.h; y++) for (let x = 0; x < p.w; x++) {
    const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
    const d = dx * dx + dy * dy;
    if (d <= 1) {
      const dith = ((x + y) & 1) === 0 ? 1 : 0.75;
      p.blend(x, y, C('#0b0a14'), a * dith * (1 - d * 0.4));
    }
  }
}

/** Pixel-perfect ring with dashes – used for telegraphs (crisp, not anti-aliased). */
export function dottedRing(p: Pix, cx: number, cy: number, r: number, c: number, step = 3): void {
  const n = Math.max(12, Math.round(r * 5));
  for (let k = 0; k < n; k++) {
    if (k % step !== 0) continue;
    const a = (k / n) * Math.PI * 2;
    p.set(Math.round(cx + Math.cos(a) * r), Math.round(cy + Math.sin(a) * r), c);
  }
}
