// Engine: owns the authoritative state, the 60 fps realtime loop, the 1 Hz settlement tick, input and persistence.
// React reads snapshots and submits intents through this class; it never mutates world state directly.
import { GameState, Intent, Result, dispatch, emptyState, freshProfile, targets, Target, phaseInfo, claimAt, structsAt, effObj, invCap } from './state';
import { getWorld, World, T, O } from './world/world';
import { createLive, Live, simStep, SimInput, SimCtx } from './sim';
import { drawScene, drawBackdrop, DrawUi, VIEW_W, VIEW_H } from './render';
import { Sfx } from './audio';
import { loadAll, saveRun } from './persist';
import { STRUCTS, CHESTS, BAL, ITEMS } from './data/catalog';
import { TILE, MAP_W, MAP_H, tkey } from './core/rng';

export interface Toast { id: number; text: string; at: number }
export interface UiState {
  screen: 'title' | 'game';
  panel: string | null;
  target: string | null;
  buildKind: string | null;
  hot: number;
  banner: string;
  bannerAt: number;
  toasts: Toast[];
  hold: number;
  qa: boolean;
  ready: boolean;
  notes: string[];
  saveState: 'idle' | 'saving' | 'saved' | 'failed';
  lastRegion: string;
}

export class Engine {
  state: GameState = emptyState(freshProfile());
  readonly world: World = getWorld();
  readonly live: Live = createLive();
  readonly audio = new Sfx();
  readonly ui: UiState = {
    screen: 'title', panel: null, target: null, buildKind: null, hot: 0, banner: '', bannerAt: 0, toasts: [], hold: 0,
    qa: false, ready: false, notes: [], saveState: 'idle', lastRegion: ''
  };
  private ctx: SimCtx;
  private g: CanvasRenderingContext2D;
  private keys = new Set<string>();
  private edge = { roll: false, spin: false, cast: false, interact: false };
  private mouse = { x: VIEW_W / 2, y: VIEW_H / 2, down: false };
  private listeners = new Set<() => void>();
  private raf = 0;
  private lastT = 0;
  private notifyAt = 0;
  private tickId = 0;
  private saveTimer = 0;
  private toastSeq = 0;
  private evacHold = 0;
  private running = false;

  constructor(private canvas: HTMLCanvasElement) {
    this.g = canvas.getContext('2d')!;
    this.g.imageSmoothingEnabled = false;
    this.ui.qa = new URLSearchParams(location.search).has('qa');
    this.ctx = {
      state: () => this.state,
      dispatch: (i: Intent) => this.dispatch(i),
      note: (t: string) => this.toast(t),
      sfx: (n: string) => this.audio.play(n),
      world: this.world
    };
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(): void {
    for (const fn of this.listeners) fn();
  }

  now(): number {
    return Date.now() + this.state.clock.qaOffsetMs;
  }

  toast(text: string): void {
    if (!text) return;
    this.ui.toasts = [...this.ui.toasts, { id: ++this.toastSeq, text, at: performance.now() }].slice(-4);
    this.emit();
  }

  dispatch(i: Intent, req?: string): Result {
    const r = dispatch(this.state, i, req);
    if (r.ok) {
      this.state = r.state;
      if (r.msg) this.toast(r.msg);
      this.scheduleSave();
      this.emit();
    } else if (i.type !== 'tick' && i.type !== 'trail' && i.type !== 'discover') {
      this.toast(r.reason);
    }
    return r;
  }

  async boot(): Promise<void> {
    const loaded = await loadAll();
    const profile = loaded.profile ? (loaded.profile as unknown as GameState['profile']) : freshProfile();
    this.ui.notes = loaded.notes;
    if (loaded.run) {
      this.state = { ...(loaded.run as unknown as GameState), profile };
    } else {
      this.state = emptyState(profile);
    }
    if (this.state.run.status === 'active') {
      const r = dispatch(this.state, { type: 'tick', now: this.now() });
      if (r.ok) {
        this.state = r.state;
        if (r.msg) this.toast('While you were away: ' + r.msg);
      }
    }
    this.ui.ready = true;
    this.emit();
  }

  newRun(spawn: string, gender: 'male' | 'female'): void {
    const r = this.dispatch({ type: 'new_run', spawn, gender, now: this.now() });
    if (r.ok) {
      this.resetLive();
      this.ui.screen = 'game';
      this.ui.panel = null;
      this.ui.buildKind = null;
      this.ui.banner = this.state.run.spawn.toUpperCase();
      this.ui.bannerAt = performance.now();
      this.saveNow();
    }
  }

  private resetLive(): void {
    const fresh = createLive();
    Object.assign(this.live, fresh);
    this.live.cam.x = this.state.actors.player.x;
    this.live.cam.y = this.state.actors.player.y;
  }

  continueRun(): void {
    this.resetLive();
    this.ui.screen = 'game';
    this.ui.panel = null;
    this.emit();
  }

  toTitle(): void {
    this.ui.screen = 'title';
    this.ui.panel = null;
    this.ui.buildKind = null;
    this.saveNow();
    this.emit();
  }

  setPanel(p: string | null, target: string | null = null): void {
    this.ui.panel = p;
    this.ui.target = target;
    if (p) this.audio.play('ui');
    this.emit();
  }

  scheduleSave(): void {
    window.clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => void this.saveNow(), 300);
  }

  async saveNow(): Promise<void> {
    const { profile, ...run } = this.state;
    this.ui.saveState = 'saving';
    this.emit();
    const ok = await saveRun(run as unknown as Record<string, unknown>, profile as unknown as Record<string, unknown>);
    this.ui.saveState = ok ? 'saved' : 'failed';
    this.emit();
  }

  qaJump(hours: number): void {
    if (!this.ui.qa) return;
    this.dispatch({ type: 'qa_offset', ms: hours * 3600000 });
    this.toast(`QA CLOCK (UNVERIFIED) +${hours}h`);
  }

  abandon(): void {
    this.dispatch({ type: 'abandon', now: this.now() });
    this.setPanel('results');
    void this.saveNow();
  }

  // ----------------------------------------------------------------- input
  start(): void {
    if (this.running) return;
    this.running = true;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    window.addEventListener('visibilitychange', this.onVis);
    window.addEventListener('beforeunload', this.onUnload);
    this.canvas.addEventListener('pointermove', this.onMove);
    this.canvas.addEventListener('pointerdown', this.onDown);
    window.addEventListener('pointerup', this.onUp);
    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    this.tickId = window.setInterval(() => {
      if (this.state.run.status === 'active') this.dispatch({ type: 'tick', now: this.now() });
    }, 1000);
    this.raf = requestAnimationFrame(this.frame);
  }

  stop(): void {
    this.running = false;
    cancelAnimationFrame(this.raf);
    window.clearInterval(this.tickId);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('visibilitychange', this.onVis);
    window.removeEventListener('beforeunload', this.onUnload);
    window.removeEventListener('pointerup', this.onUp);
  }

  private onKeyDown = (e: KeyboardEvent): void => {
    if (this.ui.screen !== 'game') return;
    const code = e.code;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'Tab'].includes(code)) e.preventDefault();
    if (e.repeat) return;
    this.keys.add(code);
    if (code === 'Space') this.edge.roll = true;
    if (code === 'KeyQ') this.edge.spin = true;
    if (code === 'KeyF') this.edge.cast = true;
    if (code === 'KeyE') { this.edge.interact = true; this.interact(); }
    if (code === 'Escape') {
      if (this.ui.panel) this.setPanel(null);
      else if (this.ui.buildKind) { this.ui.buildKind = null; this.emit(); }
      else this.setPanel('menu');
    }
    const panelFor: Record<string, string> = { KeyI: 'inv', KeyC: 'craft', KeyB: 'build', KeyR: 'research', KeyM: 'map', Tab: 'skills' };
    if (panelFor[code]) {
      const p = panelFor[code];
      this.setPanel(this.ui.panel === p ? null : p);
    }
    if (/^Digit[1-8]$/.test(code)) {
      this.ui.hot = Number(code.slice(5)) - 1;
      this.emit();
    }
    this.emit();
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
    if (e.code === 'KeyE') this.evacHold = 0;
  };

  private onBlur = (): void => {
    this.keys.clear();
    this.mouse.down = false;
    this.evacHold = 0;
  };

  private onVis = (): void => {
    if (document.visibilityState === 'hidden') void this.saveNow();
  };

  private onUnload = (): void => {
    void this.saveNow();
  };

  private toWorld(e: PointerEvent | MouseEvent): void {
    const r = this.canvas.getBoundingClientRect();
    const sx = VIEW_W / r.width, sy = VIEW_H / r.height;
    this.mouse.x = Math.max(0, Math.min(VIEW_W - 1, (e.clientX - r.left) * sx));
    this.mouse.y = Math.max(0, Math.min(VIEW_H - 1, (e.clientY - r.top) * sy));
  }

  private onMove = (e: PointerEvent): void => this.toWorld(e);

  private onDown = (e: PointerEvent): void => {
    if (this.ui.screen !== 'game') return;
    this.toWorld(e);
    if (e.button === 0) {
      if (this.ui.buildKind) this.placeAtMouse();
      else if (!this.ui.panel) this.mouse.down = true;
    } else if (e.button === 2) {
      if (this.ui.buildKind) { this.ui.buildKind = null; this.emit(); }
      else this.useHot();
    }
  };

  private onUp = (): void => {
    this.mouse.down = false;
  };

  private camX(): number {
    return Math.round(this.live.cam.x - VIEW_W / 2);
  }

  private camY(): number {
    return Math.round(this.live.cam.y - VIEW_H / 2);
  }

  private mouseTile(): { tx: number; ty: number } {
    return { tx: Math.floor((this.mouse.x + this.camX()) / TILE), ty: Math.floor((this.mouse.y + this.camY()) / TILE) };
  }

  private placeAtMouse(): void {
    if (!this.ui.buildKind) return;
    const { tx, ty } = this.mouseTile();
    const r = this.dispatch({ type: 'build', kind: this.ui.buildKind, tx, ty, now: this.now() });
    if (r.ok) this.audio.play('build');
    else this.audio.play('error');
  }

  private useHot(): void {
    const sl = this.state.custody.inv[this.ui.hot];
    if (!sl) return;
    const d = ITEMS[sl.item];
    if (d.food || d.heal || d.cure) this.dispatch({ type: 'eat', i: this.ui.hot });
    else this.toast(`${d.name}: equip it in the weapon slot, or use it with the right key.`);
  }

  /** E: interact with the nearest target. Holding E at the dock boards the skiff after a hold. */
  interact(): void {
    if (this.ui.screen !== 'game') return;
    const t: Target | undefined = targets(this.state)[0];
    if (!t) {
      this.toast('Nothing to use here. Walk over loose drops to pick them up.');
      return;
    }
    const s = this.state;
    switch (t.kind) {
      case 'struct': {
        const st = s.entities.structures[t.id];
        if (!st) return;
        if (st.kind === 'chest' || st.kind === 'furnace' || st.kind === 'cart' && false) this.setPanel('inv', st.id);
        else if (st.kind === 'workbench') this.setPanel('craft');
        else if (st.kind === 'research_desk') this.setPanel('research', st.id);
        else if (st.kind === 'door') this.dispatch({ type: 'door', id: st.id });
        else if (st.kind === 'bed') this.dispatch({ type: 'sleep', id: st.id, now: this.now() });
        else if (st.kind === 'garden') {
          if (st.plant) this.dispatch({ type: 'crop', id: st.id, now: this.now() });
          else {
            const i = s.custody.inv.findIndex((x) => x && x.item === 'seed_turnip');
            if (i < 0) this.toast('Carry turnip seeds to plant this garden.');
            else this.dispatch({ type: 'plant', id: st.id, i, now: this.now() });
          }
        } else if (st.kind === 'escrow_chest') this.dispatch({ type: 'deposit', id: st.id, now: this.now() });
        else if (st.kind === 'cart') {
          if (s.actors.player.hitched === st.id) this.dispatch({ type: 'release', id: st.id, now: this.now() });
          else this.dispatch({ type: 'hitch', id: st.id });
        } else if (st.kind === 'claim_marker') this.toast('Owned land: nine tiles around this stake are yours to build on.');
        else this.toast(`${STRUCTS[st.kind].name}: ${STRUCTS[st.kind].desc}`);
        return;
      }
      case 'poi':
        this.dispatch({ type: 'chest', poi: t.id, now: this.now() });
        return;
      case 'vendor':
        this.setPanel('vendor');
        return;
      case 'dock':
        this.evacHold = 0.0001;
        this.toast('Keep holding E to board the evacuation skiff. The run ends there.');
        return;
      case 'gallery':
        this.dispatch({ type: 'door', id: 'gallery' });
        return;
      case 'shrine':
        this.toast(t.label);
        return;
      case 'bag':
        this.setPanel('inv', 'bag:' + t.id);
        return;
      default:
        this.toast(t.label);
    }
  }

  private buildValid(kind: string, tx: number, ty: number): boolean {
    const s = this.state;
    const def = STRUCTS[kind];
    if (!def || tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return false;
    const p = s.actors.player;
    if (Math.hypot(p.x - (tx * TILE + 8), p.y - (ty * TILE + 8)) > 5 * TILE) return false;
    const k = tkey(tx, ty);
    const t = this.world.terrain[k];
    if (([T.DEEP, T.SHALLOW, T.RIVER, T.MOUNTAIN, T.CLIFF, T.CAVE, T.PIER] as number[]).includes(t)) return false;
    const o = effObj(s, k);
    if (o && o !== O.FLOWER && o !== O.MUSH && o !== O.REED) return false;
    const here = structsAt(s, tx, ty);
    if (def.block && here.length) return false;
    if (!def.block && here.some((x) => STRUCTS[x.kind].block || x.kind === kind)) return false;
    if (kind !== 'claim_marker' && !claimAt(s, tx, ty)) return false;
    void T;
    return true;
  }

  // ----------------------------------------------------------------- loop
  private frame = (t: number): void => {
    const dt = this.lastT ? Math.min(0.05, (t - this.lastT) / 1000) : 0;
    this.lastT = t;
    const inGame = this.ui.screen === 'game';
    if (inGame) {
      const idle = !!this.ui.panel;
      const inp: SimInput = idle
        ? { ax: this.live.cam.x, ay: this.live.cam.y, up: false, down: false, left: false, right: false, attack: false, spin: false, cast: false, roll: false, sprint: false }
        : {
          ax: this.mouse.x + this.camX(), ay: this.mouse.y + this.camY(),
          up: this.keys.has('KeyW') || this.keys.has('ArrowUp'), down: this.keys.has('KeyS') || this.keys.has('ArrowDown'),
          left: this.keys.has('KeyA') || this.keys.has('ArrowLeft'), right: this.keys.has('KeyD') || this.keys.has('ArrowRight'),
          attack: this.mouse.down, spin: this.edge.spin, cast: this.edge.cast, roll: this.edge.roll,
          sprint: this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')
        };
      this.edge.spin = false; this.edge.cast = false; this.edge.roll = false;
      simStep(this.ctx, this.live, dt, inp, this.now());
      if (this.keys.has('KeyE') && !this.ui.panel) {
        const near = targets(this.state)[0];
        if (near?.kind === 'dock') {
          this.evacHold += dt;
          this.ui.hold = this.evacHold / BAL.evacuation.holdSeconds;
          if (this.evacHold >= BAL.evacuation.holdSeconds) {
            this.evacHold = 0;
            this.ui.hold = 0;
            this.keys.delete('KeyE');
            const r = this.dispatch({ type: 'evacuate', now: this.now() });
            if (r.ok) this.setPanel('results');
          }
        } else this.ui.hold = 0;
      } else {
        this.ui.hold = 0;
        this.evacHold = 0;
      }
      if (this.live.lastRegion && this.live.lastRegion !== this.ui.lastRegion) {
        this.ui.lastRegion = this.live.lastRegion;
        this.ui.banner = this.live.lastRegion.toUpperCase();
        this.ui.bannerAt = performance.now();
      }
      const now = performance.now();
      this.ui.toasts = this.ui.toasts.filter((x) => now - x.at < 4800);
      drawScene(this.g, this.world, this.state, this.live, Date.now(), this.drawUi());
    } else {
      drawBackdrop(this.g, this.world, Date.now());
    }
    if (t - this.notifyAt > 110) {
      this.notifyAt = t;
      this.emit();
    }
    this.raf = requestAnimationFrame(this.frame);
  };

  private drawUi(): DrawUi {
    const t = targets(this.state)[0];
    let buildTile: { tx: number; ty: number } | null = null;
    let valid = false;
    if (this.ui.buildKind) {
      buildTile = this.mouseTile();
      valid = this.buildValid(this.ui.buildKind, buildTile.tx, buildTile.ty);
    }
    const ageMs = performance.now() - this.ui.bannerAt;
    return {
      buildKind: this.ui.buildKind,
      buildTile,
      buildValid: valid,
      prompt: t ? (t.kind === 'dock' ? 'HOLD E' : 'E') + ' · ' + t.label : undefined,
      promptX: t?.x,
      promptY: t?.y,
      banner: ageMs < 2800 ? this.ui.banner : '',
      bannerA: ageMs < 2800 ? 1 - Math.max(0, ageMs - 2000) / 800 : 0,
      hold: this.ui.hold,
      showDeath: null
    };
  }

  /** Snapshot for React (cheap object; the state reference changes only on commit). */
  snapshot(): { state: GameState; ui: UiState; phase: ReturnType<typeof phaseInfo>; target: Target | undefined; now: number; cargo: number; cap: number } {
    const now = this.now();
    return {
      state: this.state,
      ui: this.ui,
      phase: phaseInfo(this.state, now),
      target: targets(this.state)[0],
      now,
      cargo: 0,
      cap: invCap(this.state)
    };
  }

  /** Chests in view for the inventory panel. */
  chestInfo(id: string): { name: string; empty: boolean } {
    const poi = this.world.pois.find((p) => p.id === id);
    const def = poi?.chest ? CHESTS[poi.chest] : undefined;
    return { name: def?.name ?? 'Chest', empty: !!this.state.sources['poi:' + (poi?.chest ?? '')]?.hp };
  }

  /** Used by sim-independent UI to confirm the core is castable. */
  coreReady(): boolean {
    return this.state.custody.inv.some((x) => x && x.item === 'ember_core' && (x.charges ?? 0) > 0);
  }

  /** Ensures a claim exists at the tile (used by hints). */
  inClaim(tx: number, ty: number): boolean {
    return !!claimAt(this.state, tx, ty);
  }

  /** Exposed for panels that need item lookups. */
  item(id: string) {
    return ITEMS[id];
  }

  /** For the QA clock controls and tests. */
  get tickIntervalMs(): number {
    return 1000;
  }
}

export const EMPTY_PROFILE = freshProfile;
