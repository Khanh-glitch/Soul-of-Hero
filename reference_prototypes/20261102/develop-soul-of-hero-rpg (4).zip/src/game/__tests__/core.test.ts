// Core invariants (Vitest): deterministic island, four connected starts, physical once-only harvests,
// rejected actions leave no debit, duplicate requests are idempotent, the sealed vault opens only in the final 72 h,
// runs end exactly once, and every item is conserved (held = minted − spent).
import { describe, it, expect } from 'vitest';
import { dispatch, emptyState, freshProfile, heldTotals, GameState, Intent } from '../state';
import { generateWorld, getWorld, terrainBlocks, OBJ_BLOCK, O, World } from '../world/world';
import { MAP_W, MAP_H } from '../core/rng';

const T0 = 1_800_000_000_000;
const H = 3_600_000;

function run(s: GameState, i: Intent, req?: string) {
  return dispatch(s, i, req);
}

function started(spawn = 'pinewood'): GameState {
  const r = run(emptyState(freshProfile()), { type: 'new_run', spawn, gender: 'male', now: T0 });
  if (!r.ok) throw new Error(r.reason);
  return r.state;
}

function ledgerMatches(s: GameState): boolean {
  const held = heldTotals(s);
  const items = new Set([...Object.keys(held), ...Object.keys(s.ledger.minted), ...Object.keys(s.ledger.spent)]);
  for (const i of items) if ((held[i] ?? 0) !== (s.ledger.minted[i] ?? 0) - (s.ledger.spent[i] ?? 0)) return false;
  return true;
}

function passable(w: World, k: number): boolean {
  return !terrainBlocks(w.terrain[k]) && !OBJ_BLOCK.has(w.obj[k]);
}

function reachable(w: World, sx: number, sy: number, gx: number, gy: number): boolean {
  const N = MAP_W * MAP_H;
  const seen = new Uint8Array(N);
  const q = new Int32Array(N);
  let h = 0, t = 0;
  const s0 = sy * MAP_W + sx, goal = gy * MAP_W + gx;
  seen[s0] = 1;
  q[t++] = s0;
  while (h < t) {
    const cur = q[h++];
    if (cur === goal) return true;
    const x = cur % MAP_W, y = (cur - x) / MAP_W;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= MAP_W || ny >= MAP_H) continue;
      const ni = ny * MAP_W + nx;
      if (seen[ni] || !passable(w, ni)) continue;
      seen[ni] = 1;
      q[t++] = ni;
    }
  }
  return false;
}

function findBush(w: World, sx: number, sy: number): number {
  for (let k = 0; k < w.obj.length; k++) {
    if (w.obj[k] !== O.BUSH) continue;
    if (Math.abs((k % MAP_W) - sx) < 40 && Math.abs(Math.floor(k / MAP_W) - sy) < 40) return k;
  }
  return -1;
}

describe('island and starts', () => {
  it('generates the same island from the same seed and connects four safe starts to the trade post', () => {
    const a = getWorld();
    const b = generateWorld();
    let same = true;
    for (let i = 0; i < a.terrain.length; i += 61) if (a.terrain[i] !== b.terrain[i]) { same = false; break; }
    expect(same).toBe(true);
    expect(Object.keys(a.spawns).length).toBe(4);
    const tr = a.pois.find((p) => p.id === 'trade')!;
    for (const id of ['pinewood', 'marsh', 'harbor', 'glen']) {
      const sp = a.spawns[id];
      expect(reachable(a, sp.x, sp.y, tr.x, tr.y)).toBe(true);
    }
  }, 60000);
});

describe('custody, requests and runs', () => {
  it('harvests a real node once, with physical yield and a conserved ledger', () => {
    let s = started();
    const w = getWorld();
    const key = findBush(w, w.spawns.pinewood.x, w.spawns.pinewood.y);
    expect(key).toBeGreaterThan(-1);
    const r1 = run(s, { type: 'harvest', key, tool: 'eq', now: T0 + 5000 });
    expect(r1.ok).toBe(true);
    if (!r1.ok) return;
    s = r1.state;
    expect(ledgerMatches(s)).toBe(true);
    const r2 = run(s, { type: 'harvest', key, tool: 'eq', now: T0 + 6000 });
    expect(r2.ok).toBe(false);
    expect(s.custody.ground.some((g) => g.item === 'berry') || s.custody.inv.some((x) => x && x.item === 'berry')).toBe(true);
  });

  it('rejected actions leave no partial debit', () => {
    const s = started();
    const before = JSON.stringify({ inv: s.custody.inv, led: s.ledger, st: s.entities });
    expect(run(s, { type: 'craft', recipe: 'axe_iron' }).ok).toBe(false);
    expect(run(s, { type: 'build', kind: 'wall_wood', tx: 90, ty: 90, now: T0 }).ok).toBe(false);
    expect(JSON.stringify({ inv: s.custody.inv, led: s.ledger, st: s.entities })).toBe(before);
  });

  it('duplicate requests are idempotent', () => {
    const s = started();
    const w = getWorld();
    const key = findBush(w, w.spawns.pinewood.x, w.spawns.pinewood.y);
    const intent: Intent = { type: 'harvest', key, tool: 'eq', now: T0 + 5000 };
    const r1 = run(s, intent, 'req-1');
    expect(r1.ok).toBe(true);
    if (!r1.ok) return;
    expect(run(r1.state, intent, 'req-1').ok).toBe(false);
  });

  it('the sealed vault opens only in the final 72 hours and only once', () => {
    const s0 = started();
    const v = getWorld().pois.find((p) => p.id === 'slag_vault')!;
    s0.actors.player.x = v.x * 16 + 8;
    s0.actors.player.y = v.y * 16 + 8;
    expect(run(s0, { type: 'chest', poi: 'slag_vault', now: T0 + 1 * H }).ok).toBe(false);
    const ok1 = run(s0, { type: 'chest', poi: 'slag_vault', now: T0 + 265 * H });
    expect(ok1.ok).toBe(true);
    if (!ok1.ok) return;
    expect(heldTotals(ok1.state).ragnarok_cash).toBeGreaterThanOrEqual(1);
    expect(run(ok1.state, { type: 'chest', poi: 'slag_vault', now: T0 + 265 * H }).ok).toBe(false);
    expect(ledgerMatches(ok1.state)).toBe(true);
  });

  it('a run ends exactly once, wipes run-local data and keeps only the profile', () => {
    const s = started();
    const r1 = run(s, { type: 'abandon', now: T0 + 2 * H });
    expect(r1.ok).toBe(true);
    if (!r1.ok) return;
    expect(run(r1.state, { type: 'abandon', now: T0 + 3 * H }).ok).toBe(false);
    const f = r1.state;
    expect(f.custody.inv.every((x) => x === null)).toBe(true);
    expect(Object.keys(f.entities.structures).length).toBe(0);
    expect(f.profile.history.length).toBe(1);
    expect(f.profile.secured).toBe(0);
    expect(run(f, { type: 'new_run', spawn: 'harbor', gender: 'female', now: T0 + 4 * H }).ok).toBe(true);
  });

  it('a second run starts clean and cannot start while one is active', () => {
    const s = started();
    expect(run(s, { type: 'new_run', spawn: 'glen', gender: 'male', now: T0 + H }).ok).toBe(false);
    expect(ledgerMatches(s)).toBe(true);
  });
});
