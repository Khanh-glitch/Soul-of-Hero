// Visual QA: renders the generated island and the sprite sheet to PNG files (written to /tmp/soh when enabled).
// Run with: SOH_DUMP=1 npx vitest run src/game/__tests__/art.dump.test.ts
import { describe, it, expect } from 'vitest';
import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { generateWorld, T, O, REGIONS } from '../world/world';
import { groundPix, groundKey, edgeSides, objPix, heroPix, creatureSprite, elderSprite, iconPix, structPix, weaponSprite } from '../art/sprites';
import { Pix } from '../art/pix';
import { ITEMS } from '../data/catalog';

function crc32(buf: Uint8Array): number {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function chunk(type: string, data: Uint8Array): Uint8Array {
  const out = new Uint8Array(12 + data.length);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, data.length);
  for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
  out.set(data, 8);
  dv.setUint32(8 + data.length, crc32(out.subarray(4, 8 + data.length)));
  return out;
}
function encodePng(w: number, h: number, rgba: Uint8Array): Buffer {
  const raw = new Uint8Array((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    raw.set(rgba.subarray(y * w * 4, (y + 1) * w * 4), y * (w * 4 + 1) + 1);
  }
  const ihdr = new Uint8Array(13);
  const dv = new DataView(ihdr.buffer);
  dv.setUint32(0, w); dv.setUint32(4, h);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const parts = [
    new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', new Uint8Array(deflateSync(raw))),
    chunk('IEND', new Uint8Array(0))
  ];
  return Buffer.from(Buffer.concat(parts.map((p) => Buffer.from(p))));
}

function blit(buf: Uint8Array, bw: number, src: Pix, ox: number, oy: number, scale = 1): void {
  for (let y = 0; y < src.h; y++) for (let x = 0; x < src.w; x++) {
    const c = src.d[y * src.w + x];
    const a = c >>> 24;
    if (!a) continue;
    for (let sy = 0; sy < scale; sy++) for (let sx = 0; sx < scale; sx++) {
      const px = (oy + y) * scale + sy, pxx = (ox + x) * scale + sx;
      const i = (px * bw + pxx) * 4;
      if (i < 0 || i + 3 >= buf.length) continue;
      const al = a / 255;
      buf[i] = Math.round((c & 255) * al + buf[i] * (1 - al));
      buf[i + 1] = Math.round(((c >> 8) & 255) * al + buf[i + 1] * (1 - al));
      buf[i + 2] = Math.round(((c >> 16) & 255) * al + buf[i + 2] * (1 - al));
      buf[i + 3] = 255;
    }
  }
}

const TCOL: Record<number, number[]> = {
  [T.DEEP]: [31, 79, 120], [T.SHALLOW]: [62, 143, 176], [T.SAND]: [224, 194, 122], [T.GRASS]: [93, 155, 62],
  [T.FOREST]: [60, 109, 49], [T.ROAD]: [164, 119, 74], [T.HILL]: [111, 125, 86], [T.CLIFF]: [91, 86, 82],
  [T.MOUNTAIN]: [110, 106, 114], [T.MARSH]: [79, 91, 58], [T.SNOW]: [233, 242, 248], [T.TUNDRA]: [127, 156, 136],
  [T.DESERT]: [220, 154, 85], [T.SCORCH]: [63, 49, 41], [T.SLAG]: [59, 53, 54], [T.BRIDGE]: [139, 90, 43],
  [T.RIVER]: [43, 111, 152], [T.COBBLE]: [111, 107, 104], [T.FLOOR]: [74, 66, 86], [T.CAVE]: [46, 42, 54], [T.PIER]: [160, 116, 68]
};

describe('art and world visual dump', () => {
  it('generates a varied island with POIs and four starts', () => {
    const w = generateWorld();
    const counts: Record<number, number> = {};
    for (let i = 0; i < w.terrain.length; i++) counts[w.terrain[i]] = (counts[w.terrain[i]] || 0) + 1;
    expect(Object.keys(counts).length).toBeGreaterThan(12);
    expect(Object.keys(w.spawns).length).toBe(4);
    const roads = w.road.reduce((a, b) => a + b, 0);
    expect(roads).toBeGreaterThan(120);
    const ids = w.pois.map((p) => p.id);
    expect(ids).toEqual(expect.arrayContaining(['trade', 'village', 'wreck', 'mine', 'ruin', 'vault', 'dock', 'shrine_frost', 'shrine_ember', 'shrine_mire', 'shrine_stone', 'shrine_tide', 'shrine_grove']));
    expect(REGIONS.length).toBe(11);
    if (process.env.SOH_DUMP) {
      mkdirSync('/tmp/soh', { recursive: true });
      const S = 4;
      const W = 192, H = 192;
      const buf = new Uint8Array(W * S * H * S * 4);
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x;
        let c = TCOL[w.terrain[i]] ?? [255, 0, 255];
        if (w.road[i]) c = [164, 119, 74];
        if (w.obj[i] === O.OAK || w.obj[i] === O.PINE) c = [30, 80, 35];
        if (w.obj[i] === O.ROCK || w.obj[i] === O.IRON) c = [120, 120, 125];
        for (let sy = 0; sy < S; sy++) for (let sx = 0; sx < S; sx++) {
          const p = ((y * S + sy) * W * S + (x * S + sx)) * 4;
          buf[p] = c[0]; buf[p + 1] = c[1]; buf[p + 2] = c[2]; buf[p + 3] = 255;
        }
      }
      for (const p of w.pois) for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        const px = (p.x + dx) * S, py = (p.y + dy) * S;
        for (let sy = 0; sy < S; sy++) for (let sx = 0; sx < S; sx++) {
          const q = ((py + sy) * W * S + (px + sx)) * 4;
          if (q >= 0 && q + 3 < buf.length) { buf[q] = 255; buf[q + 1] = 60; buf[q + 2] = 200; buf[q + 3] = 255; }
        }
      }
      writeFileSync('/tmp/soh/world.png', encodePng(W * S, H * S, buf));
    }
  });

  it('renders the sprite sheet', () => {
    if (!process.env.SOH_DUMP) return;
    const cell = 40;
    const cols = 16, rows = 14;
    const SC = 3;
    const bw = cols * cell * SC, bh = rows * cell * SC;
    const buf = new Uint8Array(bw * bh * 4);
    for (let i = 0; i < buf.length; i += 4) { buf[i] = 46; buf[i + 1] = 110; buf[i + 2] = 64; buf[i + 3] = 255; }
    let col = 0, row = 0;
    const put = (p: Pix) => {
      const ox = col * cell + Math.floor((cell - p.w) / 2), oy = row * cell + (cell - p.h);
      blit(buf, bw, p, ox, oy, SC);
      col++; if (col >= cols) { col = 0; row++; }
    };
    const sides = (t: number) => edgeSides(t, [T.GRASS, T.SAND, T.DEEP, T.SAND] as unknown as [number, number, number, number]);
    for (const t of [T.GRASS, T.FOREST, T.SAND, T.DEEP, T.SHALLOW, T.ROAD, T.HILL, T.MOUNTAIN, T.CLIFF, T.MARSH, T.SNOW, T.TUNDRA, T.DESERT, T.SLAG, T.COBBLE, T.BRIDGE]) {
      void groundKey; void sides;
      put(groundPix(t, 1, 1, [0, 0, 0, 0]));
    }
    for (const o of [O.OAK, O.PINE, O.DEAD, O.ROCK, O.IRON, O.BUSH, O.REED, O.MUSH, O.CACTUS, O.CRATE, O.WRECK, O.PILLAR, O.HOUSE, O.WELL, O.TRADE, O.VAULT, O.CHEST, O.MINE, O.SHRINE, O.DOOR, O.FLOWER, O.DOCKPOST, O.SKIFF]) {
      const s = objPix(o, 1, 'frost');
      if (s) put(s.p);
    }
    for (const kind of ['floor', 'wall_wood', 'wall_stone', 'door', 'bed', 'workbench', 'furnace', 'research_desk', 'garden', 'torch_post', 'escrow_chest', 'cart', 'claim_marker']) put(structPix(kind, { frame: 1 }).p);
    put(heroPix({ gender: 'male', facing: 'down', frame: 0, moving: false }));
    put(heroPix({ gender: 'male', facing: 'down', frame: 1, moving: true, armor: 'iron', pack: true }));
    put(heroPix({ gender: 'male', facing: 'right', frame: 1, moving: true }));
    put(heroPix({ gender: 'female', facing: 'down', frame: 0, moving: false }));
    put(heroPix({ gender: 'female', facing: 'right', frame: 0, moving: true, armor: 'hide' }));
    put(heroPix({ gender: 'female', facing: 'up', frame: 0, moving: false, pack: true }));
    put(heroPix({ gender: 'vendor', facing: 'down', frame: 0, moving: false }));
    for (const k of ['slime', 'wolf', 'boar', 'bat', 'archer', 'crab', 'wisp']) put(creatureSprite({ kind: k, frame: 0, pose: 'idle' }).p);
    for (const id of ['frost', 'ember', 'mire', 'stone', 'tide', 'grove']) put(elderSprite(id, id === 'ember', 0).p);
    for (const id of Object.keys(ITEMS)) put(iconPix(id));
    for (const id of ['knife_stone', 'axe_iron', 'pick_stone', 'spear_stone']) put(weaponSprite(id).p);
    writeFileSync('/tmp/soh/sprites.png', encodePng(bw, bh, buf));
    expect(row).toBeGreaterThan(0);
  });
});
