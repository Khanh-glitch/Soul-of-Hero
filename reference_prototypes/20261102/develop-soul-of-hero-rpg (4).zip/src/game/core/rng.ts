// Deterministic primitives shared by world generation, the dispatcher and the realtime simulation.
// Randomness lives in a serialisable holder (`{ rng: number }`) so every roll is replayable from saved state.

export const MAP_W = 192;
export const MAP_H = 192;
export const TILE = 16;
export const WORLD_SEED = 20260101;

/** Mulberry32 step on a mutable holder. Deterministic, serialisable, fast. */
export function nextRand(h: { rng: number }): number {
  h.rng = (h.rng + 0x6d2b79f5) | 0;
  let t = h.rng;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

/** Inclusive integer roll. */
export function randInt(h: { rng: number }, lo: number, hi: number): number {
  return lo + Math.floor(nextRand(h) * (hi - lo + 1));
}

/** Stateless hash of integer lattice coordinates, in [0,1). */
export function hash2(x: number, y: number, s: number): number {
  let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 2147483629);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

/** Smooth value noise in [0,1]. */
export function valueNoise(seed: number) {
  return (x: number, y: number): number => {
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    const xf = x - xi;
    const yf = y - yi;
    const u = xf * xf * (3 - 2 * xf);
    const v = yf * yf * (3 - 2 * yf);
    const a = hash2(xi, yi, seed);
    const b = hash2(xi + 1, yi, seed);
    const c = hash2(xi, yi + 1, seed);
    const d = hash2(xi + 1, yi + 1, seed);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
}

/** Fractal brownian motion over a value-noise field, normalised to [0,1]. */
export function fbm(noise: (x: number, y: number) => number, x: number, y: number, oct = 4): number {
  let amp = 0.5;
  let freq = 1;
  let sum = 0;
  let norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += amp * noise(x * freq, y * freq);
    norm += amp;
    amp *= 0.5;
    freq *= 2.03;
  }
  return sum / norm;
}

export const clamp = (v: number, a: number, b: number): number => (v < a ? a : v > b ? b : v);
export const tkey = (tx: number, ty: number): number => ty * MAP_W + tx;
export const inMap = (tx: number, ty: number): boolean => tx >= 0 && ty >= 0 && tx < MAP_W && ty < MAP_H;

export function strHash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
