// Realtime simulation: movement, true 360° aim, attack phases, creature AI, Elder patterns, projectiles and VFX state.
// Physical positions are simulated here. Every durable or economic consequence (loot, harvest, damage to the player,
// structure damage, Core charges, footprints, discovery) is dispatched as an intent and committed by state.ts.
import { ITEMS, CREATURES, ELDERS, BAL, NODES } from './data/catalog';
import { TILE, MAP_W, MAP_H, tkey, nextRand } from './core/rng';
import { OBJ_NODE, terrainSpeed, surfaceKind, regionAt, REGIONS, World } from './world/world';
import { GameState, Intent, Result, blockedTile, effObj, tileOf, discovered, cargoWeight } from './state';

export interface SimInput {
  ax: number; ay: number;
  up: boolean; down: boolean; left: boolean; right: boolean;
  attack: boolean; spin: boolean; cast: boolean; roll: boolean; sprint: boolean;
}

export interface SimCtx {
  state(): GameState;
  dispatch(i: Intent): Result;
  note(text: string): void;
  sfx(name: string): void;
  world: World;
}

export interface Proj { x: number; y: number; vx: number; vy: number; life: number; dmg: number; from: 'enemy' | 'player'; kind: string; col: string; dead: boolean }
export interface Fx { k: string; x: number; y: number; vx: number; vy: number; life: number; max: number; col: string; s: number; ang: number; txt: string }
export interface Haz { k: 'puddle' | 'lane' | 'root' | 'beam' | 'ring' | 'dash'; x: number; y: number; x2: number; y2: number; r: number; w: number; warn: number; life: number; dmg: number; tick: number; ang: number; spd: number; done: boolean; col: string }
export interface AiState { t: number; mode: string; ang: number; hit: boolean; cool: number; tx: number; ty: number; n: number }
export interface Atk { phase: string; kind: string; time: number; ang: number; dur: number[]; hit: Set<string>; wpn: string; tx: number; ty: number }

export interface Live {
  t: number; hitstop: number; shake: number; flash: number; iframes: number; walk: number; facing: number; moving: boolean; aim: number; slow: number;
  atk: Atk;
  roll: { t: number; dx: number; dy: number };
  cd: { spin: number; cast: number; shot: number };
  ai: Record<string, AiState>;
  proj: Proj[]; fx: Fx[]; haz: Haz[];
  cam: { x: number; y: number };
  stepX: number; stepY: number; trailCd: number; pickCd: number; discCd: number; noteCd: number; stepSnd: number;
  regen: number; elderNext: Record<string, number[]>; lastRegion: string; cellCd: number;
}

export function createLive(): Live {
  return {
    t: 0, hitstop: 0, shake: 0, flash: 0, iframes: 0, walk: 0, facing: 0, moving: false, aim: 0, slow: 0,
    atk: { phase: 'idle', kind: 'none', time: 0, ang: 0, dur: [0, 0, 0], hit: new Set(), wpn: 'hands', tx: 0, ty: 0 },
    roll: { t: 0, dx: 0, dy: 0 }, cd: { spin: 0, cast: 0, shot: 0 }, ai: {}, proj: [], fx: [], haz: [], cam: { x: 0, y: 0 },
    stepX: 0, stepY: 0, trailCd: 0, pickCd: 0, discCd: 0, noteCd: 0, stepSnd: 0, regen: 0, elderNext: {}, lastRegion: '', cellCd: 0
  };
}

// Cosmetic randomness only (particles). Gameplay randomness always comes from the seeded state.rng.
const jit = (): number => Math.random() - 0.5;

function inSector(ox: number, oy: number, ang: number, reach: number, arc: number, x: number, y: number): boolean {
  const dx = x - ox, dy = y - oy;
  if (Math.hypot(dx, dy) > reach) return false;
  if (arc >= Math.PI * 2 - 1e-3) return true;
  let diff = Math.atan2(dy, dx) - ang;
  diff = Math.atan2(Math.sin(diff), Math.cos(diff));
  return Math.abs(diff) <= arc / 2;
}

function los(s: GameState, x0: number, y0: number, x1: number, y1: number): boolean {
  for (let i = 1; i < 6; i++) {
    const t = i / 6;
    if (blockedTile(s, tileOf(x0 + (x1 - x0) * t), tileOf(y0 + (y1 - y0) * t))) return false;
  }
  return true;
}

function boxFree(s: GameState, x: number, y: number): boolean {
  return !blockedTile(s, tileOf(x - 3), tileOf(y - 2)) && !blockedTile(s, tileOf(x + 3), tileOf(y - 2)) &&
    !blockedTile(s, tileOf(x - 3), tileOf(y + 2)) && !blockedTile(s, tileOf(x + 3), tileOf(y + 2));
}

function fx(L: Live, k: string, x: number, y: number, vx: number, vy: number, life: number, col: string, size = 1, txt = ''): void {
  if (L.fx.length > 500) return;
  L.fx.push({ k, x, y, vx, vy, life, max: life, col, s: size, ang: 0, txt });
}

function sparks(L: Live, x: number, y: number, ang: number, col: string, n = 7): void {
  for (let i = 0; i < n; i++) {
    const a = ang + jit() * 2.4;
    const sp = 40 + Math.random() * 70;
    fx(L, 'spark', x, y, Math.cos(a) * sp, Math.sin(a) * sp - 20, 0.28 + Math.random() * 0.2, col, 1);
  }
}

function dust(L: Live, x: number, y: number, n = 4, col = '#d8c8a0'): void {
  for (let i = 0; i < n; i++) fx(L, 'dust', x + jit() * 8, y + jit() * 3, jit() * 14, -6 - Math.random() * 10, 0.5 + Math.random() * 0.3, col, 1 + (Math.random() > 0.6 ? 1 : 0));
}

function number(L: Live, x: number, y: number, v: number, crit: boolean): void {
  fx(L, 'text', x, y, 0, -18, 0.8, crit ? '#ffd34d' : '#ffffff', 1, String(v));
}

function note(c: SimCtx, L: Live, text: string): void {
  if (L.noteCd > 0) return;
  L.noteCd = 0.7;
  c.note(text);
}

function fire(L: Live, x: number, y: number, ang: number, spd: number, life: number, dmg: number, from: 'enemy' | 'player', kind: string, col: string): void {
  if (L.proj.length > 120) return;
  L.proj.push({ x, y, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd, life, dmg, from, kind, col, dead: false });
}

function hurtPlayer(c: SimCtx, L: Live, amount: number, src: string, now: number, toxin = 0): boolean {
  if (L.iframes > 0) return false;
  const s = c.state();
  if (s.actors.player.hp <= 0) return false;
  const r = c.dispatch({ type: 'hurt', amount, src, now, toxin });
  if (!r.ok) return false;
  L.iframes = BAL.combat.iFramesAfterHitSec;
  L.flash = 1;
  L.shake = Math.max(L.shake, 3);
  c.sfx('hurt');
  if (L.atk.kind === 'cast' && L.atk.phase === 'windup') {
    L.atk.phase = 'idle';
    L.atk.kind = 'none';
    note(c, L, 'The Core cast was interrupted. Its charge is still there.');
  }
  return true;
}

function damageCreature(c: SimCtx, _L: Live, id: string, amt: number, now: number): void {
  const s = c.state();
  const cr = s.actors.creatures.find((q) => q.id === id);
  if (!cr) return;
  cr.hp -= amt;
  if (cr.hp <= 0) {
    c.dispatch({ type: 'creature_dead', id, now });
    c.sfx('kill');
  } else {
    c.sfx('hit');
  }
}

function boxMove(s: GameState, p: { x: number; y: number }, ddx: number, ddy: number): void {
  if (ddx && boxFree(s, p.x + ddx, p.y)) p.x += ddx;
  if (ddy && boxFree(s, p.x, p.y + ddy)) p.y += ddy;
}

function contact(c: SimCtx, L: Live, now: number): void {
  const A = L.atk;
  const w = c.world;
  if (A.kind === 'cast') {
    const r = c.dispatch({ type: 'cast', tx: A.tx, ty: A.ty, now });
    if (!r.ok) {
      note(c, L, r.reason);
      A.phase = 'idle';
      A.kind = 'none';
      return;
    }
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * Math.PI * 2;
      fx(L, 'ring', A.tx, A.ty, Math.cos(a) * 60, Math.sin(a) * 60, 0.45, i % 2 ? '#ffb347' : '#ff6a2c', 1);
    }
    for (let i = 0; i < 14; i++) fx(L, 'ember', A.tx + jit() * 20, A.ty + jit() * 12, jit() * 30, -20 - Math.random() * 30, 0.9, '#ffd27a', 1);
    const ids = c.state().actors.creatures.filter((q) => Math.hypot(q.x - A.tx, q.y - A.ty) < 36).map((q) => q.id);
    for (const id of ids) damageCreature(c, L, id, 14, now);
    L.shake = 2.5;
    L.hitstop = 0.06;
    c.sfx('cast');
    return;
  }
  if (A.kind === 'shot') return;
  const s0 = c.state();
  const p0 = s0.actors.player;
  const wdef = A.wpn !== 'hands' ? ITEMS[A.wpn] : null;
  const dmg = wdef?.dmg ?? 2;
  let reach = wdef?.reach ?? 14;
  let arc = ((wdef?.arc ?? 80) * Math.PI) / 180;
  const spin = A.kind === 'spin';
  if (spin) {
    arc = Math.PI * 2;
    reach += 6;
  }
  const ox = p0.x, oy = p0.y;
  c.sfx(spin ? 'spin' : 'swing');
  const hitIds = s0.actors.creatures.filter((q) => inSector(ox, oy, A.ang, reach + 4, arc, q.x, q.y)).map((q) => q.id);
  for (const id of hitIds) {
    if (A.hit.has(id)) continue;
    A.hit.add(id);
    const st = c.state();
    const cr = st.actors.creatures.find((q) => q.id === id);
    if (!cr) continue;
    const stunned = L.ai[id]?.mode === 'stun';
    const crit = stunned ? 1.5 : 1;
    const amt = dmg * crit * (spin ? 0.8 : 1);
    const ka = Math.atan2(cr.y - oy, cr.x - ox);
    const nx = cr.x + Math.cos(ka) * 8, ny = cr.y + Math.sin(ka) * 8;
    if (!blockedTile(st, tileOf(nx), tileOf(ny))) {
      cr.x = nx;
      cr.y = ny;
    }
    sparks(L, cr.x, cr.y, ka, crit > 1 ? '#ffd34d' : '#fff1d6');
    number(L, cr.x, cr.y - 10, Math.round(amt), crit > 1);
    L.hitstop = Math.max(L.hitstop, BAL.combat.hitStopSec);
    L.shake = Math.max(L.shake, 1.5);
    damageCreature(c, L, id, amt, now);
  }
  // Harvest eligibility is decided by the dispatcher; the sim only reports what the swing touched.
  const rt = Math.ceil((reach + 8) / TILE);
  const ptx = tileOf(ox), pty = tileOf(oy);
  const nodes: number[] = [];
  for (let dy = -rt; dy <= rt; dy++) for (let dx = -rt; dx <= rt; dx++) {
    const tx = ptx + dx, ty = pty + dy;
    if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) continue;
    const k = tkey(tx, ty);
    if (!OBJ_NODE[w.obj[k]] || !effObj(s0, k)) continue;
    if (!inSector(ox, oy, A.ang, reach + 8, arc, tx * TILE + 8, ty * TILE + 8)) continue;
    if (A.hit.has('n' + k)) continue;
    A.hit.add('n' + k);
    nodes.push(k);
  }
  for (const k of nodes) {
    const kind = NODES[OBJ_NODE[w.obj[k]]].kind;
    const r = c.dispatch({ type: 'harvest', key: k, tool: 'eq', now });
    if (r.ok) {
      const tx = k % MAP_W, ty = Math.floor(k / MAP_W);
      for (let i = 0; i < 6; i++) fx(L, 'spark', tx * TILE + 8 + jit() * 6, ty * TILE + 6, jit() * 40, -20 - Math.random() * 30, 0.35, kind === 'mine' ? '#e8e0d0' : '#c9a06a', 1);
      c.sfx(kind === 'mine' ? 'mine' : kind === 'chop' ? 'chop' : 'pluck');
    } else {
      note(c, L, r.reason);
      c.sfx('tink');
    }
  }
  // Elders are struck by swings that reach their shrine.
  if (!spin || true) {
    for (const def of ELDERS) {
      const shrine = w.pois.find((q) => q.elder === def.id);
      if (!shrine) continue;
      const sx = shrine.x * TILE + 8, sy = shrine.y * TILE + 8;
      if (A.hit.has('e' + def.id) || !inSector(ox, oy, A.ang, reach + 14, arc, sx, sy)) continue;
      A.hit.add('e' + def.id);
      sparks(L, sx, sy, A.ang, def.palette[0], 9);
      number(L, sx, sy - 22, Math.round(dmg), false);
      L.hitstop = Math.max(L.hitstop, BAL.combat.hitStopSec);
      c.dispatch({ type: 'elder_hit', id: def.id, dmg: dmg * (spin ? 0.7 : 1), now });
    }
  }
}

function startAttack(c: SimCtx, L: Live, inp: SimInput, now: number): void {
  const s = c.state();
  const p = s.actors.player;
  const weapon = s.custody.equip.weapon;
  const wdef = weapon ? ITEMS[weapon.item] : null;
  if (inp.attack) {
    if (wdef?.ranged) {
      if (L.cd.shot > 0) return;
      const r = c.dispatch({ type: 'shoot', now });
      if (!r.ok) {
        note(c, L, r.reason);
        return;
      }
      L.cd.shot = 0.6;
      fire(L, p.x, p.y - 4, L.aim, 230, 1.2, wdef.ranged ?? 8, 'player', 'arrow', '#e6dcc4');
      L.atk = { phase: 'windup', kind: 'shot', time: 0, ang: L.aim, dur: [0.05, 0.04, 0.14], hit: new Set(), wpn: weapon!.item, tx: 0, ty: 0 };
      c.sfx('shoot');
      return;
    }
    if (p.stamina < BAL.player.attackStamina) return;
    p.stamina -= BAL.player.attackStamina;
    L.regen = 0.7;
    const sw = wdef?.swing ?? 1;
    L.atk = { phase: 'windup', kind: 'swing', time: 0, ang: L.aim, dur: [BAL.combat.windupSec * sw, BAL.combat.contactSec, BAL.combat.recoverySec * sw], hit: new Set(), wpn: weapon ? weapon.item : 'hands', tx: 0, ty: 0 };
    return;
  }
  if (inp.spin && L.cd.spin <= 0 && wdef && !wdef.ranged && p.stamina >= BAL.player.spinStamina) {
    p.stamina -= BAL.player.spinStamina;
    L.regen = 0.7;
    L.cd.spin = 3.2;
    L.atk = { phase: 'windup', kind: 'spin', time: 0, ang: L.aim, dur: [0.12, 0.26, 0.16], hit: new Set(), wpn: weapon!.item, tx: 0, ty: 0 };
    c.sfx('charge');
    return;
  }
  if (inp.cast && L.cd.cast <= 0 && s.custody.inv.some((x) => x && x.item === 'ember_core' && (x.charges ?? 0) > 0)) {
    const dd = Math.min(84, Math.hypot(inp.ax - p.x, inp.ay - p.y));
    L.cd.cast = 1.8;
    L.atk = { phase: 'windup', kind: 'cast', time: 0, ang: L.aim, dur: [0.42, 0.1, 0.22], hit: new Set(), wpn: 'ember_core', tx: p.x + Math.cos(L.aim) * dd, ty: p.y + Math.sin(L.aim) * dd };
    c.sfx('charge');
  }
}

function stepFx(L: Live, dt: number): void {
  for (const f of L.fx) {
    f.life -= dt;
    f.x += f.vx * dt;
    f.y += f.vy * dt;
    if (f.k === 'spark' || f.k === 'ember' || f.k === 'dust') {
      f.vx *= 0.9;
      f.vy += (f.k === 'spark' ? 120 : -10) * dt;
    } else if (f.k === 'ring') {
      f.vx *= 0.93;
      f.vy *= 0.93;
    }
  }
  L.fx = L.fx.filter((f) => f.life > 0);
}

export function burst(L: Live, x: number, y: number): void {
  for (let i = 0; i < 12; i++) fx(L, 'ember', x, y, jit() * 50, -10 - Math.random() * 40, 0.6, '#ff8a3d', 1);
}

function stepProj(c: SimCtx, L: Live, dt: number, now: number): void {
  for (const pr of L.proj) {
    if (pr.dead) continue;
    pr.life -= dt;
    pr.x += pr.vx * dt;
    pr.y += pr.vy * dt;
    if (pr.life <= 0) { pr.dead = true; continue; }
    const s = c.state();
    const p = s.actors.player;
    if (pr.from === 'enemy') {
      if (Math.hypot(pr.x - p.x, pr.y - (p.y - 4)) < 7) {
        hurtPlayer(c, L, pr.dmg, 'a shot', now, pr.kind === 'orb' ? 6 : 0);
        pr.dead = true;
        continue;
      }
      if (blockedTile(s, tileOf(pr.x), tileOf(pr.y))) pr.dead = true;
    } else {
      const hit = s.actors.creatures.find((q) => Math.hypot(q.x - pr.x, q.y - pr.y) < 7);
      if (hit) {
        damageCreature(c, L, hit.id, pr.dmg, now);
        sparks(L, pr.x, pr.y, Math.atan2(pr.vy, pr.vx), '#fff1d6', 5);
        pr.dead = true;
        continue;
      }
      if (blockedTile(s, tileOf(pr.x), tileOf(pr.y))) {
        pr.dead = true;
        dust(L, pr.x, pr.y, 2);
      }
    }
  }
  L.proj = L.proj.filter((q) => !q.dead);
}

function walkCreature(s: GameState, cr: { x: number; y: number }, ang: number, spd: number, dt: number, flying: boolean): boolean {
  const nx = cr.x + Math.cos(ang) * spd * dt, ny = cr.y + Math.sin(ang) * spd * dt;
  if (flying || !blockedTile(s, tileOf(nx), tileOf(ny))) {
    cr.x = nx;
    cr.y = ny;
    return true;
  }
  return false;
}

function stepCreatures(c: SimCtx, L: Live, dt: number, now: number): void {
  const s0 = c.state();
  for (const id of s0.actors.creatures.map((q) => q.id)) {
    const s = c.state();
    const cr = s.actors.creatures.find((q) => q.id === id);
    if (!cr) continue;
    const p = s.actors.player;
    const def = CREATURES[cr.kind];
    let a = L.ai[id];
    if (!a) {
      a = { t: 0, mode: 'idle', ang: nextRand(s) * Math.PI * 2, hit: false, cool: 1 + nextRand(s) * 2, tx: cr.x, ty: cr.y, n: 0 };
      L.ai[id] = a;
    }
    const flying = cr.kind === 'bat' || cr.kind === 'wisp';
    const dP = Math.hypot(p.x - cr.x, p.y - cr.y);
    const seen = dP < def.sense && p.hp > 0 && los(s, cr.x, cr.y, p.x, p.y);
    a.t -= dt;
    a.cool -= dt;
    const home = Math.hypot(cr.x - cr.hx, cr.y - cr.hy);
    if (home > def.leash && a.mode === 'idle') a.ang = Math.atan2(cr.hy - cr.y, cr.hx - cr.x);
    switch (a.mode) {
      case 'idle': {
        if (seen && !(cr.kind === 'wisp' && dP > 96) && !(cr.kind === 'archer' && dP > 150)) {
          if (cr.kind === 'slime') { a.mode = 'alert'; a.t = 0.5; }
          else if (cr.kind === 'wolf') a.mode = 'stalk';
          else if (cr.kind === 'boar') { a.mode = 'snort'; a.t = 0.9; }
          else if (cr.kind === 'bat' && a.cool <= 0) { a.mode = 'dive'; a.t = 0.6; a.tx = p.x; a.ty = p.y; a.cool = 4; }
          else if (cr.kind === 'archer') { a.mode = 'draw'; a.t = 1.0; }
          else if (cr.kind === 'crab' && dP < 46) { a.mode = 'raise'; a.t = 0.5; }
          else if (cr.kind === 'wisp') { a.mode = 'pulse'; a.t = 1.0; }
          break;
        }
        if (def.tracker && !seen) {
          // C08: wolves follow only footprints that are still fresh and close enough to be sensed.
          let best: { x: number; y: number; t: number } | null = null;
          for (const f of s.world.trails) {
            if (now - f.t > f.life * 1000 || Math.hypot(f.x - cr.x, f.y - cr.y) > 42) continue;
            if (!best || f.t > best.t) best = f;
          }
          if (best) { a.mode = 'track'; a.tx = best.x; a.ty = best.y; a.t = 4; break; }
        }
        if (a.t <= 0) {
          a.ang = nextRand(s) * Math.PI * 2;
          a.t = 1 + nextRand(s) * 2.4;
        }
        const idleSpd = cr.kind === 'wisp' ? 14 : def.spd * 0.35;
        if (!walkCreature(s, cr, a.ang, idleSpd, dt, flying)) a.ang += Math.PI * (0.6 + nextRand(s) * 0.8);
        break;
      }
      case 'alert': {
        if (a.t <= 0) { a.mode = 'hop'; a.t = 0.36; a.ang = Math.atan2(p.y - cr.y, p.x - cr.x); a.hit = false; }
        break;
      }
      case 'hop': {
        walkCreature(s, cr, a.ang, def.spd, dt, false);
        if (!a.hit && dP < 10 && hurtPlayer(c, L, def.dmg, def.name, now)) a.hit = true;
        if (a.t <= 0) { a.mode = 'rest'; a.t = 0.7; }
        break;
      }
      case 'rest': if (a.t <= 0) a.mode = 'idle'; break;
      case 'stalk': {
        if (!seen) { a.mode = 'idle'; break; }
        a.ang = Math.atan2(p.y - cr.y, p.x - cr.x);
        walkCreature(s, cr, a.ang, def.spd * 0.62, dt, false);
        if (dP < 60) { a.mode = 'crouch'; a.t = 0.55; a.ang = Math.atan2(p.y - cr.y, p.x - cr.x); }
        break;
      }
      case 'crouch': {
        a.ang = Math.atan2(p.y - cr.y, p.x - cr.x);
        if (a.t <= 0) { a.mode = 'lunge'; a.t = 0.3; a.hit = false; }
        break;
      }
      case 'lunge': {
        walkCreature(s, cr, a.ang, 150, dt, false);
        if (!a.hit && dP < 11 && hurtPlayer(c, L, def.dmg, def.name, now)) a.hit = true;
        if (a.t <= 0) { a.mode = 'rest'; a.t = 0.8; }
        break;
      }
      case 'track': {
        const d = Math.hypot(a.tx - cr.x, a.ty - cr.y);
        if (seen) { a.mode = 'stalk'; break; }
        if (d < 4 || a.t <= 0) { a.mode = 'idle'; break; }
        walkCreature(s, cr, Math.atan2(a.ty - cr.y, a.tx - cr.x), def.spd * 0.6, dt, false);
        break;
      }
      case 'snort': {
        if (a.t <= 0) {
          a.mode = 'charge';
          a.t = 1.2;
          a.ang = Math.atan2(p.y - cr.y, p.x - cr.x);
          a.hit = false;
          dust(L, cr.x, cr.y, 5);
        }
        break;
      }
      case 'charge': {
        const nx = cr.x + Math.cos(a.ang) * 120 * dt, ny = cr.y + Math.sin(a.ang) * 120 * dt;
        if (blockedTile(s, tileOf(nx), tileOf(ny))) {
          const wall = Object.values(s.entities.structures).find((q) => q.tx === tileOf(nx) && q.ty === tileOf(ny));
          if (wall) c.dispatch({ type: 'struct_hurt', id: wall.id, amount: 12, src: 'a boar' });
          a.mode = 'stun';
          a.t = 1.6;
          dust(L, cr.x, cr.y, 6, '#c8b090');
          c.sfx('thud');
          break;
        }
        cr.x = nx;
        cr.y = ny;
        if (!a.hit && dP < 12 && hurtPlayer(c, L, def.dmg, def.name, now)) a.hit = true;
        if (a.t <= 0) { a.mode = 'rest'; a.t = 0.6; }
        break;
      }
      case 'stun': if (a.t <= 0) a.mode = 'idle'; break;
      case 'dive': {
        if (a.t <= 0) {
          a.mode = 'swoop';
          a.t = 0.42;
          a.ang = Math.atan2(a.ty - cr.y, a.tx - cr.x);
          a.hit = false;
        }
        break;
      }
      case 'swoop': {
        walkCreature(s, cr, a.ang, 120, dt, true);
        if (!a.hit && dP < 10 && hurtPlayer(c, L, def.dmg, def.name, now)) a.hit = true;
        if (a.t <= 0) { a.mode = 'flit'; a.t = 1.2; }
        break;
      }
      case 'flit': {
        if (a.n-- <= 0) { a.n = 0; }
        if (a.t <= 0 || (a.t % 0.4) < dt) a.ang = nextRand(s) * Math.PI * 2;
        walkCreature(s, cr, a.ang, 46, dt, true);
        if (a.t <= 0) a.mode = 'idle';
        break;
      }
      case 'draw': {
        if (a.t <= 0) {
          a.mode = 'loose';
          a.t = 0.2;
          fire(L, cr.x, cr.y, Math.atan2(p.y - cr.y, p.x - cr.x), 150, 2.2, def.dmg, 'enemy', 'arrow', '#f2ead3');
          c.sfx('loose');
        }
        break;
      }
      case 'loose': if (a.t <= 0) { a.mode = 'reload'; a.t = 1.5; } break;
      case 'reload': {
        if (dP < 48) walkCreature(s, cr, Math.atan2(cr.y - p.y, cr.x - p.x), 26, dt, false);
        if (a.t <= 0) a.mode = 'idle';
        break;
      }
      case 'raise': {
        if (a.t <= 0) { a.mode = 'snap'; a.t = 0.25; a.ang = Math.atan2(p.y - cr.y, p.x - cr.x); a.hit = false; }
        break;
      }
      case 'snap': {
        walkCreature(s, cr, a.ang, 58, dt, false);
        if (!a.hit && dP < 10 && hurtPlayer(c, L, def.dmg, def.name, now)) a.hit = true;
        if (a.t <= 0) { a.mode = 'retreat'; a.t = 0.9; a.ang = Math.atan2(cr.y - p.y, cr.x - p.x); }
        break;
      }
      case 'retreat': {
        walkCreature(s, cr, a.ang, 22, dt, false);
        if (a.t <= 0) a.mode = 'idle';
        break;
      }
      case 'pulse': {
        if (a.t <= 0) {
          a.mode = 'float';
          a.t = 2.5;
          fire(L, cr.x, cr.y, Math.atan2(p.y - cr.y, p.x - cr.x), 56, 3.5, def.dmg, 'enemy', 'orb', '#7ff6e0');
        }
        break;
      }
      case 'float': {
        walkCreature(s, cr, Math.atan2(cr.y - p.y, cr.x - p.x), 12, dt, true);
        if (a.t <= 0) a.mode = 'idle';
        break;
      }
      default:
        a.mode = 'idle';
    }
  }
  // Keep the render-facing AI table from growing without bound.
  const alive = new Set(c.state().actors.creatures.map((q) => q.id));
  for (const k of Object.keys(L.ai)) if (!alive.has(k)) delete L.ai[k];
}

function stepElders(c: SimCtx, L: Live, now: number): void {
  const s = c.state();
  const p = s.actors.player;
  for (const def of ELDERS) {
    const shrine = c.world.pois.find((q) => q.elder === def.id);
    const e = s.actors.elders[def.id];
    if (!shrine || !e || e.defeated) continue;
    const sx = shrine.x * TILE + 8, sy = shrine.y * TILE + 8;
    const engaged = Math.hypot(p.x - sx, p.y - sy) < 12 * TILE;
    if (!engaged) continue;
    const pats = e.awakened ? def.awakened : def.latent;
    let nx = L.elderNext[def.id];
    if (!nx) {
      nx = pats.map((_, i) => L.t + 1.4 + i * 0.7);
      L.elderNext[def.id] = nx;
    }
    for (let i = 0; i < pats.length; i++) {
      if (L.t < nx[i]) continue;
      nx[i] = L.t + pats[i].every * (0.9 + Math.random() * 0.2);
      runPattern(c, L, def.palette, pats[i], sx, sy, now);
    }
  }
}

function runPattern(c: SimCtx, L: Live, pal: [string, string, string], pat: { k: string; n?: number; dmg?: number; what?: string }, sx: number, sy: number, now: number): void {
  const s = c.state();
  const p = s.actors.player;
  const a0 = Math.atan2(p.y - sy, p.x - sx);
  const dmg = pat.dmg ?? 6;
  switch (pat.k) {
    case 'ring': {
      const n = pat.n ?? 10;
      const phase = Math.random() * 0.4;
      for (let i = 0; i < n; i++) fire(L, sx, sy, (i / n) * Math.PI * 2 + phase, 64, 4, dmg, 'enemy', 'orb', pal[0]);
      for (let i = 0; i < 16; i++) fx(L, 'ring', sx, sy, Math.cos(i / 16 * 6.28) * 14, Math.sin(i / 16 * 6.28) * 14, 0.5, pal[1], 1);
      c.sfx('bolt');
      break;
    }
    case 'fan': {
      const n = pat.n ?? 3;
      for (let i = 0; i < n; i++) fire(L, sx, sy, a0 + (i - (n - 1) / 2) * 0.28, 92, 3.2, dmg, 'enemy', 'orb', pal[0]);
      c.sfx('bolt');
      break;
    }
    case 'lanes': {
      const n = pat.n ?? 3;
      for (let i = 0; i < n; i++) {
        const a = a0 + (i - (n - 1) / 2) * 0.55;
        L.haz.push({ k: 'lane', x: sx, y: sy, x2: sx + Math.cos(a) * 150, y2: sy + Math.sin(a) * 150, r: 0, w: 8, warn: 1.0, life: 0.45, dmg, tick: 0, ang: a, spd: 0, done: false, col: pal[0] });
      }
      c.sfx('warn');
      break;
    }
    case 'slam': {
      L.haz.push({ k: 'ring', x: sx, y: sy, x2: 0, y2: 0, r: 0, w: 0, warn: 1.0, life: 0.2, dmg, tick: 0, ang: 0, spd: 0, done: false, col: pal[0] });
      c.sfx('warn');
      break;
    }
    case 'summon': {
      const n = pat.n ?? 1;
      for (let i = 0; i < n; i++) c.dispatch({ type: 'summon', kind: pat.what ?? 'slime', x: sx + Math.cos(i * 2.1) * 44, y: sy + Math.sin(i * 2.1) * 44 });
      break;
    }
    case 'puddle': {
      const n = pat.n ?? 2;
      for (let i = 0; i < n; i++) {
        const ax = p.x + (Math.random() - 0.5) * 60, ay = p.y + (Math.random() - 0.5) * 60;
        L.haz.push({ k: 'puddle', x: ax, y: ay, x2: 0, y2: 0, r: 14, w: 0, warn: 1.2, life: 4, dmg, tick: 0, ang: 0, spd: 0, done: false, col: pal[1] });
      }
      break;
    }
    case 'roots': {
      L.haz.push({ k: 'root', x: p.x, y: p.y, x2: 0, y2: 0, r: 10, w: 0, warn: 0.8, life: 1.2, dmg, tick: 0, ang: 0, spd: 0, done: false, col: pal[1] });
      c.sfx('warn');
      break;
    }
    case 'sweep': {
      L.haz.push({ k: 'beam', x: sx, y: sy, x2: 0, y2: 0, r: 130, w: 8, warn: 0.6, life: 2.4, dmg, tick: 0, ang: a0 - 1.2, spd: 1.05, done: false, col: pal[0] });
      break;
    }
    case 'dash': {
      L.haz.push({ k: 'dash', x: sx, y: sy, x2: sx + Math.cos(a0) * 120, y2: sy + Math.sin(a0) * 120, r: 0, w: 10, warn: 0.8, life: 0.35, dmg, tick: 0, ang: a0, spd: 0, done: false, col: pal[0] });
      c.sfx('warn');
      break;
    }
    default:
      break;
  }
  void now;
}

function segDist(px: number, py: number, x1: number, y1: number, x2: number, y2: number): number {
  const vx = x2 - x1, vy = y2 - y1;
  const t = Math.max(0, Math.min(1, ((px - x1) * vx + (py - y1) * vy) / (vx * vx + vy * vy || 1)));
  return Math.hypot(px - (x1 + vx * t), py - (y1 + vy * t));
}

function stepHaz(c: SimCtx, L: Live, dt: number, now: number): void {
  const s = c.state();
  const p = s.actors.player;
  for (const h of L.haz) {
    if (h.warn > 0) {
      h.warn -= dt;
      if (h.k === 'ring') h.r = 56 * (1 - Math.max(0, h.warn));
      continue;
    }
    h.life -= dt;
    if (h.k === 'puddle') {
      h.tick -= dt;
      if (h.tick <= 0 && Math.hypot(p.x - h.x, p.y - h.y) < h.r) {
        hurtPlayer(c, L, h.dmg, 'a bog pool', now, 4);
        h.tick = 0.6;
      }
    } else if (h.k === 'lane' || h.k === 'dash') {
      if (!h.done && segDist(p.x, p.y, h.x, h.y, h.x2, h.y2) < h.w) {
        hurtPlayer(c, L, h.dmg, 'an Elder lane', now);
      }
      h.done = true;
    } else if (h.k === 'root') {
      if (!h.done && Math.hypot(p.x - h.x, p.y - h.y) < h.r) {
        hurtPlayer(c, L, h.dmg, 'roots', now);
        L.slow = 1.2;
      }
      h.done = true;
    } else if (h.k === 'beam') {
      h.ang += h.spd * dt;
      h.tick -= dt;
      const ex = h.x + Math.cos(h.ang) * h.r, ey = h.y + Math.sin(h.ang) * h.r;
      if (h.tick <= 0 && segDist(p.x, p.y, h.x, h.y, ex, ey) < h.w && Math.hypot(p.x - h.x, p.y - h.y) < h.r) {
        hurtPlayer(c, L, h.dmg, 'the tide beam', now);
        h.tick = 0.7;
      }
    } else if (h.k === 'ring') {
      if (!h.done) {
        h.done = true;
        if (Math.hypot(p.x - h.x, p.y - h.y) < 56) hurtPlayer(c, L, h.dmg, 'a slam', now);
        for (let i = 0; i < 6; i++) fire(L, h.x, h.y, (i / 6) * Math.PI * 2, 70, 2.4, 5, 'enemy', 'shard', h.col);
        dust(L, h.x, h.y, 10, '#b8b0a0');
        L.shake = 4;
      }
    }
  }
  L.haz = L.haz.filter((h) => h.life > 0);
}

/** Advances the realtime world by dt (seconds). Economic results arrive through c.dispatch. */
export function simStep(c: SimCtx, L: Live, dt0: number, inp: SimInput, now: number): void {
  const dt = Math.min(dt0, 0.05);
  L.t += dt;
  L.iframes = Math.max(0, L.iframes - dt);
  L.flash = Math.max(0, L.flash - dt * 4);
  L.shake = Math.max(0, L.shake - dt * 8);
  L.cd.spin -= dt; L.cd.cast -= dt; L.cd.shot -= dt; L.pickCd -= dt; L.discCd -= dt; L.trailCd -= dt; L.noteCd -= dt; L.stepSnd -= dt;
  L.slow = Math.max(0, L.slow - dt);
  stepFx(L, dt);
  if (L.hitstop > 0) {
    L.hitstop -= dt;
    return;
  }
  let s = c.state();
  if (s.run.status !== 'active' || s.actors.player.hp <= 0) return;
  const w = c.world;
  const ml0 = Math.hypot((inp.right ? 1 : 0) - (inp.left ? 1 : 0), (inp.down ? 1 : 0) - (inp.up ? 1 : 0));
  L.aim = Math.atan2(inp.ay - s.actors.player.y, inp.ax - s.actors.player.x);
  let mx = (inp.right ? 1 : 0) - (inp.left ? 1 : 0), my = (inp.down ? 1 : 0) - (inp.up ? 1 : 0);
  if (ml0 > 0) { mx /= ml0; my /= ml0; }
  L.moving = ml0 > 0;
  if (ml0 > 0) L.facing = Math.abs(mx) > Math.abs(my) ? (mx > 0 ? 3 : 2) : my > 0 ? 0 : 1;
  if (L.atk.phase === 'idle') {
    if (inp.roll && L.roll.t <= 0 && s.actors.player.stamina >= BAL.player.rollStamina) {
      s.actors.player.stamina -= BAL.player.rollStamina;
      L.roll.t = BAL.combat.rollSec;
      L.roll.dx = ml0 > 0 ? mx : Math.cos(L.aim);
      L.roll.dy = ml0 > 0 ? my : Math.sin(L.aim);
      L.iframes = Math.max(L.iframes, BAL.combat.rollSec);
      c.sfx('roll');
    }
    startAttack(c, L, inp, now);
  }
  if (L.atk.phase !== 'idle') {
    const A = L.atk;
    A.time += dt;
    if (A.phase === 'windup' && A.time >= A.dur[0]) { A.phase = 'contact'; A.time = 0; contact(c, L, now); }
    else if (A.phase === 'contact' && A.time >= A.dur[1]) { A.phase = 'recover'; A.time = 0; }
    else if (A.phase === 'recover' && A.time >= A.dur[2]) { A.phase = 'idle'; A.kind = 'none'; }
  }
  if (L.atk.kind === 'swing' && L.atk.phase === 'windup') L.facing = dirFromAim(L.aim);
  // Movement.
  s = c.state();
  const p = s.actors.player;
  if (L.roll.t > 0) L.roll.t -= dt;
  let speed = 62;
  const sprinting = inp.sprint && ml0 > 0 && p.stamina > 0 && L.atk.phase === 'idle' && L.roll.t <= 0;
  if (sprinting) {
    speed *= 1.5;
    p.stamina = Math.max(0, p.stamina - BAL.player.sprintStaminaPerSec * dt);
  } else if (L.regen > 0) {
    L.regen -= dt;
  } else {
    p.stamina = Math.min(100, p.stamina + 24 * dt);
  }
  const tk = tkey(tileOf(p.x), tileOf(p.y));
  const terr = terrainSpeed(w.terrain[tk]);
  if (p.hitched) {
    const cart = Object.values(s.entities.structures).find((q) => q.id === p.hitched);
    const cw = cart ? cargoWeight(cart) : 0;
    speed *= 0.86 * Math.max(0.55, 1 - cw / 180);
    if (terr < 1) speed *= 0.8;
  }
  if (L.atk.phase !== 'idle') speed *= 0.55;
  if (L.slow > 0) speed *= 0.35;
  let dx = mx, dy = my, sp = speed * terr;
  if (L.roll.t > 0) {
    dx = L.roll.dx;
    dy = L.roll.dy;
    sp = 150 * terr;
  }
  boxMove(s, p, dx * sp * dt, dy * sp * dt);
  if (ml0 > 0) L.walk += dt * (sprinting ? 9 : 6);
  // Footprints: real movement on a real surface (C08).
  const moved = Math.hypot(p.x - L.stepX, p.y - L.stepY);
  if (moved >= 12 && L.trailCd <= 0) {
    L.stepX = p.x;
    L.stepY = p.y;
    L.trailCd = 0.25;
    const surf = surfaceKind(w.terrain[tk]);
    c.dispatch({ type: 'trail', x: p.x, y: p.y, kind: surf, now });
    if (L.stepSnd <= 0) { c.sfx('step:' + surf); L.stepSnd = 0.3; }
  }
  stepCreatures(c, L, dt, now);
  stepProj(c, L, dt, now);
  stepElders(c, L, now);
  stepHaz(c, L, dt, now);
  // Post-step state (dispatches above may have replaced it).
  s = c.state();
  const pp = s.actors.player;
  if (L.pickCd <= 0) {
    L.pickCd = 0.2;
    const near = s.custody.ground.filter((g) => Math.hypot(g.x - pp.x, g.y - pp.y) < 18);
    for (const g of near.slice(0, 3)) {
      const r = c.dispatch({ type: 'pickup', uid: g.uid });
      if (r.ok) {
        c.sfx('pickup');
        fx(L, 'pop', g.x, g.y, 0, -14, 0.4, '#fff1a6', 1);
      } else if (r.reason.includes('full')) note(c, L, r.reason);
    }
  }
  if (L.discCd <= 0) {
    L.discCd = 0.6;
    const ttx = tileOf(pp.x), tty = tileOf(pp.y);
    if (!discovered(s, ttx, tty)) c.dispatch({ type: 'discover', tx: ttx, ty: tty });
    const region = REGIONS[regionAt(w, ttx, tty)];
    if (region !== L.lastRegion) {
      L.lastRegion = region;
      note(c, L, `Entering ${region}.`);
    }
  }
  // Camera follows the player with a soft lag; shake is applied at draw time.
  L.cam.x += (pp.x - L.cam.x) * Math.min(1, dt * 9);
  L.cam.y += (pp.y - L.cam.y) * Math.min(1, dt * 9);
  if (L.cam.x === 0 && L.cam.y === 0) { L.cam.x = pp.x; L.cam.y = pp.y; }
  // Projectile and creature queries above keep stale references out of this frame.
  void MAP_H; void MAP_W; void NODES; void nextRand;
}

function dirFromAim(a: number): number {
  return Math.abs(Math.cos(a)) > Math.abs(Math.sin(a)) ? (Math.cos(a) > 0 ? 3 : 2) : Math.sin(a) > 0 ? 0 : 1;
}

export { sparks, dust, fx as pushFx, number as pushNumber, burst as pushBurst };
