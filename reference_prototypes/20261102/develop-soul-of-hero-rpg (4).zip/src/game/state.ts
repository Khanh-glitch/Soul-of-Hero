// Authoritative game state (K1 custody, K2 environment, K3 sources, K4 knowledge/work, K5 actors,
// K6 structures/POIs, K7 freight, K8 clock/run/profile) and the single intent dispatcher.
// Every economic change is validated first and committed on a structured clone: a rejection leaves no partial debit.
import { ITEMS, RECIPES, STRUCTS, NODES, CREATURES, ELDERS, CHESTS, ACH, RUN_STOCK, BAL, Recipe } from './data/catalog';
import { MAP_W, MAP_H, TILE, WORLD_SEED, tkey, nextRand, randInt, hash2 } from './core/rng';
import { getWorld, T, O, OBJ_BLOCK, OBJ_NODE, terrainBlocks, regionAt, REGIONS } from './world/world';

export const RUN_MS = BAL.run.maxHours * 3600000;
export const RAGNAROK_MS = (BAL.run.maxHours - BAL.run.ragnarokHours) * 3600000;
export const DISC_CELLS = 24 * 24;
const FURN_RECIPES: Recipe[] = RECIPES.filter((r) => r.st === 'furn');
const FURN_INPUTS = new Set<string>(FURN_RECIPES.map((r) => r.inp[0][0]));

export type Gender = 'male' | 'female';
export type EqSlot = 'weapon' | 'armor' | 'pack';
export interface Slot { uid: string; item: string; qty: number; dur?: number; charges?: number }
export type Maybe = Slot | null;
export interface RunRecord { id: number; outcome: string; startMs: number; endMs: number; score: number; stones: number; ach: string[]; spawn: string; gender: Gender; deposited: number }
export interface Profile { v: 1; secured: number; ach: Record<string, { runId: number; at: number }>; history: RunRecord[]; deposits: string[]; purchases: string[]; runs: number }
export interface RunInfo { id: number; status: 'active' | 'ended'; outcome: string | null; startMs: number; endMs: number | null; spawn: string; gender: Gender; score: number; stones: number; deposited: number }
export interface Player { x: number; y: number; hp: number; maxHp: number; stamina: number; hunger: number; warmth: number; toxin: number; rx: number; ry: number; deaths: number; hitched: string | null }
export interface Creature { id: string; kind: string; x: number; y: number; hp: number; hx: number; hy: number; st: string; ang: number }
export interface ElderState { hp: number; maxHp: number; awakened: boolean; defeated: boolean }
export interface Ground { uid: string; item: string; qty: number; x: number; y: number; dur?: number; charges?: number }
export interface Bag { id: string; x: number; y: number; slots: Slot[] }
export interface Structure {
  id: string; kind: string; tx: number; ty: number; hp: number; claim?: string; open?: boolean; hitched?: boolean; hx?: number; hy?: number;
  slots?: Maybe[]; fuel?: Maybe; input?: Maybe; output?: Maybe; job?: { recipe: string; progress: number; need: number } | null; burn?: number;
  plant?: { growth: number; ready: boolean } | null;
}
export interface Footprint { x: number; y: number; t: number; kind: string; life: number }
export interface Src { hp: number; gone?: boolean; regrowAt?: number }
export interface Mod { burnt?: number; puddle?: number; open?: number }
export interface Claim { id: string; tx: number; ty: number; r: number }
export interface Job { id: string; recipe: string; desk: string; progress: number; need: number }
export interface Receipt { id: string; t: number; kind: string; msg: string }

export interface GameState {
  v: 1; rev: number; seq: number; rng: number;
  profile: Profile;
  run: RunInfo;
  clock: { startMs: number; qaOffsetMs: number; settledMs: number };
  world: { mods: Record<string, Mod>; claims: Claim[]; trails: Footprint[]; discovered: string; wx: string };
  actors: { player: Player; creatures: Creature[]; elders: Record<string, ElderState>; nextSpawnMs: number };
  sources: Record<string, Src>;
  entities: { structures: Record<string, Structure> };
  custody: { inv: Maybe[]; equip: Record<EqSlot, Maybe>; ground: Ground[]; bags: Bag[] };
  knowledge: { learned: string[] };
  jobs: Record<string, Job>;
  receipts: Receipt[];
  reqs: string[];
  ach: string[];
  ledger: { minted: Record<string, number>; spent: Record<string, number> };
  stats: { kills: number; harvests: number; crafts: number; cartTrips: number; builds: number };
}

export type Loc =
  | { k: 'inv'; i: number }
  | { k: 'eq'; slot: EqSlot }
  | { k: 'st'; id: string; slot: 'slots' | 'fuel' | 'input' | 'output'; i?: number }
  | { k: 'bag'; id: string; i: number };

export type Intent =
  | { type: 'new_run'; spawn: string; gender: Gender; now: number }
  | { type: 'tick'; now: number }
  | { type: 'qa_offset'; ms: number }
  | { type: 'move'; from: Loc; to: Loc; count?: number }
  | { type: 'drop'; i: number }
  | { type: 'pickup'; uid: string }
  | { type: 'sort' }
  | { type: 'eat'; i: number }
  | { type: 'equip'; i: number }
  | { type: 'unequip'; slot: EqSlot }
  | { type: 'craft'; recipe: string }
  | { type: 'study'; desk: string; recipe: string; now: number }
  | { type: 'build'; kind: string; tx: number; ty: number; now: number }
  | { type: 'reclaim'; id: string }
  | { type: 'door'; id: string }
  | { type: 'sleep'; id: string; now: number }
  | { type: 'plant'; id: string; i: number; now: number }
  | { type: 'crop'; id: string; now: number }
  | { type: 'hitch'; id: string }
  | { type: 'release'; id: string; now: number }
  | { type: 'harvest'; key: number; tool: 'eq' | number; now: number }
  | { type: 'creature_dead'; id: string; now: number }
  | { type: 'hurt'; amount: number; src: string; now: number; toxin?: number }
  | { type: 'struct_hurt'; id: string; amount: number; src: string }
  | { type: 'cast'; tx: number; ty: number; now: number }
  | { type: 'shoot'; now: number }
  | { type: 'summon'; kind: string; x: number; y: number }
  | { type: 'elder_hit'; id: string; dmg: number; now: number }
  | { type: 'chest'; poi: string; now: number }
  | { type: 'bag_loot'; id: string }
  | { type: 'trail'; x: number; y: number; kind: string; now: number }
  | { type: 'discover'; tx: number; ty: number }
  | { type: 'deposit'; id: string; now: number }
  | { type: 'vendor_buy_escrow' }
  | { type: 'vendor_buy_run'; item: string; req: string }
  | { type: 'evacuate'; now: number }
  | { type: 'abandon'; now: number }
  | { type: 'expire'; now: number };

export interface Commit { ok: true; state: GameState; msg: string; profileChanged: boolean }
export interface Reject { ok: false; reason: string }
export type Result = Commit | Reject;

class Rej extends Error {}
function rej(m: string): never {
  throw new Rej(m);
}

// ---------------------------------------------------------------- construction
export function emptyInv(): Maybe[] {
  return new Array<Maybe>(32).fill(null);
}

export function emptyState(profile: Profile): GameState {
  return {
    v: 1, rev: 0, seq: 1, rng: WORLD_SEED,
    profile,
    run: { id: 0, status: 'ended', outcome: 'none', startMs: 0, endMs: 0, spawn: 'pinewood', gender: 'male', score: 0, stones: 0, deposited: 0 },
    clock: { startMs: 0, qaOffsetMs: 0, settledMs: 0 },
    world: { mods: {}, claims: [], trails: [], discovered: '0'.repeat(DISC_CELLS), wx: 'clear' },
    actors: {
      player: { x: 0, y: 0, hp: 100, maxHp: 100, stamina: 100, hunger: 100, warmth: 100, toxin: 0, rx: 0, ry: 0, deaths: 0, hitched: null },
      creatures: [], elders: {}, nextSpawnMs: 0
    },
    sources: {}, entities: { structures: {} },
    custody: { inv: emptyInv(), equip: { weapon: null, armor: null, pack: null }, ground: [], bags: [] },
    knowledge: { learned: [] }, jobs: {}, receipts: [], reqs: [], ach: [],
    ledger: { minted: {}, spent: {} },
    stats: { kills: 0, harvests: 0, crafts: 0, cartTrips: 0, builds: 0 }
  };
}

export function freshProfile(): Profile {
  return { v: 1, secured: 0, ach: {}, history: [], deposits: [], purchases: [], runs: 0 };
}

function startRun(prev: GameState, now: number, spawn: string, gender: Gender): GameState {
  const w = getWorld();
  const sp = w.spawns[spawn] ?? w.spawns.pinewood;
  const runId = prev.profile.runs;
  const s = emptyState(prev.profile);
  s.rev = prev.rev; s.seq = prev.seq + 1; s.receipts = prev.receipts; s.reqs = prev.reqs;
  s.rng = (WORLD_SEED ^ Math.imul(runId, 2654435761)) >>> 0;
  s.clock = { startMs: now, qaOffsetMs: prev.clock.qaOffsetMs, settledMs: now };
  s.run = { id: runId, status: 'active', outcome: null, startMs: now, endMs: null, spawn, gender, score: 0, stones: 0, deposited: 0 };
  s.actors.player = { ...s.actors.player, x: sp.x * TILE + 8, y: sp.y * TILE + 8, rx: sp.x * TILE + 8, ry: sp.y * TILE + 8 };
  s.actors.nextSpawnMs = now + BAL.creatures.safeStartSeconds * 1000;
  for (const e of ELDERS) s.actors.elders[e.id] = { hp: e.hp, maxHp: e.hp, awakened: false, defeated: false };
  s.world.discovered = discoverCell(s.world.discovered, sp.x, sp.y);
  s.world.wx = weatherAt(s, now);
  for (const [item, qty] of [['knife_stone', 1], ['fiber', 3], ['stone', 2], ['wood', 2], ['berry', 2]] as const) {
    const left = addInv(s, item, qty);
    mint(s, item, qty - left);
    if (left) dropGround(s, item, left, sp.x * TILE + 8, sp.y * TILE + 8);
  }
  const k = s.custody.inv.findIndex((x) => x && x.item === 'knife_stone');
  if (k >= 0) s.custody.equip.weapon = s.custody.inv[k], s.custody.inv[k] = null;
  return s;
}

// ---------------------------------------------------------------- small helpers
const uid = (s: GameState): string => 'u' + ++s.seq;
export const tileOf = (v: number): number => Math.floor(v / TILE);
const dpx = (ax: number, ay: number, bx: number, by: number): number => Math.hypot(ax - bx, ay - by);
const near = (s: GameState, tx: number, ty: number, tiles: number): boolean => {
  const p = s.actors.player;
  return dpx(p.x, p.y, tx * TILE + 8, ty * TILE + 8) <= tiles * TILE;
};
export function invCap(s: GameState): number {
  return 24 + (s.custody.equip.pack ? ITEMS.backpack.slots ?? 0 : 0);
}
function discoverCell(disc: string, tx: number, ty: number): string {
  const c = (ty >> 3) * 24 + (tx >> 3);
  if (disc[c] === '1') return disc;
  return disc.slice(0, c) + '1' + disc.slice(c + 1);
}
function mint(s: GameState, item: string, qty: number): void {
  if (qty > 0) s.ledger.minted[item] = (s.ledger.minted[item] ?? 0) + qty;
}
function spend(s: GameState, item: string, qty: number): void {
  if (qty > 0) s.ledger.spent[item] = (s.ledger.spent[item] ?? 0) + qty;
}
function mkSlot(s: GameState, item: string, qty: number): Slot {
  const d = ITEMS[item];
  const sl: Slot = { uid: uid(s), item, qty };
  if (d.dur !== undefined) sl.dur = d.dur;
  if (d.charges !== undefined) sl.charges = d.charges;
  return sl;
}
const stackable = (a: Slot): boolean => ITEMS[a.item].stack > 1 && a.dur === undefined && a.charges === undefined;

/** Adds to the first usable inventory slots; returns the leftover quantity (no ledger change). */
function addInv(s: GameState, item: string, qty: number): number {
  const d = ITEMS[item];
  let left = qty;
  const cap = invCap(s);
  const inv = s.custody.inv;
  if (d.stack > 1) {
    for (let i = 0; i < cap && left > 0; i++) {
      const sl = inv[i];
      if (sl && sl.item === item && stackable(sl)) {
        const add = Math.min(d.stack - sl.qty, left);
        sl.qty += add;
        left -= add;
      }
    }
  }
  for (let i = 0; i < cap && left > 0; i++) {
    if (!inv[i]) {
      const add = Math.min(d.stack, left);
      inv[i] = mkSlot(s, item, add);
      left -= add;
    }
  }
  return left;
}
function spaceFor(s: GameState, item: string): number {
  const d = ITEMS[item];
  let n = 0;
  const cap = invCap(s);
  for (let i = 0; i < cap; i++) {
    const sl = s.custody.inv[i];
    if (!sl) n += d.stack;
    else if (sl.item === item && stackable(sl)) n += d.stack - sl.qty;
  }
  return n;
}
export function countInv(s: GameState, item: string): number {
  return s.custody.inv.reduce((a, sl) => a + (sl && sl.item === item ? sl.qty : 0), 0);
}
function takeInv(s: GameState, item: string, qty: number): void {
  let left = qty;
  for (let i = 0; i < s.custody.inv.length && left > 0; i++) {
    const sl = s.custody.inv[i];
    if (!sl || sl.item !== item) continue;
    const take = Math.min(sl.qty, left);
    sl.qty -= take;
    left -= take;
    if (sl.qty <= 0) s.custody.inv[i] = null;
  }
  spend(s, item, qty - left);
}
function placeGround(s: GameState, item: string, qty: number, x: number, y: number, inst?: Slot): void {
  const d = ITEMS[item];
  if (inst) {
    s.custody.ground.push({ uid: inst.uid, item, qty: inst.qty, x, y, dur: inst.dur, charges: inst.charges });
    return;
  }
  let left = qty;
  while (left > 0) {
    const q = Math.min(d.stack, left);
    s.custody.ground.push({ uid: uid(s), item, qty: q, x: x + (nextRand(s) - 0.5) * 10, y: y + (nextRand(s) - 0.5) * 10 });
    left -= q;
  }
}
function dropGround(s: GameState, item: string, qty: number, x: number, y: number): void {
  placeGround(s, item, qty, x, y);
}
function mintGround(s: GameState, item: string, qty: number, x: number, y: number): void {
  mint(s, item, qty);
  placeGround(s, item, qty, x, y);
}
function achieve(s: GameState, id: string, msgs: string[]): void {
  const a = ACH[id];
  if (!a || s.ach.includes(id)) return;
  s.ach.push(id);
  s.run.score += a.pts;
  if (!s.profile.ach[id]) s.profile.ach[id] = { runId: s.run.id, at: s.clock.settledMs };
  msgs.push(`Achievement: ${a.name} (+${a.pts} local)`);
}

// ---------------------------------------------------------------- world queries (K2/K6)
const idxCache = new WeakMap<GameState, Map<number, Structure[]>>();
export function structIndex(s: GameState): Map<number, Structure[]> {
  let m = idxCache.get(s);
  if (m) return m;
  m = new Map();
  for (const st of Object.values(s.entities.structures)) {
    const k = tkey(st.tx, st.ty);
    const arr = m.get(k);
    if (arr) arr.push(st);
    else m.set(k, [st]);
  }
  idxCache.set(s, m);
  return m;
}
export function structsAt(s: GameState, tx: number, ty: number): Structure[] {
  return structIndex(s).get(tkey(tx, ty)) ?? [];
}
/** Effective base object at a tile after harvests, doors and decor rules. */
export function effObj(s: GameState, k: number): number {
  const w = getWorld();
  const o = w.obj[k];
  if (!o) return 0;
  if (OBJ_NODE[o]) {
    const src = s.sources[k];
    if (src && (src.gone || src.hp <= 0)) return 0;
  }
  if (o === O.DOOR && s.world.mods[k]?.open) return 0;
  return o;
}
export function blockedTile(s: GameState, tx: number, ty: number): boolean {
  if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return true;
  const w = getWorld();
  const k = tkey(tx, ty);
  if (terrainBlocks(w.terrain[k])) return true;
  if (OBJ_BLOCK.has(effObj(s, k))) return true;
  for (const st of structsAt(s, tx, ty)) {
    const d = STRUCTS[st.kind];
    if (!d.block) continue;
    if (st.kind === 'door' && st.open) continue;
    if (st.kind === 'cart' && st.hitched) continue;
    return true;
  }
  return false;
}
export function claimAt(s: GameState, tx: number, ty: number): string | null {
  for (const c of s.world.claims) if ((tx - c.tx) ** 2 + (ty - c.ty) ** 2 <= c.r * c.r) return c.id;
  return null;
}
export function isRoofed(s: GameState, tx: number, ty: number): boolean {
  return structsAt(s, tx, ty).some((st) => st.kind === 'roof');
}
function litNear(s: GameState, tx: number, ty: number): boolean {
  for (const st of Object.values(s.entities.structures)) {
    if (st.kind === 'torch_post' || (st.kind === 'furnace' && (st.burn ?? 0) > 0)) {
      if ((st.tx - tx) ** 2 + (st.ty - ty) ** 2 <= 9) return true;
    }
  }
  return false;
}
export function cashCount(s: GameState): number {
  return countInv(s, 'ragnarok_cash');
}
export function discovered(s: GameState, tx: number, ty: number): boolean {
  return s.world.discovered[(ty >> 3) * 24 + (tx >> 3)] === '1';
}
export function regionCount(s: GameState): number {
  const w = getWorld();
  const seen = new Set<number>();
  for (let c = 0; c < DISC_CELLS; c++) if (s.world.discovered[c] === '1') seen.add(regionAt(w, (c % 24) * 8 + 4, Math.floor(c / 24) * 8 + 4));
  return seen.size;
}

// ---------------------------------------------------------------- time (K8)
const WX_ORDER = ['clear', 'cloudy', 'rain', 'storm', 'fog'] as const;
export function weatherAt(s: GameState, ms: number): string {
  const cellMs = BAL.weather.cellMinutes * 60000;
  const cell = Math.floor((ms - s.clock.startMs) / cellMs);
  const r = hash2(cell, s.run.id, 4242);
  const wts = BAL.weather.weights as Record<string, number>;
  const total = WX_ORDER.reduce((a, k) => a + wts[k], 0);
  let acc = 0;
  for (const k of WX_ORDER) {
    acc += wts[k] / total;
    if (r < acc) return k;
  }
  return 'clear';
}
export function phaseInfo(s: GameState, now: number): { hours: number; day: number; phase: string; clockH: number; light: number; leftMs: number; ragnarok: boolean; danger: boolean; awaken: boolean } {
  const el = Math.max(0, now - s.run.startMs);
  const hours = el / 3600000;
  const dayMs = BAL.clock.fictionalDayRealMinutes * 60000;
  const ph = ((((now - s.clock.startMs) % dayMs) + dayMs) % dayMs) / dayMs;
  const day = Math.floor(hours / 24) + 1;
  const phase = day >= BAL.run.elderAwakenDay ? 'Awakening' : day >= BAL.run.dangerFromDay ? (day > BAL.run.dangerToDay ? 'Ragnarok' : 'Danger') : hours >= BAL.run.maxHours - BAL.run.ragnarokHours ? 'Ragnarok' : 'Early';
  return {
    hours, day, phase, clockH: (ph * 24 + 12) % 24, light: 0.5 + 0.5 * Math.cos(ph * Math.PI * 2),
    leftMs: Math.max(0, RUN_MS - el),
    ragnarok: hours >= BAL.run.maxHours - BAL.run.ragnarokHours,
    danger: day >= BAL.run.dangerFromDay && day <= BAL.run.dangerToDay,
    awaken: hours >= (BAL.run.elderAwakenDay - 1) * 24
  };
}

// ---------------------------------------------------------------- simulation of settled time (K5 vitals, K4 jobs, K1 fuel)
function stepVitals(s: GameState, sec: number): void {
  const p = s.actors.player;
  const w = getWorld();
  const tx = tileOf(p.x), ty = tileOf(p.y);
  const t = w.terrain[tkey(tx, ty)] ?? T.GRASS;
  const roof = isRoofed(s, tx, ty);
  const cold = t === T.SNOW || t === T.TUNDRA;
  const warm = roof || litNear(s, tx, ty);
  p.hunger = Math.max(0, p.hunger - sec * BAL.player.hungerDrainPerSec);
  if (p.hunger <= 0) {
    const dmg = sec * 0.45;
    p.hp = roof ? Math.max(1, p.hp - dmg) : p.hp - dmg; // shelter prevents hunger death (min 1 HP)
  }
  p.warmth = Math.min(100, Math.max(0, p.warmth - sec * (cold ? BAL.player.warmthDrainColdPerSec : 0.01) + sec * (warm ? 0.12 : 0.03)));
  if (p.warmth <= 0) p.hp -= sec * 0.3;
  if (t === T.SLAG) p.toxin += sec * 1.5;
  p.toxin = Math.max(0, p.toxin - sec * BAL.player.toxinDecayPerSec);
  if (p.toxin > 50) p.hp -= sec * 0.25;
  if (p.hunger > 40 && p.warmth > 30 && p.toxin < 15 && p.hp < p.maxHp && p.hp > 0) p.hp = Math.min(p.maxHp, p.hp + sec * 0.35);
}

function loadFuel(s: GameState, st: Structure): boolean {
  const f = st.fuel;
  if (!f) return false;
  const d = ITEMS[f.item];
  if (!d.fuel) return false;
  st.burn = (st.burn ?? 0) + d.fuel;
  spend(s, f.item, 1);
  f.qty -= 1;
  if (f.qty <= 0) st.fuel = null;
  return true;
}

function placeOutput(s: GameState, st: Structure, item: string, qty: number): boolean {
  const o = st.output;
  if (!o) {
    st.output = mkSlot(s, item, qty);
    return true;
  }
  if (o.item === item && ITEMS[item].stack - o.qty >= qty) {
    o.qty += qty;
    return true;
  }
  return false;
}

function runFurnace(s: GameState, st: Structure, sec: number, msgs: string[]): void {
  let rem = sec;
  for (let guard = 0; guard < 4000 && rem > 1e-9; guard++) {
    if (!st.job) {
      const inp = st.input;
      const rec = inp ? FURN_RECIPES.find((r) => r.inp[0][0] === inp.item) : undefined;
      if (!inp || !rec || inp.qty < rec.inp[0][1]) break;
      inp.qty -= rec.inp[0][1];
      spend(s, inp.item, rec.inp[0][1]);
      if (inp.qty <= 0) st.input = null;
      st.job = { recipe: rec.id, progress: 0, need: rec.secs ?? 8 };
    }
    if ((st.burn ?? 0) <= 1e-9 && !loadFuel(s, st)) break;
    const job = st.job;
    if (!job) break;
    const step = Math.min(rem, st.burn ?? 0, job.need - job.progress);
    job.progress += step;
    st.burn = (st.burn ?? 0) - step;
    rem -= step;
    if (job.progress >= job.need - 1e-9) {
      const rec = FURN_RECIPES.find((r) => r.id === job.recipe);
      if (!rec) { st.job = null; continue; }
      if (!placeOutput(s, st, rec.out[0], rec.out[1])) { job.progress = job.need; break; } // output blocked: waits physically
      mint(s, rec.out[0], rec.out[1]);
      msgs.push(`Furnace: ${ITEMS[rec.out[0]].name} x${rec.out[1]} ready`);
      st.job = null;
    }
  }
}

function stepWorkers(s: GameState, sec: number, wx: string, msgs: string[]): void {
  for (const st of Object.values(s.entities.structures)) {
    if (st.kind === 'furnace') runFurnace(s, st, sec, msgs);
    if (st.kind === 'garden' && st.plant && !st.plant.ready) {
      const mult = wx === 'rain' || wx === 'storm' ? BAL.crops.rainMultiplier : 1;
      st.plant.growth += (sec / BAL.crops.growSeconds) * mult;
      if (st.plant.growth >= 1) {
        st.plant.growth = 1;
        st.plant.ready = true;
        msgs.push('Turnips are ready at a garden plot.');
      }
    }
  }
  for (const j of Object.values(s.jobs)) {
    j.progress += sec;
    if (j.progress >= j.need) {
      delete s.jobs[j.id];
      if (!s.knowledge.learned.includes(j.recipe)) s.knowledge.learned.push(j.recipe);
      msgs.push(`Study complete: ${RECIPES.find((r) => r.id === j.recipe)?.name ?? j.recipe} learned for this run.`);
    }
  }
}

/** Chronological settlement from settledMs to toMs in segments aligned with weather cells. */
function advance(s: GameState, toMs: number, msgs: string[]): void {
  const start = s.clock.startMs;
  const end = Math.min(toMs, start + RUN_MS);
  let t = s.clock.settledMs;
  if (end <= t) return;
  const cellMs = BAL.weather.cellMinutes * 60000;
  while (t < end) {
    const cellEnd = start + (Math.floor((t - start) / cellMs) + 1) * cellMs;
    const segEnd = Math.min(end, cellEnd);
    const sec = (segEnd - t) / 1000;
    const wx = weatherAt(s, t);
    if (wx !== s.world.wx) {
      s.world.wx = wx;
      msgs.push(wx === 'clear' ? 'The sky clears.' : `Weather turns: ${wx}.`);
    }
    stepVitals(s, sec);
    stepWorkers(s, sec, wx, msgs);
    if (wx === 'rain' || wx === 'storm') {
      const cut = segEnd - BAL.trails.rainWashesOlderThanSec * 1000;
      s.world.trails = s.world.trails.filter((f) => f.t >= cut);
    }
    t = segEnd;
  }
  s.clock.settledMs = end;
}

function killPlayer(s: GameState, now: number, msgs: string[], cause: string): void {
  const p = s.actors.player;
  const items: Slot[] = [];
  for (const sl of s.custody.inv) if (sl) items.push(sl);
  for (const k of ['weapon', 'armor', 'pack'] as EqSlot[]) if (s.custody.equip[k]) items.push(s.custody.equip[k]!);
  if (items.length) s.custody.bags.push({ id: 'b' + ++s.seq, x: p.x, y: p.y, slots: items });
  s.custody.inv = emptyInv();
  s.custody.equip = { weapon: null, armor: null, pack: null };
  p.deaths += 1;
  s.stats.kills += 0;
  const rp = p.rx ? { x: p.rx, y: p.ry } : null;
  p.x = rp?.x ?? p.x;
  p.y = rp?.y ?? p.y;
  p.hp = Math.round(p.maxHp * 0.6);
  p.hunger = Math.max(p.hunger, 25);
  p.toxin = 0;
  p.warmth = 60;
  p.hitched = null;
  for (const st of Object.values(s.entities.structures)) if (st.hitched) st.hitched = false;
  msgs.push(`You fell to ${cause}. Your pack lies where you fell; you wake at your respawn point.`);
  void now;
}

function postTick(s: GameState, now: number, msgs: string[]): void {
  const w = getWorld();
  for (const [k, src] of Object.entries(s.sources)) if (src.regrowAt && now >= src.regrowAt) delete s.sources[k];
  for (const [k, m] of Object.entries(s.world.mods)) {
    if (m.burnt && now >= m.burnt) delete m.burnt;
    if (m.puddle && now >= m.puddle) delete m.puddle;
    if (!m.burnt && !m.puddle && !m.open) delete s.world.mods[k];
  }
  const p = s.actors.player;
  for (const st of Object.values(s.entities.structures)) {
    if (st.kind === 'cart' && st.hitched) {
      st.tx = tileOf(p.x);
      st.ty = tileOf(p.y);
    }
  }
  const el = now - s.run.startMs;
  if (el >= BAL.run.elderAwakenDay - 1 && el >= (BAL.run.elderAwakenDay - 1) * 24 * 3600000) {
    for (const e of Object.values(s.actors.elders)) if (!e.defeated && !e.awakened) { e.awakened = true; }
  }
  const cap = 30;
  if (el > BAL.creatures.safeStartSeconds * 1000 && now >= s.actors.nextSpawnMs && s.actors.creatures.length < cap) {
    spawnNear(s, w);
    const danger = phaseInfo(s, now).danger ? 0.7 : 1;
    s.actors.nextSpawnMs = now + BAL.creatures.respawnSeconds * 1000 * danger;
  }
  if (p.hp <= 0) killPlayer(s, now, msgs, 'the wilds');
}

export function spawnNear(s: GameState, w = getWorld()): void {
  const p = s.actors.player;
  const ptx = tileOf(p.x), pty = tileOf(p.y);
  for (let attempt = 0; attempt < 40; attempt++) {
    const a = nextRand(s) * Math.PI * 2;
    const d = 18 + nextRand(s) * 16;
    const tx = Math.round(ptx + Math.cos(a) * d), ty = Math.round(pty + Math.sin(a) * d);
    if (tx < 1 || ty < 1 || tx >= MAP_W - 1 || ty >= MAP_H - 1) continue;
    if (blockedTile(s, tx, ty)) continue;
    const t = w.terrain[tkey(tx, ty)];
    let kind: string;
    const r = nextRand(s);
    const water = [1, 2, 3].some((k) => [[k, 0], [-k, 0], [0, k], [0, -k]].some(([dx, dy]) => {
      const q = w.terrain[tkey(Math.min(MAP_W - 1, Math.max(0, tx + dx)), Math.min(MAP_H - 1, Math.max(0, ty + dy)))];
      return q === T.SHALLOW || q === T.DEEP;
    }));
    if (t === T.SAND && water) kind = 'crab';
    else if (t === T.MARSH) kind = r < 0.5 ? 'wisp' : 'slime';
    else if (t === T.TUNDRA || t === T.SNOW) kind = 'wolf';
    else if (t === T.DESERT || t === T.SLAG) kind = r < 0.45 ? 'archer' : 'boar';
    else if (t === T.FOREST) kind = r < 0.45 ? 'wolf' : r < 0.75 ? 'slime' : 'boar';
    else if (t === T.GRASS || t === T.HILL) kind = r < 0.5 ? 'slime' : r < 0.75 ? 'boar' : 'wolf';
    else continue;
    if (kind === 'bat') continue;
    const x = tx * TILE + 8, y = ty * TILE + 8;
    const cdef = CREATURES[kind];
    s.actors.creatures.push({ id: 'c' + ++s.seq, kind, x, y, hp: cdef.hp, hx: x, hy: y, st: 'idle', ang: 0 });
    return;
  }
}

function finalize(s: GameState, outcome: string, now: number): void {
  if (s.run.status !== 'active') rej('This run has already ended.');
  const stones = Object.values(s.actors.elders).filter((e) => e.defeated).length;
  const rec: RunRecord = {
    id: s.run.id, outcome, startMs: s.run.startMs, endMs: now, score: s.run.score, stones, ach: [...s.ach],
    spawn: s.run.spawn, gender: s.run.gender, deposited: s.run.deposited
  };
  s.profile.history.push(rec);
  if (s.profile.history.length > 60) s.profile.history.splice(0, s.profile.history.length - 60);
  s.run = { ...s.run, status: 'ended', outcome, endMs: now, stones };
  s.custody = { inv: emptyInv(), equip: { weapon: null, armor: null, pack: null }, ground: [], bags: [] };
  s.entities = { structures: {} };
  s.world = { mods: {}, claims: [], trails: [], discovered: '0'.repeat(DISC_CELLS), wx: 'clear' };
  s.actors.creatures = [];
  s.actors.elders = {};
  s.sources = {};
  s.knowledge = { learned: [] };
  s.jobs = {};
  s.ledger = { minted: {}, spent: {} };
  s.ach = [];
}

// ---------------------------------------------------------------- inventory locations (K1)
function locGet(s: GameState, l: Loc): Maybe {
  switch (l.k) {
    case 'inv': return s.custody.inv[l.i] ?? null;
    case 'eq': return s.custody.equip[l.slot];
    case 'st': {
      const st = s.entities.structures[l.id];
      if (!st) rej('That container is gone.');
      if (l.slot === 'slots') return st.slots?.[l.i ?? -1] ?? null;
      if (l.slot === 'fuel') return st.fuel ?? null;
      if (l.slot === 'input') return st.input ?? null;
      return st.output ?? null;
    }
    case 'bag': {
      const b = s.custody.bags.find((x) => x.id === l.id);
      if (!b) rej('That bag is already recovered.');
      return b.slots[l.i] ?? null;
    }
  }
}
function locSet(s: GameState, l: Loc, v: Maybe): void {
  switch (l.k) {
    case 'inv': s.custody.inv[l.i] = v; return;
    case 'eq': s.custody.equip[l.slot] = v; return;
    case 'st': {
      const st = s.entities.structures[l.id];
      if (!st) return;
      if (l.slot === 'slots' && st.slots) st.slots[l.i ?? 0] = v;
      else if (l.slot === 'fuel') st.fuel = v;
      else if (l.slot === 'input') st.input = v;
      else st.output = v;
      return;
    }
    case 'bag': {
      const b = s.custody.bags.find((x) => x.id === l.id);
      if (!b) return;
      if (v) b.slots[l.i] = v;
      else b.slots.splice(l.i, 1);
      if (b.slots.length === 0) s.custody.bags = s.custody.bags.filter((x) => x.id !== l.id);
      return;
    }
  }
}
function locAccepts(s: GameState, l: Loc, item: string): boolean {
  const d = ITEMS[item];
  switch (l.k) {
    case 'inv': return l.i < invCap(s);
    case 'eq': return d.slot === l.slot;
    case 'st': {
      const st = s.entities.structures[l.id];
      if (!st) return false;
      if (l.slot === 'slots') return !!st.slots && (l.i ?? 0) < st.slots.length;
      if (l.slot === 'fuel') return st.kind === 'furnace' && d.fuel !== undefined;
      if (l.slot === 'input') return st.kind === 'furnace' && FURN_INPUTS.has(item);
      return false;
    }
    case 'bag': return false;
  }
}
function locNear(s: GameState, l: Loc): void {
  if (l.k === 'st') {
    const st = s.entities.structures[l.id];
    if (!st) rej('That container is gone.');
    if (!near(s, st.tx, st.ty, 4)) rej('Too far away.');
  } else if (l.k === 'bag') {
    const b = s.custody.bags.find((x) => x.id === l.id);
    if (!b) rej('That bag is already recovered.');
    if (dpx(s.actors.player.x, s.actors.player.y, b.x, b.y) > 4 * TILE) rej('Too far from the bag.');
  }
}

// ---------------------------------------------------------------- dispatcher
export function dispatch(prev: GameState, intent: Intent, reqId?: string): Result {
  if (reqId && prev.reqs.includes(reqId)) return { ok: false, reason: 'Already committed (duplicate request ignored).' };
  const pBefore = JSON.stringify(prev.profile);
  const s = structuredClone(prev) as GameState;
  let msg = '';
  try {
    msg = apply(s, intent);
  } catch (e) {
    if (e instanceof Rej) return { ok: false, reason: e.message };
    throw e;
  }
  s.rev += 1;
  if (msg) {
    s.receipts.push({ id: 'R' + ++s.seq, t: s.clock.settledMs, kind: intent.type, msg });
    if (s.receipts.length > 120) s.receipts.splice(0, s.receipts.length - 120);
  }
  if (reqId) {
    s.reqs.push(reqId);
    if (s.reqs.length > 80) s.reqs.splice(0, s.reqs.length - 80);
  }
  return { ok: true, state: s, msg, profileChanged: JSON.stringify(s.profile) !== pBefore };
}

function apply(s: GameState, it: Intent): string {
  const p = s.actors.player;
  const w = getWorld();
  const msgs: string[] = [];
  switch (it.type) {
    case 'new_run': {
      if (s.run.status === 'active') rej('A run is already in progress.');
      s.profile.runs += 1;
      const fresh = startRun(s, it.now, it.spawn, it.gender);
      Object.assign(s, fresh);
      return `Run ${s.run.id} begins at ${it.spawn === 'marsh' ? 'Reed Marsh Edge' : it.spawn}. Day 1.`;
    }
    case 'tick': {
      if (s.run.status !== 'active') return '';
      if (it.now - s.run.startMs >= RUN_MS) {
        finalize(s, 'expired', it.now);
        return 'The 336-hour run has reached its end. Your run-local world is gone; profile records remain.';
      }
      advance(s, it.now, msgs);
      postTick(s, it.now, msgs);
      return msgs.join(' · ');
    }
    case 'qa_offset': {
      s.clock.qaOffsetMs += it.ms;
      return '';
    }
    case 'move': {
      if (s.run.status !== 'active') rej('No active run.');
      const src = locGet(s, it.from);
      if (!src) rej('Nothing there.');
      locNear(s, it.from);
      locNear(s, it.to);
      const count = Math.max(1, Math.min(it.count ?? src.qty, src.qty));
      if (it.from.k === 'eq' && it.from.slot === 'pack' && !(it.to.k === 'eq' && it.to.slot === 'pack')) {
        for (let i = 24; i < s.custody.inv.length; i++) if (s.custody.inv[i]) rej('Empty the pack\u2019s extra slots first.');
      }
      if (!locAccepts(s, it.to, src.item)) rej(`${ITEMS[src.item].name} does not fit there.`);
      if (it.to.k === 'inv' && it.to.i >= invCap(s)) rej('That slot is inside a missing pack.');
      const dst = locGet(s, it.to);
      const d = ITEMS[src.item];
      if (!dst) {
        const part: Slot = count === src.qty ? src : { ...src, uid: uid(s), qty: count };
        if (count !== src.qty) src.qty -= count;
        else locSet(s, it.from, null);
        locSet(s, it.to, part);
      } else if (dst.item === src.item && d.stack > 1 && stackable(dst)) {
        const room = d.stack - dst.qty;
        const add = Math.min(room, count);
        if (add <= 0) rej('That stack is full.');
        dst.qty += add;
        src.qty -= add;
        if (src.qty <= 0) locSet(s, it.from, null);
      } else {
        if (count !== src.qty) rej('Destination is occupied; move the whole stack to swap.');
        if (!locAccepts(s, it.from, dst.item)) rej(`${ITEMS[dst.item].name} cannot go there.`);
        locSet(s, it.from, dst);
        locSet(s, it.to, src);
      }
      return '';
    }
    case 'drop': {
      const sl = s.custody.inv[it.i];
      if (!sl) rej('Nothing to drop.');
      s.custody.inv[it.i] = null;
      s.custody.ground.push({ uid: sl.uid, item: sl.item, qty: sl.qty, x: p.x, y: p.y, dur: sl.dur, charges: sl.charges });
      return `Dropped ${ITEMS[sl.item].name}.`;
    }
    case 'pickup': {
      const gi = s.custody.ground.findIndex((g) => g.uid === it.uid);
      if (gi < 0) rej('Already picked up.');
      const g = s.custody.ground[gi];
      if (dpx(p.x, p.y, g.x, g.y) > 1.8 * TILE) rej('Too far away.');
      if (spaceFor(s, g.item) < g.qty) rej('Pack is full.');
      if (g.dur !== undefined || g.charges !== undefined) {
        const cap = invCap(s);
        const i = s.custody.inv.findIndex((x, idx) => idx < cap && !x);
        s.custody.inv[i] = { uid: g.uid, item: g.item, qty: g.qty, dur: g.dur, charges: g.charges };
      } else {
        addInv(s, g.item, g.qty);
      }
      s.custody.ground.splice(gi, 1);
      return '';
    }
    case 'sort': {
      const cap = invCap(s);
      const all: Slot[] = [];
      for (let i = 0; i < cap; i++) if (s.custody.inv[i]) all.push(s.custody.inv[i]!);
      const merged: Slot[] = [];
      for (const sl of all) {
        const m = merged.find((x) => x.item === sl.item && stackable(x) && stackable(sl));
        if (m && ITEMS[sl.item].stack > 1) m.qty += sl.qty;
        else merged.push({ ...sl });
      }
      const cat = ['material', 'food', 'tool', 'weapon', 'armor', 'ammo', 'pack', 'core', 'kit', 'cash', 'key', 'stone', 'blueprint', 'specimen'];
      merged.sort((a, b) => cat.indexOf(ITEMS[a.item].cat) - cat.indexOf(ITEMS[b.item].cat) || ITEMS[a.item].name.localeCompare(ITEMS[b.item].name));
      for (let i = 0; i < s.custody.inv.length; i++) s.custody.inv[i] = i < merged.length && i < cap ? merged[i] : null;
      return '';
    }
    case 'eat': {
      const sl = s.custody.inv[it.i];
      if (!sl) rej('Nothing there.');
      const d = ITEMS[sl.item];
      if (!d.food && !d.heal && !d.cure) rej(`${d.name} is not edible.`);
      p.hunger = Math.min(100, p.hunger + (d.food ?? 0));
      p.hp = Math.min(p.maxHp, p.hp + (d.heal ?? 0));
      p.toxin = Math.max(0, p.toxin - (d.cure ?? 0));
      if (sl.item === 'raw_meat') p.toxin += 12;
      sl.qty -= 1;
      spend(s, sl.item, 1);
      if (sl.qty <= 0) s.custody.inv[it.i] = null;
      return `Used ${d.name}.`;
    }
    case 'equip': {
      const sl = s.custody.inv[it.i];
      if (!sl) rej('Nothing there.');
      const d = ITEMS[sl.item];
      if (!d.slot) rej(`${d.name} cannot be equipped; use it from the hotbar.`);
      const slot = d.slot as EqSlot;
      const old = s.custody.equip[slot];
      if (slot === 'pack' && old) {
        for (let i = 24; i < s.custody.inv.length; i++) if (s.custody.inv[i]) rej('Empty the pack\u2019s extra slots first.');
      }
      s.custody.equip[slot] = sl;
      s.custody.inv[it.i] = old;
      return `Equipped ${d.name}.`;
    }
    case 'unequip': {
      const sl = s.custody.equip[it.slot];
      if (!sl) rej('Nothing equipped there.');
      if (it.slot === 'pack') {
        for (let i = 24; i < s.custody.inv.length; i++) if (s.custody.inv[i]) rej('Empty the pack\u2019s extra slots first.');
      }
      const cap = it.slot === 'pack' ? 24 : invCap(s);
      const idx = s.custody.inv.findIndex((x, i) => i < cap && !x);
      if (idx < 0) rej('Pack is full.');
      s.custody.inv[idx] = sl;
      s.custody.equip[it.slot] = null;
      return '';
    }
    case 'craft': {
      const rec = RECIPES.find((r) => r.id === it.recipe);
      if (!rec) rej('Unknown recipe.');
      if (!(rec.known || s.knowledge.learned.includes(rec.id))) rej('Recipe not learned yet; study a blueprint at a desk.');
      if (rec.st === 'furn') rej('Load the furnace instead; it smelts and cooks on its own fire.');
      if (rec.st === 'bench' && !Object.values(s.entities.structures).some((st) => st.kind === 'workbench' && near(s, st.tx, st.ty, 4))) rej('Needs a workbench nearby.');
      for (const [item, q] of rec.inp) {
        const have = countInv(s, item);
        if (have < q) rej(`Missing ${ITEMS[item].name}: ${have}/${q}.`);
      }
      for (const [item, q] of rec.inp) takeInv(s, item, q);
      const left = addInv(s, rec.out[0], rec.out[1]);
      if (left > 0) rej('Not enough room for the result.');
      mint(s, rec.out[0], rec.out[1]);
      s.stats.crafts += 1;
      achieve(s, 'first_craft', msgs);
      return `Crafted ${rec.name}.`;
    }
    case 'study': {
      const desk = s.entities.structures[it.desk];
      if (!desk || desk.kind !== 'research_desk') rej('No study desk there.');
      if (!near(s, desk.tx, desk.ty, 4)) rej('Too far from the desk.');
      if (Object.values(s.jobs).some((j) => j.desk === desk.id)) rej('The desk is already studying something.');
      const rec = RECIPES.find((r) => r.id === it.recipe);
      if (!rec || !rec.study) rej('Nothing to study there.');
      if (rec.known || s.knowledge.learned.includes(rec.id)) rej('Already known in this run.');
      const cost = rec.study!.every(([i, q]) => countInv(s, i) >= q) ? rec.study! : rec.studyAlt && rec.studyAlt.every(([i, q]) => countInv(s, i) >= q) ? rec.studyAlt : null;
      if (!cost) rej('Needs a blueprint or a specimen plus Spares.');
      for (const [i, q] of cost!) takeInv(s, i, q);
      s.jobs['j' + ++s.seq] = { id: 'j' + s.seq, recipe: rec.id, desk: desk.id, progress: 0, need: BAL.research.studySeconds };
      achieve(s, 'first_study', msgs);
      return `Study started: ${rec.name} (${BAL.research.studySeconds}s).`;
    }
    case 'build': {
      const def = STRUCTS[it.kind];
      if (!def) rej('Unknown structure.');
      if (s.run.status !== 'active') rej('No active run.');
      if (!near(s, it.tx, it.ty, 5)) rej('Too far to build there.');
      if (it.tx < 0 || it.ty < 0 || it.tx >= MAP_W || it.ty >= MAP_H) rej('Off the island.');
      const k = tkey(it.tx, it.ty);
      const t = w.terrain[k];
      if (t === T.DEEP || t === T.SHALLOW || t === T.RIVER || t === T.MOUNTAIN || t === T.CLIFF || t === T.CAVE || t === T.PIER) rej('That ground cannot be built on.');
      const o = effObj(s, k);
      if (o && o !== O.FLOWER && o !== O.MUSH && o !== O.REED) rej('Clear the obstacle first (harvest it).');
      const here = structsAt(s, it.tx, it.ty);
      if (def.block && here.length) rej('Tile occupied.');
      if (!def.block && here.some((x) => STRUCTS[x.kind].block || x.kind === it.kind)) rej('Tile occupied.');
      if (def.block && tileOf(p.x) === it.tx && tileOf(p.y) === it.ty) rej('Step off that tile first.');
      let claim: string | undefined;
      if (it.kind === 'claim_marker') {
        if (s.world.claims.some((c) => (c.tx - it.tx) ** 2 + (c.ty - it.ty) ** 2 < 100)) rej('Too close to another home stake.');
      } else {
        const cid = claimAt(s, it.tx, it.ty);
        if (!cid) rej('Build inside owned land: place a Home Stake first.');
        claim = cid ?? undefined;
      }
      if (def.cost.length === 0 && def.kit) {
        const kidx = s.custody.inv.findIndex((x) => x && x.item === def.kit);
        if (kidx < 0) rej(`You need a ${ITEMS[def.kit].name}.`);
        spend(s, def.kit, 1);
        s.custody.inv[kidx]!.qty -= 1;
        if (s.custody.inv[kidx]!.qty <= 0) s.custody.inv[kidx] = null;
      } else {
        for (const [item, q] of def.cost) if (countInv(s, item) < q) rej(`Missing ${ITEMS[item].name}: ${countInv(s, item)}/${q}.`);
        for (const [item, q] of def.cost) takeInv(s, item, q);
      }
      const id = 's' + ++s.seq;
      const st: Structure = { id, kind: it.kind, tx: it.tx, ty: it.ty, hp: def.hp, claim };
      if (it.kind === 'claim_marker') {
        s.world.claims.push({ id: 'h' + s.seq, tx: it.tx, ty: it.ty, r: BAL.claim.radiusTiles });
        st.claim = 'h' + s.seq;
      }
      if (def.station === 'chest') st.slots = new Array<Maybe>(def.cap ?? 16).fill(null);
      if (def.station === 'cart') { st.slots = new Array<Maybe>(def.cap ?? 12).fill(null); st.hitched = false; }
      if (def.station === 'furn') { st.fuel = null; st.input = null; st.output = null; st.job = null; st.burn = 0; }
      if (def.station === 'garden') st.plant = null;
      s.entities.structures[id] = st;
      s.stats.builds += 1;
      achieve(s, 'first_build', msgs);
      return `Built ${def.name}.`;
    }
    case 'reclaim': {
      const st = s.entities.structures[it.id];
      if (!st) rej('Nothing to reclaim there.');
      if (!near(s, st.tx, st.ty, 4)) rej('Too far away.');
      if (st.slots && st.slots.some((x) => x)) rej('Empty it first; contents are never deleted.');
      if (st.fuel || st.input || st.output || st.job) rej('Empty the furnace first.');
      if (st.kind === 'claim_marker' && s.entities && Object.values(s.entities.structures).some((o) => o.claim === st.claim && o.id !== st.id)) rej('Remove structures inside this land first.');
      const def = STRUCTS[st.kind];
      if (def.cost.length === 0 && def.kit) {
        const left = addInv(s, def.kit, 1);
        mint(s, def.kit, 1);
        if (left) placeGround(s, def.kit, 1, st.tx * TILE + 8, st.ty * TILE + 8);
      } else {
        for (const [item, q] of def.cost) {
          const left = addInv(s, item, q);
          mint(s, item, q);
          if (left) placeGround(s, item, left, st.tx * TILE + 8, st.ty * TILE + 8);
        }
      }
      if (st.kind === 'claim_marker') s.world.claims = s.world.claims.filter((c) => c.id !== st.claim);
      if (st.kind === 'cart' && p.hitched === st.id) p.hitched = null;
      delete s.entities.structures[it.id];
      if (p.rx === st.tx * TILE + 8 && p.ry === st.ty * TILE + 8) {
        const sp = w.spawns[s.run.spawn] ?? w.spawns.pinewood;
        p.rx = sp.x * TILE + 8;
        p.ry = sp.y * TILE + 8;
      }
      return `Reclaimed ${def.name}.`;
    }
    case 'door': {
      if (it.id === 'gallery') {
        const dk = tkey(w.pois.find((q) => q.id === 'gallery')?.x ?? 0, w.pois.find((q) => q.id === 'gallery')?.y ?? 0);
        if (!near(s, dk % MAP_W, Math.floor(dk / MAP_W), 3)) rej('Too far from the sealed door.');
        if (s.world.mods[dk]?.open) rej('The gallery is already open.');
        if (countInv(s, 'rusted_key') < 1) rej('The door is sealed. A rusted key might open it.');
        s.world.mods[dk] = { ...(s.world.mods[dk] ?? {}), open: 1 };
        achieve(s, 'deep_gallery', msgs);
        return 'The sealed door grinds open.';
      }
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'door') rej('Not a door.');
      if (!near(s, st.tx, st.ty, 3)) rej('Too far away.');
      st.open = !st.open;
      return st.open ? 'Door opened.' : 'Door closed.';
    }
    case 'sleep': {
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'bed') rej('No bed there.');
      if (!near(s, st.tx, st.ty, 3)) rej('Too far from the bed.');
      p.rx = st.tx * TILE + 8;
      p.ry = st.ty * TILE + 8;
      p.hp = p.maxHp;
      p.warmth = 100;
      p.toxin = Math.max(0, p.toxin - 10);
      return 'You rest. Your respawn point is set to this bed.';
    }
    case 'plant': {
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'garden') rej('No garden there.');
      if (!near(s, st.tx, st.ty, 3)) rej('Too far from the garden.');
      if (st.plant) rej('Something is already growing here.');
      const sl = s.custody.inv[it.i];
      if (!sl || sl.item !== 'seed_turnip') rej('Select turnip seeds in the pack to plant.');
      sl.qty -= 1;
      spend(s, 'seed_turnip', 1);
      if (sl.qty <= 0) s.custody.inv[it.i] = null;
      st.plant = { growth: 0, ready: false };
      return 'Planted turnip seeds.';
    }
    case 'crop': {
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'garden' || !st.plant) rej('Nothing planted here.');
      if (!near(s, st.tx, st.ty, 3)) rej('Too far from the garden.');
      if (!st.plant!.ready) rej(`Still growing (${Math.round(st.plant!.growth * 100)}%).`);
      const q1 = 2 + Math.floor(nextRand(s) * 2), q2 = 1 + Math.floor(nextRand(s) * 2);
      const l1 = addInv(s, 'turnip', q1), l2 = addInv(s, 'seed_turnip', q2);
      mint(s, 'turnip', q1);
      mint(s, 'seed_turnip', q2);
      if (l1) placeGround(s, 'turnip', l1, st.tx * TILE + 8, st.ty * TILE + 8);
      if (l2) placeGround(s, 'seed_turnip', l2, st.tx * TILE + 8, st.ty * TILE + 8);
      st.plant = null;
      return `Harvested ${q1} turnips and ${q2} seeds.`;
    }
    case 'hitch': {
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'cart') rej('No cart there.');
      if (p.hitched) rej('You already pull a cart.');
      if (!near(s, st.tx, st.ty, 2)) rej('Get closer to hitch the cart.');
      p.hitched = st.id;
      st.hitched = true;
      st.hx = st.tx;
      st.hy = st.ty;
      return 'Cart hitched. Heavy cargo slows you on rough ground.';
    }
    case 'release': {
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'cart') rej('No cart there.');
      if (p.hitched !== st.id) rej('You are not pulling that cart.');
      const dist = Math.hypot(st.tx - (st.hx ?? st.tx), st.ty - (st.hy ?? st.ty));
      const cargo = (st.slots ?? []).some((x) => x);
      p.hitched = null;
      st.hitched = false;
      if (cargo && dist >= 12) {
        s.stats.cartTrips += 1;
        achieve(s, 'cart_haul', msgs);
      }
      return 'Cart released where you stand.';
    }
    case 'harvest': {
      const k = it.key;
      const nodeId = OBJ_NODE[w.obj[k]];
      if (!nodeId) rej('Nothing to harvest here.');
      const src = s.sources[k];
      if (src && (src.gone || src.hp <= 0)) rej('Already harvested.');
      const node = NODES[nodeId];
      const toolSlot = it.tool === 'eq' ? s.custody.equip.weapon : s.custody.inv[it.tool] ?? null;
      const def = toolSlot ? ITEMS[toolSlot.item] : null;
      const power = def?.power ?? 0;
      let eff: number;
      if (node.kind === 'any') eff = 1;
      else if (def && def.harvest === node.kind) {
        if (power < node.need) rej(`Too hard: this needs a stronger ${node.kind === 'mine' ? 'pick' : 'tool'}.`);
        eff = power;
      } else {
        if (node.need > 0 && power < node.need) rej('Too hard: your tool cannot break this.');
        eff = Math.max(0.25, power * 0.35);
      }
      if (toolSlot && def && def.dur !== undefined && toolSlot.dur !== undefined) {
        toolSlot.dur -= 1;
        if (toolSlot.dur <= 0) {
          spend(s, toolSlot.item, 1);
          if (it.tool === 'eq') s.custody.equip.weapon = null;
          else s.custody.inv[it.tool] = null;
          msgs.push(`Your ${def.name} broke.`);
        }
      }
      let hp = src?.hp ?? node.hp;
      hp -= eff;
      const cx = it.key % MAP_W * TILE + 8, cy = Math.floor(it.key / MAP_W) * TILE + 8;
      if (hp > 0) {
        s.sources[k] = { hp };
        return msgs.join(' · ');
      }
      for (const [item, lo, hi] of node.yields) {
        const q = randInt(s, lo, hi);
        if (q > 0) mintGround(s, item, q, cx, cy);
      }
      s.sources[k] = node.finite ? { hp: 0, gone: true } : { hp: 0, regrowAt: it.now + node.regrowS * 1000 };
      s.stats.harvests += 1;
      achieve(s, 'first_chop', msgs);
      return `${node.name} cleared.`;
    }
    case 'creature_dead': {
      const idx = s.actors.creatures.findIndex((c) => c.id === it.id);
      if (idx < 0) rej('Already claimed.');
      const c = s.actors.creatures[idx];
      s.actors.creatures.splice(idx, 1);
      const def = CREATURES[c.kind];
      for (const [item, lo, hi, pct] of def.loot) {
        if (nextRand(s) * 100 < pct) {
          const q = randInt(s, lo, hi);
          if (q > 0) mintGround(s, item, q, c.x + (nextRand(s) - 0.5) * 8, c.y + (nextRand(s) - 0.5) * 8);
        }
      }
      if (c.kind === 'wisp') {
        const k = tkey(tileOf(c.x), tileOf(c.y));
        s.world.mods[k] = { ...(s.world.mods[k] ?? {}), puddle: it.now + 60000 };
      }
      s.stats.kills += 1;
      achieve(s, 'first_kill', msgs);
      return `${def.name} slain.`;
    }
    case 'hurt': {
      if (p.hp <= 0) rej('Already down.');
      const arm = s.custody.equip.armor;
      const reduce = arm ? ITEMS[arm.item].armor ?? 0 : 0;
      const dmg = it.amount * (1 - reduce);
      p.hp -= dmg;
      p.toxin += it.toxin ?? 0;
      if (p.hp <= 0) killPlayer(s, it.now, msgs, it.src);
      return '';
    }
    case 'struct_hurt': {
      const st = s.entities.structures[it.id];
      if (!st) rej('Already destroyed.');
      st.hp -= it.amount;
      if (st.hp <= 0) {
        for (const sl of st.slots ?? []) if (sl) placeGround(s, sl.item, sl.qty, st.tx * TILE + 8, st.ty * TILE + 8, sl);
        if (st.kind === 'claim_marker') s.world.claims = s.world.claims.filter((c) => c.id !== st.claim);
        delete s.entities.structures[it.id];
        return `${STRUCTS[st.kind].name} was broken by ${it.src}.`;
      }
      return '';
    }
    case 'cast': {
      const ci = s.custody.inv.findIndex((x) => x && x.item === 'ember_core' && (x.charges ?? 0) > 0);
      if (ci < 0) rej('No charged Core to cast.');
      const core = s.custody.inv[ci]!;
      core.charges = (core.charges ?? 1) - 1;
      const tx0 = tileOf(it.tx), ty0 = tileOf(it.ty);
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        if (dx * dx + dy * dy > 6) continue;
        const tx = tx0 + dx, ty = ty0 + dy;
        if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) continue;
        const kk = tkey(tx, ty);
        const tt = w.terrain[kk];
        if (tt === T.GRASS || tt === T.FOREST || tt === T.TUNDRA || tt === T.MARSH) s.world.mods[kk] = { ...(s.world.mods[kk] ?? {}), burnt: it.now + 180000 };
        if (OBJ_NODE[w.obj[kk]] && effObj(s, kk)) {
          const src = s.sources[kk];
          const hp = (src?.hp ?? NODES[OBJ_NODE[w.obj[kk]]].hp) - 2;
          if (hp <= 0) {
            const node = NODES[OBJ_NODE[w.obj[kk]]];
            s.sources[kk] = node.finite ? { hp: 0, gone: true } : { hp: 0, regrowAt: it.now + node.regrowS * 1000 };
            for (const [item, lo, hi] of node.yields) {
              const q = randInt(s, lo, hi);
              if (q > 0) mintGround(s, item, q, tx * TILE + 8, ty * TILE + 8);
            }
          } else s.sources[kk] = { hp };
        }
      }
      achieve(s, 'first_cast', msgs);
      return `Ember Core cast (${core.charges} charge${core.charges === 1 ? '' : 's'} left).`;
    }
    case 'shoot': {
      if (s.custody.equip.weapon?.item !== 'bow_wood') rej('Equip the longbow to shoot.');
      if (countInv(s, 'arrow') < 1) rej('Out of arrows.');
      takeInv(s, 'arrow', 1);
      return '';
    }
    case 'summon': {
      if (s.actors.creatures.length >= 40) rej('Too many creatures nearby.');
      if (!CREATURES[it.kind]) rej('Unknown creature.');
      s.actors.creatures.push({ id: 'c' + ++s.seq, kind: it.kind, x: it.x, y: it.y, hp: CREATURES[it.kind].hp, hx: it.x, hy: it.y, st: 'idle', ang: 0 });
      return '';
    }
    case 'elder_hit': {
      const e = s.actors.elders[it.id];
      const def = ELDERS.find((q) => q.id === it.id);
      if (!e || !def) rej('Unknown elder.');
      if (e.defeated) rej('Already defeated.');
      e.hp -= it.dmg;
      if (!e.awakened && e.hp <= e.maxHp * BAL.elders.enrageAtHpFraction) {
        e.awakened = true;
        msgs.push(`${def.name} awakens in fury.`);
      }
      if (e.hp <= 0) {
        e.hp = 0;
        e.defeated = true;
        const shrine = w.pois.find((q) => q.elder === it.id);
        if (shrine) mintGround(s, def.stone, 1, shrine.x * TILE + 8, shrine.y * TILE + 8);
        s.run.stones = Object.values(s.actors.elders).filter((q) => q.defeated).length;
        achieve(s, 'elder_' + it.id, msgs);
        if (s.run.stones >= 6) achieve(s, 'six_stones', msgs);
        msgs.push(`${def.name} is undone. ${def.stone.replace('stone_', '').toUpperCase()} stone left at the shrine.`);
      }
      return msgs.join(' · ');
    }
    case 'chest': {
      const poi = w.pois.find((q) => q.id === it.poi);
      if (!poi || !poi.chest) rej('No chest there.');
      if (!near(s, poi.x, poi.y, 1.6)) rej('Too far from the chest.');
      const def = CHESTS[poi.chest!];
      const sk = 'poi:' + poi.chest;
      if (s.sources[sk]?.hp === 1) rej('Already emptied.');
      if (def.vault) {
        const hours = (it.now - s.run.startMs) / 3600000;
        if (hours < BAL.vault.opensAtRunHour) rej('Sealed until the final seventy-two hours.');
        const q = randInt(s, BAL.vault.cashMin, BAL.vault.cashMax);
        mintGround(s, 'ragnarok_cash', 0, 0, 0);
        const left = addInv(s, 'ragnarok_cash', q);
        mint(s, 'ragnarok_cash', q);
        if (left) placeGround(s, 'ragnarok_cash', left, poi.x * TILE + 8, poi.y * TILE + 8);
        s.sources[sk] = { hp: 1 };
        achieve(s, 'vault_cash', msgs);
        return `Sealed Vault opened: ${q} Ragnarok Cash.`;
      }
      if (def.key) {
        const dk = tkey(w.pois.find((q) => q.id === 'gallery')?.x ?? 0, w.pois.find((q) => q.id === 'gallery')?.y ?? 0);
        if (!s.world.mods[dk]?.open) rej('The gallery is still sealed.');
      }
      for (const [item, lo, hi] of def.loot) {
        const q = randInt(s, lo, hi);
        const left = addInv(s, item, q);
        mint(s, item, q);
        if (left) placeGround(s, item, left, poi.x * TILE + 8, poi.y * TILE + 8);
      }
      if (def.core) {
        const cs = { uid: uid(s), item: 'ember_core', qty: 1, dur: undefined, charges: 3 };
        const cap = invCap(s);
        const idx = s.custody.inv.findIndex((x, i) => i < cap && !x);
        if (idx >= 0) s.custody.inv[idx] = { uid: cs.uid, item: 'ember_core', qty: 1, charges: 3 };
        else s.custody.ground.push({ uid: cs.uid, item: 'ember_core', qty: 1, x: poi.x * TILE + 8, y: poi.y * TILE + 8, charges: 3 });
        mint(s, 'ember_core', 1);
      }
      s.sources[sk] = { hp: 1 };
      if (poi.chest === 'mine_deep') achieve(s, 'deep_gallery', msgs);
      return `Opened ${def.name}.`;
    }
    case 'bag_loot': {
      const b = s.custody.bags.find((x) => x.id === it.id);
      if (!b) rej('That bag is already recovered.');
      if (dpx(p.x, p.y, b.x, b.y) > 3 * TILE) rej('Too far from the bag.');
      const keep: Slot[] = [];
      let taken = 0;
      for (const sl of b.slots) {
        const left = addInvSlot(s, sl);
        if (left) { keep.push(left); } else taken += 1;
      }
      if (keep.length === 0) s.custody.bags = s.custody.bags.filter((x) => x.id !== it.id);
      else b.slots = keep;
      return `Recovered ${taken} item stack${taken === 1 ? '' : 's'}${keep.length ? `; ${keep.length} left in the bag` : ''}.`;
    }
    case 'trail': {
      const life = BAL.trails[(it.kind === 'sand' ? 'sandLifeSec' : it.kind === 'snow' ? 'snowLifeSec' : it.kind === 'mud' ? 'mudLifeSec' : 'grassLifeSec') as 'grassLifeSec'];
      s.world.trails.push({ x: it.x, y: it.y, t: it.now, kind: it.kind, life });
      if (s.world.trails.length > 240) s.world.trails.splice(0, s.world.trails.length - 240);
      return '';
    }
    case 'discover': {
      if (discovered(s, it.tx, it.ty)) return '';
      s.world.discovered = discoverCell(s.world.discovered, it.tx, it.ty);
      const regs = regionCount(s);
      if (regs >= 5) achieve(s, 'five_regions', msgs);
      return `Discovered ${REGIONS[regionAt(w, it.tx, it.ty)]}.`;
    }
    case 'deposit': {
      const st = s.entities.structures[it.id];
      if (!st || st.kind !== 'escrow_chest') rej('No escrow chest there.');
      if (!st.claim) rej('Escrow must stand on owned land.');
      if (!near(s, st.tx, st.ty, 3)) rej('Too far from the escrow chest.');
      const amount = cashCount(s);
      if (amount <= 0) rej('No physical Ragnarok Cash to deposit.');
      takeInv(s, 'ragnarok_cash', amount);
      s.profile.secured += amount;
      s.run.deposited += amount;
      s.profile.deposits.push(`${s.run.id}:${s.seq}:${amount}`);
      achieve(s, 'escrow_secured', msgs);
      return `Secured ${amount} Ragnarok Cash to your profile.`;
    }
    case 'vendor_buy_escrow': {
      const tr = w.pois.find((q) => q.id === 'trade');
      if (!tr || !near(s, tr.x, tr.y + 1, 3)) rej('Visit the trade post vendor.');
      const price = BAL.escrow.chestPriceCash;
      if (cashCount(s) < price) rej(`Needs ${price} physical Ragnarok Cash in your pack.`);
      if (spaceFor(s, 'escrow_chest') < 1) rej('Pack is full.');
      takeInv(s, 'ragnarok_cash', price);
      addInv(s, 'escrow_chest', 1);
      mint(s, 'escrow_chest', 1);
      return `Bought an Escrow Chest for ${price} Ragnarok Cash. Place it on owned land.`;
    }
    case 'vendor_buy_run': {
      const tr = w.pois.find((q) => q.id === 'trade');
      if (!tr || !near(s, tr.x, tr.y + 1, 3)) rej('Visit the trade post vendor.');
      const stock = RUN_STOCK.find((x) => x.item === it.item);
      if (!stock) rej('Not stocked.');
      if (s.profile.secured < stock!.price) rej(`Needs ${stock!.price} secured Ragnarok Cash.`);
      if (spaceFor(s, it.item) < 1) rej('Pack is full.');
      const key = `buy:${s.run.id}:${it.req}`;
      if (s.profile.purchases.includes(key)) rej('Purchase already recorded.');
      s.profile.secured -= stock!.price;
      s.profile.purchases.push(key);
      addInv(s, it.item, 1);
      mint(s, it.item, 1);
      return `Bought ${ITEMS[it.item].name} for ${stock!.price} secured cash.`;
    }
    case 'evacuate': {
      const dock = w.pois.find((q) => q.id === 'dock');
      if (!dock || !near(s, dock.x, dock.y, 4)) rej('Reach the evacuation skiff first.');
      finalize(s, 'evacuated', it.now);
      achieve(s, 'evacuated', msgs);
      return 'You board the skiff. The run is over; only your secured Ragnarok Cash survives.';
    }
    case 'abandon': {
      finalize(s, 'abandoned', it.now);
      return 'You abandon the run. Everything run-local is gone.';
    }
    case 'expire': {
      if (it.now - s.run.startMs < RUN_MS) rej('The run still has time left.');
      finalize(s, 'expired', it.now);
      return 'The run has expired.';
    }
  }
  return msgs.join(' · ');
}

/** Moves one whole slot into the inventory (stacking when possible); returns the leftover slot or null. */
function addInvSlot(s: GameState, sl: Slot): Slot | null {
  const left = addInv(s, sl.item, sl.qty);
  if (left === 0) return null;
  return { ...sl, qty: left };
}

// ---------------------------------------------------------------- queries for UI and sim
export interface Target { kind: 'struct' | 'poi' | 'vendor' | 'dock' | 'bag' | 'gallery' | 'shrine'; id: string; label: string; x: number; y: number; d: number }
export function targets(s: GameState): Target[] {
  const p = s.actors.player;
  const w = getWorld();
  const out: Target[] = [];
  for (const st of Object.values(s.entities.structures)) {
    const d = dpx(p.x, p.y, st.tx * TILE + 8, st.ty * TILE + 8);
    if (d > 24) continue;
    const def = STRUCTS[st.kind];
    let label = def.name;
    if (st.kind === 'furnace') label = st.burn && st.burn > 0 ? 'Furnace (burning)' : 'Furnace';
    if (st.kind === 'chest') label = 'Open chest';
    if (st.kind === 'bed') label = 'Sleep';
    if (st.kind === 'door') label = st.open ? 'Close door' : 'Open door';
    if (st.kind === 'garden') label = st.plant ? (st.plant.ready ? 'Harvest turnips' : 'Growing…') : 'Plant seeds';
    if (st.kind === 'escrow_chest') label = 'Deposit Ragnarok Cash';
    if (st.kind === 'cart') label = p.hitched === st.id ? 'Release cart' : 'Hitch cart';
    if (st.kind === 'research_desk') label = 'Study desk';
    if (st.kind === 'workbench') label = 'Workbench';
    out.push({ kind: 'struct', id: st.id, label, x: st.tx * TILE + 8, y: st.ty * TILE + 8, d });
  }
  for (const poi of w.pois) {
    const d = dpx(p.x, p.y, poi.x * TILE + 8, poi.y * TILE + 8);
    if (d > 26) continue;
    if (poi.kind === 'chest') {
      const sk = 'poi:' + poi.chest;
      const empty = s.sources[sk]?.hp === 1;
      const vault = CHESTS[poi.chest!].vault;
      out.push({ kind: 'poi', id: poi.id, label: empty ? 'Empty' : vault ? 'Sealed Vault' : `Open ${poi.name}`, x: poi.x * TILE + 8, y: poi.y * TILE + 8, d });
    } else if (poi.kind === 'trade') {
      out.push({ kind: 'vendor', id: poi.id, label: 'Trade with the vendor', x: poi.x * TILE + 8, y: (poi.y + 1) * TILE + 8, d: dpx(p.x, p.y, poi.x * TILE + 8, (poi.y + 1) * TILE + 8) });
    } else if (poi.kind === 'dock') {
      out.push({ kind: 'dock', id: poi.id, label: 'Hold E: board the evacuation skiff', x: poi.x * TILE + 8, y: poi.y * TILE + 8, d });
    } else if (poi.kind === 'gallery') {
      const open = !!s.world.mods[tkey(poi.x, poi.y)]?.open;
      if (!open) out.push({ kind: 'gallery', id: poi.id, label: 'Sealed door: use the rusted key', x: poi.x * TILE + 8, y: poi.y * TILE + 8, d });
    } else if (poi.kind === 'shrine' && poi.elder) {
      const e = s.actors.elders[poi.elder];
      out.push({ kind: 'shrine', id: poi.elder, label: e?.defeated ? 'The shrine is quiet' : e?.awakened ? 'The Elder is awakened' : 'Elder shrine', x: poi.x * TILE + 8, y: poi.y * TILE + 8, d });
    }
  }
  for (const b of s.custody.bags) {
    const d = dpx(p.x, p.y, b.x, b.y);
    if (d <= 24) out.push({ kind: 'bag', id: b.id, label: 'Recover your death bag', x: b.x, y: b.y, d });
  }
  return out.sort((a, b) => a.d - b.d);
}

/** Daylight used by renderer and HUD (0 deep night .. 1 noon). */
export function daylight(s: GameState, now: number): number {
  return phaseInfo(s, now).light;
}

export function cargoWeight(st: Structure): number {
  return (st.slots ?? []).reduce((a, sl) => a + (sl ? ITEMS[sl.item].w * sl.qty : 0), 0);
}

export function heldTotals(s: GameState): Record<string, number> {
  const out: Record<string, number> = {};
  const add = (sl: Maybe | undefined) => { if (sl) out[sl.item] = (out[sl.item] ?? 0) + sl.qty; };
  s.custody.inv.forEach(add);
  Object.values(s.custody.equip).forEach(add);
  s.custody.ground.forEach((g) => { out[g.item] = (out[g.item] ?? 0) + g.qty; });
  s.custody.bags.forEach((b) => b.slots.forEach(add));
  for (const st of Object.values(s.entities.structures)) {
    (st.slots ?? []).forEach(add);
    add(st.fuel); add(st.input); add(st.output);
  }
  return out;
}

export function startNewRun(prev: GameState, now: number, spawn: string, gender: Gender): GameState {
  return startRun(prev, now, spawn, gender);
}


