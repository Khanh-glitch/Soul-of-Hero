// Deterministic island generation. The same seed yields the same coastline, rivers, roads and POIs in every run.
// Gameplay consequences (passability, speed, hazards, harvest eligibility) are derived from these terrain/object ids.
import { MAP_W, MAP_H, WORLD_SEED, valueNoise, fbm, hash2 } from '../core/rng';

export const T = {
  DEEP: 0, SHALLOW: 1, SAND: 2, GRASS: 3, FOREST: 4, ROAD: 5, HILL: 6, CLIFF: 7, MOUNTAIN: 8, MARSH: 9,
  SNOW: 10, TUNDRA: 11, DESERT: 12, SCORCH: 13, SLAG: 14, BRIDGE: 15, RIVER: 16, COBBLE: 17, FLOOR: 18, CAVE: 19, PIER: 20
} as const;

export const O = {
  NONE: 0, OAK: 1, PINE: 2, DEAD: 3, ROCK: 4, IRON: 5, BUSH: 6, REED: 7, MUSH: 8, CACTUS: 9, CRATE: 10, WRECK: 11,
  PILLAR: 12, HOUSE: 13, WELL: 14, SHRINE: 15, DOOR: 16, TRADE: 17, VAULT: 18, CHEST: 19, PAD: 20, FLOWER: 21,
  RUNE: 22, MINE: 23, DOCKPOST: 24, SKIFF: 25, VENDOR: 26
} as const;

export const OBJ_NODE: Record<number, string> = {
  [O.OAK]: 'oak', [O.PINE]: 'pine', [O.DEAD]: 'dead', [O.ROCK]: 'rock', [O.IRON]: 'iron', [O.BUSH]: 'bush',
  [O.REED]: 'reed', [O.MUSH]: 'mush', [O.CACTUS]: 'cactus', [O.CRATE]: 'crate', [O.WRECK]: 'wreck', [O.PILLAR]: 'pillar'
};

/** Objects that block movement when present in the base layer (depleted nodes are cleared through sources). */
export const OBJ_BLOCK = new Set<number>([
  O.OAK, O.PINE, O.DEAD, O.ROCK, O.IRON, O.BUSH, O.CACTUS, O.CRATE, O.WRECK, O.PILLAR, O.HOUSE, O.WELL,
  O.SHRINE, O.DOOR, O.TRADE, O.VAULT, O.CHEST, O.PAD, O.SKIFF, O.VENDOR
]);

export const REGIONS = [
  'Pinewood Reach', 'Frostmarch', 'Highland Glen', 'Reed Marsh', 'Mossbrook Plains', 'Crossroads Plains',
  'Stone Spine', 'Harbor Cove', 'Tideside Cliffs', 'Ashen Wastes', 'Slagworks'
];
const ANCHORS: [number, number][] = [
  [40, 40], [100, 14], [128, 50], [28, 112], [64, 80], [98, 102], [116, 76], [62, 166], [40, 176], [152, 156], [160, 86]
];

export interface Poi { id: string; kind: string; name: string; x: number; y: number; chest?: string; elder?: string }

export interface World {
  seed: number;
  terrain: Uint8Array;
  obj: Uint8Array;
  variant: Uint8Array;
  region: Uint8Array;
  road: Uint8Array;
  elev: Float32Array;
  pois: Poi[];
  spawns: Record<string, { x: number; y: number; name: string }>;
  seaLevel: number;
}

export function terrainBlocks(t: number): boolean {
  return t === T.DEEP || t === T.RIVER || t === T.MOUNTAIN || t === T.CLIFF;
}

/** Movement multiplier by surface. Roads are fast, marsh and wading slow. */
export function terrainSpeed(t: number): number {
  switch (t) {
    case T.ROAD: return 1.12;
    case T.BRIDGE: case T.PIER: case T.COBBLE: return 1.08;
    case T.MARSH: return 0.62;
    case T.SHALLOW: return 0.55;
    case T.SAND: case T.DESERT: case T.SCORCH: return 0.92;
    case T.SNOW: return 0.8;
    case T.CAVE: return 0.95;
    default: return 1;
  }
}

export function surfaceKind(t: number): 'grass' | 'sand' | 'mud' | 'snow' | 'stone' {
  switch (t) {
    case T.SAND: case T.DESERT: case T.SHALLOW: case T.PIER: case T.BRIDGE: return 'sand';
    case T.MARSH: return 'mud';
    case T.SNOW: case T.TUNDRA: return 'snow';
    case T.ROAD: case T.COBBLE: case T.HILL: case T.CAVE: case T.MOUNTAIN: case T.CLIFF: case T.SLAG: return 'stone';
    default: return 'grass';
  }
}

export function regionAt(w: World, tx: number, ty: number): number {
  return w.region[ty * MAP_W + tx];
}

function heapPush(h: number[], k: number[], i: number, key: number): void {
  h.push(i); k.push(key);
  let c = h.length - 1;
  while (c > 0) {
    const p = (c - 1) >> 1;
    if (k[p] <= k[c]) break;
    [h[p], h[c]] = [h[c], h[p]]; [k[p], k[c]] = [k[c], k[p]]; c = p;
  }
}
function heapPop(h: number[], k: number[]): number {
  const top = h[0];
  const li = h.pop()!;
  const lk = k.pop()!;
  if (h.length) {
    h[0] = li; k[0] = lk;
    let c = 0;
    for (;;) {
      const l = 2 * c + 1, r = l + 1;
      let m = c;
      if (l < h.length && k[l] < k[m]) m = l;
      if (r < h.length && k[r] < k[m]) m = r;
      if (m === c) break;
      [h[m], h[c]] = [h[c], h[m]]; [k[m], k[c]] = [k[c], k[m]]; c = m;
    }
  }
  return top;
}

const STEP_COST = (t: number): number => {
  switch (t) {
    case T.DEEP: return -1;
    case T.MOUNTAIN: case T.CLIFF: return 14;
    case T.RIVER: return 4;
    case T.SHALLOW: return 5;
    case T.MARSH: return 3;
    case T.FOREST: return 2.2;
    case T.HILL: return 2.4;
    case T.ROAD: return 0.6;
    case T.BRIDGE: case T.PIER: return 0.7;
    case T.SNOW: case T.TUNDRA: return 1.6;
    case T.SLAG: return 1.9;
    case T.SAND: case T.DESERT: return 1.2;
    default: return 1;
  }
};

/** A* over the terrain grid with road-preference; blocked objects are impassable. */
function astar(terrain: Uint8Array, obj: Uint8Array, sx: number, sy: number, gx: number, gy: number): number[] | null {
  const W = MAP_W, N = MAP_W * MAP_H;
  const start = sy * W + sx, goal = gy * W + gx;
  const g = new Float32Array(N).fill(Infinity);
  const came = new Int32Array(N).fill(-1);
  const hk: number[] = [], kk: number[] = [];
  g[start] = 0;
  heapPush(hk, kk, start, 0);
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  let pops = 0;
  while (hk.length) {
    const cur = heapPop(hk, kk);
    if (cur === goal || ++pops > 260000) break;
    const cx = cur % W, cy = (cur - cx) / W;
    for (const [dx, dy] of dirs) {
      const nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= MAP_H) continue;
      const ni = ny * W + nx;
      const c = STEP_COST(terrain[ni]);
      if (c < 0 || (OBJ_BLOCK.has(obj[ni]))) continue;
      const diag = dx !== 0 && dy !== 0 ? 1.414 : 1;
      const ng = g[cur] + c * diag;
      if (ng < g[ni]) {
        g[ni] = ng;
        came[ni] = cur;
        const h = 0.6 * Math.max(Math.abs(nx - gx), Math.abs(ny - gy));
        heapPush(hk, kk, ni, ng + h);
      }
    }
  }
  if (came[goal] < 0 && goal !== start) return null;
  const path: number[] = [];
  for (let c = goal; c !== -1; c = came[c]) {
    path.push(c);
    if (c === start) break;
  }
  return path.reverse();
}

const dist = (x: number, y: number, ax: number, ay: number): number => Math.hypot(x - ax, y - ay);

export function generateWorld(seed: number = WORLD_SEED): World {
  const W = MAP_W, H = MAP_H, N = W * H;
  const nA = valueNoise(seed + 11), nB = valueNoise(seed + 23), nC = valueNoise(seed + 37);
  const nD = valueNoise(seed + 53), nE = valueNoise(seed + 71), nF = valueNoise(seed + 97);
  const v = new Float32Array(N);
  const moist = new Float32Array(N);
  const copse = new Float32Array(N);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      const cx = ((x + 0.5) / W) * 2 - 1;
      const cy = ((y + 0.5) / H) * 2 - 1;
      const r2 = cx * cx * 0.92 + cy * cy * 1.18;
      const base = fbm(nA, x / 30, y / 30, 5);
      const det = fbm(nB, x / 8, y / 8, 3);
      const bay = fbm(nC, x / 19, y / 19, 3);
      v[i] = base * 0.8 + det * 0.2 - r2 * 0.5 + (bay - 0.5) * 0.3;
      moist[i] = fbm(nD, x / 24, y / 24, 4);
      copse[i] = fbm(nB, x / 9, y / 9, 2);
    }
  }
  // Quantile sea level keeps the island size stable whatever the noise phase.
  const sorted = Float32Array.from(v).sort();
  const sea = sorted[Math.floor(N * 0.555)];
  const range = sorted[N - 1] - sea;
  const hillV = sea + range * 0.34;
  const mtnV = sea + range * 0.6;
  const lowV = sea + range * 0.2;

  // Rivers: descend from highland sources to the sea, leaving lakes in basins.
  const river = new Uint8Array(N);
  const sources: [number, number][] = [[52, 46], [132, 46], [40, 124], [126, 118]];
  const lakeCells: number[] = [];
  // Channel from a basin to the nearest sea along the cheapest route (uphill costs more), so rivers reach the ocean.
  const channelToSea = (sx0: number, sy0: number): number[] => {
    const dd = new Float32Array(W * H).fill(Infinity);
    const pv = new Int32Array(W * H).fill(-1);
    const hk2: number[] = [], kk2: number[] = [];
    const s0 = sy0 * W + sx0;
    dd[s0] = 0;
    heapPush(hk2, kk2, s0, 0);
    let pops2 = 0, goalI = -1;
    while (hk2.length && pops2++ < 120000) {
      const cur = heapPop(hk2, kk2);
      if (v[cur] < sea) { goalI = cur; break; }
      const cx2 = cur % W, cy2 = (cur - cx2) / W;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = cx2 + dx, ny = cy2 + dy;
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const ni = ny * W + nx;
        const nd = dd[cur] + 1 + Math.max(0, v[ni] - v[cur]) * 90;
        if (nd < dd[ni]) { dd[ni] = nd; pv[ni] = cur; heapPush(hk2, kk2, ni, nd); }
      }
    }
    const out: number[] = [];
    for (let c = goalI; c !== -1 && c !== s0; c = pv[c]) out.push(c);
    return out;
  };
  for (const [sx0, sy0] of sources) {
    let best = -1, bx = sx0, by = sy0;
    for (let dy = -14; dy <= 14; dy++) for (let dx = -14; dx <= 14; dx++) {
      const x = sx0 + dx, y = sy0 + dy;
      if (x < 1 || y < 1 || x >= W - 1 || y >= H - 1) continue;
      const val = v[y * W + x];
      if (val > best) { best = val; bx = x; by = y; }
    }
    let x = bx, y = by;
    for (let step = 0; step < 520; step++) {
      const i = y * W + x;
      if (v[i] < sea) break;
      river[i] = 1;
      let nxI = -1, nyI = -1, nv = Infinity;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
        const jitter = (hash2(nx, ny, seed + step) - 0.5) * range * 0.03;
        const val = v[ny * W + nx] + jitter;
        if (val < nv && !river[ny * W + nx]) { nv = val; nxI = nx; nyI = ny; }
      }
      if (nxI < 0 || nv >= v[i]) {
        // Basin: carve a channel to the sea (river continuity), then leave a small lake.
        for (const j of channelToSea(x, y)) river[j] = 1;
        for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
          if (dx * dx + dy * dy > 4) continue;
          const lx = x + dx, ly = y + dy;
          if (lx < 0 || ly < 0 || lx >= W || ly >= H) continue;
          lakeCells.push(ly * W + lx);
        }
        break;
      }
      x = nxI; y = nyI;
    }
  }

  const terrain = new Uint8Array(N);
  const elev = new Float32Array(N);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      elev[i] = v[i];
      let t: number;
      if (v[i] < sea - range * 0.07) t = T.DEEP;
      else if (v[i] < sea) t = T.SHALLOW;
      else if (river[i]) t = T.RIVER;
      else if (v[i] < sea + range * 0.035) t = T.SAND;
      else if (v[i] > mtnV) t = T.MOUNTAIN;
      else if (v[i] > hillV) t = T.HILL;
      else {
        const north = y < 26 + nF(x / 30, y / 30) * 12;
        const desertD = dist(x, y, 152, 156) < 25 + nE(x / 22, y / 22) * 8;
        const slagD = dist(x, y, 160, 88) < 17 + nF(x / 14, y / 14) * 6;
        if (north) t = y < 16 + nF(x / 12, y / 12) * 6 ? T.SNOW : T.TUNDRA;
        else if (desertD) t = T.DESERT;
        else if (slagD) t = T.SLAG;
        else if (moist[i] > 0.6 && v[i] < lowV) t = T.MARSH;
        else if (moist[i] > 0.5) t = T.FOREST;
        else t = T.GRASS;
      }
      terrain[i] = t;
    }
  }
  for (const i of lakeCells) if (terrain[i] !== T.DEEP && terrain[i] !== T.SHALLOW && v[i] < sea + range * 0.12) terrain[i] = T.SHALLOW;
  // Cliff faces: mountain tiles whose southern neighbour is open ground.
  for (let y = 0; y < H - 1; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x;
    if (terrain[i] === T.MOUNTAIN && terrain[i + W] !== T.MOUNTAIN && terrain[i + W] !== T.DEEP && terrain[i + W] !== T.CLIFF) terrain[i] = T.CLIFF;
  }

  const obj = new Uint8Array(N);
  const variant = new Uint8Array(N);
  const region = new Uint8Array(N);
  const road = new Uint8Array(N);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x;
    let best = 0, bd = Infinity;
    for (let a = 0; a < ANCHORS.length; a++) {
      const d = Math.hypot(x - ANCHORS[a][0] + (hash2(x >> 3, y >> 3, seed + a) - 0.5) * 16, y - ANCHORS[a][1] + (hash2(y >> 3, x >> 3, seed + 9 + a) - 0.5) * 16);
      if (d < bd) { bd = d; best = a; }
    }
    region[i] = best;
  }

  const isLand = (t: number): boolean => t !== T.DEEP && t !== T.SHALLOW && t !== T.RIVER && t !== T.MOUNTAIN && t !== T.CLIFF;
  const nearWater = (x: number, y: number, r: number): boolean => {
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const t = terrain[ny * W + nx];
      if (t === T.DEEP || t === T.SHALLOW) return true;
    }
    return false;
  };
  const find = (x0: number, y0: number, pred: (x: number, y: number) => boolean, maxR = 70): { x: number; y: number } => {
    for (let r = 0; r <= maxR; r++) {
      for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x = x0 + dx, y = y0 + dy;
        if (x < 3 || y < 3 || x >= W - 3 || y >= H - 3) continue;
        if (pred(x, y)) return { x, y };
      }
    }
    return { x: x0, y: y0 };
  };
  const at = (x: number, y: number): number => terrain[y * W + x];
  const grassy = (x: number, y: number): boolean => { const t = at(x, y); return (t === T.GRASS || t === T.FOREST || t === T.TUNDRA) && !nearWater(x, y, 3); };
  const coastal = (x: number, y: number): boolean => at(x, y) === T.SAND && nearWater(x, y, 2);

  const pois: Poi[] = [];
  const pad = (x: number, y: number, w: number, h: number, anchor: number): void => {
    for (let dy = 0; dy < h; dy++) for (let dx = 0; dx < w; dx++) {
      const i = (y + dy) * W + (x + dx);
      obj[i] = dx === 0 && dy === 0 ? anchor : O.PAD;
    }
  };
  const plaza = (x: number, y: number, rx: number, ry: number, t: number): void => {
    for (let dy = -ry; dy <= ry; dy++) for (let dx = -rx; dx <= rx; dx++) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const i = ny * W + nx;
      if (terrain[i] === T.DEEP || terrain[i] === T.SHALLOW || terrain[i] === T.RIVER) continue;
      terrain[i] = t;
    }
  };

  // --- Points of interest (placed on suitable generated ground). ---
  const tr = find(96, 100, (x, y) => grassy(x, y) && grassy(x + 3, y) && grassy(x - 3, y) && grassy(x, y + 3));
  plaza(tr.x, tr.y, 3, 2, T.COBBLE);
  pad(tr.x - 1, tr.y - 3, 3, 2, O.TRADE);
  obj[(tr.y + 1) * W + tr.x] = O.VENDOR;
  pois.push({ id: 'trade', kind: 'trade', name: 'Crossroads Trade Post', x: tr.x, y: tr.y });

  const vl = find(64, 80, (x, y) => grassy(x, y) && grassy(x + 6, y + 4) && grassy(x - 6, y - 4));
  plaza(vl.x, vl.y, 3, 3, T.COBBLE);
  const houses: [number, number][] = [[-5, -4], [4, -5], [-5, 2], [5, 2]];
  for (const [hx, hy] of houses) pad(vl.x + hx, vl.y + hy, 2, 2, O.HOUSE);
  obj[vl.y * W + vl.x] = O.WELL;
  obj[(vl.y + 2) * W + (vl.x + 2)] = O.CHEST;
  obj[(vl.y - 2) * W + (vl.x - 2)] = O.CHEST;
  pois.push({ id: 'village', kind: 'village', name: 'Mossbrook', x: vl.x, y: vl.y });
  pois.push({ id: 'village_larder', kind: 'chest', name: 'Mossbrook Larder', x: vl.x + 2, y: vl.y + 2, chest: 'village_larder' });
  pois.push({ id: 'village_well', kind: 'chest', name: 'Well Cache', x: vl.x - 2, y: vl.y - 2, chest: 'village_well' });

  const wr = find(42, 156, (x, y) => coastal(x, y) && coastal(x + 2, y) && at(x + 2, y) === T.SAND);
  pad(wr.x, wr.y, 2, 2, O.WRECK);
  obj[wr.y * W + wr.x + 3] = O.CHEST;
  pois.push({ id: 'wreck', kind: 'wreck', name: 'Drowned Wreck', x: wr.x, y: wr.y });
  pois.push({ id: 'wreck_locker', kind: 'chest', name: 'Wreck Locker', x: wr.x + 3, y: wr.y, chest: 'wreck_locker' });

  const mn = find(88, 52, (x, y) => at(x, y) === T.HILL && terrain[(y + 1) * W + x] === T.MOUNTAIN);
  obj[mn.y * W + mn.x] = O.MINE;
  pois.push({ id: 'mine', kind: 'mine', name: 'Old Mine', x: mn.x, y: mn.y });
  // Deep gallery: a sealed room carved into the mountain behind a door.
  const gx = mn.x + 1, gy = mn.y + 1;
  for (let dy = 0; dy < 4; dy++) for (let dx = 0; dx < 6; dx++) {
    const nx = gx + 1 + dx, ny = gy + dy;
    if (nx >= W - 2 || ny >= H - 2) continue;
    const i = ny * W + nx;
    terrain[i] = T.CAVE;
    obj[i] = O.NONE;
  }
  obj[gy * W + gx] = O.DOOR;
  obj[(gy + 2) * W + (gx + 5)] = O.CHEST;
  obj[(gy + 1) * W + (gx + 3)] = O.IRON;
  obj[(gy + 3) * W + (gx + 2)] = O.IRON;
  pois.push({ id: 'gallery', kind: 'gallery', name: 'Sealed Gallery Door', x: gx, y: gy });
  pois.push({ id: 'mine_deep', kind: 'chest', name: 'Deep Gallery Chest', x: gx + 5, y: gy + 2, chest: 'mine_deep' });

  const ru = find(110, 126, (x, y) => grassy(x, y) && grassy(x + 4, y) && grassy(x - 4, y));
  const pillars: [number, number][] = [[-3, -3], [0, -4], [3, -3], [-4, 0], [4, 0], [-3, 3], [0, 4], [3, 3]];
  for (const [px, py] of pillars) obj[(ru.y + py) * W + (ru.x + px)] = O.PILLAR;
  obj[ru.y * W + ru.x] = O.CHEST;
  pois.push({ id: 'ruin', kind: 'ruin', name: 'Ruined Furnace', x: ru.x, y: ru.y });
  pois.push({ id: 'ruin_reliquary', kind: 'chest', name: 'Ember Reliquary', x: ru.x, y: ru.y, chest: 'ruin_reliquary' });

  const vt = find(158, 88, (x, y) => at(x, y) === T.SLAG && at(x + 1, y) === T.SLAG && at(x, y + 2) === T.SLAG);
  pad(vt.x, vt.y, 3, 2, O.VAULT);
  obj[(vt.y + 2) * W + vt.x] = O.CHEST;
  pois.push({ id: 'vault', kind: 'vault', name: 'Industrial Ruin', x: vt.x, y: vt.y });
  pois.push({ id: 'slag_vault', kind: 'chest', name: 'Sealed Vault', x: vt.x, y: vt.y + 2, chest: 'slag_vault' });

  const dk = find(176, 118, (x, y) => at(x, y) === T.SAND && nearWater(x, y, 1) && isLand(at(x - 1, y)) && at(x + 6, y) !== T.MOUNTAIN);
  for (let k = 1; k <= 6; k++) { const i = dk.y * W + dk.x + k; if (i < N && terrain[i] !== T.MOUNTAIN && terrain[i] !== T.CLIFF) terrain[i] = T.PIER; }
  obj[dk.y * W + dk.x + 6] = O.SKIFF;
  obj[dk.y * W + dk.x] = O.DOCKPOST;
  pois.push({ id: 'dock', kind: 'dock', name: 'Evacuation Dock', x: dk.x + 6, y: dk.y });

  const shrineSpec: [string, string, string, (x: number, y: number) => boolean, number, number][] = [
    ['shrine_frost', 'frost', 'Frostmarch Shrine', (x, y) => at(x, y) === T.TUNDRA || at(x, y) === T.SNOW, 100, 22],
    ['shrine_ember', 'ember', 'Ashen Shrine', (x, y) => at(x, y) === T.DESERT, 150, 160],
    ['shrine_mire', 'mire', 'Mire Shrine', (x, y) => at(x, y) === T.MARSH, 22, 110],
    ['shrine_stone', 'stone', 'Spine Shrine', (x, y) => at(x, y) === T.HILL && terrain[(y + 1) * W + x] === T.MOUNTAIN, 118, 74],
    ['shrine_tide', 'tide', 'Tide Shrine', (x, y) => at(x, y) === T.SAND && nearWater(x, y, 3), 72, 184],
    ['shrine_grove', 'grove', 'Ashen Grove Shrine', (x, y) => at(x, y) === T.FOREST && !nearWater(x, y, 4), 30, 30]
  ];
  for (const [id, elder, name, pred, sx0, sy0] of shrineSpec) {
    const s = find(sx0, sy0, (x, y) => pred(x, y) && x > 6 && y > 6 && x < W - 6 && y < H - 6);
    plaza(s.x, s.y, 2, 2, T.FLOOR);
    obj[s.y * W + s.x] = O.SHRINE;
    const runes: [number, number][] = [[-4, -2], [4, -2], [-4, 2], [4, 2], [0, -4], [0, 4]];
    for (const [rx, ry] of runes) {
      const nx = s.x + rx, ny = s.y + ry;
      if (nx > 0 && ny > 0 && nx < W - 1 && ny < H - 1) obj[ny * W + nx] = O.RUNE;
    }
    pois.push({ id, kind: 'shrine', name, x: s.x, y: s.y, elder });
  }

  const spawnSpec: [string, string, number, number][] = [
    ['pinewood', 'Pinewood Clearing', 46, 44], ['marsh', 'Reed Marsh Edge', 36, 116],
    ['harbor', 'Harbor Cove', 66, 164], ['glen', 'Highland Glen', 126, 48]
  ];
  const spawns: World['spawns'] = {};
  for (const [id, name, sx0, sy0] of spawnSpec) {
    const s = find(sx0, sy0, (x, y) => grassy(x, y) && at(x, y) !== T.TUNDRA && !nearWater(x, y, 4) && obj[y * W + x] === 0, 40);
    spawns[id] = { x: s.x, y: s.y, name };
  }

  // Roads: connect human places. Passes cut through mountains and bridges span rivers and fords.
  const link = (a: string, b: string): void => {
    const pa = pois.find((p) => p.id === a), pb = pois.find((p) => p.id === b);
    const sa = pa ? { x: pa.x, y: pa.y } : spawns[a];
    const sb = pb ? { x: pb.x, y: pb.y } : spawns[b];
    if (!sa || !sb) return;
    const path = astar(terrain, obj, sa.x, sa.y, sb.x, sb.y);
    if (!path) return;
    for (const i of path) {
      const t = terrain[i];
      if (t === T.RIVER || t === T.SHALLOW) terrain[i] = T.BRIDGE;
      else if (t === T.MOUNTAIN || t === T.CLIFF) terrain[i] = T.ROAD;
      else if (t !== T.BRIDGE && t !== T.COBBLE && t !== T.PIER && t !== T.FLOOR) terrain[i] = T.ROAD;
      road[i] = 1;
    }
  };
  link('trade', 'village');
  link('trade', 'wreck');
  link('trade', 'ruin');
  link('trade', 'vault');
  link('trade', 'dock');
  link('trade', 'harbor');
  link('trade', 'glen');
  link('village', 'pinewood');
  link('village', 'marsh');
  link('village', 'mine');
  link('mine', 'glen');
  link('ruin', 'shrine_ember');
  link('marsh', 'shrine_mire');
  link('pinewood', 'shrine_grove');
  link('glen', 'shrine_frost');
  link('mine', 'shrine_stone');
  link('wreck', 'shrine_tide');
  link('trade', 'shrine_stone');
  link('village', 'shrine_frost');
  link('trade', 'shrine_ember');
  link('marsh', 'harbor');
  link('harbor', 'wreck');

  // Natural world: trees, rocks, bushes and ruins scattered by biome and copse noise.
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x;
    if (obj[i] !== O.NONE || road[i] || terrain[i] === T.ROAD) continue;
    const r = hash2(x, y, seed + 5);
    const t = terrain[i];
    const near = (q: number): boolean => { for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; if (obj[ny * W + nx] === q) return true; } return false; };
    switch (t) {
      case T.FOREST:
        if (r < 0.34) obj[i] = O.OAK;
        else if (r < 0.37) obj[i] = O.MUSH;
        else if (r < 0.42) obj[i] = O.BUSH;
        else if (r < 0.43) obj[i] = O.DEAD;
        break;
      case T.GRASS:
        if (copse[i] > 0.6 && r < 0.2) obj[i] = O.OAK;
        else if (r < 0.012) obj[i] = O.ROCK;
        else if (r < 0.03) obj[i] = O.BUSH;
        else if (r < 0.085) obj[i] = O.FLOWER;
        break;
      case T.TUNDRA:
        if (r < 0.07) obj[i] = O.PINE;
        else if (r < 0.085) obj[i] = O.ROCK;
        break;
      case T.SNOW:
        if (r < 0.025) obj[i] = O.PINE;
        break;
      case T.MARSH:
        if (r < 0.26) obj[i] = O.REED;
        else if (r < 0.28) obj[i] = O.DEAD;
        break;
      case T.HILL:
        if (r < 0.1) obj[i] = O.ROCK;
        else if (r < 0.108) obj[i] = O.BUSH;
        else if (r < 0.112 && near(O.ROCK)) obj[i] = O.IRON;
        break;
      case T.MOUNTAIN:
        if (r < 0.0 && nearWater(x, y, 0)) obj[i] = O.NONE;
        break;
      case T.DESERT:
        if (r < 0.022) obj[i] = O.CACTUS;
        else if (r < 0.03) obj[i] = O.ROCK;
        else if (r < 0.034) obj[i] = O.PILLAR;
        break;
      case T.SLAG:
        if (r < 0.04) obj[i] = O.DEAD;
        else if (r < 0.055) obj[i] = O.ROCK;
        else if (r < 0.062) obj[i] = O.CRATE;
        break;
      case T.SAND:
        if (r < 0.006 && !nearWater(x, y, 1)) obj[i] = O.ROCK;
        break;
      default:
        break;
    }
    // Iron veins gather around the old mine.
    if (dist(x, y, mn.x, mn.y) < 9 && t === T.HILL && r < 0.07) obj[i] = O.IRON;
  }
  // Roadside salvage: crates sit on the shoulder of roads (C02 physical scrap source).
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    const i = y * W + x;
    if (!road[i] || hash2(x, y, seed + 77) > 0.035) continue;
    for (const [dx, dy] of [[2, 0], [-2, 0], [0, 2], [0, -2]]) {
      const j = (y + dy) * W + (x + dx);
      if (obj[j] === O.NONE && !road[j] && terrain[j] !== T.RIVER && terrain[j] !== T.SHALLOW && terrain[j] !== T.DEEP && terrain[j] !== T.MOUNTAIN) { obj[j] = O.CRATE; break; }
    }
  }
  // Clear the trade post, spawns and village plaza of stray blockers.
  for (const sp of Object.values(spawns)) {
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const j = (sp.y + dy) * W + (sp.x + dx);
      if (obj[j] === O.OAK || obj[j] === O.ROCK || obj[j] === O.PINE) obj[j] = O.NONE;
    }
  }
  for (let i = 0; i < N; i++) variant[i] = Math.floor(hash2(i % W, (i / W) | 0, seed + 3) * 4);

  return { seed, terrain, obj, variant, region, road, elev, pois, spawns, seaLevel: sea };
}

let cached: World | null = null;
export function getWorld(): World {
  if (!cached) cached = generateWorld(WORLD_SEED);
  return cached;
}

/** Diagnostics used by tests and the evidence report. */
export function worldSummary(w: World): Record<string, number> {
  const counts: Record<string, number> = {};
  for (let i = 0; i < w.terrain.length; i++) counts[`t${w.terrain[i]}`] = (counts[`t${w.terrain[i]}`] || 0) + 1;
  return counts;
}
