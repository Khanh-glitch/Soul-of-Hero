// Runtime catalogs. Numbers marked in balance.v1.json are editable; gameplay relationships live here.
// Status legend: LOCKED_CANON (Bible [CHỐT]) · PROPOSED_MECHANISM ([ĐỀ XUẤT]) · TUNABLE_BALANCE · NEEDS_MEASUREMENT ([CẦN ĐO]).
import balance from './balance.v1.json';

export const BAL = balance;

export type ItemCat = 'material' | 'food' | 'tool' | 'weapon' | 'armor' | 'ammo' | 'pack' | 'core' | 'cash' | 'key' | 'stone' | 'blueprint' | 'kit' | 'specimen';

export interface ItemDef {
  name: string;
  desc: string;
  cat: ItemCat;
  stack: number;
  w: number;
  icon: string;
  col?: string;
  dmg?: number; reach?: number; arc?: number; swing?: number;
  harvest?: 'chop' | 'mine' | 'cut';
  power?: number; dur?: number; ranged?: number;
  slot?: 'weapon' | 'armor' | 'pack';
  armor?: number; slots?: number;
  food?: number; heal?: number; cure?: number;
  fuel?: number;
  core?: 'ember'; charges?: number;
  kit?: 'claim' | 'escrow' | 'cart';
  cash?: boolean;
  light?: boolean;
}

export const ITEMS: Record<string, ItemDef> = {
  wood: { name: 'Wood', desc: 'Split logs. Planks, torches and furnace fuel.', cat: 'material', stack: 50, w: 1, icon: 'log', fuel: 15 },
  stone: { name: 'Stone', desc: 'Dense grey rock for walls, furnaces and stone tools.', cat: 'material', stack: 50, w: 1, icon: 'stone' },
  fiber: { name: 'Plant Fiber', desc: 'Tough reed strands. Rope, cloth and bindings.', cat: 'material', stack: 50, w: 1, icon: 'fiber' },
  planks: { name: 'Planks', desc: 'Squared timber for structures. Burns briefly.', cat: 'material', stack: 40, w: 1, icon: 'plank', fuel: 10 },
  rope: { name: 'Rope', desc: 'Twisted fiber. Binds tools, carts and roofs.', cat: 'material', stack: 30, w: 1, icon: 'rope' },
  cloth: { name: 'Cloth', desc: 'Woven fiber. Bedding, bandages and packs.', cat: 'material', stack: 30, w: 1, icon: 'cloth' },
  hide: { name: 'Hide', desc: 'Cured animal skin. Leather armour and packs.', cat: 'material', stack: 20, w: 1, icon: 'hide' },
  scrap: { name: 'Road Scrap', desc: 'Salvaged metal from roadside crates. Works into Spares.', cat: 'material', stack: 30, w: 1, icon: 'scrap' },
  spares: { name: 'Spares', desc: 'Run-local mechanical parts. Research and advanced work.', cat: 'material', stack: 20, w: 1, icon: 'spare' },
  iron_ore: { name: 'Iron Ore', desc: 'Rust-streaked ore. Needs a smelter and charcoal.', cat: 'material', stack: 30, w: 1, icon: 'ore' },
  iron_ingot: { name: 'Iron Ingot', desc: 'Refined iron bar.', cat: 'material', stack: 30, w: 1, icon: 'ingot' },
  charcoal: { name: 'Charcoal', desc: 'Long-burning fuel. Forty seconds of furnace fire.', cat: 'material', stack: 30, w: 1, icon: 'char', fuel: 40 },
  herb: { name: 'Bitterleaf', desc: 'Medicinal herb that draws out toxin.', cat: 'material', stack: 20, w: 1, icon: 'herb' },
  gel: { name: 'Slime Gel', desc: 'Sticky and surprisingly useful in potions.', cat: 'material', stack: 20, w: 1, icon: 'gel' },
  specimen: { name: 'Wisp Specimen', desc: 'A sealed marsh specimen. Eligible for study at a desk.', cat: 'specimen', stack: 5, w: 1, icon: 'specimen' },
  blueprint_torn: { name: 'Torn Blueprint', desc: 'Half a schematic. Study it to learn a recipe.', cat: 'blueprint', stack: 10, w: 1, icon: 'bp' },
  seed_turnip: { name: 'Turnip Seed', desc: 'Plant on a garden plot.', cat: 'material', stack: 40, w: 1, icon: 'seed' },
  turnip: { name: 'Turnip', desc: 'Crisp and earthy.', cat: 'food', stack: 30, w: 1, icon: 'turnip', food: 12 },
  berry: { name: 'Wild Berries', desc: 'Sweet, quick energy.', cat: 'food', stack: 40, w: 1, icon: 'berry', food: 8 },
  mushroom: { name: 'Brown Cap', desc: 'Edible when cooked. Raw, it sits heavy in the stomach.', cat: 'food', stack: 20, w: 1, icon: 'mush', food: 6 },
  raw_meat: { name: 'Raw Meat', desc: 'Cook at a furnace before eating.', cat: 'food', stack: 20, w: 1, icon: 'rawmeat', food: 4 },
  cooked_meat: { name: 'Cooked Meat', desc: 'Solid, savoury, reliable.', cat: 'food', stack: 20, w: 1, icon: 'meat', food: 30 },
  ration: { name: 'Trail Ration', desc: 'Packed meal. Feeds and mends.', cat: 'food', stack: 10, w: 1, icon: 'ration', food: 55, heal: 8 },
  bandage: { name: 'Bandage', desc: 'Clean cloth with bitterleaf. Stops bleeding.', cat: 'food', stack: 10, w: 1, icon: 'bandage', heal: 25 },
  potion_heal: { name: 'Mending Draught', desc: 'Heals and cures toxin.', cat: 'food', stack: 10, w: 1, icon: 'potion', heal: 50, cure: 25 },
  arrow: { name: 'Arrow', desc: 'Stone-tipped shaft.', cat: 'ammo', stack: 60, w: 1, icon: 'arrow' },
  torch: { name: 'Torch', desc: 'Lights the way. Burns fifteen seconds of fuel.', cat: 'tool', stack: 10, w: 1, icon: 'torch', fuel: 15, light: true },
  lantern: { name: 'Lantern', desc: 'Steady light that carries well at night.', cat: 'tool', stack: 1, w: 2, icon: 'lantern', light: true },
  knife_stone: { name: 'Stone Knife', desc: 'Light and fast. Cuts brush and wood well enough.', cat: 'weapon', stack: 1, w: 1, icon: 'knife', col: 'stone', dmg: 4, reach: 20, arc: 95, swing: 1, harvest: 'cut', power: 1, dur: 40, slot: 'weapon' },
  knife_iron: { name: 'Iron Knife', desc: 'Keen edge; the reliable sidearm.', cat: 'weapon', stack: 1, w: 1, icon: 'knife', col: 'iron', dmg: 7, reach: 20, arc: 95, swing: 0.9, harvest: 'cut', power: 1.5, dur: 80, slot: 'weapon' },
  axe_stone: { name: 'Stone Axe', desc: 'Heavy head, honest chop.', cat: 'tool', stack: 1, w: 2, icon: 'axe', col: 'stone', dmg: 6, reach: 22, arc: 105, swing: 1.2, harvest: 'chop', power: 1.5, dur: 30, slot: 'weapon' },
  axe_iron: { name: 'Iron Axe', desc: 'Bites deep into trunks.', cat: 'tool', stack: 1, w: 2, icon: 'axe', col: 'iron', dmg: 10, reach: 22, arc: 105, swing: 1.2, harvest: 'chop', power: 2.6, dur: 70, slot: 'weapon' },
  pick_stone: { name: 'Stone Pick', desc: 'Breaks rock. Cannot bite iron veins.', cat: 'tool', stack: 1, w: 2, icon: 'pick', col: 'stone', dmg: 4, reach: 22, arc: 95, swing: 1.3, harvest: 'mine', power: 1.5, dur: 30, slot: 'weapon' },
  pick_iron: { name: 'Iron Pick', desc: 'Opens iron veins and deep stone.', cat: 'tool', stack: 1, w: 2, icon: 'pick', col: 'iron', dmg: 7, reach: 22, arc: 95, swing: 1.2, harvest: 'mine', power: 2.6, dur: 70, slot: 'weapon' },
  spear_stone: { name: 'Stone Spear', desc: 'Long reach. Slow to recover.', cat: 'weapon', stack: 1, w: 2, icon: 'spear', col: 'stone', dmg: 7, reach: 34, arc: 55, swing: 1.3, dur: 25, slot: 'weapon' },
  bow_wood: { name: 'Longbow', desc: 'Shoots arrows at whatever you aim at.', cat: 'weapon', stack: 1, w: 2, icon: 'bow', ranged: 9, dur: 45, slot: 'weapon' },
  armor_hide: { name: 'Hide Jerkin', desc: 'Soft leather. Turns aside a fifth of blows.', cat: 'armor', stack: 1, w: 2, icon: 'armor', col: 'hide', armor: 0.2, dur: 40, slot: 'armor' },
  armor_iron: { name: 'Iron Cuirass', desc: 'Heavy plate. A third of every blow stops here.', cat: 'armor', stack: 1, w: 4, icon: 'armor', col: 'iron', armor: 0.35, dur: 90, slot: 'armor' },
  backpack: { name: 'Field Pack', desc: 'Eight extra slots on your back.', cat: 'pack', stack: 1, w: 2, icon: 'pack', slots: 8, slot: 'pack' },
  claim_stake: { name: 'Home Stake', desc: 'Claims a nine-tile home plot. Place it on open land.', cat: 'kit', stack: 3, w: 1, icon: 'claim', kit: 'claim' },
  escrow_chest: { name: 'Escrow Chest', desc: 'Purchased with Ragnarok Cash. Place on owned land, then deposit cash to secure it.', cat: 'kit', stack: 1, w: 3, icon: 'escrow', kit: 'escrow' },
  cart_kit: { name: 'Cart Kit', desc: 'Assemble into a hauling cart. Roads make it fly.', cat: 'kit', stack: 1, w: 4, icon: 'cartkit', kit: 'cart' },
  ember_core: { name: 'Ember Core', desc: 'Charged relic. Cast it at once; it carries three charges.', cat: 'core', stack: 1, w: 1, icon: 'core', core: 'ember', charges: 3 },
  ragnarok_cash: { name: 'Ragnarok Cash', desc: 'Physical currency minted only in the final seventy-two hours. Carry it home to secure it.', cat: 'cash', stack: 99, w: 0, icon: 'cash', cash: true },
  rusted_key: { name: 'Rusted Key', desc: 'Opens a sealed gallery door.', cat: 'key', stack: 1, w: 0, icon: 'key' },
  stone_frost: { name: 'Frost Stone', desc: 'Cold blue heart of the Frost Elder.', cat: 'stone', stack: 1, w: 1, icon: 'estone', col: '#7fd6ff' },
  stone_ember: { name: 'Ember Stone', desc: 'Warm core of the Ember Elder.', cat: 'stone', stack: 1, w: 1, icon: 'estone', col: '#ff8a3d' },
  stone_marsh: { name: 'Mire Stone', desc: 'Green-black heart of the Mire Mother.', cat: 'stone', stack: 1, w: 1, icon: 'estone', col: '#9be05c' },
  stone_mountain: { name: 'Graven Stone', desc: 'Dense heartstone of the Mountain Elder.', cat: 'stone', stack: 1, w: 1, icon: 'estone', col: '#d5c2a0' },
  stone_tide: { name: 'Tide Stone', desc: 'Pearl-blue heart of the Drowned Queen.', cat: 'stone', stack: 1, w: 1, icon: 'estone', col: '#5fe3e8' },
  stone_grove: { name: 'Grove Stone', desc: 'Living bark-heart of the Ashen Oak.', cat: 'stone', stack: 1, w: 1, icon: 'estone', col: '#c58cff' }
};

export interface Recipe {
  id: string;
  name: string;
  out: [string, number];
  inp: [string, number][];
  st: 'hand' | 'bench' | 'furn';
  secs?: number;
  known?: boolean;
  study?: [string, number][];
  studyAlt?: [string, number][];
}

export const RECIPES: Recipe[] = [
  { id: 'planks', name: 'Planks', out: ['planks', 2], inp: [['wood', 2]], st: 'hand', known: true },
  { id: 'rope', name: 'Rope', out: ['rope', 1], inp: [['fiber', 3]], st: 'hand', known: true },
  { id: 'cloth', name: 'Cloth', out: ['cloth', 1], inp: [['fiber', 4]], st: 'bench', known: true },
  { id: 'spares', name: 'Spares', out: ['spares', 1], inp: [['scrap', 3]], st: 'bench', known: true },
  { id: 'knife_stone', name: 'Stone Knife', out: ['knife_stone', 1], inp: [['stone', 1], ['wood', 1], ['fiber', 2]], st: 'hand', known: true },
  { id: 'axe_stone', name: 'Stone Axe', out: ['axe_stone', 1], inp: [['stone', 2], ['wood', 2], ['fiber', 2]], st: 'hand', known: true },
  { id: 'pick_stone', name: 'Stone Pick', out: ['pick_stone', 1], inp: [['stone', 2], ['wood', 2], ['fiber', 2]], st: 'hand', known: true },
  { id: 'spear_stone', name: 'Stone Spear', out: ['spear_stone', 1], inp: [['stone', 1], ['wood', 3], ['rope', 1]], st: 'hand', known: true },
  { id: 'bow_wood', name: 'Longbow', out: ['bow_wood', 1], inp: [['wood', 3], ['rope', 2]], st: 'hand', known: true },
  { id: 'arrow', name: 'Arrows x4', out: ['arrow', 4], inp: [['stone', 1], ['wood', 1], ['fiber', 1]], st: 'hand', known: true },
  { id: 'torch', name: 'Torches x2', out: ['torch', 2], inp: [['wood', 1], ['fiber', 2]], st: 'hand', known: true },
  { id: 'bandage', name: 'Bandages x2', out: ['bandage', 2], inp: [['cloth', 1], ['herb', 1]], st: 'hand', known: true },
  { id: 'ration', name: 'Trail Ration', out: ['ration', 1], inp: [['cooked_meat', 1], ['turnip', 1], ['berry', 1]], st: 'hand', known: true },
  { id: 'claim_stake', name: 'Home Stake', out: ['claim_stake', 1], inp: [['planks', 2], ['stone', 2]], st: 'hand', known: true },
  { id: 'charcoal', name: 'Charcoal', out: ['charcoal', 1], inp: [['wood', 3]], st: 'furn', secs: 8, known: true },
  { id: 'smelt_iron', name: 'Smelt Iron', out: ['iron_ingot', 1], inp: [['iron_ore', 1]], st: 'furn', secs: 10, known: true },
  { id: 'cook_meat', name: 'Cook Meat', out: ['cooked_meat', 1], inp: [['raw_meat', 1]], st: 'furn', secs: 6, known: true },
  { id: 'cart_kit', name: 'Cart Kit', out: ['cart_kit', 1], inp: [['planks', 6], ['rope', 2], ['iron_ingot', 2]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 2]], studyAlt: [['specimen', 1], ['spares', 2]] },
  { id: 'knife_iron', name: 'Iron Knife', out: ['knife_iron', 1], inp: [['iron_ingot', 2], ['planks', 1], ['rope', 1]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 1]], studyAlt: [['specimen', 1], ['spares', 1]] },
  { id: 'axe_iron', name: 'Iron Axe', out: ['axe_iron', 1], inp: [['iron_ingot', 3], ['planks', 2], ['rope', 1]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 2]], studyAlt: [['specimen', 1], ['spares', 2]] },
  { id: 'pick_iron', name: 'Iron Pick', out: ['pick_iron', 1], inp: [['iron_ingot', 3], ['planks', 2], ['rope', 1]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 2]], studyAlt: [['specimen', 1], ['spares', 2]] },
  { id: 'armor_hide', name: 'Hide Jerkin', out: ['armor_hide', 1], inp: [['hide', 4], ['rope', 2], ['cloth', 1]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 1]], studyAlt: [['specimen', 1], ['spares', 1]] },
  { id: 'armor_iron', name: 'Iron Cuirass', out: ['armor_iron', 1], inp: [['iron_ingot', 5], ['hide', 2], ['rope', 1]], st: 'bench', study: [['blueprint_torn', 2], ['spares', 2]], studyAlt: [['specimen', 1], ['spares', 3]] },
  { id: 'backpack', name: 'Field Pack', out: ['backpack', 1], inp: [['hide', 3], ['rope', 3], ['cloth', 2]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 1]], studyAlt: [['specimen', 1], ['spares', 1]] },
  { id: 'lantern', name: 'Lantern', out: ['lantern', 1], inp: [['iron_ingot', 1], ['torch', 2], ['cloth', 1]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 1]], studyAlt: [['specimen', 1], ['spares', 1]] },
  { id: 'potion_heal', name: 'Mending Draught', out: ['potion_heal', 1], inp: [['herb', 2], ['gel', 1], ['berry', 2]], st: 'bench', study: [['blueprint_torn', 1], ['spares', 1]], studyAlt: [['specimen', 1], ['spares', 1]] }
];

export interface StructDef {
  name: string;
  desc: string;
  cost: [string, number][];
  hp: number;
  block: boolean;
  station?: 'bench' | 'furn' | 'desk' | 'chest' | 'bed' | 'garden' | 'escrow' | 'door' | 'torch' | 'cart' | 'claim' | 'vendor';
  cap?: number;
  roof?: boolean;
  floor?: boolean;
  kit?: string;
}

export const STRUCTS: Record<string, StructDef> = {
  floor: { name: 'Plank Floor', desc: 'Walkable boards. Needed under roofs.', cost: [['planks', 1]], hp: 30, block: false, floor: true },
  wall_wood: { name: 'Wood Wall', desc: 'Stops creatures and weather. Boars can break it.', cost: [['planks', 3]], hp: 60, block: true },
  wall_stone: { name: 'Stone Wall', desc: 'Thick and patient.', cost: [['stone', 4]], hp: 160, block: true },
  door: { name: 'Door', desc: 'Open or shut with E.', cost: [['planks', 2]], hp: 50, block: true, station: 'door' },
  roof: { name: 'Roof', desc: 'Covers a tile. Standing under a roof is shelter.', cost: [['planks', 2], ['rope', 1]], hp: 40, block: false, roof: true },
  bed: { name: 'Bed', desc: 'Sleep to restore and set your respawn point.', cost: [['planks', 3], ['cloth', 2], ['hide', 1]], hp: 20, block: true, station: 'bed' },
  chest: { name: 'Storage Chest', desc: 'Sixteen slots of physical storage.', cost: [['planks', 4], ['rope', 1]], hp: 30, block: true, station: 'chest', cap: 16 },
  workbench: { name: 'Workbench', desc: 'Crafting station for bench recipes.', cost: [['planks', 4], ['rope', 2]], hp: 30, block: true, station: 'bench' },
  furnace: { name: 'Furnace', desc: 'Smelts and cooks. Burns fuel while it works.', cost: [['stone', 10], ['planks', 1]], hp: 80, block: true, station: 'furn' },
  research_desk: { name: 'Study Desk', desc: 'Study torn blueprints with Spares or a specimen.', cost: [['planks', 4], ['cloth', 2]], hp: 30, block: true, station: 'desk' },
  garden: { name: 'Garden Plot', desc: 'Turnips grow here. Rain speeds them.', cost: [['planks', 2], ['stone', 1]], hp: 20, block: false, station: 'garden' },
  torch_post: { name: 'Torch Post', desc: 'Warm light at night.', cost: [['wood', 2], ['fiber', 2]], hp: 25, block: true, station: 'torch' },
  escrow_chest: { name: 'Escrow Chest', desc: 'Ragnarok Cash goes in here and is secured to your profile.', cost: [], hp: 90, block: true, station: 'escrow', kit: 'escrow_chest' },
  cart: { name: 'Hauling Cart', desc: 'Carries cargo. Hitch with E. Heavy off-road.', cost: [], hp: 60, block: false, station: 'cart', cap: 12, kit: 'cart_kit' },
  claim_marker: { name: 'Home Stake', desc: 'Marks owned land.', cost: [], hp: 40, block: true, station: 'claim', kit: 'claim_stake' }
};

export interface NodeDef {
  name: string;
  hp: number;
  kind: 'chop' | 'mine' | 'cut' | 'any';
  need: number;
  yields: [string, number, number][];
  regrowS: number;
  finite?: boolean;
  snd: 'wood' | 'stone' | 'soft';
}

export const NODES: Record<string, NodeDef> = {
  oak: { name: 'Oak', hp: 6, kind: 'chop', need: 0, yields: [['wood', 3, 5]], regrowS: 900, snd: 'wood' },
  pine: { name: 'Pine', hp: 5, kind: 'chop', need: 0, yields: [['wood', 3, 4]], regrowS: 900, snd: 'wood' },
  dead: { name: 'Dead Tree', hp: 2, kind: 'any', need: 0, yields: [['wood', 1, 2]], regrowS: 0, finite: true, snd: 'wood' },
  rock: { name: 'Rock', hp: 5, kind: 'mine', need: 0, yields: [['stone', 2, 4]], regrowS: 1200, snd: 'stone' },
  iron: { name: 'Iron Vein', hp: 7, kind: 'mine', need: 2.5, yields: [['iron_ore', 2, 3]], regrowS: 2400, snd: 'stone' },
  bush: { name: 'Berry Bush', hp: 1, kind: 'any', need: 0, yields: [['berry', 2, 3], ['fiber', 0, 1]], regrowS: 420, snd: 'soft' },
  reed: { name: 'Reeds', hp: 1, kind: 'any', need: 0, yields: [['fiber', 1, 3]], regrowS: 300, snd: 'soft' },
  mush: { name: 'Brown Caps', hp: 1, kind: 'any', need: 0, yields: [['mushroom', 1, 2]], regrowS: 600, snd: 'soft' },
  cactus: { name: 'Cactus', hp: 3, kind: 'cut', need: 0, yields: [['fiber', 1, 2], ['herb', 0, 1]], regrowS: 900, snd: 'soft' },
  crate: { name: 'Scrap Crate', hp: 2, kind: 'any', need: 0, yields: [['scrap', 2, 4]], regrowS: 0, finite: true, snd: 'wood' },
  wreck: { name: 'Wreck Timber', hp: 8, kind: 'any', need: 0, yields: [['planks', 1, 3], ['rope', 1, 2], ['cloth', 0, 2], ['scrap', 1, 3]], regrowS: 0, finite: true, snd: 'wood' },
  pillar: { name: 'Ruin Pillar', hp: 8, kind: 'mine', need: 1, yields: [['stone', 2, 4], ['blueprint_torn', 0, 1]], regrowS: 0, finite: true, snd: 'stone' }
};

export interface CreatureDef {
  name: string;
  hp: number;
  dmg: number;
  spd: number;
  sense: number;
  leash: number;
  loot: [string, number, number, number][];
  tracker?: boolean;
  night?: boolean;
  tint: string;
}

export const CREATURES: Record<string, CreatureDef> = {
  slime: { name: 'Green Slime', hp: 9, dmg: 6, spd: 46, sense: 58, leash: 70, loot: [['gel', 1, 2, 80], ['fiber', 1, 1, 30]], tint: '#6ccf5a' },
  wolf: { name: 'Grey Wolf', hp: 18, dmg: 10, spd: 52, sense: 84, leash: 150, tracker: true, loot: [['hide', 1, 2, 90], ['raw_meat', 1, 2, 80]], tint: '#8a8076' },
  boar: { name: 'Razortusk Boar', hp: 26, dmg: 12, spd: 40, sense: 70, leash: 110, loot: [['raw_meat', 2, 3, 100], ['hide', 1, 1, 70]], tint: '#8a5a3c' },
  bat: { name: 'Cave Bat', hp: 7, dmg: 5, spd: 56, sense: 64, leash: 90, night: true, loot: [['hide', 1, 1, 30]], tint: '#4a3c60' },
  archer: { name: 'Bone Archer', hp: 20, dmg: 8, spd: 30, sense: 150, leash: 120, loot: [['arrow', 2, 4, 90], ['scrap', 1, 2, 60]], tint: '#e4dcc4' },
  crab: { name: 'Tidecrab', hp: 14, dmg: 7, spd: 34, sense: 46, leash: 60, loot: [['raw_meat', 1, 1, 90], ['scrap', 1, 1, 30]], tint: '#d6543c' },
  wisp: { name: 'Marsh Wisp', hp: 10, dmg: 6, spd: 28, sense: 96, leash: 90, loot: [['specimen', 1, 1, 45], ['herb', 1, 1, 50]], tint: '#7ff6e0' }
};

export type PatternKind = 'ring' | 'fan' | 'lanes' | 'slam' | 'summon' | 'puddle' | 'roots' | 'sweep' | 'dash';

export interface ElderPattern {
  k: PatternKind;
  every: number;
  n?: number;
  dmg?: number;
  what?: keyof typeof CREATURES;
}

export interface ElderDef {
  id: string;
  name: string;
  title: string;
  region: string;
  site: 'tundra' | 'desert' | 'marsh' | 'mountain' | 'coast' | 'forest';
  hp: number;
  stone: string;
  palette: [string, string, string];
  latent: ElderPattern[];
  awakened: ElderPattern[];
  blurb: string;
}

export const ELDERS: ElderDef[] = [
  {
    id: 'frost', name: 'Hrimr', title: 'Antlered Frost', region: 'Frostmarch', site: 'tundra', hp: 150, stone: 'stone_frost',
    palette: ['#bfeaff', '#5aa7d6', '#24476a'],
    latent: [{ k: 'ring', every: 3.2, n: 12, dmg: 7 }, { k: 'fan', every: 2.4, n: 3, dmg: 8 }],
    awakened: [{ k: 'ring', every: 2.6, n: 14, dmg: 8 }, { k: 'puddle', every: 3.8, n: 3, dmg: 4 }, { k: 'summon', every: 9, what: 'wolf', n: 2 }, { k: 'fan', every: 2, n: 5, dmg: 8 }],
    blurb: 'Frost-antlers shed shards that freeze the ground.'
  },
  {
    id: 'ember', name: 'Sol-Kaar', title: 'Ash Sovereign', region: 'Ashen Wastes', site: 'desert', hp: 170, stone: 'stone_ember',
    palette: ['#ffd27a', '#ff6a2c', '#5a1d12'],
    latent: [{ k: 'fan', every: 2.2, n: 5, dmg: 9 }, { k: 'dash', every: 5, dmg: 14 }],
    awakened: [{ k: 'lanes', every: 3.4, n: 3, dmg: 14 }, { k: 'slam', every: 4.6, dmg: 12 }, { k: 'fan', every: 1.9, n: 7, dmg: 9 }],
    blurb: 'Burning lanes scorch the sand and leave it black.'
  },
  {
    id: 'mire', name: 'Mother Mire', title: 'Reed-Queen', region: 'Reed Marsh', site: 'marsh', hp: 140, stone: 'stone_marsh',
    palette: ['#c8ff7a', '#4f8f3a', '#1e3a22'],
    latent: [{ k: 'puddle', every: 3.6, n: 2, dmg: 5 }, { k: 'summon', every: 8, what: 'wisp', n: 2 }],
    awakened: [{ k: 'roots', every: 3.2, dmg: 6 }, { k: 'puddle', every: 2.8, n: 3, dmg: 5 }, { k: 'summon', every: 7, what: 'wisp', n: 3 }],
    blurb: 'Roots lash out from the bog and hold the unwary.'
  },
  {
    id: 'stone', name: 'Graven', title: 'Heart of the Spine', region: 'Stone Spine', site: 'mountain', hp: 190, stone: 'stone_mountain',
    palette: ['#e8dcc2', '#8f8578', '#3b3430'],
    latent: [{ k: 'slam', every: 4.2, dmg: 12 }, { k: 'dash', every: 4.6, dmg: 13 }],
    awakened: [{ k: 'lanes', every: 2.8, n: 4, dmg: 13 }, { k: 'slam', every: 3.4, dmg: 14 }, { k: 'summon', every: 10, what: 'boar', n: 1 }],
    blurb: 'Shard-rings and rolling boulders across the Spine.'
  },
  {
    id: 'tide', name: 'Thalassa', title: 'Drowned Queen', region: 'Tideside Cliffs', site: 'coast', hp: 160, stone: 'stone_tide',
    palette: ['#c9fbff', '#2ca9c0', '#103c4a'],
    latent: [{ k: 'sweep', every: 5, dmg: 9 }, { k: 'fan', every: 2.6, n: 4, dmg: 8 }],
    awakened: [{ k: 'lanes', every: 2.7, n: 3, dmg: 12 }, { k: 'ring', every: 3, n: 16, dmg: 7 }, { k: 'sweep', every: 3.6, dmg: 10 }],
    blurb: 'Tide-lanes sweep the shore; wait for the gap.'
  },
  {
    id: 'grove', name: 'Ashen Oak', title: 'Elder of the Grove', region: 'Pinewood Reach', site: 'forest', hp: 165, stone: 'stone_grove',
    palette: ['#f0d6ff', '#8c59b8', '#2d1a40'],
    latent: [{ k: 'ring', every: 3.8, n: 10, dmg: 6 }, { k: 'summon', every: 9, what: 'bat', n: 2 }],
    awakened: [{ k: 'roots', every: 3, dmg: 7 }, { k: 'ring', every: 2.8, n: 12, dmg: 7 }, { k: 'fan', every: 2.2, n: 5, dmg: 8 }],
    blurb: 'Thorn-seed volleys and grasping roots.'
  }
];

export const RUN_STOCK: { item: string; price: number }[] = [
  { item: 'lantern', price: 1 },
  { item: 'backpack', price: 2 },
  { item: 'pick_iron', price: 2 },
  { item: 'potion_heal', price: 1 },
  { item: 'ration', price: 1 }
];

export const CHESTS: Record<string, { name: string; loot: [string, number, number][]; key?: string; vault?: boolean; core?: boolean }> = {
  'village_larder': { name: 'Mossbrook Larder', loot: [['ration', 1, 2], ['cloth', 1, 3], ['seed_turnip', 2, 4]] },
  'village_well': { name: 'Well Cache', loot: [['bandage', 1, 2], ['rope', 1, 2], ['torch', 1, 2]] },
  'wreck_locker': { name: 'Wreck Locker', loot: [['rusted_key', 1, 1], ['planks', 2, 4], ['rope', 1, 2], ['cloth', 1, 2], ['scrap', 2, 4]] },
  'mine_deep': { name: 'Deep Gallery Chest', loot: [['iron_ore', 3, 5], ['blueprint_torn', 1, 2], ['herb', 1, 2]], key: 'rusted_key' },
  'ruin_reliquary': { name: 'Ember Reliquary', loot: [['blueprint_torn', 1, 1]], core: true },
  'slag_vault': { name: 'Sealed Vault', loot: [['ragnarok_cash', 1, 2]], vault: true }
};

export const ACH: Record<string, { name: string; pts: number }> = {
  first_chop: { name: 'First Chop', pts: 5 },
  first_craft: { name: 'First Making', pts: 5 },
  first_kill: { name: 'First Blood', pts: 5 },
  first_build: { name: 'Raised Walls', pts: 10 },
  first_smelt: { name: 'Hot Iron', pts: 10 },
  first_study: { name: 'Study Hall', pts: 15 },
  first_cast: { name: 'Ember Unleashed', pts: 15 },
  cart_haul: { name: 'Freight Run', pts: 15 },
  deep_gallery: { name: 'Deep Gallery', pts: 25 },
  five_regions: { name: 'Five Regions Walked', pts: 20 },
  vault_cash: { name: 'Cash Under Ash', pts: 30 },
  escrow_secured: { name: 'Escrow Secured', pts: 40 },
  elder_frost: { name: 'Frost Elder Felled', pts: 60 },
  elder_ember: { name: 'Ember Elder Felled', pts: 60 },
  elder_mire: { name: 'Mire Mother Felled', pts: 60 },
  elder_stone: { name: 'Graven Felled', pts: 60 },
  elder_tide: { name: 'Drowned Queen Felled', pts: 60 },
  elder_grove: { name: 'Ashen Oak Felled', pts: 60 },
  six_stones: { name: 'Six Stones', pts: 250 },
  evacuated: { name: 'Skiff Away', pts: 80 },
  survived_day14: { name: 'Dawn After Ragnarok', pts: 100 }
};

export const SPAWNS: { id: string; name: string; blurb: string; region: string }[] = [
  { id: 'pinewood', name: 'Pinewood Clearing', blurb: 'Oak and pine, mossy stones, quiet wolves. Gentle first hour.', region: 'Pinewood Reach' },
  { id: 'marsh', name: 'Reed Marsh Edge', blurb: 'Reeds, mud and wisps. Fiber is everywhere; so is toxin.', region: 'Reed Marsh' },
  { id: 'harbor', name: 'Harbor Cove', blurb: 'Sand, crabs and a half-buried wreck. Salvage close at hand.', region: 'Harbor Cove' },
  { id: 'glen', name: 'Highland Glen', blurb: 'Rock-rich slopes above the mines. Stone for days, cold nights.', region: 'Highland Glen' }
];

export const TOOL_NAMES: Record<string, string> = { chop: 'axe', mine: 'pick', cut: 'knife' };
