// Synthesised sound design (WebAudio). No audio files are bundled: every cue is generated here.
export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  volume = 0.6;
  muted = false;
  private gate = new Map<string, number>();

  private ensure(): AudioContext | null {
    if (!this.ctx) {
      const W = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
      const AC = W.AudioContext ?? W.webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.connect(this.ctx.destination);
      const len = Math.floor(this.ctx.sampleRate * 1.5);
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.apply();
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    return this.ctx;
  }

  setVolume(v: number): void {
    this.volume = v;
    this.apply();
  }

  setMuted(m: boolean): void {
    this.muted = m;
    this.apply();
  }

  private apply(): void {
    if (this.master) this.master.gain.value = this.muted ? 0 : this.volume;
  }

  private tone(f0: number, f1: number, dur: number, type: OscillatorType, vol: number, at = 0): void {
    const c = this.ctx!;
    const o = c.createOscillator();
    const g = c.createGain();
    const t0 = c.currentTime + at;
    o.type = type;
    o.frequency.setValueAtTime(f0, t0);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(this.master!);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  private hiss(dur: number, vol: number, freq: number, q: number, sweepTo = freq, at = 0, type: BiquadFilterType = 'bandpass'): void {
    const c = this.ctx!;
    const src = c.createBufferSource();
    src.buffer = this.noise;
    const f = c.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    const t0 = c.currentTime + at;
    f.frequency.setValueAtTime(freq, t0);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, sweepTo), t0 + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master!);
    src.start(t0, Math.random() * 0.5, dur + 0.05);
  }

  play(name: string): void {
    const now = performance.now();
    const gap = name.startsWith('step') ? 110 : 45;
    if ((this.gate.get(name) ?? 0) + gap > now) return;
    this.gate.set(name, now);
    const c = this.ensure();
    if (!c || !this.master) return;
    switch (name) {
      case 'swing': this.hiss(0.12, 0.25, 2200, 1.2, 600); break;
      case 'spin': this.hiss(0.22, 0.3, 1400, 1.0, 500); break;
      case 'hit': this.tone(180, 60, 0.12, 'square', 0.22); this.hiss(0.06, 0.2, 2000, 0.8); break;
      case 'kill': this.tone(520, 90, 0.35, 'triangle', 0.25); this.tone(780, 120, 0.2, 'triangle', 0.14, 0.06); break;
      case 'hurt': this.tone(240, 80, 0.25, 'sawtooth', 0.16); break;
      case 'chop': this.hiss(0.08, 0.3, 900, 3); this.tone(260, 120, 0.12, 'triangle', 0.2); break;
      case 'mine': this.tone(1400, 900, 0.2, 'square', 0.1); this.tone(2100, 1200, 0.16, 'square', 0.07, 0.02); break;
      case 'pluck': this.tone(620, 480, 0.12, 'triangle', 0.14); break;
      case 'tink': this.tone(1100, 900, 0.07, 'square', 0.07); break;
      case 'pickup': this.tone(660, 880, 0.08, 'triangle', 0.15); this.tone(990, 1320, 0.1, 'triangle', 0.13, 0.07); break;
      case 'cast': this.hiss(0.5, 0.25, 300, 0.8, 2400); this.tone(260, 880, 0.45, 'sine', 0.12); break;
      case 'charge': this.tone(180, 620, 0.42, 'sine', 0.12); break;
      case 'shoot': this.hiss(0.06, 0.25, 4000, 2); break;
      case 'loose': this.hiss(0.07, 0.25, 2500, 2); this.tone(300, 140, 0.1, 'triangle', 0.1); break;
      case 'thud': this.tone(90, 40, 0.25, 'sine', 0.35); break;
      case 'warn': this.tone(880, 660, 0.18, 'sine', 0.1); break;
      case 'bolt': this.tone(900, 150, 0.22, 'sawtooth', 0.08); break;
      case 'roll': this.hiss(0.25, 0.18, 400, 0.7, 1400); break;
      case 'craft': this.tone(440, 660, 0.12, 'triangle', 0.12); this.tone(660, 990, 0.14, 'triangle', 0.1, 0.08); break;
      case 'build': this.tone(120, 90, 0.12, 'square', 0.18); this.hiss(0.1, 0.2, 800, 2); break;
      case 'study': this.tone(523, 784, 0.4, 'sine', 0.1); break;
      case 'coin': this.tone(1320, 1760, 0.15, 'triangle', 0.12); break;
      case 'ui': this.tone(700, 900, 0.05, 'triangle', 0.08); break;
      case 'error': this.tone(160, 110, 0.14, 'square', 0.08); break;
      case 'bag': this.hiss(0.14, 0.18, 700, 1.4); break;
      case 'eat': this.hiss(0.12, 0.12, 1200, 1); break;
      case 'thunder': this.hiss(1.6, 0.5, 120, 0.6, 60); break;
      case 'step:sand': this.hiss(0.05, 0.07, 1600, 1.5); break;
      case 'step:stone': this.hiss(0.03, 0.09, 2600, 3); break;
      case 'step:mud': this.hiss(0.09, 0.1, 300, 1.2); break;
      case 'step:snow': this.hiss(0.07, 0.07, 1200, 1.1); break;
      case 'step:grass': this.hiss(0.05, 0.06, 900, 1.6); break;
      case 'pack': this.hiss(0.14, 0.18, 700, 1.4); break;
      default: this.tone(600, 600, 0.05, 'sine', 0.05);
    }
  }
}
