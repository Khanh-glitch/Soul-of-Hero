// Durable local persistence. IndexedDB first (one transaction per commit), localStorage fallback.
// Saves are versioned; unreadable or foreign saves are quarantined under a new key instead of being overwritten.
const DB_NAME = 'soul-of-hero';
const STORE = 'kv';
const SCHEMA = 'soh.save';
const VERSION = 1;

let dbP: Promise<IDBDatabase | null> | null = null;
function openDb(): Promise<IDBDatabase | null> {
  if (!dbP) {
    dbP = new Promise((resolve) => {
      try {
        if (typeof indexedDB === 'undefined') return resolve(null);
        const rq = indexedDB.open(DB_NAME, 1);
        rq.onupgradeneeded = () => rq.result.createObjectStore(STORE);
        rq.onsuccess = () => resolve(rq.result);
        rq.onerror = () => resolve(null);
        rq.onblocked = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  }
  return dbP;
}

interface Envelope { schema: string; version: number; savedAt: number; data: unknown }

async function readRaw(key: string): Promise<Envelope | null> {
  const db = await openDb();
  if (db) {
    return new Promise((resolve) => {
      const rq = db.transaction(STORE, 'readonly').objectStore(STORE).get(key);
      rq.onsuccess = () => resolve((rq.result as Envelope) ?? null);
      rq.onerror = () => resolve(null);
    });
  }
  try {
    const t = localStorage.getItem('soh:' + key);
    return t ? (JSON.parse(t) as Envelope) : null;
  } catch {
    return null;
  }
}

async function writeMany(entries: [string, unknown][]): Promise<boolean> {
  const env = (data: unknown): Envelope => ({ schema: SCHEMA, version: VERSION, savedAt: Date.now(), data });
  const db = await openDb();
  if (db) {
    return new Promise((resolve) => {
      const tx = db.transaction(STORE, 'readwrite');
      const st = tx.objectStore(STORE);
      for (const [k, v] of entries) st.put(env(v), k);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
      tx.onabort = () => resolve(false);
    });
  }
  try {
    for (const [k, v] of entries) localStorage.setItem('soh:' + k, JSON.stringify(env(v)));
    return true;
  } catch {
    return false;
  }
}

async function quarantine(key: string, env: unknown): Promise<string> {
  const q = `${key}-corrupt-${Date.now()}`;
  await writeMany([[q, env ?? null]]);
  return q;
}

export interface LoadResult { run: Record<string, unknown> | null; profile: Record<string, unknown> | null; notes: string[] }

export async function loadAll(): Promise<LoadResult> {
  const notes: string[] = [];
  const runEnv = await readRaw('run');
  const profEnv = await readRaw('profile');
  let run: Record<string, unknown> | null = null;
  let profile: Record<string, unknown> | null = null;
  if (runEnv) {
    const d = runEnv.data as Record<string, unknown> | null;
    if (runEnv.schema === SCHEMA && runEnv.version === VERSION && d && d.v === 1 && d.custody && d.actors && d.clock) run = d;
    else notes.push(`Saved run was unreadable and was kept aside as ${await quarantine('run', runEnv)}.`);
  }
  if (profEnv) {
    const d = profEnv.data as Record<string, unknown> | null;
    if (profEnv.schema === SCHEMA && profEnv.version === VERSION && d && d.v === 1) profile = d;
    else notes.push(`Profile record was unreadable and was kept aside as ${await quarantine('profile', profEnv)}.`);
  }
  return { run, profile, notes };
}

/** Atomic commit: run and profile are written in one transaction when IndexedDB is available. */
export function saveRun(run: Record<string, unknown>, profile: Record<string, unknown>): Promise<boolean> {
  return writeMany([['run', run], ['profile', profile]]);
}

export async function clearRun(): Promise<void> {
  await writeMany([['run', null]]);
}
