import fs from 'fs';
import path from 'path';
import { BALANCE, SOURCES } from '../src/sim/catalogs';
import {
  assertCustodyInvariants,
  computePlayerCarriedMassKg,
  countPlayerItem,
  grantItemsToPlayerOrGround,
} from '../src/sim/custody';
import { computeRunUnverifiedScore, dispatchAction } from '../src/sim/dispatcher';
import { catchUpOffline, stepSimulation } from '../src/sim/simulationTick';
import { createDefaultProfile, createNewRunState } from '../src/sim/worldGen';

interface BotRunSummary {
  policy: string;
  seed: number;
  spawnRegionId: string;
  survived: boolean;
  deaths: number;
  finalHp: number;
  learnedRecipes: number;
  structuresBuilt: number;
  securedCash: number;
  elderStones: number;
  unverifiedScore: number;
  outcome: string;
  notes: string;
}

const SEEDS = [20260414, 20260501, 20260619];
const SPAWNS = [
  'spawn_west_cove',
  'spawn_south_meadow',
  'spawn_east_haven',
  'spawn_north_glade',
];

function harvestNearby(
  state: ReturnType<typeof createNewRunState>,
  materialType: string,
  swings: number,
  tag: string
) {
  let s = state;
  const spX = Math.floor(s.actors.player.x / 16);
  const spY = Math.floor(s.actors.player.y / 16);
  const node = Object.values(s.sourceStocks).find(
    (n) =>
      n.stock > 0 &&
      SOURCES[n.defId]?.materialType === materialType &&
      Math.hypot(n.tileX - spX, n.tileY - spY) <= 10
  );
  if (!node) return s;
  s.actors.player.x = node.tileX * 16 + 8;
  s.actors.player.y = (node.tileY + 1) * 16 + 8;

  for (let i = 0; i < swings && s.sourceStocks[node.id]?.stock > 0; i++) {
    s.actors.player.cooldownUntilSec = 0;
    const sDef = SOURCES[node.defId];
    if (sDef.interactLoot) {
      s = dispatchAction(s, {
        intentId: `${tag}_loot_${i}`,
        kind: 'INTERACT_NEARBY',
        targetId: node.id,
      }).state;
    } else {
      s = dispatchAction(s, {
        intentId: `${tag}_hit_${i}`,
        kind: 'START_ACT_ON_TARGET',
        targetWorldX: node.tileX * 16 + 8,
        targetWorldY: node.tileY * 16 + 8,
      }).state;
      s = stepSimulation(s, 0.5);
    }
  }
  return s;
}

function runPolicyBot(policy: string, seed: number, spawnIdx: number): BotRunSummary {
  const spawnId = SPAWNS[spawnIdx % SPAWNS.length];
  let s = createNewRunState({
    profile: createDefaultProfile(1_700_000_000_000),
    worldSeed: seed,
    spawnRegionId: spawnId,
    adventurerGender: spawnIdx % 2 === 0 ? 'female' : 'male',
  });
  const sp = s.world.spawnRegions.find((x) => x.id === spawnId)!;
  let notes = '';

  switch (policy) {
    case '01_knife_only_forager': {
      s = harvestNearby(s, 'organic', 4, 'k_org');
      s = harvestNearby(s, 'salvage', 3, 'k_slv');
      s = harvestNearby(s, 'wood', 4, 'k_wd');
      // Fight nearby scout creature with starter survival knife
      const enemy = s.actors.enemies.find((e) => e.alive)!;
      s.actors.player.x = enemy.x - 16;
      s.actors.player.y = enemy.y;
      for (let i = 0; i < 6 && s.actors.enemies.find((e) => e.id === enemy.id)?.alive; i++) {
        s.actors.player.cooldownUntilSec = 0;
        s = dispatchAction(s, {
          intentId: `k_atk_${i}`,
          kind: 'START_ACT_ON_TARGET',
          targetWorldX: enemy.x,
          targetWorldY: enemy.y,
        }).state;
        s = stepSimulation(s, 0.55);
      }
      notes = `Wood=${countPlayerItem(s, 'wood_log')}, Scrap=${countPlayerItem(s, 'scrap_metal')}`;
      break;
    }

    case '02_tool_crafter_vs_bare': {
      s = harvestNearby(s, 'wood', 6, 'tc_wd');
      s = harvestNearby(s, 'stone', 8, 'tc_st');
      grantItemsToPlayerOrGround(s, 'wood_log', 5, 'sim_pad');
      grantItemsToPlayerOrGround(s, 'stone_chunk', 5, 'sim_pad');
      s = dispatchAction(s, {
        intentId: 'tc_hatchet',
        kind: 'START_JOB',
        recipeId: 'recipe_stone_hatchet',
        stationId: 'hand',
      }).state;
      s = stepSimulation(s, 5);
      const jId = Object.keys(s.jobs)[0];
      if (jId) {
        s = dispatchAction(s, { intentId: 'tc_clm', kind: 'CLAIM_JOB_OUTPUT', jobId: jId }).state;
      }
      const hatchet = Object.values(s.items).find((i) => i.defId === 'stone_hatchet');
      if (hatchet) {
        s = dispatchAction(s, {
          intentId: 'tc_eq',
          kind: 'EQUIP_ITEM',
          itemInstanceId: hatchet.instanceId,
        }).state;
      }
      const beforeLogs = countPlayerItem(s, 'wood_log');
      s = harvestNearby(s, 'wood', 4, 'tc_wd2');
      notes = `Hatchet wood gain=+${countPlayerItem(s, 'wood_log') - beforeLogs}`;
      break;
    }

    case '03_road_scavenger_nomad': {
      // Walk along physical road collecting barrels without building a house
      for (let step = 0; step < 30; step++) {
        s = dispatchAction(s, {
          intentId: 'live_move',
          kind: 'MOVE_INPUT',
          dx: 1,
          dy: 0,
          sprint: false,
          dtSec: 0.5,
        }).state;
        s = stepSimulation(s, 0.5);
      }
      s = harvestNearby(s, 'salvage', 4, 'nomad_slv');
      notes = `Footprints=${s.footprints.length}, Spares=${countPlayerItem(s, 'spares_token')}`;
      break;
    }

    case '04_home_builder_industry': {
      grantItemsToPlayerOrGround(s, 'wood_log', 16, 'sim');
      grantItemsToPlayerOrGround(s, 'wood_plank', 24, 'sim');
      grantItemsToPlayerOrGround(s, 'stone_chunk', 24, 'sim');
      grantItemsToPlayerOrGround(s, 'plant_fiber', 10, 'sim');
      grantItemsToPlayerOrGround(s, 'scrap_metal', 10, 'sim');
      grantItemsToPlayerOrGround(s, 'cloth_roll', 4, 'sim');
      grantItemsToPlayerOrGround(s, 'iron_ore', 4, 'sim');

      s.actors.player.x = sp.tileX * 16 + 8;
      s.actors.player.y = sp.tileY * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'hb_claim',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'claim_cabinet',
        tileX: sp.tileX - 1,
        tileY: sp.tileY - 1,
      }).state;
      s = dispatchAction(s, {
        intentId: 'hb_flr',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'wood_floor',
        tileX: sp.tileX,
        tileY: sp.tileY,
      }).state;
      s = dispatchAction(s, {
        intentId: 'hb_rf',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'thatch_roof',
        tileX: sp.tileX,
        tileY: sp.tileY,
      }).state;
      s = dispatchAction(s, {
        intentId: 'hb_bed',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'sleeping_bed',
        tileX: sp.tileX + 1,
        tileY: sp.tileY - 1,
      }).state;
      s = dispatchAction(s, {
        intentId: 'hb_frn',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'stone_furnace',
        tileX: sp.tileX + 1,
        tileY: sp.tileY,
      }).state;

      const frnId = Object.keys(s.structures).find((k) => s.structures[k].defId === 'stone_furnace')!;
      const logItem = Object.values(s.items).find((i) => i.defId === 'wood_log')!;
      s = dispatchAction(s, {
        intentId: 'hb_fuel',
        kind: 'FUEL_STATION',
        structureId: frnId,
        fuelItemInstanceId: logItem.instanceId,
        count: 1,
      }).state;
      s = dispatchAction(s, {
        intentId: 'hb_smelt',
        kind: 'START_JOB',
        recipeId: 'recipe_smelt_iron',
        stationId: frnId,
      }).state;
      s = catchUpOffline(s, Date.now() + 60_000, 60).state;
      const smeltJob = s.structures[frnId].activeJobId!;
      s = dispatchAction(s, {
        intentId: 'hb_claim_ingot',
        kind: 'CLAIM_JOB_OUTPUT',
        jobId: smeltJob,
      }).state;
      notes = `Ingots=${countPlayerItem(s, 'iron_ingot')}`;
      break;
    }

    case '05_researcher_spares_and_blueprint': {
      grantItemsToPlayerOrGround(s, 'wood_plank', 10, 'sim');
      grantItemsToPlayerOrGround(s, 'wire_coil', 4, 'sim');
      grantItemsToPlayerOrGround(s, 'spares_token', 16, 'sim');
      grantItemsToPlayerOrGround(s, 'blueprint_cart', 1, 'sim');
      s = dispatchAction(s, {
        intentId: 'rs_desk',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'research_bench',
        tileX: sp.tileX + 1,
        tileY: sp.tileY,
      }).state;
      const deskId = Object.keys(s.structures).find((k) => s.structures[k].defId === 'research_bench')!;
      const bp = Object.values(s.items).find((i) => i.defId === 'blueprint_cart')!;
      s = dispatchAction(s, { intentId: 'rs_bp', kind: 'USE_ITEM', itemInstanceId: bp.instanceId }).state;
      s = dispatchAction(s, {
        intentId: 'rs_rnd',
        kind: 'START_RESEARCH',
        stationId: deskId,
        mode: 'random_spares',
      }).state;
      s = stepSimulation(s, 15);
      const j = s.structures[deskId].activeJobId!;
      s = dispatchAction(s, { intentId: 'rs_clm', kind: 'CLAIM_JOB_OUTPUT', jobId: j }).state;
      notes = `Recipes=${s.run.learnedRecipeIds.length}`;
      break;
    }

    case '06_freight_cart_hauler': {
      const cg = grantItemsToPlayerOrGround(s, 'hand_cart_kit', 1, 'sim');
      grantItemsToPlayerOrGround(s, 'iron_ore', 24, 'sim'); // 31.2kg of heavy ore!
      const footMass = computePlayerCarriedMassKg(s);
      s = dispatchAction(s, {
        intentId: 'fc_dep',
        kind: 'DEPLOY_VEHICLE',
        itemInstanceId: cg.grantedIds[0],
        tileX: sp.tileX + 1,
        tileY: sp.tileY,
      }).state;
      const vId = Object.keys(s.vehicles)[0];
      const ore = Object.values(s.items).find((i) => i.defId === 'iron_ore')!;
      s = dispatchAction(s, {
        intentId: 'fc_load',
        kind: 'TRANSFER_ITEM',
        itemInstanceId: ore.instanceId,
        toLocation: { kind: 'vehicle_cargo', vehicleId: vId, slotIndex: 0 },
      }).state;
      const afterLoadMass = computePlayerCarriedMassKg(s);
      // Compare 5s travel distance on road (96, 90) vs marsh (54, 134)
      s.actors.player.x = 84 * 16 + 8;
      s.actors.player.y = 96 * 16 + 8;
      const r0 = s.actors.player.x;
      s = dispatchAction(s, {
        intentId: 'live_move',
        kind: 'MOVE_INPUT',
        dx: 1,
        dy: 0,
        sprint: false,
        dtSec: 2.0,
      }).state;
      const roadDist = Math.round(s.actors.player.x - r0);
      notes = `BodyLoad ${footMass}kg->${afterLoadMass}kg, Road2s=${roadDist}px`;
      break;
    }

    case '07_core_immediate_caster': {
      const cg = grantItemsToPlayerOrGround(s, 'core_ember', 1, 'sim');
      const cid = cg.grantedIds[0];
      s = dispatchAction(s, { intentId: 'cc_eq', kind: 'EQUIP_ITEM', itemInstanceId: cid }).state;
      const enemy = s.actors.enemies.find((e) => e.alive)!;
      s.actors.player.x = enemy.x - 32;
      s.actors.player.y = enemy.y;
      s = dispatchAction(s, {
        intentId: 'cc_fire',
        kind: 'START_ACT_ON_TARGET',
        targetWorldX: enemy.x,
        targetWorldY: enemy.y,
      }).state;
      s = stepSimulation(s, 0.7);
      notes = `CoreCharges=${s.items[cid]?.charges}/8`;
      break;
    }

    case '08_core_specimen_analyst': {
      grantItemsToPlayerOrGround(s, 'wood_plank', 8, 'sim');
      grantItemsToPlayerOrGround(s, 'wire_coil', 3, 'sim');
      grantItemsToPlayerOrGround(s, 'spares_token', 4, 'sim');
      const cg = grantItemsToPlayerOrGround(s, 'core_volt', 1, 'sim');
      s = dispatchAction(s, {
        intentId: 'cs_desk',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'research_bench',
        tileX: sp.tileX + 1,
        tileY: sp.tileY,
      }).state;
      const deskId = Object.keys(s.structures)[Object.keys(s.structures).length - 1];
      s = dispatchAction(s, {
        intentId: 'cs_study',
        kind: 'START_RESEARCH',
        stationId: deskId,
        mode: 'specimen',
        specimenInstanceId: cg.grantedIds[0],
      }).state;
      s = stepSimulation(s, 15);
      const j = s.structures[deskId].activeJobId!;
      s = dispatchAction(s, { intentId: 'cs_clm', kind: 'CLAIM_JOB_OUTPUT', jobId: j }).state;
      notes = `LearnedVolt=${s.run.learnedRecipeIds.includes('recipe_core_volt')}`;
      break;
    }

    case '09_poi_layered_explorer': {
      const researchPoi = s.world.pois.find((p) => p.defId === 'poi_research_facility')!;
      // Loot exterior first without keycard
      const extLocker = Object.values(s.sourceStocks).find(
        (n) => n.poiId === researchPoi.id && !n.isDeepPoi
      )!;
      s.actors.player.x = extLocker.tileX * 16 + 8;
      s.actors.player.y = (extLocker.tileY + 1) * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'poi_ext',
        kind: 'INTERACT_NEARBY',
        targetId: extLocker.id,
      }).state;
      // Unlock deep gate with keycard + fuel
      grantItemsToPlayerOrGround(s, 'access_card_industrial', 1, 'sim');
      grantItemsToPlayerOrGround(s, 'fuel_canister', 1, 'sim');
      s.actors.player.x = researchPoi.gateTileX * 16 + 8;
      s.actors.player.y = (researchPoi.gateTileY + 1) * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'poi_unl',
        kind: 'UNLOCK_POI_GATE',
        poiId: researchPoi.id,
      }).state;
      const deepPedestal = Object.values(s.sourceStocks).find(
        (n) => n.poiId === researchPoi.id && n.defId === 'core_relic_pedestal'
      )!;
      s.actors.player.x = deepPedestal.tileX * 16 + 8;
      s.actors.player.y = (deepPedestal.tileY + 1) * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'poi_deep_core',
        kind: 'INTERACT_NEARBY',
        targetId: deepPedestal.id,
      }).state;
      notes = `Unlocked=${s.world.pois.find((p) => p.id === researchPoi.id)?.unlockedDeep}`;
      break;
    }

    case '10_nonboss_ragnarok_first_escrow': {
      // Zero profile cash -> Final 72h -> Non-boss vault -> Buy Rương ký gửi -> Claim Land -> Deposit -> Evacuate!
      grantItemsToPlayerOrGround(s, 'access_card_industrial', 1, 'sim');
      grantItemsToPlayerOrGround(s, 'wood_plank', 8, 'sim');
      grantItemsToPlayerOrGround(s, 'stone_chunk', 6, 'sim');
      grantItemsToPlayerOrGround(s, 'scrap_metal', 4, 'sim');

      const bunker = s.world.pois.find((p) => p.defId === 'poi_sealed_bunker')!;
      s.actors.player.x = bunker.gateTileX * 16 + 8;
      s.actors.player.y = (bunker.gateTileY + 1) * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'nb_unl',
        kind: 'UNLOCK_POI_GATE',
        poiId: bunker.id,
      }).state;

      s = dispatchAction(s, {
        intentId: 'nb_f72',
        kind: 'QA_ADVANCE_CLOCK',
        advanceSeconds: BALANCE.clock.hazardIntensifyStartSeconds.value + 600,
      }).state;

      const vault = Object.values(s.sourceStocks).find(
        (n) => n.poiId === bunker.id && n.defId === 'final72_ragnarok_vault'
      )!;
      s.actors.player.x = vault.tileX * 16 + 8;
      s.actors.player.y = (vault.tileY + 1) * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'nb_loot_vault',
        kind: 'INTERACT_NEARBY',
        targetId: vault.id,
      }).state;

      const vendor = s.world.pois.find((p) => p.defId === 'poi_frontier_vendor')!;
      s.actors.player.x = vendor.centerX * 16 + 8;
      s.actors.player.y = vendor.centerY * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'nb_buy_escrow',
        kind: 'BUY_VENDOR_OFFER',
        poiId: vendor.id,
        offerId: 'offer_escrow_chest_physical',
      }).state;

      s.actors.player.x = sp.tileX * 16 + 8;
      s.actors.player.y = sp.tileY * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'nb_claim',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'claim_cabinet',
        tileX: sp.tileX - 1,
        tileY: sp.tileY,
      }).state;
      s = dispatchAction(s, {
        intentId: 'nb_place_escrow',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'escrow_chest',
        tileX: sp.tileX + 1,
        tileY: sp.tileY,
      }).state;
      const escId = Object.keys(s.structures).find((k) => s.structures[k].defId === 'escrow_chest')!;
      s = dispatchAction(s, {
        intentId: 'nb_dep',
        kind: 'DEPOSIT_ESCROW_CASH',
        structureId: escId,
      }).state;

      const evac = s.world.pois.find((p) => p.defId === 'poi_evacuation_harbor')!;
      s.actors.player.x = evac.centerX * 16 + 8;
      s.actors.player.y = evac.centerY * 16 + 8;
      s = dispatchAction(s, {
        intentId: 'nb_evac',
        kind: 'EVACUATE_RUN',
        poiId: evac.id,
      }).state;
      notes = `ZeroBossSecured=+${s.profile.securedRagnarokCash}`;
      break;
    }

    case '11_optional_elder_challenger': {
      const machete = grantItemsToPlayerOrGround(s, 'iron_machete', 1, 'sim');
      const suit = grantItemsToPlayerOrGround(s, 'hazard_suit', 1, 'sim');
      grantItemsToPlayerOrGround(s, 'field_bandage', 10, 'sim');
      s = dispatchAction(s, {
        intentId: 'el_eq1',
        kind: 'EQUIP_ITEM',
        itemInstanceId: machete.grantedIds[0],
      }).state;
      s = dispatchAction(s, {
        intentId: 'el_eq2',
        kind: 'EQUIP_ITEM',
        itemInstanceId: suit.grantedIds[0],
      }).state;

      const gale = s.actors.elders.find((e) => e.defId === 'elder_gale')!;
      s.actors.player.x = gale.x - 18;
      s.actors.player.y = gale.y;
      for (let swing = 0; swing < 24 && s.actors.elders.find((e) => e.id === gale.id)?.alive; swing++) {
        if (s.actors.player.hp < 50) {
          const b = Object.values(s.items).find((i) => i.defId === 'field_bandage');
          if (b) {
            s = dispatchAction(s, {
              intentId: `el_heal_${swing}`,
              kind: 'USE_ITEM',
              itemInstanceId: b.instanceId,
            }).state;
          }
        }
        s.actors.player.cooldownUntilSec = 0;
        s = dispatchAction(s, {
          intentId: `el_hit_${swing}`,
          kind: 'START_ACT_ON_TARGET',
          targetWorldX: gale.x,
          targetWorldY: gale.y,
        }).state;
        s = stepSimulation(s, 0.55);
      }
      notes = `Stones=${s.run.collectedElderStones.length}/6`;
      break;
    }

    case '12_offline_sheltered_sleeper': {
      grantItemsToPlayerOrGround(s, 'wood_log', 8, 'sim');
      grantItemsToPlayerOrGround(s, 'stone_chunk', 4, 'sim');
      grantItemsToPlayerOrGround(s, 'wood_plank', 4, 'sim');
      grantItemsToPlayerOrGround(s, 'plant_fiber', 6, 'sim');
      s = dispatchAction(s, {
        intentId: 'os_flr',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'wood_floor',
        tileX: sp.tileX,
        tileY: sp.tileY,
      }).state;
      s = dispatchAction(s, {
        intentId: 'os_rf',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'thatch_roof',
        tileX: sp.tileX,
        tileY: sp.tileY,
      }).state;
      // Offline for 48 real hours!
      s = catchUpOffline(s, Date.now() + 48 * 3600 * 1000, 48 * 3600).state;
      notes = `48hShelteredHP=${Math.round(s.actors.player.hp)}, Deaths=${s.actors.player.deathCount}`;
      break;
    }

    case '13_offline_unprepared_exposed': {
      // Quit unprepared in snow zone without warm coat for 6 hours -> lawful freezing consequence!
      s.actors.player.x = 146 * 16 + 8;
      s.actors.player.y = 40 * 16 + 8;
      s = catchUpOffline(s, Date.now() + 6 * 3600 * 1000, 6 * 3600).state;
      notes = `6hBlizzardDeaths=${s.actors.player.deathCount}, DeathBags=${Object.keys(s.deathBags).length}`;
      break;
    }
  }

  assertCustodyInvariants(s);
  return {
    policy,
    seed,
    spawnRegionId: spawnId,
    survived: s.actors.player.deathCount === 0,
    deaths: s.actors.player.deathCount,
    finalHp: Math.round(s.actors.player.hp),
    learnedRecipes: s.run.learnedRecipeIds.length,
    structuresBuilt: Object.values(s.structures).filter((st) => st.ownerId === 'player').length,
    securedCash: s.profile.securedRagnarokCash,
    elderStones: s.run.collectedElderStones.length,
    unverifiedScore: computeRunUnverifiedScore(s),
    outcome: s.run.status,
    notes,
  };
}

function main() {
  const policies = [
    '01_knife_only_forager',
    '02_tool_crafter_vs_bare',
    '03_road_scavenger_nomad',
    '04_home_builder_industry',
    '05_researcher_spares_and_blueprint',
    '06_freight_cart_hauler',
    '07_core_immediate_caster',
    '08_core_specimen_analyst',
    '09_poi_layered_explorer',
    '10_nonboss_ragnarok_first_escrow',
    '11_optional_elder_challenger',
    '12_offline_sheltered_sleeper',
    '13_offline_unprepared_exposed',
  ];

  const results: BotRunSummary[] = [];
  for (const pol of policies) {
    SEEDS.forEach((seed, idx) => {
      results.push(runPolicyBot(pol, seed, idx));
    });
  }

  // Sensitivity Sweep ±20% on key economic & survival rates
  const baseVaultMin = BALANCE.ragnarokEconomy.cashPerFinal72VaultMin.value;
  const baseChestPrice = BALANCE.ragnarokEconomy.escrowChestVendorCashPrice.value;
  const baseHunger = BALANCE.player.hungerDrainPerRealHour.value;
  const baseThirst = BALANCE.player.thirstDrainPerRealHour.value;

  const sensitivity = [-0.2, 0, +0.2].map((delta) => {
    const mult = 1 + delta;
    const adjVaultMin = Math.round(baseVaultMin * (1 - delta)); // adverse when delta = +0.2 (-20% cash)
    const adjChestPrice = Math.round(baseChestPrice * mult); // adverse when delta = +0.2 (+20% price)
    const singleVaultNet = adjVaultMin - adjChestPrice;
    const twoNonBossVaultsNet = adjVaultMin * 2 - adjChestPrice;
    const threeNonBossVaultsNet = adjVaultMin * 3 - adjChestPrice;
    const hoursToEmptyHungerActive = Math.round((100 / (baseHunger * mult)) * 10) / 10;
    const hoursToEmptyThirstActive = Math.round((100 / (baseThirst * mult)) * 10) / 10;
    return {
      perturbationPct: `${delta >= 0 ? '+' : ''}${Math.round(delta * 100)}%`,
      adjVaultMinCash: adjVaultMin,
      adjEscrowChestPrice: adjChestPrice,
      singleVaultWorstCaseNet: singleVaultNet,
      twoNonBossVaultsWorstCaseNet: twoNonBossVaultsNet,
      threeNonBossVaultsWorstCaseNet: threeNonBossVaultsNet,
      twoVaultNoBossFeasible: twoNonBossVaultsNet > 0,
      hoursToEmptyHungerActive,
      hoursToEmptyThirstActive,
    };
  });

  const nonBossSecured = results
    .filter((r) => r.policy === '10_nonboss_ragnarok_first_escrow')
    .map((r) => r.securedCash)
    .sort((a, b) => a - b);

  if (nonBossSecured.some((c) => c <= 0)) {
    throw new Error('Balance gate failed: Non-boss first escrow path failed to deposit positive cash!');
  }
  if (sensitivity.some((s) => !s.twoVaultNoBossFeasible)) {
    throw new Error('Sensitivity gate failed: Two non-boss vaults infeasible under ±20% stress!');
  }

  const reportObj = {
    generatedAtUtc: new Date().toISOString(),
    totalBotRuns: results.length,
    policiesTested: policies.length,
    seedsTested: SEEDS,
    nonBossFirstEscrowDepositDistribution: {
      min: nonBossSecured[0],
      median: nonBossSecured[Math.floor(nonBossSecured.length / 2)],
      max: nonBossSecured[nonBossSecured.length - 1],
    },
    sensitivitySweep20Pct: sensitivity,
    sampleRuns: results,
  };

  fs.writeFileSync(
    path.resolve(process.cwd(), 'simulation_results.json'),
    JSON.stringify(reportObj, null, 2)
  );

  console.log('=== SOUL OF HERO DETERMINISTIC SIMULATION BENCHMARK ===');
  console.log(`Policies tested: ${policies.length} × ${SEEDS.length} seeds = ${results.length} runs`);
  console.log(
    `No-Boss First Escrow Net Deposit (min/med/max): +${nonBossSecured[0]} / +${nonBossSecured[1]} / +${nonBossSecured[2]} Secured Cash`
  );
  console.table(sensitivity);
  console.log('All custody invariants and ±20% balance sensitivity checks PASSED.');
}

main();
