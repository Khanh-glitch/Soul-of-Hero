import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { chromium } from 'playwright';
import { PNG } from 'pngjs';

const SCREENSHOT_DIR = path.resolve(process.cwd(), 'screenshots');

function inspectPngNonBlack(filePath: string): {
  width: number;
  height: number;
  nonBlackRatio: number;
  uniqueColorBuckets: number;
} {
  const buf = fs.readFileSync(filePath);
  const png = PNG.sync.read(buf);
  let nonBlack = 0;
  const buckets = new Set<number>();
  const totalPixels = png.width * png.height;

  for (let i = 0; i < png.data.length; i += 4) {
    const r = png.data[i];
    const g = png.data[i + 1];
    const b = png.data[i + 2];
    if (r + g + b > 36) {
      nonBlack++;
    }
    buckets.add(((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4));
  }

  const nonBlackRatio = Math.round((nonBlack / totalPixels) * 1000) / 1000;
  if (nonBlackRatio < 0.25 || buckets.size < 15) {
    throw new Error(
      `Visual gate failed for ${path.basename(filePath)}: nonBlackRatio=${nonBlackRatio}, buckets=${buckets.size}`
    );
  }
  return {
    width: png.width,
    height: png.height,
    nonBlackRatio,
    uniqueColorBuckets: buckets.size,
  };
}

async function waitForServer(url: string, timeoutMs = 15000): Promise<void> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(url);
      if (res.ok) return;
    } catch {
      // retry
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error(`Timed out waiting for server at ${url}`);
}

async function main() {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

  const port = 4179;
  const server = spawn(
    'npx',
    ['vite', '--host', '127.0.0.1', '--port', String(port), '--strictPort'],
    {
      stdio: 'pipe',
      env: { ...process.env },
    }
  );

  const metricsLog: Record<string, unknown> = {};

  try {
    const baseUrl = `http://127.0.0.1:${port}`;
    await waitForServer(baseUrl);

    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext({
      viewport: { width: 640, height: 360 },
      deviceScaleFactor: 1,
    });

    // ================= 1. NATIVE 640x360 TITLE & NEW RUN CHECK =================
    let page = await context.newPage();
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.waitForSelector('[data-testid="title-screen"]');
    await page.waitForTimeout(350);

    const s1Path = path.join(SCREENSHOT_DIR, '01_title_new_run_640x360.png');
    await page.screenshot({ path: s1Path });
    metricsLog['01_title_new_run_640x360.png'] = inspectPngNonBlack(s1Path);

    // Select Female Adventurer & West Driftwood Cove, click Start Run
    await page.click('[data-testid="select-gender-female"]');
    await page.click('[data-testid="select-spawn-spawn_west_cove"]');
    await page.click('[data-testid="start-new-run-btn"]');
    await page.waitForSelector('[data-testid="hud-top"]');
    await page.waitForSelector('[data-testid="hud-bottom"]');

    // Verify zero HUD clipping at native 640x360!
    const topBox640 = await page.locator('[data-testid="hud-top"]').boundingBox();
    const botBox640 = await page.locator('[data-testid="hud-bottom"]').boundingBox();
    if (
      !topBox640 ||
      !botBox640 ||
      topBox640.y < 0 ||
      topBox640.x < 0 ||
      topBox640.x + topBox640.width > 641 ||
      botBox640.y + botBox640.height > 361
    ) {
      throw new Error(
        `HUD clipped at 640x360: top=${JSON.stringify(topBox640)}, bottom=${JSON.stringify(botBox640)}`
      );
    }

    // ================= 2. 1280x720 INTEGER 2X SCALING, MOVEMENT & HARVEST =================
    await page.setViewportSize({ width: 1280, height: 720 });
    await page.waitForTimeout(250);

    // Real WASD keyboard movement & Canvas click harvest!
    const posBefore = await page.evaluate(() => {
      const api = (window as unknown as { __SOUL_OF_HERO__: { getSnapshot: () => { actors: { player: { x: number; y: number } } } } }).__SOUL_OF_HERO__;
      const st = api.getSnapshot();
      return { x: st.actors.player.x, y: st.actors.player.y };
    });

    await page.keyboard.down('d');
    await page.waitForTimeout(420);
    await page.keyboard.up('d');

    const posAfter = await page.evaluate(() => {
      const api = (window as unknown as { __SOUL_OF_HERO__: { getSnapshot: () => { actors: { player: { x: number; y: number }; footprints?: unknown[] } } } }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as unknown as { actors: { player: { x: number; y: number } }; footprints: unknown[] };
      return { x: st.actors.player.x, y: st.actors.player.y, fps: st.footprints.length };
    });

    if (posAfter.x <= posBefore.x + 8 || posAfter.fps === 0) {
      throw new Error(`Real keyboard movement failed: before=${JSON.stringify(posBefore)}, after=${JSON.stringify(posAfter)}`);
    }

    // Move next to nearby Roadside Barrel & press real 'e' key to salvage!
    await page.evaluate(() => {
      const api = (window as unknown as { __SOUL_OF_HERO__: { getSnapshot: () => Record<string, unknown> } }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as {
        actors: { player: { x: number; y: number } };
        sourceStocks: Record<string, { defId: string; tileX: number; tileY: number; stock: number }>;
      };
      const barrel = Object.values(st.sourceStocks).find(
        (s) => s.defId === 'roadside_barrel' && s.stock > 0
      );
      if (barrel) {
        st.actors.player.x = barrel.tileX * 16 + 8;
        st.actors.player.y = (barrel.tileY + 1) * 16 + 8;
      }
    });
    await page.keyboard.press('e');
    await page.mouse.click(640, 320);
    await page.waitForTimeout(250);

    const s2Path = path.join(SCREENSHOT_DIR, '02_hud_terrain_harvest_1280x720.png');
    await page.screenshot({ path: s2Path });
    metricsLog['02_hud_terrain_harvest_1280x720.png'] = inspectPngNonBlack(s2Path);

    // ================= 3. BUILD HOME WITH WALLS, STATIONS & ROOF FADE =================
    await page.evaluate(() => {
      const api = (window as unknown as {
        __SOUL_OF_HERO__: {
          getSnapshot: () => unknown;
          dispatchIntent: (i: unknown) => void;
        };
      }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as {
        world: { spawnRegions: { tileX: number; tileY: number }[] };
        actors: { player: { x: number; y: number } };
        items: Record<string, unknown>;
        run: { runId: string };
      };
      const sp = st.world.spawnRegions[0];
      st.actors.player.x = sp.tileX * 16 + 8;
      st.actors.player.y = sp.tileY * 16 + 8;

      const mats: [string, string, number, number][] = [
        ['itm_e2e_log', 'wood_log', 35, 3],
        ['itm_e2e_plk', 'wood_plank', 40, 4],
        ['itm_e2e_stn', 'stone_chunk', 35, 5],
        ['itm_e2e_fib', 'plant_fiber', 25, 6],
        ['itm_e2e_scr', 'scrap_metal', 20, 7],
        ['itm_e2e_clt', 'cloth_roll', 10, 8],
        ['itm_e2e_ore', 'iron_ore', 8, 9],
      ];
      for (const [id, defId, count, slot] of mats) {
        st.items[id] = {
          instanceId: id,
          defId,
          runId: st.run.runId,
          count,
          quality: 100,
          location: { kind: 'player_bag', slotIndex: slot },
          provenanceReceiptId: 'e2e_harvest_batch',
        };
      }

      const placements: [string, number, number][] = [
        ['wood_floor', sp.tileX - 1, sp.tileY - 1],
        ['wood_floor', sp.tileX, sp.tileY - 1],
        ['wood_floor', sp.tileX + 1, sp.tileY - 1],
        ['wood_floor', sp.tileX - 1, sp.tileY],
        ['wood_floor', sp.tileX, sp.tileY],
        ['wood_floor', sp.tileX + 1, sp.tileY],
        ['wood_floor', sp.tileX - 1, sp.tileY + 1],
        ['wood_floor', sp.tileX, sp.tileY + 1],
        ['wood_floor', sp.tileX + 1, sp.tileY + 1],
        ['wood_wall', sp.tileX - 1, sp.tileY - 2],
        ['wood_wall', sp.tileX, sp.tileY - 2],
        ['wood_wall', sp.tileX + 1, sp.tileY - 2],
        ['wood_door', sp.tileX, sp.tileY + 2],
        ['claim_cabinet', sp.tileX - 1, sp.tileY - 1],
        ['sleeping_bed', sp.tileX + 1, sp.tileY - 1],
        ['storage_chest', sp.tileX - 1, sp.tileY + 1],
        ['stone_furnace', sp.tileX + 1, sp.tileY],
        ['slate_roof', sp.tileX, sp.tileY],
        ['slate_roof', sp.tileX + 1, sp.tileY],
      ];
      let seq = 1;
      for (const [defId, tx, ty] of placements) {
        api.dispatchIntent({
          intentId: `e2e_bld_${seq++}`,
          kind: 'BUILD_STRUCTURE',
          structureDefId: defId,
          tileX: tx,
          tileY: ty,
        });
      }
    });

    await page.keyboard.press('b');
    await page.mouse.move(700, 360);
    await page.waitForTimeout(300);

    const s3Path = path.join(SCREENSHOT_DIR, '03_build_indoor_roof_fade_1280x720.png');
    await page.screenshot({ path: s3Path });
    metricsLog['03_build_indoor_roof_fade_1280x720.png'] = inspectPngNonBlack(s3Path);

    // ================= 4. CROSS-SESSION CLOSE & REOPEN PERSISTENCE + INVENTORY/CRAFT =================
    await page.evaluate(async () => {
      const api = (window as unknown as { __SOUL_OF_HERO__: { saveNow: () => Promise<void> } }).__SOUL_OF_HERO__;
      await api.saveNow();
    });
    await page.close(); // Actually close browser tab!

    // Open brand-new browser tab in same storage context -> verify persisted structures & resume!
    page = await context.newPage();
    await page.setViewportSize({ width: 1280, height: 720 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.waitForSelector('[data-testid="resume-run-btn"]');
    await page.click('[data-testid="resume-run-btn"]');
    await page.waitForSelector('[data-testid="hud-top"]');

    const persistedStructuresCount = await page.evaluate(() => {
      const api = (window as unknown as { __SOUL_OF_HERO__: { getSnapshot: () => { structures: Record<string, { ownerId: string }> } } }).__SOUL_OF_HERO__;
      return Object.values(api.getSnapshot().structures).filter((s) => s.ownerId === 'player').length;
    });
    if (persistedStructuresCount < 10) {
      throw new Error(`Cross-session IndexedDB persistence failed: expected >=10 player structures, got ${persistedStructuresCount}`);
    }

    await page.keyboard.press('i');
    await page.waitForSelector('[data-testid="panel-inventory"]');
    await page.waitForTimeout(250);

    const s4Path = path.join(SCREENSHOT_DIR, '04_inventory_craft_custody_1280x720.png');
    await page.screenshot({ path: s4Path });
    metricsLog['04_inventory_craft_custody_1280x720.png'] = inspectPngNonBlack(s4Path);
    await page.keyboard.press('i'); // close panel

    // ================= 5. LAYERED POI & TOXIC HAZARD GATE =================
    await page.evaluate(() => {
      const api = (window as unknown as { __SOUL_OF_HERO__: { getSnapshot: () => Record<string, unknown> } }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as {
        world: { pois: { defId: string; gateTileX: number; gateTileY: number }[] };
        actors: { player: { x: number; y: number; radDose: number } };
      };
      const refinery = st.world.pois.find((p) => p.defId === 'poi_refinery_factory')!;
      st.actors.player.x = refinery.gateTileX * 16 + 8;
      st.actors.player.y = (refinery.gateTileY + 2) * 16 + 8;
      st.actors.player.radDose = 18;
    });
    await page.waitForTimeout(300);

    const s5Path = path.join(SCREENSHOT_DIR, '05_poi_hazard_gate_1280x720.png');
    await page.screenshot({ path: s5Path });
    metricsLog['05_poi_hazard_gate_1280x720.png'] = inspectPngNonBlack(s5Path);

    // ================= 6. COMBAT, CHARGED CORE CAST & ELDER BOSS TELEGRAPH =================
    await page.evaluate(() => {
      const api = (window as unknown as {
        __SOUL_OF_HERO__: {
          getSnapshot: () => Record<string, unknown>;
          dispatchIntent: (i: unknown) => void;
        };
      }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as {
        actors: {
          player: { x: number; y: number; radDose: number };
          elders: { defId: string; x: number; y: number; aiState: string; windupRemainingMs: number; telegraphPos: unknown }[];
        };
        items: Record<string, unknown>;
        run: { runId: string };
      };
      const cinder = st.actors.elders.find((e) => e.defId === 'elder_cinder')!;
      st.actors.player.x = cinder.x - 36;
      st.actors.player.y = cinder.y + 12;
      st.actors.player.radDose = 0;

      // Put Elder into visible Slam Telegraph Ring & equip Frost Core
      cinder.aiState = 'telegraph_windup';
      cinder.windupRemainingMs = 750;
      cinder.telegraphPos = { x: cinder.x - 24, y: cinder.y + 8, radiusPx: 46 };

      st.items.itm_e2e_core = {
        instanceId: 'itm_e2e_core',
        defId: 'core_frost',
        runId: st.run.runId,
        count: 1,
        charges: 8,
        quality: 100,
        location: { kind: 'player_bag', slotIndex: 14 },
        provenanceReceiptId: 'e2e_poi_vault',
      };
      api.dispatchIntent({
        intentId: 'e2e_equip_frost',
        kind: 'EQUIP_ITEM',
        itemInstanceId: 'itm_e2e_core',
      });
      api.dispatchIntent({
        intentId: 'e2e_cast_frost',
        kind: 'START_ACT_ON_TARGET',
        targetWorldX: cinder.x,
        targetWorldY: cinder.y,
      });
    });
    await page.waitForTimeout(450); // Let Frost Core AOE blast & Elder telegraph render!

    const s6Path = path.join(SCREENSHOT_DIR, '06_combat_core_elder_telegraph_1280x720.png');
    await page.screenshot({ path: s6Path });
    metricsLog['06_combat_core_elder_telegraph_1280x720.png'] = inspectPngNonBlack(s6Path);

    // ================= 7. FINAL-72 RAGNAROK & ESCROW DEPOSIT (RƯƠNG KÝ GỬI) =================
    await page.evaluate(() => {
      const api = (window as unknown as {
        __SOUL_OF_HERO__: {
          getSnapshot: () => Record<string, unknown>;
          dispatchIntent: (i: unknown) => void;
        };
      }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as {
        world: { spawnRegions: { tileX: number; tileY: number }[] };
        actors: { player: { x: number; y: number } };
        items: Record<string, unknown>;
        structures: Record<string, { defId: string }>;
        run: { runId: string };
      };
      const sp = st.world.spawnRegions[0];
      st.actors.player.x = sp.tileX * 16 + 8;
      st.actors.player.y = sp.tileY * 16 + 8;

      st.items.itm_e2e_escrow_kit = {
        instanceId: 'itm_e2e_escrow_kit',
        defId: 'escrow_chest_item',
        runId: st.run.runId,
        count: 1,
        quality: 100,
        location: { kind: 'player_bag', slotIndex: 15 },
        provenanceReceiptId: 'e2e_vendor_buy',
      };
      st.items.itm_e2e_cash = {
        instanceId: 'itm_e2e_cash',
        defId: 'ragnarok_cash',
        runId: st.run.runId,
        count: 185,
        quality: 100,
        location: { kind: 'player_bag', slotIndex: 16 },
        provenanceReceiptId: 'e2e_final72_vault',
      };

      api.dispatchIntent({
        intentId: 'e2e_jump_f72',
        kind: 'QA_ADVANCE_CLOCK',
        advanceSeconds: 952_000,
      });

      api.dispatchIntent({
        intentId: 'e2e_place_escrow',
        kind: 'BUILD_STRUCTURE',
        structureDefId: 'escrow_chest',
        tileX: sp.tileX - 1,
        tileY: sp.tileY,
      });
    });

    await page.keyboard.press('i');
    await page.waitForTimeout(250);
    // Click Deposit Physical Cash button inside Inventory drawer!
    await page.locator('button:has-text("Deposit 185 Physical Cash")').click();
    await page.waitForTimeout(300);

    const s7Path = path.join(SCREENSHOT_DIR, '07_ragnarok_escrow_deposit_1280x720.png');
    await page.screenshot({ path: s7Path });
    metricsLog['07_ragnarok_escrow_deposit_1280x720.png'] = inspectPngNonBlack(s7Path);

    // ================= 8. EVACUATE, HISTORY ARCHIVE & RUN 2 WIPE AT 640x360 =================
    await page.evaluate(() => {
      const api = (window as unknown as {
        __SOUL_OF_HERO__: {
          getSnapshot: () => Record<string, unknown>;
          dispatchIntent: (i: unknown) => void;
        };
      }).__SOUL_OF_HERO__;
      const st = api.getSnapshot() as {
        world: { pois: { id: string; defId: string; centerX: number; centerY: number }[] };
        actors: { player: { x: number; y: number } };
      };
      const evac = st.world.pois.find((p) => p.defId === 'poi_evacuation_harbor')!;
      st.actors.player.x = evac.centerX * 16 + 8;
      st.actors.player.y = evac.centerY * 16 + 8;
      api.dispatchIntent({
        intentId: 'e2e_evac_now',
        kind: 'EVACUATE_RUN',
        poiId: evac.id,
      });
    });

    await page.setViewportSize({ width: 640, height: 360 });
    await page.waitForSelector('[data-testid="run-finalized-modal"]');
    await page.click('[data-testid="proceed-next-run-btn"]');
    await page.waitForSelector('[data-testid="title-screen"]');
    await page.locator('button:has-text("History (1)")').click();
    await page.waitForSelector('[data-testid="history-panel"]');
    await page.waitForTimeout(250);

    const s8Path = path.join(SCREENSHOT_DIR, '08_post_run_history_run2_640x360.png');
    await page.screenshot({ path: s8Path });
    metricsLog['08_post_run_history_run2_640x360.png'] = inspectPngNonBlack(s8Path);

    fs.writeFileSync(
      path.join(SCREENSHOT_DIR, 'visual_verification_metrics.json'),
      JSON.stringify(metricsLog, null, 2)
    );

    console.log('=== PLAYWRIGHT REAL-BROWSER E2E & SCREENSHOT VERIFICATION PASSED ===');
    console.table(metricsLog);

    await browser.close();
  } finally {
    server.kill('SIGKILL');
  }
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
  console.error(err);
  process.exit(1);
});
