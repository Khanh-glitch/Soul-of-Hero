# Public-Repository Research, Selective Reuse & Integration (`§1R`)

## 1. Executive Summary & Supply-Chain Verification

Before authoring game-specific code, live discovery was executed across public repositories (GitHub), npm registry metadata (`npm view`, `npm audit`), and CC0 open game-art archives (Kenney.nl / OpenGameArt). Every adopted package and asset has a permissive, verified redistribution license (`MIT`, `BSD-3-Clause`, `ISC`, `Apache-2.0`, `CC0-1.0`) shipped in `licenses/` and indexed in `third_party_manifest.json`.

**Supply-Chain Gate Catch & Resolution:** During `npm audit --omit=dev`, `zod@4.3.6` flagged `GHSA-mrhx-c7xc-m3w5` (collection validation memory exhaustion in `<4.6.6`). We immediately upgraded to `zod@4.6.7` and re-ran `npm audit --omit=dev` -> **`found 0 vulnerabilities`**. Zero runtime cloud/CDN calls exist; `vite-plugin-singlefile` bundles all code and CC0 sprite sheets for 100% offline play.

---

## 2. `BUILD_OR_REUSE` Evaluation Matrix (K1–K8 & Presentation/QA)

| Subsystem / K-System | Searched Engineering Problem | Evaluated Public Candidates & Licenses | Decision | Integration Adapter & Soul-of-Hero Law Added | Relevant C01–C24 Evidence |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **K2 / K5 / K7 Navigation & LOS** | Synchronous 2D grid A* pathfinding + shadowcasting FOV/LOS in TypeScript | 1. `ondras/rot.js` (`rot-js@2.2.1`, BSD-3-Clause, 0 deps, native TS)<br>2. `prettymuchbryce/easystarjs` (`0.4.4`, MIT, async callback ticker, unmaintained 5y)<br>3. `qiao/PathFinding.js` (MIT, untyped legacy CJS) | **ADOPT** `rot-js@2.2.1` (REJECT `easystarjs` async callbacks & `pathfinding` legacy CJS) | Wrapped in `src/sim/navigation.ts`: added dynamic door open/close state, wall occlusion, frozen-water `ice` walkability, cart width/shallow-water blocks, and non-omniscient creature sight/footprint checks. | `C05`, `C07`, `C08`, `C11`, `C13`, `C24` |
| **K2 Persistent Island Topology** | Seeded multi-octave 2D height/moisture/temperature noise | 1. `jwagner/simplex-noise.js` (`simplex-noise@4.0.3`, MIT, 0 deps, TS)<br>2. `Auburn/FastNoiseLite` JS port | **ADOPT** `simplex-noise@4.0.3` | Wrapped in `src/sim/worldGen.ts`: added persistent 192×192 island mask, eastern Sea Gulf + walkable Isthmus, 2 freshwater lakes, 4 safe spawns, physical roads, 10 layered POIs, and 6 Elder arenas. | `C13`, `C14`, `C19`, `C24` |
| **K1 / K4 / K8 Deterministic PRNG** | Pure functional seeded PRNG with serializable state inside `GameState` | 1. `dubzzz/pure-rand` (`pure-rand@8.4.2`, MIT, 0 deps, TS)<br>2. `davidbau/seedrandom` (MIT, CJS/mutable)<br>3. `rot-js` global `ROT.RNG` (singleton state) | **ADOPT** `pure-rand@8.4.2` (`xoroshiro128plus`) | Wrapped in `src/sim/rng.ts`: stores explicit 4-word `rngState` inside `GameState` so candidate rollbacks and offline replays are 100% deterministic. | `C01`–`C24`, `test:simulation` |
| **K8 Atomic Persistence & Migrations** | IndexedDB multi-store atomic transactions (`snapshots` + `profiles` + `receipts`) | 1. `jakearchibald/idb` (`idb@8.0.4`, ISC, 0 deps, ~1.2KB, TS)<br>2. `dexie/Dexie.js` (`4.4.7`, Apache-2.0, heavy ORM)<br>3. `jakearchibald/idb-keyval` (no multi-store tx) | **ADOPT** `idb@8.0.4` + `zod@4.6.7` | Wrapped in `src/sim/persistence.ts`: single `readwrite` transaction commits snapshot, profile wallet, and event receipts together + Zod corruption detection + `localStorage` fallback. | `C06`, `C09`, `C17`, `C23` |
| **K1 / K3 / K4 / K6 / K8 Survival & Ragnarok Economy** | Single-custody item ledger, 4-path run-local research, non-omniscient footprint AI, Final-72 finite cash & `Rương ký gửi` escrow | Inspected open survival/RPG starters on GitHub; generic survival repos bake in Respawn-on-Reload, omniscient base raids, or permanent cross-run gear trees violating `LOCKED_CANON`. | **REJECT** full game templates; **AUTHOR** clean-room TypeScript state engine over `pure-rand`/`rot-js`/`idb` | Authored `src/sim/custody.ts`, `src/sim/dispatcher.ts`, and `src/sim/simulationTick.ts` enforcing 100% of `LOCKED_CANON` laws in one state/action/receipt authority. | `C01`–`C24`, `QA-A01`–`QA-A09` |
| **Pixel Art Tiles, Characters & Monsters** | Cohesive 16×16 top-down pixel tiles, props, M/F Adventurers, and monsters with compatible redistribution license | 1. **Kenney Tiny Town** + **Kenney Tiny Dungeon** (16×16, `CC0-1.0`, identical `#2e222f` outline palette)<br>2. Liberated Pixel Cup (LPC, `CC-BY-SA-3.0/GPL-3.0` — copyleft share-alike complexity; 32×32 scale mismatch) | **ADOPT ASSET** Kenney `Tiny Town` + `Tiny Dungeon` (`CC0-1.0`); **REJECT** LPC copyleft/scale mismatch; **AUTHOR** matching `#2e222f` procedural pixel sprites for Elders & Escrow Vault | Integrated in `src/assets/kenney/*.png` and `src/render/spriteAtlas.ts`. Procedurally painted 6 Elders × 2 forms (`24×24`), `Rương ký gửi`, Final-72 Vault, Generator, Turbine, Turret, and ore veins in the exact Kenney palette. | Visual Gates `01`–`08` |
| **Local WebAudio SFX** | Offline browser sound effects without external MP3/CDN files | 1. `KilledByAPixel/ZzFX` (`zzfx@1.4.0`, MIT, 0 deps)<br>2. `chr15m/jsfxr` | **ADOPT** `zzfx@1.4.0` | Wrapped in `src/audio/sfx.ts` with mute/volume state and headless browser safety guards. | Playable UX & Audio |
| **QA, Property & Real Browser Testing** | Property fuzzing for anti-dupe conservation + real IndexedDB + real headless Chromium screenshots | `vitest`, `fast-check@4.10.2` (MIT), `fake-indexeddb@6.2.7` (Apache-2.0), `playwright` (Apache-2.0), `pngjs` (MIT) | **ADOPT** all 5 in dev/test pipeline | Integrated in `tests/contracts-and-abuse.test.ts` and `scripts/verify-browser-and-screenshots.ts`. | All C01–C24 & Screenshots `01`–`08` |

---

## 3. Build vs. Reuse Accounting

- **Generic Subsystems Not Rebuilt from Zero (Reused via Verified Open Source / CC0):**
  1. 2D Simplex Noise permutation & gradient tables (`simplex-noise`)
  2. Grid A* priority-queue pathfinder & precise shadowcasting FOV (`rot-js`)
  3. `xoroshiro128plus` jumpable PRNG state math (`pure-rand`)
  4. IndexedDB Promise/transaction lifecycle & version upgrade plumbing (`idb`) + runtime schema parser (`zod`)
  5. WebAudio FM/noise retro waveform synthesizer (`zzfx`)
  6. 264 base 16×16 pixel sprites across overworld flora, roofs, walls, doors, tools, weapons, potions, M/F Adventurers, Vendor NPC, and 8 monster species (Kenney `CC0-1.0`)
  7. Property-test shrinking engine (`fast-check`), W3C IndexedDB Node shim (`fake-indexeddb`), and Chromium automation (`playwright`)
- **Original Soul-of-Hero Modules Authored Cleanly:**
  - Single-custody item ledger (`src/sim/custody.ts`), 9 human-editable JSON catalogs (`src/data/*.json`), C01–C24 atomic action dispatcher (`src/sim/dispatcher.ts`), bounded chronological offline catch-up & non-omniscient footprint-tracking AI (`src/sim/simulationTick.ts`), bespoke Elder/Escrow/Ragnarok pixel sprites & 640×360 integer renderer (`src/render/*`), compact non-clipping HUD (`src/components/*`), and 13-bot balance benchmark (`scripts/run-simulation.ts`).

---

## 4. Final Reuse Acceptance Gate Check (`§1R R5`)

1. **Genuine public-repository search performed:** PASS (npm registry, GitHub repos, OpenGameArt/Kenney archives inspected live).
2. **Verified redistribution rights & traceable provenance:** PASS (`third_party_manifest.json` + 12 license texts in `licenses/`).
3. **Every adopted element connected to live game or build/test pipeline:** PASS (`rot-js`, `simplex-noise`, `pure-rand`, `idb`, `zod`, `zzfx`, `lucide-react`, Kenney CC0 PNGs in `dist/index.html`; `vitest`, `fast-check`, `fake-indexeddb`, `playwright`, `pngjs` in `npm test` and browser verification).
4. **One authoritative state / clock / custody system preserved:** PASS (`GameState` in `src/sim/types.ts`, single `dispatchAction` in `src/sim/dispatcher.ts`, single `items` custody map in `src/sim/custody.ts`).
5. **Local tests and real browser visual proof:** PASS (`12/12` Vitest suites, `39/39` simulation bot runs, `8/8` Playwright Chromium PNGs visually inspected).
6. **Zero runtime cloud/repository dependence:** PASS (`dist/index.html` runs 100% offline).
