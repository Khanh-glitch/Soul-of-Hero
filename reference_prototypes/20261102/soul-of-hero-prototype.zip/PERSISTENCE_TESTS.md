# Persistence, Chronological Offline Catch-Up & Anti-Dupe Proof (`PERSISTENCE_TESTS.md`)

## 1. Storage Architecture (`src/sim/persistence.ts`)

- **Primary Store**: IndexedDB database `soul_of_hero_world_sim_db` (schema `v1`) managed via `idb@8.0.4` with three object stores committed in **one single `readwrite` transaction**:
  1. `snapshots` (`active_state`: complete versioned `GameState`, `rngState`, `processedIntentIds`, `sourceStocks`, `structures`, `items`, `jobs`, `footprints`, `terrainEffects`)
  2. `profiles` (`active_profile`: `securedRagnarokCash`, `achievements`, `runHistory`, `depositReceiptIds`)
  3. `receipts` (keyed by immutable `receiptId`)
- **Fallback Mirror**: `localStorage` (`soul_of_hero_snapshot_v1`) for restricted sandboxed contexts.
- **Corruption & Tamper Guard**: On load, `validateGameStateSnapshot` parses the envelope via `zod@4.6.7` AND executes `assertCustodyInvariants(state)` (`src/sim/custody.ts`), rejecting duplicate-slot occupancy, negative/over-limit stacks, or malformed schemas without crashing the app.

---

## 2. Deterministic Bounded Chronological Offline Replay (`src/sim/simulationTick.ts:catchUpOffline`)

When a saved session reopens after `Δt` UTC seconds, `catchUpOffline` advances through exact causal event breakpoints (station fuel exhaustion timestamps, active job completion timestamps, weather front shifts, 264h Final-72 and 312h Day-14 phase rollovers, capped at 1,500 bounded intervals) rather than frame-by-frame ticking:

1. **Mid-Period Fuel Exhaustion (`C06`, Abuse `(h)`)**:
   - Verified in `tests/contracts-and-abuse.test.ts`: A `stone_furnace` smelting `iron_ore` (`20s` work) loaded with `10s` of fuel over a `7,200s` (2-hour) offline gap runs for **exactly `10.0s`**, sets `fuelRemainingSec = 0`, transitions to `paused_no_fuel`, and produces zero unpowered output for the remaining `7,190s`.
2. **Sheltered Starvation Floor vs. Lethal Hazards (`C09`)**:
   - Verified in `tests/contracts-and-abuse.test.ts` and Bot `12`/`13`: Offline starvation inside a roofed shelter stops at `1 HP` (`LOCKED_CANON`), whereas offline radiation in `toxic` terrain or freezing in `snow` terrain without protection deals full lethal damage, creates exactly one UUID `DeathBagInstance`, and respawns the Adventurer in the active run.
3. **Source Recovery & Final-72 Non-Respawn (`C14`, `C15`)**:
   - Depleted natural trees recover only when `elapsedRealSeconds >= respawnAtElapsedSec` (never on scene/tab reload). `final72_ragnarok_vault` nodes have `respawnSeconds: null` and `respawnAtElapsedSec: null` permanently.

---

## 3. Verified Cross-Session & Anti-Duplication Test Matrix

| Test Case | Harness | Verification Outcome |
| :--- | :--- | :--- |
| Duplicate `intentId` harvest / vendor buy / escrow deposit | `vitest` (`fake-indexeddb`) | **PASS** — `processedIntentIds` and `profile.depositReceiptIds` reject replay with zero extra items or cash. |
| Arbitrary stack split & container transfer conservation | `fast-check` (25 random op sequences) | **PASS** — `assertCustodyInvariants` holds after every operation; total item count is invariant. |
| Node IndexedDB write → connection reset → reload | `vitest` (`tests/contracts-and-abuse.test.ts`) | **PASS** — Placed `escrow_chest`, `securedRagnarokCash`, and receipts match pre-close state identically. |
| Real Chromium tab build cabin → `page.close()` → new tab `Resume Run #1` | `playwright` (`scripts/verify-browser-and-screenshots.ts`) | **PASS** — All `19` placed cabin structures, items, and coordinates persisted across real Chromium page close & reopen (`04_inventory_craft_custody_1280x720.png`). |
| Tampered snapshot with two items in `player_bag` slot `0` | `vitest` (`validateGameStateSnapshot`) | **PASS** — Refused cleanly with `"Custody invariant violation: duplicate occupancy at bag:0"`. |
| Run 1 Evacuation → Run 2 Reset | `vitest` + `playwright` (`08_post_run_history_run2_640x360.png`) | **PASS** — 100% of Run 1 structures, recipes, Cores, and unsecured physical cash wiped; `profile.securedRagnarokCash` (`185`) and `runHistory` preserved. |
