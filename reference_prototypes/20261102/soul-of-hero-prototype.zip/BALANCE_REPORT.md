# Balance Parameters, Coupled Equations & Simulation Report (`BALANCE_REPORT.md`)

## 1. Runtime Data Source of Truth

All numeric parameters reside in `src/data/balance.prototype.v1.json` (validated at boot by `BalanceCatalogSchema` in `src/sim/catalogs.ts`) and the 8 companion catalogs (`items.json`, `recipes.json`, `sources.json`, `structures.json`, `enemies.json`, `bosses.json`, `skills.json`, `pois.json`).

### Approval Status Summary
- **`LOCKED_CANON`**:
  - `maxRunRealSeconds = 1,209,600 s` (336 real UTC hours)
  - `ragnarokFinalSeconds = 259,200 s` (Final 72 real UTC hours; unlocks at `950,400 s` / 264h)
  - `elderAwakenStartSeconds = 1,123,200 s` (Day 14 / 312h awakening of all 6 Elders)
  - `elderCount = 6`
  - `offlineShelterStarvationMinHp = 1 HP` (prevents hunger-only offline death inside valid roofed shelter while keeping cold, radiation, fire, and monsters lethal)
  - `logicalCanvas = 640 × 360 px`
- **`PROPOSED_MECHANISM`** (Reversible prototype policies, never claimed as creator-locked):
  - `claimRadiusTiles = 10`, `maxOwnedClaimsPerRun = 2` (Territory Claim Cabinet home land rights)
  - `loadedContainerReclaimPolicy = "refuse_until_emptied"` (0-loss loaded container protection)
  - `depletedCoreStudyEligible = false` (`studyRequiresMinCharges: 1` on charged Cores)
  - `escrowChestVendorCashPrice = 120` Ragnarok Cash at Freeport Quartermaster accepting physical or profile cash for first-run zero-wallet feasibility
  - `forecastHorizonSeconds = 14,400 s` (non-omniscient barometer window)
  - `elderStoneThresholdBonusScore = [0, 120, 260, 420, 620, 860, 1500]`
- **`PROTOTYPE_TUNING`**:
  - Active hunger drain `2.5 pts/real hour` (~40h active baseline), thirst drain `4.0 pts/real hour` (~25h active baseline; `2.1×` in volcanic ash; `0.35×` offline sheltered)
  - Walk speed `85 px/s`, sprint `120 px/s`; soft carry `32 kg`, hard limit `56 kg`; Hand-Cart `95 kg` across `10 slots`
  - Fictional daylight cycle `5,400 s` (90 real minutes)
  - Final-72 Vault yield `160–240` physical Ragnarok Cash across `3` non-boss vaults + `3` high-risk fringe vaults (zero respawn)

---

## 2. Coupled Gameplay Relationships Verified

1. **Tool Investment vs. Humble Knife**:
   - Starter `survival_knife` deals `11` creature damage (`0.42s` cadence -> defeats `34–38 HP` novice crab/hound in 4 hits) and `1.0×` roadside salvage, but `0.45×` wood and `0.0×` mineral ore.
   - Crafting `stone_hatchet` (`5 wood + 4 stone`) boosts timber yield `3.1×` (`0.45× -> 1.4×`); `stone_pickaxe` (`5 wood + 5 stone`) deals `18` mineral node damage (`7 + 11` bonus) and unlocks `1.15×` iron ore extraction while dealing only `7` creature damage.
2. **Non-Positive Craft/Reclaim Loop**:
   - Structure reclaim returns `floor(cost * 0.65 * (hp / maxHp))`, guaranteeing zero raw-material multiplication exploits.
3. **Freight & Surface Tradeoffs**:
   - Carrying `31.2 kg` of raw iron ore on foot approaches the `32 kg` encumbrance knee; loading it into the `hand_cart` drops personal burden to `2.2 kg` and rolls at `1.06 × 1.18 = 1.25×` base speed on roads (`178 px` per 2s) vs `0.58 × 0.64 = 0.37×` in marsh, while footprints decay in `480 s` on road vs `2,400 s` in marsh.
4. **Zero-Wallet No-Elder First Escrow Feasibility**:
   - With `profile.securedRagnarokCash = 0` and `0` Elders fought, 3 independent non-boss Final-72 vaults (`poi_sealed_bunker`, `poi_refinery_factory`, `poi_sunken_treasury`) each yield `160–240` physical cash. Even a **single** vault worst-case roll (`160`) covers the `120` cash `Rương ký gửi` purchase and leaves `+40` net positive secured deposit (`+200` to `+360` across 2 vaults).

---

## 3. 13-Bot × 3-Seed Simulation & ±20% Sensitivity Results (`npm run test:simulation`)

Executed via `scripts/run-simulation.ts` (`39` deterministic runs across seeds `20260414`, `20260501`, `20260619`; raw artifact saved in `simulation_results.json`):

- **Bot `10_nonboss_ragnarok_first_escrow` Secured Deposit Distribution (1 Vault Sampled, 0 Elders Fought)**:
  - Minimum: **`+48` Secured Cash**
  - Median: **`+103` Secured Cash**
  - Maximum: **`+111` Secured Cash**
- **Offline Lifecycle Comparison**:
  - Bot `12_offline_sheltered_sleeper` (48h offline under roofed floor): **`0` deaths**, clamped safely above/at `1 HP` floor.
  - Bot `13_offline_unprepared_exposed` (6h offline exposed in Glacial Crown snow without coat): **`1` lawful freezing death**, `1` physical Death Bag created at death tile.

### Simultaneous ±20% Adverse Perturbation Sweep

| Perturbation | Adjusted Vault Min Cash | Adjusted Escrow Chest Price | 1-Vault Worst Net | 2-Non-Boss-Vaults Worst Net | 3-Non-Boss-Vaults Worst Net | Active Hunger Empty (h) | Active Thirst Empty (h) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **`-20%` (Favorable)** | 192 | 96 | `+96` | **`+288` (PASS)** | `+480` | 50.0 h | 31.3 h |
| **`0%` (Baseline)** | 160 | 120 | `+40` | **`+200` (PASS)** | `+360` | 40.0 h | 25.0 h |
| **`+20%` (Adverse: -20% Cash & +20% Price)** | 128 | 144 | `-16` | **`+112` (PASS)** | `+240` | 33.3 h | 20.8 h |

Even under simultaneous `-20%` vault payout AND `+20%` chest price, visiting 2 of the 3 non-boss Final-72 vaults guarantees **`>= +112` net secured Ragnarok cash** without fighting any Elder or relying on rare RNG drops.
