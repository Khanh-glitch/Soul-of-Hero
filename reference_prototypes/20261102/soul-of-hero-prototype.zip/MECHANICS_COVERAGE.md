# Mechanics & Contract Coverage Audit (`MECHANICS_COVERAGE.md`)

## 1. K1–K8 Canonical Subsystem Register

| K-ID | System | Authority Path | Status | Notes & Approval Classification |
| :--- | :--- | :--- | :--- | :--- |
| **K1** | Item & Custody Ledger | `src/sim/custody.ts`, `src/data/items.json` (56 items) | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | Single `state.items` custody dictionary; unique `instanceId` conserved across bag, quickbar, equip, chest, cart, death bag, ground. `assertCustodyInvariants` verified via `fast-check`. (`LOCKED_CANON`) |
| **K2** | World Substrate & Causality | `src/sim/worldGen.ts`, `src/sim/navigation.ts`, `src/sim/simulationTick.ts` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | Persistent 192×192 island (sea gulf, walkable isthmus, 2 lakes, forest, plains, marsh, hills, volcanic ash, snow, toxic crater, physical roads). Real weather, day/night FOV, fire spread/rain quench, water-to-ice freeze. |
| **K3** | Three Legitimate Source Economies | `src/data/sources.json` (17 node kinds), `resolveHarvestOnSource` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | `NATURAL`, `HUMAN_MADE` (roadside barrels/crates/industrial heaps), and `RARE` (Core pedestals, non-respawning Final-72 Ragnarok Vaults). |
| **K4** | Knowledge, Craft & Paid Work | `src/data/recipes.json` (34 recipes), `START_JOB`, `START_RESEARCH` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | Single `run.learnedRecipeIds` across starter, blueprint, bounded random Spares, directed Spares, and destructive specimen study (`studyRequiresMinCharges: 1` `PROPOSED_MECHANISM`). |
| **K5** | Actor, Combat & Creature Knowledge | `src/data/enemies.json` (8 species), `src/data/bosses.json` (6 Elders), `advanceCreaturesAndElders` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | M/F Adventurers; non-omniscient LOS + physical decaying footprint-trail following; zero base-GPS raids; 1-HP offline shelter hunger floor (`LOCKED_CANON`). |
| **K6** | Homestead, Territory & Layered POIs | `src/data/structures.json` (22 structures), `src/data/pois.json` (10 POIs) | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | Piece-by-piece floors, walls, doors, cutaway roofs, stations, power grid, turrets, Territory Claim Cabinet (`PROPOSED_MECHANISM`), and gated POIs with emergency interior egress. |
| **K7** | Travel, Freight & Location Strategy | `MOVE_INPUT`, `DEPLOY_VEHICLE`, `TOGGLE_CART_TETHER` | `PLAYABLE_INTEGRATED` | Physical 10-slot / 95kg `hand_cart`, surface speed multipliers (road 1.18× vs marsh 0.64×), carry encumbrance, narrow single-door cart block. |
| **K8** | Two Clocks, Ragnarok & Escrow | `advanceClockAndPhase`, `catchUpOffline`, `DEPOSIT_ESCROW_CASH`, `finalizeRunOnce` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` | 336h UTC run clock, Final 72h phase (264h), Day 14 Elder awakening (312h), physical `Rương ký gửi` atomic deposit, Run 2 total local wipe preserving only Secured Cash, achievements, and `LOCAL_UNVERIFIED` history. |

---

## 2. Single Authoritative C01–C24 Causal Contract Traceability

| Edge | Summary | Code Path (`src/sim/`) | Automated & Browser Test Evidence | Acceptance State |
| :--- | :--- | :--- | :--- | :--- |
| **C01** | Source → Harvest | `dispatcher.ts:resolveHarvestOnSource` | `contracts-and-abuse.test.ts` (C01/C02), `02_hud_terrain_harvest_1280x720.png` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C02** | Roadside Salvage → Spares/Work | `dispatcher.ts:INTERACT_NEARBY` | `contracts-and-abuse.test.ts` (C01/C02), Bot `01` & `03`, Screenshot `02` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C03** | Found Rare Instance → Immediate Use | `dispatcher.ts:START_ACT_ON_TARGET`, `commitActiveCastNow` | `contracts-and-abuse.test.ts` (C03/C05), Bot `07`, Screenshot `06` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C04** | Many Research Sources → One Knowledge Store | `dispatcher.ts:START_RESEARCH`, `USE_ITEM` (blueprint) | `contracts-and-abuse.test.ts` (C04), Bots `05` & `08` | `PLAYABLE_INTEGRATED` |
| **C05** | Shared Action / Target Material & World Mutation | `dispatcher.ts:commitActiveCastNow`, `skills.json` | `contracts-and-abuse.test.ts` (Knife vs Pickaxe yield; Frost Core freezes water to walkable ice), Screenshot `06` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C06** | Farm / Furnace / Work Timeline | `dispatcher.ts:FUEL_STATION`, `START_JOB`, `simulationTick.ts:advanceStationsAndJobs` | `contracts-and-abuse.test.ts` (C06/C09 10s fuel over 2h offline stops at 10s), Bot `04` | `PLAYABLE_INTEGRATED` |
| **C07** | General Build, Custody & Reclaim | `dispatcher.ts:BUILD_STRUCTURE`, `RECLAIM_STRUCTURE`, `TRANSFER_ITEM` | `contracts-and-abuse.test.ts` (C07 + `fast-check` 25-run property test), Screenshots `03` & `04` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C08** | Footprint Discovery → Optional Home Contact | `dispatcher.ts:MOVE_INPUT`, `simulationTick.ts:advanceCreaturesAndElders` | `contracts-and-abuse.test.ts` (C08 unseen home never attacked; rain erases trail), Screenshot `03` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C09** | Preparation → Causal Offline Consequence | `simulationTick.ts:catchUpOffline`, `advancePlayerSurvival`, `GamePanels.tsx` (Menu) | `contracts-and-abuse.test.ts` (C06/C09 1-HP shelter hunger floor vs lethal offline radiation), Bots `12` & `13` | `PLAYABLE_INTEGRATED` |
| **C10** | Hit → Death / Bag / Bed / Recovery | `simulationTick.ts:handlePlayerDeathIfLethal`, `dispatcher.ts:RECOVER_DEATH_BAG` | `contracts-and-abuse.test.ts` (C10 single UUID Death Bag, same-run respawn, physical reach required) | `PLAYABLE_INTEGRATED` |
| **C11** | POI Exterior → Deep Legal Access | `worldGen.ts`, `dispatcher.ts:UNLOCK_POI_GATE` | `contracts-and-abuse.test.ts` (C11 keycard check + interior emergency egress anti-softlock), Bot `09`, Screenshot `05` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C12** | Optional Hint / Quest Out of Order | `dispatcher.ts:recognizeOptionalHint` | `contracts-and-abuse.test.ts` (C12/QA-A01..A09 retroactive receipt recognition without gates) | `UNIT_VERIFIED` |
| **C13** | Real Routes & Net Trip Economy | `dispatcher.ts:MOVE_INPUT`, `DEPLOY_VEHICLE`, `TOGGLE_CART_TETHER` | `contracts-and-abuse.test.ts` (C13), Bot `06` (31.2kg ore loaded into cart) | `PLAYABLE_INTEGRATED` |
| **C14** | Time / Weather Changes Opportunities | `simulationTick.ts:advanceClockAndPhase`, `advanceEnvironmentAndTraces` | `contracts-and-abuse.test.ts` (C14 no scene-switch respawn; timed clock recovery; storm trace wash) | `PLAYABLE_INTEGRATED` |
| **C15** | Finite Final-72 Cash Source | `sources.json:final72_ragnarok_vault`, `resolveHarvestOnSource` | `contracts-and-abuse.test.ts` (C15 blocked before 264h; `respawnAtElapsedSec === null`), Bot `10` | `PLAYABLE_INTEGRATED` |
| **C16** | Zero-Wallet First Escrow | `pois.json:offer_escrow_chest_physical` (`PROPOSED_MECHANISM`), `BUILD_STRUCTURE` | `contracts-and-abuse.test.ts` (C16), Bot `10` (+48..+111 net secured from 1 non-boss vault) | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C17** | Exactly-Once Chest Deposit | `dispatcher.ts:DEPOSIT_ESCROW_CASH` | `contracts-and-abuse.test.ts` (C17 atomic debit/credit + duplicate replay rejection), Screenshot `07` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C18** | Next-Run Physical Profile Spend | `dispatcher.ts:BUY_VENDOR_OFFER` (`profile_secured_cash`) | `contracts-and-abuse.test.ts` (C18 Run 2 vendor purchase debits wallet, creates run-local item, 0 score) | `UNIT_VERIFIED` |
| **C19** | Six Optional Elders in Physical World | `bosses.json`, `worldGen.ts`, `simulationTick.ts`, `commitActiveCastNow` | `contracts-and-abuse.test.ts` (C19 Day-14 awakening + unique stone), Bot `11`, Screenshot `06` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C20** | Unique Score Events | `dispatcher.ts:awardUniqueScoreEvent`, `computeRunUnverifiedScore` | `contracts-and-abuse.test.ts` (C20 non-grindable milestones; zero cash conversion) | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C21** | Personal History vs Verified Online Rank | `dispatcher.ts:finalizeRunOnce`, `TitleAndEndScreens.tsx` | `contracts-and-abuse.test.ts` (C21 `LOCAL_UNVERIFIED` / `QA_ACCELERATED_UNVERIFIED`), Screenshot `08` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C22** | Physical Evacuation & Run Finalization | `dispatcher.ts:EVACUATE_RUN`, `ABANDON_RUN`, `finalizeRunOnce` | `contracts-and-abuse.test.ts` (C22 does NOT auto-deposit carried cash; finalizes once), Screenshot `08` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C23** | Run Reset & Profile Exceptions | `dispatcher.ts:START_NEW_RUN`, `worldGen.ts:createNewRunState` | `contracts-and-abuse.test.ts` (C23 wipes structures/items/recipes/cash; retains profile cash/history) | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |
| **C24** | Multiple Independent Starts & Coherence | `worldGen.ts:getBaseIslandTopology` | `contracts-and-abuse.test.ts` (C24 A* reachability from all 4 safe spawns), Screenshot `01` | `NATIVE_OR_BROWSER_VISUALLY_INSPECTED` |

---

## 3. J01–J20 Gameplay Opportunities & QA-A01–A09 Counterfactuals

- **J01–J20**: Verified as emergent sandbox affordances (zero `journey_complete` flags, zero quest gates) across the 13 deterministic policy bots (`scripts/run-simulation.ts`) and `tests/contracts-and-abuse.test.ts`:
  - `J01`–`J02` (Knife-first & Roadside serendipity): Bots `01`, `03`, Screenshot `02`.
  - `J03`–`J04` (Immediate Core cast vs Research/Scrap utility): Bots `05`, `07`, `08`, Screenshot `06`.
  - `J05`–`J06`, `J09` (Chosen home, route/trace exposure, home industry): Bot `04`, Screenshots `03`, `04`.
  - `J07`–`J08`, `J14` (Trip net cost, exterior/deep POI, Hand-Cart freight): Bots `06`, `09`, Screenshot `05`.
  - `J10`–`J12` (Instant logout, causal offline return, single Death Bag recovery): Bots `12`, `13`, `C09`/`C10` tests.
  - `J13` (Multipurpose tool & skill world mutation): Bot `02`, `C01`/`C05` tests.
  - `J15`–`J17`, `J20` (No-Elder Final-72 cash, zero-wallet first escrow, evacuation vs deposit, Run 2 wipe): Bot `10`, Screenshots `07`, `08`.
  - `J18`–`J19` (Six optional Elders & honest `LOCAL_UNVERIFIED` history): Bot `11`, `C19`–`C21` tests, Screenshot `08`.
- **Adversarial QA-A01..QA-A09**: Verified in `tests/contracts-and-abuse.test.ts` (`A01` ignore hints, `A02` zero Core, `A03` delayed build, `A04` Ash Caldera fringe build, `A05` leave/revisit gated POI, `A06` zero-Elder escrow & evacuation, `A07` unprepared blizzard logout, `A08` mid-run death bag recovery + IndexedDB reload, `A09` immediate abandon -> clean Run 2).
- **Negative Abuse Cases `(a)`–`(t)`**: All 20 abuse fixtures implemented and passing in `tests/contracts-and-abuse.test.ts`.

---

## 4. Truthful Disclosure of Scope & Non-Claimed Items

1. **Canonical Gold Skill/Boss Rasters (`REQUIRES_SOURCE` -> `GOLD_SOURCE_NOT_AVAILABLE`)**: Original Gold pixel rasters and frame timings are not supplied; skills and Elders use crisp replaceable prototype VFX and procedural `#2e222f`-outlined pixel sprites (`skills.json`, `bosses.json`).
2. **Global Verified Leaderboard (`REQUIRES_SOURCE` / Backend Absent)**: Because this is a standalone offline-first browser prototype with no server authority, all scores are truthfully tagged `LOCAL_UNVERIFIED` (or `QA_ACCELERATED_UNVERIFIED` when Dev QA clock is used).
3. **Distant Off-Screen Creature Simulation Radius**: During real-time and offline ticks, ordinary habitat patrols beyond `580px` (~36 tiles) from the Adventurer pause local patrol stepping unless actively tracking a footprint trail (`src/sim/simulationTick.ts`), avoiding O(N) CPU waste while never fabricating random offline raids.
