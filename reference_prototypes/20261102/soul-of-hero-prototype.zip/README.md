# Soul of Hero: World Simulation Prototype

A playable, offline-first, top-down 2D pixel-art solo PvE survival action-RPG browser prototype built with **pure deterministic TypeScript simulation**, **HTML5 Canvas 2D (`640×360` logical integer scaling)**, **React (HUD/drawers reading immutable snapshots & submitting intents only)**, **IndexedDB atomic persistence**, and **procedural local WebAudio (`zzfx`)**.

---

## Quick Start & Commands (Node 20+)

```bash
npm install
npm run dev              # Launch playable local dev server
npm run build            # Compile self-contained offline production build (dist/index.html)
npm test                 # Run Vitest C01-C24 contract, fast-check property, abuse & IndexedDB suite
npm run test:simulation  # Run 13 playstyle policy bots × 3 seeds + ±20% balance sensitivity sweeps
```

Optional real-browser Playwright Chromium E2E & screenshot verification:
```bash
npx tsx scripts/verify-browser-and-screenshots.ts
```

---

## Controls

| Input | Action |
| :--- | :--- |
| **`W A S D` / `Arrow Keys`** | Move Adventurer (hold **`Shift`** to Sprint) |
| **Mouse Aim + Left Click** | Swing equipped tool/weapon, cast charged Core, or place selected Build structure |
| **Right Click** | Cancel active pre-commit Core cast (spends **0** charges!) or clear Build brush |
| **`E`** *(remappable)* | Interact nearby: salvage barrels/crates, loot vaults, open doors/POI gates, recover Death Bag |
| **`1` – `8`** | Use / equip Quickbar slot `1–8` |
| **`I`** *(remappable)* | Toggle **Custody & Containers** (Equip, Split, Chests, Hand-Cart, Vendor, `Rương ký gửi` Escrow, Evacuation) |
| **`C`** *(remappable)* | Toggle **Craft & Station Queues** (Hand, Workbench, Fueled Furnace, Cooking Hearth, Garden Planter) |
| **`B`** *(remappable)* | Toggle **Build & Territory** (22 structures + live Canvas footprint ghost & validity reason) |
| **`R`** *(remappable)* | Toggle **Research & Specimen Desk** (Random Spares, Directed Spares, Blueprint, Specimen Study) |
| **`M`** *(remappable)* | Toggle **Discovered 192×192 Island Map** & Surface Freight/Trace Guide |
| **`J`** *(remappable)* | Toggle **Context Journal**, 6 Optional Elder Stones & Immutable Event Receipt Ledger |
| **`Tab`** | Toggle **Skill Driver Inspector** & Live Keybinding Remapper |
| **`Esc`** | Close active panel, or open **Session Menu, Non-Omniscient Shelter Logout Prep & Dev/QA Clock** |

---

## Canonical World Laws Implemented

- **Author Your Own Story**: Choose Female or Male Adventurer and land at any of **4 verified safe starting regions** on a persistent 192×192 island (coast, eastern Sea Gulf & walkable Isthmus, freshwater lakes, forests, plains, marsh, hills, volcanic Ash Caldera, Glacial Crown snow, Fallout Crater radiation, physical roads, and 10 layered POIs). Zero mandatory quest chain, zero Core choice popup, zero forced Elder boss.
- **Single Custody & Multipurpose Items (`K1`)**: 56 items share one custody ledger (`src/sim/custody.ts`). Tools fight and harvest with distinct creature damage vs. material yield; charged Cores work immediately upon discovery or can be destructively studied at a Research Desk while `>= 1` charge remains (`PROPOSED_MECHANISM`).
- **Non-Omniscient Footprint Creature AI (`K5`, `C08`)**: 8 habitat monsters sense only via true `rot-js` line-of-sight or physical decaying player footprints (mud/snow retain traces longer than dry road/rock; rain washes trails `3.2×` faster). Monsters have **zero** GPS awareness of unseen player homes.
- **Two Clocks & Causal Offline Catch-Up (`K8`, `C06`, `C09`)**: Runs last up to **336 real UTC hours** (including while closed), with **Final 72h Ragnarok** at `264h` and **6 Optional Elders Awakening** on Day 14 (`312h`). Reopening settles fuel exhaustion, jobs, weather, traces, and hazards chronologically. A roofed shelter prevents offline hunger-only death below `1 HP` (`LOCKED_CANON`), while freezing, radiation, fire, and lawful monsters remain lethal.
- **Finite Ragnarok Cash & `Rương Ký Gửi` Escrow (`C15`–`C18`, `C22`–`C23`)**: Physical Ragnarok Cash originates solely from non-respawning Final-72 vaults (including 3 non-Elder routes). Buy a run-local `Rương ký gửi` (`PROPOSED_MECHANISM` vendor route for zero-wallet first run), place it on owned home territory (`Territory Claim Cabinet`), and deposit cash atomically into Profile Secured Cash. Evacuating, abandoning, or expiring wipes 100% of run-local state while preserving Secured Cash, achievements, and honest `LOCAL_UNVERIFIED` run history.

---

## Editable Data Catalogs & Documentation

- **Editable Runtime Catalogs**: `src/data/balance.prototype.v1.json`, `items.json`, `recipes.json`, `sources.json`, `structures.json`, `enemies.json`, `bosses.json`, `skills.json`, `pois.json`.
- **Engineering & QA Deliverables**:
  - `REPOSITORY_RESEARCH_AND_REUSE.md` & `third_party_manifest.json` + `licenses/`
  - `MECHANICS_COVERAGE.md` (K1–K8, C01–C24, J01–J20, QA-A01–A09, abuse `(a)`–`(t)`)
  - `BALANCE_REPORT.md` & `simulation_results.json`
  - `PERSISTENCE_TESTS.md`
  - `VISUAL_REVIEW.md` & `screenshots/01..08_*.png`
  - `GODOT_TRANSFER_NOTES.md`
