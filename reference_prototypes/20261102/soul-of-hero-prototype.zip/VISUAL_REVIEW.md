# Visual Inspection & Resolution Framing Audit (`VISUAL_REVIEW.md`)

## 1. Resolution & Crisp Integer-Scaling Verification

- **Logical World Canvas**: `640 × 360` pixels (`src/render/canvasRenderer.ts`), `ctx.imageSmoothingEnabled = false`, CSS `image-rendering: pixelated; crisp-edges`.
- **Native `640 × 360` Bounding-Box Audit (`scripts/verify-browser-and-screenshots.ts`)**:
  - `[data-testid="hud-top"]` and `[data-testid="hud-bottom"]` verified programmatically in headless Chromium at `640×360`: `x >= 0`, `y >= 0`, `x + width <= 640`, `y + height <= 360` — **zero clipped HUD controls**.
- **`1280 × 720` (`2×` Integer Scale) Audit**:
  - 16×16 Kenney CC0 & procedural `#2e222f`-palette sprites render at crisp `32×32` screen pixels with zero bilinear blur; right-side floating panels (`[I]`, `[C]`, `[B]`, `[R]`, `[M]`, `[J]`, `[Tab]`, `[Esc]`) scroll internally while keeping the live world and character visible on the left.

---

## 2. Real Defect Caught & Fixed via Direct Visual Inspection

During our first visual inspection of the captured PNGs (rather than trusting file byte sizes), we spotted that rows `4..9` of `tiny_dungeon_packed.png` (`12 cols × 11 rows`) were offset by `-1` row (`adventurer_male` rendered a rail fence from row 6 instead of the tunic adventurer on row 7, and `roadside_barrel` rendered a rail track from row 5 instead of the barrel on row 6). We corrected `KENNEY_SPRITE_MAP` in `src/render/spriteAtlas.ts`, re-ran Playwright, and visually re-verified every sprite across screenshots `01`–`08`.

---

## 3. Inspected Screenshot Register (`screenshots/`)

Pixel metrics decoded by `pngjs` (`screenshots/visual_verification_metrics.json`) and visually inspected:

| Screenshot Path | Resolution | Non-Black Pixel Ratio | Unique 12-bit Color Buckets | Visual Elements Verified |
| :--- | :---: | :---: | :---: | :--- |
| `screenshots/01_title_new_run_640x360.png` | `640×360` | `0.587` | `209` | Crisp Female & Male 16×16 Adventurer sprites, 4 safe starting region cards, Profile Secured Cash (`0`), `History (0)`, full unclipped controls bar at native `640×360`. |
| `screenshots/02_hud_terrain_harvest_1280x720.png` | `1280×720` | `0.999` | `453` | Female Adventurer wielding pixel Survival Knife on dirt road outside gated stone POI courtyard, floating `+2x Roadside Scrap`, wooden supply chests, pine/oak trees, patrolling Brute (`!`), Quickbar potions/berries. |
| `screenshots/03_build_indoor_roof_fade_1280x720.png` | `1280×720` | `0.957` | `426` | Player-constructed 3×3 timber cabin with palisade walls, cabin door, Territory Claim Cabinet, Homestead Bed, Smelting Furnace, Storage Chest, outdoor barrel & road footprints, **16% cutaway faded roof**, and `[B]` Build & Territory drawer (`OWNED HOME LAND`). |
| `screenshots/04_inventory_craft_custody_1280x720.png` | `1280×720` | `0.972` | `410` | Post-tab-close/reopen persisted cabin + `[I]` Custody & Containers drawer showing Equipped slot, 20-slot pack stacks, `Homestead Bunk Bed (Bind & Rest)`, `Territory Claim Cabinet`, and `Timber Storage Chest` slots alongside live world. |
| `screenshots/05_poi_hazard_gate_1280x720.png` | `1280×720` | `1.000` | `355` | `Slag Basin Refinery [GATED]` nameplate, iron portcullis security gate, deep Final-72 Vault visible inside locked chamber, green radiation particles, `RAD 18` top HUD badge, animated white shoreline sea foam. |
| `screenshots/06_combat_core_elder_telegraph_1280x720.png` | `1280×720` | `1.000` | `462` | `Cinder Colossus [LATENT]` on Ash Caldera with red circular slam telegraph zone, `Glacier Lattice Core` icy blue Nova ring hitting both Elder (`-29`) and Ash Hound (`-32`), crimson-gold Final-72 Vault on caldera rim. |
| `screenshots/07_ragnarok_escrow_deposit_1280x720.png` | `1280×720` | `0.976` | `480` | `FINAL 72H • 71.6h` crimson badge, `Ash Wind` particles, golden `Rương Ký Gửi` placed inside cabin, committed toast `Escrow deposit committed: +185 Secured Ragnarok Cash`, top HUD `₵0/🔒185`. |
| `screenshots/08_post_run_history_run2_640x360.png` | `640×720` -> `640×360` | `0.868` | `191` | Post-evacuation archive at native `640×360`: `Run #1 • EVACUATED (female)`, `Secured Deposit: +185 | Unsecured Cash Wiped: 0`, `450 pts`, `QA_ACCELERATED_UNVERIFIED` badge, `Profile Secured Cash: 185` ready for Run #2. |
