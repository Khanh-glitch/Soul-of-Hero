import 'fake-indexeddb/auto';
import { describe, expect, it, beforeEach } from 'vitest';
import fc from 'fast-check';
import { BALANCE, ITEMS, POIS, RECIPES_LIST, SOURCES } from '../src/sim/catalogs';
import {
  assertCustodyInvariants,
  computePlayerCarriedMassKg,
  countPlayerItem,
  getEquippedItem,
  grantItemsToPlayerOrGround,
} from '../src/sim/custody';
import { computeRunUnverifiedScore, dispatchAction } from '../src/sim/dispatcher';
import { findPathTiles, getEffectiveSurface, isTileWalkable } from '../src/sim/navigation';
import {
  clearAllSavedDataForTests,
  loadGameStateAndCatchUp,
  resetPersistenceConnectionForTests,
  saveGameStateAtomic,
  validateGameStateSnapshot,
} from '../src/sim/persistence';
import { catchUpOffline, stepSimulation } from '../src/sim/simulationTick';
import { createDefaultProfile, createNewRunState } from '../src/sim/worldGen';

describe('Soul of Hero — Authoritative Simulation, C01-C24 Contracts, Negative Abuse & Persistence', () => {
  beforeEach(async () => {
    resetPersistenceConnectionForTests();
    await clearAllSavedDataForTests();
  });

  it('C24: Persistent island topology across runs & all 4 safe spawn regions have reachable wood, stone, water, salvage, vendor & evacuation', () => {
    const profile = createDefaultProfile(1_700_000_000_000);
    const s1 = createNewRunState({ profile, worldSeed: 20260414, spawnRegionId: 'spawn_west_cove' });
    expect(s1.world.spawnRegions.length).toBeGreaterThanOrEqual(4);

    for (const sp of s1.world.spawnRegions) {
      const st = createNewRunState({
        profile,
        worldSeed: 20260414,
        spawnRegionId: sp.id,
        adventurerGender: sp.id === 'spawn_north_glade' ? 'male' : 'female',
      });
      const nearSources = Object.values(st.sourceStocks).filter(
        (src) => Math.hypot(src.tileX - sp.tileX, src.tileY - sp.tileY) <= 8
      );
      expect(nearSources.some((x) => SOURCES[x.defId].materialType === 'wood')).toBe(true);
      expect(nearSources.some((x) => SOURCES[x.defId].materialType === 'stone')).toBe(true);
      expect(nearSources.some((x) => x.defId === 'fresh_spring')).toBe(true);
      expect(nearSources.some((x) => SOURCES[x.defId].economyClass === 'HUMAN_MADE')).toBe(true);

      // Verify A* reachability from spawn to Freeport Vendor & Evacuation Harbor
      const vendor = st.world.pois.find((p) => p.defId === 'poi_frontier_vendor')!;
      const evac = st.world.pois.find((p) => p.defId === 'poi_evacuation_harbor')!;
      const pathVendor = findPathTiles(st, sp.tileX, sp.tileY, vendor.centerX, vendor.centerY + 4, {
        maxExpanded: 12000,
      });
      const pathEvac = findPathTiles(st, sp.tileX, sp.tileY, evac.centerX - 2, evac.centerY, {
        maxExpanded: 16000,
      });
      expect(pathVendor).not.toBeNull();
      expect(pathEvac).not.toBeNull();
    }
  });

  it('C01, C02 & Abuse (a)(b): Harvest natural & roadside salvage, separate tool efficiency, reject empty source & duplicate intent replay', () => {
    let state = createNewRunState({
      profile: createDefaultProfile(),
      spawnRegionId: 'spawn_west_cove',
    });
    const sp = state.world.spawnRegions.find((s) => s.id === 'spawn_west_cove')!;

    // Roadside barrel near spawn (C02)
    const barrel = Object.values(state.sourceStocks).find(
      (s) => s.defId === 'roadside_barrel' && Math.hypot(s.tileX - sp.tileX, s.tileY - sp.tileY) <= 7
    )!;
    state.actors.player.x = barrel.tileX * 16 + 8;
    state.actors.player.y = (barrel.tileY + 1) * 16 + 8;

    const loot1 = dispatchAction(state, {
      intentId: 'loot_barrel_1',
      kind: 'INTERACT_NEARBY',
      targetId: barrel.id,
    });
    expect(loot1.ok).toBe(true);
    state = loot1.state;
    const scrapAfter1 = countPlayerItem(state, 'scrap_metal');
    expect(scrapAfter1).toBeGreaterThan(0);

    // Abuse (b): Replay exact same intentId -> rejected with zero duplicate yield!
    const replay = dispatchAction(state, {
      intentId: 'loot_barrel_1',
      kind: 'INTERACT_NEARBY',
      targetId: barrel.id,
    });
    expect(replay.ok).toBe(false);
    expect(countPlayerItem(replay.state, 'scrap_metal')).toBe(scrapAfter1);

    // Exhaust remaining barrel stock
    while (state.sourceStocks[barrel.id].stock > 0) {
      const r = dispatchAction(state, {
        intentId: `drain_${state.revision}`,
        kind: 'INTERACT_NEARBY',
        targetId: barrel.id,
      });
      expect(r.ok).toBe(true);
      state = r.state;
    }

    // Abuse (a): Attempt to loot depleted barrel -> rejected!
    const emptyLoot = dispatchAction(state, {
      intentId: 'loot_empty_barrel',
      kind: 'INTERACT_NEARBY',
      targetId: barrel.id,
    });
    expect(emptyLoot.ok).toBe(false);

    // Tool efficiency check: Survival Knife has 0.0 ore efficiency on Iron Vein vs Stone Pickaxe 1.15x!
    const veinId = 'test_iron_vein';
    state.sourceStocks[veinId] = {
      id: veinId,
      defId: 'iron_vein',
      tileX: sp.tileX + 1,
      tileY: sp.tileY,
      stock: 4,
      maxStock: 4,
      hitsRemaining: 20,
      maxHits: 20,
      depletedAtElapsedSec: null,
      respawnAtElapsedSec: null,
      consumedReceiptIds: [],
    };
    state.actors.player.x = sp.tileX * 16 + 8;
    state.actors.player.y = sp.tileY * 16 + 8;

    const knifeSwing = dispatchAction(state, {
      intentId: 'knife_on_ore',
      kind: 'START_ACT_ON_TARGET',
      targetWorldX: (sp.tileX + 1) * 16 + 8,
      targetWorldY: sp.tileY * 16 + 8,
    });
    state = stepSimulation(knifeSwing.state, 0.5);
    expect(countPlayerItem(state, 'iron_ore')).toBe(0); // Knife cannot mine iron ore!

    // Grant & equip Stone Pickaxe -> mines Iron Ore cleanly
    const granted = grantItemsToPlayerOrGround(state, 'stone_pickaxe', 1, 'test_grant');
    state = dispatchAction(state, {
      intentId: 'eq_pick',
      kind: 'EQUIP_ITEM',
      itemInstanceId: granted.grantedIds[0],
    }).state;
    state.actors.player.cooldownUntilSec = 0;

    state = dispatchAction(state, {
      intentId: 'pick_on_ore',
      kind: 'START_ACT_ON_TARGET',
      targetWorldX: (sp.tileX + 1) * 16 + 8,
      targetWorldY: sp.tileY * 16 + 8,
    }).state;
    state = stepSimulation(state, 0.6);
    expect(countPlayerItem(state, 'iron_ore')).toBeGreaterThan(0);
  });

  it('C03, C05 & Abuse (l): Found charged Core works immediately without recipe, pre-commit cancel spends 0 charges, Frost Core freezes water to walkable ice', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    expect(state.run.learnedRecipeIds.includes('recipe_core_frost')).toBe(false);

    const g = grantItemsToPlayerOrGround(state, 'core_frost', 1, 'found_core_rcpt');
    const coreId = g.grantedIds[0];
    const initialCharges = state.items[coreId].charges!;
    expect(initialCharges).toBe(8);

    state = dispatchAction(state, {
      intentId: 'eq_frost_core',
      kind: 'EQUIP_ITEM',
      itemInstanceId: coreId,
    }).state;

    // Start cast, advance 0.10s (< commitMs 0.40s), then cancel!
    state = dispatchAction(state, {
      intentId: 'cast_cancel_test',
      kind: 'START_ACT_ON_TARGET',
      targetWorldX: state.actors.player.x + 16,
      targetWorldY: state.actors.player.y,
    }).state;
    state = stepSimulation(state, 0.1);
    const canceled = dispatchAction(state, {
      intentId: 'do_cancel_cast',
      kind: 'CANCEL_ACTIVE_CAST',
    });
    expect(canceled.ok).toBe(true);
    state = canceled.state;
    expect(state.items[coreId].charges).toBe(initialCharges); // ZERO charges spent!

    // Now find a shallow_water tile near Crystal Lake (around 63, 76), cast Frost Core & commit!
    let waterTile: { x: number; y: number } | null = null;
    for (let y = 68; y <= 84 && !waterTile; y++) {
      for (let x = 58; x <= 78; x++) {
        if (getEffectiveSurface(state, x, y) === 'shallow_water') {
          waterTile = { x, y };
          break;
        }
      }
    }
    expect(waterTile).not.toBeNull();
    state.actors.player.x = (waterTile!.x - 1) * 16 + 8;
    state.actors.player.y = waterTile!.y * 16 + 8;
    state.actors.player.cooldownUntilSec = 0;

    state = dispatchAction(state, {
      intentId: 'cast_freeze_water',
      kind: 'START_ACT_ON_TARGET',
      targetWorldX: waterTile!.x * 16 + 8,
      targetWorldY: waterTile!.y * 16 + 8,
    }).state;
    state = stepSimulation(state, 0.65);

    expect(state.items[coreId].charges).toBe(initialCharges - 1);
    expect(getEffectiveSurface(state, waterTile!.x, waterTile!.y)).toBe('ice');
    expect(isTileWalkable(state, waterTile!.x, waterTile!.y, { forCart: true })).toBe(true);
  });

  it('C04 & Abuse (f): Four research paths update single knowledge store; depleted 0-charge Core refused for specimen study', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    const ptx = Math.floor(state.actors.player.x / 16);
    const pty = Math.floor(state.actors.player.y / 16);

    grantItemsToPlayerOrGround(state, 'wood_plank', 10, 't');
    grantItemsToPlayerOrGround(state, 'wire_coil', 4, 't');
    grantItemsToPlayerOrGround(state, 'spares_token', 20, 't');
    grantItemsToPlayerOrGround(state, 'blueprint_turret', 2, 't');
    const coreGrant = grantItemsToPlayerOrGround(state, 'core_ember', 1, 't');
    const coreId = coreGrant.grantedIds[0];

    // Place Research Bench
    const bld = dispatchAction(state, {
      intentId: 'bld_res_desk',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'research_bench',
      tileX: ptx + 1,
      tileY: pty,
    });
    expect(bld.ok).toBe(true);
    state = bld.state;
    const deskId = Object.keys(state.structures).find(
      (k) => state.structures[k].defId === 'research_bench'
    )!;

    // 1. Blueprint study
    const bpItem = Object.values(state.items).find((i) => i.defId === 'blueprint_turret')!;
    const useBp = dispatchAction(state, {
      intentId: 'read_bp_1',
      kind: 'USE_ITEM',
      itemInstanceId: bpItem.instanceId,
    });
    expect(useBp.ok).toBe(true);
    state = useBp.state;
    expect(state.run.learnedRecipeIds.includes('recipe_turret_ammo')).toBe(true);

    // Duplicate blueprint read refused without wasting second copy!
    const bpAfter = countPlayerItem(state, 'blueprint_turret');
    const dupBp = dispatchAction(state, {
      intentId: 'read_bp_dup',
      kind: 'USE_ITEM',
      itemInstanceId: Object.values(state.items).find((i) => i.defId === 'blueprint_turret')!.instanceId,
    });
    expect(dupBp.ok).toBe(false);
    expect(countPlayerItem(dupBp.state, 'blueprint_turret')).toBe(bpAfter);

    // 2. Depleted Core (0 charges) refused under prototype policy
    state.items[coreId].charges = 0;
    const depletedTry = dispatchAction(state, {
      intentId: 'study_depleted_core',
      kind: 'START_RESEARCH',
      stationId: deskId,
      mode: 'specimen',
      specimenInstanceId: coreId,
    });
    expect(depletedTry.ok).toBe(false);
    expect(state.items[coreId]).toBeDefined();

    // Restore 1 charge -> destructive specimen study succeeds once!
    state.items[coreId].charges = 1;
    const validStudy = dispatchAction(state, {
      intentId: 'study_charged_core',
      kind: 'START_RESEARCH',
      stationId: deskId,
      mode: 'specimen',
      specimenInstanceId: coreId,
    });
    expect(validStudy.ok).toBe(true);
    state = stepSimulation(validStudy.state, 12);
    const jobId = Object.keys(state.jobs)[0];
    state = dispatchAction(state, {
      intentId: 'claim_core_research',
      kind: 'CLAIM_JOB_OUTPUT',
      jobId,
    }).state;
    expect(state.run.learnedRecipeIds.includes('recipe_core_ember')).toBe(true);
    expect(state.items[coreId]).toBeUndefined();

    // 3. Random Spares research draws strictly from unknown eligible pool
    const beforeCount = state.run.learnedRecipeIds.length;
    const rndRes = dispatchAction(state, {
      intentId: 'rnd_spares_1',
      kind: 'START_RESEARCH',
      stationId: deskId,
      mode: 'random_spares',
    });
    expect(rndRes.ok).toBe(true);
    state = stepSimulation(rndRes.state, 12);
    const rndJobId = state.structures[deskId].activeJobId!;
    state = dispatchAction(state, {
      intentId: 'claim_rnd_spares',
      kind: 'CLAIM_JOB_OUTPUT',
      jobId: rndJobId,
    }).state;
    expect(state.run.learnedRecipeIds.length).toBe(beforeCount + 1);
  });

  it('C06, C09 & Abuse (g)(h): Offline furnace with 180s fuel over 7200s offline window stops at exact fuel exhaustion; sheltered starvation stops at 1 HP while radiation kills', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    const ptx = Math.floor(state.actors.player.x / 16);
    const pty = Math.floor(state.actors.player.y / 16);

    grantItemsToPlayerOrGround(state, 'stone_chunk', 20, 't');
    grantItemsToPlayerOrGround(state, 'scrap_metal', 10, 't');
    grantItemsToPlayerOrGround(state, 'wood_log', 10, 't');
    grantItemsToPlayerOrGround(state, 'wood_plank', 10, 't');
    grantItemsToPlayerOrGround(state, 'plant_fiber', 10, 't');
    grantItemsToPlayerOrGround(state, 'iron_ore', 4, 't');

    // Build roofed floor shelter at player tile + stone furnace next tile
    state = dispatchAction(state, {
      intentId: 'b_floor',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'wood_floor',
      tileX: ptx,
      tileY: pty,
    }).state;
    state = dispatchAction(state, {
      intentId: 'b_roof',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'thatch_roof',
      tileX: ptx,
      tileY: pty,
    }).state;
    state = dispatchAction(state, {
      intentId: 'b_furnace',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'stone_furnace',
      tileX: ptx + 1,
      tileY: pty,
    }).state;

    const furnaceId = Object.keys(state.structures).find(
      (k) => state.structures[k].defId === 'stone_furnace'
    )!;

    // Start smelting WITHOUT fuel -> starts paused_no_fuel; over 2 hours offline makes ZERO progress!
    state = dispatchAction(state, {
      intentId: 'start_unfueled_smelt',
      kind: 'START_JOB',
      recipeId: 'recipe_smelt_iron',
      stationId: furnaceId,
    }).state;
    const jobId = state.structures[furnaceId].activeJobId!;
    expect(state.jobs[jobId].status).toBe('paused_no_fuel');

    // Give furnace only 10s of fuel (less than 20s smelt duration), then replay 2 hours (7200s) offline with 0 food!
    state.structures[furnaceId].fuelRemainingSec = 10;
    state.jobs[jobId].status = 'active';
    state.actors.player.hunger = 0;
    state.actors.player.thirst = 100;
    state.actors.player.hp = 20;

    const caught = catchUpOffline(state, state.clock.lastSimulatedUtcMs + 7200 * 1000, 7200);
    state = caught.state;

    // Abuse (h): Furnace ran ONLY 10s and paused at fuel exhaustion — did NOT magically finish!
    expect(state.jobs[jobId].progressSec).toBeCloseTo(10, 1);
    expect(state.jobs[jobId].status).toBe('paused_no_fuel');
    expect(state.structures[furnaceId].fuelRemainingSec).toBe(0);

    // LOCKED_CANON C09: Sheltered offline player cannot die from starvation alone (clamped at 1 HP)
    expect(state.actors.player.hp).toBe(1);
    expect(state.actors.player.deathCount).toBe(0);

    // Move sheltered structure test to toxic radiation zone without Hazard Suit -> offline radiation IS lethal!
    state.actors.player.x = 144 * 16 + 8;
    state.actors.player.y = 150 * 16 + 8;
    const radOffline = catchUpOffline(state, state.clock.lastSimulatedUtcMs + 1800 * 1000, 1800);
    expect(radOffline.state.actors.player.deathCount).toBeGreaterThanOrEqual(1);
  });

  it('C07 & Abuse (c)(d)(e): Invalid build zero-loss rollback, loaded chest reclaim refusal, dynamic door pathfinding, and fast-check custody property test', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    const ptx = Math.floor(state.actors.player.x / 16);
    const pty = Math.floor(state.actors.player.y / 16);

    grantItemsToPlayerOrGround(state, 'wood_plank', 12, 't');
    grantItemsToPlayerOrGround(state, 'scrap_metal', 4, 't');
    state = dispatchAction(state, {
      intentId: 'split_scrap_for_door',
      kind: 'SPLIT_STACK',
      itemInstanceId: Object.values(state.items).find((i) => i.defId === 'scrap_metal')!.instanceId,
      splitCount: 2,
    }).state;
    const planksBefore = countPlayerItem(state, 'wood_plank');

    // Abuse (c): Invalid build on deep_water tile (0,0) -> rejected with ZERO material loss!
    const badBuild = dispatchAction(state, {
      intentId: 'invalid_water_build',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'storage_chest',
      tileX: 1,
      tileY: 1,
    });
    expect(badBuild.ok).toBe(false);
    expect(countPlayerItem(badBuild.state, 'wood_plank')).toBe(planksBefore);

    // Valid Storage Chest build
    state = dispatchAction(state, {
      intentId: 'valid_chest_build',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'storage_chest',
      tileX: ptx + 1,
      tileY: pty,
    }).state;
    const chestId = Object.keys(state.structures).find(
      (k) => state.structures[k].defId === 'storage_chest'
    )!;

    // Transfer item into chest -> Abuse (d): Reclaiming loaded chest MUST refuse without losing contents!
    const scrapItem = Object.values(state.items).find((i) => i.defId === 'scrap_metal')!;
    state = dispatchAction(state, {
      intentId: 'put_in_chest',
      kind: 'TRANSFER_ITEM',
      itemInstanceId: scrapItem.instanceId,
      toLocation: {
        kind: 'structure_container',
        structureId: chestId,
        port: 'storage',
        slotIndex: 0,
      },
    }).state;

    const reclaimLoaded = dispatchAction(state, {
      intentId: 'reclaim_loaded_chest',
      kind: 'RECLAIM_STRUCTURE',
      structureId: chestId,
    });
    expect(reclaimLoaded.ok).toBe(false);
    expect(reclaimLoaded.state.structures[chestId]).toBeDefined();
    expect(reclaimLoaded.state.items[scrapItem.instanceId]).toBeDefined();

    // Door placement & toggle immediately updates A* walkability
    state = dispatchAction(state, {
      intentId: 'build_door',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'wood_door',
      tileX: ptx,
      tileY: pty + 1,
    }).state;
    const doorId = Object.keys(state.structures).find(
      (k) => state.structures[k].defId === 'wood_door'
    )!;
    expect(isTileWalkable(state, ptx, pty + 1)).toBe(false);
    state = dispatchAction(state, {
      intentId: 'open_door',
      kind: 'TOGGLE_DOOR',
      structureId: doorId,
    }).state;
    expect(isTileWalkable(state, ptx, pty + 1)).toBe(true);

    // Abuse (e): fast-check property test over arbitrary stack splits & slot transfers conserving total items!
    fc.assert(
      fc.property(
        fc.array(
          fc.record({
            op: fc.constantFrom('transfer', 'split'),
            toSlot: fc.integer({ min: 0, max: 14 }),
            splitCnt: fc.integer({ min: 1, max: 4 }),
          }),
          { minLength: 5, maxLength: 25 }
        ),
        (ops) => {
          let s = createNewRunState({ profile: createDefaultProfile() });
          grantItemsToPlayerOrGround(s, 'wood_log', 25, 'fc_init');
          const totalBefore = Object.values(s.items)
            .filter((i) => i.defId === 'wood_log')
            .reduce((acc, i) => acc + i.count, 0);

          ops.forEach((step, idx) => {
            const logs = Object.values(s.items).filter((i) => i.defId === 'wood_log');
            if (logs.length === 0) return;
            const target = logs[idx % logs.length];
            if (step.op === 'split') {
              s = dispatchAction(s, {
                intentId: `fc_spl_${idx}`,
                kind: 'SPLIT_STACK',
                itemInstanceId: target.instanceId,
                splitCount: step.splitCnt,
              }).state;
            } else {
              s = dispatchAction(s, {
                intentId: `fc_xfr_${idx}`,
                kind: 'TRANSFER_ITEM',
                itemInstanceId: target.instanceId,
                toLocation: { kind: 'player_bag', slotIndex: step.toSlot },
              }).state;
            }
            assertCustodyInvariants(s);
          });

          const totalAfter = Object.values(s.items)
            .filter((i) => i.defId === 'wood_log')
            .reduce((acc, i) => acc + i.count, 0);
          expect(totalAfter).toBe(totalBefore);
        }
      ),
      { numRuns: 25 }
    );
  });

  it('C08 & Abuse (j)(k): Monsters have zero GPS knowledge of unobserved home, track contiguous footprints, and lose trail when rain erases footprints', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    const ptx = Math.floor(state.actors.player.x / 16);
    const pty = Math.floor(state.actors.player.y / 16);

    // Place a player wall at (ptx, pty - 4) with ZERO footprints leading to it
    grantItemsToPlayerOrGround(state, 'wood_plank', 8, 't');
    state = dispatchAction(state, {
      intentId: 'build_unseen_home_wall',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'wood_wall',
      tileX: ptx,
      tileY: pty - 4,
    }).state;
    state.footprints = [];

    // Teleport player far away so monster does not see player directly
    state.actors.player.x = (ptx + 40) * 16;
    state.actors.player.y = (pty + 40) * 16;

    // Place a scent-hound near the home (within 6 tiles) with NO footprints
    state.actors.enemies = [
      {
        id: 'hound_test',
        defId: 'plains_hound',
        x: (ptx + 5) * 16 + 8,
        y: (pty - 4) * 16 + 8,
        homeX: (ptx + 5) * 16 + 8,
        homeY: (pty - 4) * 16 + 8,
        hp: 38,
        maxHp: 38,
        alive: true,
        respawnAtSec: null,
        aiState: 'patrol',
        lastSeenPlayerPos: null,
        followedFootprintId: null,
        trailTargetPos: null,
        discoveredStructureId: null,
        lostTimerSec: 0,
        patrolAngle: 0,
        windupRemainingMs: 0,
        windupTargetPos: null,
        windupTargetStructureId: null,
        cooldownRemainingMs: 0,
      },
    ];

    // Abuse (k): Run 20 seconds — hound patrols habitat and NEVER acquires or attacks unseen wall!
    for (let i = 0; i < 20; i++) {
      state = stepSimulation(state, 1.0);
    }
    const wall = Object.values(state.structures).find((s) => s.defId === 'wood_wall')!;
    expect(wall.hp).toBe(wall.maxHp);
    expect(state.actors.enemies[0].aiState).toBe('patrol');

    // Now lay a real 3-segment contiguous footprint trail starting within hound's scent range -> hound enters follow_trail!
    state.footprints = [
      {
        id: 'fp_1',
        tileX: ptx + 3,
        tileY: pty - 4,
        prevId: null,
        createdAtElapsedSec: state.clock.elapsedRealSeconds,
        expireAtElapsedSec: state.clock.elapsedRealSeconds + 45,
        surface: 'grass',
        baseRetentionSec: 45,
        ageProgress01: 0,
      },
      {
        id: 'fp_2',
        tileX: ptx + 2,
        tileY: pty - 4,
        prevId: 'fp_1',
        createdAtElapsedSec: state.clock.elapsedRealSeconds + 1,
        expireAtElapsedSec: state.clock.elapsedRealSeconds + 46,
        surface: 'grass',
        baseRetentionSec: 45,
        ageProgress01: 0,
      },
      {
        id: 'fp_3',
        tileX: ptx + 1,
        tileY: pty - 4,
        prevId: 'fp_2',
        createdAtElapsedSec: state.clock.elapsedRealSeconds + 2,
        expireAtElapsedSec: state.clock.elapsedRealSeconds + 47,
        surface: 'grass',
        baseRetentionSec: 45,
        ageProgress01: 0,
      },
    ];
    state.actors.player.x = (ptx + 12) * 16; // within simulation radius, outside hound sightRangePx (112px)
    state.actors.player.y = (pty + 12) * 16;
    state = stepSimulation(state, 0.25);
    expect(state.actors.enemies[0].aiState).toBe('follow_trail');

    // Abuse (j): Rainstorm washes out the footprint before hound reaches home -> hound loses trail!
    state.clock.weather = 'storm';
    state = stepSimulation(state, 30);
    expect(state.footprints.length).toBe(0);
    expect(state.actors.enemies[0].aiState).not.toBe('follow_trail');
  });

  it('C10, C11, C13 & Abuse (m)(n): Death bag physical recovery, POI keycard/interior emergency anti-softlock, and Hand-Cart freight economics', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    grantItemsToPlayerOrGround(state, 'iron_ingot', 10, 't');
    expect(countPlayerItem(state, 'iron_ingot')).toBe(10);

    // Lethal damage creates 1 Death Bag and respawns player in SAME active run (C10)
    const deathX = state.actors.player.x + 64;
    const deathY = state.actors.player.y;
    state.actors.player.x = deathX;
    state.actors.player.y = deathY;
    state.actors.player.hp = 1;
    // Place active fire on player tile to deal lethal damage
    const ftx = Math.floor(deathX / 16);
    const fty = Math.floor(deathY / 16);
    state.terrainEffects[`${ftx},${fty}`] = {
      id: 'lethal_fire',
      tileX: ftx,
      tileY: fty,
      type: 'fire',
      materialBefore: 'grass',
      startSec: 0,
      endSec: 100,
      spreadGen: 2,
      lastSpreadSec: 0,
      sourceEventId: 'test',
    };
    state = stepSimulation(state, 1.0);
    expect(state.run.status).toBe('active');
    expect(state.actors.player.deathCount).toBe(1);
    expect(Object.keys(state.deathBags).length).toBe(1);
    expect(countPlayerItem(state, 'iron_ingot')).toBe(0); // Not auto-restored!

    // Must physically walk back to Death Bag to recover
    const bag = Object.values(state.deathBags)[0];
    const farRecover = dispatchAction(state, {
      intentId: 'far_rec',
      kind: 'RECOVER_DEATH_BAG',
      bagId: bag.id,
    });
    expect(farRecover.ok).toBe(false);

    state.actors.player.x = bag.x;
    state.actors.player.y = bag.y;
    const nearRecover = dispatchAction(state, {
      intentId: 'near_rec',
      kind: 'RECOVER_DEATH_BAG',
      bagId: bag.id,
    });
    expect(nearRecover.ok).toBe(true);
    state = nearRecover.state;
    expect(countPlayerItem(state, 'iron_ingot')).toBe(10);
    expect(Object.keys(state.deathBags).length).toBe(0);

    // C11 & Abuse (n): Sealed Bunker deep vault refused before gate unlock; interior emergency release prevents softlock
    const bunker = state.world.pois.find((p) => p.defId === 'poi_sealed_bunker')!;
    const gate = state.structures[bunker.gateStructureId!]!;
    state.actors.player.x = gate.tileX * 16 + 8;
    state.actors.player.y = (gate.tileY + 1) * 16 + 8;

    const noKeyTry = dispatchAction(state, {
      intentId: 'try_no_key',
      kind: 'UNLOCK_POI_GATE',
      poiId: bunker.id,
    });
    expect(noKeyTry.ok).toBe(false);

    // Put player inside room with closed gate & 0 keycards -> interior emergency latch opens gate!
    state.actors.player.x = bunker.centerX * 16 + 8;
    state.actors.player.y = (gate.tileY - 1) * 16 + 8;
    const emergencyOut = dispatchAction(state, {
      intentId: 'interior_escape',
      kind: 'UNLOCK_POI_GATE',
      poiId: bunker.id,
    });
    expect(emergencyOut.ok).toBe(true);
    expect(emergencyOut.state.structures[gate.id].isOpen).toBe(true);

    // C13 & Abuse (m): Hand-Cart cargo transfer & road vs marsh speed difference
    state = emergencyOut.state;
    const cartGrant = grantItemsToPlayerOrGround(state, 'hand_cart_kit', 1, 't');
    const sp0 = state.world.spawnRegions[0];
    state.actors.player.x = sp0.tileX * 16 + 8;
    state.actors.player.y = sp0.tileY * 16 + 8;
    const depCart = dispatchAction(state, {
      intentId: 'deploy_cart_1',
      kind: 'DEPLOY_VEHICLE',
      itemInstanceId: cartGrant.grantedIds[0],
      tileX: sp0.tileX + 1,
      tileY: sp0.tileY,
    });
    expect(depCart.ok).toBe(true);
    state = depCart.state;
    const cartId = Object.keys(state.vehicles)[0];

    // Load 10 Iron Ingots into cart -> player carry mass drops!
    const massBeforeLoad = computePlayerCarriedMassKg(state);
    const ingotItem = Object.values(state.items).find((i) => i.defId === 'iron_ingot')!;
    state = dispatchAction(state, {
      intentId: 'load_ingots_cart',
      kind: 'TRANSFER_ITEM',
      itemInstanceId: ingotItem.instanceId,
      toLocation: { kind: 'vehicle_cargo', vehicleId: cartId, slotIndex: 0 },
    }).state;
    expect(computePlayerCarriedMassKg(state)).toBeLessThan(massBeforeLoad);
  });

  it('C15, C16, C17, C18, C22, C23 & Abuse (o)(p)(q)(r)(s)(t) + IndexedDB Cross-Session Persistence: Zero-wallet No-Elder Ragnarok First Escrow -> Evacuate -> Run 2 Reset & Vendor Spend', async () => {
    let state = createNewRunState({
      profile: createDefaultProfile(1_700_000_000_000),
      spawnRegionId: 'spawn_south_meadow',
    });
    expect(state.profile.securedRagnarokCash).toBe(0);

    // Locate non-boss Final-72 vault at Lagoon Causeway Vault (poi_sunken_treasury)
    const treasury = state.world.pois.find((p) => p.defId === 'poi_sunken_treasury')!;
    const vault = Object.values(state.sourceStocks).find(
      (s) => s.poiId === treasury.id && s.defId === 'final72_ragnarok_vault'
    )!;
    expect(vault.nonBossFinal72).toBe(true);

    // Unlock treasury gate with 1 Fuel Canister
    grantItemsToPlayerOrGround(state, 'fuel_canister', 1, 't');
    state.actors.player.x = treasury.gateTileX * 16 + 8;
    state.actors.player.y = (treasury.gateTileY + 1) * 16 + 8;
    state = dispatchAction(state, {
      intentId: 'unlock_treasury',
      kind: 'UNLOCK_POI_GATE',
      poiId: treasury.id,
    }).state;

    // Abuse (o): Before Final 72h, Ragnarok vault MUST refuse to open!
    state.actors.player.x = vault.tileX * 16 + 8;
    state.actors.player.y = (vault.tileY + 1) * 16 + 8;
    const earlyLoot = dispatchAction(state, {
      intentId: 'early_vault_try',
      kind: 'INTERACT_NEARBY',
      targetId: vault.id,
    });
    expect(earlyLoot.ok).toBe(false);
    expect(countPlayerItem(earlyLoot.state, 'ragnarok_cash')).toBe(0);

    // Advance into Final 72h (264.5h) WITHOUT touching any of the 6 Elders (QA-A06)!
    state = dispatchAction(state, {
      intentId: 'advance_to_final72',
      kind: 'QA_ADVANCE_CLOCK',
      advanceSeconds: BALANCE.clock.hazardIntensifyStartSeconds.value + 1800,
    }).state;
    state = stepSimulation(state, 1.0);
    expect(state.clock.phase).toBe('ragnarok_final72');
    expect(state.run.collectedElderStones.length).toBe(0);

    // Abuse (p): Try buying Rương ký gửi at Vendor with 0 cash -> rejected!
    const vendor = state.world.pois.find((p) => p.defId === 'poi_frontier_vendor')!;
    state.actors.player.x = vendor.centerX * 16 + 8;
    state.actors.player.y = vendor.centerY * 16 + 8;
    const brokeBuy = dispatchAction(state, {
      intentId: 'broke_buy_chest',
      kind: 'BUY_VENDOR_OFFER',
      poiId: vendor.id,
      offerId: 'offer_escrow_chest_physical',
    });
    expect(brokeBuy.ok).toBe(false);

    // Loot the non-boss Final-72 vault!
    state.actors.player.x = vault.tileX * 16 + 8;
    state.actors.player.y = (vault.tileY + 1) * 16 + 8;
    const validVaultLoot = dispatchAction(state, {
      intentId: 'loot_final72_vault_1',
      kind: 'INTERACT_NEARBY',
      targetId: vault.id,
    });
    expect(validVaultLoot.ok).toBe(true);
    state = validVaultLoot.state;
    const mintedCash = countPlayerItem(state, 'ragnarok_cash');
    expect(mintedCash).toBeGreaterThanOrEqual(BALANCE.ragnarokEconomy.cashPerFinal72VaultMin.value);
    expect(state.sourceStocks[vault.id].stock).toBe(0);
    expect(state.sourceStocks[vault.id].respawnAtElapsedSec).toBeNull(); // NEVER respawns!

    // Travel to Freeport Vendor and buy Rương ký gửi with physical Ragnarok cash (C16)
    state.actors.player.x = vendor.centerX * 16 + 8;
    state.actors.player.y = vendor.centerY * 16 + 8;
    const buyChest = dispatchAction(state, {
      intentId: 'buy_first_escrow_chest',
      kind: 'BUY_VENDOR_OFFER',
      poiId: vendor.id,
      offerId: 'offer_escrow_chest_physical',
    });
    expect(buyChest.ok).toBe(true);
    state = buyChest.state;
    const remainingCashToDeposit = countPlayerItem(state, 'ragnarok_cash');
    expect(remainingCashToDeposit).toBeGreaterThan(0);

    // Move to South Meadow clearing (94, 154) — try placing Escrow Chest WITHOUT Territory Claim -> rejected!
    state.actors.player.x = 94 * 16 + 8;
    state.actors.player.y = 154 * 16 + 8;
    const unownedPlace = dispatchAction(state, {
      intentId: 'place_escrow_unowned',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'escrow_chest',
      tileX: 95,
      tileY: 154,
    });
    expect(unownedPlace.ok).toBe(false);
    expect(countPlayerItem(unownedPlace.state, 'escrow_chest_item')).toBe(1); // Not lost!

    // Place Territory Claim Cabinet -> now legitimately owned home land -> place Escrow Chest!
    grantItemsToPlayerOrGround(state, 'wood_plank', 8, 't');
    grantItemsToPlayerOrGround(state, 'stone_chunk', 6, 't');
    grantItemsToPlayerOrGround(state, 'scrap_metal', 4, 't');
    state = dispatchAction(state, {
      intentId: 'place_home_claim',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'claim_cabinet',
      tileX: 93,
      tileY: 154,
    }).state;

    const ownedPlace = dispatchAction(state, {
      intentId: 'place_escrow_owned',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'escrow_chest',
      tileX: 95,
      tileY: 154,
    });
    expect(ownedPlace.ok).toBe(true);
    state = ownedPlace.state;
    const escrowStructId = Object.keys(state.structures).find(
      (k) => state.structures[k].defId === 'escrow_chest'
    )!;

    // C17 & Abuse (q): Deposit physical cash -> atomically debits pack & credits profile once!
    const dep = dispatchAction(state, {
      intentId: 'deposit_cash_1',
      kind: 'DEPOSIT_ESCROW_CASH',
      structureId: escrowStructId,
    });
    expect(dep.ok).toBe(true);
    state = dep.state;
    expect(countPlayerItem(state, 'ragnarok_cash')).toBe(0);
    expect(state.profile.securedRagnarokCash).toBe(remainingCashToDeposit);
    expect(state.run.status).toBe('active'); // Depositing does NOT end run!

    // Replay deposit intent -> rejected without double credit!
    const dupDep = dispatchAction(state, {
      intentId: 'deposit_cash_1',
      kind: 'DEPOSIT_ESCROW_CASH',
      structureId: escrowStructId,
    });
    expect(dupDep.ok).toBe(false);
    expect(dupDep.state.profile.securedRagnarokCash).toBe(remainingCashToDeposit);

    // Cross-Session IndexedDB Persistence Test: save, close connection, reload in new session!
    await saveGameStateAtomic(state);
    resetPersistenceConnectionForTests();
    const reloaded = await loadGameStateAndCatchUp(state.clock.lastSimulatedUtcMs + 5000);
    expect(reloaded.found).toBe(true);
    expect(reloaded.state!.profile.securedRagnarokCash).toBe(remainingCashToDeposit);
    expect(reloaded.state!.structures[escrowStructId]).toBeDefined();
    state = reloaded.state!;

    // Give player 15 unsecured physical cash, then physically Evacuate at Cape Beacon Harbor (C22)
    // Verify carried unsecured cash is NOT auto-deposited!
    grantItemsToPlayerOrGround(state, 'ragnarok_cash', 15, 'unsecured_leftover');
    const evacPoi = state.world.pois.find((p) => p.defId === 'poi_evacuation_harbor')!;
    state.actors.player.x = evacPoi.centerX * 16 + 8;
    state.actors.player.y = evacPoi.centerY * 16 + 8;

    const evacRes = dispatchAction(state, {
      intentId: 'evacuate_run_1',
      kind: 'EVACUATE_RUN',
      poiId: evacPoi.id,
    });
    expect(evacRes.ok).toBe(true);
    state = evacRes.state;
    expect(state.run.status).toBe('evacuated');
    expect(state.profile.securedRagnarokCash).toBe(remainingCashToDeposit); // Still exact secured amount!
    const hist1 = state.profile.runHistory[0];
    expect(hist1.cashLostUnsecured).toBe(15);
    expect(hist1.verificationStatus).toBe('QA_ACCELERATED_UNVERIFIED'); // Abuse (t): Honest unverified label!

    // C23 & Abuse (s): Start Run 2 -> ALL Run 1 structures, escrow chest, recipes, items, cash wiped; ONLY profile persists!
    const run2Res = dispatchAction(state, {
      intentId: 'begin_run_2',
      kind: 'START_NEW_RUN',
      adventurerGender: 'male',
      spawnRegionId: 'spawn_north_glade',
      nowUtcMs: Date.now(),
    });
    expect(run2Res.ok).toBe(true);
    let run2 = run2Res.state;
    expect(run2.run.runNumber).toBe(2);
    expect(run2.profile.securedRagnarokCash).toBe(remainingCashToDeposit);
    expect(run2.structures[escrowStructId]).toBeUndefined();
    expect(countPlayerItem(run2, 'ragnarok_cash')).toBe(0);
    expect(run2.run.learnedRecipeIds.length).toBe(
      RECIPES_LIST.filter((r) => r.starterKnown).length
    );

    // C18: Spend Profile Secured Cash at Freeport Vendor in Run 2 for run-local gear (if balance >= 25)
    const r2Vendor = run2.world.pois.find((p) => p.defId === 'poi_frontier_vendor')!;
    run2.actors.player.x = r2Vendor.centerX * 16 + 8;
    run2.actors.player.y = r2Vendor.centerY * 16 + 8;
    const scoreBeforeSpend = computeRunUnverifiedScore(run2);
    const spendRes = dispatchAction(run2, {
      intentId: 'run2_vendor_buy',
      kind: 'BUY_VENDOR_OFFER',
      poiId: r2Vendor.id,
      offerId: 'offer_rations_profile',
    });
    expect(spendRes.ok).toBe(true);
    run2 = spendRes.state;
    expect(run2.profile.securedRagnarokCash).toBe(remainingCashToDeposit - 25);
    expect(countPlayerItem(run2, 'cooked_stew')).toBe(3);
    expect(computeRunUnverifiedScore(run2)).toBe(scoreBeforeSpend); // Spending cash gives 0 leaderboard points!
  });

  it('Corruption detection: validateGameStateSnapshot rejects tampered duplicate-slot custody snapshot cleanly', () => {
    const state = createNewRunState({ profile: createDefaultProfile() });
    const ids = Object.keys(state.items);
    // Tamper two distinct items onto exact same slot
    state.items[ids[0]].location = { kind: 'player_bag', slotIndex: 0 };
    state.items[ids[1]].location = { kind: 'player_bag', slotIndex: 0 };
    const check = validateGameStateSnapshot(state);
    expect(check.valid).toBe(false);
    expect(check.error).toContain('duplicate occupancy');
  });

  it('C19: Six distinct optional Elders transition from latent to awakened on Day 14 and drop unique stones once per run', () => {
    let state = createNewRunState({ profile: createDefaultProfile() });
    expect(state.actors.elders.length).toBe(6);
    expect(state.actors.elders.every((e) => e.form === 'latent')).toBe(true);

    // Advance to Day 14 (312.5h) -> all 6 living Elders awaken!
    state = dispatchAction(state, {
      intentId: 'jump_day14',
      kind: 'QA_ADVANCE_CLOCK',
      advanceSeconds: BALANCE.clock.elderAwakenStartSeconds.value + 1800,
    }).state;
    state = stepSimulation(state, 1.0);
    expect(state.clock.phase).toBe('ragnarok_day14_awakened');
    expect(state.actors.elders.every((e) => e.form === 'awakened')).toBe(true);

    // Defeat Mire Leviathan via committed combat strike -> awards elder_stone_mire once
    const mire = state.actors.elders.find((e) => e.defId === 'elder_mire')!;
    mire.hp = 5;
    state.actors.player.x = mire.x - 16;
    state.actors.player.y = mire.y;
    state = dispatchAction(state, {
      intentId: 'strike_mire_elder',
      kind: 'START_ACT_ON_TARGET',
      targetWorldX: mire.x,
      targetWorldY: mire.y,
    }).state;
    state = stepSimulation(state, 0.5);
    expect(state.run.collectedElderStones).toContain('elder_stone_mire');
    expect(countPlayerItem(state, 'elder_stone_mire')).toBe(1);
  });

  it('C12, C14, C20, C21 & Adversarial Counterfactuals QA-A01..QA-A09: Out-of-order hints, no scene-reload respawn, non-grindable local unverified score, and full counterfactual freedom', () => {
    let state = createNewRunState({
      profile: createDefaultProfile(),
      spawnRegionId: 'spawn_east_haven',
      adventurerGender: 'female',
    });

    // QA-A01, A02, A03, A04: Ignore all hints/quests, never touch Core, delay building, then build in remote Ash Caldera border!
    expect(Object.keys(state.optionalHintsRecognized).length).toBe(0);

    // C14: Deplete a natural source -> moving away and back does NOT respawn it early; only its real respawnAtElapsedSec clock restores it
    const tree = Object.values(state.sourceStocks).find((s) => s.defId === 'pine_tree' && s.stock > 0)!;
    tree.stock = 0;
    tree.depletedAtElapsedSec = 10;
    tree.respawnAtElapsedSec = 7210;
    state.actors.player.x = 10 * 16;
    state = stepSimulation(state, 60);
    expect(state.sourceStocks[tree.id].stock).toBe(0); // Still depleted after 60s!
    const afterRespawn = catchUpOffline(state, Date.now() + 7300 * 1000, 7300);
    state = afterRespawn.state;
    expect(state.sourceStocks[tree.id].stock).toBe(tree.maxStock); // Restored lawfully after 2h clock!

    // QA-A04: Build valid shelter in unusual eligible region (Ash Caldera fringe) -> C12 optional hint recognizes receipt retroactively once!
    grantItemsToPlayerOrGround(state, 'wood_plank', 10, 't');
    grantItemsToPlayerOrGround(state, 'stone_chunk', 8, 't');
    grantItemsToPlayerOrGround(state, 'scrap_metal', 4, 't');
    // Find an actual walkable Ash Caldera fringe tile for QA-A04 unusual biome home site
    let ashTx = 54;
    let ashTy = 54;
    for (let y = 48; y <= 62; y++) {
      for (let x = 48; x <= 62; x++) {
        if (getEffectiveSurface(state, x, y) === 'ash') {
          ashTx = x;
          ashTy = y;
          break;
        }
      }
    }
    for (const s of Object.values(state.sourceStocks)) {
      if (s.tileX === ashTx + 1 && s.tileY === ashTy) s.stock = 0;
    }
    state.actors.player.x = ashTx * 16 + 8;
    state.actors.player.y = ashTy * 16 + 8;
    const weirdBuild = dispatchAction(state, {
      intentId: 'qa_a04_build',
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'claim_cabinet',
      tileX: ashTx + 1,
      tileY: ashTy,
    });
    expect(weirdBuild.ok).toBe(true);
    state = weirdBuild.state;
    expect(state.optionalHintsRecognized.hint_home_claim).toBeDefined();

    // C20 & C21: Killing 50 ordinary enemies or chopping wood yields ZERO infinite leaderboard score; score never mints cash
    const scoreAfterClaim = computeRunUnverifiedScore(state);
    expect(scoreAfterClaim).toBe(BALANCE.scoring.weights.value.first_shelter_claimed);
    expect(countPlayerItem(state, 'ragnarok_cash')).toBe(0);

    // QA-A07, A09: Quit/Abandon immediately with most J untouched -> valid Run 2 starts cleanly
    const abandon = dispatchAction(state, {
      intentId: 'qa_a09_abandon',
      kind: 'ABANDON_RUN',
    });
    expect(abandon.ok).toBe(true);
    expect(abandon.state.profile.runHistory[0].verificationStatus).not.toBe('VERIFIED_WORLDWIDE');

    const run2 = dispatchAction(abandon.state, {
      intentId: 'qa_a09_run2',
      kind: 'START_NEW_RUN',
      adventurerGender: 'male',
      spawnRegionId: 'spawn_west_cove',
      nowUtcMs: Date.now(),
    });
    expect(run2.ok).toBe(true);
    expect(run2.state.run.runNumber).toBe(2);
    expect(Object.values(run2.state.structures).some((s) => s.ownerId === 'player')).toBe(false);
  });
});
