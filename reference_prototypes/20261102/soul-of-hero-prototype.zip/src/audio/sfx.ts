import { ZZFX } from 'zzfx';

export type SfxKind =
  | 'swing'
  | 'harvest'
  | 'hit_enemy'
  | 'player_hurt'
  | 'core_cast'
  | 'build'
  | 'pickup'
  | 'door'
  | 'deposit_cash'
  | 'research_done'
  | 'ui_click'
  | 'error';

class SoundController {
  private muted = false;
  private volume = 0.35;

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(m: boolean): void {
    this.muted = m;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    return this.muted;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
  }

  public play(kind: SfxKind): void {
    if (this.muted || this.volume <= 0.01) return;
    if (typeof window === 'undefined' || typeof AudioContext === 'undefined') return;
    try {
      ZZFX.volume = this.volume;
      switch (kind) {
        case 'swing':
          ZZFX.play(0.7, 0.05, 210, 0.01, 0.04, 0.06, 4, 1.5, -18);
          break;
        case 'harvest':
          ZZFX.play(0.9, 0.08, 150, 0.01, 0.03, 0.08, 3, 1.1, -6, 0, 0, 0, 0, 0.4);
          break;
        case 'hit_enemy':
          ZZFX.play(0.9, 0.05, 115, 0.01, 0.04, 0.1, 4, 1.8, -10);
          break;
        case 'player_hurt':
          ZZFX.play(1.0, 0.05, 95, 0.01, 0.06, 0.16, 3, 2.1, -8);
          break;
        case 'core_cast':
          ZZFX.play(1.0, 0.03, 420, 0.03, 0.14, 0.22, 1, 1.4, 8, 2, 80, 0.06);
          break;
        case 'build':
          ZZFX.play(0.85, 0.04, 180, 0.01, 0.05, 0.09, 2, 1.2, 4);
          break;
        case 'pickup':
          ZZFX.play(0.75, 0.02, 520, 0.01, 0.04, 0.07, 0, 1.1, 14);
          break;
        case 'door':
          ZZFX.play(0.7, 0.04, 140, 0.01, 0.05, 0.08, 2, 1.0, 3);
          break;
        case 'deposit_cash':
          ZZFX.play(1.0, 0.01, 660, 0.02, 0.12, 0.24, 0, 1.2, 0, 0, 220, 0.08);
          break;
        case 'research_done':
          ZZFX.play(0.9, 0.02, 480, 0.02, 0.1, 0.2, 0, 1.1, 0, 0, 160, 0.07);
          break;
        case 'ui_click':
          ZZFX.play(0.45, 0.01, 620, 0.005, 0.015, 0.03, 0, 1.0);
          break;
        case 'error':
          ZZFX.play(0.65, 0.02, 130, 0.01, 0.06, 0.1, 2, 1.5, -4);
          break;
      }
    } catch {
      // Ignore WebAudio autoplay restrictions before first user gesture
    }
  }
}

export const sfx = new SoundController();
