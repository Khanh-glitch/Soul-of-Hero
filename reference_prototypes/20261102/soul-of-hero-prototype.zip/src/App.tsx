import { useCallback, useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { sfx } from './audio/sfx';
import {
  GamePanels,
  makeIntentId,
  type ActivePanelKind,
  type KeyBindings,
} from './components/GamePanels';
import { PixelIcon } from './components/PixelIcon';
import { RunFinalizedModal, TitleScreen } from './components/TitleAndEndScreens';
import { renderWorldCanvas640x360, screenToWorldCoords } from './render/canvasRenderer';
import { ensureSpriteAtlasLoaded } from './render/spriteAtlas';
import { BALANCE, ITEMS, POIS, SOURCES, STRUCTURES } from './sim/catalogs';
import {
  PLAYER_QUICKBAR_SLOTS,
  computePlayerCarriedMassKg,
  countPlayerItem,
  findItemAtLocation,
  getEquippedItem,
} from './sim/custody';
import { dispatchAction } from './sim/dispatcher';
import { loadGameStateAndCatchUp, saveGameStateAtomic } from './sim/persistence';
import { catchUpOffline, stepSimulation } from './sim/simulationTick';
import type { ActionIntent, GameState, ProfileState } from './sim/types';
import { createDefaultProfile } from './sim/worldGen';

const DEFAULT_WORLD_SEED = 20260414;

export function App() {
  const [bootLoaded, setBootLoaded] = useState(false);
  const [showTitle, setShowTitle] = useState(true);
  const [profile, setProfile] = useState<ProfileState>(() => createDefaultProfile());
  const [snapshot, setSnapshot] = useState<GameState | null>(null);
  const [activePanel, setActivePanel] = useState<ActivePanelKind>(null);
  const [selectedBuildDefId, setSelectedBuildDefId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [muted, setMuted] = useState<boolean>(false);
  const [keyBindings, setKeyBindings] = useState<KeyBindings>({
    inventory: 'i',
    craft: 'c',
    build: 'b',
    research: 'r',
    map: 'm',
    journal: 'j',
    interact: 'e',
  });

  // Authoritative simulation reference lives outside React state transitions
  const simRef = useRef<GameState | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const keysDownRef = useRef<Set<string>>(new Set());
  const hoverWorldRef = useRef<{ x: number | null; y: number | null }>({ x: null, y: null });
  const selectedBuildRef = useRef<string | null>(null);
  selectedBuildRef.current = selectedBuildDefId;

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(null), 3200);
    return () => clearTimeout(t);
  }, [toastMsg]);

  const commitSimState = useCallback((next: GameState, persistNow = false) => {
    simRef.current = next;
    setSnapshot(next);
    setProfile(next.profile);
    if (persistNow) {
      void saveGameStateAtomic(next);
    }
  }, []);

  const submitIntent = useCallback(
    (intent: ActionIntent) => {
      const cur = simRef.current;
      if (!cur) return;
      const res = dispatchAction(cur, intent, Date.now());
      if (!res.ok) {
        if (res.reason) {
          showToast(res.reason);
          sfx.play('error');
        }
        return;
      }

      // Trigger appropriate offline WebAudio SFX cue from committed action
      if (intent.kind === 'START_ACT_ON_TARGET') {
        const hand = getEquippedItem(res.state, 'hand');
        const isCore = hand && ITEMS[hand.defId]?.category === 'core';
        sfx.play(isCore ? 'core_cast' : 'swing');
      } else if (intent.kind === 'BUILD_STRUCTURE' || intent.kind === 'DEPLOY_VEHICLE') {
        sfx.play('build');
      } else if (intent.kind === 'DEPOSIT_ESCROW_CASH') {
        sfx.play('deposit_cash');
      } else if (intent.kind === 'TOGGLE_DOOR' || intent.kind === 'UNLOCK_POI_GATE') {
        sfx.play('door');
      } else if (intent.kind === 'CLAIM_JOB_OUTPUT') {
        sfx.play('research_done');
      } else if (intent.kind !== 'MOVE_INPUT') {
        sfx.play('pickup');
      }

      if (res.receipt && intent.kind !== 'MOVE_INPUT') {
        showToast(res.receipt.summary);
      }

      const shouldPersist =
        intent.kind !== 'MOVE_INPUT' && intent.kind !== 'START_ACT_ON_TARGET';
      commitSimState(res.state, shouldPersist);
    },
    [commitSimState, showToast]
  );

  // Initial load from IndexedDB + chronological offline catch-up
  useEffect(() => {
    ensureSpriteAtlasLoaded();
    let mounted = true;
    loadGameStateAndCatchUp(Date.now()).then((loaded) => {
      if (!mounted) return;
      setProfile(loaded.profile);
      if (loaded.corrupted) {
        showToast(`Recovered from corrupted save: ${loaded.corruptionReason}`);
      }
      if (loaded.found && loaded.state) {
        simRef.current = loaded.state;
        setSnapshot(loaded.state);
        if (loaded.offlineCatchupSummary.length > 0) {
          showToast(loaded.offlineCatchupSummary[0]);
        }
      }
      setBootLoaded(true);
    });
    return () => {
      mounted = false;
    };
  }, [showToast]);

  // Expose controlled test bridge using the SAME single authoritative engine
  useEffect(() => {
    (window as unknown as Record<string, unknown>).__SOUL_OF_HERO__ = {
      getSnapshot: () => simRef.current,
      dispatchIntent: (intent: ActionIntent) => submitIntent(intent),
      saveNow: async () => {
        if (simRef.current) await saveGameStateAtomic(simRef.current);
      },
    };
  }, [submitIntent]);

  // Main real-time simulation & 640x360 Canvas 2D loop
  useEffect(() => {
    if (showTitle) return;
    let rafId = 0;
    let lastFrameMs = performance.now();
    let uiSyncAccum = 0;
    let autosaveAccum = 0;

    const frame = (nowPerfMs: number) => {
      const dtSec = Math.min(0.1, Math.max(0.001, (nowPerfMs - lastFrameMs) / 1000));
      lastFrameMs = nowPerfMs;

      let cur = simRef.current;
      if (cur && cur.run.status === 'active') {
        // Movement intent from held WASD / Arrow keys
        const keys = keysDownRef.current;
        let dx = 0;
        let dy = 0;
        if (keys.has('w') || keys.has('arrowup')) dy -= 1;
        if (keys.has('s') || keys.has('arrowdown')) dy += 1;
        if (keys.has('a') || keys.has('arrowleft')) dx -= 1;
        if (keys.has('d') || keys.has('arrowright')) dx += 1;
        const sprint = keys.has('shift');

        if (dx !== 0 || dy !== 0) {
          const moveRes = dispatchAction(
            cur,
            {
              intentId: 'live_move',
              kind: 'MOVE_INPUT',
              dx,
              dy,
              sprint,
              dtSec,
            },
            Date.now()
          );
          cur = moveRes.state;
        }

        const prevHp = cur.actors.player.hp;
        cur = stepSimulation(cur, dtSec, Date.now(), false);
        if (cur.actors.player.hp < prevHp - 0.5) {
          sfx.play('player_hurt');
        }
        simRef.current = cur;

        uiSyncAccum += dtSec;
        autosaveAccum += dtSec;
        if (uiSyncAccum >= 0.1 || cur.run.status !== 'active') {
          uiSyncAccum = 0;
          setSnapshot(cur);
          setProfile(cur.profile);
        }
        if (autosaveAccum >= 6.0 || cur.run.status !== 'active') {
          autosaveAccum = 0;
          void saveGameStateAtomic(cur);
        }
      }

      if (cur && canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          renderWorldCanvas640x360(ctx, cur, {
            selectedBuildDefId: selectedBuildRef.current,
            hoverWorldX: hoverWorldRef.current.x,
            hoverWorldY: hoverWorldRef.current.y,
            animTimeMs: nowPerfMs,
          });
        }
      }

      rafId = requestAnimationFrame(frame);
    };

    rafId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafId);
  }, [showTitle]);

  // Keyboard shortcuts & Quickbar 1-8
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (showTitle) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;

      const k = e.key.toLowerCase();
      keysDownRef.current.add(k);

      const togglePanel = (p: ActivePanelKind) => {
        sfx.play('ui_click');
        setActivePanel((prev) => (prev === p ? null : p));
      };

      if (k === 'escape') {
        if (selectedBuildRef.current) {
          setSelectedBuildDefId(null);
        } else if (activePanel && activePanel !== 'menu') {
          setActivePanel(null);
        } else {
          togglePanel('menu');
        }
        return;
      }

      if (k === 'tab') {
        e.preventDefault();
        togglePanel('skills');
        return;
      }

      if (k === keyBindings.inventory) {
        togglePanel('inventory');
        return;
      }
      if (k === keyBindings.craft) {
        togglePanel('craft');
        return;
      }
      if (k === keyBindings.build) {
        togglePanel('build');
        return;
      }
      if (k === keyBindings.research) {
        togglePanel('research');
        return;
      }
      if (k === keyBindings.map) {
        togglePanel('map');
        return;
      }
      if (k === keyBindings.journal) {
        togglePanel('journal');
        return;
      }
      if (k === keyBindings.interact) {
        const cur = simRef.current;
        if (!cur) return;
        // If standing adjacent to Vendor, Escrow Chest, Storage Chest, or Evac Dock, also open Inventory drawer if no direct ground/crate loot
        const res = dispatchAction(
          cur,
          { intentId: makeIntentId('interact_key'), kind: 'INTERACT_NEARBY' },
          Date.now()
        );
        if (res.ok) {
          sfx.play('pickup');
          if (res.receipt) showToast(res.receipt.summary);
          commitSimState(res.state, true);
        } else {
          // Open contextual station/container panel if adjacent to chest/vendor/station
          const p = cur.actors.player;
          const nearStation = Object.values(cur.structures).find(
            (s) =>
              s.hp > 0 &&
              Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 56
          );
          const nearPoi = cur.world.pois.find(
            (poi) => Math.hypot(poi.centerX * 16 + 8 - p.x, poi.centerY * 16 + 8 - p.y) <= 88
          );
          if (nearStation && STRUCTURES[nearStation.defId]?.stationType === 'research_bench') {
            setActivePanel('research');
          } else if (nearStation && STRUCTURES[nearStation.defId]?.stationType) {
            setActivePanel('craft');
          } else if (nearStation || (nearPoi && (POIS[nearPoi.defId]?.isVendor || POIS[nearPoi.defId]?.isEvacuationSite))) {
            setActivePanel('inventory');
          } else if (res.reason) {
            showToast(res.reason);
          }
        }
        return;
      }

      // Quickbar 1-8
      if (k >= '1' && k <= '8') {
        const slotIdx = Number(k) - 1;
        const cur = simRef.current;
        if (!cur) return;
        const qbItem = findItemAtLocation(cur, { kind: 'player_quickbar', slotIndex: slotIdx });
        if (!qbItem) return;
        const def = ITEMS[qbItem.defId];
        if (def?.equipSlot) {
          submitIntent({
            intentId: makeIntentId('qb_eq'),
            kind: 'EQUIP_ITEM',
            itemInstanceId: qbItem.instanceId,
          });
        } else if (def?.consumeEffects || def?.blueprintRecipeId) {
          submitIntent({
            intentId: makeIntentId('qb_use'),
            kind: 'USE_ITEM',
            itemInstanceId: qbItem.instanceId,
          });
        } else if (def?.deployStructureId) {
          setSelectedBuildDefId(def.deployStructureId);
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysDownRef.current.delete(e.key.toLowerCase());
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [activePanel, commitSimState, keyBindings, showTitle, showToast, submitIntent]);

  // Save on tab hide/close
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === 'hidden' && simRef.current) {
        void saveGameStateAtomic(simRef.current);
      }
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  const handleStartNewRun = (gender: 'male' | 'female', spawnRegionId: string) => {
    const baseState =
      simRef.current ??
      ({
        profile,
        world: { seed: DEFAULT_WORLD_SEED },
        processedIntentIds: [],
        run: { status: 'abandoned' },
      } as unknown as GameState);

    const res = dispatchAction(
      baseState,
      {
        intentId: makeIntentId('new_run'),
        kind: 'START_NEW_RUN',
        adventurerGender: gender,
        spawnRegionId,
        nowUtcMs: Date.now(),
      },
      Date.now()
    );
    if (res.ok) {
      commitSimState(res.state, true);
      setActivePanel(null);
      setSelectedBuildDefId(null);
      setShowTitle(false);
    }
  };

  if (!bootLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-950 text-amber-300 text-xs">
        Loading Persistent Island & IndexedDB Ledger...
      </div>
    );
  }

  const p = snapshot?.actors.player;
  const remainingHours = snapshot
    ? Math.max(
        0,
        (BALANCE.clock.maxRunRealSeconds.value - snapshot.clock.elapsedRealSeconds) / 3600
      )
    : 336;
  const handEquipped = snapshot ? getEquippedItem(snapshot, 'hand') : null;
  const handDef = handEquipped ? ITEMS[handEquipped.defId] : null;

  // Detect nearby contextual [E] prompt
  let nearbyPrompt: string | null = null;
  if (snapshot && p) {
    const nearBag = Object.values(snapshot.deathBags).find(
      (b) => Math.hypot(b.x - p.x, b.y - p.y) <= 46
    );
    const nearSrc = Object.values(snapshot.sourceStocks).find(
      (s) =>
        s.stock > 0 &&
        SOURCES[s.defId]?.interactLoot &&
        Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 46
    );
    const nearPoi = snapshot.world.pois.find(
      (poi) => Math.hypot(poi.centerX * 16 + 8 - p.x, poi.centerY * 16 + 8 - p.y) <= 84
    );
    if (nearBag) nearbyPrompt = `[${keyBindings.interact.toUpperCase()}] Recover Death Bag`;
    else if (nearSrc) nearbyPrompt = `[${keyBindings.interact.toUpperCase()}] Loot ${SOURCES[nearSrc.defId]?.name}`;
    else if (nearPoi && POIS[nearPoi.defId]?.isVendor)
      nearbyPrompt = `[${keyBindings.interact.toUpperCase()}] Trade Quartermaster`;
    else if (nearPoi && POIS[nearPoi.defId]?.isEvacuationSite)
      nearbyPrompt = `[${keyBindings.interact.toUpperCase()}] Evacuation Beacon`;
  }

  return (
    <div className="w-full h-full flex items-center justify-center bg-slate-950 overflow-hidden">
      {/* Crisp 16:9 Stage Container fitting 640x360 native up to 100vw/100vh without HUD clipping */}
      <div
        data-testid="game-stage"
        className="relative w-full h-full max-w-[177.78vh] max-h-[56.25vw] bg-slate-950 overflow-hidden shadow-2xl border border-slate-800/80"
      >
        {/* Logical 640x360 HTML5 Canvas 2D World */}
        <canvas
          ref={canvasRef}
          data-testid="world-canvas"
          width={640}
          height={360}
          onContextMenu={(e) => {
            e.preventDefault();
            if (selectedBuildDefId) {
              setSelectedBuildDefId(null);
            } else if (simRef.current?.actors.player.activeCast) {
              submitIntent({
                intentId: makeIntentId('rc_cancel'),
                kind: 'CANCEL_ACTIVE_CAST',
              });
            }
          }}
          onMouseMove={(e) => {
            if (!canvasRef.current || !simRef.current) return;
            const coords = screenToWorldCoords(
              canvasRef.current,
              e.clientX,
              e.clientY,
              simRef.current
            );
            hoverWorldRef.current = { x: coords.worldX, y: coords.worldY };
          }}
          onMouseDown={(e) => {
            if (e.button !== 0 || showTitle || !canvasRef.current || !simRef.current) return;
            const coords = screenToWorldCoords(
              canvasRef.current,
              e.clientX,
              e.clientY,
              simRef.current
            );
            if (selectedBuildDefId) {
              submitIntent({
                intentId: makeIntentId('place_str'),
                kind: 'BUILD_STRUCTURE',
                structureDefId: selectedBuildDefId,
                tileX: Math.floor(coords.worldX / 16),
                tileY: Math.floor(coords.worldY / 16),
              });
            } else {
              submitIntent({
                intentId: makeIntentId('act_target'),
                kind: 'START_ACT_ON_TARGET',
                targetWorldX: coords.worldX,
                targetWorldY: coords.worldY,
              });
            }
          }}
          className="w-full h-full block cursor-crosshair"
        />

        {/* Title / New Run Screen */}
        {showTitle && (
          <TitleScreen
            profile={profile}
            savedRun={snapshot}
            worldSeed={DEFAULT_WORLD_SEED}
            onStartNewRun={handleStartNewRun}
            onResumeRun={() => setShowTitle(false)}
          />
        )}

        {/* Active Gameplay Compact HUD (Strictly non-clipping at 640x360 & 1280x720) */}
        {!showTitle && snapshot && p && (
          <>
            {/* Top Status Bar */}
            <header
              data-testid="hud-top"
              className="absolute top-0 left-0 right-0 h-6 px-1.5 bg-slate-950/88 border-b border-slate-800/90 flex items-center justify-between text-[10px] z-10 pointer-events-auto"
            >
              {/* Vitals */}
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="px-1.5 py-0.2 rounded bg-rose-950/90 border border-rose-600/60 text-rose-200 font-bold">
                  HP {Math.ceil(p.hp)}/{p.maxHp}
                </span>
                <span className="px-1 py-0.2 rounded bg-amber-950/80 border border-amber-700/50 text-amber-200">
                  Food {Math.round(p.hunger)}
                </span>
                <span className="px-1 py-0.2 rounded bg-sky-950/80 border border-sky-700/50 text-sky-200">
                  H2O {Math.round(p.thirst)}
                </span>
                {p.radDose >= 3 && (
                  <span className="px-1 rounded bg-lime-900 text-lime-200 font-bold">
                    RAD {Math.round(p.radDose)}
                  </span>
                )}
                {p.tempStress <= -15 && (
                  <span className="px-1 rounded bg-cyan-900 text-cyan-200 font-bold">COLD</span>
                )}
                <span className="text-slate-300 hidden sm:inline">
                  {computePlayerCarriedMassKg(snapshot)}kg
                  {p.tetheredVehicleId ? ' [CART]' : ''}
                </span>
              </div>

              {/* Run Clock, Ragnarok Phase & Secured Cash */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span
                  className={`px-1.5 rounded font-bold ${
                    snapshot.clock.phase !== 'normal'
                      ? 'bg-rose-700 text-amber-200 animate-pulse'
                      : 'bg-slate-800 text-amber-300'
                  }`}
                >
                  {snapshot.clock.phase === 'normal'
                    ? `Day ${snapshot.clock.fictionalDay} • ${remainingHours.toFixed(1)}h`
                    : snapshot.clock.phase === 'ragnarok_day14_awakened'
                      ? `DAY 14 ELDERS • ${remainingHours.toFixed(1)}h`
                      : `FINAL 72H • ${remainingHours.toFixed(1)}h`}
                </span>
                <span className="text-slate-300 capitalize">
                  {snapshot.clock.weather.replace('_', ' ')}
                </span>
                <span
                  title="Held Physical Ragnarok Cash / Secured Profile Cash"
                  className="px-1 rounded bg-amber-950/80 border border-amber-600/50 text-amber-300 font-mono"
                >
                  ₵{countPlayerItem(snapshot, 'ragnarok_cash')}/🔒{profile.securedRagnarokCash}
                </span>
                <button
                  onClick={() => setMuted(sfx.toggleMute())}
                  title={muted ? 'Unmute Audio' : 'Mute Audio'}
                  className="p-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                >
                  {muted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                </button>
              </div>
            </header>

            {/* Toast / Action Receipt Notification */}
            {toastMsg && (
              <div className="absolute top-7 left-2 max-w-[330px] bg-slate-950/90 border border-amber-500/60 text-amber-100 px-2 py-0.5 rounded text-[10px] shadow z-20 pointer-events-none truncate">
                {toastMsg}
              </div>
            )}

            {/* Nearby Interaction Pill */}
            {nearbyPrompt && (
              <button
                onClick={() =>
                  submitIntent({
                    intentId: makeIntentId('prompt_e'),
                    kind: 'INTERACT_NEARBY',
                  })
                }
                className="absolute bottom-10 left-1/2 -translate-x-1/2 bg-amber-500/95 hover:bg-amber-400 text-slate-950 font-extrabold px-2.5 py-0.5 rounded-full text-[10px] shadow-lg z-10"
              >
                {nearbyPrompt}
              </button>
            )}

            {/* Right-Side Scrollable Drawer Panels */}
            <GamePanels
              state={snapshot}
              activePanel={activePanel}
              onClose={() => setActivePanel(null)}
              onDispatch={submitIntent}
              selectedBuildDefId={selectedBuildDefId}
              onSelectBuildDefId={setSelectedBuildDefId}
              onManualSave={() => {
                if (simRef.current) {
                  void saveGameStateAtomic(simRef.current);
                  showToast('Saved atomic snapshot & receipts to IndexedDB.');
                }
              }}
              onReturnToTitle={() => {
                if (simRef.current) void saveGameStateAtomic(simRef.current);
                setShowTitle(true);
              }}
              onSimulateOfflineHours={(hrs) => {
                if (!simRef.current) return;
                const res = catchUpOffline(simRef.current, Date.now(), hrs * 3600);
                res.state.run.qaClockUsed = true;
                commitSimState(res.state, true);
                showToast(res.summaryLog[0] ?? `Replayed ${hrs}h offline.`);
              }}
              keyBindings={keyBindings}
              onUpdateKeyBinding={(act, key) =>
                setKeyBindings((prev) => ({ ...prev, [act]: key }))
              }
            />

            {/* Bottom Quickbar (1-8) + Panel Shortcut Buttons */}
            <footer
              data-testid="hud-bottom"
              className="absolute bottom-0 left-0 right-0 h-9 px-1.5 bg-slate-950/90 border-t border-slate-800/90 flex items-center justify-between gap-1 text-[10px] z-10"
            >
              {/* Equipped Hand Badge */}
              <div className="flex items-center gap-1 bg-slate-900 border border-amber-700/50 rounded px-1.5 py-0.5 min-w-0 max-w-[135px]">
                {handDef ? (
                  <>
                    <PixelIcon sprite={handDef.sprite} size={16} />
                    <div className="truncate leading-none">
                      <div className="truncate font-semibold text-amber-200 text-[9px]">
                        {handDef.name}
                      </div>
                      <div className="text-[8px] text-slate-400">
                        {handEquipped?.charges !== undefined
                          ? `${handEquipped.charges} chg`
                          : handEquipped?.durability !== undefined
                            ? `${Math.round(handEquipped.durability)} dur`
                            : 'Ready'}
                      </div>
                    </div>
                  </>
                ) : (
                  <span className="text-[9px] text-slate-400">Unarmed</span>
                )}
              </div>

              {/* 1-8 Quickbar */}
              <div className="flex items-center gap-0.5">
                {Array.from({ length: PLAYER_QUICKBAR_SLOTS }).map((_, idx) => {
                  const qbItem = findItemAtLocation(snapshot, {
                    kind: 'player_quickbar',
                    slotIndex: idx,
                  });
                  const qDef = qbItem ? ITEMS[qbItem.defId] : null;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        if (!qbItem || !qDef) return;
                        if (qDef.equipSlot) {
                          submitIntent({
                            intentId: makeIntentId('click_qb_eq'),
                            kind: 'EQUIP_ITEM',
                            itemInstanceId: qbItem.instanceId,
                          });
                        } else if (qDef.consumeEffects || qDef.blueprintRecipeId) {
                          submitIntent({
                            intentId: makeIntentId('click_qb_use'),
                            kind: 'USE_ITEM',
                            itemInstanceId: qbItem.instanceId,
                          });
                        }
                      }}
                      title={qDef ? `[${idx + 1}] ${qDef.name}` : `Quickbar ${idx + 1}`}
                      className="w-7 h-7 rounded border border-slate-700 bg-slate-900/90 hover:border-amber-500 flex items-center justify-center relative"
                    >
                      <span className="absolute top-0 left-0.5 text-[7px] text-slate-500 leading-none">
                        {idx + 1}
                      </span>
                      {qbItem && qDef && (
                        <>
                          <PixelIcon sprite={qDef.sprite} size={16} />
                          {qbItem.count > 1 && (
                            <span className="absolute bottom-0 right-0.5 text-[8px] font-mono text-amber-200 leading-none">
                              {qbItem.count}
                            </span>
                          )}
                        </>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Panel Toggle Buttons with Key Hints */}
              <div className="flex items-center gap-0.5 shrink-0">
                {(
                  [
                    ['inventory', 'Bag', keyBindings.inventory],
                    ['craft', 'Craft', keyBindings.craft],
                    ['build', 'Build', keyBindings.build],
                    ['research', 'Study', keyBindings.research],
                    ['map', 'Map', keyBindings.map],
                    ['journal', 'Log', keyBindings.journal],
                    ['skills', 'Skill', 'Tab'],
                    ['menu', 'Menu', 'Esc'],
                  ] as [ActivePanelKind, string, string][]
                ).map(([panelId, label, keyHint]) => (
                  <button
                    key={panelId}
                    data-testid={`btn-panel-${panelId}`}
                    onClick={() =>
                      setActivePanel((curP) => (curP === panelId ? null : panelId))
                    }
                    className={`px-1.5 py-1 rounded border text-[9px] font-semibold leading-none ${
                      activePanel === panelId
                        ? 'bg-amber-500 border-amber-300 text-slate-950'
                        : 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    {label}
                    <span className="opacity-70 ml-0.5 uppercase hidden md:inline">
                      [{keyHint}]
                    </span>
                  </button>
                ))}
              </div>
            </footer>

            {/* Run Finalized Overlay */}
            {snapshot.run.status !== 'active' && (
              <RunFinalizedModal
                state={snapshot}
                onStartNextRunSetup={() => setShowTitle(true)}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;
