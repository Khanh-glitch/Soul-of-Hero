import {
  BALANCE,
  BOSSES,
  ENEMIES,
  ITEMS,
  POIS,
  SOURCES,
  STRUCTURES,
} from '../sim/catalogs';
import { getEquippedItem } from '../sim/custody';
import { checkBuildPlacementValidity } from '../sim/dispatcher';
import {
  computeVisibleTileSet,
  getEffectiveSurface,
  isTileInPlayerOwnedTerritory,
} from '../sim/navigation';
import type { GameState, SurfaceType } from '../sim/types';
import { drawSpriteByKey, ensureSpriteAtlasLoaded } from './spriteAtlas';

export interface RenderUIContext {
  selectedBuildDefId: string | null;
  hoverWorldX: number | null;
  hoverWorldY: number | null;
  animTimeMs: number;
}

const SURFACE_COLORS: Record<SurfaceType, [string, string]> = {
  deep_water: ['#1d3557', '#24426b'],
  shallow_water: ['#3a7ca5', '#4f8fba'],
  sand: ['#d9b878', '#e6c98e'],
  grass: ['#5b8c5a', '#659b64'],
  forest: ['#3c6e47', '#467d52'],
  road: ['#9c7a54', '#ab875f'],
  hills: ['#6c6f64', '#7a7e71'],
  mountain_rock: ['#44424c', '#52505c'],
  stone: ['#7c8089', '#8a8e98'],
  marsh: ['#415d43', '#354f3c'],
  ash: ['#4a3f41', '#5e4c4a'],
  snow: ['#d8e2ec', '#eaf1f7'],
  toxic: ['#4b5835', '#61733b'],
  ice: ['#90e0ef', '#caf0f8'],
};

export function renderWorldCanvas640x360(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  uiCtx: RenderUIContext
): void {
  const W = 640;
  const H = 360;
  ctx.imageSmoothingEnabled = false;

  const atlas = ensureSpriteAtlasLoaded();
  const p = state.actors.player;
  const camX = Math.round(Math.max(0, Math.min(state.world.width * 16 - W, p.x - W / 2)));
  const camY = Math.round(Math.max(0, Math.min(state.world.height * 16 - H, p.y - H / 2)));

  ctx.fillStyle = '#141b29';
  ctx.fillRect(0, 0, W, H);

  const minTx = Math.max(0, Math.floor(camX / 16) - 1);
  const maxTx = Math.min(state.world.width - 1, Math.ceil((camX + W) / 16) + 1);
  const minTy = Math.max(0, Math.floor(camY / 16) - 1);
  const maxTy = Math.min(state.world.height - 1, Math.ceil((camY + H) / 16) + 1);

  // Compute lawful player FOV (C08/K2: never reveal hidden monsters behind walls!)
  const isNight = state.clock.timeOfDay01 < 0.22 || state.clock.timeOfDay01 > 0.8;
  const utilEq = getEquippedItem(state, 'utility');
  const lanternBonus = utilEq ? ITEMS[utilEq.defId]?.visionBonusTiles ?? 0 : 0;
  const fovRadius =
    (isNight ? BALANCE.player.nightVisionTiles.value : BALANCE.player.dayVisionTiles.value) +
    lanternBonus;
  const ptx = Math.floor(p.x / 16);
  const pty = Math.floor(p.y / 16);
  const visibleSet = computeVisibleTileSet(state, ptx, pty, fovRadius);

  const animTick = Math.floor(uiCtx.animTimeMs / 350);

  // 1. Base Terrain Tiles + Shoreline Foam + Biome Detail
  for (let ty = minTy; ty <= maxTy; ty++) {
    for (let tx = minTx; tx <= maxTx; tx++) {
      const sx = tx * 16 - camX;
      const sy = ty * 16 - camY;
      const surf = getEffectiveSurface(state, tx, ty);
      const hash = ((tx * 73856093) ^ (ty * 19349663)) >>> 0;
      const [c0, c1] = SURFACE_COLORS[surf] ?? ['#5b8c5a', '#659b64'];

      ctx.fillStyle = (hash & 3) === 0 ? c1 : c0;
      ctx.fillRect(sx, sy, 16, 16);

      // Crisp Kenney grass/road/stone accents
      if (surf === 'grass' && (hash % 7 === 0)) {
        drawSpriteByKey(ctx, atlas, hash % 14 === 0 ? 'grass_flower' : 'grass_blades', sx, sy, 16);
      } else if (surf === 'road') {
        drawSpriteByKey(ctx, atlas, 'road_dirt', sx, sy, 16);
      } else if (surf === 'stone') {
        drawSpriteByKey(ctx, atlas, 'stone_plaza', sx, sy, 16);
      } else if (surf === 'deep_water' || surf === 'shallow_water') {
        // Animated water ripple pixel
        if (((hash + animTick) & 7) === 0) {
          ctx.fillStyle = surf === 'deep_water' ? '#3a6ea5' : '#90e0ef';
          ctx.fillRect(sx + (hash % 10) + 2, sy + ((hash >> 3) % 10) + 3, 4, 1);
        }
        // Shoreline foam where water borders land
        const upSurf = getEffectiveSurface(state, tx, ty - 1);
        if (upSurf !== 'deep_water' && upSurf !== 'shallow_water' && upSurf !== 'ice') {
          ctx.fillStyle = '#e0fbfc';
          ctx.fillRect(sx, sy, 16, (animTick + tx) % 2 === 0 ? 2 : 1);
        }
      } else if (surf === 'mountain_rock' || surf === 'hills') {
        // Cliff highlight & shadow
        ctx.fillStyle = surf === 'mountain_rock' ? '#2e222f' : '#4a4e48';
        ctx.fillRect(sx, sy + 13, 16, 3);
        ctx.fillStyle = '#9aa0a8';
        ctx.fillRect(sx + 2, sy + 2, 5, 2);
      } else if (surf === 'marsh') {
        ctx.fillStyle = '#2d4739';
        ctx.fillRect(sx + (hash % 9) + 2, sy + 5, 5, 3);
      } else if (surf === 'toxic') {
        if (((hash + animTick) & 5) === 0) {
          ctx.fillStyle = '#9ef01a';
          ctx.fillRect(sx + (hash % 11) + 2, sy + ((hash >> 2) % 11) + 2, 2, 2);
        }
      } else if (surf === 'ash') {
        if (((hash + animTick) & 7) === 0) {
          ctx.fillStyle = '#ff6b35';
          ctx.fillRect(sx + (hash % 12) + 2, sy + ((hash >> 2) % 12) + 2, 2, 1);
        }
      }

      // Active Terrain Effects (Fire, Ice, Scorch)
      const te = state.terrainEffects[`${tx},${ty}`];
      if (te) {
        if (te.type === 'fire') {
          ctx.fillStyle = animTick % 2 === 0 ? '#ff6b35' : '#ffba08';
          ctx.fillRect(sx + 3, sy + 3, 10, 10);
          ctx.fillStyle = '#fff3b0';
          ctx.fillRect(sx + 6, sy + 5, 4, 6);
        } else if (te.type === 'ice') {
          ctx.strokeStyle = '#ffffff';
          ctx.strokeRect(sx + 1.5, sy + 1.5, 13, 13);
        }
      }
    }
  }

  // 2. Player Footprint Trails (C08: visible surface-dependent decaying traces)
  for (const fp of state.footprints) {
    if (fp.tileX < minTx || fp.tileX > maxTx || fp.tileY < minTy || fp.tileY > maxTy) continue;
    const sx = fp.tileX * 16 - camX;
    const sy = fp.tileY * 16 - camY;
    const alpha = Math.max(0.15, (1 - fp.ageProgress01) * 0.65);
    ctx.fillStyle = `rgba(38, 28, 36, ${alpha.toFixed(2)})`;
    ctx.fillRect(sx + 5, sy + 5, 2, 3);
    ctx.fillRect(sx + 9, sy + 8, 2, 3);
  }

  // 3. Placed Floors / Foundations & Territory Boundary Preview
  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0 || st.tileX < minTx || st.tileX > maxTx || st.tileY < minTy || st.tileY > maxTy)
      continue;
    const sDef = STRUCTURES[st.defId];
    if (!sDef?.isFloor) continue;
    const sx = st.tileX * 16 - camX;
    const sy = st.tileY * 16 - camY;
    drawSpriteByKey(ctx, atlas, sDef.sprite, sx, sy, 16);
    ctx.strokeStyle = 'rgba(46,34,47,0.35)';
    ctx.strokeRect(sx + 0.5, sy + 0.5, 15, 15);
  }

  if (uiCtx.selectedBuildDefId) {
    // Highlight owned territory tiles subtly during Build Mode
    for (let ty = minTy; ty <= maxTy; ty++) {
      for (let tx = minTx; tx <= maxTx; tx++) {
        if (isTileInPlayerOwnedTerritory(state, tx, ty)) {
          ctx.fillStyle = 'rgba(82, 183, 136, 0.11)';
          ctx.fillRect(tx * 16 - camX, ty * 16 - camY, 16, 16);
        }
      }
    }
  }

  // 4. Sources (Trees, Rocks, Veins, Barrels, Final-72 Vaults)
  for (const src of Object.values(state.sourceStocks)) {
    if (
      src.stock <= 0 ||
      src.tileX < minTx - 1 ||
      src.tileX > maxTx + 1 ||
      src.tileY < minTy - 1 ||
      src.tileY > maxTy + 1
    ) {
      continue;
    }
    const sx = src.tileX * 16 - camX;
    const sy = src.tileY * 16 - camY;
    const sDef = SOURCES[src.defId];
    if (!sDef) continue;

    // Ground drop shadow
    ctx.fillStyle = 'rgba(20, 18, 28, 0.32)';
    ctx.fillRect(sx + 2, sy + 13, 12, 3);

    if (src.defId === 'pine_tree') {
      drawSpriteByKey(ctx, atlas, 'pine_tree_bot', sx, sy, 16);
      drawSpriteByKey(ctx, atlas, 'pine_tree_top', sx, sy - 12, 16);
    } else if (src.defId === 'oak_tree') {
      drawSpriteByKey(ctx, atlas, 'oak_tree_bot', sx, sy, 16);
      drawSpriteByKey(ctx, atlas, 'oak_tree_top', sx, sy - 12, 16);
    } else {
      drawSpriteByKey(ctx, atlas, sDef.sprite, sx, sy, 16);
    }

    // Pulse beacon on Final-72 Ragnarok Vault when unlocked
    if (sDef.onlyFinal72) {
      const unlocked = state.clock.phase !== 'normal';
      ctx.strokeStyle = unlocked ? '#ffd166' : '#8d99ae';
      ctx.strokeRect(sx - 0.5, sy - 0.5, 17, 17);
    }

    if (src.hitsRemaining < src.maxHits) {
      ctx.fillStyle = '#2e222f';
      ctx.fillRect(sx + 2, sy - 3, 12, 3);
      ctx.fillStyle = '#52b788';
      ctx.fillRect(sx + 3, sy - 2, Math.round(10 * (src.hitsRemaining / src.maxHits)), 1);
    }
  }

  // 5. Non-Floor, Non-Roof Structures & Stations + POI Relays
  for (const poi of state.world.pois) {
    const rx = poi.relayTileX * 16 - camX;
    const ry = poi.relayTileY * 16 - camY;
    if (rx >= -16 && rx <= W + 16 && ry >= -16 && ry <= H + 16) {
      const pDef = POIS[poi.defId];
      if (pDef.isVendor) {
        drawSpriteByKey(ctx, atlas, 'vendor_quartermaster', poi.centerX * 16 - camX, poi.centerY * 16 - camY, 16);
      } else if (pDef.isEvacuationSite) {
        // Evacuation Harbor Beacon Signal Pillar
        const bx = poi.centerX * 16 - camX;
        const by = poi.centerY * 16 - camY;
        ctx.fillStyle = '#2e222f';
        ctx.fillRect(bx + 3, by - 4, 10, 20);
        ctx.fillStyle = animTick % 2 === 0 ? '#00f5d4' : '#4cc9f0';
        ctx.fillRect(bx + 5, by - 2, 6, 6);
      } else if (pDef.gateType === 'power' || pDef.gateType === 'keycard_and_power') {
        drawSpriteByKey(ctx, atlas, 'fuel_generator', rx, ry, 16);
      }
    }
  }

  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0 || st.tileX < minTx || st.tileX > maxTx || st.tileY < minTy || st.tileY > maxTy)
      continue;
    const sDef = STRUCTURES[st.defId];
    if (!sDef || sDef.isFloor || sDef.isRoof) continue;
    const sx = st.tileX * 16 - camX;
    const sy = st.tileY * 16 - camY;

    if (sDef.isDoor && st.isOpen) {
      drawSpriteByKey(ctx, atlas, 'wood_door_open', sx, sy, 16);
    } else {
      drawSpriteByKey(ctx, atlas, sDef.sprite, sx, sy, 16);
    }

    // Active furnace/generator flame indicator
    if (sDef.usesFuel && st.fuelRemainingSec > 0) {
      ctx.fillStyle = animTick % 2 === 0 ? '#ff9f1c' : '#ffbf69';
      ctx.fillRect(sx + 6, sy + 6, 4, 4);
    }

    // Completed unclaimed job indicator badge
    if (st.activeJobId && state.jobs[st.activeJobId]?.status === 'completed_unclaimed') {
      ctx.fillStyle = '#2e222f';
      ctx.fillRect(sx + 5, sy - 7, 6, 6);
      ctx.fillStyle = '#52b788';
      ctx.fillRect(sx + 6, sy - 6, 4, 4);
    }

    // Damaged structure health bar
    if (st.hp < st.maxHp) {
      ctx.fillStyle = '#2e222f';
      ctx.fillRect(sx + 1, sy - 4, 14, 3);
      ctx.fillStyle = '#e63946';
      ctx.fillRect(sx + 2, sy - 3, Math.round(12 * (st.hp / st.maxHp)), 1);
    }
  }

  // 6. Ground Drops, Death Bags & Vehicles (Freight Hand-Cart)
  for (const item of Object.values(state.items)) {
    if (item.location.kind !== 'ground_drop') continue;
    const sx = item.location.x - camX - 6;
    const sy = item.location.y - camY - 6;
    if (sx < -16 || sx > W + 16 || sy < -16 || sy > H + 16) continue;
    drawSpriteByKey(ctx, atlas, ITEMS[item.defId]?.sprite ?? 'salvage_crate', sx, sy, 12);
  }

  for (const bag of Object.values(state.deathBags)) {
    const sx = bag.x - camX - 8;
    const sy = bag.y - camY - 8;
    if (sx < -20 || sx > W + 20 || sy < -20 || sy > H + 20) continue;
    drawSpriteByKey(ctx, atlas, 'death_bag', sx, sy, 16);
    ctx.strokeStyle = '#ffd166';
    ctx.strokeRect(sx - 1.5, sy - 1.5, 19, 19);
  }

  for (const vh of Object.values(state.vehicles)) {
    const sx = Math.round(vh.x - camX - 8);
    const sy = Math.round(vh.y - camY - 8);
    if (sx < -20 || sx > W + 20 || sy < -20 || sy > H + 20) continue;
    ctx.fillStyle = 'rgba(20,18,28,0.35)';
    ctx.fillRect(sx + 1, sy + 13, 14, 3);
    drawSpriteByKey(ctx, atlas, 'hand_cart_kit', sx, sy, 16);
  }

  // 7. Monsters & Six Elders (ONLY rendered when inside lawful player FOV!)
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive) continue;
    const etx = Math.floor(enemy.x / 16);
    const ety = Math.floor(enemy.y / 16);
    if (!visibleSet.has(`${etx},${ety}`)) continue;

    const sx = Math.round(enemy.x - camX - 8);
    const sy = Math.round(enemy.y - camY - 8);
    if (sx < -24 || sx > W + 24 || sy < -24 || sy > H + 24) continue;

    const eDef = ENEMIES[enemy.defId];
    if (enemy.aiState === 'attack_windup') {
      // Crisp attack telegraph ring
      ctx.strokeStyle = '#ff4d6d';
      ctx.strokeRect(sx - 3.5, sy - 3.5, 23, 23);
    }

    ctx.fillStyle = 'rgba(20,18,28,0.35)';
    ctx.fillRect(sx + 2, sy + 13, 12, 3);
    drawSpriteByKey(ctx, atlas, eDef?.sprite ?? 'bog_slime', sx, sy, 16);

    // State indicator pixel icon (! for direct sight pursuit, ? for footprint tracking)
    if (enemy.aiState === 'pursue_player' || enemy.aiState === 'attack_windup') {
      ctx.fillStyle = '#ff4d6d';
      ctx.fillRect(sx + 7, sy - 6, 2, 4);
    } else if (enemy.aiState === 'follow_trail') {
      ctx.fillStyle = '#ffd166';
      ctx.fillRect(sx + 6, sy - 6, 4, 2);
    }

    if (enemy.hp < enemy.maxHp) {
      ctx.fillStyle = '#2e222f';
      ctx.fillRect(sx + 1, sy - 3, 14, 3);
      ctx.fillStyle = '#e63946';
      ctx.fillRect(sx + 2, sy - 2, Math.round(12 * (enemy.hp / enemy.maxHp)), 1);
    }
  }

  for (const elder of state.actors.elders) {
    if (!elder.alive) continue;
    const etx = Math.floor(elder.x / 16);
    const ety = Math.floor(elder.y / 16);
    if (!visibleSet.has(`${etx},${ety}`)) continue;

    const sx = Math.round(elder.x - camX - 12);
    const sy = Math.round(elder.y - camY - 12);
    if (sx < -36 || sx > W + 36 || sy < -36 || sy > H + 36) continue;

    if (elder.telegraphPos) {
      // Readable Boss Slam Telegraph Zone!
      const gx = Math.round(elder.telegraphPos.x - camX);
      const gy = Math.round(elder.telegraphPos.y - camY);
      ctx.save();
      ctx.beginPath();
      ctx.arc(gx, gy, elder.telegraphPos.radiusPx, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(230, 57, 70, 0.24)';
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#ff4d6d';
      ctx.stroke();
      ctx.restore();
    }

    ctx.fillStyle = 'rgba(20,18,28,0.45)';
    ctx.fillRect(sx + 3, sy + 21, 18, 4);
    drawSpriteByKey(ctx, atlas, `${elder.defId}_${elder.form}`, sx, sy, 24);

    // Elder nameplate & HP bar
    const bDef = BOSSES[elder.defId];
    if (bDef) {
      ctx.font = 'bold 8px monospace';
      ctx.fillStyle = elder.form === 'awakened' ? '#ffd166' : '#f8edeb';
      ctx.fillText(
        `${bDef.name} [${elder.form === 'awakened' ? 'AWAKENED' : 'LATENT'}]`,
        sx - 14,
        sy - 9
      );
    }
    ctx.fillStyle = '#2e222f';
    ctx.fillRect(sx - 2, sy - 6, 28, 4);
    ctx.fillStyle = elder.form === 'awakened' ? '#ff9f1c' : '#e63946';
    ctx.fillRect(sx - 1, sy - 5, Math.round(26 * (elder.hp / elder.maxHp)), 2);
  }

  // 8. Playable Adventurer (Male / Female) + Equipped Hand Tool/Core + Windup Bar
  {
    const pxScreen = Math.round(p.x - camX - 8);
    const pyScreen = Math.round(p.y - camY - 8);
    const bodyArmor = getEquippedItem(state, 'body');
    const advKey =
      state.run.adventurerGender === 'male'
        ? bodyArmor
          ? 'adventurer_male_armored'
          : 'adventurer_male'
        : 'adventurer_female';

    ctx.fillStyle = 'rgba(15, 14, 22, 0.42)';
    ctx.fillRect(pxScreen + 3, pyScreen + 13, 10, 3);
    drawSpriteByKey(ctx, atlas, advKey, pxScreen, pyScreen, 16);

    // Facing indicator & equipped hand item sprite
    const handEq = getEquippedItem(state, 'hand');
    if (handEq) {
      const hDef = ITEMS[handEq.defId];
      const offX = p.facing === 'left' ? -7 : p.facing === 'right' ? 9 : 6;
      const offY = p.facing === 'up' ? -5 : p.facing === 'down' ? 4 : 2;
      drawSpriteByKey(ctx, atlas, hDef?.sprite ?? 'survival_knife', pxScreen + offX, pyScreen + offY, 12);
    }

    // Active cast windup bar
    if (p.activeCast && !p.activeCast.committed) {
      const prog = Math.min(
        1,
        (state.clock.elapsedRealSeconds - p.activeCast.startedAtElapsedSec) /
          Math.max(0.05, p.activeCast.commitSec)
      );
      ctx.fillStyle = '#2e222f';
      ctx.fillRect(pxScreen + 1, pyScreen - 5, 14, 3);
      ctx.fillStyle = '#4cc9f0';
      ctx.fillRect(pxScreen + 2, pyScreen - 4, Math.round(12 * prog), 1);
    }
  }

  // 9. Roofs with Automatic Room Cutaway Occlusion (§4, §9.6, §12)
  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0 || st.tileX < minTx || st.tileX > maxTx || st.tileY < minTy || st.tileY > maxTy)
      continue;
    const sDef = STRUCTURES[st.defId];
    if (!sDef?.isRoof) continue;
    const sx = st.tileX * 16 - camX;
    const sy = st.tileY * 16 - camY;
    // Fade roof cleanly when player is inside/under nearby connected roofed room (within 3 tiles)
    const underRoof = Math.max(Math.abs(st.tileX - ptx), Math.abs(st.tileY - pty)) <= 3;
    ctx.save();
    ctx.globalAlpha = underRoof ? 0.16 : 0.96;
    drawSpriteByKey(ctx, atlas, sDef.sprite, sx, sy, 16);
    ctx.restore();
  }

  // 10. Fog-of-War / Non-LOS Dimming & Day/Night Ambient Pass
  for (let ty = minTy; ty <= maxTy; ty++) {
    for (let tx = minTx; tx <= maxTx; tx++) {
      if (!visibleSet.has(`${tx},${ty}`)) {
        ctx.fillStyle = 'rgba(11, 15, 25, 0.56)';
        ctx.fillRect(tx * 16 - camX, ty * 16 - camY, 16, 16);
      }
    }
  }

  if (isNight) {
    ctx.fillStyle = 'rgba(14, 22, 46, 0.34)';
    ctx.fillRect(0, 0, W, H);
  }
  if (state.clock.phase !== 'normal') {
    // Subtle Ragnarok crimson dusk atmosphere (never obscuring gameplay readability)
    ctx.fillStyle = 'rgba(120, 28, 36, 0.12)';
    ctx.fillRect(0, 0, W, H);
  }

  // 11. Weather Particles (Rain, Storm, Ash Wind, Cold Snap Snow)
  if (state.clock.weather !== 'clear') {
    const t = Math.floor(uiCtx.animTimeMs / 45);
    ctx.fillStyle =
      state.clock.weather === 'cold_snap'
        ? 'rgba(240, 248, 255, 0.7)'
        : state.clock.weather === 'ash_wind'
          ? 'rgba(255, 140, 66, 0.6)'
          : 'rgba(144, 224, 239, 0.55)';
    const count = state.clock.weather === 'storm' ? 55 : 30;
    for (let i = 0; i < count; i++) {
      const wx = ((i * 97 + t * 5) % W + W) % W;
      const wy = ((i * 53 + t * 9) % H + H) % H;
      if (state.clock.weather === 'rain' || state.clock.weather === 'storm') {
        ctx.fillRect(wx, wy, 1, 5);
      } else {
        ctx.fillRect(wx, wy, 2, 2);
      }
    }
  }

  // 12. Build Mode Footprint Ghost Preview (shows validity + cost + exact rejection reason!)
  if (uiCtx.selectedBuildDefId && uiCtx.hoverWorldX !== null && uiCtx.hoverWorldY !== null) {
    const gtx = Math.floor(uiCtx.hoverWorldX / 16);
    const gty = Math.floor(uiCtx.hoverWorldY / 16);
    const check = checkBuildPlacementValidity(state, uiCtx.selectedBuildDefId, gtx, gty);
    const gx = gtx * 16 - camX;
    const gy = gty * 16 - camY;
    const bDef = STRUCTURES[uiCtx.selectedBuildDefId];

    ctx.save();
    ctx.globalAlpha = 0.65;
    if (bDef) {
      drawSpriteByKey(ctx, atlas, bDef.sprite, gx, gy, 16);
    }
    ctx.globalAlpha = 1;
    ctx.strokeStyle = check.valid ? '#52b788' : '#ff4d6d';
    ctx.strokeRect(gx + 0.5, gy + 0.5, 15, 15);
    if (!check.valid && check.reason) {
      ctx.font = '9px monospace';
      const tw = ctx.measureText(check.reason).width + 8;
      const bx = Math.max(4, Math.min(W - tw - 4, gx - tw / 2 + 8));
      const by = Math.max(28, gy - 14);
      ctx.fillStyle = 'rgba(22, 18, 28, 0.9)';
      ctx.fillRect(bx, by, tw, 12);
      ctx.fillStyle = '#ff758f';
      ctx.fillText(check.reason, bx + 4, by + 9);
    }
    ctx.restore();
  }

  // 13. Authorized VFX Cues (Slashes, Core AOE Blasts, Rays, Floating Damage/Yield Text)
  for (const cue of state.vfxCues) {
    const age = state.clock.elapsedRealSeconds - cue.createdAtSec;
    if (age < 0 || age > cue.durationSec) continue;
    const prog = age / Math.max(0.05, cue.durationSec);
    const sx = cue.x - camX;
    const sy = cue.y - camY;

    ctx.save();
    ctx.globalAlpha = Math.max(0.1, 1 - prog);
    if (cue.kind === 'slash') {
      const ang = Math.atan2((cue.targetY ?? cue.y) - cue.y, (cue.targetX ?? cue.x + 16) - cue.x);
      ctx.strokeStyle = cue.color;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(sx, sy, 18, ang - 0.7, ang + 0.7);
      ctx.stroke();
    } else if (cue.kind === 'aoe_blast' || cue.kind === 'self_aura') {
      ctx.strokeStyle = cue.color;
      ctx.fillStyle = cue.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(sx, sy, (cue.radiusPx ?? 32) * (0.4 + 0.6 * prog), 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 0.22 * (1 - prog);
      ctx.fill();
    } else if (cue.kind === 'line_ray' && cue.targetX !== undefined && cue.targetY !== undefined) {
      ctx.strokeStyle = cue.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(cue.targetX - camX, cue.targetY - camY);
      ctx.stroke();
    } else if (cue.kind === 'floating_text' && cue.text) {
      ctx.font = 'bold 9px monospace';
      ctx.fillStyle = '#14111a';
      ctx.fillText(cue.text, Math.round(sx - 12 + 1), Math.round(sy - prog * 14 + 1));
      ctx.fillStyle = cue.color;
      ctx.fillText(cue.text, Math.round(sx - 12), Math.round(sy - prog * 14));
    }
    ctx.restore();
  }

  // 14. Crisp Nearby POI Nameplate Banner when approaching POI
  const nearPoi = state.world.pois.find(
    (poi) => Math.hypot(poi.centerX * 16 - p.x, poi.centerY * 16 - p.y) < 128
  );
  if (nearPoi) {
    ctx.font = 'bold 9px monospace';
    const label = `${nearPoi.name}${nearPoi.unlockedDeep ? '' : ' [GATED]'}`;
    const lw = ctx.measureText(label).width + 10;
    ctx.fillStyle = 'rgba(20, 24, 36, 0.82)';
    ctx.fillRect(Math.round(W / 2 - lw / 2), 26, lw, 13);
    ctx.fillStyle = '#ffd166';
    ctx.fillText(label, Math.round(W / 2 - lw / 2 + 5), 35);
  }
}

export function screenToWorldCoords(
  canvas: HTMLCanvasElement,
  clientX: number,
  clientY: number,
  state: GameState
): { worldX: number; worldY: number } {
  const rect = canvas.getBoundingClientRect();
  const lx = ((clientX - rect.left) / Math.max(1, rect.width)) * 640;
  const ly = ((clientY - rect.top) / Math.max(1, rect.height)) * 360;
  const p = state.actors.player;
  const camX = Math.round(Math.max(0, Math.min(state.world.width * 16 - 640, p.x - 320)));
  const camY = Math.round(Math.max(0, Math.min(state.world.height * 16 - 360, p.y - 180)));
  return {
    worldX: camX + lx,
    worldY: camY + ly,
  };
}
