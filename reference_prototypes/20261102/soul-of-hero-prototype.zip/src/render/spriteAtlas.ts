import tinyTownUrl from '../assets/kenney/tiny_town_packed.png';
import tinyDungeonUrl from '../assets/kenney/tiny_dungeon_packed.png';

export type SheetKey = 'town' | 'dungeon';

export interface SheetTileCoord {
  sheet: SheetKey;
  col: number;
  row: number;
}

/**
 * Visually verified 16x16 sprite coordinates in Kenney CC0 Tiny Town & Tiny Dungeon packed sheets (12 cols x 11 rows: 0..10).
 */
export const KENNEY_SPRITE_MAP: Record<string, SheetTileCoord> = {
  // Terrain & Natural Props (Tiny Town & Tiny Dungeon)
  grass_plain: { sheet: 'town', col: 0, row: 0 },
  grass_blades: { sheet: 'town', col: 1, row: 0 },
  grass_flower: { sheet: 'town', col: 2, row: 0 },
  road_dirt: { sheet: 'town', col: 1, row: 2 },
  cobble_tile: { sheet: 'town', col: 7, row: 3 },
  stone_plaza: { sheet: 'town', col: 1, row: 9 },
  pine_tree_top: { sheet: 'town', col: 4, row: 0 },
  pine_tree_bot: { sheet: 'town', col: 4, row: 1 },
  pine_tree: { sheet: 'town', col: 4, row: 2 },
  oak_tree_top: { sheet: 'town', col: 3, row: 0 },
  oak_tree_bot: { sheet: 'town', col: 3, row: 1 },
  oak_tree: { sheet: 'town', col: 3, row: 2 },
  berry_bush: { sheet: 'town', col: 5, row: 0 },
  herb_patch: { sheet: 'town', col: 5, row: 1 },
  mushrooms: { sheet: 'town', col: 5, row: 2 },
  fresh_spring: { sheet: 'town', col: 8, row: 8 },
  wood_log: { sheet: 'town', col: 10, row: 8 },
  stone_outcrop: { sheet: 'dungeon', col: 0, row: 2 },

  // Salvage & Containers (Tiny Dungeon rows 4, 6, 7)
  roadside_barrel: { sheet: 'dungeon', col: 10, row: 6 },
  salvage_crate: { sheet: 'dungeon', col: 5, row: 7 },
  poi_locker: { sheet: 'dungeon', col: 7, row: 7 },
  deep_tech_chest: { sheet: 'dungeon', col: 7, row: 7 },
  industrial_scrap: { sheet: 'dungeon', col: 6, row: 4 },
  fuel_drum: { sheet: 'dungeon', col: 7, row: 4 },

  // Structures & Homestead
  wood_floor: { sheet: 'town', col: 1, row: 2 },
  stone_foundation: { sheet: 'town', col: 1, row: 9 },
  wood_wall: { sheet: 'town', col: 1, row: 6 },
  stone_wall: { sheet: 'town', col: 5, row: 6 },
  wood_door: { sheet: 'town', col: 1, row: 7 },
  wood_door_open: { sheet: 'dungeon', col: 9, row: 1 },
  powered_blast_door: { sheet: 'town', col: 3, row: 9 },
  thatch_roof: { sheet: 'town', col: 5, row: 4 },
  slate_roof: { sheet: 'town', col: 1, row: 4 },
  claim_cabinet: { sheet: 'dungeon', col: 3, row: 5 },
  sleeping_bed: { sheet: 'dungeon', col: 10, row: 0 },
  storage_chest: { sheet: 'dungeon', col: 5, row: 7 },
  iron_strongbox: { sheet: 'dungeon', col: 7, row: 7 },
  workbench: { sheet: 'dungeon', col: 0, row: 6 },
  stone_furnace: { sheet: 'dungeon', col: 2, row: 6 },
  cooking_hearth: { sheet: 'town', col: 11, row: 8 },
  research_bench: { sheet: 'dungeon', col: 3, row: 6 },
  garden_planter: { sheet: 'dungeon', col: 6, row: 5 },
  campfire_lantern: { sheet: 'town', col: 10, row: 7 },
  hand_cart_kit: { sheet: 'town', col: 9, row: 4 },
  death_bag: { sheet: 'dungeon', col: 4, row: 5 },

  // Characters & NPCs (Tiny Dungeon rows 7 & 8)
  adventurer_male: { sheet: 'dungeon', col: 4, row: 7 },
  adventurer_male_armored: { sheet: 'dungeon', col: 2, row: 8 },
  adventurer_female: { sheet: 'dungeon', col: 3, row: 8 },
  vendor_quartermaster: { sheet: 'dungeon', col: 2, row: 7 },

  // 8 Distinct Habitat Monsters (Tiny Dungeon rows 9 & 10)
  bog_slime: { sheet: 'dungeon', col: 0, row: 9 },
  quarry_brute: { sheet: 'dungeon', col: 1, row: 9 },
  shore_crab: { sheet: 'dungeon', col: 2, row: 9 },
  road_scavenger: { sheet: 'dungeon', col: 4, row: 9 },
  rad_wraith: { sheet: 'dungeon', col: 1, row: 10 },
  forest_spider: { sheet: 'dungeon', col: 2, row: 10 },
  plains_hound: { sheet: 'dungeon', col: 3, row: 10 },
  ash_hound: { sheet: 'dungeon', col: 4, row: 10 },

  // Items, Tools, Weapons, Cores, Consumables (Tiny Dungeon rows 8, 9, 10 & Tiny Town rows 7..10)
  survival_knife: { sheet: 'dungeon', col: 7, row: 8 },
  stone_hatchet: { sheet: 'town', col: 7, row: 10 },
  stone_pickaxe: { sheet: 'town', col: 7, row: 9 },
  iron_axe: { sheet: 'dungeon', col: 10, row: 9 },
  iron_pickaxe: { sheet: 'town', col: 7, row: 9 },
  iron_machete: { sheet: 'dungeon', col: 9, row: 8 },
  hunting_bow: { sheet: 'town', col: 10, row: 9 },
  wood_arrow: { sheet: 'town', col: 11, row: 9 },
  repair_hammer: { sheet: 'dungeon', col: 9, row: 9 },
  iron_buckler: { sheet: 'dungeon', col: 5, row: 8 },
  leather_vest: { sheet: 'dungeon', col: 6, row: 8 },
  warm_coat: { sheet: 'dungeon', col: 1, row: 7 },
  hazard_suit: { sheet: 'dungeon', col: 0, row: 8 },
  miner_lantern: { sheet: 'town', col: 10, row: 7 },
  access_card_industrial: { sheet: 'town', col: 9, row: 9 },
  ragnarok_cash: { sheet: 'town', col: 9, row: 7 },
  clean_water: { sheet: 'dungeon', col: 8, row: 9 },
  field_bandage: { sheet: 'dungeon', col: 7, row: 9 },
  antirad_tonic: { sheet: 'dungeon', col: 6, row: 9 },
  spares_token: { sheet: 'dungeon', col: 5, row: 10 },
  blueprint_scroll: { sheet: 'dungeon', col: 8, row: 10 },
  core_volt: { sheet: 'dungeon', col: 9, row: 10 },
  core_mend: { sheet: 'dungeon', col: 10, row: 10 },
  core_ember: { sheet: 'dungeon', col: 11, row: 10 },
  evac_flare: { sheet: 'town', col: 9, row: 8 },
  wild_berries: { sheet: 'town', col: 5, row: 2 },
  cooked_stew: { sheet: 'town', col: 11, row: 8 },
  raw_meat: { sheet: 'dungeon', col: 7, row: 9 },
  harvest_tuber: { sheet: 'town', col: 9, row: 7 },
  medicinal_herb: { sheet: 'town', col: 5, row: 1 },
  plant_fiber: { sheet: 'town', col: 1, row: 0 },
  wood_plank: { sheet: 'town', col: 10, row: 8 },
  stone_chunk: { sheet: 'dungeon', col: 0, row: 2 },
  scrap_metal: { sheet: 'dungeon', col: 6, row: 4 },
  wire_coil: { sheet: 'dungeon', col: 6, row: 10 },
  machine_parts: { sheet: 'dungeon', col: 8, row: 4 },
  cloth_roll: { sheet: 'dungeon', col: 5, row: 9 },
  hide_pelt: { sheet: 'dungeon', col: 3, row: 10 },
  fuel_canister: { sheet: 'dungeon', col: 7, row: 4 },
  charcoal: { sheet: 'dungeon', col: 0, row: 2 },
  turret_ammo: { sheet: 'town', col: 11, row: 9 },
  crop_seed: { sheet: 'town', col: 2, row: 0 },
  bunker_fuse: { sheet: 'dungeon', col: 7, row: 10 },
};

export interface LoadedSpriteAtlas {
  townImg: HTMLImageElement | null;
  dungeonImg: HTMLImageElement | null;
  proceduralSprites: Record<string, HTMLCanvasElement>;
  ready: boolean;
}

const atlasSingleton: LoadedSpriteAtlas = {
  townImg: null,
  dungeonImg: null,
  proceduralSprites: {},
  ready: false,
};

function makePixelCanvas(
  w: number,
  h: number,
  draw: (ctx: CanvasRenderingContext2D) => void
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  draw(ctx);
  return c;
}

function px(ctx: CanvasRenderingContext2D, color: string, x: number, y: number, w = 1, h = 1) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function buildProceduralSprites(): Record<string, HTMLCanvasElement> {
  if (typeof document === 'undefined') return {};
  const sprites: Record<string, HTMLCanvasElement> = {};
  const OUT = '#2e222f';

  for (const [key, oreCol, hiCol] of [
    ['iron_vein', '#c77b58', '#f4cca1'],
    ['iron_ore', '#c77b58', '#f4cca1'],
    ['iron_ingot', '#99a9b8', '#e2ebf2'],
    ['sulfur_vent', '#e8c170', '#fff3b0'],
    ['sulfur_ore', '#e8c170', '#fff3b0'],
    ['core_frost', '#4f8fba', '#a4dddb'],
    ['core_pedestal', '#a265c9', '#f2d5f8'],
  ] as const) {
    sprites[key] = makePixelCanvas(16, 16, (ctx) => {
      px(ctx, OUT, 2, 4, 12, 10);
      px(ctx, '#5a5363', 3, 5, 10, 8);
      px(ctx, '#7d7587', 4, 5, 7, 5);
      px(ctx, oreCol, 4, 7, 3, 3);
      px(ctx, oreCol, 9, 6, 3, 4);
      px(ctx, hiCol, 5, 7, 1, 2);
      px(ctx, hiCol, 10, 6, 1, 2);
    });
  }

  sprites.escrow_chest = makePixelCanvas(16, 16, (ctx) => {
    px(ctx, OUT, 1, 3, 14, 12);
    px(ctx, '#d49a35', 2, 4, 12, 10);
    px(ctx, '#ffd166', 2, 4, 12, 4);
    px(ctx, OUT, 2, 8, 12, 1);
    px(ctx, '#4f8fba', 6, 7, 4, 4);
    px(ctx, '#a4dddb', 7, 8, 2, 2);
  });

  sprites.final72_vault = makePixelCanvas(16, 16, (ctx) => {
    px(ctx, OUT, 1, 2, 14, 13);
    px(ctx, '#8c2f39', 2, 3, 12, 11);
    px(ctx, '#e63946', 3, 4, 10, 4);
    px(ctx, '#ffd166', 2, 3, 2, 11);
    px(ctx, '#ffd166', 12, 3, 2, 11);
    px(ctx, OUT, 2, 8, 12, 1);
    px(ctx, '#ffd166', 6, 6, 4, 5);
    px(ctx, '#fff3b0', 7, 7, 2, 3);
  });

  sprites.fuel_generator = makePixelCanvas(16, 16, (ctx) => {
    px(ctx, OUT, 2, 3, 12, 11);
    px(ctx, '#c65146', 3, 4, 10, 9);
    px(ctx, '#4f5d75', 4, 5, 5, 5);
    px(ctx, '#ffd166', 10, 5, 2, 3);
    px(ctx, '#a4dddb', 5, 11, 6, 1);
  });

  sprites.wind_turbine = makePixelCanvas(16, 16, (ctx) => {
    px(ctx, OUT, 6, 6, 4, 9);
    px(ctx, '#bfc0c0', 7, 7, 2, 7);
    px(ctx, OUT, 2, 2, 12, 5);
    px(ctx, '#eef4ed', 3, 3, 10, 3);
    px(ctx, '#4f8fba', 7, 3, 2, 3);
  });

  sprites.auto_turret = makePixelCanvas(16, 16, (ctx) => {
    px(ctx, OUT, 4, 8, 8, 7);
    px(ctx, '#4f5d75', 5, 9, 6, 5);
    px(ctx, OUT, 3, 3, 10, 6);
    px(ctx, '#7d8597', 4, 4, 8, 4);
    px(ctx, '#ff6b35', 10, 5, 4, 2);
  });

  const stoneColors: Record<string, [string, string]> = {
    elder_stone_mire: ['#38b000', '#9ef01a'],
    elder_stone_cinder: ['#e85d04', '#ffba08'],
    elder_stone_frost: ['#00b4d8', '#caf0f8'],
    elder_stone_rad: ['#9d4edd', '#e0aaff'],
    elder_stone_gale: ['#4cc9f0', '#f1faee'],
    elder_stone_abyss: ['#1d3557', '#a8dadc'],
  };
  for (const [sId, [base, hi]] of Object.entries(stoneColors)) {
    sprites[sId] = makePixelCanvas(16, 16, (ctx) => {
      px(ctx, OUT, 4, 2, 8, 12);
      px(ctx, OUT, 3, 4, 10, 8);
      px(ctx, base, 5, 3, 6, 10);
      px(ctx, base, 4, 5, 8, 6);
      px(ctx, hi, 5, 4, 3, 4);
    });
  }

  const elderPalettes: Record<string, { body: string; accent: string; eye: string; crown: string }> = {
    elder_mire: { body: '#2d6a4f', accent: '#74c69d', eye: '#d8f3dc', crown: '#b7e4c7' },
    elder_cinder: { body: '#9d0208', accent: '#f48c06', eye: '#ffba08', crown: '#ffd166' },
    elder_frost: { body: '#1d4e89', accent: '#7dcfb6', eye: '#e0fbfc', crown: '#caf0f8' },
    elder_rad: { body: '#5a189a', accent: '#9ef01a', eye: '#ccff33', crown: '#e0aaff' },
    elder_gale: { body: '#3d5a80', accent: '#98c1d9', eye: '#e0fbfc', crown: '#ffd166' },
    elder_abyss: { body: '#1b263b', accent: '#415a77', eye: '#00f5d4', crown: '#72efdd' },
  };

  for (const [eId, pal] of Object.entries(elderPalettes)) {
    for (const form of ['latent', 'awakened'] as const) {
      sprites[`${eId}_${form}`] = makePixelCanvas(24, 24, (ctx) => {
        const isAwake = form === 'awakened';
        if (isAwake) {
          px(ctx, OUT, 3, 1, 4, 6);
          px(ctx, OUT, 17, 1, 4, 6);
          px(ctx, pal.crown, 4, 2, 2, 5);
          px(ctx, pal.crown, 18, 2, 2, 5);
          px(ctx, pal.crown, 9, 1, 6, 3);
        }
        px(ctx, OUT, 3, 5, 18, 16);
        px(ctx, pal.body, 4, 6, 16, 14);
        px(ctx, pal.accent, 6, 7, 12, 5);
        px(ctx, OUT, 6, 9, 4, 3);
        px(ctx, OUT, 14, 9, 4, 3);
        px(ctx, pal.eye, 7, 10, 2, 2);
        px(ctx, pal.eye, 15, 10, 2, 2);
        px(ctx, isAwake ? pal.crown : pal.accent, 10, 14, 4, 4);
        px(ctx, OUT, 5, 20, 5, 3);
        px(ctx, OUT, 14, 20, 5, 3);
      });
    }
  }

  return sprites;
}

export function ensureSpriteAtlasLoaded(onLoaded?: () => void): LoadedSpriteAtlas {
  if (Object.keys(atlasSingleton.proceduralSprites).length === 0 && typeof document !== 'undefined') {
    atlasSingleton.proceduralSprites = buildProceduralSprites();
  }
  if (!atlasSingleton.townImg && typeof Image !== 'undefined') {
    const tImg = new Image();
    const dImg = new Image();
    let count = 0;
    const check = () => {
      count++;
      if (count >= 2) {
        atlasSingleton.ready = true;
        onLoaded?.();
      }
    };
    tImg.onload = check;
    dImg.onload = check;
    tImg.src = tinyTownUrl;
    dImg.src = tinyDungeonUrl;
    atlasSingleton.townImg = tImg;
    atlasSingleton.dungeonImg = dImg;
  }
  return atlasSingleton;
}

export function drawSpriteByKey(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedSpriteAtlas,
  spriteKey: string,
  destX: number,
  destY: number,
  destSize = 16
): boolean {
  const proc = atlas.proceduralSprites[spriteKey];
  if (proc) {
    ctx.drawImage(proc, 0, 0, proc.width, proc.height, destX, destY, destSize, destSize);
    return true;
  }
  const coord = KENNEY_SPRITE_MAP[spriteKey];
  if (!coord) return false;
  const img = coord.sheet === 'town' ? atlas.townImg : atlas.dungeonImg;
  if (!img || !img.complete || img.naturalWidth === 0) return false;
  ctx.drawImage(
    img,
    coord.col * 16,
    coord.row * 16,
    16,
    16,
    Math.round(destX),
    Math.round(destY),
    destSize,
    destSize
  );
  return true;
}
