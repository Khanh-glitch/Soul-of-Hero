declare module '*.png' {
  const src: string;
  export default src;
}

declare module 'zzfx' {
  export const ZZFX: {
    volume: number;
    play: (...params: number[]) => unknown;
  };
  export function zzfx(...params: number[]): unknown;
}
