import React, { useEffect, useRef } from 'react';
import { STRUCTURES } from '../sim/catalogs';
import type { GameState, SurfaceType } from '../sim/types';
import { getBaseIslandTopology } from '../sim/worldGen';

const MINI_COLORS: Record<SurfaceType, string> = {
  deep_water: '#162842',
  shallow_water: '#356f96',
  sand: '#d9b878',
  grass: '#5b8c5a',
  forest: '#366341',
  road: '#b08968',
  hills: '#6d7066',
  mountain_rock: '#403d47',
  stone: '#8a8e98',
  marsh: '#38523d',
  ash: '#574443',
  snow: '#dce6f0',
  toxic: '#687d3b',
  ice: '#90e0ef',
};

export const MinimapCanvas: React.FC<{ state: GameState }> = ({ state }) => {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    const topo = getBaseIslandTopology(state.world.seed);
    const discovered = new Set(state.world.discoveredChunks);
    const chunkW = Math.ceil(topo.width / 4);

    ctx.fillStyle = '#0d1321';
    ctx.fillRect(0, 0, 192, 192);

    for (let y = 0; y < topo.height; y++) {
      for (let x = 0; x < topo.width; x++) {
        const cIdx = Math.floor(y / 4) * chunkW + Math.floor(x / 4);
        const surf = topo.surfaces[y * topo.width + x];
        ctx.fillStyle = MINI_COLORS[surf] ?? '#5b8c5a';
        ctx.globalAlpha = discovered.has(cIdx) ? 1.0 : 0.28;
        ctx.fillRect(x, y, 1, 1);
      }
    }
    ctx.globalAlpha = 1.0;

    // Draw POIs
    for (const poi of state.world.pois) {
      ctx.fillStyle =
        poi.defId === 'poi_evacuation_harbor'
          ? '#00f5d4'
          : poi.defId === 'poi_frontier_vendor'
            ? '#ffd166'
            : '#f4a261';
      ctx.fillRect(poi.centerX - 2, poi.centerY - 2, 4, 4);
    }

    // Draw player Claim Cabinets & Escrow Chests
    for (const st of Object.values(state.structures)) {
      if (st.ownerId !== 'player' || st.hp <= 0) continue;
      const def = STRUCTURES[st.defId];
      if (def?.isEscrowChest) {
        ctx.fillStyle = '#ffd166';
        ctx.fillRect(st.tileX - 2, st.tileY - 2, 4, 4);
      } else if (def?.isTerritoryClaim) {
        ctx.fillStyle = '#52b788';
        ctx.fillRect(st.tileX - 1, st.tileY - 1, 3, 3);
      }
    }

    // Draw Death Bags
    for (const bag of Object.values(state.deathBags)) {
      ctx.fillStyle = '#ff4d6d';
      ctx.fillRect(Math.floor(bag.x / 16) - 2, Math.floor(bag.y / 16) - 2, 4, 4);
    }

    // Draw Adventurer
    const ptx = Math.floor(state.actors.player.x / 16);
    const pty = Math.floor(state.actors.player.y / 16);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(ptx - 2, pty - 2, 5, 5);
    ctx.fillStyle = '#e63946';
    ctx.fillRect(ptx - 1, pty - 1, 3, 3);
  }, [state]);

  return (
    <canvas
      ref={ref}
      width={192}
      height={192}
      style={{ width: '192px', height: '192px', imageRendering: 'pixelated' }}
      className="border border-amber-700/60 rounded bg-slate-950 mx-auto block"
    />
  );
};
