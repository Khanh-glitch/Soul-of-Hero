import React, { useEffect, useRef } from 'react';
import { drawSpriteByKey, ensureSpriteAtlasLoaded } from '../render/spriteAtlas';

interface PixelIconProps {
  sprite: string;
  size?: number;
  className?: string;
}

export const PixelIcon: React.FC<PixelIconProps> = ({ sprite, size = 20, className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const paint = () => {
      const c = canvasRef.current;
      if (!c) return;
      const ctx = c.getContext('2d');
      if (!ctx) return;
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, c.width, c.height);
      const atlas = ensureSpriteAtlasLoaded(paint);
      const ok = drawSpriteByKey(ctx, atlas, sprite, 0, 0, 16);
      if (!ok) {
        ctx.fillStyle = '#5c677d';
        ctx.fillRect(3, 3, 10, 10);
      }
    };
    paint();
  }, [sprite]);

  return (
    <canvas
      ref={canvasRef}
      width={16}
      height={16}
      style={{
        width: `${size}px`,
        height: `${size}px`,
        imageRendering: 'pixelated',
      }}
      className={`shrink-0 ${className}`}
    />
  );
};
