import React, { useState } from 'react';
import {
  BALANCE,
  BOSSES_LIST,
  ITEMS,
  POIS,
  RECIPES,
  RECIPES_LIST,
  SKILLS,
  STRUCTURES,
  STRUCTURES_LIST,
} from '../sim/catalogs';
import {
  PLAYER_BAG_SLOTS,
  PLAYER_QUICKBAR_SLOTS,
  computePlayerCarriedMassKg,
  computeVehicleCargoMassKg,
  countPlayerItem,
  findItemAtLocation,
  findOpenPlayerSlot,
  findOpenStructurePortSlot,
  findOpenVehicleSlot,
  getEquippedItem,
  isPlayerHeldLocation,
} from '../sim/custody';
import { computeRunUnverifiedScore } from '../sim/dispatcher';
import {
  getEffectiveSurface,
  isPlayerSheltered,
  isTileInPlayerOwnedTerritory,
  isTilePowered,
} from '../sim/navigation';
import type { ActionIntent, EquipSlot, GameState, ItemInstance } from '../sim/types';
import { MinimapCanvas } from './MinimapCanvas';
import { PixelIcon } from './PixelIcon';

export type ActivePanelKind =
  | null
  | 'inventory'
  | 'craft'
  | 'build'
  | 'research'
  | 'map'
  | 'journal'
  | 'skills'
  | 'menu';

export interface KeyBindings {
  inventory: string;
  craft: string;
  build: string;
  research: string;
  map: string;
  journal: string;
  interact: string;
}

interface GamePanelsProps {
  state: GameState;
  activePanel: ActivePanelKind;
  onClose: () => void;
  onDispatch: (intent: ActionIntent) => void;
  selectedBuildDefId: string | null;
  onSelectBuildDefId: (defId: string | null) => void;
  onManualSave: () => void;
  onReturnToTitle: () => void;
  onSimulateOfflineHours: (hours: number) => void;
  keyBindings: KeyBindings;
  onUpdateKeyBinding: (action: keyof KeyBindings, key: string) => void;
}

let uiIntentCounter = 1;
export function makeIntentId(prefix: string): string {
  return `ui_${prefix}_${Date.now()}_${uiIntentCounter++}`;
}

function distPx(x0: number, y0: number, x1: number, y1: number): number {
  return Math.hypot(x1 - x0, y1 - y0);
}

export const GamePanels: React.FC<GamePanelsProps> = ({
  state,
  activePanel,
  onClose,
  onDispatch,
  selectedBuildDefId,
  onSelectBuildDefId,
  onManualSave,
  onReturnToTitle,
  onSimulateOfflineHours,
  keyBindings,
  onUpdateKeyBinding,
}) => {
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [confirmAbandon, setConfirmAbandon] = useState(false);
  const [showDevQa, setShowDevQa] = useState(false);
  const [rebindingKey, setRebindingKey] = useState<keyof KeyBindings | null>(null);

  if (!activePanel) return null;

  const p = state.actors.player;
  const ptx = Math.floor(p.x / 16);
  const pty = Math.floor(p.y / 16);

  // Nearby physical structures, vehicles, death bags, and POIs within interaction reach
  const nearbyStructures = Object.values(state.structures).filter(
    (st) => st.hp > 0 && distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) <= 64
  );
  const nearbyVehicles = Object.values(state.vehicles).filter(
    (vh) => distPx(p.x, p.y, vh.x, vh.y) <= 64
  );
  const nearbyDeathBags = Object.values(state.deathBags).filter(
    (b) => distPx(p.x, p.y, b.x, b.y) <= 56
  );
  const nearbyPoi = state.world.pois.find(
    (poi) => distPx(p.x, p.y, poi.centerX * 16 + 8, poi.centerY * 16 + 8) <= 96
  );

  const selectedItem: ItemInstance | null = selectedItemId
    ? state.items[selectedItemId] ?? null
    : null;
  const selectedDef = selectedItem ? ITEMS[selectedItem.defId] : null;

  return (
    <aside
      data-testid={`panel-${activePanel}`}
      className="absolute right-1.5 top-7 bottom-10 w-[290px] sm:w-[350px] bg-slate-950/95 border border-amber-600/60 rounded shadow-2xl flex flex-col text-[11px] text-slate-100 z-20 overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-2.5 py-1.5 bg-slate-900 border-b border-amber-700/40 shrink-0">
        <span className="font-bold tracking-wide text-amber-300 uppercase text-[11px]">
          {activePanel === 'inventory' && 'Custody & Containers [I]'}
          {activePanel === 'craft' && 'Craft & Work Queues [C]'}
          {activePanel === 'build' && 'Build & Territory [B]'}
          {activePanel === 'research' && 'Research & Specimens [R]'}
          {activePanel === 'map' && 'Island Topology & Routes [M]'}
          {activePanel === 'journal' && 'Context Journal & Ledger [J]'}
          {activePanel === 'skills' && 'Skill Drivers & Controls [Tab]'}
          {activePanel === 'menu' && 'Session, Shelter Prep & QA [Esc]'}
        </span>
        <button
          onClick={onClose}
          className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px]"
        >
          ✕
        </button>
      </div>

      {/* Scrollable Interior Body */}
      <div className="flex-1 overflow-y-auto p-2 space-y-2.5">
        {/* ==================== INVENTORY & CUSTODY ==================== */}
        {activePanel === 'inventory' && (
          <>
            {/* Equipped Slots */}
            <div className="bg-slate-900/80 border border-slate-800 rounded p-1.5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-amber-200 font-semibold">EQUIPPED GEAR</span>
                <span className="text-[10px] text-slate-400">
                  Carry: {computePlayerCarriedMassKg(state)} / {BALANCE.player.baseCarryCapacityKg.value}kg
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {(['hand', 'body', 'utility'] as EquipSlot[]).map((slot) => {
                  const eq = getEquippedItem(state, slot);
                  const def = eq ? ITEMS[eq.defId] : null;
                  return (
                    <div
                      key={slot}
                      onClick={() => eq && setSelectedItemId(eq.instanceId)}
                      className={`p-1 rounded border cursor-pointer flex items-center gap-1 ${
                        eq && selectedItemId === eq.instanceId
                          ? 'border-amber-400 bg-amber-950/40'
                          : 'border-slate-700 bg-slate-950/70'
                      }`}
                    >
                      {def ? (
                        <>
                          <PixelIcon sprite={def.sprite} size={18} />
                          <div className="min-w-0 flex-1">
                            <div className="truncate text-[10px] font-medium">{def.name}</div>
                            <div className="text-[9px] text-slate-400">
                              {eq?.charges !== undefined
                                ? `${eq.charges} chg`
                                : eq?.durability !== undefined
                                  ? `${Math.round(eq.durability)} dur`
                                  : slot}
                            </div>
                          </div>
                        </>
                      ) : (
                        <span className="text-[9px] text-slate-500 uppercase mx-auto py-1">
                          {slot}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Selected Item Inspector & Direct Actions */}
            {selectedItem && selectedDef && (
              <div className="bg-amber-950/30 border border-amber-600/50 rounded p-2 space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-semibold text-amber-200">
                    <PixelIcon sprite={selectedDef.sprite} size={18} />
                    <span>
                      {selectedDef.name} {selectedItem.count > 1 ? `×${selectedItem.count}` : ''}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono">
                    {selectedItem.instanceId.slice(0, 14)}
                  </span>
                </div>
                <p className="text-[10px] text-slate-300 leading-tight">{selectedDef.description}</p>
                <div className="flex flex-wrap gap-1 pt-1">
                  {selectedDef.equipSlot && isPlayerHeldLocation(selectedItem.location) && (
                    <button
                      onClick={() =>
                        onDispatch(
                          selectedItem.location.kind === 'player_equip'
                            ? {
                                intentId: makeIntentId('uneq'),
                                kind: 'UNEQUIP_ITEM',
                                slot: selectedDef.equipSlot!,
                              }
                            : {
                                intentId: makeIntentId('eq'),
                                kind: 'EQUIP_ITEM',
                                itemInstanceId: selectedItem.instanceId,
                              }
                        )
                      }
                      className="px-2 py-0.5 rounded bg-amber-700 hover:bg-amber-600 text-white text-[10px]"
                    >
                      {selectedItem.location.kind === 'player_equip' ? 'Unequip' : 'Equip'}
                    </button>
                  )}
                  {(selectedDef.consumeEffects || selectedDef.blueprintRecipeId) &&
                    isPlayerHeldLocation(selectedItem.location) && (
                      <button
                        onClick={() =>
                          onDispatch({
                            intentId: makeIntentId('use'),
                            kind: 'USE_ITEM',
                            itemInstanceId: selectedItem.instanceId,
                          })
                        }
                        className="px-2 py-0.5 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-[10px]"
                      >
                        {selectedDef.blueprintRecipeId ? 'Read Blueprint' : 'Consume / Use'}
                      </button>
                    )}
                  {selectedDef.deployVehicleType && isPlayerHeldLocation(selectedItem.location) && (
                    <button
                      onClick={() =>
                        onDispatch({
                          intentId: makeIntentId('dep_cart'),
                          kind: 'DEPLOY_VEHICLE',
                          itemInstanceId: selectedItem.instanceId,
                          tileX: ptx,
                          tileY: pty,
                        })
                      }
                      className="px-2 py-0.5 rounded bg-sky-700 hover:bg-sky-600 text-white text-[10px]"
                    >
                      Deploy Hand-Cart
                    </button>
                  )}
                  {selectedDef.deployStructureId && isPlayerHeldLocation(selectedItem.location) && (
                    <button
                      onClick={() => onSelectBuildDefId(selectedDef.deployStructureId!)}
                      className="px-2 py-0.5 rounded bg-amber-600 hover:bg-amber-500 text-slate-950 font-semibold text-[10px]"
                    >
                      Place on Owned Land
                    </button>
                  )}
                  {selectedItem.count >= 2 && isPlayerHeldLocation(selectedItem.location) && (
                    <button
                      onClick={() =>
                        onDispatch({
                          intentId: makeIntentId('split'),
                          kind: 'SPLIT_STACK',
                          itemInstanceId: selectedItem.instanceId,
                          splitCount: Math.floor(selectedItem.count / 2),
                        })
                      }
                      className="px-2 py-0.5 rounded bg-slate-700 hover:bg-slate-600 text-[10px]"
                    >
                      Split ½
                    </button>
                  )}
                  {isPlayerHeldLocation(selectedItem.location) && (
                    <button
                      onClick={() => {
                        onDispatch({
                          intentId: makeIntentId('drop'),
                          kind: 'TRANSFER_ITEM',
                          itemInstanceId: selectedItem.instanceId,
                          toLocation: {
                            kind: 'ground_drop',
                            x: Math.round(p.x),
                            y: Math.round(p.y + 10),
                          },
                        });
                        setSelectedItemId(null);
                      }}
                      className="px-2 py-0.5 rounded bg-rose-900/80 hover:bg-rose-800 text-rose-100 text-[10px]"
                    >
                      Drop
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Backpack Grid (20 slots) */}
            <div>
              <div className="text-[10px] text-slate-400 font-semibold mb-1">
                ADVENTURER PACK ({PLAYER_BAG_SLOTS} SLOTS) — Click item, then click target slot/chest/cart
              </div>
              <div className="grid grid-cols-5 gap-1">
                {Array.from({ length: PLAYER_BAG_SLOTS }).map((_, idx) => {
                  const loc = { kind: 'player_bag' as const, slotIndex: idx };
                  const itm = findItemAtLocation(state, loc);
                  const def = itm ? ITEMS[itm.defId] : null;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        if (selectedItem && selectedItem.instanceId !== itm?.instanceId) {
                          onDispatch({
                            intentId: makeIntentId('xfer_bag'),
                            kind: 'TRANSFER_ITEM',
                            itemInstanceId: selectedItem.instanceId,
                            toLocation: loc,
                          });
                          setSelectedItemId(null);
                        } else if (itm) {
                          setSelectedItemId(itm.instanceId);
                        }
                      }}
                      title={def ? `${def.name} x${itm?.count}` : `Empty Slot ${idx + 1}`}
                      className={`h-10 rounded border flex flex-col items-center justify-center relative ${
                        itm && selectedItemId === itm.instanceId
                          ? 'border-amber-400 bg-amber-900/40'
                          : 'border-slate-800 bg-slate-900/70 hover:border-slate-600'
                      }`}
                    >
                      {itm && def && (
                        <>
                          <PixelIcon sprite={def.sprite} size={18} />
                          <span className="text-[9px] leading-none font-mono text-amber-200">
                            {itm.charges !== undefined
                              ? `${itm.charges}⚡`
                              : itm.count > 1
                                ? itm.count
                                : ''}
                          </span>
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
              {/* Quick Move to Quickbar */}
              {selectedItem && isPlayerHeldLocation(selectedItem.location) && (
                <div className="mt-1 flex items-center gap-1 flex-wrap">
                  <span className="text-[9px] text-slate-400">To Quickbar:</span>
                  {Array.from({ length: PLAYER_QUICKBAR_SLOTS }).map((_, qbIdx) => (
                    <button
                      key={qbIdx}
                      onClick={() => {
                        onDispatch({
                          intentId: makeIntentId('to_qb'),
                          kind: 'TRANSFER_ITEM',
                          itemInstanceId: selectedItem.instanceId,
                          toLocation: { kind: 'player_quickbar', slotIndex: qbIdx },
                        });
                        setSelectedItemId(null);
                      }}
                      className="px-1.5 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-[9px]"
                    >
                      {qbIdx + 1}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Nearby Placed Escrow Chest (Rương ký gửi) */}
            {nearbyStructures
              .filter((s) => STRUCTURES[s.defId]?.isEscrowChest && s.ownerId === 'player')
              .map((esc) => {
                const heldCash = countPlayerItem(state, 'ragnarok_cash');
                return (
                  <div
                    key={esc.id}
                    className="bg-amber-950/50 border border-amber-500 rounded p-2 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-300">
                        Rương Ký Gửi (Owned Escrow Vault)
                      </span>
                      <span className="text-[10px] text-emerald-300">
                        Secured: {state.profile.securedRagnarokCash}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-300">
                      Physical Ragnarok Cash in pack: <b>{heldCash}</b>
                    </div>
                    <button
                      disabled={heldCash <= 0}
                      onClick={() =>
                        onDispatch({
                          intentId: makeIntentId('escrow_dep'),
                          kind: 'DEPOSIT_ESCROW_CASH',
                          structureId: esc.id,
                        })
                      }
                      className="w-full py-1 rounded bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-bold text-[10px]"
                    >
                      Deposit {heldCash} Physical Cash → Secured Profile
                    </button>
                  </div>
                );
              })}

            {/* Nearby Homestead Bed */}
            {nearbyStructures
              .filter((s) => STRUCTURES[s.defId]?.isBed)
              .map((bed) => (
                <div
                  key={bed.id}
                  className="bg-slate-900 border border-slate-700 rounded p-2 flex items-center justify-between"
                >
                  <div>
                    <div className="font-semibold text-emerald-300">Homestead Bunk Bed</div>
                    <div className="text-[9px] text-slate-400">
                      {p.bedStructureId === bed.id ? 'Active Respawn Bound' : 'Not yet bound'}
                    </div>
                  </div>
                  <button
                    onClick={() =>
                      onDispatch({
                        intentId: makeIntentId('bed_rest'),
                        kind: 'SET_OR_REST_BED',
                        structureId: bed.id,
                      })
                    }
                    className="px-2 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-[10px]"
                  >
                    Bind & Rest
                  </button>
                </div>
              ))}

            {/* Nearby Storage Chests / Strongboxes / Turrets */}
            {nearbyStructures
              .filter((s) => (STRUCTURES[s.defId]?.containerSlots ?? 0) > 0 && !STRUCTURES[s.defId]?.stationType)
              .map((box) => {
                const sDef = STRUCTURES[box.defId]!;
                const slots = sDef.containerSlots ?? 6;
                return (
                  <div key={box.id} className="bg-slate-900/90 border border-slate-700 rounded p-1.5">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-amber-200">{sDef.name}</span>
                      {selectedItem && isPlayerHeldLocation(selectedItem.location) && (
                        <button
                          onClick={() => {
                            const open = findOpenStructurePortSlot(state, box.id, 'storage');
                            if (open) {
                              onDispatch({
                                intentId: makeIntentId('store_box'),
                                kind: 'TRANSFER_ITEM',
                                itemInstanceId: selectedItem.instanceId,
                                toLocation: open,
                              });
                              setSelectedItemId(null);
                            }
                          }}
                          className="px-1.5 py-0.5 rounded bg-amber-700 hover:bg-amber-600 text-[9px]"
                        >
                          Store Selected →
                        </button>
                      )}
                    </div>
                    <div className="grid grid-cols-6 gap-1">
                      {Array.from({ length: slots }).map((_, sIdx) => {
                        const loc = {
                          kind: 'structure_container' as const,
                          structureId: box.id,
                          port: 'storage' as const,
                          slotIndex: sIdx,
                        };
                        const cItem = findItemAtLocation(state, loc);
                        const cDef = cItem ? ITEMS[cItem.defId] : null;
                        return (
                          <button
                            key={sIdx}
                            onClick={() => {
                              if (cItem) {
                                const open = findOpenPlayerSlot(state);
                                if (open) {
                                  onDispatch({
                                    intentId: makeIntentId('take_box'),
                                    kind: 'TRANSFER_ITEM',
                                    itemInstanceId: cItem.instanceId,
                                    toLocation: open,
                                  });
                                }
                              } else if (selectedItem) {
                                onDispatch({
                                  intentId: makeIntentId('put_box'),
                                  kind: 'TRANSFER_ITEM',
                                  itemInstanceId: selectedItem.instanceId,
                                  toLocation: loc,
                                });
                                setSelectedItemId(null);
                              }
                            }}
                            title={cDef ? `Take ${cDef.name} x${cItem?.count}` : 'Empty container slot'}
                            className="h-8 rounded border border-slate-800 bg-slate-950 flex flex-col items-center justify-center"
                          >
                            {cItem && cDef && (
                              <>
                                <PixelIcon sprite={cDef.sprite} size={14} />
                                <span className="text-[8px] font-mono">{cItem.count}</span>
                              </>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

            {/* Nearby Freight Hand-Cart */}
            {nearbyVehicles.map((vh) => {
              const cartKg = computeVehicleCargoMassKg(state, vh.id);
              const isHitched = p.tetheredVehicleId === vh.id;
              return (
                <div key={vh.id} className="bg-slate-900 border border-sky-700/60 rounded p-1.5 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sky-300">
                      Freight Hand-Cart ({cartKg}/{BALANCE.freight.handCartCargoCapacityKg.value}kg)
                    </span>
                    <div className="flex gap-1">
                      {selectedItem && isPlayerHeldLocation(selectedItem.location) && (
                        <button
                          onClick={() => {
                            const open = findOpenVehicleSlot(state, vh.id);
                            if (open) {
                              onDispatch({
                                intentId: makeIntentId('load_cart'),
                                kind: 'TRANSFER_ITEM',
                                itemInstanceId: selectedItem.instanceId,
                                toLocation: open,
                              });
                              setSelectedItemId(null);
                            }
                          }}
                          className="px-1.5 py-0.5 rounded bg-sky-800 hover:bg-sky-700 text-[9px]"
                        >
                          Load →
                        </button>
                      )}
                      <button
                        onClick={() =>
                          onDispatch({
                            intentId: makeIntentId('hitch'),
                            kind: 'TOGGLE_CART_TETHER',
                            vehicleId: vh.id,
                          })
                        }
                        className="px-2 py-0.5 rounded bg-sky-600 hover:bg-sky-500 text-white text-[9px]"
                      >
                        {isHitched ? 'Park Cart' : 'Hitch Cart'}
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-1">
                    {Array.from({ length: BALANCE.freight.handCartSlots.value }).map((_, sIdx) => {
                      const loc = {
                        kind: 'vehicle_cargo' as const,
                        vehicleId: vh.id,
                        slotIndex: sIdx,
                      };
                      const cItem = findItemAtLocation(state, loc);
                      const cDef = cItem ? ITEMS[cItem.defId] : null;
                      return (
                        <button
                          key={sIdx}
                          onClick={() => {
                            if (cItem) {
                              const open = findOpenPlayerSlot(state);
                              if (open) {
                                onDispatch({
                                  intentId: makeIntentId('unload_cart'),
                                  kind: 'TRANSFER_ITEM',
                                  itemInstanceId: cItem.instanceId,
                                  toLocation: open,
                                });
                              }
                            }
                          }}
                          className="h-8 rounded border border-slate-800 bg-slate-950 flex flex-col items-center justify-center"
                        >
                          {cItem && cDef && (
                            <>
                              <PixelIcon sprite={cDef.sprite} size={14} />
                              <span className="text-[8px] font-mono">{cItem.count}</span>
                            </>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}

            {/* Nearby Death Bag Recovery */}
            {nearbyDeathBags.map((bag) => (
              <div
                key={bag.id}
                className="bg-rose-950/50 border border-rose-500 rounded p-2 flex items-center justify-between"
              >
                <span className="font-semibold text-rose-200">Dropped Death Bag Nearby</span>
                <button
                  onClick={() =>
                    onDispatch({
                      intentId: makeIntentId('rec_bag'),
                      kind: 'RECOVER_DEATH_BAG',
                      bagId: bag.id,
                    })
                  }
                  className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-semibold text-[10px]"
                >
                  Recover All
                </button>
              </div>
            ))}

            {/* Nearby Freeport Quartermaster Vendor */}
            {nearbyPoi && POIS[nearbyPoi.defId]?.isVendor && (
              <div className="bg-slate-900 border border-amber-500/70 rounded p-2 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300">Freeport Quartermaster</span>
                  <span className="text-[9px] text-emerald-300">
                    Secured: {state.profile.securedRagnarokCash} | Held: {countPlayerItem(state, 'ragnarok_cash')}
                  </span>
                </div>
                <div className="space-y-1">
                  {POIS[nearbyPoi.defId].vendorCatalog?.map((offer) => {
                    const oDef = ITEMS[offer.itemId];
                    const stock = state.vendorStocks[offer.id] ?? 0;
                    return (
                      <div
                        key={offer.id}
                        className="flex items-center justify-between bg-slate-950/80 p-1 rounded border border-slate-800"
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          {oDef && <PixelIcon sprite={oDef.sprite} size={16} />}
                          <div className="min-w-0">
                            <div className="truncate font-medium text-[10px]">
                              {oDef?.name ?? offer.itemId} {offer.count > 1 ? `×${offer.count}` : ''}
                            </div>
                            <div className="text-[8px] text-slate-400">
                              Stock: {stock} •{' '}
                              {offer.currency === 'physical_or_profile_cash'
                                ? 'Physical or Profile Cash [PROPOSED]'
                                : 'Profile Secured Cash'}
                            </div>
                          </div>
                        </div>
                        <button
                          disabled={stock <= 0}
                          onClick={() =>
                            onDispatch({
                              intentId: makeIntentId('buy_vnd'),
                              kind: 'BUY_VENDOR_OFFER',
                              poiId: nearbyPoi.id,
                              offerId: offer.id,
                            })
                          }
                          className="px-2 py-0.5 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-slate-950 font-bold text-[10px] shrink-0"
                        >
                          Buy ({offer.price})
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Nearby Cape Beacon Evacuation Dock */}
            {nearbyPoi && POIS[nearbyPoi.defId]?.isEvacuationSite && (
              <div className="bg-teal-950/50 border border-teal-400 rounded p-2 space-y-1">
                <div className="font-bold text-teal-300">Cape Beacon Evacuation Dock</div>
                <p className="text-[9px] text-slate-300">
                  Finalizes this run once. Carried unsecured cash ({countPlayerItem(state, 'ragnarok_cash')}) is{' '}
                  <b>NOT</b> auto-deposited! Requires Signal Flare (or Final-72 window).
                </p>
                <button
                  onClick={() =>
                    onDispatch({
                      intentId: makeIntentId('evac'),
                      kind: 'EVACUATE_RUN',
                      poiId: nearbyPoi.id,
                    })
                  }
                  className="w-full py-1 rounded bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-[10px]"
                >
                  Activate Beacon & Evacuate Run
                </button>
              </div>
            )}
          </>
        )}

        {/* ==================== CRAFT & WORK QUEUES ==================== */}
        {activePanel === 'craft' && (
          <>
            {/* Nearby Fueled Stations & Power Controls */}
            {nearbyStructures
              .filter((s) => STRUCTURES[s.defId]?.usesFuel)
              .map((st) => {
                const sDef = STRUCTURES[st.defId]!;
                const fuelItems = Object.values(state.items).filter(
                  (i) => isPlayerHeldLocation(i.location) && (ITEMS[i.defId]?.fuelSeconds ?? 0) > 0
                );
                return (
                  <div
                    key={st.id}
                    className="bg-slate-900 border border-amber-700/50 rounded p-1.5 space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-amber-200">{sDef.name}</span>
                      <span className="text-[10px] text-orange-300 font-mono">
                        Fuel: {Math.round(st.fuelRemainingSec)}s
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {fuelItems.length === 0 ? (
                        <span className="text-[9px] text-slate-500">
                          Carry Logs, Planks, Charcoal, or Fuel Cans to fuel station
                        </span>
                      ) : (
                        fuelItems.map((fi) => (
                          <button
                            key={fi.instanceId}
                            onClick={() =>
                              onDispatch({
                                intentId: makeIntentId('fuel'),
                                kind: 'FUEL_STATION',
                                structureId: st.id,
                                fuelItemInstanceId: fi.instanceId,
                                count: 1,
                              })
                            }
                            className="px-1.5 py-0.5 rounded bg-orange-800 hover:bg-orange-700 text-white text-[9px]"
                          >
                            +1 {ITEMS[fi.defId]?.name} ({ITEMS[fi.defId]?.fuelSeconds}s)
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}

            {/* Active / Completed Work Jobs */}
            {Object.values(state.jobs).filter(
              (j) => j.status !== 'claimed' && j.status !== 'cancelled'
            ).length > 0 && (
              <div className="bg-slate-900/90 border border-emerald-700/50 rounded p-1.5 space-y-1">
                <div className="text-[10px] font-semibold text-emerald-300">WORK ORDERS</div>
                {Object.values(state.jobs)
                  .filter((j) => j.status !== 'claimed' && j.status !== 'cancelled')
                  .map((job) => {
                    const rName = RECIPES[job.recipeId]?.name ?? job.recipeId;
                    const pct = Math.min(100, Math.round((job.progressSec / Math.max(1, job.totalWorkSec)) * 100));
                    return (
                      <div
                        key={job.id}
                        className="bg-slate-950 p-1.5 rounded border border-slate-800 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{rName}</span>
                          <span className="text-[9px] uppercase text-amber-300">
                            {job.status.replace(/_/g, ' ')} ({pct}%)
                          </span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded overflow-hidden">
                          <div
                            className="h-full bg-emerald-500"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <div className="flex justify-end gap-1">
                          {job.status === 'completed_unclaimed' ? (
                            <button
                              onClick={() =>
                                onDispatch({
                                  intentId: makeIntentId('claim_job'),
                                  kind: 'CLAIM_JOB_OUTPUT',
                                  jobId: job.id,
                                })
                              }
                              className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[10px]"
                            >
                              Claim Output
                            </button>
                          ) : (
                            <button
                              onClick={() =>
                                onDispatch({
                                  intentId: makeIntentId('cancel_job'),
                                  kind: 'CANCEL_JOB',
                                  jobId: job.id,
                                })
                              }
                              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-rose-300 text-[9px]"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}

            {/* Known Recipes */}
            <div className="space-y-1">
              <div className="text-[10px] text-slate-400 font-semibold">
                KNOWN RECIPES ({state.run.learnedRecipeIds.length} / {RECIPES_LIST.length})
              </div>
              {RECIPES_LIST.filter((r) => state.run.learnedRecipeIds.includes(r.id)).map((rec) => {
                const matchingStation =
                  rec.station === 'hand'
                    ? 'hand'
                    : nearbyStructures.find((s) => STRUCTURES[s.defId]?.stationType === rec.station)?.id ??
                      null;
                const canAfford = rec.inputs.every(
                  (inp) => countPlayerItem(state, inp.itemId) >= inp.count
                );
                const outDef = ITEMS[rec.outputs[0]?.itemId];
                return (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between bg-slate-900/80 border border-slate-800 rounded p-1.5"
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      {outDef && <PixelIcon sprite={outDef.sprite} size={18} />}
                      <div className="min-w-0">
                        <div className="font-medium truncate">{rec.name}</div>
                        <div className="text-[9px] text-slate-400">
                          {rec.inputs
                            .map(
                              (i) =>
                                `${countPlayerItem(state, i.itemId)}/${i.count} ${ITEMS[i.itemId]?.name ?? i.itemId}`
                            )
                            .join(', ')}
                        </div>
                        <div className="text-[8px] text-amber-300/80">
                          Station: {rec.station.replace('_', ' ')} • {rec.workSeconds}s
                          {rec.fuelSecondsRequired > 0 ? ' • Uses Fuel' : ''}
                          {rec.powerRequired ? ' • Needs Power' : ''}
                        </div>
                      </div>
                    </div>
                    <button
                      disabled={!matchingStation || !canAfford}
                      onClick={() =>
                        matchingStation &&
                        onDispatch({
                          intentId: makeIntentId('start_job'),
                          kind: 'START_JOB',
                          recipeId: rec.id,
                          stationId: matchingStation,
                        })
                      }
                      className="px-2 py-1 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-35 text-slate-950 font-bold text-[10px] shrink-0"
                    >
                      Start
                    </button>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* ==================== BUILD & TERRITORY ==================== */}
        {activePanel === 'build' && (
          <>
            <div className="bg-slate-900 border border-slate-800 rounded p-1.5 text-[10px] flex items-center justify-between">
              <span>
                Territory here:{' '}
                <b
                  className={
                    isTileInPlayerOwnedTerritory(state, ptx, pty)
                      ? 'text-emerald-400'
                      : 'text-slate-400'
                  }
                >
                  {isTileInPlayerOwnedTerritory(state, ptx, pty) ? 'OWNED HOME LAND' : 'UNCLAIMED'}
                </b>
              </span>
              {selectedBuildDefId && (
                <button
                  onClick={() => onSelectBuildDefId(null)}
                  className="px-1.5 py-0.5 rounded bg-rose-900 text-rose-200 text-[9px]"
                >
                  Clear Brush
                </button>
              )}
            </div>

            {selectedBuildDefId && (
              <div className="bg-emerald-950/40 border border-emerald-500/60 rounded p-1.5 text-[10px] text-emerald-200">
                <b>Active Build Brush:</b> {STRUCTURES[selectedBuildDefId]?.name} — Click any valid
                nearby tile on the world canvas to place!
              </div>
            )}

            {/* Nearby Owned Structures Management (Door / Repair / Reclaim) */}
            {nearbyStructures.filter((s) => s.ownerId === 'player').length > 0 && (
              <div className="bg-slate-900/80 border border-slate-800 rounded p-1.5 space-y-1">
                <div className="text-[10px] text-amber-300 font-semibold">
                  NEARBY OWNED STRUCTURES
                </div>
                {nearbyStructures
                  .filter((s) => s.ownerId === 'player')
                  .slice(0, 6)
                  .map((st) => {
                    const sDef = STRUCTURES[st.defId]!;
                    return (
                      <div
                        key={st.id}
                        className="flex items-center justify-between bg-slate-950 px-1.5 py-1 rounded text-[10px]"
                      >
                        <span className="truncate">
                          {sDef.name} ({Math.round(st.hp)}/{st.maxHp})
                        </span>
                        <div className="flex gap-1 shrink-0">
                          {sDef.isDoor && (
                            <button
                              onClick={() =>
                                onDispatch({
                                  intentId: makeIntentId('door'),
                                  kind: 'TOGGLE_DOOR',
                                  structureId: st.id,
                                })
                              }
                              className="px-1.5 py-0.5 bg-sky-800 rounded text-[9px]"
                            >
                              {st.isOpen ? 'Close' : 'Open'}
                            </button>
                          )}
                          {st.hp < st.maxHp && (
                            <button
                              onClick={() =>
                                onDispatch({
                                  intentId: makeIntentId('rep'),
                                  kind: 'REPAIR_STRUCTURE',
                                  structureId: st.id,
                                })
                              }
                              className="px-1.5 py-0.5 bg-emerald-800 rounded text-[9px]"
                            >
                              Repair
                            </button>
                          )}
                          <button
                            onClick={() =>
                              onDispatch({
                                intentId: makeIntentId('rcl'),
                                kind: 'RECLAIM_STRUCTURE',
                                structureId: st.id,
                              })
                            }
                            className="px-1.5 py-0.5 bg-slate-800 hover:bg-rose-900 rounded text-[9px]"
                          >
                            Reclaim
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}

            {/* 22 Buildable Structures Catalog */}
            <div className="space-y-1">
              {STRUCTURES_LIST.map((sDef) => {
                const canAfford = sDef.cost.every(
                  (c) => countPlayerItem(state, c.itemId) >= c.count
                );
                const isSelected = selectedBuildDefId === sDef.id;
                return (
                  <div
                    key={sDef.id}
                    className={`flex items-center justify-between p-1.5 rounded border ${
                      isSelected
                        ? 'border-emerald-400 bg-emerald-950/40'
                        : 'border-slate-800 bg-slate-900/75'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <PixelIcon sprite={sDef.sprite} size={18} />
                      <div className="min-w-0">
                        <div className="font-medium truncate">
                          {sDef.name}{' '}
                          {sDef.requiresOwnedTerritory && (
                            <span className="text-[8px] text-amber-400">[Claim Req]</span>
                          )}
                        </div>
                        <div className="text-[9px] text-slate-400">
                          {sDef.cost
                            .map(
                              (c) =>
                                `${countPlayerItem(state, c.itemId)}/${c.count} ${ITEMS[c.itemId]?.name ?? c.itemId}`
                            )
                            .join(', ')}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => onSelectBuildDefId(isSelected ? null : sDef.id)}
                      className={`px-2 py-1 rounded font-bold text-[10px] shrink-0 ${
                        isSelected
                          ? 'bg-emerald-500 text-slate-950'
                          : canAfford
                            ? 'bg-amber-600 hover:bg-amber-500 text-slate-950'
                            : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isSelected ? 'Placing' : 'Select'}
                    </button>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* ==================== RESEARCH & SPECIMENS ==================== */}
        {activePanel === 'research' && (
          <>
            {(() => {
              const desk = nearbyStructures.find(
                (s) => STRUCTURES[s.defId]?.stationType === 'research_bench'
              );
              const sparesHeld = countPlayerItem(state, 'spares_token');
              const eligibleSpecimens = Object.values(state.items).filter(
                (i) => isPlayerHeldLocation(i.location) && ITEMS[i.defId]?.studyEligible
              );
              const unknownDirected = RECIPES_LIST.filter(
                (r) =>
                  !r.starterKnown &&
                  !r.specimenOnly &&
                  r.directedSparesCost &&
                  !state.run.learnedRecipeIds.includes(r.id)
              );

              return (
                <>
                  <div className="bg-slate-900 border border-slate-800 rounded p-2 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-amber-300">
                        {desk ? 'Specimen & Schematic Desk Ready' : 'No Research Desk Nearby'}
                      </span>
                      <span className="text-[10px] text-sky-300">Spares: {sparesHeld}</span>
                    </div>
                    <p className="text-[9px] text-slate-400">
                      All 4 discovery paths update one run-local knowledge store. Cores require ≥1
                      remaining charge to study (PROPOSED_MECHANISM).
                    </p>
                    <button
                      disabled={
                        !desk ||
                        sparesHeld < BALANCE.researchAndCores.randomSparesResearchCost.value ||
                        unknownDirected.length === 0
                      }
                      onClick={() =>
                        desk &&
                        onDispatch({
                          intentId: makeIntentId('res_rnd'),
                          kind: 'START_RESEARCH',
                          stationId: desk.id,
                          mode: 'random_spares',
                        })
                      }
                      className="w-full py-1 rounded bg-sky-600 hover:bg-sky-500 disabled:opacity-35 text-white font-bold text-[10px]"
                    >
                      Random Unknown Schematic ({BALANCE.researchAndCores.randomSparesResearchCost.value} Spares)
                    </button>
                  </div>

                  {/* Destructive Specimen Study */}
                  <div className="space-y-1">
                    <div className="text-[10px] font-semibold text-purple-300">
                      ELIGIBLE SPECIMENS IN CUSTODY
                    </div>
                    {eligibleSpecimens.length === 0 ? (
                      <div className="text-[9px] text-slate-500 bg-slate-900/50 p-2 rounded">
                        No study-eligible Core, Ranger Blade, or Hazard Suit currently in pack.
                      </div>
                    ) : (
                      eligibleSpecimens.map((spec) => {
                        const sDef = ITEMS[spec.defId]!;
                        const alreadyKnown = sDef.studyRecipeId
                          ? state.run.learnedRecipeIds.includes(sDef.studyRecipeId)
                          : true;
                        const depleted =
                          sDef.maxCharges !== undefined &&
                          (spec.charges ?? 0) < (sDef.studyRequiresMinCharges ?? 1);
                        return (
                          <div
                            key={spec.instanceId}
                            className="flex items-center justify-between bg-slate-900 border border-purple-800/50 rounded p-1.5"
                          >
                            <div className="flex items-center gap-1.5">
                              <PixelIcon sprite={sDef.sprite} size={18} />
                              <div>
                                <div className="font-medium">{sDef.name}</div>
                                <div className="text-[9px] text-slate-400">
                                  {spec.charges !== undefined ? `${spec.charges} charges left • ` : ''}
                                  {alreadyKnown
                                    ? 'Already learned'
                                    : depleted
                                      ? 'Depleted (0 charges)'
                                      : `Unlocks ${RECIPES[sDef.studyRecipeId!]?.name}`}
                                </div>
                              </div>
                            </div>
                            <button
                              disabled={!desk || alreadyKnown || depleted}
                              onClick={() =>
                                desk &&
                                onDispatch({
                                  intentId: makeIntentId('res_spec'),
                                  kind: 'START_RESEARCH',
                                  stationId: desk.id,
                                  mode: 'specimen',
                                  specimenInstanceId: spec.instanceId,
                                })
                              }
                              className="px-2 py-1 rounded bg-purple-600 hover:bg-purple-500 disabled:opacity-35 text-white font-bold text-[10px]"
                            >
                              Analyze
                            </button>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Directed Spares Research */}
                  <div className="space-y-1">
                    <div className="text-[10px] font-semibold text-slate-400">
                      DIRECTED SPARES SCHEMATICS ({unknownDirected.length} remaining)
                    </div>
                    {unknownDirected.map((rec) => (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between bg-slate-900/75 border border-slate-800 rounded p-1.5"
                      >
                        <div>
                          <div className="font-medium">{rec.name}</div>
                          <div className="text-[9px] text-slate-400">
                            Cost: {rec.directedSparesCost} Technical Spares
                          </div>
                        </div>
                        <button
                          disabled={!desk || sparesHeld < (rec.directedSparesCost ?? 99)}
                          onClick={() =>
                            desk &&
                            onDispatch({
                              intentId: makeIntentId('res_dir'),
                              kind: 'START_RESEARCH',
                              stationId: desk.id,
                              mode: 'directed_spares',
                              targetRecipeId: rec.id,
                            })
                          }
                          className="px-2 py-0.5 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-35 text-slate-950 font-bold text-[10px]"
                        >
                          Study ({rec.directedSparesCost})
                        </button>
                      </div>
                    ))}
                  </div>
                </>
              );
            })()}
          </>
        )}

        {/* ==================== ISLAND MAP & ROUTES ==================== */}
        {activePanel === 'map' && (
          <div className="space-y-2">
            <MinimapCanvas state={state} />
            <div className="bg-slate-900 border border-slate-800 rounded p-2 text-[10px] space-y-1">
              <div className="flex justify-between">
                <span>Position: ({ptx}, {pty})</span>
                <span className="capitalize">
                  Surface: <b>{getEffectiveSurface(state, ptx, pty).replace('_', ' ')}</b>
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1 text-[9px] text-slate-300 pt-1">
                <span>⬜🔴 Adventurer</span>
                <span>🟨 Vendor / Escrow</span>
                <span>🟧 Layered POIs</span>
                <span>🟦 Evacuation Dock</span>
                <span>🟩 Home Claim</span>
                <span>🟥 Death Bag</span>
              </div>
              <div className="text-[9px] text-slate-400 border-t border-slate-800 pt-1">
                <b>Freight & Trace Law:</b> Roads give 1.18× speed & fast trace fade (8m); Marsh
                slows to 0.64× & holds footprints 40m. Rain erases trails 3.2× faster.
              </div>
            </div>
          </div>
        )}

        {/* ==================== CONTEXT JOURNAL & RECEIPT LEDGER ==================== */}
        {activePanel === 'journal' && (
          <div className="space-y-2">
            <div className="bg-slate-900 border border-slate-800 rounded p-2 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-300">
                  Provisional Run Score: {computeRunUnverifiedScore(state)}
                </span>
                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[8px] font-mono text-amber-200">
                  {state.run.qaClockUsed ? 'QA_ACCELERATED_UNVERIFIED' : 'LOCAL_UNVERIFIED'}
                </span>
              </div>
              <p className="text-[9px] text-slate-400">
                Scores derive only from unique milestones & never convert into cash. No fake online
                leaderboard is claimed without a verified server backend.
              </p>
            </div>

            {/* Six Optional Elder Stones */}
            <div className="bg-slate-900/80 border border-slate-800 rounded p-2">
              <div className="text-[10px] font-semibold text-purple-300 mb-1">
                OPTIONAL ELDER STONES ({state.run.collectedElderStones.length} / 6)
              </div>
              <div className="grid grid-cols-2 gap-1">
                {BOSSES_LIST.map((b) => {
                  const has = state.run.collectedElderStones.includes(b.stoneItemId);
                  return (
                    <div
                      key={b.id}
                      className={`flex items-center gap-1 p-1 rounded border text-[9px] ${
                        has
                          ? 'border-amber-500 bg-amber-950/40 text-amber-200'
                          : 'border-slate-800 text-slate-500'
                      }`}
                    >
                      <PixelIcon sprite={b.stoneItemId} size={14} />
                      <span className="truncate">{b.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Optional Non-Gating Contextual Notes */}
            <div className="bg-slate-900/80 border border-slate-800 rounded p-2 space-y-1">
              <div className="text-[10px] font-semibold text-emerald-300">
                CONTEXTUAL WORLD NOTES (OPTIONAL, OUT-OF-ORDER)
              </div>
              {[
                ['hint_natural_harvest', 'Natural timber, stone & springs sustain off-road camps.'],
                ['hint_road_salvage', 'Roadside barrels yield Scrap & Spares for knife-first runs.'],
                ['hint_first_research', 'Research Desk unlocks mid-tier tools, carts & Core synthesis.'],
                ['hint_home_claim', 'Territory Claim Cabinet authorizes placing Rương ký gửi.'],
              ].map(([hKey, label]) => {
                const proof = state.optionalHintsRecognized[hKey];
                return (
                  <div key={hKey} className="text-[9px] flex items-start gap-1">
                    <span className={proof ? 'text-emerald-400' : 'text-slate-500'}>
                      {proof ? '✓' : '○'}
                    </span>
                    <span className={proof ? 'text-slate-200' : 'text-slate-400'}>
                      {label} {proof ? `(${proof})` : ''}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Immutable Event Receipts Stream */}
            <div className="space-y-1">
              <div className="text-[10px] font-semibold text-slate-400">
                ATOMIC EVENT RECEIPTS ({state.eventReceipts.length})
              </div>
              <div className="space-y-1 max-h-40 overflow-y-auto">
                {[...state.eventReceipts].reverse().slice(0, 18).map((r) => (
                  <div
                    key={r.receiptId}
                    className="bg-slate-950 border border-slate-800/80 rounded p-1 text-[9px]"
                  >
                    <div className="flex justify-between text-amber-400/90 font-mono">
                      <span>[{r.contractEdge}]</span>
                      <span>r{r.revision} • {r.elapsedSec}s</span>
                    </div>
                    <div className="text-slate-300">{r.summary}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ==================== SKILL DRIVERS & REMAPPABLE CONTROLS ==================== */}
        {activePanel === 'skills' && (
          <div className="space-y-2">
            {(() => {
              const hand = getEquippedItem(state, 'hand');
              const hDef = hand ? ITEMS[hand.defId] : null;
              const sk = SKILLS[hDef?.weaponProfile?.skillId ?? 'basic_slash'];
              return (
                <div className="bg-slate-900 border border-amber-700/50 rounded p-2 space-y-1">
                  <div className="font-bold text-amber-300">
                    Active Driver: {sk?.name ?? 'Unarmed'} ({hDef?.name ?? 'Bare Hands'})
                  </div>
                  <div className="text-[9px] text-slate-300">
                    Windup: {sk?.windupMs}ms → Commit: {sk?.commitMs}ms → Recovery: {sk?.recoveryMs}ms
                  </div>
                  <div className="text-[9px] text-slate-300">
                    Actor Damage: {hDef?.weaponProfile?.actorDamage ?? 4} | Range:{' '}
                    {hDef?.weaponProfile?.rangePx ?? 22}px
                  </div>
                  {hDef?.harvestProfile && (
                    <div className="text-[9px] text-emerald-300">
                      Harvest Multipliers:{' '}
                      {Object.entries(hDef.harvestProfile)
                        .map(([k, v]) => `${k}:${v}x`)
                        .join(' ')}
                    </div>
                  )}
                  <div className="text-[8px] text-amber-400/80 font-mono">
                    VFX Status: {sk?.goldArtStatus} (Replaceable prototype driver; charges debit at
                    commitMs only)
                  </div>
                  {p.activeCast && !p.activeCast.committed && (
                    <button
                      onClick={() =>
                        onDispatch({
                          intentId: makeIntentId('cancel_cast'),
                          kind: 'CANCEL_ACTIVE_CAST',
                        })
                      }
                      className="w-full py-1 rounded bg-rose-700 text-white font-bold text-[10px]"
                    >
                      Cancel Active Windup (0 Charges Spent)
                    </button>
                  )}
                </div>
              );
            })()}

            {/* Remappable Keybindings */}
            <div className="bg-slate-900/80 border border-slate-800 rounded p-2 space-y-1">
              <div className="text-[10px] font-semibold text-slate-300">
                REMAPPABLE KEYBINDINGS (Click to rebind)
              </div>
              {(Object.keys(keyBindings) as (keyof KeyBindings)[]).map((action) => (
                <div key={action} className="flex items-center justify-between text-[10px]">
                  <span className="capitalize text-slate-300">{action}</span>
                  <button
                    onClick={() => setRebindingKey(action)}
                    onKeyDown={(e) => {
                      if (rebindingKey === action) {
                        e.preventDefault();
                        e.stopPropagation();
                        onUpdateKeyBinding(action, e.key.toLowerCase());
                        setRebindingKey(null);
                      }
                    }}
                    className={`px-2 py-0.5 rounded font-mono uppercase ${
                      rebindingKey === action
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-amber-300'
                    }`}
                  >
                    {rebindingKey === action ? 'Press Key...' : keyBindings[action]}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== MENU, SHELTER LOGOUT PREP & DEV QA ==================== */}
        {activePanel === 'menu' && (
          <div className="space-y-2">
            {/* Optional Non-Omniscient Logout Preparation Assessment (C09) */}
            <div className="bg-slate-900 border border-slate-800 rounded p-2 space-y-1">
              <div className="font-bold text-amber-300">
                Optional Shelter & Offline Preparation View
              </div>
              <div className="text-[10px] space-y-0.5 text-slate-300">
                <div>
                  • Shelter Roof/Floor:{' '}
                  <b className={isPlayerSheltered(state) ? 'text-emerald-400' : 'text-amber-400'}>
                    {isPlayerSheltered(state)
                      ? 'PROTECTED (1-HP offline hunger floor active)'
                      : 'EXPOSED OUTDOORS'}
                  </b>
                </div>
                <div>
                  • Local Grid Power:{' '}
                  <b>{isTilePowered(state, ptx, pty) ? 'ENERGIZED' : 'UNPOWERED'}</b>
                </div>
                <div>
                  • Current Weather: <b className="capitalize">{state.clock.weather.replace('_', ' ')}</b>{' '}
                  (Barometer change in ~{Math.max(1, Math.round((state.clock.nextWeatherFrontSec - state.clock.elapsedRealSeconds) / 60))}m)
                </div>
                <div>
                  • Visible Nearby Footprints:{' '}
                  <b>
                    {
                      state.footprints.filter(
                        (f) => Math.hypot(f.tileX - ptx, f.tileY - pty) <= 12
                      ).length
                    }{' '}
                    active segments
                  </b>
                </div>
              </div>
              <p className="text-[8px] text-slate-400">
                Non-omniscient barometer [PROPOSED_MECHANISM]: never reveals unseen creatures. Cold,
                fire & radiation remain lethal offline. Quit is always immediate.
              </p>
              <div className="grid grid-cols-2 gap-1.5 pt-1">
                <button
                  onClick={onManualSave}
                  className="py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-[10px]"
                >
                  Save Snapshot Now
                </button>
                <button
                  onClick={onReturnToTitle}
                  className="py-1 rounded bg-slate-700 hover:bg-slate-600 text-white font-semibold text-[10px]"
                >
                  Save & Exit to Title
                </button>
              </div>
            </div>

            {/* Voluntary Run Abandonment */}
            <div className="bg-rose-950/30 border border-rose-800/60 rounded p-2 space-y-1">
              <div className="font-semibold text-rose-300">Voluntary Run Abandonment</div>
              <p className="text-[9px] text-slate-400">
                Ends current run immediately and wipes all run-local items, recipes, structures &
                unsecured cash. Secured Profile Cash ({state.profile.securedRagnarokCash}) persists.
              </p>
              {!confirmAbandon ? (
                <button
                  onClick={() => setConfirmAbandon(true)}
                  className="w-full py-1 rounded bg-rose-900 hover:bg-rose-800 text-rose-100 text-[10px]"
                >
                  Abandon Active Run...
                </button>
              ) : (
                <div className="flex gap-1">
                  <button
                    onClick={() => {
                      onDispatch({ intentId: makeIntentId('abandon'), kind: 'ABANDON_RUN' });
                      setConfirmAbandon(false);
                    }}
                    className="flex-1 py-1 rounded bg-rose-600 text-white font-bold text-[10px]"
                  >
                    Confirm Wipe & End Run
                  </button>
                  <button
                    onClick={() => setConfirmAbandon(false)}
                    className="px-2 py-1 rounded bg-slate-800 text-[10px]"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>

            {/* Dev / QA Accelerated Clock & Balance Inspector */}
            <div className="bg-slate-900/70 border border-slate-800 rounded p-2 space-y-1.5">
              <button
                onClick={() => setShowDevQa((v) => !v)}
                className="w-full flex items-center justify-between text-[10px] font-mono text-amber-400"
              >
                <span>[DEV / QA] Balance & Accelerated Clock</span>
                <span>{showDevQa ? '▲' : '▼'}</span>
              </button>
              {showDevQa && (
                <div className="space-y-1.5 pt-1 border-t border-slate-800">
                  <div className="text-[8px] text-amber-300/90">
                    Using QA clock permanently marks run <code>QA_ACCELERATED_UNVERIFIED</code>.
                  </div>
                  <div className="grid grid-cols-2 gap-1">
                    <button
                      onClick={() => onSimulateOfflineHours(2)}
                      className="py-1 px-1.5 rounded bg-slate-800 hover:bg-slate-700 text-[9px]"
                    >
                      Replay +2h Offline
                    </button>
                    <button
                      onClick={() =>
                        onDispatch({
                          intentId: makeIntentId('qa_24h'),
                          kind: 'QA_ADVANCE_CLOCK',
                          advanceSeconds: 24 * 3600,
                        })
                      }
                      className="py-1 px-1.5 rounded bg-slate-800 hover:bg-slate-700 text-[9px]"
                    >
                      +24h Run Clock
                    </button>
                    <button
                      onClick={() => {
                        const needed = Math.max(
                          60,
                          BALANCE.clock.hazardIntensifyStartSeconds.value -
                            state.clock.elapsedRealSeconds +
                            60
                        );
                        onDispatch({
                          intentId: makeIntentId('qa_f72'),
                          kind: 'QA_ADVANCE_CLOCK',
                          advanceSeconds: needed,
                        });
                      }}
                      className="py-1 px-1.5 rounded bg-amber-900/70 hover:bg-amber-800 text-amber-200 text-[9px]"
                    >
                      Jump to Final 72h (264h)
                    </button>
                    <button
                      onClick={() => {
                        const needed = Math.max(
                          60,
                          BALANCE.clock.elderAwakenStartSeconds.value -
                            state.clock.elapsedRealSeconds +
                            60
                        );
                        onDispatch({
                          intentId: makeIntentId('qa_d14'),
                          kind: 'QA_ADVANCE_CLOCK',
                          advanceSeconds: needed,
                        });
                      }}
                      className="py-1 px-1.5 rounded bg-purple-900/70 hover:bg-purple-800 text-purple-200 text-[9px]"
                    >
                      Jump to Day 14 (312h)
                    </button>
                  </div>
                  <div className="text-[8px] font-mono text-slate-400 bg-slate-950 p-1 rounded max-h-24 overflow-y-auto">
                    <div>maxRun: {BALANCE.clock.maxRunRealSeconds.value}s [LOCKED_CANON]</div>
                    <div>final72: {BALANCE.clock.ragnarokFinalSeconds.value}s [LOCKED_CANON]</div>
                    <div>escrowPrice: {BALANCE.ragnarokEconomy.escrowChestVendorCashPrice.value} [PROPOSED]</div>
                    <div>hunger/h: {BALANCE.player.hungerDrainPerRealHour.value} [TUNING]</div>
                    <div>thirst/h: {BALANCE.player.thirstDrainPerRealHour.value} [TUNING]</div>
                    <div>claimRad: {BALANCE.territoryAndBuild.claimRadiusTiles.value} tiles [PROPOSED]</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
