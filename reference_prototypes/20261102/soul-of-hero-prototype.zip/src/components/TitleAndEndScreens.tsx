import React, { useState } from 'react';
import type { GameState, ProfileState, SpawnRegion } from '../sim/types';
import { getBaseIslandTopology } from '../sim/worldGen';
import { PixelIcon } from './PixelIcon';

interface TitleScreenProps {
  profile: ProfileState;
  savedRun: GameState | null;
  worldSeed: number;
  onStartNewRun: (gender: 'male' | 'female', spawnRegionId: string) => void;
  onResumeRun: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  profile,
  savedRun,
  worldSeed,
  onStartNewRun,
  onResumeRun,
}) => {
  const topo = getBaseIslandTopology(worldSeed);
  const [gender, setGender] = useState<'male' | 'female'>('female');
  const [spawnId, setSpawnId] = useState<string>(topo.spawnRegions[0].id);
  const [tab, setTab] = useState<'launch' | 'history'>('launch');

  return (
    <div
      data-testid="title-screen"
      className="absolute inset-0 bg-slate-950/92 flex flex-col justify-between p-2.5 sm:p-4 text-slate-100 z-30 overflow-y-auto"
    >
      {/* Top Banner */}
      <div className="flex items-center justify-between border-b border-amber-700/50 pb-1.5">
        <div>
          <h1 className="text-sm sm:text-lg font-extrabold tracking-wider text-amber-300 uppercase">
            Soul of Hero: World Simulation
          </h1>
          <p className="text-[9px] sm:text-[11px] text-slate-400">
            Solo PvE Top-Down Survival RPG • Persistent Island Seed #{worldSeed} • 336h UTC Run Clock
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-amber-950/60 border border-amber-500/60 rounded px-2 py-0.5 text-right">
            <div className="text-[8px] uppercase text-amber-300">Profile Secured Cash</div>
            <div className="text-xs sm:text-sm font-bold font-mono text-amber-200">
              {profile.securedRagnarokCash}
            </div>
          </div>
          <button
            onClick={() => setTab(tab === 'launch' ? 'history' : 'launch')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 border border-slate-600 text-[10px] sm:text-xs font-semibold"
          >
            {tab === 'launch' ? `History (${profile.runHistory.length})` : '← Expedition Setup'}
          </button>
        </div>
      </div>

      {tab === 'launch' ? (
        <div className="grid grid-cols-12 gap-2 my-auto py-1.5">
          {/* Left: Adventurer Selection */}
          <div className="col-span-5 bg-slate-900/90 border border-slate-800 rounded p-2 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-bold text-amber-300 uppercase mb-1.5">
                1. Choose Adventurer
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {(['female', 'male'] as const).map((g) => (
                  <button
                    key={g}
                    data-testid={`select-gender-${g}`}
                    onClick={() => setGender(g)}
                    className={`p-1.5 rounded border flex flex-col items-center gap-1 ${
                      gender === g
                        ? 'border-amber-400 bg-amber-950/50 text-amber-200'
                        : 'border-slate-800 bg-slate-950/70 text-slate-400'
                    }`}
                  >
                    <PixelIcon
                      sprite={g === 'male' ? 'adventurer_male' : 'adventurer_female'}
                      size={28}
                    />
                    <span className="text-[10px] font-bold capitalize">{g}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-2 text-[9px] text-slate-400 leading-snug bg-slate-950/70 p-1.5 rounded border border-slate-800/80">
              <b>Author Your Own Story:</b> No forced quest corridor, Core modal, or mandatory Elder.
              Survive with a humble knife, salvage roads, build anywhere eligible, or secure Final-72
              Ragnarok Vault cash via <i>Rương ký gửi</i>.
            </div>
          </div>

          {/* Right: 4 Safe Starting Regions */}
          <div className="col-span-7 bg-slate-900/90 border border-slate-800 rounded p-2 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-bold text-amber-300 uppercase mb-1">
                2. Select Safe Landing Region (4 Verified Starts)
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {topo.spawnRegions.map((sp: SpawnRegion) => (
                  <button
                    key={sp.id}
                    data-testid={`select-spawn-${sp.id}`}
                    onClick={() => setSpawnId(sp.id)}
                    className={`text-left p-1.5 rounded border ${
                      spawnId === sp.id
                        ? 'border-emerald-400 bg-emerald-950/40'
                        : 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-[10px] font-bold text-emerald-300 truncate">{sp.name}</div>
                    <div className="text-[8px] sm:text-[9px] text-slate-400 line-clamp-2 leading-tight">
                      {sp.description}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2 mt-2">
              {savedRun && savedRun.run.status === 'active' && (
                <button
                  data-testid="resume-run-btn"
                  onClick={onResumeRun}
                  className="flex-1 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-[11px] sm:text-xs"
                >
                  Resume Run #{savedRun.run.runNumber} (Day {savedRun.clock.fictionalDay})
                </button>
              )}
              <button
                data-testid="start-new-run-btn"
                onClick={() => onStartNewRun(gender, spawnId)}
                className="flex-1 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-[11px] sm:text-xs"
              >
                {savedRun && savedRun.run.status === 'active'
                  ? 'Start Fresh Run (Wipes Active Run)'
                  : `Begin Run #${profile.runHistory.length + 1}`}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Run History & Honest Local/Unverified Score Ledger */
        <div
          data-testid="history-panel"
          className="flex-1 my-2 bg-slate-900/90 border border-slate-800 rounded p-2 overflow-y-auto space-y-1.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300">
              EXPEDITION HISTORY & LOCAL/UNVERIFIED SCORE ARCHIVE
            </span>
            <span className="text-[9px] text-slate-400">
              Achievements: {profile.achievements.length}
            </span>
          </div>
          {profile.runHistory.length === 0 ? (
            <div className="text-[11px] text-slate-400 py-8 text-center">
              No finalized runs recorded yet. Evacuate, expire at 336h, or abandon a run to archive
              its history.
            </div>
          ) : (
            [...profile.runHistory].reverse().map((h) => (
              <div
                key={h.runId}
                className="bg-slate-950 border border-slate-800 rounded p-2 flex items-center justify-between text-[10px]"
              >
                <div>
                  <div className="font-bold text-amber-200">
                    Run #{h.runNumber} • {h.outcome.replace(/_/g, ' ').toUpperCase()} ({h.adventurerGender})
                  </div>
                  <div className="text-[9px] text-slate-400">
                    Spawn: {h.spawnRegionId} • Elapsed: {(h.elapsedRealSeconds / 3600).toFixed(1)}h •
                    Elder Stones: {h.elderStonesCollected.length}/6
                  </div>
                  <div className="text-[9px] text-emerald-300">
                    Secured Deposit: +{h.cashDepositedThisRun} | Unsecured Cash Wiped:{' '}
                    {h.cashLostUnsecured}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold font-mono text-amber-300">
                    {h.unverifiedLocalScore} pts
                  </div>
                  <div className="text-[8px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                    {h.verificationStatus}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Footer Controls Hint */}
      <div className="text-[9px] sm:text-[10px] text-slate-400 flex items-center justify-between border-t border-slate-800 pt-1">
        <span>
          Controls: <b>WASD/Arrows</b> Move • <b>Shift</b> Sprint • <b>Click</b> Swing/Cast •{' '}
          <b>E</b> Interact • <b>1–8</b> Quickbar
        </span>
        <span>
          <b>I</b> Bag • <b>C</b> Craft • <b>B</b> Build • <b>R</b> Study • <b>M</b> Map • <b>J</b>{' '}
          Journal • <b>Esc</b> Menu
        </span>
      </div>
    </div>
  );
};

export const RunFinalizedModal: React.FC<{
  state: GameState;
  onStartNextRunSetup: () => void;
}> = ({ state, onStartNextRunSetup }) => {
  const latest = state.profile.runHistory[state.profile.runHistory.length - 1];
  return (
    <div
      data-testid="run-finalized-modal"
      className="absolute inset-0 bg-slate-950/90 flex items-center justify-center p-3 z-30"
    >
      <div className="max-w-md w-full bg-slate-900 border-2 border-amber-500 rounded-lg p-3 space-y-2 text-slate-100 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
          <h2 className="text-sm font-extrabold text-amber-300 uppercase">
            Run #{state.run.runNumber} Finalized:{' '}
            {state.run.status.replace(/_/g, ' ').toUpperCase()}
          </h2>
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 font-mono text-amber-200">
            {latest?.verificationStatus ?? 'LOCAL_UNVERIFIED'}
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-[11px]">
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <div className="text-[9px] text-slate-400">Secured Cash (Persists to Run 2+)</div>
            <div className="text-sm font-bold text-emerald-400 font-mono">
              {state.profile.securedRagnarokCash}
            </div>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <div className="text-[9px] text-slate-400">Provisional Run Score</div>
            <div className="text-sm font-bold text-amber-300 font-mono">
              {latest?.unverifiedLocalScore ?? 0} pts
            </div>
          </div>
        </div>
        <p className="text-[10px] text-slate-300 leading-snug">
          All run-local items, Cores, learned recipes, houses, stations, vehicles, Death Bags, POI
          unlocks, and unsecured physical cash ({latest?.cashLostUnsecured ?? 0}) are wiped for the
          next run. Only Secured Profile Cash, achievements, and run history carry forward.
        </p>
        <button
          data-testid="proceed-next-run-btn"
          onClick={onStartNextRunSetup}
          className="w-full py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs"
        >
          Proceed to Run #{state.run.runNumber + 1} Landing Setup →
        </button>
      </div>
    </div>
  );
};
