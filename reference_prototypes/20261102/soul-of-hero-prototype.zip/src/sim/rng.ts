import {
  xoroshiro128plus,
  xoroshiro128plusFromState,
} from 'pure-rand/generator/xoroshiro128plus';
import { uniformInt } from 'pure-rand/distribution/uniformInt';
import type { RandomGenerator } from 'pure-rand/types/RandomGenerator';

export interface SimRng {
  gen: RandomGenerator;
}

export function createSeededRng(seed: number): SimRng {
  return { gen: xoroshiro128plus(seed) };
}

export function restoreRng(stateWords: number[]): SimRng {
  if (stateWords.length >= 4) {
    return { gen: xoroshiro128plusFromState(stateWords) };
  }
  return createSeededRng(stateWords[0] ?? 133742);
}

export function serializeRng(rng: SimRng): number[] {
  const st = rng.gen.getState?.();
  return st ? Array.from(st) : [133742];
}

export function nextInt(rng: SimRng, minInclusive: number, maxInclusive: number): number {
  return uniformInt(rng.gen, minInclusive, maxInclusive);
}

export function nextFloat01(rng: SimRng): number {
  return uniformInt(rng.gen, 0, 1_000_000) / 1_000_000;
}

export function nextDeterministicId(
  prefix: string,
  runId: string,
  revision: number,
  subIndex = 0
): string {
  return `${prefix}_${runId}_r${revision}_${subIndex}`;
}
