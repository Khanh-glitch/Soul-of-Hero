import * as ROT from 'rot-js';
import { BALANCE, SOURCES, STRUCTURES } from './catalogs';
import { getBaseIslandTopology } from './worldGen';
import type { GameState, StructureInstance, SurfaceType } from './types';

export function getEffectiveSurface(state: GameState, tileX: number, tileY: number): SurfaceType {
  const topo = getBaseIslandTopology(state.world.seed);
  if (tileX < 0 || tileY < 0 || tileX >= topo.width || tileY >= topo.height) {
    return 'deep_water';
  }
  // Check active terrain mutations (e.g., frozen water -> walkable ice, scorched -> ash)
  const effect = state.terrainEffects[`${tileX},${tileY}`];
  if (effect && effect.endSec > state.clock.elapsedRealSeconds) {
    if (effect.type === 'ice') return 'ice';
    if (effect.type === 'scorch') return 'ash';
    if (effect.type === 'toxic_pool') return 'toxic';
  }
  return topo.surfaces[tileY * topo.width + tileX];
}

export function getStructuresAtTile(
  state: GameState,
  tileX: number,
  tileY: number
): StructureInstance[] {
  const res: StructureInstance[] = [];
  for (const st of Object.values(state.structures)) {
    if (st.tileX === tileX && st.tileY === tileY && st.hp > 0) {
      res.push(st);
    }
  }
  return res;
}

export function isTileWalkable(
  state: GameState,
  tileX: number,
  tileY: number,
  options?: { forCart?: boolean; ignoreStructures?: boolean }
): boolean {
  const topo = getBaseIslandTopology(state.world.seed);
  if (tileX < 1 || tileY < 1 || tileX >= topo.width - 1 || tileY >= topo.height - 1) {
    return false;
  }
  const surf = getEffectiveSurface(state, tileX, tileY);
  if (surf === 'deep_water' || surf === 'mountain_rock') {
    return false;
  }
  if (options?.forCart && surf === 'shallow_water') {
    return false;
  }

  if (!options?.ignoreStructures) {
    for (const st of Object.values(state.structures)) {
      if (st.tileX === tileX && st.tileY === tileY && st.hp > 0) {
        const def = STRUCTURES[st.defId];
        if (!def) continue;
        if (def.isDoor) {
          if (!st.isOpen) return false;
          // Single cabin doors are too narrow for loaded hand-cart unless blast door
          if (options?.forCart && st.defId === 'wood_door') return false;
        } else if (def.blocksMovement) {
          return false;
        }
      }
    }
  }

  for (const src of Object.values(state.sourceStocks)) {
    if (src.tileX === tileX && src.tileY === tileY && src.stock > 0) {
      const def = SOURCES[src.defId];
      if (def?.blocksMovement) return false;
    }
  }

  return true;
}

export function doesTilePassLight(state: GameState, tileX: number, tileY: number): boolean {
  const topo = getBaseIslandTopology(state.world.seed);
  if (tileX < 0 || tileY < 0 || tileX >= topo.width || tileY >= topo.height) {
    return false;
  }
  const surf = getEffectiveSurface(state, tileX, tileY);
  if (surf === 'mountain_rock') return false;

  for (const st of Object.values(state.structures)) {
    if (st.tileX === tileX && st.tileY === tileY && st.hp > 0) {
      const def = STRUCTURES[st.defId];
      if (!def) continue;
      if (def.isDoor) {
        if (!st.isOpen) return false;
      } else if (def.blocksSight) {
        return false;
      }
    }
  }
  return true;
}

/**
 * Computes true line-of-sight tile visibility set using rot-js PreciseShadowcasting.
 */
export function computeVisibleTileSet(
  state: GameState,
  originTileX: number,
  originTileY: number,
  radiusTiles: number
): Set<string> {
  const visible = new Set<string>();
  const fov = new ROT.FOV.PreciseShadowcasting((x, y) => {
    if (x === originTileX && y === originTileY) return true;
    return doesTilePassLight(state, x, y);
  });
  fov.compute(originTileX, originTileY, Math.ceil(radiusTiles), (x, y, _r, vis) => {
    if (vis > 0) {
      visible.add(`${x},${y}`);
    }
  });
  return visible;
}

/**
 * Checks true line-of-sight between two world pixel coordinates.
 */
export function hasLineOfSight(
  state: GameState,
  x0Px: number,
  y0Px: number,
  x1Px: number,
  y1Px: number,
  maxRangePx: number
): boolean {
  const d = Math.hypot(x1Px - x0Px, y1Px - y0Px);
  if (d > maxRangePx) return false;
  const tx0 = Math.floor(x0Px / 16);
  const ty0 = Math.floor(y0Px / 16);
  const tx1 = Math.floor(x1Px / 16);
  const ty1 = Math.floor(y1Px / 16);
  if (tx0 === tx1 && ty0 === ty1) return true;
  const vis = computeVisibleTileSet(state, tx0, ty0, Math.ceil(maxRangePx / 16) + 1);
  return vis.has(`${tx1},${ty1}`);
}

/**
 * Uses rot-js A* pathfinder to compute a legal tile path respecting walls, doors, water, and cart rules.
 */
export function findPathTiles(
  state: GameState,
  startTileX: number,
  startTileY: number,
  goalTileX: number,
  goalTileY: number,
  options?: { forCart?: boolean; maxExpanded?: number }
): { x: number; y: number }[] | null {
  const maxExpanded = options?.maxExpanded ?? 1400;
  let expanded = 0;

  const astar = new ROT.Path.AStar(
    goalTileX,
    goalTileY,
    (x, y) => {
      if (x === startTileX && y === startTileY) return true;
      if (x === goalTileX && y === goalTileY) return true;
      if (++expanded > maxExpanded) return false;
      return isTileWalkable(state, x, y, { forCart: options?.forCart });
    },
    { topology: 4 }
  );

  const path: { x: number; y: number }[] = [];
  astar.compute(startTileX, startTileY, (x, y) => {
    path.push({ x, y });
  });

  if (path.length === 0) return null;
  const last = path[path.length - 1];
  if (last.x !== goalTileX || last.y !== goalTileY) return null;
  return path;
}

export function isTileInPlayerOwnedTerritory(
  state: GameState,
  tileX: number,
  tileY: number
): boolean {
  const radius = BALANCE.territoryAndBuild.claimRadiusTiles.value;
  for (const st of Object.values(state.structures)) {
    if (st.ownerId === 'player' && st.hp > 0 && STRUCTURES[st.defId]?.isTerritoryClaim) {
      if (Math.max(Math.abs(st.tileX - tileX), Math.abs(st.tileY - tileY)) <= radius) {
        return true;
      }
    }
  }
  return false;
}

export function isTilePowered(state: GameState, tileX: number, tileY: number): boolean {
  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0) continue;
    const def = STRUCTURES[st.defId];
    if (!def?.powerSupplyWatts || !def.powerRadiusTiles) continue;
    const active = def.usesFuel ? st.fuelRemainingSec > 0 : true;
    if (!active) continue;
    if (Math.hypot(st.tileX - tileX, st.tileY - tileY) <= def.powerRadiusTiles) {
      return true;
    }
  }
  if (
    state.structures &&
    Object.values(state.structures).some(
      (st) =>
        st.tileX === tileX &&
        st.tileY === tileY &&
        (st.energizedUntilSec ?? 0) > state.clock.elapsedRealSeconds
    )
  ) {
    return true;
  }
  return false;
}

export function isPlayerSheltered(state: GameState): boolean {
  const tx = Math.floor(state.actors.player.x / 16);
  const ty = Math.floor(state.actors.player.y / 16);
  const here = getStructuresAtTile(state, tx, ty);
  const hasRoof = here.some((s) => STRUCTURES[s.defId]?.isRoof);
  const hasFloorOrBed = here.some(
    (s) => STRUCTURES[s.defId]?.isFloor || STRUCTURES[s.defId]?.isBed
  );
  if (hasRoof && hasFloorOrBed) return true;
  // Also sheltered if adjacent to player bed under a roof within 1 tile
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const adj = getStructuresAtTile(state, tx + dx, ty + dy);
      if (adj.some((s) => STRUCTURES[s.defId]?.isRoof) && here.some((s) => STRUCTURES[s.defId]?.isRoof)) {
        return true;
      }
    }
  }
  return false;
}
