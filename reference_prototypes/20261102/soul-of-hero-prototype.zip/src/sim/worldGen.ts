import { createNoise2D } from 'simplex-noise';
import {
  BALANCE,
  BOSSES_LIST,
  ENEMIES_LIST,
  ITEMS,
  POIS,
  RECIPES_LIST,
  SOURCES,
} from './catalogs';
import { createSeededRng, nextFloat01, nextInt, serializeRng } from './rng';
import type {
  ElderActor,
  EnemyActor,
  GameState,
  ProfileState,
  SourceNodeInstance,
  SpawnRegion,
  StructureInstance,
  SurfaceType,
  WorldPoiInstance,
} from './types';

export interface BaseIslandTopology {
  seed: number;
  width: number;
  height: number;
  surfaces: SurfaceType[]; // length = width * height
  elevation: Float32Array;
  moisture: Float32Array;
  temperature: Float32Array;
  spawnRegions: SpawnRegion[];
  poiBlueprints: {
    defId: string;
    centerX: number;
    centerY: number;
    widthTiles: number;
    heightTiles: number;
  }[];
  elderSites: {
    bossDefId: string;
    tileX: number;
    tileY: number;
  }[];
}

const topologyCache = new Map<number, BaseIslandTopology>();

function dist(x0: number, y0: number, x1: number, y1: number): number {
  return Math.hypot(x1 - x0, y1 - y0);
}

function carveRoadLine(
  surfaces: SurfaceType[],
  width: number,
  height: number,
  x0: number,
  y0: number,
  x1: number,
  y1: number
): void {
  const steps = Math.ceil(dist(x0, y0, x1, y1) * 1.5);
  for (let i = 0; i <= steps; i++) {
    const t = steps === 0 ? 0 : i / steps;
    const wobble = Math.sin(t * Math.PI * 3) * 1.4;
    const cx = Math.round(x0 + (x1 - x0) * t + wobble);
    const cy = Math.round(y0 + (y1 - y0) * t - wobble * 0.5);
    for (let oy = -1; oy <= 0; oy++) {
      for (let ox = -1; ox <= 0; ox++) {
        const tx = cx + ox;
        const ty = cy + oy;
        if (tx >= 4 && ty >= 4 && tx < width - 4 && ty < height - 4) {
          const idx = ty * width + tx;
          const cur = surfaces[idx];
          if (cur !== 'deep_water') {
            surfaces[idx] = 'road';
          }
        }
      }
    }
  }
}

export function getBaseIslandTopology(seed: number): BaseIslandTopology {
  const cached = topologyCache.get(seed);
  if (cached) return cached;

  const width = BALANCE.world.widthTiles.value;
  const height = BALANCE.world.heightTiles.value;
  const rng = createSeededRng(seed);
  const elevNoise = createNoise2D(() => nextFloat01(rng));
  const moistNoise = createNoise2D(() => nextFloat01(rng));
  const tempNoise = createNoise2D(() => nextFloat01(rng));

  const surfaces = new Array<SurfaceType>(width * height).fill('deep_water');
  const elevation = new Float32Array(width * height);
  const moisture = new Float32Array(width * height);
  const temperature = new Float32Array(width * height);

  const cx = width * 0.5;
  const cy = height * 0.5;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      const nx = (x - cx) / (width * 0.46);
      const ny = (y - cy) / (height * 0.46);
      const radial = Math.hypot(nx, ny);

      let e =
        0.58 +
        0.28 * elevNoise(x * 0.025, y * 0.025) +
        0.14 * elevNoise(x * 0.06, y * 0.06) +
        0.06 * elevNoise(x * 0.14, y * 0.14) -
        Math.pow(radial, 2.05) * 0.72;

      // Eastern Sea Gulf & Isthmus bridge:
      // Carve two sea bays north and south of y=96 at x in [120..152], leaving an isthmus at y in [93..99]!
      const inNorthGulf = dist(x, y, 134, 79) < 12.5;
      const inSouthGulf = dist(x, y, 134, 113) < 12.5;
      if (inNorthGulf || inSouthGulf) {
        e -= 0.46;
      }
      // Guarantee walkable Isthmus land bridge around x=[124..144], y=[93..99]
      if (x >= 122 && x <= 148 && y >= 93 && y <= 99) {
        e = Math.max(e, 0.34);
      }

      // Two freshwater inland lakes
      const lakeWest = dist(x, y, 68, 76);
      const lakeNorth = dist(x, y, 110, 62);

      const m = 0.5 + 0.35 * moistNoise(x * 0.03, y * 0.03) + 0.15 * moistNoise(x * 0.09, y * 0.09);
      const tmp =
        0.5 +
        0.3 * tempNoise(x * 0.022, y * 0.022) -
        (x > 125 && y < 65 ? 0.45 : 0) +
        (x < 68 && y < 66 ? 0.48 : 0);

      elevation[idx] = e;
      moisture[idx] = m;
      temperature[idx] = tmp;

      if (x <= 3 || y <= 3 || x >= width - 4 || y >= height - 4 || e < 0.16) {
        surfaces[idx] = 'deep_water';
      } else if (e < 0.22) {
        surfaces[idx] = 'shallow_water';
      } else if (lakeWest < 6.5 || lakeNorth < 5.5) {
        surfaces[idx] = lakeWest < 4.5 || lakeNorth < 3.6 ? 'deep_water' : 'shallow_water';
      } else if (e < 0.27) {
        surfaces[idx] = 'sand';
      } else if (dist(x, y, 46, 46) < 20) {
        surfaces[idx] = e > 0.72 ? 'mountain_rock' : 'ash';
      } else if (dist(x, y, 146, 42) < 21) {
        surfaces[idx] = e > 0.74 ? 'mountain_rock' : 'snow';
      } else if (dist(x, y, 144, 150) < 19) {
        surfaces[idx] = 'toxic';
      } else if (dist(x, y, 54, 134) < 19 || (m > 0.72 && e < 0.42)) {
        surfaces[idx] = 'marsh';
      } else if (e > 0.76) {
        surfaces[idx] = 'mountain_rock';
      } else if (e > 0.62) {
        surfaces[idx] = 'hills';
      } else if (m > 0.52) {
        surfaces[idx] = 'forest';
      } else {
        surfaces[idx] = 'grass';
      }
    }
  }

  const spawnRegions: SpawnRegion[] = [
    {
      id: 'spawn_west_cove',
      name: 'West Driftwood Cove',
      description: 'Sheltered western timber shore near Crystal Lake and quiet woodland roads.',
      tileX: 34,
      tileY: 96,
    },
    {
      id: 'spawn_south_meadow',
      name: 'South Sunlit Meadow',
      description: 'Open southern grassland close to Freeport Quartermaster and road salvage.',
      tileX: 94,
      tileY: 154,
    },
    {
      id: 'spawn_east_haven',
      name: 'East Peninsula Haven',
      description: 'Breezy coastal cape beyond the Isthmus, near the Evacuation Harbor.',
      tileX: 154,
      tileY: 118,
    },
    {
      id: 'spawn_north_glade',
      name: 'North Pine Glade',
      description: 'Elevated northern glade bordering rich Ironspine Quarry foothills.',
      tileX: 86,
      tileY: 36,
    },
  ];

  const poiBlueprints = [
    { defId: 'poi_abandoned_village', centerX: 96, centerY: 96, widthTiles: 10, heightTiles: 8 },
    { defId: 'poi_frontier_vendor', centerX: 84, centerY: 118, widthTiles: 8, heightTiles: 7 },
    { defId: 'poi_roadside_workshop', centerX: 64, centerY: 96, widthTiles: 9, heightTiles: 8 },
    { defId: 'poi_mineral_quarry', centerX: 96, centerY: 58, widthTiles: 10, heightTiles: 8 },
    { defId: 'poi_research_facility', centerX: 114, centerY: 82, widthTiles: 10, heightTiles: 8 },
    { defId: 'poi_power_station', centerX: 122, centerY: 96, widthTiles: 9, heightTiles: 7 },
    { defId: 'poi_sealed_bunker', centerX: 74, centerY: 60, widthTiles: 10, heightTiles: 8 },
    { defId: 'poi_refinery_factory', centerX: 122, centerY: 134, widthTiles: 10, heightTiles: 8 },
    { defId: 'poi_sunken_treasury', centerX: 112, centerY: 122, widthTiles: 9, heightTiles: 8 },
    { defId: 'poi_evacuation_harbor', centerX: 164, centerY: 96, widthTiles: 9, heightTiles: 8 },
  ];

  const elderSites = [
    { bossDefId: 'elder_mire', tileX: 50, tileY: 136 },
    { bossDefId: 'elder_cinder', tileX: 44, tileY: 44 },
    { bossDefId: 'elder_frost', tileX: 146, tileY: 40 },
    { bossDefId: 'elder_rad', tileX: 146, tileY: 152 },
    { bossDefId: 'elder_gale', tileX: 116, tileY: 44 },
    { bossDefId: 'elder_abyss', tileX: 164, tileY: 70 },
  ];

  // Ensure all spawn zones, POI footprints, and Elder arenas sit on firm walkable land
  for (const sp of spawnRegions) {
    for (let dy = -6; dy <= 6; dy++) {
      for (let dx = -6; dx <= 6; dx++) {
        const tx = sp.tileX + dx;
        const ty = sp.tileY + dy;
        const idx = ty * width + tx;
        if (surfaces[idx] === 'deep_water' || surfaces[idx] === 'shallow_water' || surfaces[idx] === 'mountain_rock') {
          surfaces[idx] = 'grass';
        }
      }
    }
  }

  for (const pb of poiBlueprints) {
    for (let dy = -6; dy <= 6; dy++) {
      for (let dx = -7; dx <= 7; dx++) {
        const tx = pb.centerX + dx;
        const ty = pb.centerY + dy;
        const idx = ty * width + tx;
        if (Math.abs(dx) <= Math.floor(pb.widthTiles / 2) && Math.abs(dy) <= Math.floor(pb.heightTiles / 2)) {
          surfaces[idx] = 'stone';
        } else if (
          surfaces[idx] === 'deep_water' ||
          surfaces[idx] === 'shallow_water' ||
          surfaces[idx] === 'mountain_rock'
        ) {
          surfaces[idx] = 'grass';
        }
      }
    }
  }

  for (const es of elderSites) {
    const bossBiome = BOSSES_LIST.find((b) => b.id === es.bossDefId)?.biome as SurfaceType | undefined;
    for (let dy = -6; dy <= 6; dy++) {
      for (let dx = -6; dx <= 6; dx++) {
        const tx = es.tileX + dx;
        const ty = es.tileY + dy;
        const idx = ty * width + tx;
        surfaces[idx] = bossBiome ?? 'stone';
      }
    }
  }

  // Carve physical roads joining spawns, crossroads, vendor, POIs, and evacuation harbor across the isthmus
  carveRoadLine(surfaces, width, height, 34, 96, 64, 96);
  carveRoadLine(surfaces, width, height, 64, 96, 96, 96);
  carveRoadLine(surfaces, width, height, 96, 96, 122, 96);
  carveRoadLine(surfaces, width, height, 122, 96, 164, 96);
  carveRoadLine(surfaces, width, height, 154, 118, 160, 96);
  carveRoadLine(surfaces, width, height, 94, 154, 84, 118);
  carveRoadLine(surfaces, width, height, 84, 118, 96, 96);
  carveRoadLine(surfaces, width, height, 86, 36, 96, 58);
  carveRoadLine(surfaces, width, height, 96, 58, 96, 96);
  carveRoadLine(surfaces, width, height, 74, 60, 96, 58);
  carveRoadLine(surfaces, width, height, 114, 82, 96, 96);
  carveRoadLine(surfaces, width, height, 112, 122, 84, 118);
  carveRoadLine(surfaces, width, height, 122, 134, 112, 122);

  // Re-stamp clean stone floor inside POI interiors after roads
  for (const pb of poiBlueprints) {
    const hw = Math.floor(pb.widthTiles / 2);
    const hh = Math.floor(pb.heightTiles / 2);
    for (let dy = -hh; dy <= hh; dy++) {
      for (let dx = -hw; dx <= hw; dx++) {
        surfaces[(pb.centerY + dy) * width + (pb.centerX + dx)] = 'stone';
      }
    }
  }

  const topo: BaseIslandTopology = {
    seed,
    width,
    height,
    surfaces,
    elevation,
    moisture,
    temperature,
    spawnRegions,
    poiBlueprints,
    elderSites,
  };
  topologyCache.set(seed, topo);
  return topo;
}

export function createDefaultProfile(nowUtcMs = Date.now()): ProfileState {
  return {
    profileId: 'local_adventurer_profile',
    securedRagnarokCash: 0,
    achievements: [],
    runHistory: [],
    depositReceiptIds: [],
    createdAtUtcMs: nowUtcMs,
  };
}

export function createNewRunState(options: {
  profile: ProfileState;
  worldSeed?: number;
  adventurerGender?: 'male' | 'female';
  spawnRegionId?: string;
  nowUtcMs?: number;
}): GameState {
  const worldSeed = options.worldSeed ?? 20260414;
  const nowUtcMs = options.nowUtcMs ?? Date.now();
  const topo = getBaseIslandTopology(worldSeed);
  const runNumber = options.profile.runHistory.length + 1;
  const runId = `run_${runNumber}_${worldSeed}`;
  const rng = createSeededRng(worldSeed + runNumber * 7919);

  const chosenSpawn =
    topo.spawnRegions.find((s) => s.id === options.spawnRegionId) ??
    topo.spawnRegions[nextInt(rng, 0, topo.spawnRegions.length - 1)];

  const structures: Record<string, StructureInstance> = {};
  const sourceStocks: Record<string, SourceNodeInstance> = {};
  const pois: WorldPoiInstance[] = [];
  const occupiedTiles = new Set<string>();

  const markOcc = (x: number, y: number) => occupiedTiles.add(`${x},${y}`);
  const isOcc = (x: number, y: number) => occupiedTiles.has(`${x},${y}`);

  let srcSeq = 1;
  const addSource = (
    defId: string,
    tx: number,
    ty: number,
    extra?: { poiId?: string; isDeepPoi?: boolean; nonBossFinal72?: boolean }
  ) => {
    if (tx < 2 || ty < 2 || tx >= topo.width - 2 || ty >= topo.height - 2) return;
    if (isOcc(tx, ty)) return;
    const def = SOURCES[defId];
    if (!def) return;
    const id = `src_${srcSeq++}_${defId}`;
    sourceStocks[id] = {
      id,
      defId,
      tileX: tx,
      tileY: ty,
      poiId: extra?.poiId,
      isDeepPoi: extra?.isDeepPoi,
      nonBossFinal72: extra?.nonBossFinal72,
      stock: def.initialStock,
      maxStock: def.initialStock,
      hitsRemaining: def.maxHits,
      maxHits: def.maxHits,
      depletedAtElapsedSec: null,
      respawnAtElapsedSec: null,
      consumedReceiptIds: [],
    };
    markOcc(tx, ty);
  };

  // 1. Stamp physical POI structures, gated deep rooms, exterior & deep sources, and Final-72 vaults
  let poiStructSeq = 1;
  for (const pb of topo.poiBlueprints) {
    const def = POIS[pb.defId];
    const poiId = pb.defId;
    const hw = Math.floor(pb.widthTiles / 2);
    const hh = Math.floor(pb.heightTiles / 2);
    const left = pb.centerX - hw;
    const right = pb.centerX + hw;
    const top = pb.centerY - hh;
    const bottom = pb.centerY + hh;
    const gateX = pb.centerX;
    const gateY = bottom;
    let gateStructureId: string | null = null;

    if (def.gateType !== 'open') {
      // Build physical perimeter stone walls around the deep room
      for (let y = top; y <= bottom; y++) {
        for (let x = left; x <= right; x++) {
          const isBorder = x === left || x === right || y === top || y === bottom;
          if (!isBorder) continue;
          if (x === gateX && y === gateY) {
            const gid = `poi_gate_${poiStructSeq++}`;
            gateStructureId = gid;
            structures[gid] = {
              id: gid,
              defId: 'powered_blast_door',
              tileX: x,
              tileY: y,
              hp: 999,
              maxHp: 999,
              ownerId: 'world_poi',
              poiId,
              isOpen: false,
              fuelRemainingSec: 0,
              activeJobId: null,
              createdReceiptId: 'world_init',
            };
            markOcc(x, y);
          } else {
            const wid = `poi_wall_${poiStructSeq++}`;
            structures[wid] = {
              id: wid,
              defId: 'stone_wall',
              tileX: x,
              tileY: y,
              hp: 999,
              maxHp: 999,
              ownerId: 'world_poi',
              poiId,
              fuelRemainingSec: 0,
              activeJobId: null,
              createdReceiptId: 'world_init',
            };
            markOcc(x, y);
          }
        }
      }
    } else {
      // Open-air pavilion corners for vendor & evacuation harbor
      for (const [cx, cy] of [
        [left, top],
        [right, top],
        [left, bottom],
        [right, bottom],
      ]) {
        const wid = `poi_pillar_${poiStructSeq++}`;
        structures[wid] = {
          id: wid,
          defId: 'stone_wall',
          tileX: cx,
          tileY: cy,
          hp: 999,
          maxHp: 999,
          ownerId: 'world_poi',
          poiId,
          fuelRemainingSec: 0,
          activeJobId: null,
          createdReceiptId: 'world_init',
        };
        markOcc(cx, cy);
      }
    }

    // Place exterior sources in front courtyard (bottom + 2)
    def.exteriorSources.forEach((sDefId, i) => {
      addSource(sDefId, left + 1 + i * 2, bottom + 2, { poiId, isDeepPoi: false });
    });

    // Place deep sources inside gated interior
    def.deepSources.forEach((sDefId, i) => {
      addSource(sDefId, left + 2 + i * 2, top + 2, { poiId, isDeepPoi: true });
    });

    if (def.hasFinal72Vault) {
      addSource('final72_ragnarok_vault', pb.centerX, pb.centerY - 1, {
        poiId,
        isDeepPoi: def.gateType !== 'open',
        nonBossFinal72: Boolean(def.nonBossFinal72Eligible),
      });
    }

    pois.push({
      id: poiId,
      defId: pb.defId,
      name: def.name,
      centerX: pb.centerX,
      centerY: pb.centerY,
      widthTiles: pb.widthTiles,
      heightTiles: pb.heightTiles,
      gateTileX: gateX,
      gateTileY: gateY,
      gateStructureId,
      relayTileX: right + 1,
      relayTileY: bottom + 1,
      unlockedDeep: def.gateType === 'open',
      poweredUntilSec: 0,
      fuseInstalled: false,
    });
  }

  // 2. Guarantee early survival resources & a clear 2-tile camp pad at ALL 4 safe spawn regions
  for (const sp of topo.spawnRegions) {
    for (let cy = -2; cy <= 2; cy++) {
      for (let cx = -2; cx <= 2; cx++) {
        markOcc(sp.tileX + cx, sp.tileY + cy);
      }
    }
    addSource('pine_tree', sp.tileX - 3, sp.tileY - 2);
    addSource('pine_tree', sp.tileX + 3, sp.tileY - 2);
    addSource('oak_tree', sp.tileX - 4, sp.tileY + 2);
    addSource('stone_outcrop', sp.tileX + 4, sp.tileY + 2);
    addSource('stone_outcrop', sp.tileX + 3, sp.tileY - 4);
    addSource('berry_bush', sp.tileX - 2, sp.tileY + 3);
    addSource('berry_bush', sp.tileX + 2, sp.tileY + 3);
    addSource('herb_patch', sp.tileX - 3, sp.tileY - 4);
    addSource('fresh_spring', sp.tileX, sp.tileY - 3);
    addSource('roadside_barrel', sp.tileX + 5, sp.tileY);
    addSource('salvage_crate', sp.tileX - 5, sp.tileY);
  }

  // 3. Place 3 high-risk outer Final-72 vaults near outer hazard fringes
  addSource('final72_ragnarok_vault', 52, 48, { nonBossFinal72: false });
  addSource('final72_ragnarok_vault', 140, 48, { nonBossFinal72: false });
  addSource('final72_ragnarok_vault', 138, 146, { nonBossFinal72: false });

  // 4. Populate biome-coherent natural & roadside salvage sources across the 192x192 island
  for (let y = 8; y < topo.height - 8; y += 3) {
    for (let x = 8; x < topo.width - 8; x += 3) {
      const tx = x + nextInt(rng, -1, 1);
      const ty = y + nextInt(rng, -1, 1);
      if (isOcc(tx, ty)) continue;
      // Keep POI doorways clear
      if (pois.some((p) => dist(tx, ty, p.centerX, p.centerY) < 7)) continue;
      if (topo.elderSites.some((e) => dist(tx, ty, e.tileX, e.tileY) < 5)) continue;

      const surf = topo.surfaces[ty * topo.width + tx];
      const roll = nextFloat01(rng);

      if (surf === 'road') {
        if (roll < 0.085) {
          // Place roadside barrel/crate adjacent to road so road remains unobstructed for carts!
          const adjX = tx + 1;
          const adjSurf = topo.surfaces[ty * topo.width + adjX];
          if (adjSurf !== 'road' && adjSurf !== 'deep_water' && !isOcc(adjX, ty)) {
            addSource(roll < 0.05 ? 'roadside_barrel' : 'salvage_crate', adjX, ty);
          }
        }
      } else if (surf === 'forest') {
        if (roll < 0.24) addSource('pine_tree', tx, ty);
        else if (roll < 0.34) addSource('oak_tree', tx, ty);
        else if (roll < 0.39) addSource('berry_bush', tx, ty);
        else if (roll < 0.43) addSource('herb_patch', tx, ty);
      } else if (surf === 'grass') {
        if (roll < 0.07) addSource('oak_tree', tx, ty);
        else if (roll < 0.12) addSource('berry_bush', tx, ty);
        else if (roll < 0.16) addSource('stone_outcrop', tx, ty);
        else if (roll < 0.185) addSource('herb_patch', tx, ty);
      } else if (surf === 'sand') {
        if (roll < 0.12) addSource('driftwood_pile', tx, ty);
      } else if (surf === 'hills') {
        if (roll < 0.18) addSource('stone_outcrop', tx, ty);
        else if (roll < 0.30) addSource('iron_vein', tx, ty);
      } else if (surf === 'ash') {
        if (roll < 0.16) addSource('sulfur_vent', tx, ty);
        else if (roll < 0.24) addSource('iron_vein', tx, ty);
      } else if (surf === 'marsh') {
        if (roll < 0.14) addSource('herb_patch', tx, ty);
        else if (roll < 0.20) addSource('pine_tree', tx, ty);
      } else if (surf === 'toxic') {
        if (roll < 0.12) addSource('industrial_scrap_pile', tx, ty);
        else if (roll < 0.17) addSource('fuel_drum', tx, ty);
      } else if (surf === 'snow') {
        if (roll < 0.15) addSource('iron_vein', tx, ty);
        else if (roll < 0.22) addSource('pine_tree', tx, ty);
      }
    }
  }

  // 5. Spawn habitat-appropriate ordinary monsters (never inside safe spawn 11-tile sanctuary at start)
  const enemies: EnemyActor[] = [];
  let enemySeq = 1;
  for (let y = 12; y < topo.height - 12; y += 11) {
    for (let x = 12; x < topo.width - 12; x += 11) {
      if (topo.spawnRegions.some((sp) => dist(x, y, sp.tileX, sp.tileY) < 12)) continue;
      if (pois.some((p) => (p.defId === 'poi_frontier_vendor' || p.defId === 'poi_evacuation_harbor') && dist(x, y, p.centerX, p.centerY) < 10)) {
        continue;
      }
      const surf = topo.surfaces[y * topo.width + x];
      if (surf === 'deep_water' || surf === 'mountain_rock') continue;
      const matching = ENEMIES_LIST.filter((e) => e.habitatBiomes.includes(surf));
      if (matching.length === 0 || nextFloat01(rng) > 0.52) continue;
      const eDef = matching[nextInt(rng, 0, matching.length - 1)];
      const px = x * 16 + 8;
      const py = y * 16 + 8;
      enemies.push({
        id: `enm_${enemySeq++}_${eDef.id}`,
        defId: eDef.id,
        x: px,
        y: py,
        homeX: px,
        homeY: py,
        hp: eDef.maxHp,
        maxHp: eDef.maxHp,
        alive: true,
        respawnAtSec: null,
        aiState: 'patrol',
        lastSeenPlayerPos: null,
        followedFootprintId: null,
        trailTargetPos: null,
        discoveredStructureId: null,
        lostTimerSec: 0,
        patrolAngle: nextFloat01(rng) * Math.PI * 2,
        windupRemainingMs: 0,
        windupTargetPos: null,
        windupTargetStructureId: null,
        cooldownRemainingMs: 0,
      });
    }
  }

  // Ensure at least one low-tier enemy within reasonable scouting distance (~13 tiles) of each spawn
  topo.spawnRegions.forEach((sp, idx) => {
    const eDef = ENEMIES_LIST[idx % 2]; // shore_crab or plains_hound
    const ex = (sp.tileX + 12) * 16 + 8;
    const ey = (sp.tileY + 4) * 16 + 8;
    enemies.push({
      id: `enm_scout_${idx + 1}_${eDef.id}`,
      defId: eDef.id,
      x: ex,
      y: ey,
      homeX: ex,
      homeY: ey,
      hp: eDef.maxHp,
      maxHp: eDef.maxHp,
      alive: true,
      respawnAtSec: null,
      aiState: 'patrol',
      lastSeenPlayerPos: null,
      followedFootprintId: null,
      trailTargetPos: null,
      discoveredStructureId: null,
      lostTimerSec: 0,
      patrolAngle: 0,
      windupRemainingMs: 0,
      windupTargetPos: null,
      windupTargetStructureId: null,
      cooldownRemainingMs: 0,
    });
  });

  // 6. Place the 6 distinct optional Elders in their latent form at their geographic sanctuaries
  const elders: ElderActor[] = topo.elderSites.map((es) => {
    const bDef = BOSSES_LIST.find((b) => b.id === es.bossDefId)!;
    const px = es.tileX * 16 + 8;
    const py = es.tileY * 16 + 8;
    return {
      id: `elder_inst_${bDef.id}`,
      defId: bDef.id,
      x: px,
      y: py,
      homeX: px,
      homeY: py,
      form: 'latent',
      hp: bDef.latent.maxHp,
      maxHp: bDef.latent.maxHp,
      alive: true,
      defeatedReceiptId: null,
      aiState: 'idle',
      windupRemainingMs: 0,
      telegraphPos: null,
      cooldownRemainingMs: 0,
    };
  });

  // 7. Vendor stock initialization
  const vendorStocks: Record<string, number> = {};
  for (const poiDef of Object.values(POIS)) {
    for (const offer of poiDef.vendorCatalog ?? []) {
      vendorStocks[offer.id] = offer.stock;
    }
  }

  // 8. Starter learned recipes (run-local!)
  const learnedRecipeIds = RECIPES_LIST.filter((r) => r.starterKnown).map((r) => r.id);

  // 9. Starter equipment: humble Rust-Edge Survival Knife + 1 Purified Water + 2 Island Berries
  const items: GameState['items'] = {
    [`itm_${runId}_starter_knife`]: {
      instanceId: `itm_${runId}_starter_knife`,
      defId: 'survival_knife',
      runId,
      count: 1,
      durability: ITEMS.survival_knife.maxDurability,
      quality: 100,
      location: { kind: 'player_equip', equipSlot: 'hand' },
      provenanceReceiptId: `rcpt_${runId}_init`,
    },
    [`itm_${runId}_starter_water`]: {
      instanceId: `itm_${runId}_starter_water`,
      defId: 'clean_water',
      runId,
      count: 1,
      quality: 100,
      location: { kind: 'player_quickbar', slotIndex: 0 },
      provenanceReceiptId: `rcpt_${runId}_init`,
    },
    [`itm_${runId}_starter_berries`]: {
      instanceId: `itm_${runId}_starter_berries`,
      defId: 'wild_berries',
      runId,
      count: 2,
      quality: 100,
      location: { kind: 'player_quickbar', slotIndex: 1 },
      provenanceReceiptId: `rcpt_${runId}_init`,
    },
  };

  const state: GameState = {
    schemaVersion: 1,
    revision: 1,
    profile: structuredClone(options.profile),
    run: {
      runId,
      runNumber,
      worldSeed,
      adventurerGender: options.adventurerGender ?? 'female',
      spawnRegionId: chosenSpawn.id,
      status: 'active',
      finalizedOnce: false,
      learnedRecipeIds,
      collectedElderStones: [],
      uniqueScoreEvents: {},
      cashDepositedThisRun: 0,
      qaClockUsed: false,
    },
    clock: {
      startUtcMs: nowUtcMs,
      lastSimulatedUtcMs: nowUtcMs,
      elapsedRealSeconds: 0,
      qaOffsetSeconds: 0,
      phase: 'normal',
      fictionalDay: 1,
      timeOfDay01: 0.35, // morning daylight
      season: 'spring',
      weather: 'clear',
      nextWeatherFrontSec: BALANCE.environment.weatherCycleSeconds.value,
    },
    world: {
      seed: worldSeed,
      width: topo.width,
      height: topo.height,
      spawnRegions: topo.spawnRegions,
      pois,
      discoveredChunks: [],
    },
    actors: {
      player: {
        id: 'player',
        x: chosenSpawn.tileX * 16 + 8,
        y: chosenSpawn.tileY * 16 + 8,
        facing: 'down',
        hp: BALANCE.player.maxHp.value,
        maxHp: BALANCE.player.maxHp.value,
        hunger: BALANCE.player.maxHunger.value,
        thirst: BALANCE.player.maxThirst.value,
        stamina: BALANCE.player.maxStamina.value,
        tempStress: 0,
        radDose: 0,
        slowRemainingSec: 0,
        chillRemainingSec: 0,
        activeCast: null,
        cooldownUntilSec: 0,
        bedStructureId: null,
        tetheredVehicleId: null,
        deathCount: 0,
        lastFootprintId: null,
        lastFootprintTileKey: null,
      },
      enemies,
      elders,
    },
    items,
    sourceStocks,
    structures,
    vehicles: {},
    deathBags: {},
    footprints: [],
    terrainEffects: {},
    jobs: {},
    vendorStocks,
    optionalHintsRecognized: {},
    eventReceipts: [
      {
        receiptId: `rcpt_${runId}_init`,
        intentId: 'init_run',
        contractEdge: 'C24',
        runId,
        revision: 1,
        timestampUtcMs: nowUtcMs,
        elapsedSec: 0,
        actorId: 'player',
        sourceId: chosenSpawn.id,
        summary: `Landed at ${chosenSpawn.name} (${options.adventurerGender ?? 'female'} Adventurer).`,
      },
    ],
    processedIntentIds: [],
    vfxCues: [],
    rngState: serializeRng(rng),
  };

  revealDiscoveryAroundPlayer(state);
  return state;
}

export function revealDiscoveryAroundPlayer(state: GameState): void {
  const chunkW = Math.ceil(state.world.width / 4);
  const ptx = Math.floor(state.actors.player.x / 16);
  const pty = Math.floor(state.actors.player.y / 16);
  const set = new Set(state.world.discoveredChunks);
  for (let dy = -3; dy <= 3; dy++) {
    for (let dx = -3; dx <= 3; dx++) {
      const cx = Math.floor((ptx + dx * 4) / 4);
      const cy = Math.floor((pty + dy * 4) / 4);
      if (cx >= 0 && cy >= 0 && cx < chunkW && cy < Math.ceil(state.world.height / 4)) {
        set.add(cy * chunkW + cx);
      }
    }
  }
  state.world.discoveredChunks = Array.from(set);
}
