import { openDB, type IDBPDatabase } from 'idb';
import { z } from 'zod';
import { assertCustodyInvariants } from './custody';
import { catchUpOffline } from './simulationTick';
import { createDefaultProfile } from './worldGen';
import type { EventReceipt, GameState, ProfileState } from './types';

const DB_NAME = 'soul_of_hero_world_sim_db';
const DB_VERSION = 1;
const LS_FALLBACK_KEY = 'soul_of_hero_snapshot_v1';

const ProfileSchema = z.object({
  profileId: z.string(),
  securedRagnarokCash: z.number().nonnegative(),
  achievements: z.array(z.string()),
  runHistory: z.array(z.any()),
  depositReceiptIds: z.array(z.string()),
  createdAtUtcMs: z.number(),
});

const GameStateEnvelopeSchema = z.object({
  schemaVersion: z.literal(1),
  revision: z.number().int().positive(),
  profile: ProfileSchema,
  run: z.object({
    runId: z.string(),
    runNumber: z.number().int().positive(),
    worldSeed: z.number(),
    adventurerGender: z.enum(['male', 'female']),
    spawnRegionId: z.string(),
    status: z.enum([
      'active',
      'evacuated',
      'abandoned',
      'expired',
      'six_stone_convergence',
    ]),
    finalizedOnce: z.boolean(),
    learnedRecipeIds: z.array(z.string()),
    collectedElderStones: z.array(z.string()),
    uniqueScoreEvents: z.record(z.string(), z.any()),
    cashDepositedThisRun: z.number().nonnegative(),
    qaClockUsed: z.boolean(),
  }),
  clock: z.object({
    startUtcMs: z.number(),
    lastSimulatedUtcMs: z.number(),
    elapsedRealSeconds: z.number().nonnegative(),
    qaOffsetSeconds: z.number().nonnegative(),
    phase: z.enum([
      'normal',
      'ragnarok_final72',
      'ragnarok_day14_awakened',
      'expired',
    ]),
    fictionalDay: z.number(),
    timeOfDay01: z.number(),
    season: z.enum(['spring', 'summer', 'autumn', 'winter']),
    weather: z.enum(['clear', 'rain', 'storm', 'ash_wind', 'cold_snap']),
    nextWeatherFrontSec: z.number(),
  }),
  world: z.any(),
  actors: z.any(),
  items: z.record(z.string(), z.any()),
  sourceStocks: z.record(z.string(), z.any()),
  structures: z.record(z.string(), z.any()),
  vehicles: z.record(z.string(), z.any()),
  deathBags: z.record(z.string(), z.any()),
  footprints: z.array(z.any()),
  terrainEffects: z.record(z.string(), z.any()),
  jobs: z.record(z.string(), z.any()),
  vendorStocks: z.record(z.string(), z.number()),
  optionalHintsRecognized: z.record(z.string(), z.string()),
  eventReceipts: z.array(z.any()),
  processedIntentIds: z.array(z.string()),
  vfxCues: z.array(z.any()),
  rngState: z.array(z.number()),
});

interface SoulDbStores {
  snapshots: {
    key: string;
    value: GameState;
  };
  profiles: {
    key: string;
    value: ProfileState;
  };
  receipts: {
    key: string;
    value: EventReceipt;
  };
}

let dbPromise: Promise<IDBPDatabase<SoulDbStores>> | null = null;

export function resetPersistenceConnectionForTests(): void {
  dbPromise = null;
}

async function getDb(): Promise<IDBPDatabase<SoulDbStores>> {
  if (!dbPromise) {
    dbPromise = openDB<SoulDbStores>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('snapshots')) {
          db.createObjectStore('snapshots');
        }
        if (!db.objectStoreNames.contains('profiles')) {
          db.createObjectStore('profiles');
        }
        if (!db.objectStoreNames.contains('receipts')) {
          db.createObjectStore('receipts', { keyPath: 'receiptId' });
        }
      },
    });
  }
  return dbPromise;
}

export function validateGameStateSnapshot(candidate: unknown): {
  valid: boolean;
  state?: GameState;
  error?: string;
} {
  const parsed = GameStateEnvelopeSchema.safeParse(candidate);
  if (!parsed.success) {
    return { valid: false, error: parsed.error.message };
  }
  const st = candidate as GameState;
  try {
    assertCustodyInvariants(st);
  } catch (err) {
    return { valid: false, error: err instanceof Error ? err.message : String(err) };
  }
  return { valid: true, state: st };
}

/**
 * Atomically saves GameState snapshot, ProfileState, and newest EventReceipts in ONE IndexedDB readwrite transaction,
 * with localStorage mirror fallback.
 */
export async function saveGameStateAtomic(state: GameState): Promise<void> {
  assertCustodyInvariants(state);
  try {
    const db = await getDb();
    const tx = db.transaction(['snapshots', 'profiles', 'receipts'], 'readwrite');
    await Promise.all([
      tx.objectStore('snapshots').put(structuredClone(state), 'active_state'),
      tx.objectStore('profiles').put(structuredClone(state.profile), 'active_profile'),
      ...state.eventReceipts
        .slice(-20)
        .map((rcpt) => tx.objectStore('receipts').put(structuredClone(rcpt))),
      tx.done,
    ]);
  } catch {
    // Fallback to localStorage if IndexedDB is blocked in restricted iframe
  }

  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(LS_FALLBACK_KEY, JSON.stringify(state));
    }
  } catch {
    // Ignore storage quota warnings on fallback
  }
}

export interface LoadGameResult {
  found: boolean;
  corrupted?: boolean;
  corruptionReason?: string;
  state: GameState | null;
  profile: ProfileState;
  offlineCatchupSummary: string[];
}

/**
 * Loads saved state from IndexedDB (or localStorage fallback), validates schema + custody invariants,
 * and runs chronological offline catch-up up to `nowUtcMs`.
 */
export async function loadGameStateAndCatchUp(nowUtcMs = Date.now()): Promise<LoadGameResult> {
  let rawState: unknown = undefined;
  let rawProfile: unknown = undefined;

  try {
    const db = await getDb();
    rawState = await db.get('snapshots', 'active_state');
    rawProfile = await db.get('profiles', 'active_profile');
  } catch {
    // IndexedDB unavailable; try localStorage fallback
  }

  if (!rawState && typeof localStorage !== 'undefined') {
    const ls = localStorage.getItem(LS_FALLBACK_KEY);
    if (ls) {
      try {
        rawState = JSON.parse(ls);
      } catch (e) {
        return {
          found: false,
          corrupted: true,
          corruptionReason: `Corrupted JSON in localStorage: ${String(e)}`,
          state: null,
          profile: createDefaultProfile(nowUtcMs),
          offlineCatchupSummary: [],
        };
      }
    }
  }

  const parsedProfile = ProfileSchema.safeParse(rawProfile);
  const safeProfile: ProfileState = parsedProfile.success
    ? (rawProfile as ProfileState)
    : createDefaultProfile(nowUtcMs);

  if (!rawState) {
    return {
      found: false,
      state: null,
      profile: safeProfile,
      offlineCatchupSummary: [],
    };
  }

  const validated = validateGameStateSnapshot(rawState);
  if (!validated.valid || !validated.state) {
    return {
      found: false,
      corrupted: true,
      corruptionReason: validated.error ?? 'Unknown snapshot corruption',
      state: null,
      profile: safeProfile,
      offlineCatchupSummary: [],
    };
  }

  const caughtUp = catchUpOffline(validated.state, nowUtcMs);
  if (caughtUp.settledSeconds >= 1) {
    await saveGameStateAtomic(caughtUp.state);
  }

  return {
    found: true,
    state: caughtUp.state,
    profile: caughtUp.state.profile,
    offlineCatchupSummary: caughtUp.summaryLog,
  };
}

export async function clearAllSavedDataForTests(): Promise<void> {
  try {
    const db = await getDb();
    const tx = db.transaction(['snapshots', 'profiles', 'receipts'], 'readwrite');
    await Promise.all([
      tx.objectStore('snapshots').clear(),
      tx.objectStore('profiles').clear(),
      tx.objectStore('receipts').clear(),
      tx.done,
    ]);
  } catch {
    // ignore
  }
  if (typeof localStorage !== 'undefined') {
    localStorage.removeItem(LS_FALLBACK_KEY);
  }
}
