import {
  BALANCE,
  BOSSES,
  ENEMIES,
  ITEMS,
  SOURCES,
  STRUCTURES,
} from './catalogs';
import {
  assertCustodyInvariants,
  getEquippedItem,
  isPlayerHeldLocation,
  listStructureItems,
} from './custody';
import { commitActiveCastNow, finalizeRunOnce } from './dispatcher';
import {
  findPathTiles,
  getEffectiveSurface,
  hasLineOfSight,
  isPlayerSheltered,
  isTilePowered,
  isTileWalkable,
} from './navigation';
import { nextDeterministicId, nextInt, restoreRng, serializeRng } from './rng';
import type { GameState, WeatherKind } from './types';

function distPx(x0: number, y0: number, x1: number, y1: number): number {
  return Math.hypot(x1 - x0, y1 - y0);
}

const WEATHER_ORDER: WeatherKind[] = ['clear', 'rain', 'clear', 'storm', 'cold_snap', 'ash_wind'];

function computePlayerArmorAndResist(state: GameState) {
  let armor = 0;
  let coldResist = 0;
  let heatResist = 0;
  let radResist = 0;
  for (const slot of ['body', 'utility', 'hand'] as const) {
    const eq = getEquippedItem(state, slot);
    const prof = eq ? ITEMS[eq.defId]?.armorProfile : undefined;
    if (prof) {
      armor += prof.armor;
      coldResist += prof.coldResist;
      heatResist += prof.heatResist;
      radResist += prof.radResist;
    }
  }
  return { armor, coldResist, heatResist, radResist };
}

function isNearWarmStation(state: GameState, xPx: number, yPx: number): boolean {
  const tx = xPx / 16;
  const ty = yPx / 16;
  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0 || st.fuelRemainingSec <= 0) continue;
    const wRad = STRUCTURES[st.defId]?.warmthRadiusTiles;
    if (wRad && Math.hypot(st.tileX + 0.5 - tx, st.tileY + 0.5 - ty) <= wRad) {
      return true;
    }
  }
  return false;
}

export function handlePlayerDeathIfLethal(
  state: GameState,
  cause: string,
  nowUtcMs: number
): void {
  const p = state.actors.player;
  if (p.hp > 0 || state.run.status !== 'active') return;

  state.revision += 1;
  p.deathCount += 1;
  p.activeCast = null;
  p.tetheredVehicleId = null;

  const deathReceiptId = nextDeterministicId('rcpt_death', state.run.runId, state.revision);
  const bagId = nextDeterministicId('dbag', state.run.runId, state.revision);

  // Move all carried player items once into physical Death Bag at death coordinates (C10)
  const carried = Object.values(state.items).filter((i) => isPlayerHeldLocation(i.location));
  if (carried.length > 0) {
    state.deathBags[bagId] = {
      id: bagId,
      x: Math.round(p.x),
      y: Math.round(p.y),
      createdAtElapsedSec: state.clock.elapsedRealSeconds,
      deathReceiptId,
    };
    carried.forEach((itm, idx) => {
      itm.location = { kind: 'death_bag', bagId, slotIndex: idx };
    });
  }

  // Respawn within SAME active run at valid bound Bed or safe starting spawn
  let respawnX = (state.world.spawnRegions[0]?.tileX ?? 34) * 16 + 8;
  let respawnY = (state.world.spawnRegions[0]?.tileY ?? 96) * 16 + 8;
  const sp = state.world.spawnRegions.find((s) => s.id === state.run.spawnRegionId);
  if (sp) {
    respawnX = sp.tileX * 16 + 8;
    respawnY = sp.tileY * 16 + 8;
  }
  if (p.bedStructureId && state.structures[p.bedStructureId]?.hp > 0) {
    const bed = state.structures[p.bedStructureId];
    respawnX = bed.tileX * 16 + 8;
    respawnY = (bed.tileY + 1) * 16 + 8;
  }

  p.x = respawnX;
  p.y = respawnY;
  p.hp = Math.round(p.maxHp * 0.7);
  p.hunger = Math.max(45, p.hunger);
  p.thirst = Math.max(45, p.thirst);
  p.stamina = BALANCE.player.maxStamina.value;
  p.tempStress = 0;
  p.radDose = Math.max(0, p.radDose * 0.4);

  state.eventReceipts.push({
    receiptId: deathReceiptId,
    intentId: 'lethal_damage_resolution',
    contractEdge: 'C10',
    runId: state.run.runId,
    revision: state.revision,
    timestampUtcMs: nowUtcMs,
    elapsedSec: Math.round(state.clock.elapsedRealSeconds * 100) / 100,
    actorId: 'player',
    sourceId: carried.length > 0 ? bagId : undefined,
    summary: `Adventurer fell (${cause}). ${carried.length > 0 ? `Dropped Death Bag ${bagId} (${carried.length} stacks)` : 'No carried items dropped'}; respawned in active run.`,
    details: { cause, bagId: carried.length > 0 ? bagId : null },
  });
}

function advanceClockAndPhase(state: GameState, dtSec: number, nowUtcMs: number): void {
  state.clock.elapsedRealSeconds += dtSec;
  state.clock.lastSimulatedUtcMs = nowUtcMs;

  const elapsed = state.clock.elapsedRealSeconds;
  const maxRun = BALANCE.clock.maxRunRealSeconds.value;
  const ragStart = BALANCE.clock.hazardIntensifyStartSeconds.value;
  const elderAwake = BALANCE.clock.elderAwakenStartSeconds.value;

  if (elapsed >= maxRun) {
    state.clock.phase = 'expired';
    finalizeRunOnce(state, 'expired', nowUtcMs, 'clock_336h_expiration');
    return;
  } else if (elapsed >= elderAwake) {
    if (state.clock.phase !== 'ragnarok_day14_awakened') {
      state.clock.phase = 'ragnarok_day14_awakened';
      // Awaken all 6 living optional Elders on Day 14!
      for (const el of state.actors.elders) {
        if (el.alive && el.form === 'latent') {
          const bDef = BOSSES[el.defId];
          const hpRatio = el.hp / el.maxHp;
          el.form = 'awakened';
          el.maxHp = bDef.awakened.maxHp;
          el.hp = Math.max(1, Math.round(bDef.awakened.maxHp * hpRatio));
        }
      }
    }
  } else if (elapsed >= ragStart) {
    state.clock.phase = 'ragnarok_final72';
  } else {
    state.clock.phase = 'normal';
  }

  // Fictional daylight & season progression
  const dayLen = BALANCE.clock.fictionalDayRealSeconds.value;
  const totalDaysFloat = elapsed / dayLen + 0.35;
  state.clock.fictionalDay = Math.floor(totalDaysFloat) + 1;
  state.clock.timeOfDay01 = totalDaysFloat - Math.floor(totalDaysFloat);
  const seasons = ['spring', 'summer', 'autumn', 'winter'] as const;
  state.clock.season = seasons[Math.floor((state.clock.fictionalDay - 1) / 6) % 4];

  // Scheduled deterministic weather front transitions
  if (elapsed >= state.clock.nextWeatherFrontSec) {
    const rng = restoreRng(state.rngState);
    const idx =
      state.clock.phase !== 'normal'
        ? nextInt(rng, 1, WEATHER_ORDER.length - 1) // more intense weather during Final 72h
        : nextInt(rng, 0, WEATHER_ORDER.length - 2);
    state.clock.weather = WEATHER_ORDER[idx];
    state.clock.nextWeatherFrontSec =
      elapsed + BALANCE.environment.weatherCycleSeconds.value;
    state.rngState = serializeRng(rng);
  }
}

function advanceStationsAndJobs(state: GameState, dtSec: number): void {
  // 1. Burn fuel on active fuel-using stations (generators, hearths, furnaces with active jobs or power supply)
  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0) continue;
    const sDef = STRUCTURES[st.defId];
    if (!sDef?.usesFuel || st.fuelRemainingSec <= 0) continue;

    const job = st.activeJobId ? state.jobs[st.activeJobId] : null;
    const isGenerator = Boolean(sDef.powerSupplyWatts);
    const isHearthOrFire = st.defId === 'campfire_lantern' || st.defId === 'cooking_hearth';

    if (isGenerator || isHearthOrFire || (job && job.status === 'active')) {
      const burn = Math.min(st.fuelRemainingSec, dtSec);
      st.fuelRemainingSec = Math.max(0, st.fuelRemainingSec - burn);

      // Advance fuel-dependent job ONLY by the actual fueled duration `burn`!
      if (job && job.status === 'active' && job.requiresFuel) {
        job.progressSec = Math.min(job.totalWorkSec, job.progressSec + burn);
        if (job.progressSec >= job.totalWorkSec) {
          job.status = 'completed_unclaimed';
        } else if (st.fuelRemainingSec <= 0) {
          job.status = 'paused_no_fuel';
        }
      }
    }
  }

  // 2. Advance non-fuel jobs (hand, workbench, research_bench, garden_planter, powered jobs)
  for (const job of Object.values(state.jobs)) {
    if (job.status !== 'active' && job.status !== 'paused_no_power') continue;
    if (job.requiresFuel) {
      // Handled above or paused if fuel ran out
      const st = job.stationId !== 'hand' ? state.structures[job.stationId] : null;
      if (!st || st.fuelRemainingSec <= 0) {
        job.status = 'paused_no_fuel';
      }
      continue;
    }

    if (job.stationId !== 'hand') {
      const st = state.structures[job.stationId];
      if (!st || st.hp <= 0) {
        job.status = 'interrupted_hazard';
        continue;
      }
      if (job.requiresPower) {
        const powered = isTilePowered(state, st.tileX, st.tileY);
        if (!powered) {
          job.status = 'paused_no_power';
          continue;
        } else if (job.status === 'paused_no_power') {
          job.status = 'active';
        }
      }
    }

    if (job.status === 'active') {
      job.progressSec = Math.min(job.totalWorkSec, job.progressSec + dtSec);
      if (job.progressSec >= job.totalWorkSec) {
        job.status = 'completed_unclaimed';
      }
    }
  }
}

function advanceEnvironmentAndTraces(state: GameState, dtSec: number): void {
  const nowSec = state.clock.elapsedRealSeconds;
  const isRaining = state.clock.weather === 'rain' || state.clock.weather === 'storm';

  // 1. Decay footprints (faster during rain/storm!)
  const rainMult = isRaining ? BALANCE.environment.rainTraceDecayMultiplier.value : 1.0;
  for (const fp of state.footprints) {
    if (isRaining) {
      fp.expireAtElapsedSec -= dtSec * (rainMult - 1);
    }
    const totalSpan = Math.max(1, fp.baseRetentionSec);
    fp.ageProgress01 = Math.min(1, (nowSec - fp.createdAtElapsedSec) / totalSpan);
  }
  state.footprints = state.footprints.filter((fp) => fp.expireAtElapsedSec > nowSec);

  // 2. Terrain effects: expire, rain extinguish, and bounded fire propagation
  const newEffects: GameState['terrainEffects'] = {};
  const maxGen = BALANCE.environment.fireMaxSpreadGeneration.value;
  const spreadInterval = BALANCE.environment.fireSpreadIntervalSeconds.value;

  for (const [key, eff] of Object.entries(state.terrainEffects)) {
    if (eff.endSec <= nowSec) {
      if (eff.type === 'fire') {
        // Leave short-lived scorch mark after fire burns out
        newEffects[key] = {
          ...eff,
          type: 'scorch',
          startSec: nowSec,
          endSec: nowSec + 120,
        };
      }
      continue;
    }
    if (eff.type === 'fire' && isRaining) {
      continue; // Rain quenches outdoor wildfire!
    }

    // Fire damages flammable structures/sources on tile
    if (eff.type === 'fire') {
      for (const st of Object.values(state.structures)) {
        if (st.tileX === eff.tileX && st.tileY === eff.tileY && st.hp > 0 && STRUCTURES[st.defId]?.flammable) {
          st.hp = Math.max(0, st.hp - 6 * dtSec);
        }
      }
      if (
        eff.spreadGen < maxGen &&
        nowSec - eff.lastSpreadSec >= spreadInterval
      ) {
        eff.lastSpreadSec = nowSec;
        for (const [ox, oy] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ]) {
          const ntx = eff.tileX + ox;
          const nty = eff.tileY + oy;
          const nKey = `${ntx},${nty}`;
          if (state.terrainEffects[nKey] || newEffects[nKey]) continue;
          const surf = getEffectiveSurface(state, ntx, nty);
          if (surf === 'forest') {
            newEffects[nKey] = {
              id: `te_fire_sp_${Math.round(nowSec)}_${ntx}_${nty}`,
              tileX: ntx,
              tileY: nty,
              type: 'fire',
              materialBefore: surf,
              startSec: nowSec,
              endSec: nowSec + 30,
              spreadGen: eff.spreadGen + 1,
              lastSpreadSec: nowSec,
              sourceEventId: eff.sourceEventId,
            };
          }
        }
      }
    }

    newEffects[key] = eff;
  }
  state.terrainEffects = newEffects;

  // 3. Lawful timed source regeneration (NEVER respawns Final-72 Ragnarok Vaults!)
  for (const src of Object.values(state.sourceStocks)) {
    if (src.stock <= 0 && src.respawnAtElapsedSec !== null && nowSec >= src.respawnAtElapsedSec) {
      const sDef = SOURCES[src.defId];
      if (sDef && !sDef.onlyFinal72 && !sDef.mintsPhysicalCash && sDef.respawnSeconds !== null) {
        src.stock = src.maxStock;
        src.hitsRemaining = src.maxHits;
        src.depletedAtElapsedSec = null;
        src.respawnAtElapsedSec = null;
        src.crackedPenalty = false;
      }
    }
  }
}

function advancePlayerSurvival(
  state: GameState,
  dtSec: number,
  isOfflineReplay: boolean,
  nowUtcMs: number
): void {
  const p = state.actors.player;
  const tx = Math.floor(p.x / 16);
  const ty = Math.floor(p.y / 16);
  const surf = getEffectiveSurface(state, tx, ty);
  const sheltered = isPlayerSheltered(state);
  const nearWarmth = isNearWarmStation(state, p.x, p.y);
  const prot = computePlayerArmorAndResist(state);

  // Recover stamina & tick debuffs
  p.stamina = Math.min(BALANCE.player.maxStamina.value, p.stamina + 14 * dtSec);
  p.slowRemainingSec = Math.max(0, p.slowRemainingSec - dtSec);
  p.chillRemainingSec = Math.max(0, p.chillRemainingSec - dtSec);

  // Active cast windup -> commit -> recovery
  if (p.activeCast) {
    const castElapsed = state.clock.elapsedRealSeconds - p.activeCast.startedAtElapsedSec;
    if (!p.activeCast.committed && castElapsed >= p.activeCast.commitSec) {
      commitActiveCastNow(state, nowUtcMs);
    }
    if (p.activeCast && castElapsed >= p.activeCast.totalSec) {
      p.activeCast = null;
    }
  }

  // Hunger & Thirst metabolism
  const metabMult =
    sheltered && isOfflineReplay
      ? BALANCE.player.offlineShelterMetabolismMultiplier.value
      : sheltered
        ? 0.65
        : 1.0;
  const heatMult =
    surf === 'ash' || state.clock.weather === 'ash_wind'
      ? BALANCE.environment.heatThirstMultiplier.value * Math.max(0.4, 1 - prot.heatResist / 100)
      : 1.0;

  const hungerDrain = (BALANCE.player.hungerDrainPerRealHour.value / 3600) * metabMult * dtSec;
  const thirstDrain =
    (BALANCE.player.thirstDrainPerRealHour.value / 3600) * metabMult * heatMult * dtSec;

  p.hunger = Math.max(0, p.hunger - hungerDrain);
  p.thirst = Math.max(0, p.thirst - thirstDrain);

  // Starvation damage — obeys LOCKED_CANON 1-HP floor ONLY when offline AND inside valid shelter!
  if (p.hunger <= 0) {
    const starvDmg = (BALANCE.player.starvationDamagePerRealHour.value / 3600) * dtSec;
    if (isOfflineReplay && sheltered) {
      const floorHp = BALANCE.player.offlineShelterStarvationMinHp.value;
      if (p.hp > floorHp) {
        p.hp = Math.max(floorHp, p.hp - starvDmg);
      }
    } else {
      p.hp = Math.max(0, p.hp - starvDmg);
      if (p.hp <= 0) {
        handlePlayerDeathIfLethal(state, 'starvation', nowUtcMs);
        return;
      }
    }
  }

  // Dehydration damage (remains lethal if completely unhydrated in exposed heat)
  if (p.thirst <= 0 && !(isOfflineReplay && sheltered && p.hp <= 1 && surf !== 'ash')) {
    const dehydDmg = (BALANCE.player.dehydrationDamagePerRealHour.value / 3600) * dtSec;
    if (isOfflineReplay && sheltered) {
      p.hp = Math.max(1, p.hp - dehydDmg);
    } else {
      p.hp = Math.max(0, p.hp - dehydDmg);
      if (p.hp <= 0) {
        handlePlayerDeathIfLethal(state, 'dehydration', nowUtcMs);
        return;
      }
    }
  }

  // Cold hazard (Snow biome or Cold Snap weather without warmth or coat — ALWAYS LETHAL even offline!)
  const isColdEnv = surf === 'snow' || state.clock.weather === 'cold_snap';
  if (isColdEnv && !nearWarmth && !(sheltered && surf !== 'snow')) {
    const mitigation = Math.min(0.95, prot.coldResist / 100);
    if (mitigation < 0.7) {
      p.tempStress = Math.max(-100, p.tempStress - 12 * (1 - mitigation) * dtSec);
      const coldDmg =
        (BALANCE.environment.coldDamagePerMinuteExposed.value / 60) * (1 - mitigation) * dtSec;
      p.hp = Math.max(0, p.hp - coldDmg);
      if (p.hp <= 0) {
        handlePlayerDeathIfLethal(state, 'freezing exposure', nowUtcMs);
        return;
      }
    }
  } else {
    p.tempStress *= Math.max(0, 1 - 0.15 * dtSec);
  }

  // Radiation / Toxic hazard (ALWAYS LETHAL even offline if unprotected!)
  const activeEffect = state.terrainEffects[`${tx},${ty}`];
  if (surf === 'toxic' || activeEffect?.type === 'toxic_pool') {
    const radMit = Math.min(0.92, prot.radResist / 100);
    p.radDose = Math.min(100, p.radDose + 8 * (1 - radMit) * dtSec);
    const radDmg =
      (BALANCE.environment.radiationDamagePerMinuteExposed.value / 60) * (1 - radMit) * dtSec;
    p.hp = Math.max(0, p.hp - radDmg);
    if (p.hp <= 0) {
      handlePlayerDeathIfLethal(state, 'radiation/toxic exposure', nowUtcMs);
      return;
    }
  } else if (p.radDose > 0) {
    p.radDose = Math.max(0, p.radDose - 0.6 * dtSec);
  }

  // Standing in active fire tile (ALWAYS LETHAL!)
  if (activeEffect?.type === 'fire') {
    p.hp = Math.max(0, p.hp - 9 * dtSec);
    if (p.hp <= 0) {
      handlePlayerDeathIfLethal(state, 'wildfire burn', nowUtcMs);
      return;
    }
  }
}

function advanceTurrets(state: GameState, dtSec: number): void {
  for (const st of Object.values(state.structures)) {
    if (st.hp <= 0) continue;
    const sDef = STRUCTURES[st.defId];
    if (!sDef?.isTurret) continue;

    st.turretCooldownMs = Math.max(0, (st.turretCooldownMs ?? 0) - dtSec * 1000);
    if ((st.turretCooldownMs ?? 0) > 0) continue;
    if (!isTilePowered(state, st.tileX, st.tileY)) continue;

    // Must consume legitimate physical turret_ammo stored inside turret container
    const ammoItem = listStructureItems(state, st.id).find((i) => i.defId === 'turret_ammo');
    if (!ammoItem || ammoItem.count <= 0) continue;

    const sx = st.tileX * 16 + 8;
    const sy = st.tileY * 16 + 8;
    const range = sDef.turretRangePx ?? 115;

    const target = state.actors.enemies.find(
      (e) => e.alive && distPx(sx, sy, e.x, e.y) <= range && hasLineOfSight(state, sx, sy, e.x, e.y, range)
    );
    if (!target) continue;

    ammoItem.count -= 1;
    if (ammoItem.count <= 0) delete state.items[ammoItem.instanceId];
    st.turretCooldownMs = sDef.turretCooldownMs ?? 900;

    const eDef = ENEMIES[target.defId];
    const dmg = Math.max(1, (sDef.turretDamage ?? 18) - (eDef?.armor ?? 0));
    target.hp = Math.max(0, target.hp - dmg);
    state.vfxCues.push({
      id: `vfx_tur_${state.clock.elapsedRealSeconds}_${st.id}`,
      kind: 'line_ray',
      x: sx,
      y: sy,
      targetX: target.x,
      targetY: target.y,
      color: '#ffd166',
      createdAtSec: state.clock.elapsedRealSeconds,
      durationSec: 0.2,
    });
    if (target.hp <= 0) {
      target.alive = false;
      target.respawnAtSec = state.clock.elapsedRealSeconds + 14400;
    }
  }
}

function advanceCreaturesAndElders(state: GameState, dtSec: number, nowUtcMs: number): void {
  const p = state.actors.player;
  const prot = computePlayerArmorAndResist(state);
  const isNight = state.clock.timeOfDay01 < 0.22 || state.clock.timeOfDay01 > 0.8;
  const sightDayFactor = isNight ? 0.78 : 1.0;

  // Optimize active creature simulation radius (within 36 tiles of player or actively tracking a footprint trail)
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive) {
      if (enemy.respawnAtSec !== null && state.clock.elapsedRealSeconds >= enemy.respawnAtSec) {
        // Habitat respawn only when player isn't standing right on habitat spawn
        if (distPx(p.x, p.y, enemy.homeX, enemy.homeY) > 160) {
          enemy.alive = true;
          enemy.x = enemy.homeX;
          enemy.y = enemy.homeY;
          enemy.hp = enemy.maxHp;
          enemy.aiState = 'patrol';
          enemy.respawnAtSec = null;
        }
      }
      continue;
    }

    const dPlayer = distPx(enemy.x, enemy.y, p.x, p.y);
    if (dPlayer > 580 && enemy.aiState === 'patrol') continue;

    const eDef = ENEMIES[enemy.defId];
    if (!eDef) continue;

    enemy.cooldownRemainingMs = Math.max(0, enemy.cooldownRemainingMs - dtSec * 1000);

    // 1. Handle active attack windup telegraph -> committed hit
    if (enemy.aiState === 'attack_windup') {
      enemy.windupRemainingMs -= dtSec * 1000;
      if (enemy.windupRemainingMs <= 0) {
        enemy.cooldownRemainingMs = eDef.cooldownMs;
        if (enemy.windupTargetStructureId) {
          const st = state.structures[enemy.windupTargetStructureId];
          if (st && st.hp > 0 && distPx(enemy.x, enemy.y, st.tileX * 16 + 8, st.tileY * 16 + 8) <= eDef.attackRangePx + 14) {
            const wallDmg = Math.round(eDef.attackDamage * (eDef.wallDamageMultiplier ?? 1.0));
            st.hp = Math.max(0, st.hp - wallDmg);
            if (st.hp <= 0) {
              delete state.structures[st.id];
            }
          }
          enemy.windupTargetStructureId = null;
          enemy.aiState = 'follow_trail';
        } else if (distPx(enemy.x, enemy.y, p.x, p.y) <= eDef.attackRangePx + 10) {
          const dmg = Math.max(1, eDef.attackDamage - prot.armor);
          p.hp = Math.max(0, p.hp - dmg);
          if (eDef.inflictsSlowSec) p.slowRemainingSec = Math.max(p.slowRemainingSec, eDef.inflictsSlowSec);
          if (eDef.inflictsRadDose) p.radDose = Math.min(100, p.radDose + eDef.inflictsRadDose);
          state.vfxCues.push({
            id: `vfx_ehit_${state.clock.elapsedRealSeconds}_${enemy.id}`,
            kind: 'floating_text',
            x: p.x,
            y: p.y - 12,
            color: '#ff4d6d',
            text: `-${dmg}`,
            createdAtSec: state.clock.elapsedRealSeconds,
            durationSec: 0.9,
          });
          handlePlayerDeathIfLethal(state, eDef.name, nowUtcMs);
          if (state.actors.player.hp <= 0) return;
          enemy.aiState = 'pursue_player';
        } else {
          enemy.aiState = 'pursue_player';
        }
      }
      continue;
    }

    // 2. Direct player sight check (strictly requires LOS — NEVER sees through walls!)
    const effSight = eDef.sightRangePx * sightDayFactor;
    const seesPlayer = dPlayer <= effSight && hasLineOfSight(state, enemy.x, enemy.y, p.x, p.y, effSight);

    if (seesPlayer) {
      enemy.aiState = 'pursue_player';
      enemy.lastSeenPlayerPos = { x: p.x, y: p.y };
      enemy.lostTimerSec = 5.0;

      if (dPlayer <= eDef.attackRangePx && enemy.cooldownRemainingMs <= 0) {
        enemy.aiState = 'attack_windup';
        enemy.windupRemainingMs = eDef.windupMs;
        enemy.windupTargetPos = { x: p.x, y: p.y };
        enemy.windupTargetStructureId = null;
        continue;
      }
    } else if (enemy.aiState === 'pursue_player') {
      enemy.lostTimerSec -= dtSec;
      if (enemy.lostTimerSec <= 0) {
        enemy.aiState = 'search_last_known';
      }
    }

    // 3. Footprint Trail Sensing & Contiguous Following (C08: NO GPS awareness of player home!)
    if (!seesPlayer && (enemy.aiState === 'patrol' || enemy.aiState === 'search_last_known')) {
      // Can only detect an existing, non-expired footprint within physical traceSenseRangePx + LOS
      const sensedFp = state.footprints.find((fp) => {
        const fx = fp.tileX * 16 + 8;
        const fy = fp.tileY * 16 + 8;
        return (
          distPx(enemy.x, enemy.y, fx, fy) <= eDef.traceSenseRangePx &&
          hasLineOfSight(state, enemy.x, enemy.y, fx, fy, eDef.traceSenseRangePx)
        );
      });
      if (sensedFp) {
        enemy.aiState = 'follow_trail';
        enemy.followedFootprintId = sensedFp.id;
        enemy.trailTargetPos = { x: sensedFp.tileX * 16 + 8, y: sensedFp.tileY * 16 + 8 };
      } else if (enemy.aiState === 'search_last_known') {
        enemy.aiState = 'return_habitat';
        enemy.lastSeenPlayerPos = null;
      }
    }

    if (enemy.aiState === 'follow_trail') {
      const curFp = state.footprints.find((f) => f.id === enemy.followedFootprintId);
      if (!curFp) {
        // Trail segment eroded or washed away by rain -> monster loses trail and CANNOT know unseen home!
        enemy.followedFootprintId = null;
        enemy.trailTargetPos = null;
        enemy.aiState = 'return_habitat';
      } else {
        const targetX = curFp.tileX * 16 + 8;
        const targetY = curFp.tileY * 16 + 8;
        enemy.trailTargetPos = { x: targetX, y: targetY };

        if (distPx(enemy.x, enemy.y, targetX, targetY) <= 18) {
          // Look ONLY for contiguous newer footprint segment!
          const nextFp = state.footprints.find(
            (f) =>
              f.prevId === curFp.id ||
              (f.createdAtElapsedSec > curFp.createdAtElapsedSec &&
                Math.hypot(f.tileX - curFp.tileX, f.tileY - curFp.tileY) <= 1.6)
          );
          if (nextFp) {
            enemy.followedFootprintId = nextFp.id;
            enemy.trailTargetPos = { x: nextFp.tileX * 16 + 8, y: nextFp.tileY * 16 + 8 };
          } else {
            // End of trail reached: check if a blocking player wall/door is physically right ahead within attack reach
            const blockingWall = eDef.canAttackWalls
              ? Object.values(state.structures).find(
                  (st) =>
                    st.ownerId === 'player' &&
                    st.hp > 0 &&
                    (STRUCTURES[st.defId]?.blocksMovement || STRUCTURES[st.defId]?.isDoor) &&
                    distPx(enemy.x, enemy.y, st.tileX * 16 + 8, st.tileY * 16 + 8) <=
                      eDef.attackRangePx + 14
                )
              : undefined;

            if (blockingWall && enemy.cooldownRemainingMs <= 0) {
              enemy.aiState = 'attack_windup';
              enemy.windupRemainingMs = eDef.windupMs;
              enemy.windupTargetStructureId = blockingWall.id;
              continue;
            } else if (!blockingWall) {
              enemy.followedFootprintId = null;
              enemy.trailTargetPos = null;
              enemy.aiState = 'return_habitat';
            }
          }
        }
      }
    }

    // 4. Movement execution using A* / local collision
    let goalX = enemy.homeX;
    let goalY = enemy.homeY;
    if (enemy.aiState === 'pursue_player' && enemy.lastSeenPlayerPos) {
      goalX = enemy.lastSeenPlayerPos.x;
      goalY = enemy.lastSeenPlayerPos.y;
    } else if (enemy.aiState === 'follow_trail' && enemy.trailTargetPos) {
      goalX = enemy.trailTargetPos.x;
      goalY = enemy.trailTargetPos.y;
    } else if (enemy.aiState === 'patrol') {
      enemy.patrolAngle += dtSec * 0.6;
      goalX = enemy.homeX + Math.cos(enemy.patrolAngle) * 28;
      goalY = enemy.homeY + Math.sin(enemy.patrolAngle) * 28;
    } else if (enemy.aiState === 'return_habitat') {
      if (distPx(enemy.x, enemy.y, enemy.homeX, enemy.homeY) <= 14) {
        enemy.aiState = 'patrol';
      }
    }

    moveActorTowards(state, enemy, goalX, goalY, eDef.speedPxPerSec, dtSec, eDef.canAttackWalls ? eDef : undefined);
  }

  // 5. Optional 6 Elder Boss AI (engaged ONLY when player enters their physical sanctuary!)
  for (const elder of state.actors.elders) {
    if (!elder.alive) continue;
    const bDef = BOSSES[elder.defId];
    const stats = elder.form === 'awakened' ? bDef.awakened : bDef.latent;
    elder.cooldownRemainingMs = Math.max(0, elder.cooldownRemainingMs - dtSec * 1000);

    const dPlayer = distPx(elder.x, elder.y, p.x, p.y);
    const dHome = distPx(elder.x, elder.y, elder.homeX, elder.homeY);

    if (elder.aiState === 'telegraph_windup') {
      elder.windupRemainingMs -= dtSec * 1000;
      if (elder.windupRemainingMs <= 0 && elder.telegraphPos) {
        // Commit Elder telegraphed slam at exact telegraph circle!
        if (distPx(p.x, p.y, elder.telegraphPos.x, elder.telegraphPos.y) <= elder.telegraphPos.radiusPx) {
          const dmg = Math.max(2, stats.attackDamage - prot.armor);
          p.hp = Math.max(0, p.hp - dmg);
          state.vfxCues.push({
            id: `vfx_eld_${state.clock.elapsedRealSeconds}_${elder.id}`,
            kind: 'aoe_blast',
            x: elder.telegraphPos.x,
            y: elder.telegraphPos.y,
            radiusPx: elder.telegraphPos.radiusPx,
            color: '#e63946',
            createdAtSec: state.clock.elapsedRealSeconds,
            durationSec: 0.4,
          });
          handlePlayerDeathIfLethal(state, `${bDef.name} (${elder.form})`, nowUtcMs);
          if (state.actors.player.hp <= 0) return;
        }
        elder.telegraphPos = null;
        elder.cooldownRemainingMs = stats.cooldownMs;
        elder.aiState = 'pursue';
      }
      continue;
    }

    // Leash radius: player can always retreat cleanly from an optional Elder!
    if (dPlayer <= 155 && dHome <= 220 && hasLineOfSight(state, elder.x, elder.y, p.x, p.y, 170)) {
      elder.aiState = 'pursue';
      if (dPlayer <= stats.telegraphRadiusPx + 14 && elder.cooldownRemainingMs <= 0) {
        elder.aiState = 'telegraph_windup';
        elder.windupRemainingMs = stats.windupMs;
        elder.telegraphPos = {
          x: p.x,
          y: p.y,
          radiusPx: stats.telegraphRadiusPx,
        };
        continue;
      }
      moveActorTowards(state, elder, p.x, p.y, stats.speedPxPerSec, dtSec);
    } else if (dHome > 10) {
      elder.aiState = 'return';
      elder.telegraphPos = null;
      moveActorTowards(state, elder, elder.homeX, elder.homeY, stats.speedPxPerSec * 1.1, dtSec);
    } else {
      elder.aiState = 'idle';
    }
  }
}

function moveActorTowards(
  state: GameState,
  actor: { x: number; y: number; aiState?: string; windupRemainingMs?: number; windupTargetStructureId?: string | null; cooldownRemainingMs?: number },
  goalX: number,
  goalY: number,
  speedPxPerSec: number,
  dtSec: number,
  wallAttackerDef?: { attackRangePx: number; windupMs: number }
): void {
  const dist = distPx(actor.x, actor.y, goalX, goalY);
  if (dist < 4) return;

  let nextTargetX = goalX;
  let nextTargetY = goalY;

  const curTx = Math.floor(actor.x / 16);
  const curTy = Math.floor(actor.y / 16);
  const goalTx = Math.floor(goalX / 16);
  const goalTy = Math.floor(goalY / 16);

  // If direct step is blocked, query rot-js A* pathfinder around walls/doors!
  const directAngle = Math.atan2(goalY - actor.y, goalX - actor.x);
  const probeX = actor.x + Math.cos(directAngle) * 10;
  const probeY = actor.y + Math.sin(directAngle) * 10;
  if (!isTileWalkable(state, Math.floor(probeX / 16), Math.floor(probeY / 16))) {
    const path = findPathTiles(state, curTx, curTy, goalTx, goalTy, { maxExpanded: 160 });
    if (path && path.length >= 2) {
      nextTargetX = path[1].x * 16 + 8;
      nextTargetY = path[1].y * 16 + 8;
    } else if (wallAttackerDef && (actor.cooldownRemainingMs ?? 0) <= 0) {
      // Blocked by closed door/wall on direct path -> attack adjacent blocking player structure if allowed
      const adjWall = Object.values(state.structures).find(
        (st) =>
          st.ownerId === 'player' &&
          st.hp > 0 &&
          (STRUCTURES[st.defId]?.blocksMovement || (STRUCTURES[st.defId]?.isDoor && !st.isOpen)) &&
          distPx(actor.x, actor.y, st.tileX * 16 + 8, st.tileY * 16 + 8) <=
            wallAttackerDef.attackRangePx + 14
      );
      if (adjWall && 'windupTargetStructureId' in actor) {
        actor.aiState = 'attack_windup';
        actor.windupRemainingMs = wallAttackerDef.windupMs;
        actor.windupTargetStructureId = adjWall.id;
      }
      return;
    }
  }

  const ang = Math.atan2(nextTargetY - actor.y, nextTargetX - actor.x);
  const step = Math.min(dist, speedPxPerSec * dtSec);
  const nx = actor.x + Math.cos(ang) * step;
  const ny = actor.y + Math.sin(ang) * step;

  if (isTileWalkable(state, Math.floor(nx / 16), Math.floor(actor.y / 16))) {
    actor.x = nx;
  }
  if (isTileWalkable(state, Math.floor(actor.x / 16), Math.floor(ny / 16))) {
    actor.y = ny;
  }
}

/**
 * Online simulation step (called by main loop with bounded real dtSec).
 */
export function stepSimulation(
  currentState: GameState,
  dtSec: number,
  nowUtcMs = Date.now(),
  isOfflineReplay = false
): GameState {
  if (currentState.run.status !== 'active' || dtSec <= 0) {
    return currentState;
  }

  const state: GameState = isOfflineReplay ? currentState : structuredClone(currentState);
  advanceClockAndPhase(state, dtSec, nowUtcMs);
  if (state.run.status !== 'active') {
    return state;
  }

  advanceStationsAndJobs(state, dtSec);
  advanceEnvironmentAndTraces(state, dtSec);
  advancePlayerSurvival(state, dtSec, isOfflineReplay, nowUtcMs);
  if (state.run.status !== 'active') {
    return state;
  }
  advanceTurrets(state, dtSec);
  advanceCreaturesAndElders(state, dtSec, nowUtcMs);

  // Clean expired VFX cues
  state.vfxCues = state.vfxCues.filter(
    (c) => state.clock.elapsedRealSeconds - c.createdAtSec <= c.durationSec
  );

  return state;
}

/**
 * Deterministic Bounded Chronological Offline Event Replay (§6, K8, C06, C09, C14).
 * Reconstructs exact causal event ordering (fuel exhaustion, job completion, weather front,
 * source recovery, trace decay, shelter starvation floor, hazards) without frame-by-frame lag.
 */
export function catchUpOffline(
  savedState: GameState,
  reopenedUtcMs = Date.now(),
  explicitOfflineSeconds?: number
): { state: GameState; settledSeconds: number; summaryLog: string[] } {
  if (savedState.run.status !== 'active') {
    return { state: savedState, settledSeconds: 0, summaryLog: [] };
  }

  const targetElapsed =
    explicitOfflineSeconds !== undefined
      ? savedState.clock.elapsedRealSeconds + Math.max(0, explicitOfflineSeconds)
      : Math.max(
          savedState.clock.elapsedRealSeconds,
          (reopenedUtcMs - savedState.clock.startUtcMs) / 1000 + savedState.clock.qaOffsetSeconds
        );

  const totalDelta = Math.min(
    BALANCE.clock.maxRunRealSeconds.value - savedState.clock.elapsedRealSeconds + 1,
    Math.max(0, targetElapsed - savedState.clock.elapsedRealSeconds)
  );

  if (totalDelta < 1.0) {
    return { state: savedState, settledSeconds: 0, summaryLog: [] };
  }

  const state = structuredClone(savedState);
  const startHp = state.actors.player.hp;
  const completedBefore = Object.values(state.jobs).filter(
    (j) => j.status === 'completed_unclaimed'
  ).length;

  let remaining = totalDelta;
  let simUtc = savedState.clock.lastSimulatedUtcMs;
  let steps = 0;
  const maxBatches = 1500;

  while (remaining > 0.001 && state.run.status === 'active' && steps < maxBatches) {
    steps++;
    const nowSec = state.clock.elapsedRealSeconds;

    // Compute next exact causal breakpoint timestamp!
    let nextEventDelta = Math.min(remaining, Math.max(15, totalDelta / 400));

    // Weather change breakpoint
    const toWeather = state.clock.nextWeatherFrontSec - nowSec;
    if (toWeather > 0.05) nextEventDelta = Math.min(nextEventDelta, toWeather);

    // Fuel exhaustion breakpoints on active stations
    for (const st of Object.values(state.structures)) {
      if (st.hp > 0 && st.fuelRemainingSec > 0.05) {
        nextEventDelta = Math.min(nextEventDelta, st.fuelRemainingSec);
      }
    }

    // Active job completion breakpoints
    for (const job of Object.values(state.jobs)) {
      if (job.status === 'active') {
        const remWork = job.totalWorkSec - job.progressSec;
        if (remWork > 0.05) nextEventDelta = Math.min(nextEventDelta, remWork);
      }
    }

    // Phase boundary breakpoints
    for (const boundary of [
      BALANCE.clock.hazardIntensifyStartSeconds.value,
      BALANCE.clock.elderAwakenStartSeconds.value,
      BALANCE.clock.maxRunRealSeconds.value,
    ]) {
      if (boundary > nowSec + 0.05) {
        nextEventDelta = Math.min(nextEventDelta, boundary - nowSec);
      }
    }

    const dt = Math.max(0.05, Math.min(remaining, nextEventDelta));
    simUtc += dt * 1000;
    stepSimulation(state, dt, Math.round(simUtc), true);
    remaining -= dt;
  }

  state.clock.lastSimulatedUtcMs = reopenedUtcMs;
  const completedAfter = Object.values(state.jobs).filter(
    (j) => j.status === 'completed_unclaimed'
  ).length;
  const pausedFuel = Object.values(state.jobs).filter((j) => j.status === 'paused_no_fuel').length;

  const summaryLog: string[] = [
    `Settled ${Math.round(totalDelta)}s (${(totalDelta / 3600).toFixed(2)}h) chronologically across ${steps} event intervals.`,
  ];
  if (completedAfter > completedBefore) {
    summaryLog.push(`${completedAfter - completedBefore} station job(s) finished lawfully.`);
  }
  if (pausedFuel > 0) {
    summaryLog.push(`${pausedFuel} job(s) paused at exact fuel exhaustion point.`);
  }
  if (state.actors.player.hp !== startHp) {
    summaryLog.push(`HP changed ${Math.round(startHp)} -> ${Math.round(state.actors.player.hp)}.`);
  }

  state.revision += 1;
  state.eventReceipts.push({
    receiptId: nextDeterministicId('rcpt_off', state.run.runId, state.revision),
    intentId: 'offline_chronological_catchup',
    contractEdge: 'C06/C09/C14',
    runId: state.run.runId,
    revision: state.revision,
    timestampUtcMs: reopenedUtcMs,
    elapsedSec: Math.round(state.clock.elapsedRealSeconds * 100) / 100,
    actorId: 'system_clock',
    summary: summaryLog.join(' '),
    details: { settledSeconds: Math.round(totalDelta), batches: steps },
  });

  assertCustodyInvariants(state);
  return { state, settledSeconds: totalDelta, summaryLog };
}
