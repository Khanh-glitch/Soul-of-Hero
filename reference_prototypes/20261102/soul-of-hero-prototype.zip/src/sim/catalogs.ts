import { z } from 'zod';
import balanceRaw from '../data/balance.prototype.v1.json';
import itemsRaw from '../data/items.json';
import recipesRaw from '../data/recipes.json';
import sourcesRaw from '../data/sources.json';
import structuresRaw from '../data/structures.json';
import enemiesRaw from '../data/enemies.json';
import bossesRaw from '../data/bosses.json';
import skillsRaw from '../data/skills.json';
import poisRaw from '../data/pois.json';

const BalanceFieldSchema = z.object({
  value: z.unknown(),
  unit: z.string(),
  status: z.enum(['LOCKED_CANON', 'PROTOTYPE_TUNING', 'PROPOSED_MECHANISM', 'REQUIRES_SOURCE']),
  dependencies: z.array(z.string()),
  rationale: z.string(),
});

export const BalanceCatalogSchema = z.object({
  schemaVersion: z.literal('balance.prototype.v1'),
  clock: z.record(z.string(), BalanceFieldSchema),
  world: z.record(z.string(), BalanceFieldSchema),
  player: z.record(z.string(), BalanceFieldSchema),
  environment: z.record(z.string(), BalanceFieldSchema),
  territoryAndBuild: z.record(z.string(), BalanceFieldSchema),
  researchAndCores: z.record(z.string(), BalanceFieldSchema),
  freight: z.record(z.string(), BalanceFieldSchema),
  ragnarokEconomy: z.record(z.string(), BalanceFieldSchema),
  scoring: z.record(z.string(), BalanceFieldSchema),
});

export interface ItemDef {
  id: string;
  name: string;
  category: string;
  materialFamily: string;
  tags: string[];
  capabilities: string[];
  uniqueInstance?: boolean;
  equipSlot?: 'hand' | 'body' | 'utility';
  stackLimit: number;
  massKg: number;
  fuelSeconds?: number;
  maxDurability?: number;
  wearPerUse?: number;
  maxCharges?: number;
  studyEligible?: boolean;
  studyRequiresMinCharges?: number;
  studyRecipeId?: string;
  blueprintRecipeId?: string;
  deployVehicleType?: 'hand_cart';
  deployStructureId?: string;
  ammoItemId?: string;
  visionBonusTiles?: number;
  consumeEffects?: {
    hp?: number;
    hunger?: number;
    thirst?: number;
    tempRelief?: number;
    clearRadiation?: number;
  };
  weaponProfile?: {
    skillId: string;
    actorDamage: number;
    rangePx: number;
    cooldownMs: number;
    knockbackPx: number;
  };
  harvestProfile?: Record<string, number>;
  armorProfile?: {
    armor: number;
    coldResist: number;
    heatResist: number;
    radResist: number;
  };
  sprite: string;
  description: string;
}

export interface RecipeDef {
  id: string;
  name: string;
  station: string;
  starterKnown: boolean;
  researchPool?: string;
  directedSparesCost?: number;
  specimenOnly?: boolean;
  specimenItemId?: string;
  workSeconds: number;
  fuelSecondsRequired: number;
  waterRequired?: number;
  powerRequired: boolean;
  inputs: { itemId: string; count: number }[];
  outputs: { itemId: string; count: number }[];
}

export interface SourceDef {
  id: string;
  name: string;
  economyClass: 'NATURAL' | 'HUMAN_MADE' | 'RARE';
  materialType: string;
  flammable: boolean;
  maxHits: number;
  initialStock: number;
  respawnSeconds: number | null;
  blocksMovement: boolean;
  interactLoot?: boolean;
  requiresUnlockedPoiId?: boolean;
  onlyFinal72?: boolean;
  mintsPhysicalCash?: boolean;
  sprite: string;
  yieldPoolOneOf?: string[];
  yieldTable: { itemId: string; baseCount: number; chance: number }[];
}

export interface StructureDef {
  id: string;
  name: string;
  category: string;
  maxHp: number;
  blocksMovement: boolean;
  blocksSight: boolean;
  isFloor?: boolean;
  isDoor?: boolean;
  isRoof?: boolean;
  isTerritoryClaim?: boolean;
  isBed?: boolean;
  isTurret?: boolean;
  isEscrowChest?: boolean;
  flammable?: boolean;
  requiresOwnedTerritory: boolean;
  requiresPowerToOperate?: boolean;
  powerDrawWatts?: number;
  powerSupplyWatts?: number;
  powerRadiusTiles?: number;
  outdoorOnly?: boolean;
  usesFuel?: boolean;
  warmthRadiusTiles?: number;
  lightRadiusTiles?: number;
  stationType?: string;
  containerSlots?: number;
  turretRangePx?: number;
  turretDamage?: number;
  turretCooldownMs?: number;
  deployFromItemOnly?: string;
  cost: { itemId: string; count: number }[];
  sprite: string;
  description: string;
}

export interface EnemyDef {
  id: string;
  name: string;
  habitatBiomes: string[];
  maxHp: number;
  armor: number;
  speedPxPerSec: number;
  sightRangePx: number;
  traceSenseRangePx: number;
  attackDamage: number;
  wallDamageMultiplier?: number;
  attackRangePx: number;
  windupMs: number;
  cooldownMs: number;
  inflictsSlowSec?: number;
  inflictsRadDose?: number;
  canAttackWalls: boolean;
  sprite: string;
  drops: { itemId: string; count: number; chance: number }[];
}

export interface BossFormStats {
  maxHp: number;
  armor: number;
  speedPxPerSec: number;
  attackDamage: number;
  telegraphRadiusPx: number;
  windupMs: number;
  cooldownMs: number;
  worldEffect?: string;
}

export interface BossDef {
  id: string;
  name: string;
  title: string;
  biome: string;
  stoneItemId: string;
  goldArtStatus: string;
  latent: BossFormStats;
  awakened: BossFormStats;
  sprite: string;
}

export interface SkillDef {
  id: string;
  name: string;
  driverType: 'melee_arc' | 'line_ray' | 'aoe_blast' | 'self_aura';
  goldArtStatus: string;
  windupMs: number;
  commitMs: number;
  recoveryMs: number;
  arcDegrees?: number;
  aoeRadiusPx?: number;
  mineralNodeBonusDamage?: number;
  healHp?: number;
  clearRad?: number;
  spendsCoreCharge: boolean;
  worldMutation: {
    ignitesFlammable?: boolean;
    cracksMineralYieldPenalty?: number;
    meltsIce?: boolean;
    freezesWaterToIce?: boolean;
    extinguishesFire?: boolean;
    chillsActorsSec?: number;
    energizesPoiRelaySec?: number;
    durationSeconds?: number;
  } | null;
  vfxColor: string;
}

export interface VendorOfferDef {
  id: string;
  itemId: string;
  count: number;
  currency: 'physical_or_profile_cash' | 'profile_secured_cash';
  price: number;
  stock: number;
  status: string;
}

export interface PoiDef {
  id: string;
  name: string;
  archetype: string;
  gateType: 'open' | 'fuse' | 'power' | 'keycard' | 'keycard_and_power' | 'hazard_and_fuse';
  hazardType?: string;
  exteriorSources: string[];
  deepSources: string[];
  hasFinal72Vault: boolean;
  nonBossFinal72Eligible?: boolean;
  isVendor?: boolean;
  isEvacuationSite?: boolean;
  vendorCatalog?: VendorOfferDef[];
  description: string;
}

// Validate balance catalog at startup so malformed tuning fails loudly
BalanceCatalogSchema.parse(balanceRaw);

export const BALANCE = balanceRaw;
export const ITEMS_LIST = itemsRaw as ItemDef[];
export const RECIPES_LIST = recipesRaw as RecipeDef[];
export const SOURCES_LIST = sourcesRaw as SourceDef[];
export const STRUCTURES_LIST = structuresRaw as StructureDef[];
export const ENEMIES_LIST = enemiesRaw as EnemyDef[];
export const BOSSES_LIST = bossesRaw as BossDef[];
export const SKILLS_LIST = skillsRaw as SkillDef[];
export const POIS_LIST = poisRaw as PoiDef[];

export const ITEMS: Record<string, ItemDef> = Object.fromEntries(ITEMS_LIST.map((x) => [x.id, x]));
export const RECIPES: Record<string, RecipeDef> = Object.fromEntries(
  RECIPES_LIST.map((x) => [x.id, x])
);
export const SOURCES: Record<string, SourceDef> = Object.fromEntries(
  SOURCES_LIST.map((x) => [x.id, x])
);
export const STRUCTURES: Record<string, StructureDef> = Object.fromEntries(
  STRUCTURES_LIST.map((x) => [x.id, x])
);
export const ENEMIES: Record<string, EnemyDef> = Object.fromEntries(
  ENEMIES_LIST.map((x) => [x.id, x])
);
export const BOSSES: Record<string, BossDef> = Object.fromEntries(
  BOSSES_LIST.map((x) => [x.id, x])
);
export const SKILLS: Record<string, SkillDef> = Object.fromEntries(
  SKILLS_LIST.map((x) => [x.id, x])
);
export const POIS: Record<string, PoiDef> = Object.fromEntries(POIS_LIST.map((x) => [x.id, x]));
