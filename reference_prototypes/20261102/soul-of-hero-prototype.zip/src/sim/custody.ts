import { BALANCE, ITEMS, STRUCTURES } from './catalogs';
import { nextDeterministicId } from './rng';
import type {
  ContainerPort,
  CustodyLocation,
  EquipSlot,
  GameState,
  ItemInstance,
} from './types';

export const PLAYER_BAG_SLOTS = 20;
export const PLAYER_QUICKBAR_SLOTS = 8;

export function locationsEqual(a: CustodyLocation, b: CustodyLocation): boolean {
  if (a.kind !== b.kind) return false;
  switch (a.kind) {
    case 'player_bag':
      return a.slotIndex === (b as typeof a).slotIndex;
    case 'player_quickbar':
      return a.slotIndex === (b as typeof a).slotIndex;
    case 'player_equip':
      return a.equipSlot === (b as typeof a).equipSlot;
    case 'structure_container': {
      const tb = b as typeof a;
      return (
        a.structureId === tb.structureId && a.port === tb.port && a.slotIndex === tb.slotIndex
      );
    }
    case 'vehicle_cargo': {
      const tb = b as typeof a;
      return a.vehicleId === tb.vehicleId && a.slotIndex === tb.slotIndex;
    }
    case 'death_bag': {
      const tb = b as typeof a;
      return a.bagId === tb.bagId && a.slotIndex === tb.slotIndex;
    }
    case 'ground_drop': {
      const tb = b as typeof a;
      return a.x === tb.x && a.y === tb.y;
    }
  }
}

export function isPlayerHeldLocation(loc: CustodyLocation): boolean {
  return (
    loc.kind === 'player_bag' || loc.kind === 'player_quickbar' || loc.kind === 'player_equip'
  );
}

export function findItemAtLocation(state: GameState, loc: CustodyLocation): ItemInstance | null {
  for (const item of Object.values(state.items)) {
    if (locationsEqual(item.location, loc)) {
      return item;
    }
  }
  return null;
}

export function listPlayerHeldItems(state: GameState): ItemInstance[] {
  return Object.values(state.items).filter((i) => isPlayerHeldLocation(i.location));
}

export function getEquippedItem(state: GameState, slot: EquipSlot): ItemInstance | null {
  return (
    Object.values(state.items).find(
      (i) => i.location.kind === 'player_equip' && i.location.equipSlot === slot
    ) ?? null
  );
}

export function computePlayerCarriedMassKg(state: GameState): number {
  let mass = 0;
  for (const item of Object.values(state.items)) {
    if (isPlayerHeldLocation(item.location)) {
      const def = ITEMS[item.defId];
      if (def) {
        mass += def.massKg * item.count;
      }
    }
  }
  return Math.round(mass * 100) / 100;
}

export function computeVehicleCargoMassKg(state: GameState, vehicleId: string): number {
  let mass = 0;
  for (const item of Object.values(state.items)) {
    if (item.location.kind === 'vehicle_cargo' && item.location.vehicleId === vehicleId) {
      const def = ITEMS[item.defId];
      if (def) {
        mass += def.massKg * item.count;
      }
    }
  }
  return Math.round(mass * 100) / 100;
}

export function countPlayerItem(state: GameState, defId: string): number {
  let sum = 0;
  for (const item of Object.values(state.items)) {
    if (item.defId === defId && isPlayerHeldLocation(item.location)) {
      sum += item.count;
    }
  }
  return sum;
}

export function findOpenPlayerSlot(state: GameState, preferQuickbar = false): CustodyLocation | null {
  if (preferQuickbar) {
    for (let s = 0; s < PLAYER_QUICKBAR_SLOTS; s++) {
      const loc: CustodyLocation = { kind: 'player_quickbar', slotIndex: s };
      if (!findItemAtLocation(state, loc)) return loc;
    }
  }
  for (let s = 0; s < PLAYER_BAG_SLOTS; s++) {
    const loc: CustodyLocation = { kind: 'player_bag', slotIndex: s };
    if (!findItemAtLocation(state, loc)) return loc;
  }
  if (!preferQuickbar) {
    for (let s = 0; s < PLAYER_QUICKBAR_SLOTS; s++) {
      const loc: CustodyLocation = { kind: 'player_quickbar', slotIndex: s };
      if (!findItemAtLocation(state, loc)) return loc;
    }
  }
  return null;
}

export function findOpenStructurePortSlot(
  state: GameState,
  structureId: string,
  port: ContainerPort = 'storage'
): CustodyLocation | null {
  const st = state.structures[structureId];
  if (!st) return null;
  const def = STRUCTURES[st.defId];
  const maxSlots = def?.containerSlots ?? 6;
  for (let s = 0; s < maxSlots; s++) {
    const loc: CustodyLocation = {
      kind: 'structure_container',
      structureId,
      port,
      slotIndex: s,
    };
    if (!findItemAtLocation(state, loc)) return loc;
  }
  return null;
}

export function findOpenVehicleSlot(state: GameState, vehicleId: string): CustodyLocation | null {
  const maxSlots = BALANCE.freight.handCartSlots.value;
  for (let s = 0; s < maxSlots; s++) {
    const loc: CustodyLocation = { kind: 'vehicle_cargo', vehicleId, slotIndex: s };
    if (!findItemAtLocation(state, loc)) return loc;
  }
  return null;
}

/**
 * Adds newly minted items from an authorized source/job receipt into player custody
 * (or drops excess onto ground at player position if player bags are completely full).
 */
export function grantItemsToPlayerOrGround(
  state: GameState,
  defId: string,
  count: number,
  provenanceReceiptId: string,
  subIndexOffset = 0,
  preferQuickbar = false
): { grantedIds: string[]; subIndexNext: number } {
  const def = ITEMS[defId];
  if (!def || count <= 0) return { grantedIds: [], subIndexNext: subIndexOffset };

  let remaining = count;
  let subIdx = subIndexOffset;
  const grantedIds: string[] = [];

  // Stack into existing player stacks first if stackable and not uniqueInstance
  if (!def.uniqueInstance && def.stackLimit > 1) {
    for (const existing of Object.values(state.items)) {
      if (remaining <= 0) break;
      if (
        existing.defId === defId &&
        (existing.location.kind === 'player_bag' || existing.location.kind === 'player_quickbar') &&
        existing.count < def.stackLimit
      ) {
        const space = def.stackLimit - existing.count;
        const add = Math.min(space, remaining);
        existing.count += add;
        remaining -= add;
        grantedIds.push(existing.instanceId);
      }
    }
  }

  while (remaining > 0) {
    const batchCount = def.uniqueInstance ? 1 : Math.min(remaining, def.stackLimit);
    remaining -= batchCount;
    const openLoc =
      findOpenPlayerSlot(state, preferQuickbar) ?? {
        kind: 'ground_drop',
        x: Math.round(state.actors.player.x + (subIdx % 3) * 6),
        y: Math.round(state.actors.player.y + ((subIdx >> 1) % 3) * 6),
      };
    let instanceId = nextDeterministicId('itm', state.run.runId, state.revision, subIdx++);
    while (state.items[instanceId]) {
      instanceId = nextDeterministicId('itm', state.run.runId, state.revision, subIdx++);
    }
    state.items[instanceId] = {
      instanceId,
      defId,
      runId: state.run.runId,
      count: batchCount,
      durability: def.maxDurability,
      charges: def.maxCharges,
      quality: 100,
      location: openLoc,
      provenanceReceiptId,
    };
    grantedIds.push(instanceId);
  }

  return { grantedIds, subIndexNext: subIdx };
}

/**
 * Atomically debits required materials from player custody. Returns false without mutation if insufficient.
 */
export function debitPlayerMaterials(
  state: GameState,
  costs: { itemId: string; count: number }[]
): boolean {
  for (const c of costs) {
    if (countPlayerItem(state, c.itemId) < c.count) {
      return false;
    }
  }
  for (const c of costs) {
    let need = c.count;
    // Prefer bag slots before quickbar/equipped
    const candidates = Object.values(state.items)
      .filter((i) => i.defId === c.itemId && isPlayerHeldLocation(i.location))
      .sort((a, b) => {
        const rank = (k: CustodyLocation['kind']) =>
          k === 'player_bag' ? 0 : k === 'player_quickbar' ? 1 : 2;
        return rank(a.location.kind) - rank(b.location.kind);
      });
    for (const item of candidates) {
      if (need <= 0) break;
      const take = Math.min(need, item.count);
      item.count -= take;
      need -= take;
      if (item.count <= 0) {
        delete state.items[item.instanceId];
      }
    }
  }
  return true;
}

export function listStructureItems(state: GameState, structureId: string): ItemInstance[] {
  return Object.values(state.items).filter(
    (i) => i.location.kind === 'structure_container' && i.location.structureId === structureId
  );
}

/**
 * Verifies K1 Custody Ledger conservation & uniqueness invariants:
 * - Every dictionary key matches instanceId
 * - Every count >= 1 and <= stackLimit
 * - No two items occupy the same slotted container slot
 */
export function assertCustodyInvariants(state: GameState): void {
  const occupiedSlots = new Set<string>();
  for (const [key, item] of Object.entries(state.items)) {
    if (key !== item.instanceId) {
      throw new Error(`Custody invariant violation: key ${key} !== instanceId ${item.instanceId}`);
    }
    const def = ITEMS[item.defId];
    if (!def) {
      throw new Error(`Custody invariant violation: unknown item defId ${item.defId}`);
    }
    if (item.count < 1 || item.count > def.stackLimit) {
      throw new Error(
        `Custody invariant violation: ${item.instanceId} (${item.defId}) invalid count ${item.count}`
      );
    }
    const loc = item.location;
    if (loc.kind !== 'ground_drop') {
      const slotKey =
        loc.kind === 'player_bag'
          ? `bag:${loc.slotIndex}`
          : loc.kind === 'player_quickbar'
            ? `qbar:${loc.slotIndex}`
            : loc.kind === 'player_equip'
              ? `eq:${loc.equipSlot}`
              : loc.kind === 'structure_container'
                ? `st:${loc.structureId}:${loc.port}:${loc.slotIndex}`
                : loc.kind === 'vehicle_cargo'
                  ? `vh:${loc.vehicleId}:${loc.slotIndex}`
                  : `db:${loc.bagId}:${loc.slotIndex}`;
      if (occupiedSlots.has(slotKey)) {
        throw new Error(`Custody invariant violation: duplicate occupancy at ${slotKey}`);
      }
      occupiedSlots.add(slotKey);
    }
  }
}
