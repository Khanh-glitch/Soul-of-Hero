import {
  BALANCE,
  BOSSES,
  ENEMIES,
  ITEMS,
  POIS,
  RECIPES,
  RECIPES_LIST,
  SKILLS,
  SOURCES,
  STRUCTURES,
} from './catalogs';
import {
  assertCustodyInvariants,
  computePlayerCarriedMassKg,
  computeVehicleCargoMassKg,
  countPlayerItem,
  debitPlayerMaterials,
  findItemAtLocation,
  findOpenPlayerSlot,
  findOpenStructurePortSlot,
  getEquippedItem,
  grantItemsToPlayerOrGround,
  isPlayerHeldLocation,
  listStructureItems,
  locationsEqual,
} from './custody';
import {
  getEffectiveSurface,
  getStructuresAtTile,
  hasLineOfSight,
  isTileInPlayerOwnedTerritory,
  isTilePowered,
  isTileWalkable,
} from './navigation';
import { nextDeterministicId, nextFloat01, nextInt, restoreRng, serializeRng } from './rng';
import { createNewRunState, revealDiscoveryAroundPlayer } from './worldGen';
import type {
  ActionIntent,
  CustodyLocation,
  DispatchResult,
  EventReceipt,
  GameState,
  ItemInstance,
  SourceNodeInstance,
} from './types';

function distPx(x0: number, y0: number, x1: number, y1: number): number {
  return Math.hypot(x1 - x0, y1 - y0);
}

export function awardUniqueScoreEvent(
  state: GameState,
  eventKey: string,
  weightKey: keyof typeof BALANCE.scoring.weights.value,
  receiptId: string
): void {
  if (state.run.uniqueScoreEvents[eventKey]) return;
  const pts = BALANCE.scoring.weights.value[weightKey] ?? 0;
  if (pts <= 0) return;
  state.run.uniqueScoreEvents[eventKey] = {
    points: pts,
    receiptId,
    elapsedSec: state.clock.elapsedRealSeconds,
  };
  if (!state.profile.achievements.includes(eventKey)) {
    state.profile.achievements.push(eventKey);
  }
}

export function recognizeOptionalHint(
  state: GameState,
  hintKey: string,
  receiptId: string
): void {
  if (!state.optionalHintsRecognized[hintKey]) {
    state.optionalHintsRecognized[hintKey] = receiptId;
  }
}

export function computeRunUnverifiedScore(state: GameState): number {
  let total = Object.values(state.run.uniqueScoreEvents).reduce((acc, e) => acc + e.points, 0);
  const stoneCount = state.run.collectedElderStones.length;
  const thresholds = BALANCE.ragnarokEconomy.elderStoneThresholdBonusScore.value;
  total += thresholds[Math.min(stoneCount, thresholds.length - 1)] ?? 0;
  return total;
}

export function finalizeRunOnce(
  state: GameState,
  outcome: 'evacuated' | 'abandoned' | 'expired' | 'six_stone_convergence',
  nowUtcMs: number,
  intentId: string
): EventReceipt | null {
  if (state.run.finalizedOnce) {
    return null;
  }
  state.run.finalizedOnce = true;
  state.run.status = outcome;
  state.revision += 1;

  const receiptId = nextDeterministicId('rcpt_fin', state.run.runId, state.revision);
  if (outcome === 'evacuated') {
    awardUniqueScoreEvent(state, 'clean_evacuation', 'clean_evacuation', receiptId);
  } else if (outcome === 'six_stone_convergence') {
    awardUniqueScoreEvent(state, 'six_stone_convergence', 'six_stone_convergence', receiptId);
  }

  // Count unsecured physical cash lost on run close (never auto-deposited!)
  let unsecuredCashLost = 0;
  for (const item of Object.values(state.items)) {
    if (item.defId === 'ragnarok_cash') {
      unsecuredCashLost += item.count;
    }
  }

  const score = computeRunUnverifiedScore(state);
  state.profile.runHistory.push({
    runId: state.run.runId,
    runNumber: state.run.runNumber,
    adventurerGender: state.run.adventurerGender,
    spawnRegionId: state.run.spawnRegionId,
    outcome,
    elapsedRealSeconds: Math.round(state.clock.elapsedRealSeconds),
    elderStonesCollected: [...state.run.collectedElderStones],
    cashDepositedThisRun: state.run.cashDepositedThisRun,
    cashLostUnsecured: unsecuredCashLost,
    unverifiedLocalScore: score,
    verificationStatus: state.run.qaClockUsed ? 'QA_ACCELERATED_UNVERIFIED' : 'LOCAL_UNVERIFIED',
    endedAtUtcMs: nowUtcMs,
    notableReceipts: state.eventReceipts.slice(-8).map((r) => r.receiptId),
  });

  const receipt: EventReceipt = {
    receiptId,
    intentId,
    contractEdge: 'C22/C23',
    runId: state.run.runId,
    revision: state.revision,
    timestampUtcMs: nowUtcMs,
    elapsedSec: state.clock.elapsedRealSeconds,
    actorId: 'player',
    summary: `Run finalized (${outcome}). Secured cash: ${state.profile.securedRagnarokCash}. Unsecured cash wiped: ${unsecuredCashLost}. Score: ${score} (LOCAL/UNVERIFIED).`,
    details: {
      outcome,
      unsecuredCashLost,
      score,
      verificationStatus: state.run.qaClockUsed ? 'QA_ACCELERATED_UNVERIFIED' : 'LOCAL_UNVERIFIED',
    },
  };
  state.eventReceipts.push(receipt);
  return receipt;
}

function appendReceipt(
  state: GameState,
  intentId: string,
  contractEdge: string,
  nowUtcMs: number,
  summary: string,
  sourceId?: string,
  details?: Record<string, unknown>
): EventReceipt {
  const receiptId = nextDeterministicId('rcpt', state.run.runId, state.revision);
  const receipt: EventReceipt = {
    receiptId,
    intentId,
    contractEdge,
    runId: state.run.runId,
    revision: state.revision,
    timestampUtcMs: nowUtcMs,
    elapsedSec: Math.round(state.clock.elapsedRealSeconds * 100) / 100,
    actorId: 'player',
    sourceId,
    summary,
    details,
  };
  state.eventReceipts.push(receipt);
  if (state.eventReceipts.length > 400) {
    state.eventReceipts = state.eventReceipts.slice(-400);
  }
  return receipt;
}

function pushCue(
  state: GameState,
  cue: Omit<GameState['vfxCues'][number], 'id' | 'createdAtSec'>
): void {
  state.vfxCues.push({
    ...cue,
    id: `vfx_${state.revision}_${state.vfxCues.length}`,
    createdAtSec: state.clock.elapsedRealSeconds,
  });
  if (state.vfxCues.length > 48) {
    state.vfxCues = state.vfxCues.slice(-48);
  }
}

export function resolveHarvestOnSource(
  state: GameState,
  src: SourceNodeInstance,
  toolItem: ItemInstance | null,
  isSkillBlast: boolean,
  crackPenaltyMultiplier: number,
  intentId: string,
  nowUtcMs: number
): EventReceipt | null {
  const sDef = SOURCES[src.defId];
  if (!sDef || src.stock <= 0) return null;

  if (sDef.onlyFinal72 && state.clock.phase === 'normal') {
    pushCue(state, {
      kind: 'floating_text',
      x: src.tileX * 16 + 8,
      y: src.tileY * 16,
      color: '#ff9f1c',
      text: 'Sealed until Final 72h',
      durationSec: 1.4,
    });
    return null;
  }

  // Check if deep POI source requires unlocked gate
  if (src.isDeepPoi && src.poiId) {
    const poi = state.world.pois.find((p) => p.id === src.poiId);
    if (poi && !poi.unlockedDeep) {
      return null;
    }
  }

  const rng = restoreRng(state.rngState);
  const tDef = toolItem ? ITEMS[toolItem.defId] : null;
  const eff = tDef?.harvestProfile?.[sDef.materialType] ?? (sDef.interactLoot ? 1.0 : 0.35);

  if (eff <= 0 && !sDef.interactLoot && !sDef.mintsPhysicalCash) {
    pushCue(state, {
      kind: 'floating_text',
      x: src.tileX * 16 + 8,
      y: src.tileY * 16,
      color: '#e63946',
      text: 'Ineffective Tool',
      durationSec: 1.1,
    });
    return null;
  }

  const hitPower = sDef.interactLoot
    ? src.hitsRemaining
    : (tDef?.weaponProfile?.actorDamage ?? 5) +
      (tDef?.weaponProfile?.skillId === 'tool_chop_mine' &&
      (sDef.materialType === 'stone' || sDef.materialType === 'ore')
        ? SKILLS.tool_chop_mine.mineralNodeBonusDamage ?? 0
        : 0);

  src.hitsRemaining = Math.max(0, src.hitsRemaining - hitPower);
  if (crackPenaltyMultiplier < 1) {
    src.crackedPenalty = true;
  }

  let subIdx = 1;
  const grantedSummary: string[] = [];
  const receiptId = nextDeterministicId('rcpt_src', state.run.runId, state.revision);

  if (src.hitsRemaining <= 0 || !sDef.interactLoot) {
    // Debit 1 stock unit when threshold hit or every strike on multi-stock natural node
    const debitTrigger =
      sDef.interactLoot || src.hitsRemaining <= 0 || hitPower >= sDef.maxHits / src.maxStock;
    if (debitTrigger && src.stock > 0) {
      src.stock -= 1;
      src.consumedReceiptIds.push(receiptId);

      if (sDef.mintsPhysicalCash) {
        // Finite Final-72 Ragnarok Cash Vault!
        const minCash = BALANCE.ragnarokEconomy.cashPerFinal72VaultMin.value;
        const maxCash = BALANCE.ragnarokEconomy.cashPerFinal72VaultMax.value;
        const cashAmount = nextInt(rng, minCash, maxCash);
        const res = grantItemsToPlayerOrGround(
          state,
          'ragnarok_cash',
          cashAmount,
          receiptId,
          subIdx
        );
        subIdx = res.subIndexNext;
        grantedSummary.push(`${cashAmount} Ragnarok Cash`);
      } else {
        if (sDef.yieldPoolOneOf && sDef.yieldPoolOneOf.length > 0) {
          const chosen = sDef.yieldPoolOneOf[nextInt(rng, 0, sDef.yieldPoolOneOf.length - 1)];
          const res = grantItemsToPlayerOrGround(state, chosen, 1, receiptId, subIdx);
          subIdx = res.subIndexNext;
          grantedSummary.push(`1x ${ITEMS[chosen]?.name ?? chosen}`);
        }

        const qualityFactor = src.crackedPenalty ? crackPenaltyMultiplier : 1.0;
        for (const yEntry of sDef.yieldTable) {
          if (nextFloat01(rng) <= yEntry.chance) {
            const rawQty = sDef.interactLoot
              ? yEntry.baseCount
              : Math.max(1, Math.round(yEntry.baseCount * eff * qualityFactor));
            const res = grantItemsToPlayerOrGround(state, yEntry.itemId, rawQty, receiptId, subIdx);
            subIdx = res.subIndexNext;
            grantedSummary.push(`${rawQty}x ${ITEMS[yEntry.itemId]?.name ?? yEntry.itemId}`);
          }
        }
      }

      if (src.stock <= 0) {
        src.depletedAtElapsedSec = state.clock.elapsedRealSeconds;
        // CRITICAL CANON: Final-72 Ragnarok vaults and null-respawn rare chests NEVER respawn!
        if (!sDef.onlyFinal72 && !sDef.mintsPhysicalCash && sDef.respawnSeconds !== null) {
          src.respawnAtElapsedSec = state.clock.elapsedRealSeconds + sDef.respawnSeconds;
        } else {
          src.respawnAtElapsedSec = null;
        }
      } else {
        src.hitsRemaining = Math.ceil(sDef.maxHits / src.maxStock);
      }
    }
  }

  state.rngState = serializeRng(rng);

  if (grantedSummary.length > 0) {
    pushCue(state, {
      kind: 'floating_text',
      x: src.tileX * 16 + 8,
      y: src.tileY * 16 - 4,
      color: sDef.mintsPhysicalCash ? '#ffd166' : '#a7f3d0',
      text: `+${grantedSummary[0]}`,
      durationSec: 1.2,
    });
    if (sDef.economyClass === 'HUMAN_MADE') {
      recognizeOptionalHint(state, 'hint_road_salvage', receiptId);
    } else if (sDef.economyClass === 'NATURAL') {
      recognizeOptionalHint(state, 'hint_natural_harvest', receiptId);
    }
  }

  const edge = sDef.mintsPhysicalCash
    ? 'C15'
    : sDef.economyClass === 'HUMAN_MADE'
      ? 'C02'
      : isSkillBlast
        ? 'C05'
        : 'C01';

  const receipt: EventReceipt = {
    receiptId,
    intentId,
    contractEdge: edge,
    runId: state.run.runId,
    revision: state.revision,
    timestampUtcMs: nowUtcMs,
    elapsedSec: Math.round(state.clock.elapsedRealSeconds * 100) / 100,
    actorId: 'player',
    sourceId: src.id,
    summary:
      grantedSummary.length > 0
        ? `Harvested ${sDef.name}: ${grantedSummary.join(', ')} (stock ${src.stock}/${src.maxStock})`
        : `Struck ${sDef.name} (${src.hitsRemaining} integrity left)`,
    details: {
      sourceDefId: src.defId,
      remainingStock: src.stock,
      yields: grantedSummary,
    },
  };
  state.eventReceipts.push(receipt);
  return receipt;
}

export function commitActiveCastNow(state: GameState, nowUtcMs: number): EventReceipt | null {
  const cast = state.actors.player.activeCast;
  if (!cast || cast.committed) return null;
  cast.committed = true;

  const skill = SKILLS[cast.skillId];
  if (!skill) return null;

  const item = cast.itemInstanceId ? state.items[cast.itemInstanceId] ?? null : null;
  const itemDef = item ? ITEMS[item.defId] : null;

  // Validate charges/ammo at commit milestone!
  if (skill.spendsCoreCharge) {
    if (!item || (item.charges ?? 0) <= 0) {
      state.actors.player.activeCast = null;
      return null;
    }
    item.charges = (item.charges ?? 1) - 1;
  } else if (itemDef?.ammoItemId) {
    if (!debitPlayerMaterials(state, [{ itemId: itemDef.ammoItemId, count: 1 }])) {
      pushCue(state, {
        kind: 'floating_text',
        x: state.actors.player.x,
        y: state.actors.player.y - 10,
        color: '#e63946',
        text: 'No Arrows!',
        durationSec: 1.0,
      });
      state.actors.player.activeCast = null;
      return null;
    }
  }

  // Apply weapon durability wear at committed swing
  if (item && itemDef?.maxDurability && itemDef.wearPerUse) {
    item.durability = Math.max(0, Math.round(((item.durability ?? itemDef.maxDurability) - itemDef.wearPerUse) * 100) / 100);
    if (item.durability <= 0) {
      delete state.items[item.instanceId];
      pushCue(state, {
        kind: 'floating_text',
        x: state.actors.player.x,
        y: state.actors.player.y - 12,
        color: '#ff6b6b',
        text: `${itemDef.name} Broke!`,
        durationSec: 1.5,
      });
    }
  }

  state.revision += 1;
  const px = state.actors.player.x;
  const py = state.actors.player.y;
  const baseDamage = itemDef?.weaponProfile?.actorDamage ?? 5;
  const rangePx = itemDef?.weaponProfile?.rangePx ?? 24;
  const aoeRadius = skill.aoeRadiusPx ?? 22;

  // Visual cue authorized by committed action
  pushCue(state, {
    kind: skill.driverType === 'melee_arc' ? 'slash' : skill.driverType,
    x: skill.driverType === 'aoe_blast' ? cast.targetX : px,
    y: skill.driverType === 'aoe_blast' ? cast.targetY : py,
    targetX: cast.targetX,
    targetY: cast.targetY,
    radiusPx: aoeRadius,
    color: skill.vfxColor,
    durationSec: 0.35,
  });

  // Self heal / purge if core_mend_pulse
  if (skill.healHp) {
    state.actors.player.hp = Math.min(state.actors.player.maxHp, state.actors.player.hp + skill.healHp);
  }
  if (skill.clearRad) {
    state.actors.player.radDose = Math.max(0, state.actors.player.radDose - skill.clearRad);
  }

  const hitSummaries: string[] = [];
  const rng = restoreRng(state.rngState);

  const impactCenterX =
    skill.driverType === 'aoe_blast'
      ? cast.targetX
      : skill.driverType === 'self_aura'
        ? px
        : px + Math.cos(Math.atan2(cast.targetY - py, cast.targetX - px)) * Math.min(rangePx * 0.75, distPx(px, py, cast.targetX, cast.targetY));
  const impactCenterY =
    skill.driverType === 'aoe_blast'
      ? cast.targetY
      : skill.driverType === 'self_aura'
        ? py
        : py + Math.sin(Math.atan2(cast.targetY - py, cast.targetX - px)) * Math.min(rangePx * 0.75, distPx(px, py, cast.targetX, cast.targetY));

  const hitRadius =
    skill.driverType === 'aoe_blast' || skill.driverType === 'self_aura'
      ? aoeRadius
      : skill.driverType === 'line_ray'
        ? 18
        : 24;

  // 1. Check ordinary enemies
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive) continue;
    const inHit =
      skill.driverType === 'line_ray'
        ? distToSegment(enemy.x, enemy.y, px, py, cast.targetX, cast.targetY) <= 14 &&
          hasLineOfSight(state, px, py, enemy.x, enemy.y, rangePx + 12)
        : distPx(enemy.x, enemy.y, impactCenterX, impactCenterY) <= hitRadius &&
          hasLineOfSight(state, px, py, enemy.x, enemy.y, rangePx + aoeRadius);

    if (inHit) {
      const eDef = ENEMIES[enemy.defId];
      const dmg = Math.max(1, Math.round(baseDamage - (eDef?.armor ?? 0)));
      enemy.hp = Math.max(0, enemy.hp - dmg);
      enemy.aiState = 'pursue_player';
      enemy.lastSeenPlayerPos = { x: px, y: py };

      const angle = Math.atan2(enemy.y - py, enemy.x - px);
      const kb = itemDef?.weaponProfile?.knockbackPx ?? 4;
      const nx = enemy.x + Math.cos(angle) * kb;
      const ny = enemy.y + Math.sin(angle) * kb;
      if (isTileWalkable(state, Math.floor(nx / 16), Math.floor(ny / 16))) {
        enemy.x = nx;
        enemy.y = ny;
      }

      pushCue(state, {
        kind: 'floating_text',
        x: enemy.x,
        y: enemy.y - 10,
        color: '#ffd166',
        text: `-${dmg}`,
        durationSec: 0.9,
      });
      hitSummaries.push(`${eDef?.name ?? enemy.defId} (-${dmg} HP)`);

      if (enemy.hp <= 0) {
        enemy.alive = false;
        enemy.respawnAtSec = state.clock.elapsedRealSeconds + 14400; // 4h habitat recovery
        const dropReceiptId = nextDeterministicId('rcpt_drop', state.run.runId, state.revision);
        let sub = 10;
        for (const dr of eDef?.drops ?? []) {
          if (nextFloat01(rng) <= dr.chance) {
            const g = grantItemsToPlayerOrGround(state, dr.itemId, dr.count, dropReceiptId, sub);
            sub = g.subIndexNext;
          }
        }
        hitSummaries.push(`slain ${eDef?.name ?? enemy.defId}`);
      }
    }
  }

  // 2. Check 6 optional Elders
  for (const elder of state.actors.elders) {
    if (!elder.alive) continue;
    const inHit =
      distPx(elder.x, elder.y, impactCenterX, impactCenterY) <= hitRadius + 10 &&
      hasLineOfSight(state, px, py, elder.x, elder.y, rangePx + aoeRadius + 16);
    if (inHit) {
      const bDef = BOSSES[elder.defId];
      const stats = elder.form === 'awakened' ? bDef.awakened : bDef.latent;
      const dmg = Math.max(1, Math.round(baseDamage - stats.armor));
      elder.hp = Math.max(0, elder.hp - dmg);
      elder.aiState = 'pursue';
      pushCue(state, {
        kind: 'floating_text',
        x: elder.x,
        y: elder.y - 14,
        color: '#ff758f',
        text: `-${dmg}`,
        durationSec: 1.0,
      });
      hitSummaries.push(`${bDef.name} (-${dmg} HP)`);

      if (elder.hp <= 0) {
        elder.alive = false;
        const stoneId = bDef.stoneItemId;
        const elderRcpt = nextDeterministicId('rcpt_elder', state.run.runId, state.revision);
        elder.defeatedReceiptId = elderRcpt;
        // Grant unique per-run Elder Stone ONLY ONCE per run!
        if (!state.run.collectedElderStones.includes(stoneId)) {
          state.run.collectedElderStones.push(stoneId);
          grantItemsToPlayerOrGround(state, stoneId, 1, elderRcpt, 50);
          awardUniqueScoreEvent(
            state,
            `elder_${bDef.id}_${elder.form}`,
            elder.form === 'awakened' ? 'elder_awakened_defeated' : 'elder_latent_defeated',
            elderRcpt
          );
          hitSummaries.push(`claimed unique ${ITEMS[stoneId]?.name ?? stoneId}!`);
        }
      }
    }
  }

  state.rngState = serializeRng(rng);

  // 3. Check world sources within impact geometry (prioritizing closest node to aim cursor!)
  let sourceReceipt: EventReceipt | null = null;
  const candidateSources = Object.values(state.sourceStocks)
    .filter((src) => {
      if (src.stock <= 0) return false;
      const sx = src.tileX * 16 + 8;
      const sy = src.tileY * 16 + 8;
      return (
        distPx(sx, sy, impactCenterX, impactCenterY) <= hitRadius &&
        distPx(px, py, sx, sy) <= rangePx + aoeRadius
      );
    })
    .sort(
      (a, b) =>
        distPx(a.tileX * 16 + 8, a.tileY * 16 + 8, cast.targetX, cast.targetY) -
        distPx(b.tileX * 16 + 8, b.tileY * 16 + 8, cast.targetX, cast.targetY)
    );

  for (const src of candidateSources) {
    const crackMult = skill.worldMutation?.cracksMineralYieldPenalty ?? 1.0;
    sourceReceipt = resolveHarvestOnSource(
      state,
      src,
      item,
      skill.spendsCoreCharge,
      crackMult,
      cast.intentId,
      nowUtcMs
    );
    if (sourceReceipt) break;
  }

  // 4. Authorized World Terrain Mutations (C05 / K2: ONLY via committed legal skill!)
  if (skill.worldMutation) {
    const mut = skill.worldMutation;
    const centerTx = Math.floor(impactCenterX / 16);
    const centerTy = Math.floor(impactCenterY / 16);
    const tileRad = Math.max(1, Math.round(aoeRadius / 16));
    const rcptRef = nextDeterministicId('rcpt_mut', state.run.runId, state.revision);

    for (let dy = -tileRad; dy <= tileRad; dy++) {
      for (let dx = -tileRad; dx <= tileRad; dx++) {
        if (Math.hypot(dx, dy) > tileRad + 0.3) continue;
        const tx = centerTx + dx;
        const ty = centerTy + dy;
        const key = `${tx},${ty}`;
        const curSurf = getEffectiveSurface(state, tx, ty);

        if (mut.extinguishesFire && state.terrainEffects[key]?.type === 'fire') {
          delete state.terrainEffects[key];
          hitSummaries.push('extinguished fire');
        }
        if (mut.meltsIce && state.terrainEffects[key]?.type === 'ice') {
          delete state.terrainEffects[key];
        }
        if (mut.freezesWaterToIce && curSurf === 'shallow_water') {
          state.terrainEffects[key] = {
            id: `te_ice_${state.revision}_${tx}_${ty}`,
            tileX: tx,
            tileY: ty,
            type: 'ice',
            materialBefore: 'shallow_water',
            startSec: state.clock.elapsedRealSeconds,
            endSec: state.clock.elapsedRealSeconds + (mut.durationSeconds ?? 180),
            spreadGen: 0,
            lastSpreadSec: state.clock.elapsedRealSeconds,
            sourceEventId: rcptRef,
          };
          hitSummaries.push('froze shallow water');
        }
        if (
          mut.ignitesFlammable &&
          state.clock.weather !== 'rain' &&
          state.clock.weather !== 'storm' &&
          (curSurf === 'forest' || curSurf === 'grass')
        ) {
          state.terrainEffects[key] = {
            id: `te_fire_${state.revision}_${tx}_${ty}`,
            tileX: tx,
            tileY: ty,
            type: 'fire',
            materialBefore: curSurf,
            startSec: state.clock.elapsedRealSeconds,
            endSec: state.clock.elapsedRealSeconds + (mut.durationSeconds ?? 45),
            spreadGen: 0,
            lastSpreadSec: state.clock.elapsedRealSeconds,
            sourceEventId: rcptRef,
          };
          hitSummaries.push('ignited brush');
        }
      }
    }

    if (mut.energizesPoiRelaySec) {
      for (const poi of state.world.pois) {
        if (distPx(impactCenterX, impactCenterY, poi.relayTileX * 16 + 8, poi.relayTileY * 16 + 8) <= 44) {
          poi.poweredUntilSec = state.clock.elapsedRealSeconds + mut.energizesPoiRelaySec;
          const pDef = POIS[poi.defId];
          if (pDef.gateType === 'power' && poi.gateStructureId && state.structures[poi.gateStructureId]) {
            poi.unlockedDeep = true;
            state.structures[poi.gateStructureId].isOpen = true;
          }
          hitSummaries.push(`energized ${poi.name} relay`);
        }
      }
    }
  }

  if (sourceReceipt && hitSummaries.length === 0) {
    return sourceReceipt;
  }

  return appendReceipt(
    state,
    cast.intentId,
    skill.spendsCoreCharge ? 'C03/C05' : 'C05',
    nowUtcMs,
    `Committed ${skill.name}${hitSummaries.length ? `: ${hitSummaries.slice(0, 3).join(', ')}` : ' (miss)'}`,
    item?.instanceId,
    { skillId: skill.id, remainingCharges: item?.charges }
  );
}

function distToSegment(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number
): number {
  const l2 = (x2 - x1) ** 2 + (y2 - y1) ** 2;
  if (l2 === 0) return distPx(px, py, x1, y1);
  let t = ((px - x1) * (x2 - x1) + (py - y1) * (y2 - y1)) / l2;
  t = Math.max(0, Math.min(1, t));
  return distPx(px, py, x1 + t * (x2 - x1), y1 + t * (y2 - y1));
}

export function checkBuildPlacementValidity(
  state: GameState,
  structureDefId: string,
  tileX: number,
  tileY: number
): { valid: boolean; reason?: string } {
  const def = STRUCTURES[structureDefId];
  if (!def) return { valid: false, reason: 'Unknown structure' };
  if (tileX < 3 || tileY < 3 || tileX >= state.world.width - 3 || tileY >= state.world.height - 3) {
    return { valid: false, reason: 'Out of island bounds' };
  }
  const surf = getEffectiveSurface(state, tileX, tileY);
  if (surf === 'deep_water' || surf === 'shallow_water' || surf === 'mountain_rock') {
    return { valid: false, reason: `Cannot build on ${surf.replace('_', ' ')}` };
  }

  // Prevent building inside protected POI footprints
  for (const poi of state.world.pois) {
    if (
      Math.abs(tileX - poi.centerX) <= Math.ceil(poi.widthTiles / 2) + 1 &&
      Math.abs(tileY - poi.centerY) <= Math.ceil(poi.heightTiles / 2) + 1
    ) {
      return { valid: false, reason: `Blocked by ${poi.name} structure zone` };
    }
  }

  // Check undepleted blocking source on tile
  for (const src of Object.values(state.sourceStocks)) {
    if (src.tileX === tileX && src.tileY === tileY && src.stock > 0) {
      return { valid: false, reason: 'Clear resource node on tile first' };
    }
  }

  const existing = getStructuresAtTile(state, tileX, tileY);
  if (def.isFloor) {
    if (existing.some((s) => STRUCTURES[s.defId]?.isFloor)) {
      return { valid: false, reason: 'Floor already placed here' };
    }
  } else if (def.isRoof) {
    if (existing.some((s) => STRUCTURES[s.defId]?.isRoof)) {
      return { valid: false, reason: 'Roof already placed here' };
    }
  } else {
    if (
      existing.some((s) => {
        const sd = STRUCTURES[s.defId];
        return sd && !sd.isFloor && !sd.isRoof;
      })
    ) {
      return { valid: false, reason: 'Tile already occupied by structure' };
    }
  }

  if (def.outdoorOnly && existing.some((s) => STRUCTURES[s.defId]?.isRoof)) {
    return { valid: false, reason: 'Must be placed outdoors (unroofed)' };
  }

  if (def.isTerritoryClaim) {
    const ownedClaims = Object.values(state.structures).filter(
      (s) => s.ownerId === 'player' && s.hp > 0 && STRUCTURES[s.defId]?.isTerritoryClaim
    ).length;
    if (ownedClaims >= BALANCE.territoryAndBuild.maxOwnedClaimsPerRun.value) {
      return {
        valid: false,
        reason: `Max ${BALANCE.territoryAndBuild.maxOwnedClaimsPerRun.value} Territory Claims per run`,
      };
    }
  }

  if (def.requiresOwnedTerritory && !isTileInPlayerOwnedTerritory(state, tileX, tileY)) {
    return {
      valid: false,
      reason: 'Requires owned home land (place Territory Claim Cabinet nearby first)',
    };
  }

  // Range check from player (max 5 tiles)
  const ptx = Math.floor(state.actors.player.x / 16);
  const pty = Math.floor(state.actors.player.y / 16);
  if (Math.hypot(tileX - ptx, tileY - pty) > 5.5) {
    return { valid: false, reason: 'Too far from Adventurer' };
  }

  // Prevent trapping self inside blocking wall on exact player tile
  if (def.blocksMovement && !def.isDoor && tileX === ptx && tileY === pty) {
    return { valid: false, reason: 'Step off tile before placing solid structure' };
  }

  return { valid: true };
}

/**
 * Single Authoritative Action Dispatcher:
 * intent -> validate -> simulate candidate -> commit atomically -> event receipt
 */
export function dispatchAction(
  currentState: GameState,
  intent: ActionIntent,
  nowUtcMs = Date.now()
): DispatchResult {
  // Idempotency guard: never execute duplicate intentId twice!
  if (
    intent.kind !== 'MOVE_INPUT' &&
    currentState.processedIntentIds.includes(intent.intentId)
  ) {
    return { ok: false, reason: 'Duplicate intent already processed', state: currentState };
  }

  if (
    currentState.run.status !== 'active' &&
    intent.kind !== 'START_NEW_RUN'
  ) {
    return { ok: false, reason: `Run is already ${currentState.run.status}`, state: currentState };
  }

  // Clone candidate state for atomic commit / rollback
  const state: GameState =
    intent.kind === 'MOVE_INPUT' ? structuredClone(currentState) : structuredClone(currentState);

  const reject = (reason: string): DispatchResult => ({
    ok: false,
    reason,
    state: currentState,
  });

  const recordIntent = () => {
    if (intent.kind !== 'MOVE_INPUT') {
      state.processedIntentIds.push(intent.intentId);
      if (state.processedIntentIds.length > 500) {
        state.processedIntentIds = state.processedIntentIds.slice(-500);
      }
      state.revision += 1;
    }
  };

  switch (intent.kind) {
    case 'START_NEW_RUN': {
      // C23: Wipe ALL run-local state; preserve ONLY profile securedRagnarokCash, achievements, runHistory!
      const fresh = createNewRunState({
        profile: currentState.profile,
        worldSeed: currentState.world.seed,
        adventurerGender: intent.adventurerGender,
        spawnRegionId: intent.spawnRegionId,
        nowUtcMs: intent.nowUtcMs,
      });
      fresh.processedIntentIds.push(intent.intentId);
      assertCustodyInvariants(fresh);
      return { ok: true, state: fresh, receipt: fresh.eventReceipts[0] };
    }

    case 'MOVE_INPUT': {
      const p = state.actors.player;
      const mag = Math.hypot(intent.dx, intent.dy);
      if (mag < 0.01 || intent.dtSec <= 0) {
        return { ok: true, state };
      }
      const ndx = intent.dx / mag;
      const ndy = intent.dy / mag;

      if (Math.abs(ndx) >= Math.abs(ndy)) {
        p.facing = ndx >= 0 ? 'right' : 'left';
      } else {
        p.facing = ndy >= 0 ? 'down' : 'up';
      }

      const tx = Math.floor(p.x / 16);
      const ty = Math.floor(p.y / 16);
      const surf = getEffectiveSurface(state, tx, ty);
      const surfMults = BALANCE.environment.surfaceSpeedMultipliers.value as Record<string, number>;
      const surfMult = surfMults[surf] ?? 1.0;

      // Encumbrance & Tethered Hand-Cart physics (C13 / K7)
      const carriedKg = computePlayerCarriedMassKg(state);
      const softCap = BALANCE.player.baseCarryCapacityKg.value;
      const hardCap = BALANCE.player.hardCarryLimitKg.value;
      if (carriedKg > hardCap) {
        return reject('Over-encumbered beyond max personal limit! Drop items or load Hand-Cart.');
      }
      const encumbMult =
        carriedKg <= softCap ? 1.0 : Math.max(0.42, 1.0 - ((carriedKg - softCap) / (hardCap - softCap)) * 0.55);

      let cartMult = 1.0;
      const tetheredCart = p.tetheredVehicleId ? state.vehicles[p.tetheredVehicleId] : null;
      if (tetheredCart) {
        const cartMass = computeVehicleCargoMassKg(state, tetheredCart.id);
        if (cartMass > BALANCE.freight.handCartCargoCapacityKg.value) {
          return reject('Hand-Cart cargo exceeds 95kg axle limit!');
        }
        const loadRatio = cartMass / BALANCE.freight.handCartCargoCapacityKg.value;
        if (surf === 'road' || surf === 'stone') {
          cartMult = BALANCE.freight.handCartRoadSpeedMultiplier.value * (1 - loadRatio * 0.14);
        } else if (surf === 'marsh' || surf === 'hills' || surf === 'snow') {
          cartMult = BALANCE.freight.handCartRoughTerrainPenalty.value * (1 - loadRatio * 0.2);
        } else {
          cartMult = 0.92 * (1 - loadRatio * 0.15);
        }
      }

      const debuffMult = (p.slowRemainingSec > 0 ? 0.62 : 1.0) * (p.chillRemainingSec > 0 ? 0.75 : 1.0);
      const canSprint = intent.sprint && p.stamina > 4 && carriedKg <= hardCap * 0.9 && !tetheredCart;
      const baseSpd = canSprint
        ? BALANCE.player.sprintSpeedPxPerSec.value
        : BALANCE.player.walkSpeedPxPerSec.value;

      if (canSprint) {
        p.stamina = Math.max(0, p.stamina - 16 * intent.dtSec);
      }

      const speed = baseSpd * surfMult * encumbMult * cartMult * debuffMult;
      const stepX = ndx * speed * intent.dtSec;
      const stepY = ndy * speed * intent.dtSec;

      const tryX = p.x + stepX;
      const tryY = p.y + stepY;
      const forCart = Boolean(tetheredCart);

      if (isTileWalkable(state, Math.floor(tryX / 16), Math.floor(p.y / 16), { forCart })) {
        p.x = tryX;
      }
      if (isTileWalkable(state, Math.floor(p.x / 16), Math.floor(tryY / 16), { forCart })) {
        p.y = tryY;
      }

      if (tetheredCart) {
        tetheredCart.x = p.x - ndx * 13;
        tetheredCart.y = p.y - ndy * 13;
      }

      // Write physical decaying footprint segment when entering a new tile (C08)
      const newTx = Math.floor(p.x / 16);
      const newTy = Math.floor(p.y / 16);
      const tileKey = `${newTx},${newTy}`;
      if (p.lastFootprintTileKey !== tileKey) {
        const newSurf = getEffectiveSurface(state, newTx, newTy);
        const retMap = BALANCE.environment.surfaceTraceRetentionSeconds.value as Record<
          string,
          number
        >;
        const retention = retMap[newSurf] ?? 600;
        const fpId = `fp_${state.run.runId}_${Math.round(state.clock.elapsedRealSeconds * 10)}_${state.footprints.length}`;
        state.footprints.push({
          id: fpId,
          tileX: newTx,
          tileY: newTy,
          prevId: p.lastFootprintId,
          createdAtElapsedSec: state.clock.elapsedRealSeconds,
          expireAtElapsedSec: state.clock.elapsedRealSeconds + retention,
          surface: newSurf,
          baseRetentionSec: retention,
          ageProgress01: 0,
        });
        p.lastFootprintId = fpId;
        p.lastFootprintTileKey = tileKey;

        const maxFp = BALANCE.environment.maxFootprintSegments.value;
        if (state.footprints.length > maxFp) {
          state.footprints = state.footprints.slice(-maxFp);
        }
        revealDiscoveryAroundPlayer(state);
      }

      return { ok: true, state };
    }

    case 'START_ACT_ON_TARGET': {
      const p = state.actors.player;
      if (p.activeCast) {
        return reject('Action already in windup/recovery');
      }
      if (state.clock.elapsedRealSeconds < p.cooldownUntilSec) {
        return reject('Weapon/skill on cooldown');
      }

      const handItem = intent.itemInstanceId
        ? state.items[intent.itemInstanceId] ?? null
        : getEquippedItem(state, 'hand');

      if (intent.itemInstanceId && (!handItem || !isPlayerHeldLocation(handItem.location))) {
        return reject('Item not in Adventurer custody');
      }

      const iDef = handItem ? ITEMS[handItem.defId] : null;
      const skillId = iDef?.weaponProfile?.skillId ?? 'basic_slash';
      const skill = SKILLS[skillId];
      if (!skill) return reject('Invalid skill driver');

      if (skill.spendsCoreCharge && (!handItem || (handItem.charges ?? 0) <= 0)) {
        return reject('Core has 0 charges remaining');
      }

      const dx = intent.targetWorldX - p.x;
      const dy = intent.targetWorldY - p.y;
      if (Math.abs(dx) >= Math.abs(dy)) {
        p.facing = dx >= 0 ? 'right' : 'left';
      } else {
        p.facing = dy >= 0 ? 'down' : 'up';
      }

      recordIntent();
      const windupSec = skill.windupMs / 1000;
      const commitSec = skill.commitMs / 1000;
      const totalSec = (skill.commitMs + skill.recoveryMs) / 1000;

      p.activeCast = {
        intentId: intent.intentId,
        itemInstanceId: handItem?.instanceId ?? null,
        skillId,
        targetX: intent.targetWorldX,
        targetY: intent.targetWorldY,
        targetEntityId: intent.targetEntityId,
        startedAtElapsedSec: state.clock.elapsedRealSeconds,
        windupSec,
        commitSec,
        totalSec,
        committed: false,
      };
      p.cooldownUntilSec =
        state.clock.elapsedRealSeconds + (iDef?.weaponProfile?.cooldownMs ?? 400) / 1000;

      return { ok: true, state };
    }

    case 'CANCEL_ACTIVE_CAST': {
      const cast = state.actors.player.activeCast;
      if (!cast) return reject('No active cast to cancel');
      if (cast.committed) {
        return reject('Cast already passed commit milestone');
      }
      recordIntent();
      state.actors.player.activeCast = null;
      state.actors.player.cooldownUntilSec = state.clock.elapsedRealSeconds;
      const receipt = appendReceipt(
        state,
        intent.intentId,
        'C03/C05',
        nowUtcMs,
        `Canceled ${cast.skillId} before commit milestone (0 charges/durability spent).`
      );
      return { ok: true, state, receipt };
    }

    case 'INTERACT_NEARBY': {
      const p = state.actors.player;
      recordIntent();

      // 1. Check nearby ground drop items first
      for (const item of Object.values(state.items)) {
        if (
          item.location.kind === 'ground_drop' &&
          distPx(p.x, p.y, item.location.x, item.location.y) <= 36
        ) {
          const openSlot = findOpenPlayerSlot(state);
          if (!openSlot) return reject('Inventory full');
          item.location = openSlot;
          const rcpt = appendReceipt(
            state,
            intent.intentId,
            'C07',
            nowUtcMs,
            `Picked up ${item.count}x ${ITEMS[item.defId]?.name ?? item.defId}.`,
            item.instanceId
          );
          assertCustodyInvariants(state);
          return { ok: true, state, receipt: rcpt };
        }
      }

      // 2. Check nearby death bag
      for (const bag of Object.values(state.deathBags)) {
        if (distPx(p.x, p.y, bag.x, bag.y) <= 42) {
          state.processedIntentIds.pop();
          state.revision -= 1;
          return dispatchAction(
            currentState,
            { intentId: intent.intentId, kind: 'RECOVER_DEATH_BAG', bagId: bag.id },
            nowUtcMs
          );
        }
      }

      // 3. Check nearby interactable sources (crates, barrels, lockers, springs, Final-72 vaults!)
      let nearestSrc: SourceNodeInstance | null = null;
      let nearestDist = 46;
      for (const src of Object.values(state.sourceStocks)) {
        if (src.stock <= 0) continue;
        if (intent.targetId && src.id !== intent.targetId) continue;
        const sDef = SOURCES[src.defId];
        if (!sDef?.interactLoot && !intent.targetId) continue;
        const d = distPx(p.x, p.y, src.tileX * 16 + 8, src.tileY * 16 + 8);
        if (d <= nearestDist) {
          nearestDist = d;
          nearestSrc = src;
        }
      }

      if (nearestSrc) {
        const sDef = SOURCES[nearestSrc.defId];
        if (sDef?.onlyFinal72 && state.clock.phase === 'normal') {
          return reject('Final-72 Ragnarok Treasury Vault is time-locked until Final 72h phase!');
        }
        if (nearestSrc.isDeepPoi && nearestSrc.poiId) {
          const poi = state.world.pois.find((x) => x.id === nearestSrc!.poiId);
          if (poi && !poi.unlockedDeep) {
            return reject('Locked behind deep POI security gate!');
          }
        }
        const hand = getEquippedItem(state, 'hand');
        const rcpt = resolveHarvestOnSource(
          state,
          nearestSrc,
          hand,
          false,
          1.0,
          intent.intentId,
          nowUtcMs
        );
        if (!rcpt) return reject('Cannot harvest/loot source right now');
        assertCustodyInvariants(state);
        return { ok: true, state, receipt: rcpt };
      }

      // 4. Check nearby doors or POI gates
      for (const st of Object.values(state.structures)) {
        if (st.hp <= 0) continue;
        const sDef = STRUCTURES[st.defId];
        if (!sDef?.isDoor) continue;
        const d = distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8);
        if (d <= 38) {
          if (st.ownerId === 'world_poi' && st.poiId) {
            state.processedIntentIds.pop();
            state.revision -= 1;
            return dispatchAction(
              currentState,
              { intentId: intent.intentId, kind: 'UNLOCK_POI_GATE', poiId: st.poiId },
              nowUtcMs
            );
          } else {
            state.processedIntentIds.pop();
            state.revision -= 1;
            return dispatchAction(
              currentState,
              { intentId: intent.intentId, kind: 'TOGGLE_DOOR', structureId: st.id },
              nowUtcMs
            );
          }
        }
      }

      return reject('Nothing within reach to interact with');
    }

    case 'USE_ITEM': {
      const item = state.items[intent.itemInstanceId];
      if (!item || !isPlayerHeldLocation(item.location)) {
        return reject('Item must be in Adventurer bag/quickbar');
      }
      const def = ITEMS[item.defId];
      if (!def) return reject('Unknown item');

      if (def.blueprintRecipeId) {
        if (state.run.learnedRecipeIds.includes(def.blueprintRecipeId)) {
          return reject('Recipe already learned in this run');
        }
        recordIntent();
        state.run.learnedRecipeIds.push(def.blueprintRecipeId);
        item.count -= 1;
        if (item.count <= 0) delete state.items[item.instanceId];
        const rcpt = appendReceipt(
          state,
          intent.intentId,
          'C04',
          nowUtcMs,
          `Studied ${def.name} -> learned ${RECIPES[def.blueprintRecipeId]?.name ?? def.blueprintRecipeId}.`,
          item.instanceId
        );
        assertCustodyInvariants(state);
        return { ok: true, state, receipt: rcpt };
      }

      if (def.consumeEffects) {
        recordIntent();
        const p = state.actors.player;
        const eff = def.consumeEffects;
        if (eff.hp) p.hp = Math.max(1, Math.min(p.maxHp, p.hp + eff.hp));
        if (eff.hunger)
          p.hunger = Math.min(BALANCE.player.maxHunger.value, p.hunger + eff.hunger);
        if (eff.thirst)
          p.thirst = Math.min(BALANCE.player.maxThirst.value, p.thirst + eff.thirst);
        if (eff.tempRelief) {
          p.tempStress =
            p.tempStress > 0
              ? Math.max(0, p.tempStress - eff.tempRelief)
              : Math.min(0, p.tempStress + eff.tempRelief);
        }
        if (eff.clearRadiation) {
          p.radDose = Math.max(0, p.radDose - eff.clearRadiation);
        }
        item.count -= 1;
        if (item.count <= 0) delete state.items[item.instanceId];
        const rcpt = appendReceipt(
          state,
          intent.intentId,
          'K1/K5',
          nowUtcMs,
          `Consumed ${def.name}.`,
          item.instanceId
        );
        assertCustodyInvariants(state);
        return { ok: true, state, receipt: rcpt };
      }

      return reject(`${def.name} cannot be consumed directly`);
    }

    case 'EQUIP_ITEM': {
      const item = state.items[intent.itemInstanceId];
      if (!item || !isPlayerHeldLocation(item.location)) {
        return reject('Item must be in Adventurer custody to equip');
      }
      const def = ITEMS[item.defId];
      const slot = intent.slot ?? def?.equipSlot;
      if (!def || !slot || def.equipSlot !== slot) {
        return reject('Item is not equippable in that slot');
      }
      recordIntent();
      const targetLoc: CustodyLocation = { kind: 'player_equip', equipSlot: slot };
      const currentlyEquipped = findItemAtLocation(state, targetLoc);
      const prevLoc = item.location;
      item.location = targetLoc;
      if (currentlyEquipped && currentlyEquipped.instanceId !== item.instanceId) {
        currentlyEquipped.location = prevLoc;
      }
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C03/C07',
        nowUtcMs,
        `Equipped ${def.name} (${slot}).`,
        item.instanceId
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'UNEQUIP_ITEM': {
      const equipped = getEquippedItem(state, intent.slot);
      if (!equipped) return reject('Nothing equipped in slot');
      const open = findOpenPlayerSlot(state);
      if (!open) return reject('No free bag/quickbar slot to unequip');
      recordIntent();
      equipped.location = open;
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `Unequipped ${ITEMS[equipped.defId]?.name ?? equipped.defId}.`,
        equipped.instanceId
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'TRANSFER_ITEM': {
      const item = state.items[intent.itemInstanceId];
      if (!item) return reject('Item instance not found');
      const def = ITEMS[item.defId];
      if (!def) return reject('Unknown item definition');

      // Validate physical reach to source and destination containers!
      const p = state.actors.player;
      const checkReach = (loc: CustodyLocation): string | null => {
        if (isPlayerHeldLocation(loc)) return null;
        if (loc.kind === 'structure_container') {
          const st = state.structures[loc.structureId];
          if (!st || st.hp <= 0) return 'Target container missing';
          if (distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) > 64) {
            return 'Too far from structure container';
          }
          const maxSlots = STRUCTURES[st.defId]?.containerSlots ?? 6;
          if (loc.slotIndex < 0 || loc.slotIndex >= maxSlots) return 'Invalid container slot';
          return null;
        }
        if (loc.kind === 'vehicle_cargo') {
          const vh = state.vehicles[loc.vehicleId];
          if (!vh || vh.hp <= 0) return 'Hand-Cart not found';
          if (distPx(p.x, p.y, vh.x, vh.y) > 64) return 'Too far from Hand-Cart';
          if (loc.slotIndex < 0 || loc.slotIndex >= BALANCE.freight.handCartSlots.value) {
            return 'Invalid cart slot';
          }
          return null;
        }
        if (loc.kind === 'death_bag') {
          const bag = state.deathBags[loc.bagId];
          if (!bag) return 'Death bag missing';
          if (distPx(p.x, p.y, bag.x, bag.y) > 56) return 'Must physically reach death bag';
          return null;
        }
        if (loc.kind === 'ground_drop') {
          if (distPx(p.x, p.y, loc.x, loc.y) > 64) return 'Too far to reach ground item';
          return null;
        }
        return null;
      };

      const errFrom = checkReach(item.location);
      if (errFrom) return reject(errFrom);
      const errTo = checkReach(intent.toLocation);
      if (errTo) return reject(errTo);

      if (locationsEqual(item.location, intent.toLocation)) {
        return { ok: true, state };
      }

      // Check cart mass cap if moving into vehicle_cargo
      if (
        intent.toLocation.kind === 'vehicle_cargo' &&
        !(
          item.location.kind === 'vehicle_cargo' &&
          item.location.vehicleId === intent.toLocation.vehicleId
        )
      ) {
        const moveCnt = Math.min(item.count, intent.count ?? item.count);
        const curCartKg = computeVehicleCargoMassKg(state, intent.toLocation.vehicleId);
        if (curCartKg + moveCnt * def.massKg > BALANCE.freight.handCartCargoCapacityKg.value) {
          return reject('Exceeds Hand-Cart 95kg cargo capacity');
        }
      }

      recordIntent();
      if (intent.toLocation.kind === 'ground_drop') {
        item.location = intent.toLocation;
      } else {
        const destOccupant = findItemAtLocation(state, intent.toLocation);
        if (!destOccupant) {
          item.location = intent.toLocation;
        } else if (
          destOccupant.defId === item.defId &&
          !def.uniqueInstance &&
          destOccupant.count < def.stackLimit
        ) {
          const canAdd = Math.min(def.stackLimit - destOccupant.count, item.count);
          destOccupant.count += canAdd;
          item.count -= canAdd;
          if (item.count <= 0) delete state.items[item.instanceId];
        } else {
          // Atomic swap preserving both unique instance IDs!
          const prevLoc = item.location;
          item.location = intent.toLocation;
          destOccupant.location = prevLoc;
        }
      }

      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `Transferred ${def.name} -> ${intent.toLocation.kind}.`,
        item.instanceId
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'SPLIT_STACK': {
      const item = state.items[intent.itemInstanceId];
      if (!item || !isPlayerHeldLocation(item.location)) {
        return reject('Item must be in Adventurer bag/quickbar');
      }
      if (intent.splitCount < 1 || intent.splitCount >= item.count) {
        return reject('Invalid split count');
      }
      const openSlot = findOpenPlayerSlot(state);
      if (!openSlot) return reject('Need an empty bag slot to split stack');

      recordIntent();
      item.count -= intent.splitCount;
      const newId = nextDeterministicId('itm_spl', state.run.runId, state.revision);
      state.items[newId] = {
        ...structuredClone(item),
        instanceId: newId,
        count: intent.splitCount,
        location: openSlot,
      };
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `Split ${intent.splitCount}x ${ITEMS[item.defId]?.name ?? item.defId} into ${newId}.`,
        item.instanceId
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'BUILD_STRUCTURE': {
      const def = STRUCTURES[intent.structureDefId];
      if (!def) return reject('Unknown structure');
      const check = checkBuildPlacementValidity(state, intent.structureDefId, intent.tileX, intent.tileY);
      if (!check.valid) return reject(check.reason ?? 'Invalid build site');

      recordIntent();
      if (def.deployFromItemOnly) {
        if (!debitPlayerMaterials(state, [{ itemId: def.deployFromItemOnly, count: 1 }])) {
          return reject(`Requires physical ${ITEMS[def.deployFromItemOnly]?.name ?? def.deployFromItemOnly} in inventory`);
        }
      } else {
        if (!debitPlayerMaterials(state, def.cost)) {
          return reject('Insufficient construction materials in Adventurer custody');
        }
      }

      const stId = nextDeterministicId('str', state.run.runId, state.revision);
      const rcptId = nextDeterministicId('rcpt_bld', state.run.runId, state.revision);
      state.structures[stId] = {
        id: stId,
        defId: def.id,
        tileX: intent.tileX,
        tileY: intent.tileY,
        hp: def.maxHp,
        maxHp: def.maxHp,
        ownerId: 'player',
        isOpen: def.isDoor ? false : undefined,
        fuelRemainingSec: 0,
        activeJobId: null,
        turretCooldownMs: def.isTurret ? 0 : undefined,
        createdReceiptId: rcptId,
      };

      if (def.isBed) {
        state.actors.player.bedStructureId = stId;
      }
      if (def.isTerritoryClaim) {
        awardUniqueScoreEvent(state, 'first_shelter_claimed', 'first_shelter_claimed', rcptId);
        recognizeOptionalHint(state, 'hint_home_claim', rcptId);
      }

      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `Built ${def.name} at (${intent.tileX}, ${intent.tileY}).`,
        stId
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'DEPLOY_VEHICLE': {
      const item = state.items[intent.itemInstanceId];
      if (!item || !isPlayerHeldLocation(item.location)) {
        return reject('Hand-Cart Kit must be in Adventurer inventory');
      }
      const def = ITEMS[item.defId];
      if (!def?.deployVehicleType) return reject('Item is not a deployable vehicle');
      if (!isTileWalkable(state, intent.tileX, intent.tileY, { forCart: true })) {
        return reject('Target ground cannot support Hand-Cart');
      }
      const p = state.actors.player;
      if (Math.hypot(intent.tileX * 16 + 8 - p.x, intent.tileY * 16 + 8 - p.y) > 72) {
        return reject('Too far to deploy Hand-Cart');
      }

      recordIntent();
      delete state.items[item.instanceId];
      const vId = nextDeterministicId('veh', state.run.runId, state.revision);
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07/C13',
        nowUtcMs,
        `Deployed Freight Hand-Cart at (${intent.tileX}, ${intent.tileY}).`,
        vId
      );
      state.vehicles[vId] = {
        id: vId,
        type: 'hand_cart',
        x: intent.tileX * 16 + 8,
        y: intent.tileY * 16 + 8,
        hp: 180,
        maxHp: 180,
        ownerId: 'player',
        createdReceiptId: rcpt.receiptId,
      };
      p.tetheredVehicleId = vId;
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'TOGGLE_CART_TETHER': {
      const v = state.vehicles[intent.vehicleId];
      if (!v) return reject('Hand-Cart not found');
      const p = state.actors.player;
      if (p.tetheredVehicleId === v.id) {
        recordIntent();
        p.tetheredVehicleId = null;
        const rcpt = appendReceipt(state, intent.intentId, 'C13', nowUtcMs, 'Parked Hand-Cart.', v.id);
        return { ok: true, state, receipt: rcpt };
      }
      if (distPx(p.x, p.y, v.x, v.y) > 48) {
        return reject('Walk closer to Hand-Cart handles to hitch');
      }
      recordIntent();
      p.tetheredVehicleId = v.id;
      const rcpt = appendReceipt(state, intent.intentId, 'C13', nowUtcMs, 'Hitched Freight Hand-Cart.', v.id);
      return { ok: true, state, receipt: rcpt };
    }

    case 'RECLAIM_STRUCTURE': {
      const st = state.structures[intent.structureId];
      if (!st || st.ownerId !== 'player') return reject('Cannot reclaim non-owned structure');
      const p = state.actors.player;
      if (distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) > 72) {
        return reject('Move closer to reclaim structure');
      }
      // Enforce loaded container reclaim policy (C07)
      const heldItems = listStructureItems(state, st.id);
      if (heldItems.length > 0) {
        return reject('Container is non-empty! Transfer contents out before reclaiming (0 items lost).');
      }
      if (st.activeJobId && state.jobs[st.activeJobId]?.status === 'active') {
        return reject('Cancel or claim active station job before reclaiming');
      }
      const sDef = STRUCTURES[st.defId];
      if (!sDef) return reject('Unknown structure');

      // Prevent removing last Territory Claim Cabinet if an Escrow Chest depends on it
      if (sDef.isTerritoryClaim) {
        const escrowDepending = Object.values(state.structures).some(
          (other) =>
            other.id !== st.id &&
            STRUCTURES[other.defId]?.isEscrowChest &&
            Math.max(Math.abs(other.tileX - st.tileX), Math.abs(other.tileY - st.tileY)) <=
              BALANCE.territoryAndBuild.claimRadiusTiles.value
        );
        if (escrowDepending) {
          return reject('Reclaim placed Rương ký gửi (Escrow Chest) inside territory first');
        }
      }

      recordIntent();
      const rcptId = nextDeterministicId('rcpt_rcl', state.run.runId, state.revision);
      let sub = 1;
      if (sDef.deployFromItemOnly) {
        grantItemsToPlayerOrGround(state, sDef.deployFromItemOnly, 1, rcptId, sub++);
      } else {
        const ratio =
          BALANCE.territoryAndBuild.reclaimMaterialReturnRatio.value * (st.hp / st.maxHp);
        for (const c of sDef.cost) {
          const ret = Math.floor(c.count * ratio);
          if (ret > 0) {
            const g = grantItemsToPlayerOrGround(state, c.itemId, ret, rcptId, sub);
            sub = g.subIndexNext;
          }
        }
      }

      if (state.actors.player.bedStructureId === st.id) {
        state.actors.player.bedStructureId = null;
      }
      delete state.structures[st.id];
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `Reclaimed ${sDef.name}.`,
        st.id
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'REPAIR_STRUCTURE': {
      const st = state.structures[intent.structureId];
      if (!st || st.ownerId !== 'player') return reject('Structure not owned');
      if (st.hp >= st.maxHp) return reject('Structure already at full HP');
      const sDef = STRUCTURES[st.defId];
      if (!sDef) return reject('Unknown structure');
      const primaryMat = sDef.cost[0]?.itemId ?? 'wood_plank';
      if (primaryMat === 'escrow_chest_item') {
        if (!debitPlayerMaterials(state, [{ itemId: 'iron_ingot', count: 1 }])) {
          return reject('Need 1 Iron Ingot to repair Escrow Vault');
        }
      } else if (!debitPlayerMaterials(state, [{ itemId: primaryMat, count: 1 }])) {
        return reject(`Need 1 ${ITEMS[primaryMat]?.name ?? primaryMat} to repair`);
      }

      recordIntent();
      st.hp = Math.min(st.maxHp, st.hp + Math.ceil(st.maxHp * 0.45));
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `Repaired ${sDef.name} (${st.hp}/${st.maxHp} HP).`,
        st.id
      );
      return { ok: true, state, receipt: rcpt };
    }

    case 'TOGGLE_DOOR': {
      const st = state.structures[intent.structureId];
      if (!st || st.hp <= 0) return reject('Door not found');
      const sDef = STRUCTURES[st.defId];
      if (!sDef?.isDoor) return reject('Not a door');
      const p = state.actors.player;
      if (distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) > 48) {
        return reject('Too far from door');
      }
      if (sDef.requiresPowerToOperate && !isTilePowered(state, st.tileX, st.tileY)) {
        return reject('Powered Blast Door has no active generator/turbine power!');
      }
      recordIntent();
      st.isOpen = !st.isOpen;
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C07',
        nowUtcMs,
        `${st.isOpen ? 'Opened' : 'Closed'} ${sDef.name}.`,
        st.id
      );
      return { ok: true, state, receipt: rcpt };
    }

    case 'UNLOCK_POI_GATE': {
      const poi = state.world.pois.find((x) => x.id === intent.poiId);
      if (!poi || !poi.gateStructureId) return reject('POI gate not found');
      const gate = state.structures[poi.gateStructureId];
      if (!gate) return reject('Gate missing');
      const p = state.actors.player;
      if (distPx(p.x, p.y, gate.tileX * 16 + 8, gate.tileY * 16 + 8) > 54) {
        return reject('Approach POI security gate to interact');
      }

      const pDef = POIS[poi.defId];
      // Anti-softlock rule (C11): If Adventurer is INSIDE the POI room and gate closed, emergency interior latch always opens outward!
      const playerInsideRoom =
        p.y < gate.tileY * 16 &&
        Math.abs(Math.floor(p.x / 16) - poi.centerX) <= Math.floor(poi.widthTiles / 2);

      if (poi.unlockedDeep || playerInsideRoom) {
        recordIntent();
        gate.isOpen = !gate.isOpen;
        poi.unlockedDeep = true;
        const rcpt = appendReceipt(
          state,
          intent.intentId,
          'C11',
          nowUtcMs,
          `${gate.isOpen ? 'Opened' : 'Closed'} ${poi.name} gate${playerInsideRoom ? ' (interior emergency release)' : ''}.`,
          poi.id
        );
        return { ok: true, state, receipt: rcpt };
      }

      // Check specific POI gate requirements
      if (pDef.gateType === 'fuse' || pDef.gateType === 'hazard_and_fuse') {
        if (!debitPlayerMaterials(state, [{ itemId: 'bunker_fuse', count: 1 }])) {
          return reject(`${poi.name} requires 1x Heavy Relay Fuse to restore gate circuit!`);
        }
        poi.fuseInstalled = true;
      } else if (pDef.gateType === 'power') {
        const poweredByCore = poi.poweredUntilSec > state.clock.elapsedRealSeconds;
        if (!poweredByCore && !debitPlayerMaterials(state, [{ itemId: 'fuel_canister', count: 1 }])) {
          return reject(`${poi.name} gate requires 1x Refined Fuel Can (or Storm Arc Core jolt on relay)!`);
        }
        poi.poweredUntilSec = state.clock.elapsedRealSeconds + 1800;
      } else if (pDef.gateType === 'keycard' || pDef.gateType === 'keycard_and_power') {
        const card = Object.values(state.items).find(
          (i) => i.defId === 'access_card_industrial' && isPlayerHeldLocation(i.location) && (i.charges ?? 1) > 0
        );
        if (!card) {
          return reject(`${poi.name} requires an Industrial Clearance Keycard!`);
        }
        if (pDef.gateType === 'keycard_and_power') {
          const powered = poi.poweredUntilSec > state.clock.elapsedRealSeconds;
          if (!powered && !debitPlayerMaterials(state, [{ itemId: 'fuel_canister', count: 1 }])) {
            return reject(`${poi.name} requires Industrial Keycard AND 1x Refined Fuel Can (or energized relay)!`);
          }
          poi.poweredUntilSec = state.clock.elapsedRealSeconds + 1800;
        }
        card.charges = (card.charges ?? 1) - 1;
        if (card.charges <= 0) {
          delete state.items[card.instanceId];
        }
      }

      recordIntent();
      poi.unlockedDeep = true;
      gate.isOpen = true;
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C11',
        nowUtcMs,
        `Unlocked deep access to ${poi.name}!`,
        poi.id
      );
      awardUniqueScoreEvent(state, `poi_${poi.id}`, 'deep_poi_unlocked', rcpt.receiptId);
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'FUEL_STATION': {
      const st = state.structures[intent.structureId];
      if (!st || st.hp <= 0) return reject('Station not found');
      const sDef = STRUCTURES[st.defId];
      if (!sDef?.usesFuel) return reject('Structure does not burn fuel');
      const p = state.actors.player;
      if (distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) > 64) {
        return reject('Too far from station');
      }
      const fuelItem = state.items[intent.fuelItemInstanceId];
      if (!fuelItem || !isPlayerHeldLocation(fuelItem.location)) {
        return reject('Fuel item must be in Adventurer inventory');
      }
      const fDef = ITEMS[fuelItem.defId];
      if (!fDef?.fuelSeconds) return reject('Item is not valid fuel');

      const useCount = Math.max(1, Math.min(fuelItem.count, intent.count ?? 1));
      recordIntent();
      fuelItem.count -= useCount;
      if (fuelItem.count <= 0) delete state.items[fuelItem.instanceId];
      st.fuelRemainingSec += fDef.fuelSeconds * useCount;

      // Resume paused fuel job if present
      if (st.activeJobId && state.jobs[st.activeJobId]?.status === 'paused_no_fuel') {
        state.jobs[st.activeJobId].status = 'active';
      }

      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C06',
        nowUtcMs,
        `Loaded ${useCount}x ${fDef.name} into ${sDef.name} (+${fDef.fuelSeconds * useCount}s fuel).`,
        st.id
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'START_JOB': {
      const rec = RECIPES[intent.recipeId];
      if (!rec) return reject('Unknown recipe');
      if (!state.run.learnedRecipeIds.includes(rec.id)) {
        return reject('Recipe not yet learned in this run');
      }

      let stationTileX = Math.floor(state.actors.player.x / 16);
      let stationTileY = Math.floor(state.actors.player.y / 16);

      if (rec.station !== 'hand') {
        if (intent.stationId === 'hand') {
          return reject(`Requires a physical ${rec.station.replace('_', ' ')} nearby`);
        }
        const st = state.structures[intent.stationId];
        if (!st || st.hp <= 0 || STRUCTURES[st.defId]?.stationType !== rec.station) {
          return reject(`Requires matching ${rec.station.replace('_', ' ')} station`);
        }
        if (
          distPx(
            state.actors.player.x,
            state.actors.player.y,
            st.tileX * 16 + 8,
            st.tileY * 16 + 8
          ) > 64
        ) {
          return reject('Stand near station to start job');
        }
        if (st.activeJobId && ['active', 'paused_no_fuel', 'paused_no_power', 'completed_unclaimed'].includes(state.jobs[st.activeJobId]?.status ?? '')) {
          return reject('Station already has an active or unclaimed work order');
        }
        if (rec.powerRequired && !isTilePowered(state, st.tileX, st.tileY)) {
          return reject('Station requires active Generator or Wind Turbine power!');
        }
        stationTileX = st.tileX;
        stationTileY = st.tileY;
      }

      if (!debitPlayerMaterials(state, rec.inputs)) {
        return reject('Missing required input materials');
      }

      recordIntent();
      const jobId = nextDeterministicId('job', state.run.runId, state.revision);
      const stObj = intent.stationId !== 'hand' ? state.structures[intent.stationId] : null;
      const needsFuel = rec.fuelSecondsRequired > 0;
      const initialStatus =
        needsFuel && (!stObj || stObj.fuelRemainingSec <= 0)
          ? 'paused_no_fuel'
          : rec.powerRequired && !isTilePowered(state, stationTileX, stationTileY)
            ? 'paused_no_power'
            : 'active';

      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C06',
        nowUtcMs,
        `Started ${rec.name} (${rec.workSeconds}s, ${initialStatus}).`,
        intent.stationId
      );

      state.jobs[jobId] = {
        id: jobId,
        recipeId: rec.id,
        stationId: intent.stationId,
        status: initialStatus,
        progressSec: 0,
        totalWorkSec: rec.workSeconds,
        requiresFuel: needsFuel,
        requiresPower: rec.powerRequired,
        reservedOutputs: structuredClone(rec.outputs),
        startedAtSec: state.clock.elapsedRealSeconds,
        receiptId: rcpt.receiptId,
      };
      if (stObj) {
        stObj.activeJobId = jobId;
      }
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'START_RESEARCH': {
      const st = state.structures[intent.stationId];
      if (!st || st.hp <= 0 || STRUCTURES[st.defId]?.stationType !== 'research_bench') {
        return reject('Requires physical Specimen & Schematic Desk nearby');
      }
      if (
        distPx(
          state.actors.player.x,
          state.actors.player.y,
          st.tileX * 16 + 8,
          st.tileY * 16 + 8
        ) > 64
      ) {
        return reject('Stand next to Research Desk');
      }
      if (
        st.activeJobId &&
        ['active', 'completed_unclaimed'].includes(state.jobs[st.activeJobId]?.status ?? '')
      ) {
        return reject('Research Desk already busy or awaiting claim');
      }

      let chosenRecipeId: string | undefined;
      let summaryText = '';

      if (intent.mode === 'random_spares') {
        const candidates = RECIPES_LIST.filter(
          (r) =>
            !r.starterKnown &&
            !r.specimenOnly &&
            !state.run.learnedRecipeIds.includes(r.id) &&
            !Object.values(state.jobs).some(
              (j) =>
                j.targetLearnRecipeId === r.id &&
                (j.status === 'active' || j.status === 'completed_unclaimed')
            )
        );
        if (candidates.length === 0) {
          return reject('All Spares-eligible recipes are already discovered in this run!');
        }
        const cost = BALANCE.researchAndCores.randomSparesResearchCost.value;
        if (!debitPlayerMaterials(state, [{ itemId: 'spares_token', count: cost }])) {
          return reject(`Requires ${cost}x Technical Spares`);
        }
        const rng = restoreRng(state.rngState);
        chosenRecipeId = candidates[nextInt(rng, 0, candidates.length - 1)].id;
        state.rngState = serializeRng(rng);
        summaryText = `Started Random Spares study (${cost} Spares reserved).`;
      } else if (intent.mode === 'directed_spares') {
        const rec = intent.targetRecipeId ? RECIPES[intent.targetRecipeId] : null;
        if (!rec || rec.specimenOnly || !rec.directedSparesCost) {
          return reject('Recipe cannot be researched via Spares alone');
        }
        if (state.run.learnedRecipeIds.includes(rec.id)) {
          return reject('Recipe already learned in this run');
        }
        if (!debitPlayerMaterials(state, [{ itemId: 'spares_token', count: rec.directedSparesCost }])) {
          return reject(`Requires ${rec.directedSparesCost}x Technical Spares`);
        }
        chosenRecipeId = rec.id;
        summaryText = `Started Directed Study for ${rec.name} (${rec.directedSparesCost} Spares).`;
      } else if (intent.mode === 'specimen') {
        const spec = intent.specimenInstanceId ? state.items[intent.specimenInstanceId] : null;
        if (!spec || !isPlayerHeldLocation(spec.location)) {
          return reject('Specimen item must be in Adventurer custody');
        }
        const specDef = ITEMS[spec.defId];
        if (!specDef?.studyEligible || !specDef.studyRecipeId) {
          return reject('Item is not an eligible research specimen');
        }
        if (state.run.learnedRecipeIds.includes(specDef.studyRecipeId)) {
          return reject('Specimen recipe is already known in this run');
        }
        const minChg = BALANCE.researchAndCores.depletedCoreStudyEligible.value
          ? 0
          : specDef.studyRequiresMinCharges ?? 0;
        if (specDef.maxCharges !== undefined && (spec.charges ?? 0) < minChg) {
          return reject(`Depleted Core (${spec.charges ?? 0} charges) cannot be studied under current prototype policy!`);
        }
        delete state.items[spec.instanceId];
        chosenRecipeId = specDef.studyRecipeId;
        summaryText = `Committed destructive specimen study of ${specDef.name}.`;
      } else if (intent.mode === 'blueprint') {
        const bp = intent.specimenInstanceId ? state.items[intent.specimenInstanceId] : null;
        if (!bp || !isPlayerHeldLocation(bp.location)) {
          return reject('Blueprint must be in Adventurer custody');
        }
        const bpDef = ITEMS[bp.defId];
        if (!bpDef?.blueprintRecipeId) return reject('Not a blueprint');
        if (state.run.learnedRecipeIds.includes(bpDef.blueprintRecipeId)) {
          return reject('Blueprint recipe already known');
        }
        bp.count -= 1;
        if (bp.count <= 0) delete state.items[bp.instanceId];
        chosenRecipeId = bpDef.blueprintRecipeId;
        summaryText = `Transcribing ${bpDef.name} at Research Desk.`;
      }

      if (!chosenRecipeId) return reject('No valid research target');

      recordIntent();
      const jobId = nextDeterministicId('job_res', state.run.runId, state.revision);
      const rcpt = appendReceipt(state, intent.intentId, 'C04', nowUtcMs, summaryText, st.id, {
        mode: intent.mode,
        targetLearnRecipeId: chosenRecipeId,
      });

      state.jobs[jobId] = {
        id: jobId,
        recipeId: chosenRecipeId,
        researchMode: intent.mode,
        targetLearnRecipeId: chosenRecipeId,
        stationId: st.id,
        status: 'active',
        progressSec: 0,
        totalWorkSec: intent.mode === 'blueprint' ? 3 : 10,
        requiresFuel: false,
        requiresPower: false,
        reservedOutputs: [],
        startedAtSec: state.clock.elapsedRealSeconds,
        receiptId: rcpt.receiptId,
      };
      st.activeJobId = jobId;
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'CANCEL_JOB': {
      const job = state.jobs[intent.jobId];
      if (!job || job.status === 'claimed' || job.status === 'cancelled') {
        return reject('Job cannot be cancelled');
      }
      if (job.status === 'completed_unclaimed') {
        return reject('Job already completed; claim output instead');
      }
      recordIntent();
      job.status = 'cancelled';
      if (job.stationId !== 'hand' && state.structures[job.stationId]?.activeJobId === job.id) {
        state.structures[job.stationId].activeJobId = null;
      }

      // Partial refund (50% rounded down) for non-specimen craft cancellation
      const rcptId = nextDeterministicId('rcpt_cnc', state.run.runId, state.revision);
      if (!job.researchMode) {
        const rec = RECIPES[job.recipeId];
        let sub = 1;
        for (const inp of rec?.inputs ?? []) {
          const refund = Math.floor(inp.count * 0.5);
          if (refund > 0) {
            const g = grantItemsToPlayerOrGround(state, inp.itemId, refund, rcptId, sub);
            sub = g.subIndexNext;
          }
        }
      }
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C04/C06',
        nowUtcMs,
        `Cancelled job ${job.id}.`,
        job.id
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'CLAIM_JOB_OUTPUT': {
      const job = state.jobs[intent.jobId];
      if (!job || job.status !== 'completed_unclaimed') {
        return reject('Job output is not ready or already claimed');
      }

      if (job.stationId !== 'hand') {
        const st = state.structures[job.stationId];
        if (!st || st.hp <= 0) return reject('Station destroyed');
        if (
          distPx(
            state.actors.player.x,
            state.actors.player.y,
            st.tileX * 16 + 8,
            st.tileY * 16 + 8
          ) > 68
        ) {
          return reject('Must physically stand at station to collect output (no remote delivery)');
        }
      }

      recordIntent();
      job.status = 'claimed';
      if (job.stationId !== 'hand' && state.structures[job.stationId]?.activeJobId === job.id) {
        state.structures[job.stationId].activeJobId = null;
      }

      const rcptId = nextDeterministicId('rcpt_clm', state.run.runId, state.revision);
      let summary = '';

      if (job.targetLearnRecipeId) {
        if (!state.run.learnedRecipeIds.includes(job.targetLearnRecipeId)) {
          state.run.learnedRecipeIds.push(job.targetLearnRecipeId);
        }
        const rName = RECIPES[job.targetLearnRecipeId]?.name ?? job.targetLearnRecipeId;
        summary = `Completed research: learned ${rName}!`;
        recognizeOptionalHint(state, 'hint_first_research', rcptId);
      } else {
        let sub = 1;
        for (const out of job.reservedOutputs) {
          if (job.stationId !== 'hand') {
            // Try station output port first, else directly into nearby player bag
            const outSlot = findOpenStructurePortSlot(state, job.stationId, 'output');
            if (outSlot && !ITEMS[out.itemId]?.uniqueInstance) {
              const g = grantItemsToPlayerOrGround(state, out.itemId, out.count, rcptId, sub);
              sub = g.subIndexNext;
            } else {
              const g = grantItemsToPlayerOrGround(state, out.itemId, out.count, rcptId, sub);
              sub = g.subIndexNext;
            }
          } else {
            const g = grantItemsToPlayerOrGround(state, out.itemId, out.count, rcptId, sub);
            sub = g.subIndexNext;
          }
        }
        summary = `Claimed ${RECIPES[job.recipeId]?.name ?? job.recipeId} output.`;
      }

      const rcpt = appendReceipt(state, intent.intentId, job.targetLearnRecipeId ? 'C04' : 'C06', nowUtcMs, summary, job.id);
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'RECOVER_DEATH_BAG': {
      const bag = state.deathBags[intent.bagId];
      if (!bag) return reject('Death bag not found');
      const p = state.actors.player;
      if (distPx(p.x, p.y, bag.x, bag.y) > 54) {
        return reject('Must physically travel to Death Bag location to recover items');
      }

      recordIntent();
      const bagItems = Object.values(state.items).filter(
        (i) => i.location.kind === 'death_bag' && i.location.bagId === bag.id
      );
      let recovered = 0;
      for (const bi of bagItems) {
        const slot =
          bi.defId === 'survival_knife' && !getEquippedItem(state, 'hand')
            ? ({ kind: 'player_equip', equipSlot: 'hand' } as CustodyLocation)
            : findOpenPlayerSlot(state);
        if (slot) {
          bi.location = slot;
          recovered++;
        } else {
          bi.location = { kind: 'ground_drop', x: bag.x, y: bag.y };
        }
      }
      delete state.deathBags[bag.id];
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C10',
        nowUtcMs,
        `Recovered Death Bag (${recovered} item stacks restored).`,
        bag.id
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'SET_OR_REST_BED': {
      const st = state.structures[intent.structureId];
      if (!st || st.hp <= 0 || !STRUCTURES[st.defId]?.isBed) {
        return reject('Valid bed not found');
      }
      const p = state.actors.player;
      if (distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) > 54) {
        return reject('Move next to bed');
      }
      recordIntent();
      p.bedStructureId = st.id;
      p.stamina = BALANCE.player.maxStamina.value;
      p.hp = Math.min(p.maxHp, p.hp + 15);
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'C10',
        nowUtcMs,
        'Bound respawn point to Homestead Bed and rested (+15 HP).',
        st.id
      );
      return { ok: true, state, receipt: rcpt };
    }

    case 'BUY_VENDOR_OFFER': {
      const poi = state.world.pois.find((x) => x.id === intent.poiId);
      const pDef = poi ? POIS[poi.defId] : null;
      if (!poi || !pDef?.isVendor || !pDef.vendorCatalog) {
        return reject('Vendor outpost not found');
      }
      const p = state.actors.player;
      if (distPx(p.x, p.y, poi.centerX * 16 + 8, poi.centerY * 16 + 8) > 96) {
        return reject('Travel physically to Freeport Quartermaster Post to trade');
      }
      const offer = pDef.vendorCatalog.find((o) => o.id === intent.offerId);
      if (!offer) return reject('Unknown vendor offer');
      const remStock = state.vendorStocks[offer.id] ?? 0;
      if (remStock <= 0) return reject('Vendor is out of stock for this item in current run');

      let paidSource = '';
      if (offer.currency === 'profile_secured_cash') {
        if (state.profile.securedRagnarokCash < offer.price) {
          return reject(`Insufficient Secured Profile Cash (need ${offer.price}, have ${state.profile.securedRagnarokCash})`);
        }
        recordIntent();
        state.profile.securedRagnarokCash -= offer.price;
        paidSource = `${offer.price} Secured Profile Cash`;
      } else {
        // physical_or_profile_cash (PROPOSED_MECHANISM for zero-wallet first Rương ký gửi purchase!)
        const physCash = countPlayerItem(state, 'ragnarok_cash');
        if (physCash >= offer.price) {
          recordIntent();
          debitPlayerMaterials(state, [{ itemId: 'ragnarok_cash', count: offer.price }]);
          paidSource = `${offer.price} Physical Ragnarok Cash`;
        } else if (state.profile.securedRagnarokCash >= offer.price) {
          recordIntent();
          state.profile.securedRagnarokCash -= offer.price;
          paidSource = `${offer.price} Secured Profile Cash`;
        } else {
          return reject(
            `Need ${offer.price} Physical Ragnarok Cash (have ${physCash}) or Secured Cash (have ${state.profile.securedRagnarokCash})`
          );
        }
      }

      state.vendorStocks[offer.id] = remStock - 1;
      const rcptId = nextDeterministicId('rcpt_vnd', state.run.runId, state.revision);
      grantItemsToPlayerOrGround(state, offer.itemId, offer.count, rcptId, 1);
      const rcpt = appendReceipt(
        state,
        intent.intentId,
        offer.itemId === 'escrow_chest_item' ? 'C16' : 'C18',
        nowUtcMs,
        `Purchased run-local ${offer.count}x ${ITEMS[offer.itemId]?.name ?? offer.itemId} for ${paidSource}.`,
        poi.id,
        { offerId: offer.id, remainingStock: state.vendorStocks[offer.id] }
      );
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'DEPOSIT_ESCROW_CASH': {
      const st = state.structures[intent.structureId];
      if (!st || st.hp <= 0 || st.ownerId !== 'player' || !STRUCTURES[st.defId]?.isEscrowChest) {
        return reject('Must interact with a physically placed, player-owned Rương ký gửi (Escrow Vault)');
      }
      if (!isTileInPlayerOwnedTerritory(state, st.tileX, st.tileY)) {
        return reject('Escrow Vault lacks active Territory Claim Cabinet coverage');
      }
      const p = state.actors.player;
      if (distPx(p.x, p.y, st.tileX * 16 + 8, st.tileY * 16 + 8) > 58) {
        return reject('Stand next to placed Rương ký gửi to deposit cash');
      }
      const heldCash = countPlayerItem(state, 'ragnarok_cash');
      if (heldCash <= 0) {
        return reject('No physical Ragnarok Vault Scrip in Adventurer custody');
      }
      const depositAmt = Math.max(1, Math.min(heldCash, intent.amount ?? heldCash));

      recordIntent();
      const rcptId = nextDeterministicId('rcpt_esc', state.run.runId, state.revision);
      if (state.profile.depositReceiptIds.includes(rcptId)) {
        return reject('Deposit receipt already applied');
      }

      if (!debitPlayerMaterials(state, [{ itemId: 'ragnarok_cash', count: depositAmt }])) {
        return reject('Failed to debit physical Ragnarok cash');
      }

      state.profile.securedRagnarokCash += depositAmt;
      state.profile.depositReceiptIds.push(rcptId);
      state.run.cashDepositedThisRun += depositAmt;
      awardUniqueScoreEvent(state, 'first_escrow_deposit', 'first_escrow_deposit', rcptId);

      const rcpt: EventReceipt = {
        receiptId: rcptId,
        intentId: intent.intentId,
        contractEdge: 'C17',
        runId: state.run.runId,
        revision: state.revision,
        timestampUtcMs: nowUtcMs,
        elapsedSec: Math.round(state.clock.elapsedRealSeconds * 100) / 100,
        actorId: 'player',
        sourceId: st.id,
        summary: `Escrow deposit committed: +${depositAmt} Secured Ragnarok Cash (Profile total: ${state.profile.securedRagnarokCash}).`,
        details: {
          deposited: depositAmt,
          profileSecuredBalance: state.profile.securedRagnarokCash,
        },
      };
      state.eventReceipts.push(rcpt);
      assertCustodyInvariants(state);
      return { ok: true, state, receipt: rcpt };
    }

    case 'EVACUATE_RUN': {
      const poi = state.world.pois.find((x) => x.id === intent.poiId);
      const pDef = poi ? POIS[poi.defId] : null;
      if (!poi || !pDef?.isEvacuationSite) {
        return reject('Must be at Cape Beacon Evacuation Dock');
      }
      const p = state.actors.player;
      if (distPx(p.x, p.y, poi.centerX * 16 + 8, poi.centerY * 16 + 8) > 84) {
        return reject('Physically board the Cape Beacon Evacuation Dock first');
      }

      const inFinal72 = state.clock.phase !== 'normal';
      const hasFlare = countPlayerItem(state, 'evac_flare') >= 1;
      if (!inFinal72 && !hasFlare) {
        return reject('Early extraction before Final 72h requires 1x Signal Evacuation Flare!');
      }

      recordIntent();
      if (!inFinal72 && hasFlare) {
        debitPlayerMaterials(state, [{ itemId: 'evac_flare', count: 1 }]);
      }

      const hasAllSixStones = state.run.collectedElderStones.length >= 6;
      const outcome = hasAllSixStones ? 'six_stone_convergence' : 'evacuated';
      const rcpt = finalizeRunOnce(state, outcome, nowUtcMs, intent.intentId);
      if (!rcpt) return reject('Run already finalized');
      return { ok: true, state, receipt: rcpt };
    }

    case 'ABANDON_RUN': {
      recordIntent();
      const rcpt = finalizeRunOnce(state, 'abandoned', nowUtcMs, intent.intentId);
      if (!rcpt) return reject('Run already finalized');
      return { ok: true, state, receipt: rcpt };
    }

    case 'QA_ADVANCE_CLOCK': {
      if (intent.advanceSeconds <= 0) return reject('Advance seconds must be positive');
      recordIntent();
      state.run.qaClockUsed = true;
      state.clock.qaOffsetSeconds += intent.advanceSeconds;
      state.clock.elapsedRealSeconds += intent.advanceSeconds;

      const elapsed = state.clock.elapsedRealSeconds;
      if (elapsed >= BALANCE.clock.maxRunRealSeconds.value) {
        state.clock.phase = 'expired';
        finalizeRunOnce(state, 'expired', nowUtcMs, intent.intentId);
      } else if (elapsed >= BALANCE.clock.elderAwakenStartSeconds.value) {
        state.clock.phase = 'ragnarok_day14_awakened';
        for (const el of state.actors.elders) {
          if (el.alive && el.form === 'latent') {
            const bDef = BOSSES[el.defId];
            el.form = 'awakened';
            el.maxHp = bDef.awakened.maxHp;
            el.hp = bDef.awakened.maxHp;
          }
        }
      } else if (elapsed >= BALANCE.clock.hazardIntensifyStartSeconds.value) {
        state.clock.phase = 'ragnarok_final72';
      }

      const rcpt = appendReceipt(
        state,
        intent.intentId,
        'QA_CLOCK',
        nowUtcMs,
        `[QA DEV] Advanced +${Math.round((intent.advanceSeconds / 3600) * 10) / 10}h run clock -> phase ${state.clock.phase} (QA_ACCELERATED_UNVERIFIED).`
      );
      return { ok: true, state, receipt: rcpt };
    }
  }
}
