export type ApprovalStatus =
  | 'LOCKED_CANON'
  | 'PROTOTYPE_TUNING'
  | 'PROPOSED_MECHANISM'
  | 'REQUIRES_SOURCE';

export type SurfaceType =
  | 'deep_water'
  | 'shallow_water'
  | 'sand'
  | 'grass'
  | 'forest'
  | 'road'
  | 'hills'
  | 'mountain_rock'
  | 'stone'
  | 'marsh'
  | 'ash'
  | 'snow'
  | 'toxic'
  | 'ice';

export type WeatherKind = 'clear' | 'rain' | 'storm' | 'ash_wind' | 'cold_snap';

export type Direction4 = 'up' | 'down' | 'left' | 'right';

export type EquipSlot = 'hand' | 'body' | 'utility';

export type ContainerPort = 'storage' | 'input' | 'fuel' | 'output';

export type CustodyLocation =
  | { kind: 'player_bag'; slotIndex: number }
  | { kind: 'player_quickbar'; slotIndex: number }
  | { kind: 'player_equip'; equipSlot: EquipSlot }
  | { kind: 'structure_container'; structureId: string; port: ContainerPort; slotIndex: number }
  | { kind: 'vehicle_cargo'; vehicleId: string; slotIndex: number }
  | { kind: 'death_bag'; bagId: string; slotIndex: number }
  | { kind: 'ground_drop'; x: number; y: number };

export interface ItemInstance {
  instanceId: string;
  defId: string;
  runId: string;
  count: number;
  durability?: number;
  charges?: number;
  quality: number;
  location: CustodyLocation;
  provenanceReceiptId: string;
  customMeta?: Record<string, string | number | boolean>;
}

export interface SourceNodeInstance {
  id: string;
  defId: string;
  tileX: number;
  tileY: number;
  poiId?: string;
  isDeepPoi?: boolean;
  nonBossFinal72?: boolean;
  stock: number;
  maxStock: number;
  hitsRemaining: number;
  maxHits: number;
  depletedAtElapsedSec: number | null;
  respawnAtElapsedSec: number | null;
  crackedPenalty?: boolean;
  burned?: boolean;
  consumedReceiptIds: string[];
}

export interface StructureInstance {
  id: string;
  defId: string;
  tileX: number;
  tileY: number;
  hp: number;
  maxHp: number;
  ownerId: 'player' | 'world_poi';
  poiId?: string;
  isOpen?: boolean;
  fuelRemainingSec: number;
  activeJobId: string | null;
  turretCooldownMs?: number;
  energizedUntilSec?: number;
  createdReceiptId: string;
}

export interface VehicleInstance {
  id: string;
  type: 'hand_cart';
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  ownerId: 'player';
  createdReceiptId: string;
}

export interface DeathBagInstance {
  id: string;
  x: number;
  y: number;
  createdAtElapsedSec: number;
  deathReceiptId: string;
}

export interface FootprintSegment {
  id: string;
  tileX: number;
  tileY: number;
  prevId: string | null;
  createdAtElapsedSec: number;
  expireAtElapsedSec: number;
  surface: SurfaceType;
  baseRetentionSec: number;
  ageProgress01: number;
}

export interface TerrainEffectInstance {
  id: string;
  tileX: number;
  tileY: number;
  type: 'fire' | 'ice' | 'scorch' | 'toxic_pool';
  materialBefore: SurfaceType;
  startSec: number;
  endSec: number;
  spreadGen: number;
  lastSpreadSec: number;
  sourceEventId: string;
}

export interface WorkJobInstance {
  id: string;
  recipeId: string;
  researchMode?: 'random_spares' | 'directed_spares' | 'specimen' | 'blueprint';
  targetLearnRecipeId?: string;
  stationId: string | 'hand';
  status:
    | 'active'
    | 'paused_no_fuel'
    | 'paused_no_power'
    | 'interrupted_hazard'
    | 'completed_unclaimed'
    | 'claimed'
    | 'cancelled';
  progressSec: number;
  totalWorkSec: number;
  requiresFuel: boolean;
  requiresPower: boolean;
  reservedOutputs: { itemId: string; count: number }[];
  startedAtSec: number;
  receiptId: string;
}

export interface ActiveCastState {
  intentId: string;
  itemInstanceId: string | null;
  skillId: string;
  targetX: number;
  targetY: number;
  targetEntityId?: string;
  startedAtElapsedSec: number;
  windupSec: number;
  commitSec: number;
  totalSec: number;
  committed: boolean;
}

export interface PlayerActor {
  id: 'player';
  x: number;
  y: number;
  facing: Direction4;
  hp: number;
  maxHp: number;
  hunger: number;
  thirst: number;
  stamina: number;
  tempStress: number; // -100 (freezing) to +100 (overheating)
  radDose: number; // 0..100
  slowRemainingSec: number;
  chillRemainingSec: number;
  activeCast: ActiveCastState | null;
  cooldownUntilSec: number;
  bedStructureId: string | null;
  tetheredVehicleId: string | null;
  deathCount: number;
  lastFootprintId: string | null;
  lastFootprintTileKey: string | null;
}

export interface EnemyActor {
  id: string;
  defId: string;
  x: number;
  y: number;
  homeX: number;
  homeY: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  respawnAtSec: number | null;
  aiState:
    | 'patrol'
    | 'pursue_player'
    | 'follow_trail'
    | 'attack_windup'
    | 'search_last_known'
    | 'return_habitat';
  lastSeenPlayerPos: { x: number; y: number } | null;
  followedFootprintId: string | null;
  trailTargetPos: { x: number; y: number } | null;
  discoveredStructureId: string | null;
  lostTimerSec: number;
  patrolAngle: number;
  windupRemainingMs: number;
  windupTargetPos: { x: number; y: number } | null;
  windupTargetStructureId: string | null;
  cooldownRemainingMs: number;
}

export interface ElderActor {
  id: string;
  defId: string;
  x: number;
  y: number;
  homeX: number;
  homeY: number;
  form: 'latent' | 'awakened';
  hp: number;
  maxHp: number;
  alive: boolean;
  defeatedReceiptId: string | null;
  aiState: 'idle' | 'pursue' | 'telegraph_windup' | 'return';
  windupRemainingMs: number;
  telegraphPos: { x: number; y: number; radiusPx: number } | null;
  cooldownRemainingMs: number;
}

export interface WorldPoiInstance {
  id: string;
  defId: string;
  name: string;
  centerX: number;
  centerY: number;
  widthTiles: number;
  heightTiles: number;
  gateTileX: number;
  gateTileY: number;
  gateStructureId: string | null;
  relayTileX: number;
  relayTileY: number;
  unlockedDeep: boolean;
  poweredUntilSec: number;
  fuseInstalled: boolean;
}

export interface SpawnRegion {
  id: string;
  name: string;
  description: string;
  tileX: number;
  tileY: number;
}

export interface EventReceipt {
  receiptId: string;
  intentId: string;
  contractEdge: string;
  runId: string;
  revision: number;
  timestampUtcMs: number;
  elapsedSec: number;
  actorId: string;
  sourceId?: string;
  summary: string;
  details?: Record<string, unknown>;
}

export interface VisualCue {
  id: string;
  kind: 'slash' | 'aoe_blast' | 'line_ray' | 'self_aura' | 'floating_text' | 'hit_spark';
  x: number;
  y: number;
  targetX?: number;
  targetY?: number;
  radiusPx?: number;
  color: string;
  text?: string;
  createdAtSec: number;
  durationSec: number;
}

export interface RunHistoryEntry {
  runId: string;
  runNumber: number;
  adventurerGender: 'male' | 'female';
  spawnRegionId: string;
  outcome: 'evacuated' | 'abandoned' | 'expired' | 'six_stone_convergence';
  elapsedRealSeconds: number;
  elderStonesCollected: string[];
  cashDepositedThisRun: number;
  cashLostUnsecured: number;
  unverifiedLocalScore: number;
  verificationStatus: 'LOCAL_UNVERIFIED' | 'QA_ACCELERATED_UNVERIFIED';
  endedAtUtcMs: number;
  notableReceipts: string[];
}

export interface ProfileState {
  profileId: string;
  securedRagnarokCash: number;
  achievements: string[];
  runHistory: RunHistoryEntry[];
  depositReceiptIds: string[];
  createdAtUtcMs: number;
}

export interface GameState {
  schemaVersion: 1;
  revision: number;
  profile: ProfileState;
  run: {
    runId: string;
    runNumber: number;
    worldSeed: number;
    adventurerGender: 'male' | 'female';
    spawnRegionId: string;
    status: 'active' | 'evacuated' | 'abandoned' | 'expired' | 'six_stone_convergence';
    finalizedOnce: boolean;
    learnedRecipeIds: string[];
    collectedElderStones: string[];
    uniqueScoreEvents: Record<
      string,
      { points: number; receiptId: string; elapsedSec: number }
    >;
    cashDepositedThisRun: number;
    qaClockUsed: boolean;
  };
  clock: {
    startUtcMs: number;
    lastSimulatedUtcMs: number;
    elapsedRealSeconds: number;
    qaOffsetSeconds: number;
    phase: 'normal' | 'ragnarok_final72' | 'ragnarok_day14_awakened' | 'expired';
    fictionalDay: number;
    timeOfDay01: number; // 0.0 midnight .. 0.5 noon .. 1.0 midnight
    season: 'spring' | 'summer' | 'autumn' | 'winter';
    weather: WeatherKind;
    nextWeatherFrontSec: number;
  };
  world: {
    seed: number;
    width: number;
    height: number;
    spawnRegions: SpawnRegion[];
    pois: WorldPoiInstance[];
    discoveredChunks: number[]; // bitset or list of discovered 4x4 chunk indices
  };
  actors: {
    player: PlayerActor;
    enemies: EnemyActor[];
    elders: ElderActor[];
  };
  items: Record<string, ItemInstance>;
  sourceStocks: Record<string, SourceNodeInstance>;
  structures: Record<string, StructureInstance>;
  vehicles: Record<string, VehicleInstance>;
  deathBags: Record<string, DeathBagInstance>;
  footprints: FootprintSegment[];
  terrainEffects: Record<string, TerrainEffectInstance>;
  jobs: Record<string, WorkJobInstance>;
  vendorStocks: Record<string, number>;
  optionalHintsRecognized: Record<string, string>; // hintId -> proof receiptId
  eventReceipts: EventReceipt[];
  processedIntentIds: string[];
  vfxCues: VisualCue[];
  rngState: number[];
}

export type ActionIntent =
  | {
      intentId: string;
      kind: 'MOVE_INPUT';
      dx: number;
      dy: number;
      sprint: boolean;
      dtSec: number;
    }
  | {
      intentId: string;
      kind: 'START_ACT_ON_TARGET';
      itemInstanceId?: string;
      targetWorldX: number;
      targetWorldY: number;
      targetEntityId?: string;
    }
  | {
      intentId: string;
      kind: 'CANCEL_ACTIVE_CAST';
    }
  | {
      intentId: string;
      kind: 'INTERACT_NEARBY';
      targetId?: string;
    }
  | {
      intentId: string;
      kind: 'USE_ITEM';
      itemInstanceId: string;
    }
  | {
      intentId: string;
      kind: 'EQUIP_ITEM';
      itemInstanceId: string;
      slot?: EquipSlot;
    }
  | {
      intentId: string;
      kind: 'UNEQUIP_ITEM';
      slot: EquipSlot;
    }
  | {
      intentId: string;
      kind: 'TRANSFER_ITEM';
      itemInstanceId: string;
      toLocation: CustodyLocation;
      count?: number;
    }
  | {
      intentId: string;
      kind: 'SPLIT_STACK';
      itemInstanceId: string;
      splitCount: number;
    }
  | {
      intentId: string;
      kind: 'BUILD_STRUCTURE';
      structureDefId: string;
      tileX: number;
      tileY: number;
      deployItemInstanceId?: string;
    }
  | {
      intentId: string;
      kind: 'DEPLOY_VEHICLE';
      itemInstanceId: string;
      tileX: number;
      tileY: number;
    }
  | {
      intentId: string;
      kind: 'TOGGLE_CART_TETHER';
      vehicleId: string;
    }
  | {
      intentId: string;
      kind: 'RECLAIM_STRUCTURE';
      structureId: string;
    }
  | {
      intentId: string;
      kind: 'REPAIR_STRUCTURE';
      structureId: string;
    }
  | {
      intentId: string;
      kind: 'TOGGLE_DOOR';
      structureId: string;
    }
  | {
      intentId: string;
      kind: 'UNLOCK_POI_GATE';
      poiId: string;
      credentialItemInstanceId?: string;
    }
  | {
      intentId: string;
      kind: 'FUEL_STATION';
      structureId: string;
      fuelItemInstanceId: string;
      count?: number;
    }
  | {
      intentId: string;
      kind: 'START_JOB';
      recipeId: string;
      stationId: string | 'hand';
    }
  | {
      intentId: string;
      kind: 'START_RESEARCH';
      stationId: string;
      mode: 'random_spares' | 'directed_spares' | 'specimen' | 'blueprint';
      targetRecipeId?: string;
      specimenInstanceId?: string;
    }
  | {
      intentId: string;
      kind: 'CANCEL_JOB';
      jobId: string;
    }
  | {
      intentId: string;
      kind: 'CLAIM_JOB_OUTPUT';
      jobId: string;
    }
  | {
      intentId: string;
      kind: 'RECOVER_DEATH_BAG';
      bagId: string;
    }
  | {
      intentId: string;
      kind: 'SET_OR_REST_BED';
      structureId: string;
      restSeconds?: number;
    }
  | {
      intentId: string;
      kind: 'BUY_VENDOR_OFFER';
      poiId: string;
      offerId: string;
    }
  | {
      intentId: string;
      kind: 'DEPOSIT_ESCROW_CASH';
      structureId: string;
      amount?: number;
    }
  | {
      intentId: string;
      kind: 'EVACUATE_RUN';
      poiId: string;
    }
  | {
      intentId: string;
      kind: 'ABANDON_RUN';
    }
  | {
      intentId: string;
      kind: 'START_NEW_RUN';
      adventurerGender: 'male' | 'female';
      spawnRegionId?: string;
      nowUtcMs: number;
    }
  | {
      intentId: string;
      kind: 'QA_ADVANCE_CLOCK';
      advanceSeconds: number;
    };

export interface DispatchResult {
  ok: boolean;
  reason?: string;
  state: GameState;
  receipt?: EventReceipt;
}
