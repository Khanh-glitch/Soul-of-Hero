# Godot Production Transfer Notes (`GODOT_TRANSFER_NOTES.md`)

> **Scope Boundary**: This browser project (`Soul of Hero: World Simulation Prototype`) is a standalone TypeScript + HTML5 Canvas 2D simulation prototype. It does not modify, emulate, or claim to be the separate Godot production codebase.

## 1. Directly Portable Pure Simulation Contracts (`src/sim/`)

Because 100% of authoritative state, RNG, item custody, world rules, and chronological offline catch-up live in pure deterministic TypeScript (`src/sim/*`) with zero React/DOM dependencies, the following modules map 1-to-1 into Godot 4 (GDScript or C#):

1. **Data-Driven JSON Catalogs (`src/data/*.json`)**:
   - `balance.prototype.v1.json`, `items.json`, `recipes.json`, `sources.json`, `structures.json`, `enemies.json`, `bosses.json`, `skills.json`, and `pois.json` can be loaded directly via `FileAccess.get_file_as_string()` + `JSON.parse_string()` or converted into Godot `Resource` (`.tres`) definitions while retaining `{ value, unit, status }` metadata.
2. **Single-Custody Item Ledger (`src/sim/custody.ts` → K1)**:
   - Retain a single `Dictionary[String, ItemInstance]` keyed by `instance_id` where `location` is a tagged union (`player_bag`, `player_quickbar`, `player_equip`, `structure_container`, `vehicle_cargo`, `death_bag`, `ground_drop`). Never store duplicated item arrays inside UI `Control` nodes.
3. **Replaceable Skill & Boss Drivers (`src/data/skills.json`, `src/data/bosses.json` → Gold Art Plug-In)**:
   - Every skill currently flags `"goldArtStatus": "GOLD_SOURCE_NOT_AVAILABLE"` and separates `windupMs`, `commitMs` (the exact frame/tick where Core charges and weapon durability debit — pre-commit cancel spends zero!), `recoveryMs`, `driverType` (`melee_arc`, `line_ray`, `aoe_blast`, `self_aura`), and `worldMutation` (`ignitesFlammable`, `freezesWaterToIce`, `cracksMineralYieldPenalty`, `energizesPoiRelaySec`).
   - In Godot production, canonical Gold `AnimationPlayer` / `AnimatedSprite2D` method-call tracks should emit the `commit` signal at the authored Gold impact frame, invoking the exact same `commitActiveCastNow` transaction without changing K1 charge/yield semantics.
4. **Non-Omniscient Footprint AI (`src/sim/simulationTick.ts` → C08)**:
   - Map `FootprintSegment` (`prevId`, `expireAtElapsedSec`, surface retention, `3.2×` rain wash multiplier) to a spatial hash grid in Godot. Creature `NavigationAgent2D` queries must never read `claim_cabinet` coordinates from global state; home discovery occurs solely by sensing an unexpired footprint segment within `traceSenseRangePx` + `RayCast2D` LOS and walking contiguous segments.
5. **Bounded Chronological Offline Catch-Up (`src/sim/simulationTick.ts:catchUpOffline` → K8)**:
   - On save load in Godot (`Time.get_unix_time_from_system()`), compute next causal breakpoints (`min(fuelRemainingSec, jobRemainingSec, nextWeatherFrontSec, phaseBoundarySec)`) rather than stepping `_physics_process` 60 times per offline second. Preserve the `1 HP` offline shelter starvation floor while allowing freezing, radiation, fire, and lawful creature paths to resolve lethally.
6. **Ragnarok & `Rương ký gửi` Escrow Invariants (`src/sim/dispatcher.ts` → C15–C18, C22–C23)**:
   - Keep `ProfileState` (`securedRagnarokCash`, `achievements`, `runHistory`, `depositReceiptIds`) in a separate save slot/table from `RunState`, committed atomically on `DEPOSIT_ESCROW_CASH` and `finalizeRunOnce`. If an online leaderboard backend is added later, the server must validate the signed `eventReceipts` chain (`sourceId`, UTC timestamps, non-respawning Final-72 vault IDs) before promoting `LOCAL_UNVERIFIED` to `VERIFIED`.
