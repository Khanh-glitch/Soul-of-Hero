# Soul of Hero: World Simulation Prototype

A cohesive, offline-first, top-down 2D pixel-art solo PvE survival action-RPG prototype built with **TypeScript**, **Vite**, **React (UI only)**, **HTML5 Canvas 2D (640×360 integer-scaled logical pixel renderer)**, and a **pure deterministic TypeScript simulation engine** (`src/sim/`).

---

## Quickstart Commands (Node 20+ & npm)

```bash
npm install                  # Install dependencies (no runtime cloud/API keys required)
npm run dev                  # Start local interactive dev server
npm run build                # Compile standalone offline production bundle (dist/index.html)
npm test                     # Run deterministic C01-C24, negative (a)-(t), fast-check & IndexedDB tests
npm run test:simulation      # Run 48-run (12 playstyle bots x 4 spawns) balance & +-20% sensitivity suite
node scripts/playwright_e2e_and_screenshots.mjs  # Run headless Chromium real-input E2E & capture 8 PNGs
```

---

## Controls (Remappable in `Esc` Menu)

| Input | Action |
| :--- | :--- |
| **`W A S D` / Arrow Keys** | Move Adventurer (writes surface-specific decaying footprints) |
| **`Shift`** | Sprint (consumes Stamina; disabled while pulling hitched Cargo Hand-Cart) |
| **Mouse Aim + Left-Click** | Attack creature, harvest natural/roadside node, place selected Build Ghost, or cast equipped Core |
| **Right-Click / `X`** | Cancel active Build Ghost or cancel Core cast windup pre-commit (`0` charges spent) |
| **`E`** | Contextual Physical Interact (recover Death Bag, claim station output, toggle door, open Escrow Chest / Trader / Evac Beacon, or harvest adjacent node) |
| **`1` – `8`** | Select Quickbar slot & equip/use item |
| **`I`** | Custody & Gear Drawer (Equip, Split Stack `½`, Chest/Cart/Death Bag transfers, Escrow Deposit, Trader) |
| **`C`** | Crafting & Station Work Queues (Hand craft, add Furnace/Campfire fuel, claim station outputs) |
| **`B`** | Construction & Homestead Drawer (24 structures, Homestead Claim Totem, door/repair/reclaim) |
| **`R`** | Knowledge & Specimen Study (Random Spares, Directed Spares, Blueprints, Core/Specimen analysis) |
| **`M`** | 192×192 Island Topology Map (fog-of-war sectors, known POIs, Homestead claims, Death Bags) |
| **`J`** | Optional Contextual Field Notes & Profile Run History (`LOCAL_UNVERIFIED` scores) |
| **`Tab`** | Core Skill Drivers (`GOLD_SOURCE_NOT_AVAILABLE`) & Six Optional Elder Boss status |
| **`Esc`** | Save Snapshot, Non-Omniscient Logout Forecast, Remap Keys, Abandon Run, & Dev/QA Clock Inspector |

---

## Architecture & Core World Laws

- **Author Your Own Story**: No forced `J01→J20` quest chain, tutorial gate, three-button Core popup, mandatory house plot, or mandatory Elder boss fight.
- **Single Authoritative Simulation (`src/sim/`)**: React components read immutable snapshots from `src/store/gameStore.ts` and submit `GameIntent`s through `dispatchIntent(state, intent)`.
- **336h Real UTC Clock & Final-72h Ragnarok**: Runs last up to `336` real UTC hours (`1,209,600s`) including offline time. At `264h` (`950,400s`), Final-72h Ragnarok unlocks 4 finite non-respawning POI Cash Vaults (`ragnarok_treasury_chest`). On Day 14 (`1,123,200s`), six regional Elders awaken.
- **Physical Ragnarok Cash & Homestead Escrow (`Rương ký gửi`)**: Cash originates strictly from finite Final-72h POI chests, is carried physically (and drops into your Death Bag on death), purchases a run-local Escrow Chest at the Crossroads Wayfarer Trader (`PROPOSED_MECHANISM` accepts physical cash on zero-wallet runs), and transfers atomically to `profile.securedCash` only when deployed on owned Homestead territory.
- **Run Finalization & True Run 2**: Physical evacuation at Sunken Harbor (or 6-Elder-stone convergence, abandon, or 336h expiry) wipes 100% of run-local items, Cores, structures, recipes, carts, bags, and undeclared cash, preserving only `profile.securedCash`, `achievements`, and `LOCAL_UNVERIFIED` `runHistory`.

---

## Documentation & Verification Artifacts Included

- `REPOSITORY_RESEARCH_AND_REUSE.md` & `third_party_manifest.json` + `licenses/` — `§1R` open-source & CC0 asset provenance (`simplex-noise`, `rot-js`, `pure-rand`, `idb`, `zzfx`, `pixelarticons`, `vitest`, `fast-check`, `fake-indexeddb`, and **Kenney Tiny Town v1.1 CC0**).
- `MECHANICS_COVERAGE.md` — Traceability across `K1–K8`, `C01–C24`, `J01–J20`, `QA-A01–A09`, and negative abuse tests `(a)–(t)`.
- `BALANCE_REPORT.md` & `simulation_evidence.json` — Coupled equations, 48-run 12-policy metrics, and ±20% sensitivity sweeps from `src/data/balance.prototype.v1.json`.
- `PERSISTENCE_TESTS.md` — Atomic IndexedDB multi-store receipts, tamper rejection, and chronological offline catch-up proofs.
- `VISUAL_REVIEW.md` & `screenshots/01_*.png .. 08_*.png` — Real Chromium visual audit at `640×360` and `1280×720`.
- `GODOT_TRANSFER_NOTES.md` — Clean migration notes for the separate Godot production project.
