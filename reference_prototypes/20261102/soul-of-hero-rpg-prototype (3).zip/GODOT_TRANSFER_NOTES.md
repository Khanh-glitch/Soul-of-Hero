# Godot Production Transfer Notes (`§8`, `§13`)

> **Important Scope Note**: This browser application (`TypeScript + Vite + React + HTML5 Canvas 2D`) is a standalone functional world-simulation prototype. It does **not** modify, wrap, or claim to be the separate Godot production codebase.

## 1. Directly Reusable Data Catalogs (`src/data/*.json`)

All 9 JSON catalogs are engine-agnostic and can be loaded directly via Godot 4's `FileAccess.get_file_as_string()` + `JSON.parse_string()` into typed `Resource` registries:
- `balance.prototype.v1.json`: preserves `LOCKED_CANON`, `PROTOTYPE_TUNING`, `PROPOSED_MECHANISM`, and `REQUIRES_SOURCE` metadata alongside units so designers can tune Godot `Resource` curves without losing canon audit tags.
- `items.json`, `recipes.json`, `sources.json`, `structures.json`, `enemies.json`, `bosses.json`, `pois.json`: share one capability/material vocabulary (`ACT_ON_TARGET`, `USE`, `EQUIP`, `DEPLOY`, `TRANSFER`, `TRANSFORM`, `RECLAIM`; materials `wood | stone | ore | scrap | plant`).

## 2. Replaceable Gold Skill Driver Architecture (`src/data/skills.json`)

To allow drop-in substitution of authentic Gold pixel animations and hitboxes in Godot later (`§2A`, `§13`):
- Simulation (`src/sim/engine.ts`: `START_CORE_CAST` -> `CANCEL_CORE_CAST` -> `commitActiveCoreCast`) decouples **item custody & charge debit** from visual playback.
- A Core charge is debited **strictly at `commitMilestoneMs`**, never on input press or windup start, and environmental mutations (`ignite_vegetation`, `freeze_water`, `crack_mineral`) execute only when `commitActiveCoreCast` writes an authorized `TerrainEffect` receipt.
- In Godot 4, `AnimationPlayer` method-call tracks or custom `SkillDriver` resources can fire the exact `commit_milestone` signal on the authored Gold frame while reusing the identical custody debit and `TerrainEffect` rules.

## 3. Pure Simulation Algorithms Ready for GDScript / C# Port

1. **Single Custody Ledger (`src/sim/custody.ts`)**: Keying every unique tool, Core, credential, and Elder stone by immutable `instance_id` inside one dictionary (`Dictionary[String, ItemInstance]`) with `container_id` pointers (`player_bag`, `structure:<id>`, `cart:<id>`, `death_bag:<id>`) eliminates container-transfer duplication bugs.
2. **Non-Omniscient Footprint Trail Sensing (`src/sim/engine.ts`)**: Monsters query 2D LOS (`NavigationServer2D` / `RayCast2D` in Godot) for direct player sight, and query a spatial ring buffer of decaying `FootprintTrace` segments (`surfaceRetention * rainErosion`) to advance strictly to contiguous newer segments (`dist <= traceSenseRange && LOS`).
3. **Bounded Chronological Offline Settlement (`OFFLINE_CATCHUP`)**: Replaying offline UTC elapsed time in `300s` (5-minute) slices settles `min(sliceSec, station.fuelRemainingSec)`, weather transitions, crop timers, and the `1 HP` enclosed-shelter hunger floor in `O(elapsed / 300)` steps rather than simulating millions of 60Hz frames.
