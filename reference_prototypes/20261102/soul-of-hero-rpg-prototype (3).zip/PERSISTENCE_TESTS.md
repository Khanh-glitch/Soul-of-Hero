# Persistence, Atomic Receipts & Offline Catch-Up Verification (`§6`, `§8`)

## 1. Storage Architecture (`src/sim/persistence.ts`)

Persistence is built on `idb` v8.0.4 (`ISC`, Jake Archibald) opening IndexedDB database `soul_of_hero_world_sim_db` (schema version `1`) with three object stores committed inside **one atomic `readwrite` transaction**:
1. `snapshots` (`keyPath: 'slotId'`): stores `{ slotId, savedAtUtcSec, schemaVersion, revision, state }`.
2. `profiles` (`keyPath: 'profileId'`): stores cross-run `{ profileId, securedCash, achievements, runHistory, depositedReceiptIds }`.
3. `receipts` (`keyPath: 'receiptId'`, indexed `by-run`): stores immutable `EventReceipt` records (`receiptId`, `intentId`, `actionKind`, `runId`, `actorId`, `utcSec`, `revision`, `sourceId`, `summary`).

A synchronized `localStorage` fallback (`soul_of_hero_snapshot_v1`) mirrors the validated snapshot when quota permits.

---

## 2. Anti-Duplication, Tamper Rejection & Custody Validation

On every `dispatchIntent` and every `loadGameStateAtomic`:
1. **Explicit `intentId` & Deposit Token Idempotency**: Re-submitting an already committed `intentId` or `clientDepositToken` (`profile.depositedReceiptIds`) returns `{ accepted: false, reason: 'Duplicate ...' }` with zero mutation (`contracts_c01_c24.test.ts` L100–106, L678–686).
2. **Unique Instance Conservation**: Loading a snapshot never regenerates `instanceId`s; `verifyCustodyInvariants(state)` rejects any snapshot containing duplicate `instanceId`s, slot collisions, or out-of-bounds stack counts (`fast-check` property suite, 25 randomized multi-step runs).
3. **Refusal of Bogus Online `VERIFIED` Claims (`C21`)**: `validateAndSanitizeLoadedState` inspects `profile.runHistory` and rejects tampered local saves claiming anything other than `LOCAL_UNVERIFIED` or impossible million-point scores (`contracts_c01_c24.test.ts` L736–745).

---

## 3. Ordered Offline Catch-Up (`OFFLINE_CATCHUP`)

When reopening a saved run after elapsed real UTC time, `gameStore.initializeFromStorage()` dispatches `OFFLINE_CATCHUP` (`src/sim/engine.ts`), replaying elapsed time in deterministic bounded `300s` (5-minute) chronological batches rather than frame-by-frame ticking:
- **Fuel Exhaustion Boundary**: A `stone_furnace` with `900s` (15m) of fuel over a `7200s` (2h) offline gap processes exactly `900s` of smelting (`15` iron ingots into `station_out:<id>`) and transitions the remaining `10` queued jobs to `paused_no_fuel` (`contracts_c01_c24.test.ts` L335–366).
- **Weather & Trace Ordering**: Scheduled weather shifts extinguish outdoor burning tiles, pause unroofed `campfire` jobs during `storm`, fill outdoor `rain_collector`s, and erode player footprints `4×` faster during precipitation.
- **Shelter Hunger Floor vs. Real Hazards**: Inside an enclosed roofed+walled room, offline hunger/thirst drain cannot reduce HP below `1 HP` (`LOCKED_CANON`), whereas offline hypothermia in `cold` biomes or `radiation` exposure remains lethal (`contracts_c01_c24.test.ts` L368–387).

---

## 4. Cross-Session Reload Proofs Executed

1. **Node + `fake-indexeddb` Cross-Connection Test** (`src/tests/contracts_c01_c24.test.ts` L866–892):
   - Unlocked `research_outpost` deep gate, saved via `saveGameStateAtomic`, closed/reset DB handle via `resetPersistenceConnectionForTests()`, reopened via `loadGameStateAtomic`, ran `OFFLINE_CATCHUP` (`+1800s`), and verified exact `rusty_knife` `instanceId` and `gateUnlocked === true` survived untouched.
2. **Real Headless Chromium Cross-Page Persistence Test** (`scripts/playwright_e2e_and_screenshots.mjs`):
   - Built a 15-piece Homestead cottage (`preReloadRev: 3177`), called `await page.close()`, opened a brand-new `page2 = await context.newPage()` on `http://127.0.0.1:4173`, resumed the run from IndexedDB, and verified `postReloadCheck: { revision: 3213, playerOwnedStructures: 15 }` before completing Ragnarok escrow deposit and Harbor evacuation (`securedCash: 50`).
