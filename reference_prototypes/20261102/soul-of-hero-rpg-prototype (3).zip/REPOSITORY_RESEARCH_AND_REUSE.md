# Repository Research, Selective Reuse & Integration (`§1R` Evidence)

## 1. Reuse-First Methodology & Hard Licensing Gate

Before authoring game-specific subsystems, live external discovery was executed across npm, GitHub, and OpenGameArt to evaluate candidate open-source primitives and openly licensed 16×16 pixel-art packs. Every adopted component was verified for:
1. Permissive redistribution compatibility (`MIT`, `BSD-3-Clause`, `ISC`, `Apache-2.0`, `CC0-1.0`) with verbatim upstream `LICENSE` files preserved in `licenses/`.
2. Zero runtime cloud/CDN dependency (even the CC0 `tilemap_packed.png` is embedded synchronously in `src/assets/kenneyTinyTownData.ts` so the single-file production bundle runs 100% offline).
3. Strict preservation of **Soul of Hero** `LOCKED_CANON` laws: external libraries operate exclusively behind narrow adapters (`src/sim/rng.ts`, `src/sim/worldGen.ts`, `src/sim/persistence.ts`, `src/audio/sfx.ts`) feeding ONE `GameState`, ONE item custody ledger, and ONE `dispatchIntent` pipeline.

---

## 2. Subsystem Coverage & Candidate Evaluation Matrix (`K1–K8`)

| Capability / K-System | Searched Technical Problem | Candidates Inspected (URL, Version, License) | Decision | Integration Path & Concrete Benefit | Soul-of-Hero Specific Layer Added |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Deterministic PRNG (`K1, K3, K4, K8`)** | Pure serializable seeded RNG without mutating `Math.random()` | 1. `dubzzz/pure-rand` v8.4.2 (`MIT`, https://github.com/dubzzz/pure-rand)<br>2. `davidbau/seedrandom` (`MIT`, older CJS) | **ADOPT** `pure-rand` | `src/sim/rng.ts` (`xoroshiro128plus` + `uniformInt`). Explicit `rngStepCount` cursor ensures identical loot/offline replay. | Deterministic receipt & unique `instanceId` formatting (`item_<run>_r<rev>_s<step>`). |
| **Island Terrain & Biomes (`K2, C24`)** | Seeded 2D continuous heightmap & moisture fields for archipelago/bay/lake topology | 1. `jwagner/simplex-noise.js` v4.0.3 (`MIT`, https://github.com/jwagner/simplex-noise.js)<br>2. Hand-rolled value noise | **ADOPT** `simplex-noise` | `src/sim/worldGen.ts` (`createNoise2D` seeded via `pure-rand`). Zero deps, fast 192×192 island generation. | Harbor bay, eastern sea gulf, central lake, 4 safe spawn clearings, road network, and 8 POI footprints. |
| **2D FOV/LOS & Grid Pathfinding (`K2, K5, K6, K7, C07, C08, C13`)** | Synchronous 2D shadowcasting LOS (walls/doors/cliffs) and dynamic A* pathfinding | 1. `ondras/rot.js` v2.2.1 (`BSD-3-Clause`, https://github.com/ondras/rot.js)<br>2. `prettymuchbryce/easystarjs` v0.4.4 (`MIT`, async callbacks unfit for pure sync step)<br>3. `qiao/PathFinding.js` (`MIT`, unmaintained CJS) | **ADOPT** `rot-js` | `src/sim/worldGen.ts` (`ROT.FOV.PreciseShadowcasting` & `ROT.Path.AStar`). Instant synchronous LOS & A* queries. | Non-omniscient footprint-segment sensing (`C08`), dynamic door/wall blocking (`C07`), frozen-water bridges (`C03`), and Hand-Cart width/cliff restrictions (`C13`). |
| **Durable Persistence (`K8, §6`)** | Atomic multi-store IndexedDB snapshots + receipts + schema upgrades | 1. `jakearchibald/idb` v8.0.4 (`ISC`, https://github.com/jakearchibald/idb)<br>2. `dexie/Dexie.js` v4.4.3 (`Apache-2.0`, heavier ORM surface)<br>3. `jakearchibald/idb-keyval` v6.2.1 (lacks multi-store atomic tx) | **ADOPT** `idb` | `src/sim/persistence.ts` (`openDB` + single `readwrite` tx across `snapshots`, `receipts`, `profiles` + `localStorage` fallback). | Custody invariant check & local anti-tamper validation refusing bogus `VERIFIED_WORLDWIDE` claims (`C21`). |
| **Pixel Tileset & Props (`Render, §4, §12`)** | Cohesive 16×16 top-down overworld, trees, roads, walls, roofs, crates, Hand-Cart | 1. **Kenney Tiny Town v1.1** (`CC0-1.0`, https://opengameart.org/content/tiny-town)<br>2. **Kenney Tiny Dungeon** (`CC0-1.0`, https://opengameart.org/content/tiny-dungeon — OGA download requires login form; rejected unverified mirror scraping) | **ADAPT OPEN ASSET** Kenney Tiny Town v1.1 | `public/assets/kenney_tiny_town/tilemap_packed.png` + `src/assets/kenneyTinyTownData.ts` + `src/render/worldRenderer.ts`. Verified `License.txt` inside official archive. | Authored matching dark-outlined 16×16 & 24×24 pixel sprites in `src/render/pixelSprites.ts` for Female/Male Adventurers, 8 enemies, 6 Elders × 2 forms, workstations, Escrow Chest, and Ragnarok Vaults + indoor roof-fade. |
| **UI Pixel Icons (`UX, §4`)** | Strict pixel-grid UI icons without anti-aliased vector blur | 1. `halfmage/pixelarticons` v2.4.2 (`MIT`, https://github.com/halfmage/pixelarticons)<br>2. Generic smoothed feather icons | **ADOPT** `pixelarticons` | `src/App.tsx`, `src/components/SidePanels.tsx` (`Heart`, `Coins`, `Shield`, `Home`, `Map`, `BookOpen`, `Zap`, `Volume2`). | Compact 640×360-safe HUD bars and non-blocking side drawers. |
| **Local WebAudio SFX (`Audio, §4`)** | Procedural offline retro SFX without external MP3/CDN files | 1. `KilledByAPixel/ZzFX` v1.4.0 (`MIT`, https://github.com/KilledByAPixel/ZzFX)<br>2. `howler.js` (requires audio asset blobs) | **ADOPT** `zzfx` | `src/audio/sfx.ts` (`zzfx` parameter presets for swing, hit, chop, mine, craft, build, Core windup/commit, escrow chime, hurt). | Triggered strictly on committed `dispatchIntent` receipts with mute toggle. |
| **Deterministic QA, Property & Browser Verification (`§7, §16`)** | Unit runner, QuickCheck property fuzzer, Node IndexedDB, and real Chromium input/screenshot harness | 1. `vitest` v4.1.12 (`MIT`)<br>2. `dubzzz/fast-check` v4.10.2 (`MIT`)<br>3. `dumbmatter/fakeIndexedDB` v6.2.7 (`Apache-2.0`)<br>4. `@playwright/test` (`Apache-2.0`) | **ADOPT_DEV** all four | `src/tests/contracts_c01_c24.test.ts`, `src/tests/simulation.bench.test.ts`, `scripts/playwright_e2e_and_screenshots.mjs`. | C01–C24 contracts, `(a)–(t)` negative tests, 48-run 12-policy simulation + ±20% sweeps, and 8 real Chromium screenshots. |
| **Survival Economy, Custody & Ragnarok Escrow (`K1, K3, K4, K6, K8`)** | Single custody ledger, 336h/Final72 UTC clock, paid fuel/power queues, zero-wallet Escrow Chest | Inspected generic open survival templates; all bundle conflicting assumptions (infinite respawn, omniscient raids, free banks, or permanent meta-stats). | **REJECT** full templates; **AUTHOR** clean domain core | `src/sim/custody.ts`, `src/sim/engine.ts`, `src/data/*.json`. | 100% faithful implementation of `LOCKED_CANON` laws without conflicting borrowed rules. |

---

## 3. Build vs. Reuse Accounting

- **Generic Subsystems Not Rebuilt From Scratch (9 verified packages + 1 verified CC0 132-tile packed sheet)**:
  - 2D Simplex noise generator (`simplex-noise`)
  - Precise shadowcasting 2D FOV/LOS and 4-way grid A* pathfinder (`rot-js`)
  - `xoroshiro128plus` pure functional PRNG & uniform integer distributions (`pure-rand`)
  - Promise-based IndexedDB transaction & schema-migration wrapper (`idb`)
  - 20-parameter WebAudio procedural SFX synth (`zzfx`)
  - 24×24 pixel-grid SVG HUD icon set (`pixelarticons`)
  - 16×16 overworld pixel tileset: grass, roads, trees, shrubs, walls, doors, roofs, crates, barrels, wells, gates, and wooden Hand-Cart (`Kenney Tiny Town v1.1 CC0`)
  - Test runner, QuickCheck property generator, W3C IndexedDB simulator, and real Chromium automation (`vitest`, `fast-check`, `fake-indexeddb`, `playwright`)
- **Original Soul-of-Hero Domain Modules Authored**:
  - `src/data/*.json` (9 human-editable versioned catalogs: 56 items, 36 recipes, 16 source classes, 24 structures, 8 enemies, 6 Elders × 2 forms, 4 replaceable skill drivers, 8 layered POIs, and `balance.prototype.v1.json`)
  - `src/sim/custody.ts` & `src/sim/engine.ts` (single custody ledger, atomic `dispatchIntent`, non-omniscient footprint-following AI, ordered offline catch-up, zero-wallet first Escrow Chest economy, run finalization & Run 2 reset)
  - `src/render/pixelSprites.ts` & `src/render/worldRenderer.ts` (authored pixel matrices for Female/Male Adventurers, enemies, 24×24 Elders, survival stations, Escrow/Ragnarok chests + indoor roof-fade renderer)

---

## 4. Research Limitations & Security/License Audit

- **Kenney Tiny Dungeon OGA Archive**: OpenGameArt's direct file download section on `tiny-dungeon` gated the attachment link behind a login prompt during automated `web_fetch`; per `§1R R3`, rather than scraping unverified third-party mirrors without an accompanying `License.txt`, we used the directly verified `kenney_tiny-town.zip` (whose `License.txt` was extracted and verified as `CC0-1.0`) and authored matching dark-ink pixel matrices in `src/render/pixelSprites.ts` for characters, monsters, Elders, and specialized stations.
- **Gold Skill Source Assets**: Marked `GOLD_SOURCE_NOT_AVAILABLE` (`REQUIRES_SOURCE`) in `src/data/balance.prototype.v1.json` and `src/data/skills.json`; skill timing/hit/terrain drivers are cleanly data-driven for future drop-in replacement.
- **Final Reuse Acceptance Gate**:
  1. Live public search & verification performed: **PASS**
  2. Verified redistribution rights & `licenses/` shipped: **PASS**
  3. Every adopted package/asset actively wired into live runtime or test pipeline: **PASS**
  4. Single authoritative `GameState`, clock, and item custody ledger preserved: **PASS**
  5. Local unit/property/simulation + real Chromium Playwright proof captured: **PASS**
  6. Zero runtime cloud/network dependency in `dist/index.html`: **PASS**
