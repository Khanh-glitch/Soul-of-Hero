# Balance Report, Coupled Equations & Sensitivity Audit (`§5`, `§11`)

## 1. Canon vs. Prototype Tuning Separation

All runtime balance parameters reside in `src/data/balance.prototype.v1.json` alongside explicit `unit`, `scope`, `rationale`, and `status`:
- **`LOCKED_CANON`**: `maxRunRealSeconds = 1,209,600s` (336 real UTC hours), `ragnarokFinalSeconds = 259,200s` (Final 72h starting at 950,400s), `elderAwakenStartSeconds = 1,123,200s` (Day 14), `elderCount = 6`, `logicalCanvas = 640×360`, `offlineShelterStarvationHpFloor = 1 HP`, `verificationAuthority = LOCAL_UNVERIFIED`.
- **`PROPOSED_MECHANISM`** (reversible, never claimed as creator-locked):
  - `homesteadClaimRadiusTiles = 10` tiles (`maxHomesteadClaimsPerRun = 2`) via `homestead_claim_totem` (`6 wood_log + 4 stone_chunk`).
  - `escrowChestVendorPriceCash = 120` Ragnarok Cash at Crossroads Wayfarer Trader (`acceptsUnsecuredPhysicalCash = true` so a zero-wallet Run 1 player can purchase their first `escrow_chest_item` with physical Final-72h cash).
  - `loadedContainerReclaimPolicy = DENY_UNTIL_EMPTIED` and `depletedCoreStudyEligible = false`.
  - `forecastHorizonSeconds = 14,400s` (4h observable barometer sky estimate) and `stoneThresholdRewards = [100, 220, 360, 520, 700, 2000]`.
- **`PROTOTYPE_TUNING`**: Metabolic drain (`2.5` hunger/real hour, `4.0` thirst/real hour, `0.35x` offline shelter multiplier), walk/sprint speeds (`85` / `120` px/s), carry thresholds (`35 kg` base / `70 kg` hard cap vs `120 kg` Hand-Cart), 90-minute fictional daylight cycle (`5400s`), tool durability (`60–150`), and station work/fuel timings.

---

## 2. Coupled Simulation Equations Implemented

1. **Actor Damage vs. Material Harvest Separation (`src/sim/engine.ts`)**:
   - `mitigated_damage = max(1, round(weapon_actor_damage - armor_defense * 0.45))`
   - `unit_hp_next = unit_hp - tool.harvestProfile[source.material]` (e.g., `stone_pickaxe` deals `18` to stone and `14` to ore vs `7` to creatures; `rusty_knife` deals `11` to creatures vs `0` to ore; Seismic Core shockwave degrades mineral yield by `harvestQualityFactor = 0.45`).
2. **Movement, Surface Friction & Freight (`src/sim/worldGen.ts`, `src/sim/engine.ts`)**:
   - `actual_speed = raw_speed * surface_mult(biome, hasCart) * encumbrance_mult(playerKg, cartKg) * (1 + bootsBonus)`
   - Carrying `65 kg` of raw iron ore on foot along a road reduces speed to `85 * 1.15 * 0.48 = 46.9 px/s`, whereas loading `65 kg` into a deployed Cargo Hand-Cart moves at `85 * 1.08 * 0.79 = 72.5 px/s` (**+54.6% faster haul**), while deep wetland slows carts (`0.44x`) and steep cliffs/narrow doors block carts completely.
3. **Paid Station Output Under Finite Fuel (`src/sim/engine.ts`)**:
   - `effective_work_sec = min(elapsed_slice_sec, station.fuelRemainingSec)`
   - Verified in `C06`: 15 minutes (`900s`) of fuel over a 2-hour (`7200s`) offline period completes **exactly `900 / 60 = 15` iron ingots** and pauses remaining queued jobs (`paused_no_fuel`).
4. **Zero-Wallet First Escrow Feasibility (`C15–C17`)**:
   - Two non-Elder, non-keycard Final-72h exterior annex chests (`rust_refinery = 195` + `research_outpost = 205` = `400` physical Ragnarok Cash; total finite island supply across 4 chests = `860` cash, `respawnSeconds = null`).
   - `net_first_deposit = reachable_no_boss_cash (400) - vendor_escrow_chest_price (120) = +280 > 0` (even a single annex chest yields `195 - 120 = +75 > 0`).

---

## 3. Empirical 12-Policy Multi-Seed Benchmark (`npm run test:simulation`)

Measured across **48 deterministic runs** (12 policies × 4 safe spawn regions, recorded in `simulation_evidence.json`):

| Policy Bot | Runs | Survival Rate | Median End-of-Segment Items | Median Secured Cash | Median Local Score (`LOCAL_UNVERIFIED`) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| `knife_only` | 4 | 100% | 27 | 0 | 0 |
| `road_scavenger` | 4 | 100% | 29 | 0 | 0 |
| `home_first` | 4 | 100% | 15 | 0 | 0 |
| `nomad_explorer` (48h, 0 buildings) | 4 | 100% | 60 | 0 | 0 |
| `spares_researcher` | 4 | 100% | 37 | 0 | 0 |
| `cart_merchant` | 4 | 100% | 34 | 0 | 0 |
| `core_caster` | 4 | 100% | 5 | 0 | 0 |
| `specimen_analyst` | 4 | 100% | 9 | 0 | 0 |
| `poi_explorer` (deep vault breach) | 4 | 100% | 29 | 0 | 150 |
| `no_boss_ragnarok` (escrow + evac) | 4 | 100% | 0 *(wiped on evac)* | **+280** | **750** |
| `elder_challenger` (1 latent Elder) | 4 | 100% | 6 | 0 | 300 |
| `offline_shelter_regular` (36h offline) | 4 | 100% | 24 | 0 | 0 |

---

## 4. ±20% Parameter Sensitivity Sweep (`simulation_evidence.json`)

| Parameter Shift (`Δ`) | Worst-Case No-Boss Cash Supply | Adjusted Escrow Chest Price | Net First Escrow Deposit | Active Hours to 0 Hunger | Active Hours to 0 Thirst |
| :---: | :---: | :---: | :---: | :---: | :---: |
| **-20%** | 320 | 96 | **+224** | 50.0 h | 31.3 h |
| **-10%** | 360 | 108 | **+252** | 44.4 h | 27.8 h |
| **0% (Baseline)** | 400 | 120 | **+280** | 40.0 h | 25.0 h |
| **+10%** | 360 | 132 | **+228** | 36.4 h | 22.7 h |
| **+20% (Adverse)** | 320 | 144 | **+176** | 33.3 h | 20.8 h |

Even under simultaneous `-20%` Final-72h cash supply and `+20%` Escrow Chest vendor price, a zero-wallet solo player who avoids all six Elders secures **+176 Ragnarok Cash** without requiring lucky RNG drops.
