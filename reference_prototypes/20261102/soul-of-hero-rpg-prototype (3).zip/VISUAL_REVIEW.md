# Visual Review & Pixel Framing Audit (`§7`, `§12`, `§16`)

## 1. Automated & Human-Inspected Screenshot Verification

All 8 screenshots in `screenshots/` were captured from a live headless Chromium browser running the compiled production build (`vite preview` via `scripts/playwright_e2e_and_screenshots.mjs`) and decoded/inspected both programmatically (`getImageData` pixel-bucket audit) and visually:

- **640×360 Native Logical Framing Audit**:
  - `topFits: true`, `botFits: true` (`hud-topbar` and `hud-bottombar` fit strictly within `[0..640, 0..360]` with zero clipped buttons).
  - `uniqueColorBuckets: 47`, `nonBlackRatio: 1.0` (100% non-black world coverage, crisp integer pixel art with `imageSmoothingEnabled = false`).

---

## 2. Per-Screenshot Visual Inspection Notes

1. **`screenshots/01_title_new_game_640x360.png` (640×360 native 1×)**:
   - Launch modal fits comfortably inside native `640×360` with live pixel terrain visible behind the translucent frame. Female/Male Adventurer toggle, 4 safe coastal/woodland landing cards, `Secured Cash: 0`, and control summary are crisp and unclipped.
2. **`screenshots/02_hud_terrain_1280x720.png` (1280×720 integer 2×)**:
   - Displays CC0 Kenney Tiny Town grass, wildflowers, tall 16×32 pine and amber oak trees, stone wellspring, dirt/cobble road, roadside supply crate and barrel, granite/ore outcrops along cliff ridges, Brush Crawlers in the meadow, Female Adventurer in crimson hood & emerald cloak, and **3 decaying physical boot footprints on the dirt road** after real `WASD` movement.
3. **`screenshots/03_build_indoor_roof_fade.png` (1280×720 integer 2×)**:
   - Shows player-built Homestead Claim Totem alongside a floored, walled cottage room. Standing inside automatically fades the overhead `Woven Thatch Roof` (`globalAlpha = 0.16`) so the floor planks and interior are legible while `CONSTRUCTION & HOMESTEAD` confirms `Owned Homestead Territory`.
4. **`screenshots/04_inventory_craft.png` (1280×720 integer 2×)**:
   - Inside `Granite & Iron Quarry` masonry courtyard with floating green harvest feedback (`Granite Outcrop (6)`) and `CRAFTING & STATION QUEUES` drawer highlighting `Planed Timber Planks (x2)` ready to craft.
5. **`screenshots/05_poi_hazard_gate.png` (1280×720 integer 2×)**:
   - Inside `Containment Bio-Bunker [DEEP VAULT LOCKED]` surrounded by toxic radiation terrain. Exterior locker and fuel drum sit open in the outer courtyard while the locked iron portcullis gate (with red lock indicator) guards the inner Core Reliquary and Vault Crate; the one-way emergency ladder hatch is visible on the south vault wall.
6. **`screenshots/06_combat_core_cast.png` (1280×720 integer 2×)**:
   - Northeastern volcanic ash caldera (`39°C` shown in top HUD) with yellow sulfur vents, alerted Cinder-Beetles (`!`), and the 24×24 twin-horned magma Elder **`IGNIS`** projecting a readable orange AoE telegraph ring around the Adventurer.
7. **`screenshots/07_ragnarok_escrow_deposit.png` (1280×720 integer 2×)**:
   - Pulsing `RAGNAROK 72.0h` top banner, pixel rain particles, deployed emerald-and-gold **`ESCROW`** chest next to Homestead Claim Totem with floating `+50 SECURED` world receipt, a physical **`BAG`** (`Death Recovery Bag`) on the porch, and the `CUSTODY & GEAR` drawer showing both `Profile Secured Wallet: 50` (`Bag Physical Cash: 25`) and item-by-item Death Bag recovery.
8. **`screenshots/08_postrun_history_run2.png` (1280×720 integer 2×)**:
   - Sunken Breakwater Harbor pier post-evacuation summary confirming `Secured Profile Ragnarok Cash: 50 (+50 this run)`, `Unsecured Physical Cash Wiped: 25` (no auto-deposit on evac), `Elder Stones Claimed: 0/6`, and `Local Score: 900 pts [LOCAL_UNVERIFIED]`.

---

## 3. Observed Visual Polish Boundaries

- **Vietnamese Diacritic Kerning in Monospace**: In `07_ragnarok_escrow_deposit.png`, headless Linux DejaVu Sans Mono renders `ử` in `Rương Ký Gửi` slightly tighter than ASCII glyphs while remaining legible.
- **Gold Skill Raster Art**: Per `GOLD_SOURCE_NOT_AVAILABLE`, Core AoE rings and elemental particles use clean prototype pixel rings/embers rather than unreleased production Gold sprite sheets.
