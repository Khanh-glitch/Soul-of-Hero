import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import { verifyCustodyInvariants } from './custody';
import { CURRENT_SCHEMA_VERSION } from './engine';
import type { EventReceipt, GameState, ProfileState } from './types';

const DB_NAME = 'soul_of_hero_world_sim_db';
const DB_VERSION = 1;
const LS_FALLBACK_KEY = 'soul_of_hero_snapshot_v1';

interface SoulOfHeroDbSchema extends DBSchema {
  snapshots: {
    key: string;
    value: {
      slotId: string;
      savedAtUtcSec: number;
      schemaVersion: number;
      revision: number;
      state: GameState;
    };
  };
  receipts: {
    key: string;
    value: EventReceipt;
    indexes: { 'by-run': string };
  };
  profiles: {
    key: string;
    value: ProfileState;
  };
}

let dbPromise: Promise<IDBPDatabase<SoulOfHeroDbSchema>> | null = null;

export function resetPersistenceConnectionForTests(): void {
  dbPromise = null;
}

async function getDb(): Promise<IDBPDatabase<SoulOfHeroDbSchema> | null> {
  if (typeof indexedDB === 'undefined') return null;
  if (!dbPromise) {
    dbPromise = openDB<SoulOfHeroDbSchema>(DB_NAME, DB_VERSION, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
          db.createObjectStore('snapshots', { keyPath: 'slotId' });
          const receiptStore = db.createObjectStore('receipts', { keyPath: 'receiptId' });
          receiptStore.createIndex('by-run', 'runId');
          db.createObjectStore('profiles', { keyPath: 'profileId' });
        }
      },
    });
  }
  return dbPromise;
}

export function validateAndSanitizeLoadedState(candidate: unknown): {
  valid: boolean;
  reason?: string;
  state?: GameState;
} {
  if (!candidate || typeof candidate !== 'object') {
    return { valid: false, reason: 'Snapshot payload is missing or non-object' };
  }
  const st = candidate as GameState;
  if (
    typeof st.schemaVersion !== 'number' ||
    st.schemaVersion > CURRENT_SCHEMA_VERSION ||
    !st.profile ||
    !st.run ||
    !st.clock ||
    !st.actors?.player ||
    !st.inventory?.items
  ) {
    return { valid: false, reason: 'Snapshot failed schema structural validation' };
  }

  // Enforce C21: Refuse bogus online VERIFIED claims in local browser storage!
  for (const h of st.profile.runHistory ?? []) {
    if ((h as { verificationLabel?: string }).verificationLabel !== 'LOCAL_UNVERIFIED') {
      return {
        valid: false,
        reason: 'Refused tampered local save claiming VERIFIED_WORLDWIDE without backend authority',
      };
    }
    if (typeof h.localUnverifiedScore !== 'number' || h.localUnverifiedScore < 0 || h.localUnverifiedScore > 50_000) {
      return {
        valid: false,
        reason: 'Refused tampered impossible local score record',
      };
    }
  }

  if (typeof st.profile.securedCash !== 'number' || st.profile.securedCash < 0 || !Number.isFinite(st.profile.securedCash)) {
    return { valid: false, reason: 'Corrupted profile securedCash ledger' };
  }

  const custodyCheck = verifyCustodyInvariants(st);
  if (!custodyCheck.valid) {
    return {
      valid: false,
      reason: `Custody invariant violation: ${custodyCheck.errors[0]}`,
    };
  }

  return { valid: true, state: st };
}

/**
 * Atomically commits the canonical GameState snapshot, profile ledger, and latest event receipts
 * inside ONE IndexedDB `readwrite` transaction boundary (plus localStorage mirror fallback).
 */
export async function saveGameStateAtomic(state: GameState, slotId = 'primary'): Promise<void> {
  const cleanState: GameState = structuredClone({
    ...state,
    vfxQueue: [], // ephemeral render particles excluded from durable snapshot
  });
  const nowUtcSec = Math.floor(Date.now() / 1000);

  const db = await getDb();
  if (db) {
    const tx = db.transaction(['snapshots', 'receipts', 'profiles'], 'readwrite');
    await tx.objectStore('snapshots').put({
      slotId,
      savedAtUtcSec: nowUtcSec,
      schemaVersion: cleanState.schemaVersion,
      revision: cleanState.revision,
      state: cleanState,
    });
    await tx.objectStore('profiles').put(cleanState.profile);
    const rStore = tx.objectStore('receipts');
    const recentReceipts = cleanState.eventReceipts.slice(-40);
    for (const rcpt of recentReceipts) {
      await rStore.put(rcpt);
    }
    await tx.done;
  }

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(LS_FALLBACK_KEY, JSON.stringify(cleanState));
    } catch {
      // Ignore quota exceeded when IndexedDB succeeded
    }
  }
}

export async function loadGameStateAtomic(slotId = 'primary'): Promise<{
  loaded: boolean;
  corruptionError?: string;
  state?: GameState;
}> {
  const db = await getDb();
  if (db) {
    const record = await db.get('snapshots', slotId);
    if (record?.state) {
      const check = validateAndSanitizeLoadedState(record.state);
      if (!check.valid) {
        return { loaded: false, corruptionError: check.reason };
      }
      return { loaded: true, state: check.state };
    }
  }

  if (typeof localStorage !== 'undefined') {
    const raw = localStorage.getItem(LS_FALLBACK_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        const check = validateAndSanitizeLoadedState(parsed);
        if (!check.valid) {
          return { loaded: false, corruptionError: check.reason };
        }
        return { loaded: true, state: check.state };
      } catch {
        return { loaded: false, corruptionError: 'Malformed JSON in localStorage fallback' };
      }
    }
  }

  return { loaded: false };
}

export async function clearAllSavedData(): Promise<void> {
  const db = await getDb();
  if (db) {
    const tx = db.transaction(['snapshots', 'receipts', 'profiles'], 'readwrite');
    await tx.objectStore('snapshots').clear();
    await tx.objectStore('receipts').clear();
    await tx.objectStore('profiles').clear();
    await tx.done;
  }
  if (typeof localStorage !== 'undefined') {
    localStorage.removeItem(LS_FALLBACK_KEY);
  }
}
