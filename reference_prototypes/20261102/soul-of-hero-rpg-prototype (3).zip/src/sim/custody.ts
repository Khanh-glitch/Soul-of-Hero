import { BALANCE, ITEM_MAP } from '../data/catalogs';
import type { GameState, ItemInstance } from './types';
import { DeterministicRng } from './rng';

export function getContainerCapacity(state: GameState, containerId: string): number {
  if (containerId === 'player_bag') {
    return BALANCE.player.inventorySlots.value;
  }
  if (containerId.startsWith('player_equip:')) {
    return 1;
  }
  if (containerId.startsWith('cart:')) {
    return BALANCE.economyAndTerritory.handCartCargoSlots.value;
  }
  if (containerId.startsWith('station_out:')) {
    return 6;
  }
  if (containerId.startsWith('death_bag:')) {
    return 64;
  }
  if (containerId.startsWith('structure:')) {
    const strId = containerId.slice('structure:'.length);
    const str = state.entities.structures[strId];
    if (!str) return 0;
    if (str.definitionId === 'wooden_chest') return 10;
    if (str.definitionId === 'iron_strongbox') return 18;
    return 0;
  }
  return 0;
}

export function getItemsInContainer(state: GameState, containerId: string): ItemInstance[] {
  return Object.values(state.inventory.items)
    .filter((it) => it.containerId === containerId && it.count > 0)
    .sort((a, b) => a.slotIndex - b.slotIndex);
}

export function getPlayerCarryWeightKg(state: GameState): number {
  let total = 0;
  for (const it of Object.values(state.inventory.items)) {
    if (it.containerId === 'player_bag' || it.containerId.startsWith('player_equip:')) {
      const def = ITEM_MAP.get(it.definitionId);
      if (def) total += def.weightKg * it.count;
    }
  }
  return Number(total.toFixed(2));
}

export function getCartCargoWeightKg(state: GameState, cartId: string): number {
  let total = 0;
  const cid = `cart:${cartId}`;
  for (const it of Object.values(state.inventory.items)) {
    if (it.containerId === cid) {
      const def = ITEM_MAP.get(it.definitionId);
      if (def) total += def.weightKg * it.count;
    }
  }
  return Number(total.toFixed(2));
}

export function countItemInContainer(state: GameState, containerId: string, definitionId: string): number {
  let sum = 0;
  for (const it of Object.values(state.inventory.items)) {
    if (it.containerId === containerId && it.definitionId === definitionId) {
      sum += it.count;
    }
  }
  return sum;
}

export function findFreeSlot(state: GameState, containerId: string): number | null {
  const cap = getContainerCapacity(state, containerId);
  if (cap <= 0) return null;
  const occupied = new Set<number>();
  for (const it of Object.values(state.inventory.items)) {
    if (it.containerId === containerId) {
      occupied.add(it.slotIndex);
    }
  }
  for (let i = 0; i < cap; i++) {
    if (!occupied.has(i)) return i;
  }
  return null;
}

/**
 * Mints a legitimate item from an authorized physical source/recipe receipt into a target container.
 * Never alters existing unique instance IDs.
 */
export function grantItemToContainer(
  state: GameState,
  rng: DeterministicRng,
  containerId: string,
  definitionId: string,
  count: number,
  provenanceSourceId: string,
  provenanceReceiptId: string,
  overrides?: { durability?: number; charges?: number; quality?: number }
): { addedCount: number; createdInstanceIds: string[] } {
  const def = ITEM_MAP.get(definitionId);
  if (!def || count <= 0) return { addedCount: 0, createdInstanceIds: [] };

  let remaining = count;
  let added = 0;
  const createdIds: string[] = [];

  // Stack onto existing non-unique lots first
  if (!def.uniqueInstance && def.maxStack > 1) {
    const existing = getItemsInContainer(state, containerId).filter(
      (it) => it.definitionId === definitionId && it.count < def.maxStack
    );
    for (const lot of existing) {
      if (remaining <= 0) break;
      const room = def.maxStack - lot.count;
      const put = Math.min(room, remaining);
      lot.count += put;
      remaining -= put;
      added += put;
    }
  }

  while (remaining > 0) {
    const freeSlot = findFreeSlot(state, containerId);
    if (freeSlot === null) break;
    const put = def.uniqueInstance ? 1 : Math.min(def.maxStack, remaining);
    const instanceId = rng.nextId('item', state.run.runId, state.revision);
    const inst: ItemInstance = {
      instanceId,
      definitionId,
      runId: state.run.runId,
      count: put,
      durability: overrides?.durability ?? def.maxDurability,
      maxDurability: def.maxDurability,
      charges: overrides?.charges ?? def.maxCharges,
      maxCharges: def.maxCharges,
      quality: overrides?.quality ?? 100,
      containerId,
      slotIndex: freeSlot,
      provenanceSourceId,
      provenanceReceiptId,
    };
    state.inventory.items[instanceId] = inst;
    createdIds.push(instanceId);
    remaining -= put;
    added += put;
  }

  return { addedCount: added, createdInstanceIds: createdIds };
}

/**
 * Atomically debits `requiredCount` of `definitionId` from `containerId`.
 * Returns false and mutates NOTHING if insufficient stock exists.
 */
export function debitItemFromContainer(
  state: GameState,
  containerId: string,
  definitionId: string,
  requiredCount: number
): boolean {
  if (requiredCount <= 0) return true;
  const available = countItemInContainer(state, containerId, definitionId);
  if (available < requiredCount) return false;

  let remaining = requiredCount;
  const matching = getItemsInContainer(state, containerId).filter((it) => it.definitionId === definitionId);
  for (const lot of matching) {
    if (remaining <= 0) break;
    const take = Math.min(lot.count, remaining);
    lot.count -= take;
    remaining -= take;
    if (lot.count <= 0) {
      delete state.inventory.items[lot.instanceId];
    }
  }
  return true;
}

/**
 * Moves a unique item instance or stack between containers while conserving its exact `instanceId`
 * (or merges commodity stacks cleanly).
 */
export function transferInstanceToContainer(
  state: GameState,
  instanceId: string,
  toContainerId: string,
  preferredSlot?: number
): { ok: boolean; reason?: string } {
  const inst = state.inventory.items[instanceId];
  if (!inst) return { ok: false, reason: 'Item instance not found in custody ledger' };
  const def = ITEM_MAP.get(inst.definitionId);
  if (!def) return { ok: false, reason: 'Unknown item definition' };

  if (toContainerId.startsWith('cart:')) {
    const cartId = toContainerId.slice('cart:'.length);
    const currentKg = getCartCargoWeightKg(state, cartId);
    const addedKg = def.weightKg * inst.count;
    if (currentKg + addedKg > BALANCE.economyAndTerritory.handCartMaxWeightKg.value) {
      return { ok: false, reason: 'Hand-Cart cargo weight limit (120 kg) exceeded' };
    }
  }

  // Merge non-unique commodity stacks when transferring into a container that already holds a partial stack
  if (!def.uniqueInstance && def.maxStack > 1 && preferredSlot === undefined) {
    const partials = getItemsInContainer(state, toContainerId).filter(
      (it) => it.instanceId !== inst.instanceId && it.definitionId === inst.definitionId && it.count < def.maxStack
    );
    for (const lot of partials) {
      if (inst.count <= 0) break;
      const take = Math.min(def.maxStack - lot.count, inst.count);
      lot.count += take;
      inst.count -= take;
    }
    if (inst.count <= 0) {
      delete state.inventory.items[inst.instanceId];
      return { ok: true };
    }
  }

  const cap = getContainerCapacity(state, toContainerId);
  if (cap <= 0) return { ok: false, reason: 'Target container cannot hold items' };

  if (preferredSlot !== undefined && preferredSlot >= 0 && preferredSlot < cap) {
    const occupant = Object.values(state.inventory.items).find(
      (it) => it.containerId === toContainerId && it.slotIndex === preferredSlot && it.instanceId !== inst.instanceId
    );
    if (!occupant) {
      inst.containerId = toContainerId;
      inst.slotIndex = preferredSlot;
      return { ok: true };
    }
    if (inst.containerId === toContainerId) {
      // Swap slots within same container conserving both IDs
      const oldSlot = inst.slotIndex;
      inst.slotIndex = preferredSlot;
      occupant.slotIndex = oldSlot;
      return { ok: true };
    }
  }

  const freeSlot = findFreeSlot(state, toContainerId);
  if (freeSlot === null) {
    return { ok: false, reason: 'Destination container is full' };
  }
  inst.containerId = toContainerId;
  inst.slotIndex = freeSlot;
  return { ok: true };
}

/**
 * Verifies K1 Custody Ledger conservation laws:
 * - Every record key equals its `instanceId`
 * - No two items occupy the same `(containerId, slotIndex)`
 * - Every item count > 0 and <= maxStack
 * - Unique instances have count === 1
 */
export function verifyCustodyInvariants(state: GameState): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const slotSet = new Set<string>();
  const idSet = new Set<string>();

  for (const [key, item] of Object.entries(state.inventory.items)) {
    if (key !== item.instanceId) {
      errors.push(`Key mismatch: ${key} !== ${item.instanceId}`);
    }
    if (idSet.has(item.instanceId)) {
      errors.push(`Duplicate instanceId: ${item.instanceId}`);
    }
    idSet.add(item.instanceId);

    const def = ITEM_MAP.get(item.definitionId);
    if (!def) {
      errors.push(`Unknown definitionId on ${item.instanceId}: ${item.definitionId}`);
      continue;
    }
    if (item.count <= 0 || item.count > def.maxStack) {
      errors.push(`Illegal count on ${item.instanceId}: ${item.count}`);
    }
    if (def.uniqueInstance && item.count !== 1) {
      errors.push(`Unique instance ${item.instanceId} has count ${item.count}`);
    }
    const slotKey = `${item.containerId}#${item.slotIndex}`;
    if (slotSet.has(slotKey)) {
      errors.push(`Container slot collision at ${slotKey}`);
    }
    slotSet.add(slotKey);
  }

  return { valid: errors.length === 0, errors };
}
