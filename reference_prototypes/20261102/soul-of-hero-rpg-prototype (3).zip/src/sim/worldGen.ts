import { createNoise2D } from 'simplex-noise';
import * as ROT from 'rot-js';
import {
  BALANCE,
  BOSSES,
  ENEMIES,
  POIS,
  SOURCE_MAP,
  STRUCTURE_MAP,
} from '../data/catalogs';
import { createSeededNoiseRng, DeterministicRng } from './rng';
import type {
  BiomeId,
  ElderBossActorState,
  EnemyActorState,
  GameState,
  PlacedStructureState,
  PoiRuntimeState,
  SourceNodeState,
  SpawnRegionInfo,
  WorldTopology,
} from './types';

const topologyCache = new Map<number, WorldTopology>();

export function tileIndex(x: number, y: number, width: number): number {
  return y * width + x;
}

export function getSurfaceSpeedMultiplier(biome: BiomeId, withCart = false): number {
  switch (biome) {
    case 'road':
    case 'poi_floor':
      return withCart ? 1.08 : 1.15;
    case 'plains':
    case 'coast':
      return withCart ? 0.92 : 1.0;
    case 'forest':
      return withCart ? 0.72 : 0.92;
    case 'hills':
      return withCart ? 0.62 : 0.84;
    case 'wetland':
      return withCart ? 0.44 : 0.72;
    case 'cold':
      return withCart ? 0.7 : 0.88;
    case 'hot':
    case 'radiation':
      return withCart ? 0.82 : 0.94;
    case 'shallow_water':
      return withCart ? 0.0 : 0.55;
    default:
      return 0.0;
  }
}

export function getSurfaceTraceRetention(biome: BiomeId): number {
  switch (biome) {
    case 'wetland':
      return 1.8;
    case 'coast':
      return 1.35;
    case 'forest':
    case 'plains':
      return 1.0;
    case 'cold':
      return 1.45;
    case 'road':
      return 0.8;
    case 'hills':
    case 'hot':
    case 'radiation':
      return 0.5;
    case 'poi_floor':
      return 0.35;
    default:
      return 0.4;
  }
}

function carveRoadLine(biomes: BiomeId[], width: number, height: number, x0: number, y0: number, x1: number, y1: number): void {
  let cx = x0;
  let cy = y0;
  let guard = 0;
  while ((cx !== x1 || cy !== y1) && guard < width * height) {
    guard++;
    for (let oy = -1; oy <= 0; oy++) {
      for (let ox = -1; ox <= 0; ox++) {
        const tx = cx + ox;
        const ty = cy + oy;
        if (tx > 4 && ty > 4 && tx < width - 5 && ty < height - 5) {
          const idx = tileIndex(tx, ty, width);
          if (biomes[idx] !== 'deep_sea') {
            biomes[idx] = 'road';
          }
        }
      }
    }
    if (Math.abs(x1 - cx) >= Math.abs(y1 - cy)) {
      cx += cx < x1 ? 1 : -1;
    } else {
      cy += cy < y1 ? 1 : -1;
    }
  }
}

export function getOrCreateTopology(seed = BALANCE.world.defaultIslandSeed.value): WorldTopology {
  const cached = topologyCache.get(seed);
  if (cached) return cached;

  const width = BALANCE.world.mapWidthTiles.value;
  const height = BALANCE.world.mapHeightTiles.value;
  const elevNoise = createNoise2D(createSeededNoiseRng(seed ^ 0x13579bdf));
  const detailNoise = createNoise2D(createSeededNoiseRng(seed ^ 0x2468ace1));
  const moistNoise = createNoise2D(createSeededNoiseRng(seed ^ 0x55aa33cc));

  const biomes: BiomeId[] = new Array(width * height);
  const elevation: number[] = new Array(width * height);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const nx = x / width;
      const ny = y / height;
      const dx = (nx - 0.5) * 2;
      const dy = (ny - 0.5) * 2;
      const radialDist = Math.sqrt(dx * dx + dy * dy);

      // Coherent island silhouette with southern harbor bay & eastern sea gulf/isthmus
      const bayCut =
        Math.exp(-((nx - 0.48) ** 2 / 0.008 + (ny - 0.90) ** 2 / 0.012)) * 0.48 +
        Math.exp(-((nx - 0.86) ** 2 / 0.014 + (ny - 0.50) ** 2 / 0.007)) * 0.42;

      // Central freshwater lake west of crossroads
      const lakeCut = Math.exp(-((nx - 0.41) ** 2 / 0.0022 + (ny - 0.53) ** 2 / 0.0022)) * 0.52;

      const n1 = (elevNoise(x * 0.032, y * 0.032) + 1) * 0.5;
      const n2 = (detailNoise(x * 0.085, y * 0.085) + 1) * 0.5;
      const rawElev = n1 * 0.72 + n2 * 0.28;
      const islandFalloff = Math.max(0, 1 - Math.pow(radialDist * 0.96, 2.35));
      const h = Math.max(0, Math.min(1, rawElev * 0.65 + islandFalloff * 0.58 - bayCut - lakeCut));
      const idx = tileIndex(x, y, width);
      elevation[idx] = h;

      const moist = (moistNoise(x * 0.045, y * 0.045) + 1) * 0.5;

      let biome: BiomeId = 'plains';
      if (h < 0.24 || x <= 2 || y <= 2 || x >= width - 3 || y >= height - 3) {
        biome = 'deep_sea';
      } else if (h < 0.30) {
        biome = 'shallow_water';
      } else if (h < 0.35) {
        biome = 'coast';
      } else if (nx < 0.34 && ny < 0.33 && h > 0.42) {
        biome = 'cold';
      } else if (nx > 0.67 && ny < 0.34 && h > 0.40) {
        biome = 'hot';
      } else if (nx > 0.59 && nx < 0.77 && ny > 0.41 && ny < 0.56 && h > 0.38) {
        biome = 'radiation';
      } else if (nx < 0.38 && ny > 0.63 && h < 0.58) {
        biome = 'wetland';
      } else if (h > 0.83) {
        biome = 'mountain';
      } else if (h > 0.70) {
        biome = 'hills';
      } else if (moist > 0.53) {
        biome = 'forest';
      } else {
        biome = 'plains';
      }
      biomes[idx] = biome;
    }
  }

  // Four distinct, safe starting regions across temperate island edges
  const spawnRegions: SpawnRegionInfo[] = [
    {
      id: 'west_meadow',
      name: 'Westwind Coastal Meadow',
      tileX: 34,
      tileY: 96,
      description: 'Temperate western shore near timber groves, granite outcrops, and the quarry road.',
    },
    {
      id: 'south_woods',
      name: 'Southreach Timber Haven',
      tileX: 74,
      tileY: 148,
      description: 'Sheltered southern woodland east of the fen with fresh springs and harbor road access.',
    },
    {
      id: 'north_glade',
      name: 'Suncrest Orchard Glade',
      tileX: 88,
      tileY: 50,
      description: 'Rolling northern meadow between research trails and highland pines.',
    },
    {
      id: 'east_riverbend',
      name: 'Eastbrook Crossroads Bend',
      tileX: 128,
      tileY: 128,
      description: 'Southeastern valley crossroads offering balanced salvage and copper foothill routes.',
    },
  ];

  // Ensure safe walkable clearings around all 4 spawns, all 8 POIs, and all 6 Elder arenas
  const clearPatch = (cx: number, cy: number, rx: number, ry: number, fillBiome: BiomeId) => {
    for (let ty = cy - ry; ty <= cy + ry; ty++) {
      for (let tx = cx - rx; tx <= cx + rx; tx++) {
        if (tx > 4 && ty > 4 && tx < width - 5 && ty < height - 5) {
          biomes[tileIndex(tx, ty, width)] = fillBiome;
          elevation[tileIndex(tx, ty, width)] = Math.max(0.45, Math.min(0.65, elevation[tileIndex(tx, ty, width)]));
        }
      }
    }
  };

  for (const sp of spawnRegions) {
    clearPatch(sp.tileX, sp.tileY, 6, 6, 'plains');
  }

  for (const poi of POIS) {
    const px = Math.round(poi.anchorRatio.x * width);
    const py = Math.round(poi.anchorRatio.y * height);
    const hw = Math.ceil(poi.footprintTiles.w / 2) + 2;
    const hh = Math.ceil(poi.footprintTiles.h / 2) + 2;
    clearPatch(px, py, hw, hh, 'plains');
  }

  for (const boss of BOSSES) {
    const bx = Math.round(boss.arenaAnchorRatio.x * width);
    const by = Math.round(boss.arenaAnchorRatio.y * height);
    const arenaBiome = (boss.biome as BiomeId) || 'plains';
    clearPatch(bx, by, 6, 6, arenaBiome === 'mountain' ? 'hills' : arenaBiome);
  }

  // Carve physical roads connecting central market to spawns and POIs
  const marketPoi = POIS.find((p) => p.id === 'abandoned_market')!;
  const hubX = Math.round(marketPoi.anchorRatio.x * width);
  const hubY = Math.round(marketPoi.anchorRatio.y * height);

  for (const sp of spawnRegions) {
    carveRoadLine(biomes, width, height, sp.tileX, sp.tileY, hubX, hubY);
  }
  for (const poi of POIS) {
    const px = Math.round(poi.anchorRatio.x * width);
    const py = Math.round(poi.anchorRatio.y * height);
    carveRoadLine(biomes, width, height, hubX, hubY, px, py);
    // Stamp POI interior floor
    const x0 = px - Math.floor(poi.footprintTiles.w / 2);
    const y0 = py - Math.floor(poi.footprintTiles.h / 2);
    for (let ty = y0; ty < y0 + poi.footprintTiles.h; ty++) {
      for (let tx = x0; tx < x0 + poi.footprintTiles.w; tx++) {
        if (tx > 3 && ty > 3 && tx < width - 4 && ty < height - 4) {
          biomes[tileIndex(tx, ty, width)] = 'poi_floor';
        }
      }
    }
  }

  const topology: WorldTopology = {
    seed,
    width,
    height,
    biomes,
    elevation,
    spawnRegions,
  };
  topologyCache.set(seed, topology);
  return topology;
}

/**
 * Populates run-local physical sources, POI walls/gates/vendors, ordinary habitat monsters,
 * and 6 optional Elder bosses on a fresh run while keeping geography constant.
 */
export function populateRunWorldEntities(
  topology: WorldTopology,
  rng: DeterministicRng,
  runId: string,
  nowUtcSec: number
): {
  pois: Record<string, PoiRuntimeState>;
  structures: Record<string, PlacedStructureState>;
  sources: Record<string, SourceNodeState>;
  enemies: EnemyActorState[];
  elders: ElderBossActorState[];
} {
  const { width, height, biomes, spawnRegions } = topology;
  const pois: Record<string, PoiRuntimeState> = {};
  const structures: Record<string, PlacedStructureState> = {};
  const sources: Record<string, SourceNodeState> = {};
  const occupiedTiles = new Set<string>();

  const markOccupied = (tx: number, ty: number) => occupiedTiles.add(`${tx},${ty}`);
  const isOccupied = (tx: number, ty: number) => occupiedTiles.has(`${tx},${ty}`);

  let strSeq = 1;
  const addPoiWall = (tx: number, ty: number, defId = 'stone_wall') => {
    const id = `poi_str_${strSeq++}`;
    const def = STRUCTURE_MAP.get(defId)!;
    structures[id] = {
      structureId: id,
      definitionId: defId,
      tileX: tx,
      tileY: ty,
      hp: def.maxHp,
      maxHp: def.maxHp,
      ownerId: 'world_poi',
      isOpen: false,
      fuelRemainingSec: 0,
      createdAtUtcSec: nowUtcSec,
    };
    markOccupied(tx, ty);
  };

  let srcSeq = 1;
  const addSource = (
    defId: string,
    tx: number,
    ty: number,
    extra?: { poiId?: string; isDeepInterior?: boolean; fixedCashYield?: number }
  ) => {
    if (tx < 3 || ty < 3 || tx >= width - 3 || ty >= height - 3) return;
    if (isOccupied(tx, ty)) return;
    const def = SOURCE_MAP.get(defId);
    if (!def) return;
    const sourceId = `src_${defId}_${srcSeq++}`;
    sources[sourceId] = {
      sourceId,
      definitionId: defId,
      tileX: tx,
      tileY: ty,
      stock: def.maxStock,
      maxStock: def.maxStock,
      currentUnitHp: def.hpPerUnit,
      depletedAtUtcSec: null,
      poiId: extra?.poiId,
      isDeepInterior: extra?.isDeepInterior,
      fixedCashYield: extra?.fixedCashYield,
    };
    markOccupied(tx, ty);
  };

  // 1. Build 8 physical POIs with outer salvage + optional gated inner vault + emergency exit
  for (const poiDef of POIS) {
    const cx = Math.round(poiDef.anchorRatio.x * width);
    const cy = Math.round(poiDef.anchorRatio.y * height);
    const w = poiDef.footprintTiles.w;
    const h = poiDef.footprintTiles.h;
    const x0 = cx - Math.floor(w / 2);
    const y0 = cy - Math.floor(h / 2);

    const poiRuntime: PoiRuntimeState = {
      poiId: poiDef.id,
      name: poiDef.name,
      centerX: cx * 16 + 8,
      centerY: cy * 16 + 8,
      bounds: { x: x0, y: y0, w, h },
      gateUnlocked: poiDef.deepGate === null,
      deepClearedOnce: false,
      vendorStock: (poiDef.vendorStock ?? []).map((v) => ({
        itemId: v.itemId,
        priceCash: v.priceCash,
        remaining: v.stock,
        acceptsUnsecuredPhysicalCash: v.acceptsUnsecuredPhysicalCash,
        policyStatus: v.policyStatus,
      })),
    };

    // Outer courtyard low perimeter corners leaving wide south & west open entrances
    for (let tx = x0; tx < x0 + w; tx++) {
      if (tx !== cx && tx !== cx - 1) {
        addPoiWall(tx, y0);
      }
      if (tx < cx - 2 || tx > cx + 2) {
        addPoiWall(tx, y0 + h - 1);
      }
    }
    for (let ty = y0 + 1; ty < y0 + h - 1; ty++) {
      if (ty < cy - 1 || ty > cy + 1) {
        addPoiWall(x0, ty);
        addPoiWall(x0 + w - 1, ty);
      }
    }

    // Place useful exterior sources accessible immediately without keys
    const outerPositions = [
      { x: x0 + 2, y: y0 + h - 2 },
      { x: x0 + 3, y: y0 + h - 2 },
      { x: x0 + w - 3, y: y0 + h - 2 },
      { x: x0 + 2, y: y0 + 2 },
    ];
    poiDef.outerSources.forEach((sDefId, idx) => {
      const pos = outerPositions[idx % outerPositions.length];
      addSource(sDefId, pos.x, pos.y, { poiId: poiDef.id, isDeepInterior: false });
    });

    // Optional gated inner vault room in upper-right quadrant of POI
    if (poiDef.deepGate) {
      const rx0 = cx;
      const ry0 = y0 + 1;
      const rw = x0 + w - 1 - rx0;
      const rh = Math.max(4, Math.floor(h / 2));
      poiRuntime.deepRoomBounds = { x: rx0, y: ry0, w: rw, h: rh };

      const gateX = rx0;
      const gateY = ry0 + Math.floor(rh / 2);
      const exitX = rx0 + Math.floor(rw / 2);
      const exitY = ry0 + rh - 1;
      poiRuntime.gateTile = { x: gateX, y: gateY };
      poiRuntime.emergencyExitTile = { x: exitX, y: exitY };
      markOccupied(gateX, gateY);
      markOccupied(exitX, exitY);

      for (let tx = rx0; tx < rx0 + rw; tx++) {
        if (tx !== exitX) addPoiWall(tx, ry0 + rh - 1);
      }
      for (let ty = ry0; ty < ry0 + rh; ty++) {
        if (ty !== gateY) addPoiWall(rx0, ty);
      }

      // Deep vault rewards inside room
      addSource('poi_vault_crate', rx0 + 2, ry0 + 1, { poiId: poiDef.id, isDeepInterior: true });
      addSource('ancient_core_reliquary', rx0 + 3, ry0 + 1, { poiId: poiDef.id, isDeepInterior: true });

      if (poiDef.hasFinal72CashChest && !poiDef.final72ChestAccessibleExteriorAnnex) {
        addSource('ragnarok_treasury_chest', rx0 + 2, ry0 + 2, {
          poiId: poiDef.id,
          isDeepInterior: true,
          fixedCashYield: poiDef.final72CashAmount ?? 210,
        });
      }
    }

    // Final-72h special finite Ragnarok Cash Chest in accessible exterior annex (no Elder/Core lock!)
    if (poiDef.hasFinal72CashChest && (poiDef.final72ChestAccessibleExteriorAnnex || !poiDef.deepGate)) {
      addSource('ragnarok_treasury_chest', x0 + 2, cy, {
        poiId: poiDef.id,
        isDeepInterior: false,
        fixedCashYield: poiDef.final72CashAmount ?? 200,
      });
    }

    if (poiDef.hasPhysicalVendor) {
      poiRuntime.vendorTile = { x: cx, y: cy };
      markOccupied(cx, cy);
    }

    if (poiDef.hasEvacuationBeacon) {
      poiRuntime.evacTile = { x: cx - 2, y: cy + 1 };
      markOccupied(cx - 2, cy + 1);
    }

    pois[poiDef.id] = poiRuntime;
  }

  // 2. Guarantee balanced starter resources around every one of the 4 safe spawn regions (C24)
  for (const sp of spawnRegions) {
    markOccupied(sp.tileX, sp.tileY);
    addSource('pine_tree', sp.tileX - 3, sp.tileY - 2);
    addSource('pine_tree', sp.tileX + 4, sp.tileY - 2);
    addSource('stone_outcrop', sp.tileX - 4, sp.tileY + 2);
    addSource('stone_outcrop', sp.tileX + 3, sp.tileY + 3);
    addSource('berry_bush', sp.tileX + 2, sp.tileY - 3);
    addSource('berry_bush', sp.tileX - 2, sp.tileY + 3);
    addSource('fresh_spring', sp.tileX + 4, sp.tileY + 1);
    addSource('roadside_crate', sp.tileX + 5, sp.tileY);
    addSource('roadside_barrel', sp.tileX, sp.tileY + 5);
  }

  // 3. Distribute natural & roadside sources coherently across the 192x192 island
  for (let ty = 6; ty < height - 6; ty += 3) {
    for (let tx = 6; tx < width - 6; tx += 3) {
      const jx = tx + rng.nextInt(-1, 1);
      const jy = ty + rng.nextInt(-1, 1);
      if (isOccupied(jx, jy)) continue;
      // Keep immediate 2-tile spawn pad clear
      if (spawnRegions.some((s) => Math.hypot(s.tileX - jx, s.tileY - jy) < 3.5)) continue;

      const b = biomes[tileIndex(jx, jy, width)];
      const roll = rng.nextFloat();

      if (b === 'road') {
        if (roll < 0.085) {
          addSource(roll < 0.042 ? 'roadside_crate' : 'roadside_barrel', jx, jy);
        }
      } else if (b === 'forest') {
        if (roll < 0.34) {
          addSource(roll < 0.23 ? 'pine_tree' : 'autumn_oak', jx, jy);
        } else if (roll < 0.41) {
          addSource(roll < 0.38 ? 'berry_bush' : 'herb_patch', jx, jy);
        } else if (roll < 0.44) {
          addSource('stone_outcrop', jx, jy);
        }
      } else if (b === 'plains' || b === 'coast') {
        if (roll < 0.08) addSource('pine_tree', jx, jy);
        else if (roll < 0.15) addSource('berry_bush', jx, jy);
        else if (roll < 0.20) addSource('stone_outcrop', jx, jy);
        else if (roll < 0.225) addSource('fresh_spring', jx, jy);
      } else if (b === 'wetland') {
        if (roll < 0.18) addSource('herb_patch', jx, jy);
        else if (roll < 0.25) addSource('autumn_oak', jx, jy);
      } else if (b === 'hills' || b === 'mountain') {
        if (roll < 0.20) addSource('stone_outcrop', jx, jy);
        else if (roll < 0.33) addSource('iron_vein', jx, jy);
        else if (roll < 0.41) addSource('copper_vein', jx, jy);
      } else if (b === 'cold') {
        if (roll < 0.16) addSource('copper_vein', jx, jy);
        else if (roll < 0.28) addSource('stone_outcrop', jx, jy);
        else if (roll < 0.36) addSource('pine_tree', jx, jy);
      } else if (b === 'hot' || b === 'radiation') {
        if (roll < 0.22) addSource('sulfur_vent', jx, jy);
        else if (roll < 0.32) addSource('iron_vein', jx, jy);
        else if (roll < 0.345) addSource('ancient_core_reliquary', jx, jy);
      }
    }
  }

  // 4. Spawn habitat-matched ordinary monsters (never inside safe spawn clearings)
  const enemies: EnemyActorState[] = [];
  let enemySeq = 1;
  for (let ty = 14; ty < height - 14; ty += 16) {
    for (let tx = 14; tx < width - 14; tx += 16) {
      const ex = tx + rng.nextInt(-4, 4);
      const ey = ty + rng.nextInt(-4, 4);
      if (isOccupied(ex, ey)) continue;
      if (spawnRegions.some((s) => Math.hypot(s.tileX - ex, s.tileY - ey) < 9)) continue;

      const b = biomes[tileIndex(ex, ey, width)];
      if (b === 'deep_sea' || b === 'shallow_water' || b === 'mountain') continue;

      const candidates = ENEMIES.filter((ed) => ed.habitatBiomes.includes(b));
      const chosen =
        candidates.length > 0
          ? candidates[rng.nextInt(0, candidates.length - 1)]
          : b === 'poi_floor'
          ? ENEMIES.find((e) => e.id === 'ruin_sentinel')!
          : ENEMIES[0];

      const wx = ex * 16 + 8;
      const wy = ey * 16 + 8;
      enemies.push({
        actorId: `enemy_${runId}_${enemySeq++}`,
        definitionId: chosen.id,
        x: wx,
        y: wy,
        homeX: wx,
        homeY: wy,
        hp: chosen.maxHp,
        maxHp: chosen.maxHp,
        alive: true,
        respawnAtUtcSec: null,
        aiState: 'patrol',
        targetPos: null,
        trackingFootprintId: null,
        visitedFootprintIds: [],
        lostTimerSec: 0,
        attackCooldownRemainingMs: 0,
        chilledUntilUtcSec: 0,
        facing: 'down',
      });
    }
  }

  // Also place one novice crawler at a fair optional skirmish distance (~10 tiles) near each spawn
  for (const sp of spawnRegions) {
    const crawler = ENEMIES[0];
    const cx = (sp.tileX + 9) * 16 + 8;
    const cy = (sp.tileY + 3) * 16 + 8;
    enemies.push({
      actorId: `enemy_${runId}_${enemySeq++}`,
      definitionId: crawler.id,
      x: cx,
      y: cy,
      homeX: cx,
      homeY: cy,
      hp: crawler.maxHp,
      maxHp: crawler.maxHp,
      alive: true,
      respawnAtUtcSec: null,
      aiState: 'patrol',
      targetPos: null,
      trackingFootprintId: null,
      visitedFootprintIds: [],
      lostTimerSec: 0,
      attackCooldownRemainingMs: 0,
      chilledUntilUtcSec: 0,
      facing: 'left',
    });
  }

  // 5. Spawn the 6 distinct optional Elders in latent form at their geographic domains
  const elders: ElderBossActorState[] = BOSSES.map((b) => {
    const bx = Math.round(b.arenaAnchorRatio.x * width) * 16 + 8;
    const by = Math.round(b.arenaAnchorRatio.y * height) * 16 + 8;
    return {
      bossId: b.id,
      definitionId: b.id,
      x: bx,
      y: by,
      arenaX: bx,
      arenaY: by,
      hp: b.latent.maxHp,
      maxHp: b.latent.maxHp,
      form: 'latent',
      defeated: false,
      stoneGranted: false,
      telegraph: null,
      cooldownRemainingMs: 0,
      facing: 'down',
    };
  });

  return { pois, structures, sources, enemies, elders };
}

export function isTileFrozenIce(state: GameState, tx: number, ty: number): boolean {
  return state.world.terrainEffects.some(
    (ef) => ef.type === 'frozen_ice' && ef.tileX === tx && ef.tileY === ty && ef.endUtcSec > state.clock.lastSimulatedUtcSec
  );
}

export function isTileWalkable(
  state: GameState,
  topology: WorldTopology,
  tx: number,
  ty: number,
  options?: { forCart?: boolean; ignoreStructures?: boolean }
): boolean {
  if (tx < 1 || ty < 1 || tx >= topology.width - 1 || ty >= topology.height - 1) return false;
  const biome = topology.biomes[tileIndex(tx, ty, topology.width)];

  if (biome === 'deep_sea') return false;
  if (biome === 'mountain') return false;
  if (biome === 'shallow_water' && !isTileFrozenIce(state, tx, ty)) {
    return options?.forCart ? false : true; // player can wade shallow water slowly; hand-cart cannot!
  }
  if (options?.forCart && biome === 'hills' && topology.elevation[tileIndex(tx, ty, topology.width)] > 0.78) {
    return false; // steep highland ledges block loaded carts
  }

  // Check POI locked gate tiles
  for (const poi of Object.values(state.world.pois)) {
    if (!poi.gateUnlocked && poi.gateTile && poi.gateTile.x === tx && poi.gateTile.y === ty) {
      return false;
    }
  }

  // Check active blocking natural/industrial sources
  for (const src of Object.values(state.sourceStocks)) {
    if (src.stock > 0 && src.tileX === tx && src.tileY === ty) {
      const sDef = SOURCE_MAP.get(src.definitionId);
      if (sDef?.blocksMovement) return false;
    }
  }

  if (!options?.ignoreStructures) {
    for (const str of Object.values(state.entities.structures)) {
      if (str.hp > 0 && str.tileX === tx && str.tileY === ty) {
        const def = STRUCTURE_MAP.get(str.definitionId);
        if (!def) continue;
        if (def.isDoor) {
          if (!str.isOpen) return false;
          if (options?.forCart) return false; // narrow house doorway blocks wide hand-cart
        } else if (def.blocksMovement) {
          return false;
        }
      }
    }
  }

  return true;
}

export function doesTilePassLight(state: GameState, topology: WorldTopology, tx: number, ty: number): boolean {
  if (tx < 0 || ty < 0 || tx >= topology.width || ty >= topology.height) return false;
  const biome = topology.biomes[tileIndex(tx, ty, topology.width)];
  if (biome === 'mountain') return false;

  for (const poi of Object.values(state.world.pois)) {
    if (!poi.gateUnlocked && poi.gateTile && poi.gateTile.x === tx && poi.gateTile.y === ty) {
      return false;
    }
  }

  for (const str of Object.values(state.entities.structures)) {
    if (str.hp > 0 && str.tileX === tx && str.tileY === ty) {
      const def = STRUCTURE_MAP.get(str.definitionId);
      if (!def) continue;
      if (def.isDoor) return Boolean(str.isOpen);
      if (def.blocksSight) return false;
    }
  }
  return true;
}

/**
 * Uses `rot-js` (`ROT.FOV.PreciseShadowcasting`, BSD-3-Clause) to verify exact 2D line-of-sight
 * so creatures, turrets, and ranged bows never cheat through walls, closed doors, or cliffs.
 */
export function hasLineOfSight(
  state: GameState,
  topology: WorldTopology,
  fromWorldX: number,
  fromWorldY: number,
  toWorldX: number,
  toWorldY: number,
  maxRadiusTiles = 12
): boolean {
  const sx = Math.floor(fromWorldX / 16);
  const sy = Math.floor(fromWorldY / 16);
  const gx = Math.floor(toWorldX / 16);
  const gy = Math.floor(toWorldY / 16);
  if (sx === gx && sy === gy) return true;
  if (Math.hypot(gx - sx, gy - sy) > maxRadiusTiles + 0.5) return false;

  let visible = false;
  const fov = new ROT.FOV.PreciseShadowcasting((x, y) => {
    if (x === sx && y === sy) return true;
    return doesTilePassLight(state, topology, x, y);
  });

  fov.compute(sx, sy, Math.ceil(maxRadiusTiles), (x, y) => {
    if (x === gx && y === gy) {
      visible = true;
    }
  });
  return visible;
}

/**
 * Uses `rot-js` (`ROT.Path.AStar`, BSD-3-Clause) for deterministic bounded grid navigation.
 * Immediately reflects newly built or destroyed walls/doors and cart route restrictions.
 */
export function findTilePath(
  state: GameState,
  topology: WorldTopology,
  startTx: number,
  startTy: number,
  goalTx: number,
  goalTy: number,
  options?: { maxSearchRadius?: number; forCart?: boolean; allowGoalOccupied?: boolean }
): Array<{ x: number; y: number }> {
  const maxR = options?.maxSearchRadius ?? 28;
  if (Math.abs(goalTx - startTx) > maxR || Math.abs(goalTy - startTy) > maxR) {
    return [];
  }

  const astar = new ROT.Path.AStar(
    goalTx,
    goalTy,
    (x, y) => {
      if (x === startTx && y === startTy) return true;
      if (options?.allowGoalOccupied && x === goalTx && y === goalTy) return true;
      if (Math.abs(x - startTx) > maxR || Math.abs(y - startTy) > maxR) return false;
      return isTileWalkable(state, topology, x, y, { forCart: options?.forCart });
    },
    { topology: 4 }
  );

  const path: Array<{ x: number; y: number }> = [];
  astar.compute(startTx, startTy, (x, y) => {
    path.push({ x, y });
  });
  return path;
}
