import {
  BALANCE,
  BOSS_MAP,
  ENEMY_MAP,
  ITEM_MAP,
  POI_MAP,
  RECIPES,
  RECIPE_MAP,
  SKILL_MAP,
  SOURCE_MAP,
  STRUCTURE_MAP,
} from '../data/catalogs';
import {
  countItemInContainer,
  debitItemFromContainer,
  getCartCargoWeightKg,
  getItemsInContainer,
  getPlayerCarryWeightKg,
  grantItemToContainer,
  transferInstanceToContainer,
} from './custody';
import { DeterministicRng } from './rng';
import type {
  AdventurerGender,
  BiomeId,
  DispatchResult,
  EventReceipt,
  FootprintTrace,
  GameIntent,
  GameState,
  PlacedStructureState,
  ProfileState,
  RunEndReason,
  VisualFeedbackEvent,
  WeatherKind,
} from './types';
import {
  getOrCreateTopology,
  getSurfaceSpeedMultiplier,
  getSurfaceTraceRetention,
  hasLineOfSight,
  isTileWalkable,
  populateRunWorldEntities,
  tileIndex,
} from './worldGen';

export const CURRENT_SCHEMA_VERSION = 1;

function computeClockFields(startedAtUtcSec: number, effectiveUtcSec: number) {
  const maxRun = BALANCE.clock.maxRunRealSeconds.value; // 1,209,600s (336h)
  const ragStart = maxRun - BALANCE.clock.ragnarokFinalSeconds.value; // 950,400s (264h)
  const elderAwaken = BALANCE.clock.elderAwakenStartSeconds.value; // 1,123,200s (312h / Day 14)

  const elapsed = Math.max(0, effectiveUtcSec - startedAtUtcSec);
  let phase: GameState['clock']['phase'] = 'ordinary';
  if (elapsed >= maxRun) phase = 'expired';
  else if (elapsed >= elderAwaken) phase = 'ragnarok_day14_elders';
  else if (elapsed >= ragStart) phase = 'ragnarok_final72';

  const dayCycle = BALANCE.clock.fictionalDayCycleRealSeconds.value;
  const cyclePos = (elapsed % dayCycle) / dayCycle; // 0..1
  // Smooth daylight curve: 0.25 at midnight, 1.0 at noon
  const daylightFactor = Number((0.62 + 0.38 * Math.sin((cyclePos - 0.22) * Math.PI * 2)).toFixed(3));
  const fictionalDayNumber = Math.floor(elapsed / dayCycle) + 1;

  return {
    elapsedRunSec: elapsed,
    phase,
    daylightFactor: Math.max(0.24, Math.min(1, daylightFactor)),
    fictionalDayNumber,
  };
}

function pushMessage(state: GameState, msg: string): void {
  state.history.recentMessages.unshift(msg);
  if (state.history.recentMessages.length > 40) {
    state.history.recentMessages.length = 40;
  }
}

function pushVfx(state: GameState, vfx: Omit<VisualFeedbackEvent, 'id' | 'createdAtSimMs'>): void {
  state.vfxQueue.push({
    ...vfx,
    id: `vfx_${state.revision}_${state.vfxQueue.length}_${Math.round(state.clock.simTimeMs)}`,
    createdAtSimMs: state.clock.simTimeMs,
  });
  if (state.vfxQueue.length > 48) {
    state.vfxQueue.splice(0, state.vfxQueue.length - 48);
  }
}

function awardUniqueScore(
  state: GameState,
  scoreKey: string,
  label: string,
  points: number,
  receiptId: string
): void {
  if (points <= 0) return;
  if (state.run.scoreEvents.some((s) => s.scoreKey === scoreKey)) return;
  state.run.scoreEvents.push({
    scoreKey,
    label,
    points,
    utcSec: state.clock.lastSimulatedUtcSec,
    receiptId,
  });
  if (!state.profile.achievements.includes(scoreKey)) {
    state.profile.achievements.push(scoreKey);
  }
}

export function isTileOwnedHomestead(state: GameState, tx: number, ty: number): boolean {
  const radius = BALANCE.economyAndTerritory.homesteadClaimRadiusTiles.value;
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp > 0 && str.ownerId === state.actors.player.actorId) {
      const def = STRUCTURE_MAP.get(str.definitionId);
      if (def?.claimsTerritory && Math.hypot(str.tileX - tx, str.tileY - ty) <= radius) {
        return true;
      }
    }
  }
  return false;
}

export function isPlayerSheltered(state: GameState): boolean {
  const ptx = Math.floor(state.actors.player.x / 16);
  const pty = Math.floor(state.actors.player.y / 16);
  let hasRoof = false;
  let nearbyWalls = 0;
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0) continue;
    const def = STRUCTURE_MAP.get(str.definitionId);
    if (!def) continue;
    if (def.isRoof && Math.abs(str.tileX - ptx) <= 1 && Math.abs(str.tileY - pty) <= 1) {
      hasRoof = true;
    }
    if ((def.category === 'wall' || def.isDoor) && Math.hypot(str.tileX - ptx, str.tileY - pty) <= 3.2) {
      nearbyWalls += 1;
    }
  }
  return hasRoof && nearbyWalls >= 3;
}

export function isTileRoofed(state: GameState, tx: number, ty: number): boolean {
  return Object.values(state.entities.structures).some((str) => {
    if (str.hp <= 0) return false;
    const def = STRUCTURE_MAP.get(str.definitionId);
    return Boolean(def?.isRoof && str.tileX === tx && str.tileY === ty);
  });
}

export function isStructurePowered(state: GameState, target: PlacedStructureState): boolean {
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0) continue;
    const def = STRUCTURE_MAP.get(str.definitionId);
    if (!def || !def.powerOutputWatts || !def.powerRadiusTiles) continue;
    if (def.usesFuel && str.fuelRemainingSec <= 0) continue;
    if (Math.hypot(str.tileX - target.tileX, str.tileY - target.tileY) <= def.powerRadiusTiles) {
      return true;
    }
  }
  return false;
}

function discoverNearbyChunks(state: GameState): void {
  const cx = Math.floor(state.actors.player.x / (16 * 16));
  const cy = Math.floor(state.actors.player.y / (16 * 16));
  const chunksPerRow = Math.ceil(state.world.width / 16);
  for (let oy = -1; oy <= 1; oy++) {
    for (let ox = -1; ox <= 1; ox++) {
      const nx = cx + ox;
      const ny = cy + oy;
      if (nx >= 0 && ny >= 0 && nx < chunksPerRow && ny < chunksPerRow) {
        const idx = ny * chunksPerRow + nx;
        if (!state.run.discoveredChunks.includes(idx)) {
          state.run.discoveredChunks.push(idx);
        }
      }
    }
  }
}

export function createInitialGameState(
  options?: {
    seed?: number;
    gender?: AdventurerGender;
    spawnRegionIndex?: number;
    nowUtcSec?: number;
    existingProfile?: ProfileState;
  }
): GameState {
  const worldSeed = options?.seed ?? BALANCE.world.defaultIslandSeed.value;
  const nowUtcSec = options?.nowUtcSec ?? Math.floor(Date.now() / 1000);
  const gender = options?.gender ?? 'female';
  const topology = getOrCreateTopology(worldSeed);

  const profile: ProfileState = options?.existingProfile
    ? structuredClone(options.existingProfile)
    : {
        profileId: 'local_profile_v1',
        securedCash: 0,
        achievements: [],
        runHistory: [],
        depositedReceiptIds: [],
      };

  const runNum = profile.runHistory.length + 1;
  const runSeed = (worldSeed ^ Math.imul(runNum, 0x85ebca6b) ^ (nowUtcSec & 0xffff)) | 0;
  const rng = new DeterministicRng(runSeed, 0);
  const runId = `run_${runNum}_${Math.abs(runSeed % 100000)}`;

  const spawnIdx =
    options?.spawnRegionIndex !== undefined
      ? Math.max(0, Math.min(topology.spawnRegions.length - 1, options.spawnRegionIndex))
      : rng.nextInt(0, topology.spawnRegions.length - 1);
  const chosenSpawn = topology.spawnRegions[spawnIdx];

  const populated = populateRunWorldEntities(topology, rng, runId, nowUtcSec);
  const starterRecipes = RECIPES.filter((r) => r.starterKnown).map((r) => r.id);
  const clockFields = computeClockFields(nowUtcSec, nowUtcSec);

  const state: GameState = {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    revision: 1,
    rngSeed: runSeed,
    rngStepCount: rng.stepCount,
    profile,
    run: {
      runId,
      active: true,
      endedReason: null,
      startedAtUtcSec: nowUtcSec,
      qaClockOffsetSec: 0,
      qaAcceleratedUsed: false,
      discoveredChunks: [],
      scoreEvents: [],
      elderStonesCollected: [],
      cashSecuredThisRun: 0,
      contextualNotesSeen: [],
    },
    clock: {
      lastSimulatedUtcSec: nowUtcSec,
      elapsedRunSec: clockFields.elapsedRunSec,
      simTimeMs: 0,
      phase: clockFields.phase,
      daylightFactor: clockFields.daylightFactor,
      fictionalDayNumber: clockFields.fictionalDayNumber,
      weather: 'clear',
      nextWeatherShiftUtcSec: nowUtcSec + BALANCE.clock.weatherShiftIntervalSeconds.value,
    },
    world: {
      seed: worldSeed,
      width: topology.width,
      height: topology.height,
      footprints: [],
      terrainEffects: [],
      pois: populated.pois,
    },
    actors: {
      player: {
        actorId: 'player_1',
        gender,
        x: chosenSpawn.tileX * 16 + 8,
        y: chosenSpawn.tileY * 16 + 8,
        facing: 'down',
        hp: BALANCE.player.maxHp.value,
        maxHp: BALANCE.player.maxHp.value,
        hunger: BALANCE.player.maxHunger.value,
        maxHunger: BALANCE.player.maxHunger.value,
        thirst: BALANCE.player.maxThirst.value,
        maxThirst: BALANCE.player.maxThirst.value,
        stamina: BALANCE.player.maxStamina.value,
        maxStamina: BALANCE.player.maxStamina.value,
        temperatureC: 21,
        radiationDose: 0,
        selectedQuickbarIndex: 0,
        attackCooldownMs: 0,
        lastSwingAtSimMs: -9999,
        lastSwingAngleRad: 0,
        activeCast: null,
        distanceSinceLastFootprintPx: 0,
        spawnRegionId: chosenSpawn.id,
        deathsCount: 0,
      },
      enemies: populated.enemies,
      elders: populated.elders,
    },
    sourceStocks: populated.sources,
    entities: {
      structures: populated.structures,
      carts: {},
      deathBags: {},
    },
    inventory: {
      items: {},
    },
    research: {
      learnedRecipeIds: starterRecipes,
    },
    jobs: {},
    history: {
      recentMessages: [
        `Landed at ${chosenSpawn.name}. 336h UTC survival clock active. Author your own story.`,
      ],
    },
    eventReceipts: [],
    vfxQueue: [],
  };

  // Humble starter kit: 1 Rusty Survival Knife equipped + 1 Purified Water Canteen in bag
  const initReceiptId = `rcpt_${runId}_init`;
  const knifeGrant = grantItemToContainer(
    state,
    rng,
    'player_equip:main_hand',
    'rusty_knife',
    1,
    `spawn:${chosenSpawn.id}`,
    initReceiptId
  );
  grantItemToContainer(state, rng, 'player_bag', 'clean_water', 1, `spawn:${chosenSpawn.id}`, initReceiptId);
  // Also place a quickbar reference or keep main_hand equipped; give 2 wild berries
  grantItemToContainer(state, rng, 'player_bag', 'wild_berries', 2, `spawn:${chosenSpawn.id}`, initReceiptId);

  state.rngStepCount = rng.stepCount;
  discoverNearbyChunks(state);

  state.eventReceipts.push({
    receiptId: initReceiptId,
    intentId: 'init_run',
    actionKind: 'START_NEW_RUN',
    runId,
    actorId: 'player_1',
    utcSec: nowUtcSec,
    revision: 1,
    sourceId: `spawn:${chosenSpawn.id}`,
    summary: `Started ${runId} (${gender}) at ${chosenSpawn.name} with ${knifeGrant.createdInstanceIds[0] ?? 'knife'}`,
  });

  return state;
}

function getEquippedArmorStats(state: GameState) {
  let defense = 0;
  let coldResist = 0;
  let heatResist = 0;
  let radResist = 0;
  let speedBonus = 0;

  for (const slot of ['body', 'accessory'] as const) {
    const equipped = getItemsInContainer(state, `player_equip:${slot}`)[0];
    if (!equipped) continue;
    if (equipped.durability !== undefined && equipped.durability <= 0) continue;
    const def = ITEM_MAP.get(equipped.definitionId);
    if (!def) continue;
    defense += def.armorDefense ?? 0;
    coldResist += def.coldResist ?? 0;
    heatResist += def.heatResist ?? 0;
    radResist += def.radResist ?? 0;
    speedBonus += def.speedBonus ?? 0;
  }

  return {
    defense,
    coldResist: Math.min(0.95, Math.max(-0.5, coldResist)),
    heatResist: Math.min(0.95, Math.max(-0.5, heatResist)),
    radResist: Math.min(0.95, Math.max(0, radResist)),
    speedBonus,
  };
}

function getActiveWeaponInstance(state: GameState, explicitInstanceId?: string) {
  if (explicitInstanceId) {
    const it = state.inventory.items[explicitInstanceId];
    if (it && (it.containerId === 'player_bag' || it.containerId === 'player_equip:main_hand')) {
      return it;
    }
  }
  const mainHand = getItemsInContainer(state, 'player_equip:main_hand')[0];
  if (mainHand) return mainHand;

  const qbItem = Object.values(state.inventory.items).find(
    (it) => it.containerId === 'player_bag' && it.slotIndex === state.actors.player.selectedQuickbarIndex
  );
  return qbItem ?? null;
}

function applyItemWear(state: GameState, instanceId: string, wearAmount: number): void {
  const inst = state.inventory.items[instanceId];
  if (!inst || inst.durability === undefined) return;
  inst.durability = Math.max(0, Number((inst.durability - wearAmount).toFixed(2)));
  if (inst.durability <= 0) {
    const def = ITEM_MAP.get(inst.definitionId);
    pushMessage(state, `${def?.name ?? 'Equipment'} broke! Repair or replace it.`);
  }
}

function handlePlayerDeath(state: GameState, rng: DeterministicRng, cause: string): void {
  const player = state.actors.player;
  const topology = getOrCreateTopology(state.world.seed);
  const deathX = player.x;
  const deathY = player.y;

  // Move all player_bag and player_equip:* items into ONE physical world DeathBagEntity (C10)
  const carried = Object.values(state.inventory.items).filter(
    (it) => it.containerId === 'player_bag' || it.containerId.startsWith('player_equip:')
  );

  if (carried.length > 0) {
    const bagId = rng.nextId('bag', state.run.runId, state.revision);
    state.entities.deathBags[bagId] = {
      bagId,
      runId: state.run.runId,
      x: deathX,
      y: deathY,
      createdAtUtcSec: state.clock.lastSimulatedUtcSec,
      deathCause: cause,
    };
    carried.forEach((it, idx) => {
      it.containerId = `death_bag:${bagId}`;
      it.slotIndex = idx;
    });
  }

  // Unhitch any hitched hand-cart at death spot
  for (const cart of Object.values(state.entities.carts)) {
    if (cart.hitchedByPlayer) cart.hitchedByPlayer = false;
  }

  player.deathsCount += 1;
  player.activeCast = null;

  // Respawn at valid intact player bed in SAME run, or safe spawn region fallback
  const playerBed = Object.values(state.entities.structures).find((str) => {
    const def = STRUCTURE_MAP.get(str.definitionId);
    return str.hp > 0 && str.ownerId === player.actorId && def?.isBed;
  });

  if (playerBed) {
    player.x = playerBed.tileX * 16 + 8;
    player.y = (playerBed.tileY + 1) * 16 + 8;
  } else {
    const sp =
      topology.spawnRegions.find((s) => s.id === player.spawnRegionId) ?? topology.spawnRegions[0];
    player.x = sp.tileX * 16 + 8;
    player.y = sp.tileY * 16 + 8;
  }

  player.hp = 75;
  player.hunger = Math.max(45, player.hunger);
  player.thirst = Math.max(45, player.thirst);
  player.stamina = player.maxStamina;
  player.radiationDose = 0;
  discoverNearbyChunks(state);
  pushMessage(
    state,
    `Fell to ${cause}! Dropped 1 physical recovery bag at (${Math.floor(deathX / 16)}, ${Math.floor(deathY / 16)}).`
  );
}

export function finalizeRunOnce(
  state: GameState,
  rng: DeterministicRng,
  reason: RunEndReason,
  intentId: string
): EventReceipt | null {
  if (!state.run.active) return null;

  // Count unsecured physical cash left behind in any run-local container (lost on finalize! C22/C23)
  let unsecuredLost = 0;
  for (const it of Object.values(state.inventory.items)) {
    if (it.definitionId === 'ragnarok_cash') {
      unsecuredLost += it.count;
    }
  }

  let finalReason = reason;
  if (reason === 'evacuated') {
    awardUniqueScore(
      state,
      'evacuated_alive',
      'Physical Harbor Evacuation',
      BALANCE.scoring.successfulEvacuationScore.value,
      `rcpt_evac_${state.run.runId}`
    );
    if (state.run.elderStonesCollected.length >= BALANCE.economyAndTerritory.elderCount.value) {
      finalReason = 'six_stone_convergence';
      awardUniqueScore(
        state,
        'six_elder_stones_convergence',
        'Six Elder Stones Convergence Ending',
        BALANCE.scoring.sixStoneEndingBonusScore.value,
        `rcpt_6stone_${state.run.runId}`
      );
    }
  }

  const totalScore = state.run.scoreEvents.reduce((acc, s) => acc + s.points, 0);
  const topology = getOrCreateTopology(state.world.seed);
  const spName =
    topology.spawnRegions.find((s) => s.id === state.actors.player.spawnRegionId)?.name ?? 'Island Coast';

  state.run.active = false;
  state.run.endedReason = finalReason;

  state.profile.runHistory.unshift({
    runId: state.run.runId,
    gender: state.actors.player.gender,
    spawnRegionName: spName,
    startedAtUtcSec: state.run.startedAtUtcSec,
    endedAtUtcSec: state.clock.lastSimulatedUtcSec,
    elapsedRealSeconds: state.clock.elapsedRunSec,
    endReason: finalReason,
    cashSecuredDuringRun: state.run.cashSecuredThisRun,
    unsecuredCashLostOnEnd: unsecuredLost,
    elderStonesCollected: [...state.run.elderStonesCollected],
    localUnverifiedScore: totalScore,
    verificationLabel: 'LOCAL_UNVERIFIED',
    qaClockUsed: state.run.qaAcceleratedUsed,
  });

  // Wipe run-local custody, stations, bags, carts, recipes, and Elder stones immediately on finalize
  state.inventory.items = {};
  state.entities.carts = {};
  state.entities.deathBags = {};
  state.jobs = {};
  state.research.learnedRecipeIds = [];

  const rcpt: EventReceipt = {
    receiptId: rng.nextId('rcpt_fin', state.run.runId, state.revision),
    intentId,
    actionKind: 'FINALIZE_RUN',
    runId: state.run.runId,
    actorId: state.actors.player.actorId,
    utcSec: state.clock.lastSimulatedUtcSec,
    revision: state.revision,
    summary: `Run finalized (${finalReason}). Secured profile cash: ${state.profile.securedCash}. Unsecured cash wiped: ${unsecuredLost}. Score: ${totalScore} (LOCAL_UNVERIFIED).`,
  };
  state.eventReceipts.push(rcpt);
  pushMessage(state, rcpt.summary);
  return rcpt;
}

function commitActiveCoreCast(state: GameState, rng: DeterministicRng): void {
  const cast = state.actors.player.activeCast;
  if (!cast || cast.committed) return;

  const coreInst = state.inventory.items[cast.coreInstanceId];
  const skill = SKILL_MAP.get(cast.skillId);
  if (!coreInst || !skill || (coreInst.charges ?? 0) <= 0) {
    state.actors.player.activeCast = null;
    return;
  }

  // Commit milestone reached: debit 1 charge atomically NOW (never earlier! C03)
  cast.committed = true;
  coreInst.charges = (coreInst.charges ?? 1) - 1;
  const rcptId = rng.nextId('rcpt_cast', state.run.runId, state.revision);

  // 1. Actor AoE damage
  let hitCount = 0;
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive) continue;
    if (Math.hypot(enemy.x - cast.targetX, enemy.y - cast.targetY) <= skill.aoeRadiusPx) {
      enemy.hp -= skill.actorDamage;
      hitCount++;
      if (skill.statusApplied === 'chilled') {
        enemy.chilledUntilUtcSec = state.clock.lastSimulatedUtcSec + 8;
      }
      if (enemy.hp <= 0) {
        killEnemy(state, rng, enemy, rcptId);
      }
    }
  }

  for (const elder of state.actors.elders) {
    if (elder.defeated) continue;
    if (Math.hypot(elder.x - cast.targetX, elder.y - cast.targetY) <= skill.aoeRadiusPx + 10) {
      elder.hp -= skill.actorDamage;
      hitCount++;
      if (elder.hp <= 0) {
        defeatElder(state, rng, elder, rcptId);
      }
    }
  }

  // 2. Authorized environmental terrain & resource mutations (C05)
  const topology = getOrCreateTopology(state.world.seed);
  const centerTx = Math.floor(cast.targetX / 16);
  const centerTy = Math.floor(cast.targetY / 16);
  const tileRad = Math.ceil(skill.aoeRadiusPx / 16);

  if (skill.terrainMutation === 'ignite_vegetation') {
    for (let ty = centerTy - tileRad; ty <= centerTy + tileRad; ty++) {
      for (let tx = centerTx - tileRad; tx <= centerTx + tileRad; tx++) {
        if (tx < 1 || ty < 1 || tx >= topology.width - 1 || ty >= topology.height - 1) continue;
        if (Math.hypot(tx * 16 + 8 - cast.targetX, ty * 16 + 8 - cast.targetY) > skill.aoeRadiusPx) continue;
        const b = topology.biomes[tileIndex(tx, ty, topology.width)];
        const hasFlammableSrc = Object.values(state.sourceStocks).some(
          (s) => s.stock > 0 && s.tileX === tx && s.tileY === ty && SOURCE_MAP.get(s.definitionId)?.flammable
        );
        if ((b === 'forest' || b === 'plains' || hasFlammableSrc) && state.clock.weather !== 'rain' && state.clock.weather !== 'storm') {
          state.world.terrainEffects.push({
            effectId: rng.nextId('tef', state.run.runId, state.revision),
            sourceInstanceId: coreInst.instanceId,
            sourceEventId: rcptId,
            tileX: tx,
            tileY: ty,
            materialBefore: b,
            type: 'burning',
            intensity: 1,
            startUtcSec: state.clock.lastSimulatedUtcSec,
            endUtcSec: state.clock.lastSimulatedUtcSec + 35,
            spreadDepth: 0,
            lastProcessedUtcSec: state.clock.lastSimulatedUtcSec,
          });
        }
      }
    }
  } else if (skill.terrainMutation === 'freeze_water') {
    for (let ty = centerTy - tileRad; ty <= centerTy + tileRad; ty++) {
      for (let tx = centerTx - tileRad; tx <= centerTx + tileRad; tx++) {
        if (tx < 1 || ty < 1 || tx >= topology.width - 1 || ty >= topology.height - 1) continue;
        const b = topology.biomes[tileIndex(tx, ty, topology.width)];
        if (b === 'shallow_water') {
          state.world.terrainEffects = state.world.terrainEffects.filter(
            (e) => !(e.tileX === tx && e.tileY === ty && e.type === 'frozen_ice')
          );
          state.world.terrainEffects.push({
            effectId: rng.nextId('tef', state.run.runId, state.revision),
            sourceInstanceId: coreInst.instanceId,
            sourceEventId: rcptId,
            tileX: tx,
            tileY: ty,
            materialBefore: b,
            type: 'frozen_ice',
            intensity: 1,
            startUtcSec: state.clock.lastSimulatedUtcSec,
            endUtcSec: state.clock.lastSimulatedUtcSec + 240,
            spreadDepth: 0,
            lastProcessedUtcSec: state.clock.lastSimulatedUtcSec,
          });
        }
      }
    }
  } else if (skill.terrainMutation === 'crack_mineral') {
    for (const src of Object.values(state.sourceStocks)) {
      if (src.stock <= 0) continue;
      const sDef = SOURCE_MAP.get(src.definitionId);
      if (!sDef || (sDef.material !== 'stone' && sDef.material !== 'ore')) continue;
      if (Math.hypot(src.tileX * 16 + 8 - cast.targetX, src.tileY * 16 + 8 - cast.targetY) <= skill.aoeRadiusPx) {
        src.stock -= 1;
        if (src.stock <= 0) src.depletedAtUtcSec = state.clock.lastSimulatedUtcSec;
        // Degraded blast yield (45% mineral purity compared to pickaxe mining - C05)
        if (rng.nextFloat() <= skill.harvestQualityFactor) {
          const primaryYield = sDef.yields[0];
          if (primaryYield) {
            grantItemToContainer(state, rng, 'player_bag', primaryYield.itemId, 1, src.sourceId, rcptId);
          }
        }
        state.world.terrainEffects.push({
          effectId: rng.nextId('tef', state.run.runId, state.revision),
          sourceInstanceId: coreInst.instanceId,
          sourceEventId: rcptId,
          tileX: src.tileX,
          tileY: src.tileY,
          materialBefore: topology.biomes[tileIndex(src.tileX, src.tileY, topology.width)],
          type: 'cracked_rock',
          intensity: 1,
          startUtcSec: state.clock.lastSimulatedUtcSec,
          endUtcSec: state.clock.lastSimulatedUtcSec + 300,
          spreadDepth: 0,
          lastProcessedUtcSec: state.clock.lastSimulatedUtcSec,
        });
      }
    }
  }

  pushVfx(state, {
    kind:
      skill.terrainMutation === 'ignite_vegetation'
        ? 'fire'
        : skill.terrainMutation === 'freeze_water'
        ? 'frost'
        : skill.terrainMutation === 'crack_mineral'
        ? 'seismic'
        : 'storm',
    x: cast.targetX,
    y: cast.targetY,
    radiusPx: skill.aoeRadiusPx,
    text: `${skill.name}!`,
    color: skill.vfxColor,
    durationMs: 650,
  });

  state.eventReceipts.push({
    receiptId: rcptId,
    intentId: cast.castId,
    actionKind: 'COMMIT_CORE_CAST',
    runId: state.run.runId,
    actorId: state.actors.player.actorId,
    utcSec: state.clock.lastSimulatedUtcSec,
    revision: state.revision,
    sourceId: coreInst.instanceId,
    summary: `Committed ${skill.name} (${coreInst.charges} charges left, ${hitCount} actors hit)`,
  });
  pushMessage(state, `${skill.name} unleashed! (${coreInst.charges} Core charges remaining)`);
}

function killEnemy(
  state: GameState,
  rng: DeterministicRng,
  enemy: GameState['actors']['enemies'][number],
  receiptId: string
): void {
  enemy.alive = false;
  enemy.hp = 0;
  const def = ENEMY_MAP.get(enemy.definitionId);
  if (!def) return;
  enemy.respawnAtUtcSec = state.clock.lastSimulatedUtcSec + def.respawnSeconds;
  enemy.trackingFootprintId = null;
  enemy.visitedFootprintIds = [];

  for (const drop of def.drops) {
    if (rng.nextFloat() <= drop.chance) {
      const qty = rng.nextInt(drop.min, drop.max);
      grantItemToContainer(state, rng, 'player_bag', drop.itemId, qty, enemy.actorId, receiptId);
    }
  }
  pushVfx(state, {
    kind: 'pickup',
    x: enemy.x,
    y: enemy.y,
    text: `${def.name} slain`,
    color: '#fca5a5',
    durationMs: 700,
  });
}

function defeatElder(
  state: GameState,
  rng: DeterministicRng,
  elder: GameState['actors']['elders'][number],
  receiptId: string
): void {
  if (elder.defeated) return;
  elder.defeated = true;
  elder.hp = 0;
  elder.telegraph = null;

  const bossDef = BOSS_MAP.get(elder.definitionId);
  if (!bossDef) return;

  if (!elder.stoneGranted && !state.run.elderStonesCollected.includes(bossDef.stoneItemId)) {
    elder.stoneGranted = true;
    state.run.elderStonesCollected.push(bossDef.stoneItemId);
    grantItemToContainer(
      state,
      rng,
      'player_bag',
      bossDef.stoneItemId,
      1,
      `elder:${elder.bossId}`,
      receiptId
    );
  }

  const pts =
    elder.form === 'awakened'
      ? BALANCE.scoring.uniqueElderAwakenedDefeatScore.value
      : BALANCE.scoring.uniqueElderLatentDefeatScore.value;

  awardUniqueScore(
    state,
    `elder_defeat:${elder.bossId}`,
    `Defeated ${bossDef.name} (${elder.form})`,
    pts,
    receiptId
  );

  pushMessage(state, `Vanquished ${bossDef.name}! Claimed unique ${bossDef.stoneItemId}.`);
}

/**
 * Advances scheduled world processes (stations, fuel, crops, weather, footprints,
 * terrain fire spread/extinguish, source regeneration, survival exposure, turret defense)
 * identically for online ticks AND bounded offline chronological replay!
 */
function advanceWorldProcessesSlice(
  state: GameState,
  rng: DeterministicRng,
  sliceSec: number,
  isOffline: boolean
): void {
  if (sliceSec <= 0 || !state.run.active) return;

  const prevUtc = state.clock.lastSimulatedUtcSec;
  const nextUtc = prevUtc + sliceSec;
  state.clock.lastSimulatedUtcSec = nextUtc;

  const effectiveUtc = nextUtc + state.run.qaClockOffsetSec;
  const clockFields = computeClockFields(state.run.startedAtUtcSec, effectiveUtc);
  state.clock.elapsedRunSec = clockFields.elapsedRunSec;
  state.clock.phase = clockFields.phase;
  state.clock.daylightFactor = clockFields.daylightFactor;
  state.clock.fictionalDayNumber = clockFields.fictionalDayNumber;

  // Check Day 14 Elder Awakening transition
  if (clockFields.phase === 'ragnarok_day14_elders') {
    for (const elder of state.actors.elders) {
      if (!elder.defeated && elder.form === 'latent') {
        const bDef = BOSS_MAP.get(elder.definitionId);
        if (bDef) {
          elder.form = 'awakened';
          elder.maxHp = bDef.awakened.maxHp;
          elder.hp = bDef.awakened.maxHp;
        }
      }
    }
  }

  // 1. Weather schedule transition
  if (nextUtc >= state.clock.nextWeatherShiftUtcSec) {
    const weathers: WeatherKind[] =
      clockFields.phase === 'ordinary'
        ? ['clear', 'clear', 'overcast', 'rain', 'storm']
        : ['overcast', 'rain', 'storm', 'ash_wind', 'storm'];
    state.clock.weather = weathers[rng.nextInt(0, weathers.length - 1)];
    state.clock.nextWeatherShiftUtcSec = nextUtc + BALANCE.clock.weatherShiftIntervalSeconds.value;
  }

  const isRaining = state.clock.weather === 'rain' || state.clock.weather === 'storm';
  const isStorm = state.clock.weather === 'storm';

  // 2. Footprint erosion (rain erodes 4x faster! C08/C14)
  if (isRaining && state.world.footprints.length > 0) {
    const extraDecay = sliceSec * (BALANCE.environmentAndTraces.rainTraceErosionMultiplier.value - 1);
    for (const fp of state.world.footprints) {
      fp.expiresAtUtcSec -= extraDecay;
    }
  }
  state.world.footprints = state.world.footprints.filter((fp) => fp.expiresAtUtcSec > nextUtc);

  // 3. Terrain effects (fire extinguish in rain, bounded fire spread, ice expiry)
  const newEffects: GameState['world']['terrainEffects'] = [];
  const topology = getOrCreateTopology(state.world.seed);
  for (const ef of state.world.terrainEffects) {
    if (ef.type === 'burning') {
      if (isRaining) {
        ef.endUtcSec = nextUtc; // Rain extinguishes outdoor vegetation fire!
        continue;
      }
      // Damage flammable source on burning tile once
      for (const src of Object.values(state.sourceStocks)) {
        if (src.stock > 0 && src.tileX === ef.tileX && src.tileY === ef.tileY) {
          const sDef = SOURCE_MAP.get(src.definitionId);
          if (sDef?.flammable && nextUtc - ef.lastProcessedUtcSec >= 6) {
            src.stock = Math.max(0, src.stock - 1);
            if (src.stock === 0) src.depletedAtUtcSec = nextUtc;
          }
        }
      }
      // Bounded fire spread (max depth 3 so novice forests aren't wiped)
      if (
        ef.spreadDepth < BALANCE.environmentAndTraces.fireSpreadMaxDepth.value &&
        nextUtc - ef.startUtcSec >= 12 &&
        ef.lastProcessedUtcSec === ef.startUtcSec
      ) {
        const dirs = [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ];
        const [dx, dy] = dirs[rng.nextInt(0, 3)];
        const ntx = ef.tileX + dx;
        const nty = ef.tileY + dy;
        if (
          ntx > 2 &&
          nty > 2 &&
          ntx < topology.width - 2 &&
          nty < topology.height - 2 &&
          topology.biomes[tileIndex(ntx, nty, topology.width)] === 'forest' &&
          !state.world.terrainEffects.some((o) => o.tileX === ntx && o.tileY === nty)
        ) {
          newEffects.push({
            effectId: rng.nextId('tef', state.run.runId, state.revision),
            sourceInstanceId: ef.sourceInstanceId,
            sourceEventId: ef.sourceEventId,
            tileX: ntx,
            tileY: nty,
            materialBefore: 'forest',
            type: 'burning',
            intensity: 1,
            startUtcSec: nextUtc,
            endUtcSec: nextUtc + 25,
            spreadDepth: ef.spreadDepth + 1,
            lastProcessedUtcSec: nextUtc,
          });
        }
      }
      ef.lastProcessedUtcSec = nextUtc;
    }
  }
  state.world.terrainEffects.push(...newEffects);
  state.world.terrainEffects = state.world.terrainEffects.filter((ef) => ef.endUtcSec > nextUtc);

  // 4. Station fuel burn, jobs timeline, and rain collectors (C06, C09)
  // First update generators & passive rain collectors
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0) continue;
    const def = STRUCTURE_MAP.get(str.definitionId);
    if (!def) continue;

    if (str.definitionId === 'fuel_generator' && str.fuelRemainingSec > 0) {
      str.fuelRemainingSec = Math.max(0, str.fuelRemainingSec - sliceSec);
    }

    if (str.definitionId === 'rain_collector' && isRaining && !isTileRoofed(state, str.tileX, str.tileY)) {
      if (sliceSec >= 60 || rng.nextFloat() < sliceSec / 90) {
        grantItemToContainer(
          state,
          rng,
          `station_out:${str.structureId}`,
          'clean_water',
          1,
          `rain:${str.structureId}`,
          `rcpt_rain_${nextUtc}`
        );
      }
    }
  }

  // Group active jobs by station so sequential jobs share finite fuel accurately!
  const jobsByStation = new Map<string, GameState['jobs'][string][]>();
  for (const job of Object.values(state.jobs)) {
    if (job.status === 'completed_unclaimed' || job.status === 'cancelled') continue;
    const list = jobsByStation.get(job.stationStructureId) ?? [];
    list.push(job);
    jobsByStation.set(job.stationStructureId, list);
  }

  for (const [stationId, stationJobs] of jobsByStation.entries()) {
    stationJobs.sort((a, b) => a.startedAtUtcSec - b.startedAtUtcSec);

    if (stationId === 'hand') {
      let rem = sliceSec;
      for (const job of stationJobs) {
        if (rem <= 0) break;
        const need = job.requiredSec - job.progressSec;
        const step = Math.min(rem, need);
        job.progressSec += step;
        job.lastUpdatedUtcSec = nextUtc;
        rem -= step;
        if (job.progressSec >= job.requiredSec) {
          completeJobIntoOutput(state, rng, job, 'player_bag');
        }
      }
      continue;
    }

    const station = state.entities.structures[stationId];
    if (!station || station.hp <= 0) continue;
    const stDef = STRUCTURE_MAP.get(station.definitionId);
    if (!stDef) continue;

    // Storm extinguishes unroofed outdoor campfires!
    if (station.definitionId === 'campfire' && isStorm && !isTileRoofed(state, station.tileX, station.tileY)) {
      station.fuelRemainingSec = 0;
      for (const job of stationJobs) {
        job.status = 'paused_storm';
        job.lastUpdatedUtcSec = nextUtc;
      }
      continue;
    }

    let availableWorkSec = sliceSec;
    if (stDef.usesFuel) {
      availableWorkSec = Math.min(sliceSec, station.fuelRemainingSec);
      station.fuelRemainingSec = Math.max(0, station.fuelRemainingSec - availableWorkSec);
    }

    for (const job of stationJobs) {
      const rcp = RECIPE_MAP.get(job.recipeId);
      if (!rcp) continue;
      if (rcp.powerRequired && !isStructurePowered(state, station)) {
        job.status = 'paused_no_power';
        job.lastUpdatedUtcSec = nextUtc;
        continue;
      }

      if (availableWorkSec <= 0) {
        if (stDef.usesFuel && station.fuelRemainingSec <= 0) {
          job.status = 'paused_no_fuel';
        }
        job.lastUpdatedUtcSec = nextUtc;
        continue;
      }

      job.status = 'active';
      const need = job.requiredSec - job.progressSec;
      const step = Math.min(availableWorkSec, need);
      job.progressSec += step;
      job.lastUpdatedUtcSec = nextUtc;
      availableWorkSec -= step;

      if (job.progressSec >= job.requiredSec - 1e-6) {
        completeJobIntoOutput(state, rng, job, `station_out:${station.structureId}`);
      } else if (stDef.usesFuel && station.fuelRemainingSec <= 0) {
        job.status = 'paused_no_fuel';
      }
    }
  }

  // 5. Source regeneration (NEVER regenerates final72Only or respawnSeconds === null! K3/C14/C15)
  for (const src of Object.values(state.sourceStocks)) {
    if (src.stock > 0 || src.depletedAtUtcSec === null) continue;
    const sDef = SOURCE_MAP.get(src.definitionId);
    if (!sDef || sDef.final72Only || sDef.respawnSeconds === null) continue;
    if (nextUtc - src.depletedAtUtcSec >= sDef.respawnSeconds) {
      src.stock = src.maxStock;
      src.currentUnitHp = sDef.hpPerUnit;
      src.depletedAtUtcSec = null;
    }
  }

  // 6. Enemy respawns
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive && enemy.respawnAtUtcSec !== null && nextUtc >= enemy.respawnAtUtcSec) {
      enemy.alive = true;
      enemy.hp = enemy.maxHp;
      enemy.x = enemy.homeX;
      enemy.y = enemy.homeY;
      enemy.respawnAtUtcSec = null;
      enemy.aiState = 'patrol';
      enemy.trackingFootprintId = null;
    }
  }

  // 7. Powered Auto-Turrets defend against line-of-sight enemies (consume real ammo + power, never spawn waves!)
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0 || str.definitionId !== 'auto_turret') continue;
    const def = STRUCTURE_MAP.get('auto_turret')!;
    if (!isStructurePowered(state, str)) continue;
    const ammoContainer = `station_out:${str.structureId}`;
    if (countItemInContainer(state, ammoContainer, 'turret_ammo_pack') <= 0) continue;

    const txWorld = str.tileX * 16 + 8;
    const tyWorld = str.tileY * 16 + 8;
    const targetEnemy = state.actors.enemies.find(
      (e) =>
        e.alive &&
        Math.hypot(e.x - txWorld, e.y - tyWorld) <= (def.turretRangePx ?? 125) &&
        hasLineOfSight(state, topology, txWorld, tyWorld, e.x, e.y, 9)
    );
    if (targetEnemy && sliceSec >= 0.8) {
      if (debitItemFromContainer(state, ammoContainer, 'turret_ammo_pack', 1)) {
        targetEnemy.hp -= def.turretDamage ?? 24;
        if (targetEnemy.hp <= 0) {
          killEnemy(state, rng, targetEnemy, `rcpt_turret_${nextUtc}`);
        }
      }
    }
  }

  // 8. Player metabolic & environmental exposure causality (K5, C09)
  const player = state.actors.player;
  const ptx = Math.floor(player.x / 16);
  const pty = Math.floor(player.y / 16);
  const biome: BiomeId =
    ptx >= 0 && pty >= 0 && ptx < topology.width && pty < topology.height
      ? topology.biomes[tileIndex(ptx, pty, topology.width)]
      : 'plains';
  const sheltered = isPlayerSheltered(state);
  const armor = getEquippedArmorStats(state);

  const hours = sliceSec / 3600;
  const shelterMetabolicFactor =
    isOffline && sheltered ? BALANCE.player.offlineShelterHungerMultiplier.value : sheltered ? 0.75 : 1.0;
  const heatFactor =
    biome === 'hot'
      ? 1 + (BALANCE.environmentAndTraces.hotZoneThirstMultiplier.value - 1) * (1 - armor.heatResist)
      : 1.0;

  player.hunger = Math.max(
    0,
    player.hunger - BALANCE.player.hungerDrainPerRealHour.value * shelterMetabolicFactor * hours
  );
  player.thirst = Math.max(
    0,
    player.thirst - BALANCE.player.thirstDrainPerRealHour.value * shelterMetabolicFactor * heatFactor * hours
  );

  // Starvation / dehydration HP drain — offline valid shelter protects hunger-ONLY death at 1 HP floor (LOCKED_CANON)
  if (player.hunger <= 0 || player.thirst <= 0) {
    const starveDmg = BALANCE.player.starvationDamagePerHour.value * hours * (player.hunger <= 0 && player.thirst <= 0 ? 1.5 : 1);
    if (isOffline && sheltered && player.thirst > 0) {
      player.hp = Math.max(BALANCE.player.offlineShelterStarvationHpFloor.value, player.hp - starveDmg);
    } else if (isOffline && sheltered) {
      player.hp = Math.max(BALANCE.player.offlineShelterStarvationHpFloor.value, player.hp - starveDmg);
    } else {
      player.hp -= starveDmg;
    }
  }

  // Environmental hazards are NEVER blocked by offline shelter floor (freezing, radiation, fire CAN kill! §2A)
  let warmFromFire = false;
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp > 0 && str.fuelRemainingSec > 0 && (str.definitionId === 'campfire' || str.definitionId === 'stone_furnace')) {
      if (Math.hypot(str.tileX - ptx, str.tileY - pty) <= 4) {
        warmFromFire = true;
        break;
      }
    }
  }

  if (biome === 'cold' && !warmFromFire) {
    player.temperatureC = 2 + armor.coldResist * 16;
    const coldDmg = (BALANCE.environmentAndTraces.coldZoneDamagePerMin.value * (1 - armor.coldResist) * sliceSec) / 60;
    if (coldDmg > 0.01) {
      player.hp -= coldDmg;
      if (player.hp <= 0) {
        handlePlayerDeath(state, rng, 'Hypothermia in Alpine Cold');
        return;
      }
    }
  } else if (biome === 'hot') {
    player.temperatureC = 39 - armor.heatResist * 10;
  } else {
    player.temperatureC = sheltered || warmFromFire ? 23 : 19;
  }

  // Check Bio-Bunker irradiated deep room or radiation crater
  let inRadVolume = biome === 'radiation';
  const bioBunker = state.world.pois['bio_bunker'];
  if (bioBunker?.deepRoomBounds) {
    const r = bioBunker.deepRoomBounds;
    if (ptx >= r.x && ptx < r.x + r.w && pty >= r.y && pty < r.y + r.h) {
      inRadVolume = true;
    }
  }
  if (inRadVolume) {
    const radRate = BALANCE.environmentAndTraces.radiationZoneDamagePerMin.value * (1 - armor.radResist);
    const radDmg = (radRate * sliceSec) / 60;
    player.radiationDose = Math.min(100, player.radiationDose + radDmg * 2);
    player.hp -= radDmg;
    if (player.hp <= 0) {
      handlePlayerDeath(state, rng, 'Lethal Radiation Exposure');
      return;
    }
  } else {
    player.radiationDose = Math.max(0, player.radiationDose - sliceSec * 0.2);
  }

  // Active burning tile under player
  if (state.world.terrainEffects.some((ef) => ef.type === 'burning' && ef.tileX === ptx && ef.tileY === pty)) {
    player.hp -= sliceSec * 6;
    if (player.hp <= 0) {
      handlePlayerDeath(state, rng, 'Wildfire Burns');
      return;
    }
  }

  if (player.hp <= 0) {
    handlePlayerDeath(state, rng, 'Starvation & Dehydration');
    return;
  }

  // 9. Natural 336h UTC run expiration check (LOCKED_CANON)
  if (state.clock.phase === 'expired' && state.run.active) {
    finalizeRunOnce(state, rng, 'expired_336h', `auto_expire_${nextUtc}`);
  }
}

function completeJobIntoOutput(
  state: GameState,
  rng: DeterministicRng,
  job: GameState['jobs'][string],
  outputContainerId: string
): void {
  const rcp = RECIPE_MAP.get(job.recipeId);
  if (!rcp) return;
  job.status = 'completed_unclaimed';
  job.progressSec = job.requiredSec;

  const rcptId = rng.nextId('rcpt_job', state.run.runId, state.revision);
  for (const out of rcp.outputs) {
    grantItemToContainer(state, rng, outputContainerId, out.itemId, out.count, `job:${job.jobId}`, rcptId);
  }
  delete state.jobs[job.jobId];
  pushMessage(
    state,
    `Completed ${rcp.name} -> ${outputContainerId === 'player_bag' ? 'Inventory' : 'Station Output Slot'}.`
  );
}

/**
 * Steps real-time movement, active Core windup, non-omniscient footprint-following Monster AI,
 * and Elder boss telegraphs.
 */
function stepRealtimeActors(
  state: GameState,
  rng: DeterministicRng,
  dtSec: number,
  moveDx: number,
  moveDy: number,
  sprint: boolean,
  aimWorldX?: number,
  aimWorldY?: number
): void {
  if (!state.run.active || dtSec <= 0) return;

  const dtMs = dtSec * 1000;
  state.clock.simTimeMs += dtMs;
  const player = state.actors.player;
  const topology = getOrCreateTopology(state.world.seed);

  player.attackCooldownMs = Math.max(0, player.attackCooldownMs - dtMs);

  // Resolve active Core cast windup -> commitMilestone
  if (player.activeCast) {
    if (!player.activeCast.committed && state.clock.simTimeMs >= player.activeCast.commitAtSimMs) {
      commitActiveCoreCast(state, rng);
    }
    if (player.activeCast && state.clock.simTimeMs >= player.activeCast.endAtSimMs) {
      player.activeCast = null;
    }
  }

  // Update player facing from aim or movement
  if (aimWorldX !== undefined && aimWorldY !== undefined) {
    const adx = aimWorldX - player.x;
    const ady = aimWorldY - player.y;
    if (Math.abs(adx) > Math.abs(ady)) {
      player.facing = adx >= 0 ? 'right' : 'left';
    } else if (Math.abs(ady) > 1) {
      player.facing = ady >= 0 ? 'down' : 'up';
    }
  }

  // Player movement with encumbrance, surface friction, and hitched Hand-Cart checks (K7/C13)
  const hitchedCart = Object.values(state.entities.carts).find((c) => c.hitchedByPlayer) ?? null;
  const carryKg = getPlayerCarryWeightKg(state);
  const baseCap = BALANCE.player.baseCarryCapacityKg.value;
  const hardCap = BALANCE.player.maxCarryHardCapKg.value;

  let encumbranceMult = 1.0;
  if (carryKg > hardCap) encumbranceMult = 0.35;
  else if (carryKg > baseCap) {
    encumbranceMult = Math.max(0.48, 1 - ((carryKg - baseCap) / (hardCap - baseCap)) * 0.5);
  }

  if (hitchedCart) {
    const cartKg = getCartCargoWeightKg(state, hitchedCart.cartId);
    const cartRatio = cartKg / BALANCE.economyAndTerritory.handCartMaxWeightKg.value;
    encumbranceMult *= Math.max(0.68, 0.92 - cartRatio * 0.24);
  }

  const ptx = Math.floor(player.x / 16);
  const pty = Math.floor(player.y / 16);
  const currentBiome = topology.biomes[tileIndex(ptx, pty, topology.width)] ?? 'plains';
  const surfaceMult = getSurfaceSpeedMultiplier(currentBiome, Boolean(hitchedCart));
  const armor = getEquippedArmorStats(state);

  const canSprint = sprint && !hitchedCart && player.stamina > 4 && (moveDx !== 0 || moveDy !== 0);
  const rawSpeed = canSprint
    ? BALANCE.player.sprintSpeedPxPerSec.value
    : BALANCE.player.walkSpeedPxPerSec.value;

  if (canSprint) {
    player.stamina = Math.max(0, player.stamina - BALANCE.player.sprintStaminaPerSec.value * dtSec);
  } else {
    player.stamina = Math.min(
      player.maxStamina,
      player.stamina + BALANCE.player.staminaRegenPerSec.value * dtSec
    );
  }

  const actualSpeed = rawSpeed * surfaceMult * encumbranceMult * (1 + armor.speedBonus);

  if (moveDx !== 0 || moveDy !== 0) {
    const mag = Math.hypot(moveDx, moveDy) || 1;
    const nx = moveDx / mag;
    const ny = moveDy / mag;
    if (aimWorldX === undefined) {
      if (Math.abs(nx) >= Math.abs(ny)) player.facing = nx >= 0 ? 'right' : 'left';
      else player.facing = ny >= 0 ? 'down' : 'up';
    }

    const prevX = player.x;
    const prevY = player.y;
    const candX = player.x + nx * actualSpeed * dtSec;
    const candY = player.y + ny * actualSpeed * dtSec;

    // Emergency one-way exit tile inside POI deep vault always lets player retreat outward!
    const isEmergencyExit = (tx: number, ty: number) =>
      Object.values(state.world.pois).some(
        (p) => p.emergencyExitTile && p.emergencyExitTile.x === tx && p.emergencyExitTile.y === ty
      );

    const candTxX = Math.floor(candX / 16);
    const curTy = Math.floor(player.y / 16);
    if (
      isEmergencyExit(candTxX, curTy) ||
      isTileWalkable(state, topology, candTxX, curTy, { forCart: Boolean(hitchedCart) })
    ) {
      player.x = candX;
    }

    const curTx = Math.floor(player.x / 16);
    const candTyY = Math.floor(candY / 16);
    if (
      isEmergencyExit(curTx, candTyY) ||
      isTileWalkable(state, topology, curTx, candTyY, { forCart: Boolean(hitchedCart) })
    ) {
      player.y = candY;
    }

    const movedPx = Math.hypot(player.x - prevX, player.y - prevY);
    if (movedPx > 0.05) {
      discoverNearbyChunks(state);
      player.distanceSinceLastFootprintPx += movedPx;

      // Update hitched Hand-Cart trailing position & slight wheel wear
      if (hitchedCart) {
        const trailDist = 18;
        const cdx = player.x - hitchedCart.x;
        const cdy = player.y - hitchedCart.y;
        const cDist = Math.hypot(cdx, cdy);
        if (cDist > trailDist) {
          hitchedCart.x += (cdx / cDist) * (cDist - trailDist);
          hitchedCart.y += (cdy / cDist) * (cDist - trailDist);
          hitchedCart.durability = Math.max(1, Number((hitchedCart.durability - movedPx * 0.002).toFixed(3)));
        }
      }

      // Emit surface-specific decaying FootprintTrace (K2/K5/C08)
      if (player.distanceSinceLastFootprintPx >= BALANCE.environmentAndTraces.footprintWriteIntervalPx.value) {
        player.distanceSinceLastFootprintPx = 0;
        const ftx = Math.floor(player.x / 16);
        const fty = Math.floor(player.y / 16);
        const fBiome = topology.biomes[tileIndex(ftx, fty, topology.width)] ?? 'plains';
        const retention = getSurfaceTraceRetention(fBiome);
        const lifetime = Math.round(BALANCE.environmentAndTraces.footprintBaseLifetimeSeconds.value * retention);
        const fp: FootprintTrace = {
          id: rng.nextId('fp', state.run.runId, state.revision),
          x: Math.round(player.x),
          y: Math.round(player.y),
          tileX: ftx,
          tileY: fty,
          createdAtUtcSec: state.clock.lastSimulatedUtcSec,
          expiresAtUtcSec: state.clock.lastSimulatedUtcSec + lifetime,
          surfaceRetention: retention,
          strength: retention,
        };
        state.world.footprints.push(fp);
        if (state.world.footprints.length > BALANCE.environmentAndTraces.maxActiveFootprints.value) {
          state.world.footprints.shift();
        }
      }
    }
  }

  // Non-omniscient Creature AI (K5/C08): NEVER reads global player home coordinates!
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive) continue;
    // Spatial simulation scope: active real-time AI within 380 px of player or while tracking trail
    const distToPlayer = Math.hypot(player.x - enemy.x, player.y - enemy.y);
    if (distToPlayer > 420 && enemy.aiState === 'patrol') continue;

    const eDef = ENEMY_MAP.get(enemy.definitionId);
    if (!eDef) continue;

    enemy.attackCooldownRemainingMs = Math.max(0, enemy.attackCooldownRemainingMs - dtMs);
    const chillMult = enemy.chilledUntilUtcSec > state.clock.lastSimulatedUtcSec ? 0.5 : 1.0;
    const speed = eDef.speedPxPerSec * chillMult;

    // 1. Direct visual detection ONLY within sightRangePx + real FOV line-of-sight
    const sightRange = eDef.sightRangePx * (0.7 + 0.3 * state.clock.daylightFactor);
    const seesPlayer =
      distToPlayer <= sightRange &&
      hasLineOfSight(state, topology, enemy.x, enemy.y, player.x, player.y, Math.ceil(sightRange / 16));

    if (seesPlayer) {
      enemy.aiState = 'chase_sight';
      enemy.targetPos = { x: player.x, y: player.y };
      enemy.lostTimerSec = 5;
      enemy.trackingFootprintId = null;
    } else if (enemy.aiState === 'chase_sight') {
      enemy.lostTimerSec -= dtSec;
      if (enemy.lostTimerSec <= 0) {
        enemy.aiState = 'return_habitat';
        enemy.targetPos = { x: enemy.homeX, y: enemy.homeY };
      }
    }

    // 2. Physical footprint trail discovery & contiguous segment following (C08)
    if (!seesPlayer && enemy.aiState !== 'chase_sight') {
      if (enemy.trackingFootprintId) {
        const curFp = state.world.footprints.find((f) => f.id === enemy.trackingFootprintId);
        if (!curFp || curFp.expiresAtUtcSec <= state.clock.lastSimulatedUtcSec) {
          // Trail faded or washed out by rain -> monster loses route knowledge immediately!
          enemy.trackingFootprintId = null;
          enemy.aiState = 'return_habitat';
          enemy.targetPos = { x: enemy.homeX, y: enemy.homeY };
        } else {
          enemy.targetPos = { x: curFp.x, y: curFp.y };
          if (Math.hypot(curFp.x - enemy.x, curFp.y - enemy.y) <= 14) {
            enemy.visitedFootprintIds.push(curFp.id);
            if (enemy.visitedFootprintIds.length > 24) enemy.visitedFootprintIds.shift();
            // Can ONLY advance to an adjacent contiguous newer segment within physical traceSenseRange!
            const maxStepDist = Math.min(42, eDef.traceSenseRangePx);
            const nextFp = state.world.footprints
              .filter(
                (f) =>
                  f.id !== curFp.id &&
                  !enemy.visitedFootprintIds.includes(f.id) &&
                  f.createdAtUtcSec >= curFp.createdAtUtcSec &&
                  Math.hypot(f.x - curFp.x, f.y - curFp.y) <= maxStepDist &&
                  hasLineOfSight(state, topology, enemy.x, enemy.y, f.x, f.y, 4)
              )
              .sort((a, b) => a.createdAtUtcSec - b.createdAtUtcSec)[0];

            if (nextFp) {
              enemy.trackingFootprintId = nextFp.id;
              enemy.targetPos = { x: nextFp.x, y: nextFp.y };
            } else {
              // Trail broken -> forget unknown home and return to habitat
              enemy.trackingFootprintId = null;
              enemy.aiState = 'return_habitat';
              enemy.targetPos = { x: enemy.homeX, y: enemy.homeY };
            }
          }
        }
      } else {
        // Check if a visible footprint exists within physical traceSenseRangePx
        const sensedFp = state.world.footprints.find(
          (f) =>
            !enemy.visitedFootprintIds.includes(f.id) &&
            Math.hypot(f.x - enemy.x, f.y - enemy.y) <= eDef.traceSenseRangePx &&
            hasLineOfSight(state, topology, enemy.x, enemy.y, f.x, f.y, 5)
        );
        if (sensedFp) {
          enemy.aiState = 'follow_trail';
          enemy.trackingFootprintId = sensedFp.id;
          enemy.targetPos = { x: sensedFp.x, y: sensedFp.y };
        } else if (enemy.aiState === 'patrol') {
          if (!enemy.targetPos || Math.hypot(enemy.targetPos.x - enemy.x, enemy.targetPos.y - enemy.y) < 10) {
            enemy.targetPos = {
              x: enemy.homeX + rng.nextInt(-36, 36),
              y: enemy.homeY + rng.nextInt(-36, 36),
            };
          }
        }
      }
    }

    // 3. Move & resolve lawful melee contact against player or blocking player wall/door
    if (distToPlayer <= eDef.attackRangePx && seesPlayer) {
      if (enemy.attackCooldownRemainingMs <= 0) {
        enemy.attackCooldownRemainingMs = eDef.attackCooldownMs;
        const mitigated = Math.max(1, Math.round(eDef.damage - armor.defense * 0.45));
        player.hp -= mitigated;
        pushVfx(state, {
          kind: 'hit',
          x: player.x,
          y: player.y - 6,
          text: `-${mitigated}`,
          color: '#ef4444',
          durationMs: 450,
        });
        // Slight armor wear
        const bodyArmor = getItemsInContainer(state, 'player_equip:body')[0];
        if (bodyArmor) applyItemWear(state, bodyArmor.instanceId, 0.4);
        if (player.hp <= 0) {
          handlePlayerDeath(state, rng, eDef.name);
          return;
        }
      }
    } else if (enemy.targetPos) {
      const mdx = enemy.targetPos.x - enemy.x;
      const mdy = enemy.targetPos.y - enemy.y;
      const mDist = Math.hypot(mdx, mdy);
      if (mDist > 2) {
        const vx = (mdx / mDist) * speed * dtSec;
        const vy = (mdy / mDist) * speed * dtSec;
        enemy.facing = Math.abs(mdx) > Math.abs(mdy) ? (mdx >= 0 ? 'right' : 'left') : mdy >= 0 ? 'down' : 'up';
        const ntx = Math.floor((enemy.x + vx) / 16);
        const nty = Math.floor((enemy.y + vy) / 16);

        if (isTileWalkable(state, topology, ntx, nty)) {
          enemy.x += vx;
          enemy.y += vy;
        } else if (
          eDef.canAttackStructures &&
          (enemy.aiState === 'chase_sight' || enemy.aiState === 'follow_trail')
        ) {
          // Monster can ONLY attack a player wall/door blocking its lawful path within reach!
          const blockingStr = Object.values(state.entities.structures).find(
            (s) =>
              s.hp > 0 &&
              s.ownerId === player.actorId &&
              s.tileX === ntx &&
              s.tileY === nty
          );
          if (blockingStr && enemy.attackCooldownRemainingMs <= 0) {
            enemy.attackCooldownRemainingMs = eDef.attackCooldownMs;
            blockingStr.hp = Math.max(0, blockingStr.hp - eDef.structureDamage);
            pushVfx(state, {
              kind: 'hit',
              x: blockingStr.tileX * 16 + 8,
              y: blockingStr.tileY * 16 + 8,
              text: `-${eDef.structureDamage}`,
              color: '#f97316',
              durationMs: 400,
            });
            if (blockingStr.hp <= 0) {
              delete state.entities.structures[blockingStr.structureId];
            }
          }
        } else if (enemy.aiState === 'patrol') {
          enemy.targetPos = { x: enemy.homeX, y: enemy.homeY };
        } else if (enemy.aiState === 'return_habitat' && Math.hypot(enemy.x - enemy.homeX, enemy.y - enemy.homeY) < 20) {
          enemy.aiState = 'patrol';
        }
      }
    }
  }

  // 4. Optional Six Elder Boss AI (telegraphed AoE committed at exact animation tick! C19)
  for (const elder of state.actors.elders) {
    if (elder.defeated) continue;
    const dist = Math.hypot(player.x - elder.x, player.y - elder.y);
    if (dist > 280) {
      elder.telegraph = null;
      continue;
    }
    const bDef = BOSS_MAP.get(elder.definitionId);
    if (!bDef) continue;
    const spec = elder.form === 'awakened' ? bDef.awakened : bDef.latent;
    elder.cooldownRemainingMs = Math.max(0, elder.cooldownRemainingMs - dtMs);

    if (elder.telegraph?.active) {
      if (state.clock.simTimeMs >= elder.telegraph.commitAtMs) {
        const hitDist = Math.hypot(player.x - elder.telegraph.targetX, player.y - elder.telegraph.targetY);
        if (hitDist <= elder.telegraph.radiusPx) {
          const dmg = Math.max(4, Math.round(spec.damage - armor.defense * 0.4));
          player.hp -= dmg;
          pushVfx(state, {
            kind: 'hit',
            x: player.x,
            y: player.y,
            radiusPx: elder.telegraph.radiusPx,
            text: `-${dmg} ${bDef.name.split(',')[0]}`,
            color: bDef.palettePrimary,
            durationMs: 600,
          });
          if (player.hp <= 0) {
            elder.telegraph = null;
            handlePlayerDeath(state, rng, bDef.name);
            return;
          }
        } else {
          pushVfx(state, {
            kind: 'cast',
            x: elder.telegraph.targetX,
            y: elder.telegraph.targetY,
            radiusPx: elder.telegraph.radiusPx,
            color: bDef.palettePrimary,
            durationMs: 350,
          });
        }
        elder.telegraph = null;
        elder.cooldownRemainingMs = spec.cooldownMs;
      }
    } else if (dist <= 155 && elder.cooldownRemainingMs <= 0) {
      elder.telegraph = {
        active: true,
        targetX: player.x,
        targetY: player.y,
        radiusPx: spec.aoeRadiusPx,
        startedAtMs: state.clock.simTimeMs,
        commitAtMs: state.clock.simTimeMs + spec.telegraphMs,
      };
    } else if (dist > 44 && Math.hypot(player.x - elder.arenaX, player.y - elder.arenaY) <= 190) {
      const edx = player.x - elder.x;
      const edy = player.y - elder.y;
      const em = Math.hypot(edx, edy) || 1;
      elder.x += (edx / em) * spec.speedPxPerSec * dtSec;
      elder.y += (edy / em) * spec.speedPxPerSec * dtSec;
      elder.facing = Math.abs(edx) > Math.abs(edy) ? (edx >= 0 ? 'right' : 'left') : edy >= 0 ? 'down' : 'up';
    }
  }

  // Clean up expired VFX
  state.vfxQueue = state.vfxQueue.filter(
    (v) => state.clock.simTimeMs - v.createdAtSimMs <= v.durationMs
  );
}

/**
 * Single Authoritative Action Dispatcher (`intent -> validate -> simulate candidate -> commit atomically -> receipt`).
 */
export function dispatchIntent(prevState: GameState, intent: GameIntent): DispatchResult {
  const intentId =
    intent.intentId ?? `intent_${prevState.revision}_${intent.kind}_${prevState.clock.lastSimulatedUtcSec}`;

  // Reject replay of an already-committed explicit intentId (anti-duplication invariant!)
  if (
    intent.intentId &&
    (prevState.eventReceipts.some((r) => r.intentId === intent.intentId) ||
      prevState.profile.depositedReceiptIds.includes(intent.intentId))
  ) {
    return {
      accepted: false,
      reason: `Duplicate intentId ${intent.intentId} already committed`,
      state: prevState,
    };
  }

  if (intent.kind === 'START_NEW_RUN') {
    const fresh = createInitialGameState({
      seed: prevState.world.seed,
      gender: intent.gender,
      spawnRegionIndex: intent.spawnRegionIndex,
      nowUtcSec: intent.nowUtcSec,
      existingProfile: prevState.profile,
    });
    return {
      accepted: true,
      receipt: fresh.eventReceipts[fresh.eventReceipts.length - 1],
      state: fresh,
    };
  }

  if (!prevState.run.active) {
    return {
      accepted: false,
      reason: 'Current run has already finalized. Start a new run.',
      state: prevState,
    };
  }

  // High-frequency real-time frame step avoids deep cloning receipts if unnecessary,
  // while still mutating a clean copy atomically.
  const state: GameState = structuredClone(prevState);
  state.revision += 1;
  const rng = new DeterministicRng(state.rngSeed, state.rngStepCount);
  const topology = getOrCreateTopology(state.world.seed);
  const player = state.actors.player;

  const commit = (summary: string, sourceId?: string, details?: Record<string, unknown>, recordReceipt = true): DispatchResult => {
    state.rngStepCount = rng.stepCount;
    let rcpt: EventReceipt | undefined;
    if (recordReceipt) {
      rcpt = {
        receiptId: rng.nextId('rcpt', state.run.runId, state.revision),
        intentId,
        actionKind: intent.kind,
        runId: state.run.runId,
        actorId: player.actorId,
        utcSec: state.clock.lastSimulatedUtcSec,
        revision: state.revision,
        sourceId,
        summary,
        details,
      };
      state.rngStepCount = rng.stepCount;
      state.eventReceipts.push(rcpt);
      if (state.eventReceipts.length > 250) {
        state.eventReceipts.splice(0, state.eventReceipts.length - 250);
      }
    }
    return { accepted: true, receipt: rcpt, state };
  };

  const reject = (reason: string): DispatchResult => ({
    accepted: false,
    reason,
    state: prevState,
  });

  switch (intent.kind) {
    case 'STEP_SIMULATION': {
      const clampedDt = Math.max(0, Math.min(0.25, intent.dtSec));
      stepRealtimeActors(
        state,
        rng,
        clampedDt,
        intent.moveDx,
        intent.moveDy,
        intent.sprint,
        intent.aimWorldX,
        intent.aimWorldY
      );
      const wallElapsed = Math.max(clampedDt, intent.nowUtcSec - state.clock.lastSimulatedUtcSec);
      if (wallElapsed >= 0.05) {
        advanceWorldProcessesSlice(state, rng, Math.min(wallElapsed, 5), false);
      }
      return commit('Frame tick', undefined, undefined, false);
    }

    case 'OFFLINE_CATCHUP': {
      const elapsedSec = intent.nowUtcSec - state.clock.lastSimulatedUtcSec;
      if (elapsedSec <= 1) {
        return commit('No offline gap to settle', undefined, { elapsedSec: 0 });
      }
      const batchSec = BALANCE.clock.offlineCatchupBatchSeconds.value; // 300s (5m) chronological slices
      let remaining = Math.min(elapsedSec, BALANCE.clock.maxRunRealSeconds.value);
      let slicesProcessed = 0;
      while (remaining > 0 && state.run.active) {
        const step = Math.min(batchSec, remaining);
        advanceWorldProcessesSlice(state, rng, step, true);
        remaining -= step;
        slicesProcessed++;
      }
      const msg = `Settled ${Math.round(elapsedSec)}s offline world timeline across ${slicesProcessed} ordered batches.`;
      pushMessage(state, msg);
      return commit(msg, 'clock:offline_catchup', { elapsedSec, slicesProcessed });
    }

    case 'QA_ADVANCE_CLOCK': {
      if (intent.advanceSeconds <= 0) return reject('Advance seconds must be positive');
      state.run.qaAcceleratedUsed = true;
      const batchSec = 900; // 15-min chronological steps for QA jumps
      let remaining = intent.advanceSeconds;
      while (remaining > 0 && state.run.active) {
        const step = Math.min(batchSec, remaining);
        advanceWorldProcessesSlice(state, rng, step, true);
        remaining -= step;
      }
      const msg = `[QA Clock] Advanced +${Math.round(intent.advanceSeconds / 3600 * 10) / 10}h (Run marked QA/UNVERIFIED).`;
      pushMessage(state, msg);
      return commit(msg, 'qa:clock', { advanceSeconds: intent.advanceSeconds });
    }

    case 'SELECT_QUICKBAR': {
      if (intent.slotIndex < 0 || intent.slotIndex >= 8) return reject('Invalid quickbar slot');
      player.selectedQuickbarIndex = intent.slotIndex;
      return commit(`Selected quickbar slot ${intent.slotIndex + 1}`, undefined, undefined, false);
    }

    case 'START_CORE_CAST': {
      const coreInst = state.inventory.items[intent.coreInstanceId];
      if (!coreInst) return reject('Core instance not found in custody');
      if (coreInst.containerId !== 'player_bag' && coreInst.containerId !== 'player_equip:main_hand') {
        return reject('Core must be carried or equipped to cast');
      }
      const def = ITEM_MAP.get(coreInst.definitionId);
      if (!def || def.category !== 'core' || !def.skillId) return reject('Item is not a castable Core');
      if ((coreInst.charges ?? 0) <= 0) return reject('Core has 0 charges remaining');
      const skill = SKILL_MAP.get(def.skillId);
      if (!skill) return reject('Unknown Core skill driver');
      if (Math.hypot(intent.targetWorldX - player.x, intent.targetWorldY - player.y) > skill.rangePx) {
        return reject('Target is out of Core skill range');
      }

      const castId = rng.nextId('cast', state.run.runId, state.revision);
      player.activeCast = {
        castId,
        coreInstanceId: coreInst.instanceId,
        skillId: skill.id,
        targetX: intent.targetWorldX,
        targetY: intent.targetWorldY,
        startedAtSimMs: state.clock.simTimeMs,
        commitAtSimMs: state.clock.simTimeMs + skill.windupMs,
        endAtSimMs: state.clock.simTimeMs + skill.windupMs + skill.recoveryMs,
        committed: false,
      };
      return commit(`Started ${skill.name} windup (charge not yet spent)`, coreInst.instanceId);
    }

    case 'CANCEL_CORE_CAST': {
      if (!player.activeCast) return reject('No active Core cast to cancel');
      if (player.activeCast.committed) return reject('Cast already passed commit milestone');
      const canceledSkillId = player.activeCast.skillId;
      player.activeCast = null;
      pushMessage(state, `Canceled ${canceledSkillId} before release (0 charges spent).`);
      return commit(`Canceled Core cast ${canceledSkillId} pre-commit with 0 charge debit`);
    }

    case 'ACT_ON_TARGET': {
      if (player.attackCooldownMs > 0) return reject('Action on cooldown');

      const toolInst = getActiveWeaponInstance(state, intent.itemInstanceId);
      const toolDef = toolInst ? ITEM_MAP.get(toolInst.definitionId) : null;
      const toolBroken = toolInst?.durability !== undefined && toolInst.durability <= 0;

      // If holding a charged Core, ACT_ON_TARGET delegates directly to START_CORE_CAST! (C03)
      if (toolInst && toolDef?.category === 'core') {
        return dispatchIntent(prevState, {
          kind: 'START_CORE_CAST',
          intentId: intent.intentId,
          coreInstanceId: toolInst.instanceId,
          targetWorldX: intent.targetWorldX,
          targetWorldY: intent.targetWorldY,
        });
      }

      const actorDmg =
        toolDef && !toolBroken && toolDef.actorDamage !== undefined
          ? toolDef.actorDamage
          : BALANCE.player.bareHandActorDamage.value;
      const rangePx =
        toolDef && !toolBroken && toolDef.attackRangePx !== undefined ? toolDef.attackRangePx : 26;
      const cooldownMs = toolDef?.attackCooldownMs ?? 380;

      player.lastSwingAtSimMs = state.clock.simTimeMs;
      player.lastSwingAngleRad = Math.atan2(intent.targetWorldY - player.y, intent.targetWorldX - player.x);
      player.attackCooldownMs = cooldownMs;

      // 1. Check hostile actors (enemies & Elders) near aim/reach with LOS check
      const hitEnemy = state.actors.enemies.find(
        (e) =>
          e.alive &&
          Math.hypot(e.x - player.x, e.y - player.y) <= rangePx + 10 &&
          Math.hypot(e.x - intent.targetWorldX, e.y - intent.targetWorldY) <= 28 &&
          hasLineOfSight(state, topology, player.x, player.y, e.x, e.y, Math.ceil(rangePx / 16) + 1)
      );

      if (hitEnemy) {
        hitEnemy.hp -= actorDmg;
        if (toolInst && !toolBroken && toolDef?.wearPerAction) {
          applyItemWear(state, toolInst.instanceId, toolDef.wearPerAction);
        }
        const rcptId = rng.nextId('rcpt_hit', state.run.runId, state.revision);
        pushVfx(state, {
          kind: 'hit',
          x: hitEnemy.x,
          y: hitEnemy.y - 6,
          text: `-${actorDmg}`,
          color: '#fde047',
          durationMs: 420,
        });
        if (hitEnemy.hp <= 0) {
          killEnemy(state, rng, hitEnemy, rcptId);
        }
        return commit(`Struck ${hitEnemy.definitionId} for ${actorDmg} dmg`, hitEnemy.actorId, {
          damage: actorDmg,
          remainingHp: hitEnemy.hp,
        });
      }

      const hitElder = state.actors.elders.find(
        (b) =>
          !b.defeated &&
          Math.hypot(b.x - player.x, b.y - player.y) <= rangePx + 16 &&
          Math.hypot(b.x - intent.targetWorldX, b.y - intent.targetWorldY) <= 36 &&
          hasLineOfSight(state, topology, player.x, player.y, b.x, b.y, Math.ceil(rangePx / 16) + 2)
      );

      if (hitElder) {
        hitElder.hp -= actorDmg;
        if (toolInst && !toolBroken && toolDef?.wearPerAction) {
          applyItemWear(state, toolInst.instanceId, toolDef.wearPerAction);
        }
        const rcptId = rng.nextId('rcpt_bhit', state.run.runId, state.revision);
        pushVfx(state, {
          kind: 'hit',
          x: hitElder.x,
          y: hitElder.y - 10,
          text: `-${actorDmg}`,
          color: '#fb923c',
          durationMs: 480,
        });
        if (hitElder.hp <= 0) {
          defeatElder(state, rng, hitElder, rcptId);
        }
        return commit(`Struck Elder ${hitElder.bossId} for ${actorDmg} dmg`, hitElder.bossId);
      }

      // 2. Check physical source node at target tile (C01, C02, C05, C15)
      if (toolDef?.rangedProjectile) {
        return reject('Ranged bow shot missed; arrows cannot harvest resource nodes');
      }

      const ttx = Math.floor(intent.targetWorldX / 16);
      const tty = Math.floor(intent.targetWorldY / 16);
      const hitSource = Object.values(state.sourceStocks)
        .filter(
          (s) =>
            s.stock > 0 &&
            Math.abs(s.tileX - ttx) <= 1 &&
            Math.abs(s.tileY - tty) <= 1 &&
            Math.hypot(s.tileX * 16 + 8 - player.x, s.tileY * 16 + 8 - player.y) <= Math.max(36, rangePx + 14)
        )
        .sort(
          (a, b) =>
            Math.hypot(a.tileX * 16 + 8 - intent.targetWorldX, a.tileY * 16 + 8 - intent.targetWorldY) -
            Math.hypot(b.tileX * 16 + 8 - intent.targetWorldX, b.tileY * 16 + 8 - intent.targetWorldY)
        )[0];

      if (!hitSource) {
        return reject('No valid creature or harvestable source within reach');
      }

      const sDef = SOURCE_MAP.get(hitSource.definitionId);
      if (!sDef) return reject('Unknown source definition');

      // Enforce Final-72h Ragnarok phase gate on finite cash chests! (C15)
      if (
        sDef.final72Only &&
        state.clock.phase !== 'ragnarok_final72' &&
        state.clock.phase !== 'ragnarok_day14_elders'
      ) {
        const msg = 'Ragnarok Vault Chest is sealed until the Final 72h Ragnarok phase!';
        pushMessage(state, msg);
        return reject(msg);
      }

      // Check POI locked interior access (prevent harvesting through locked wall/gate!)
      if (!hasLineOfSight(state, topology, player.x, player.y, hitSource.tileX * 16 + 8, hitSource.tileY * 16 + 8, 4)) {
        return reject('Blocked by wall or locked POI gate');
      }

      const harvestPower =
        toolDef && !toolBroken && toolDef.harvestProfile
          ? toolDef.harvestProfile[sDef.material] ?? 0
          : sDef.material === 'ore' || sDef.material === 'stone'
          ? sDef.material === 'stone'
            ? 2
            : 0
          : BALANCE.player.bareHandHarvestPower.value;

      if (harvestPower <= 0) {
        const msg = `Cannot extract ${sDef.name} without an appropriate tool (e.g. Pickaxe).`;
        pushMessage(state, msg);
        return reject(msg);
      }

      hitSource.currentUnitHp -= harvestPower;
      if (toolInst && !toolBroken && toolDef?.wearPerAction) {
        applyItemWear(state, toolInst.instanceId, toolDef.wearPerAction);
      }

      const grantedSummary: string[] = [];
      const rcptId = rng.nextId('rcpt_harv', state.run.runId, state.revision);

      if (hitSource.currentUnitHp <= 0) {
        hitSource.stock -= 1;
        hitSource.currentUnitHp = hitSource.stock > 0 ? sDef.hpPerUnit : 0;
        if (hitSource.stock <= 0) {
          hitSource.depletedAtUtcSec = state.clock.lastSimulatedUtcSec;
        }

        if (sDef.id === 'ragnarok_treasury_chest') {
          const cashAmt = hitSource.fixedCashYield ?? rng.nextInt(190, 230);
          const g = grantItemToContainer(
            state,
            rng,
            'player_bag',
            'ragnarok_cash',
            cashAmt,
            hitSource.sourceId,
            rcptId
          );
          if (g.addedCount <= 0) {
            return reject('Inventory full — make space before opening Ragnarok Vault Chest');
          }
          grantedSummary.push(`+${g.addedCount} Ragnarok Cash`);
          pushMessage(
            state,
            `Recovered ${g.addedCount} physical Ragnarok Cash from ${hitSource.sourceId}! Secure it via an owned Escrow Chest.`
          );
        } else {
          for (const yRule of sDef.yields) {
            if (rng.nextFloat() <= yRule.chance) {
              const qty = rng.nextInt(yRule.min, yRule.max);
              const g = grantItemToContainer(
                state,
                rng,
                'player_bag',
                yRule.itemId,
                qty,
                hitSource.sourceId,
                rcptId
              );
              if (g.addedCount > 0) {
                grantedSummary.push(`+${g.addedCount} ${ITEM_MAP.get(yRule.itemId)?.name ?? yRule.itemId}`);
              }
            }
          }
        }

        // Award one-time POI deep vault discovery score if inside a POI deep vault
        if (hitSource.poiId && hitSource.isDeepInterior) {
          const poi = state.world.pois[hitSource.poiId];
          if (poi && !poi.deepClearedOnce) {
            poi.deepClearedOnce = true;
            awardUniqueScore(
              state,
              `poi_deep:${poi.poiId}`,
              `Breached ${poi.name} Deep Vault`,
              BALANCE.scoring.uniquePoiDeepVaultClearScore.value,
              rcptId
            );
          }
        }
      }

      pushVfx(state, {
        kind: 'harvest',
        x: hitSource.tileX * 16 + 8,
        y: hitSource.tileY * 16 + 6,
        text: grantedSummary.length > 0 ? grantedSummary[0] : `${sDef.name} (${hitSource.stock})`,
        color: '#a3e635',
        durationMs: 550,
      });

      return commit(
        grantedSummary.length > 0
          ? `Harvested ${sDef.name}: ${grantedSummary.join(', ')}`
          : `Worked ${sDef.name} (unit HP ${hitSource.currentUnitHp})`,
        hitSource.sourceId,
        { stockRemaining: hitSource.stock, granted: grantedSummary }
      );
    }

    case 'USE_ITEM': {
      const inst = state.inventory.items[intent.instanceId];
      if (!inst || inst.containerId !== 'player_bag') return reject('Item must be in player inventory');
      const def = ITEM_MAP.get(inst.definitionId);
      if (!def) return reject('Unknown item');

      if (def.category === 'blueprint' && def.teachesRecipes) {
        const newlyLearned = def.teachesRecipes.filter((r) => !state.research.learnedRecipeIds.includes(r));
        if (newlyLearned.length === 0) {
          return reject('All recipes on this blueprint are already known in this run');
        }
        state.research.learnedRecipeIds.push(...newlyLearned);
        inst.count -= 1;
        if (inst.count <= 0) delete state.inventory.items[inst.instanceId];
        pushMessage(state, `Studied ${def.name}: learned ${newlyLearned.join(', ')}!`);
        return commit(`Learned ${newlyLearned.join(', ')} from blueprint`, inst.instanceId);
      }

      if (def.repairAmount) {
        const targetEquip =
          getItemsInContainer(state, 'player_equip:main_hand')[0] ??
          getItemsInContainer(state, 'player_equip:body')[0];
        if (!targetEquip || targetEquip.durability === undefined || targetEquip.maxDurability === undefined) {
          return reject('Equip a damaged tool, weapon, or armor piece to repair');
        }
        if (targetEquip.durability >= targetEquip.maxDurability) {
          return reject('Equipped item is already at full durability');
        }
        targetEquip.durability = Math.min(targetEquip.maxDurability, targetEquip.durability + def.repairAmount);
        inst.count -= 1;
        if (inst.count <= 0) delete state.inventory.items[inst.instanceId];
        return commit(`Repaired ${targetEquip.definitionId} to ${targetEquip.durability}`, inst.instanceId);
      }

      if (
        def.hungerRestore === undefined &&
        def.thirstRestore === undefined &&
        def.hpRestore === undefined &&
        def.radClear === undefined
      ) {
        return reject(`${def.name} cannot be consumed directly`);
      }

      player.hunger = Math.min(player.maxHunger, Math.max(0, player.hunger + (def.hungerRestore ?? 0)));
      player.thirst = Math.min(player.maxThirst, Math.max(0, player.thirst + (def.thirstRestore ?? 0)));
      player.hp = Math.min(player.maxHp, Math.max(1, player.hp + (def.hpRestore ?? 0)));
      if (def.radClear) {
        player.radiationDose = Math.max(0, player.radiationDose - def.radClear);
      }

      inst.count -= 1;
      if (inst.count <= 0) delete state.inventory.items[inst.instanceId];
      pushMessage(state, `Consumed ${def.name}.`);
      return commit(`Used ${def.name}`, inst.instanceId);
    }

    case 'EQUIP_ITEM': {
      const inst = state.inventory.items[intent.instanceId];
      if (!inst) return reject('Item not found');
      const def = ITEM_MAP.get(inst.definitionId);
      if (!def || !def.equipSlot) return reject('Item cannot be equipped');

      const equipContainer = `player_equip:${def.equipSlot}`;
      const existing = getItemsInContainer(state, equipContainer)[0];
      const oldContainer = inst.containerId;
      const oldSlot = inst.slotIndex;

      if (existing) {
        existing.containerId = oldContainer;
        existing.slotIndex = oldSlot;
      }
      inst.containerId = equipContainer;
      inst.slotIndex = 0;
      return commit(`Equipped ${def.name} (${inst.instanceId})`, inst.instanceId);
    }

    case 'UNEQUIP_ITEM': {
      const equipContainer = `player_equip:${intent.equipSlot}`;
      const existing = getItemsInContainer(state, equipContainer)[0];
      if (!existing) return reject('Nothing equipped in that slot');
      const res = transferInstanceToContainer(state, existing.instanceId, 'player_bag');
      if (!res.ok) return reject(res.reason ?? 'Inventory full');
      return commit(`Unequipped ${existing.definitionId}`, existing.instanceId);
    }

    case 'TRANSFER_ITEM': {
      const inst = state.inventory.items[intent.instanceId];
      if (!inst) return reject('Item instance not found');

      // Validate physical proximity for external containers (chests, stations, carts, death bags)
      const checkProximity = (cid: string): string | null => {
        if (cid === 'player_bag' || cid.startsWith('player_equip:')) return null;
        if (cid.startsWith('structure:') || cid.startsWith('station_out:')) {
          const sid = cid.split(':')[1];
          const str = state.entities.structures[sid];
          if (!str || str.hp <= 0) return 'Target container structure does not exist';
          if (Math.hypot(str.tileX * 16 + 8 - player.x, str.tileY * 16 + 8 - player.y) > 68) {
            return 'Too far from structure container';
          }
          return null;
        }
        if (cid.startsWith('cart:')) {
          const cartId = cid.slice('cart:'.length);
          const cart = state.entities.carts[cartId];
          if (!cart) return 'Hand-Cart not found';
          if (Math.hypot(cart.x - player.x, cart.y - player.y) > 68) return 'Too far from Hand-Cart';
          return null;
        }
        if (cid.startsWith('death_bag:')) {
          const bagId = cid.slice('death_bag:'.length);
          const bag = state.entities.deathBags[bagId];
          if (!bag) return 'Death recovery bag not found';
          if (Math.hypot(bag.x - player.x, bag.y - player.y) > 64) return 'Must physically travel to Death Bag';
          return null;
        }
        return 'Invalid container';
      };

      const errFrom = checkProximity(inst.containerId);
      if (errFrom) return reject(errFrom);
      const errTo = checkProximity(intent.toContainerId);
      if (errTo) return reject(errTo);

      const fromCid = inst.containerId;
      const res = transferInstanceToContainer(state, inst.instanceId, intent.toContainerId, intent.toSlotIndex);
      if (!res.ok) return reject(res.reason ?? 'Transfer failed');

      // Clean up empty death bag once emptied
      if (fromCid.startsWith('death_bag:')) {
        const bagId = fromCid.slice('death_bag:'.length);
        if (getItemsInContainer(state, fromCid).length === 0) {
          delete state.entities.deathBags[bagId];
        }
      }

      return commit(`Transferred ${inst.definitionId} (${inst.instanceId}) -> ${intent.toContainerId}`, inst.instanceId);
    }

    case 'SPLIT_STACK': {
      const inst = state.inventory.items[intent.instanceId];
      if (!inst) return reject('Stack not found');
      const def = ITEM_MAP.get(inst.definitionId);
      if (!def || def.uniqueInstance || inst.count <= 1) return reject('Item cannot be split');
      if (intent.splitCount <= 0 || intent.splitCount >= inst.count) return reject('Invalid split quantity');

      const beforeCount = inst.count;
      inst.count -= intent.splitCount;
      const granted = grantItemToContainer(
        state,
        rng,
        inst.containerId,
        inst.definitionId,
        intent.splitCount,
        inst.provenanceSourceId,
        inst.provenanceReceiptId
      );
      if (granted.addedCount < intent.splitCount || granted.createdInstanceIds.length === 0) {
        return reject('No free slot in container to split stack');
      }
      return commit(`Split ${intent.splitCount}/${beforeCount} ${def.name}`, inst.instanceId);
    }

    case 'BUILD_STRUCTURE': {
      const sDef = STRUCTURE_MAP.get(intent.structureDefId);
      if (!sDef) return reject('Unknown structure blueprint');
      const { tileX, tileY } = intent;

      if (tileX < 2 || tileY < 2 || tileX >= topology.width - 2 || tileY >= topology.height - 2) {
        return reject('Out of buildable island bounds');
      }
      if (Math.hypot(tileX * 16 + 8 - player.x, tileY * 16 + 8 - player.y) > 84) {
        return reject('Build site is out of reach (move closer)');
      }

      const biome = topology.biomes[tileIndex(tileX, tileY, topology.width)];
      if (biome === 'deep_sea' || biome === 'shallow_water' || biome === 'mountain') {
        return reject(`Cannot build on ${biome} terrain`);
      }

      // Check Homestead claim cap
      if (sDef.claimsTerritory) {
        const activeClaims = Object.values(state.entities.structures).filter(
          (s) => s.hp > 0 && s.ownerId === player.actorId && STRUCTURE_MAP.get(s.definitionId)?.claimsTerritory
        ).length;
        if (activeClaims >= BALANCE.economyAndTerritory.maxHomesteadClaimsPerRun.value) {
          return reject('Maximum Homestead Claim Totems reached for this run');
        }
      }

      // Check legitimate Homestead ownership requirement (e.g. Escrow Chest! LOCKED_CANON / C16)
      if (sDef.requiresOwnedTerritory && !isTileOwnedHomestead(state, tileX, tileY)) {
        return reject('Escrow Chest must be placed on legitimately owned Homestead land (build a Homestead Claim Totem first)');
      }

      // Check tile occupancy conflicts
      const blockingSrc = Object.values(state.sourceStocks).find(
        (s) => s.stock > 0 && s.tileX === tileX && s.tileY === tileY
      );
      if (blockingSrc) return reject('Clear resource node on tile before building');

      const sameTileStructures = Object.values(state.entities.structures).filter(
        (s) => s.hp > 0 && s.tileX === tileX && s.tileY === tileY
      );
      for (const existing of sameTileStructures) {
        const exDef = STRUCTURE_MAP.get(existing.definitionId);
        if (!exDef) continue;
        if (sDef.isFloor && exDef.isFloor) return reject('Floor foundation already placed here');
        if (sDef.isRoof && exDef.isRoof) return reject('Roof already placed overhead');
        if (!sDef.isFloor && !sDef.isRoof && !exDef.isFloor && !exDef.isRoof) {
          return reject(`Tile occupied by ${exDef.name}`);
        }
      }

      // Prevent trapping player inside newly built blocking wall
      const ptx = Math.floor(player.x / 16);
      const pty = Math.floor(player.y / 16);
      if (sDef.blocksMovement && !sDef.isDoor && ptx === tileX && pty === tileY) {
        return reject('Step off the tile before placing a solid structure');
      }

      // Debit deployable item instance OR raw construction materials atomically
      let deployedInstanceId: string | undefined;
      if (sDef.deployItemOnly) {
        const inst = intent.deployInstanceId
          ? state.inventory.items[intent.deployInstanceId]
          : Object.values(state.inventory.items).find(
              (it) => it.containerId === 'player_bag' && it.definitionId === sDef.deployItemOnly
            );
        if (!inst || inst.containerId !== 'player_bag' || inst.definitionId !== sDef.deployItemOnly) {
          return reject(`Requires physical ${ITEM_MAP.get(sDef.deployItemOnly)?.name ?? sDef.deployItemOnly} in inventory`);
        }
        deployedInstanceId = inst.instanceId;
        delete state.inventory.items[inst.instanceId];
      } else {
        for (const req of sDef.cost) {
          if (countItemInContainer(state, 'player_bag', req.itemId) < req.count) {
            return reject(`Insufficient ${ITEM_MAP.get(req.itemId)?.name ?? req.itemId} (${req.count} required)`);
          }
        }
        for (const req of sDef.cost) {
          debitItemFromContainer(state, 'player_bag', req.itemId, req.count);
        }
      }

      const structureId = rng.nextId('str', state.run.runId, state.revision);
      state.entities.structures[structureId] = {
        structureId,
        definitionId: sDef.id,
        tileX,
        tileY,
        hp: sDef.maxHp,
        maxHp: sDef.maxHp,
        ownerId: player.actorId,
        isOpen: false,
        fuelRemainingSec: 0,
        deployedFromInstanceId: deployedInstanceId,
        createdAtUtcSec: state.clock.lastSimulatedUtcSec,
      };

      pushMessage(state, `Constructed ${sDef.name} at (${tileX}, ${tileY}).`);
      return commit(`Built ${sDef.name} (${structureId})`, structureId, { tileX, tileY });
    }

    case 'RECLAIM_STRUCTURE': {
      const str = state.entities.structures[intent.structureId];
      if (!str || str.hp <= 0) return reject('Structure not found');
      if (str.ownerId !== player.actorId) return reject('Cannot reclaim unowned POI masonry');
      if (Math.hypot(str.tileX * 16 + 8 - player.x, str.tileY * 16 + 8 - player.y) > 76) {
        return reject('Move closer to reclaim structure');
      }

      // Loaded-container policy check (C07): NEVER vanish items inside chests or station output slots!
      const heldItems = [
        ...getItemsInContainer(state, `structure:${str.structureId}`),
        ...getItemsInContainer(state, `station_out:${str.structureId}`),
      ];
      if (heldItems.length > 0) {
        return reject('Container/station holds physical items — transfer contents out before reclaiming');
      }

      const sDef = STRUCTURE_MAP.get(str.definitionId)!;
      const rcptId = rng.nextId('rcpt_rec', state.run.runId, state.revision);

      if (sDef.deployItemOnly) {
        const g = grantItemToContainer(
          state,
          rng,
          'player_bag',
          sDef.deployItemOnly,
          1,
          str.structureId,
          rcptId
        );
        if (g.addedCount <= 0) return reject('Inventory full — cannot pick up deployed structure');
      } else {
        for (const ref of sDef.reclaimRefund) {
          grantItemToContainer(state, rng, 'player_bag', ref.itemId, ref.count, str.structureId, rcptId);
        }
      }

      // Cancel active jobs on reclaimed station
      for (const job of Object.values(state.jobs)) {
        if (job.stationStructureId === str.structureId) {
          delete state.jobs[job.jobId];
        }
      }

      delete state.entities.structures[str.structureId];
      pushMessage(state, `Reclaimed ${sDef.name}.`);
      return commit(`Reclaimed ${sDef.name}`, str.structureId);
    }

    case 'REPAIR_STRUCTURE': {
      const str = state.entities.structures[intent.structureId];
      if (!str || str.hp <= 0) return reject('Structure not found');
      if (str.hp >= str.maxHp) return reject('Structure is already at full HP');
      if (Math.hypot(str.tileX * 16 + 8 - player.x, str.tileY * 16 + 8 - player.y) > 72) {
        return reject('Too far to repair structure');
      }
      const sDef = STRUCTURE_MAP.get(str.definitionId);
      const repairMat = sDef?.cost[0]?.itemId ?? 'wood_log';
      if (!debitItemFromContainer(state, 'player_bag', repairMat, 2)) {
        return reject(`Requires 2 ${ITEM_MAP.get(repairMat)?.name ?? repairMat} to repair`);
      }
      str.hp = Math.min(str.maxHp, str.hp + Math.round(str.maxHp * 0.45));
      return commit(`Repaired ${str.definitionId} to ${str.hp}/${str.maxHp} HP`, str.structureId);
    }

    case 'TOGGLE_DOOR': {
      const str = state.entities.structures[intent.structureId];
      if (!str || str.hp <= 0) return reject('Door not found');
      const sDef = STRUCTURE_MAP.get(str.definitionId);
      if (!sDef?.isDoor) return reject('Target structure is not a door');
      if (Math.hypot(str.tileX * 16 + 8 - player.x, str.tileY * 16 + 8 - player.y) > 64) {
        return reject('Move closer to operate door');
      }
      if (sDef.requiresPower && !isStructurePowered(state, str)) {
        return reject('Powered Blast Door has no active generator or turbine power!');
      }
      str.isOpen = !str.isOpen;
      return commit(`${str.isOpen ? 'Opened' : 'Closed'} ${sDef.name}`, str.structureId);
    }

    case 'ADD_STATION_FUEL': {
      const str = state.entities.structures[intent.structureId];
      if (!str || str.hp <= 0) return reject('Station not found');
      const sDef = STRUCTURE_MAP.get(str.definitionId);
      if (!sDef?.usesFuel) return reject('Station does not burn fuel');
      if (Math.hypot(str.tileX * 16 + 8 - player.x, str.tileY * 16 + 8 - player.y) > 72) {
        return reject('Move closer to load fuel');
      }

      const fuelInst = state.inventory.items[intent.fuelInstanceId];
      if (!fuelInst || fuelInst.containerId !== 'player_bag') return reject('Fuel item not in inventory');
      const fDef = ITEM_MAP.get(fuelInst.definitionId);
      if (!fDef?.fuelSeconds) return reject(`${fDef?.name ?? 'Item'} is not valid fuel`);

      const qty = Math.max(1, Math.min(fuelInst.count, intent.count ?? 1));
      fuelInst.count -= qty;
      if (fuelInst.count <= 0) delete state.inventory.items[fuelInst.instanceId];

      str.fuelRemainingSec += fDef.fuelSeconds * qty;
      // Resume any fuel-paused jobs on this station
      for (const job of Object.values(state.jobs)) {
        if (job.stationStructureId === str.structureId && job.status === 'paused_no_fuel') {
          job.status = 'active';
        }
      }
      pushMessage(state, `Added ${qty}x ${fDef.name} (+${fDef.fuelSeconds * qty}s fuel) to ${sDef.name}.`);
      return commit(`Loaded ${qty} ${fDef.id} into ${str.structureId}`, str.structureId);
    }

    case 'QUEUE_RECIPE_JOB': {
      const rcp = RECIPE_MAP.get(intent.recipeId);
      if (!rcp) return reject('Unknown recipe');
      if (!state.research.learnedRecipeIds.includes(rcp.id)) {
        return reject('Recipe has not been learned in this run yet');
      }

      if (rcp.station !== 'hand') {
        const station = state.entities.structures[intent.stationStructureId];
        if (!station || station.hp <= 0) return reject(`Requires nearby ${rcp.station}`);
        const stDef = STRUCTURE_MAP.get(station.definitionId);
        if (stDef?.stationClass !== rcp.station) {
          return reject(`Recipe requires ${rcp.station}, not ${station.definitionId}`);
        }
        if (Math.hypot(station.tileX * 16 + 8 - player.x, station.tileY * 16 + 8 - player.y) > 76) {
          return reject(`Move closer to ${stDef.name}`);
        }
        if (rcp.powerRequired && !isStructurePowered(state, station)) {
          return reject(`${stDef.name} requires active electrical power for ${rcp.name}`);
        }
      }

      for (const inp of rcp.inputs) {
        if (countItemInContainer(state, 'player_bag', inp.itemId) < inp.count) {
          return reject(`Missing ${inp.count}x ${ITEM_MAP.get(inp.itemId)?.name ?? inp.itemId}`);
        }
      }
      for (const inp of rcp.inputs) {
        debitItemFromContainer(state, 'player_bag', inp.itemId, inp.count);
      }

      // Immediate completion for quick 2-4s hand crafts; scheduled real-time job for stations!
      if (rcp.station === 'hand') {
        const rcptId = rng.nextId('rcpt_craft', state.run.runId, state.revision);
        for (const out of rcp.outputs) {
          const g = grantItemToContainer(state, rng, 'player_bag', out.itemId, out.count, `craft:${rcp.id}`, rcptId);
          if (g.addedCount < out.count) {
            return reject('Inventory full — free a slot before crafting');
          }
        }
        pushMessage(state, `Crafted ${rcp.name}.`);
        return commit(`Hand-crafted ${rcp.name}`, `recipe:${rcp.id}`);
      }

      const jobId = rng.nextId('job', state.run.runId, state.revision);
      const station = state.entities.structures[intent.stationStructureId];
      const stDef = STRUCTURE_MAP.get(station.definitionId)!;
      const initialStatus = stDef.usesFuel && station.fuelRemainingSec <= 0 ? 'paused_no_fuel' : 'active';

      state.jobs[jobId] = {
        jobId,
        stationStructureId: station.structureId,
        recipeId: rcp.id,
        status: initialStatus,
        progressSec: 0,
        requiredSec: rcp.workSeconds,
        startedAtUtcSec: state.clock.lastSimulatedUtcSec,
        lastUpdatedUtcSec: state.clock.lastSimulatedUtcSec,
      };
      pushMessage(
        state,
        initialStatus === 'paused_no_fuel'
          ? `Queued ${rcp.name} on ${stDef.name} (Add fuel to start!)`
          : `Started ${rcp.name} (${rcp.workSeconds}s) on ${stDef.name}.`
      );
      return commit(`Queued job ${jobId} (${rcp.id})`, station.structureId);
    }

    case 'CANCEL_JOB': {
      const job = state.jobs[intent.jobId];
      if (!job) return reject('Job not found');
      const rcp = RECIPE_MAP.get(job.recipeId);
      const refundRatio = job.progressSec < job.requiredSec * 0.5 ? 1 : 0.5;
      const rcptId = rng.nextId('rcpt_cjob', state.run.runId, state.revision);
      if (rcp) {
        for (const inp of rcp.inputs) {
          const qty = Math.floor(inp.count * refundRatio);
          if (qty > 0) {
            grantItemToContainer(state, rng, 'player_bag', inp.itemId, qty, `cancel:${job.jobId}`, rcptId);
          }
        }
      }
      delete state.jobs[job.jobId];
      return commit(`Canceled job ${intent.jobId}`, job.stationStructureId);
    }

    case 'CLAIM_STATION_OUTPUT': {
      const station = state.entities.structures[intent.structureId];
      if (!station || station.hp <= 0) return reject('Station not found');
      if (Math.hypot(station.tileX * 16 + 8 - player.x, station.tileY * 16 + 8 - player.y) > 76) {
        return reject('Must physically stand at station to collect output');
      }
      const outCid = `station_out:${station.structureId}`;
      const outputs = intent.instanceId
        ? getItemsInContainer(state, outCid).filter((i) => i.instanceId === intent.instanceId)
        : getItemsInContainer(state, outCid);
      if (outputs.length === 0) return reject('No completed output waiting at this station');

      let claimed = 0;
      for (const item of outputs) {
        const res = transferInstanceToContainer(state, item.instanceId, 'player_bag');
        if (res.ok) claimed++;
      }
      if (claimed === 0) return reject('Player inventory is full');
      return commit(`Claimed ${claimed} output stack(s) from ${station.definitionId}`, station.structureId);
    }

    case 'RESEARCH_ACTION': {
      if (intent.mode === 'blueprint' && intent.specimenInstanceId) {
        return dispatchIntent(prevState, {
          kind: 'USE_ITEM',
          intentId: intent.intentId,
          instanceId: intent.specimenInstanceId,
        });
      }

      const desk = state.entities.structures[intent.stationStructureId];
      if (!desk || desk.hp <= 0 || desk.definitionId !== 'research_desk') {
        return reject('Requires an intact nearby Research Desk');
      }
      if (Math.hypot(desk.tileX * 16 + 8 - player.x, desk.tileY * 16 + 8 - player.y) > 76) {
        return reject('Move closer to Research Desk');
      }

      if (intent.mode === 'random_spares') {
        const unknownPool = RECIPES.filter(
          (r) => r.researchPool && !state.research.learnedRecipeIds.includes(r.id)
        );
        if (unknownPool.length === 0) {
          return reject('All Spares-discoverable recipes are already known in this run');
        }
        const cost = BALANCE.economyAndTerritory.randomSparesResearchCost.value;
        if (!debitItemFromContainer(state, 'player_bag', 'spares_token', cost)) {
          return reject(`Requires ${cost} Mechanical Spares`);
        }
        const picked = unknownPool[rng.nextInt(0, unknownPool.length - 1)];
        state.research.learnedRecipeIds.push(picked.id);
        pushMessage(state, `Discovered recipe: ${picked.name} (-${cost} Spares)!`);
        return commit(`Random Spares research learned ${picked.id}`, desk.structureId, {
          learnedRecipeId: picked.id,
        });
      }

      if (intent.mode === 'directed_spares') {
        if (!intent.targetRecipeId) return reject('Choose a target recipe for directed study');
        const rcp = RECIPE_MAP.get(intent.targetRecipeId);
        if (!rcp || !rcp.researchPool) return reject('Recipe is not eligible for Spares study');
        if (state.research.learnedRecipeIds.includes(rcp.id)) {
          return reject('Recipe is already learned in this run');
        }
        const cost = BALANCE.economyAndTerritory.directedSparesResearchCost.value;
        if (!debitItemFromContainer(state, 'player_bag', 'spares_token', cost)) {
          return reject(`Directed study requires ${cost} Mechanical Spares`);
        }
        state.research.learnedRecipeIds.push(rcp.id);
        pushMessage(state, `Mastered directed recipe: ${rcp.name} (-${cost} Spares)!`);
        return commit(`Directed Spares research learned ${rcp.id}`, desk.structureId, {
          learnedRecipeId: rcp.id,
        });
      }

      if (intent.mode === 'specimen_study') {
        if (!intent.specimenInstanceId) return reject('Select an eligible specimen or Core to analyze');
        const specInst = state.inventory.items[intent.specimenInstanceId];
        if (!specInst || specInst.containerId !== 'player_bag') {
          return reject('Specimen must be in your backpack inventory (unequip first)');
        }
        const def = ITEM_MAP.get(specInst.definitionId);
        if (!def || !def.studyEligible || !def.learnedRecipeId) {
          return reject(`${def?.name ?? 'Item'} is not eligible for specimen study`);
        }
        if (
          def.category === 'core' &&
          !BALANCE.economyAndTerritory.depletedCoreStudyEligible.value &&
          (specInst.charges ?? 0) <= 0
        ) {
          return reject('Depleted 0-charge Core cannot be analyzed under prototype policy (PROPOSED_MECHANISM)');
        }
        if (state.research.learnedRecipeIds.includes(def.learnedRecipeId)) {
          return reject(`Recipe ${def.learnedRecipeId} is already learned — specimen preserved!`);
        }

        delete state.inventory.items[specInst.instanceId];
        state.research.learnedRecipeIds.push(def.learnedRecipeId);
        const rcpName = RECIPE_MAP.get(def.learnedRecipeId)?.name ?? def.learnedRecipeId;
        pushMessage(state, `Analyzed ${def.name} specimen -> unlocked ${rcpName}!`);
        return commit(`Destructive specimen study of ${specInst.instanceId} learned ${def.learnedRecipeId}`, desk.structureId);
      }

      return reject('Unsupported research mode');
    }

    case 'DEPLOY_CART': {
      const kit = state.inventory.items[intent.cartKitInstanceId];
      if (!kit || kit.containerId !== 'player_bag' || kit.definitionId !== 'hand_cart_kit') {
        return reject('Folded Cargo Hand-Cart must be in player inventory');
      }
      if (!isTileWalkable(state, topology, intent.tileX, intent.tileY, { forCart: true })) {
        return reject('Hand-Cart requires open walkable road or level ground');
      }
      if (Math.hypot(intent.tileX * 16 + 8 - player.x, intent.tileY * 16 + 8 - player.y) > 64) {
        return reject('Deploy tile is out of reach');
      }

      const cartId = rng.nextId('cart', state.run.runId, state.revision);
      state.entities.carts[cartId] = {
        cartId,
        x: intent.tileX * 16 + 8,
        y: intent.tileY * 16 + 8,
        hp: 200,
        maxHp: 200,
        durability: kit.durability ?? 200,
        maxDurability: 200,
        hitchedByPlayer: true,
        deployedFromInstanceId: kit.instanceId,
      };
      delete state.inventory.items[kit.instanceId];
      pushMessage(state, 'Deployed & hitched 12-slot Cargo Hand-Cart.');
      return commit(`Deployed Hand-Cart ${cartId}`, cartId);
    }

    case 'TOGGLE_HITCH_CART': {
      const cart = state.entities.carts[intent.cartId];
      if (!cart) return reject('Hand-Cart not found');
      if (Math.hypot(cart.x - player.x, cart.y - player.y) > 56) {
        return reject('Move closer to hitch/unhitch Hand-Cart');
      }
      if (!cart.hitchedByPlayer) {
        for (const other of Object.values(state.entities.carts)) {
          other.hitchedByPlayer = false;
        }
        cart.hitchedByPlayer = true;
      } else {
        cart.hitchedByPlayer = false;
      }
      return commit(`${cart.hitchedByPlayer ? 'Hitched' : 'Unhitched'} Hand-Cart ${cart.cartId}`, cart.cartId);
    }

    case 'PACK_CART': {
      const cart = state.entities.carts[intent.cartId];
      if (!cart) return reject('Hand-Cart not found');
      if (Math.hypot(cart.x - player.x, cart.y - player.y) > 56) return reject('Move closer to Hand-Cart');
      if (getItemsInContainer(state, `cart:${cart.cartId}`).length > 0) {
        return reject('Unload all cargo from Hand-Cart before folding it');
      }
      const rcptId = rng.nextId('rcpt_pack', state.run.runId, state.revision);
      const g = grantItemToContainer(
        state,
        rng,
        'player_bag',
        'hand_cart_kit',
        1,
        cart.cartId,
        rcptId,
        { durability: cart.durability }
      );
      if (g.addedCount <= 0) return reject('Inventory full — cannot pack Hand-Cart');
      delete state.entities.carts[cart.cartId];
      return commit(`Packed Hand-Cart ${cart.cartId}`, cart.cartId);
    }

    case 'RECOVER_DEATH_BAG': {
      const bag = state.entities.deathBags[intent.bagId];
      if (!bag) return reject('Death recovery bag not found');
      if (Math.hypot(bag.x - player.x, bag.y - player.y) > 60) {
        return reject('Must physically reach your Death Bag to recover items');
      }
      const bagCid = `death_bag:${bag.bagId}`;
      const items = getItemsInContainer(state, bagCid);
      let recovered = 0;
      for (const item of items) {
        const res = transferInstanceToContainer(state, item.instanceId, 'player_bag');
        if (res.ok) recovered++;
      }
      if (getItemsInContainer(state, bagCid).length === 0) {
        delete state.entities.deathBags[bag.bagId];
      }
      if (recovered === 0 && items.length > 0) {
        return reject('Inventory full — clear slots to recover Death Bag contents');
      }
      pushMessage(state, `Recovered ${recovered} item(s) from Death Bag.`);
      return commit(`Recovered ${recovered} items from ${bag.bagId}`, bag.bagId);
    }

    case 'UNLOCK_POI_GATE': {
      const poi = state.world.pois[intent.poiId];
      const poiDef = POI_MAP.get(intent.poiId);
      if (!poi || !poiDef || !poiDef.deepGate || !poi.gateTile) {
        return reject('POI has no locked gate');
      }
      if (poi.gateUnlocked) return reject('POI gate is already unlocked');
      if (Math.hypot(poi.gateTile.x * 16 + 8 - player.x, poi.gateTile.y * 16 + 8 - player.y) > 64) {
        return reject('Stand next to the POI gate to unlock it');
      }

      const reqTag = poiDef.deepGate.requiredUnlockTag;
      const cred = intent.credentialInstanceId
        ? state.inventory.items[intent.credentialInstanceId]
        : Object.values(state.inventory.items).find(
            (it) => it.containerId === 'player_bag' && ITEM_MAP.get(it.definitionId)?.unlockTag === reqTag
          );
      const credDef = cred ? ITEM_MAP.get(cred.definitionId) : null;
      if (!cred || cred.containerId !== 'player_bag' || credDef?.unlockTag !== reqTag) {
        return reject(`Locked: ${poiDef.deepGate.label}`);
      }

      if (cred.charges !== undefined) {
        cred.charges -= 1;
        if (cred.charges <= 0) delete state.inventory.items[cred.instanceId];
      } else {
        cred.count -= 1;
        if (cred.count <= 0) delete state.inventory.items[cred.instanceId];
      }

      poi.gateUnlocked = true;
      pushMessage(state, `Unlocked ${poi.name} deep gate using ${credDef.name}!`);
      return commit(`Unlocked ${poi.poiId} deep gate`, `poi:${poi.poiId}`);
    }

    case 'VENDOR_BUY': {
      const poi = state.world.pois[intent.poiId];
      if (!poi || !poi.vendorTile) return reject('No physical vendor at this location');
      if (Math.hypot(poi.vendorTile.x * 16 + 8 - player.x, poi.vendorTile.y * 16 + 8 - player.y) > 68) {
        return reject('Walk to the Wayfarer Trader caravan at Crossroads Market to trade');
      }

      const listing = poi.vendorStock.find((v) => v.itemId === intent.itemId);
      if (!listing || listing.remaining <= 0) return reject('Vendor is out of stock for that item');

      const useBagCash = Boolean(intent.payWithUnsecuredBagCash);
      if (useBagCash) {
        if (!listing.acceptsUnsecuredPhysicalCash) {
          return reject('This item requires secured Profile Ragnarok Cash');
        }
        if (countItemInContainer(state, 'player_bag', 'ragnarok_cash') < listing.priceCash) {
          return reject(`Requires ${listing.priceCash} physical Ragnarok Cash in backpack`);
        }
      } else {
        if (state.profile.securedCash < listing.priceCash) {
          // Automatically allow fallback to unsecured physical bag cash ONLY if policy permits (first Escrow Chest! C16)
          if (
            listing.acceptsUnsecuredPhysicalCash &&
            countItemInContainer(state, 'player_bag', 'ragnarok_cash') >= listing.priceCash
          ) {
            debitItemFromContainer(state, 'player_bag', 'ragnarok_cash', listing.priceCash);
          } else {
            return reject(`Insufficient secured Profile Cash (${listing.priceCash} required)`);
          }
        } else {
          state.profile.securedCash -= listing.priceCash;
        }
      }

      if (useBagCash) {
        debitItemFromContainer(state, 'player_bag', 'ragnarok_cash', listing.priceCash);
      }

      const rcptId = rng.nextId('rcpt_vnd', state.run.runId, state.revision);
      const granted = grantItemToContainer(
        state,
        rng,
        'player_bag',
        listing.itemId,
        1,
        `vendor:${poi.poiId}`,
        rcptId
      );
      if (granted.addedCount <= 0) {
        return reject('Backpack full — clear a slot before buying');
      }
      listing.remaining -= 1;
      const iName = ITEM_MAP.get(listing.itemId)?.name ?? listing.itemId;
      pushMessage(state, `Purchased run-local ${iName} for ${listing.priceCash} Ragnarok Cash.`);
      return commit(`Purchased ${listing.itemId} at ${poi.poiId}`, `vendor:${poi.poiId}`, {
        priceCash: listing.priceCash,
        remainingProfileCash: state.profile.securedCash,
      });
    }

    case 'DEPOSIT_ESCROW': {
      if (intent.amount <= 0 || !Number.isInteger(intent.amount)) {
        return reject('Deposit amount must be a positive whole number');
      }
      const token = intent.clientDepositToken ?? intentId;
      if (state.profile.depositedReceiptIds.includes(token)) {
        return reject('Deposit receipt already applied (idempotent duplicate blocked)');
      }

      const chest = state.entities.structures[intent.escrowStructureId];
      if (!chest || chest.hp <= 0 || chest.definitionId !== 'escrow_chest') {
        return reject('Must interact with a physically deployed Escrow Chest (Rương ký gửi)');
      }
      if (chest.ownerId !== player.actorId) {
        return reject('You do not own this Escrow Chest');
      }
      if (!isTileOwnedHomestead(state, chest.tileX, chest.tileY)) {
        return reject('Escrow Chest is outside active Homestead territory claim');
      }
      if (Math.hypot(chest.tileX * 16 + 8 - player.x, chest.tileY * 16 + 8 - player.y) > 64) {
        return reject('Stand next to your placed Escrow Chest to deposit physical cash');
      }

      const heldCash = countItemInContainer(state, 'player_bag', 'ragnarok_cash');
      if (heldCash < intent.amount) {
        return reject(`Only carrying ${heldCash} physical Ragnarok Cash in backpack`);
      }

      // Atomic transfer: physical custody debit -> profile secured wallet credit -> immutable receipt! (C17)
      debitItemFromContainer(state, 'player_bag', 'ragnarok_cash', intent.amount);
      state.profile.securedCash += intent.amount;
      state.run.cashSecuredThisRun += intent.amount;
      state.profile.depositedReceiptIds.push(token);

      awardUniqueScore(
        state,
        'first_escrow_deposit',
        'Secured Ragnarok Cash via Homestead Escrow Chest',
        BALANCE.scoring.firstEscrowSecuredScore.value,
        token
      );

      pushVfx(state, {
        kind: 'deposit',
        x: chest.tileX * 16 + 8,
        y: chest.tileY * 16,
        text: `+${intent.amount} SECURED`,
        color: '#34d399',
        durationMs: 900,
      });
      pushMessage(
        state,
        `Secured +${intent.amount} Ragnarok Cash into Profile Wallet (Total Secured: ${state.profile.securedCash}).`
      );
      return commit(`Escrow deposited ${intent.amount} cash`, chest.structureId, {
        deposited: intent.amount,
        profileSecuredCash: state.profile.securedCash,
      });
    }

    case 'EVACUATE_RUN': {
      const poi = state.world.pois[intent.poiId];
      if (!poi || !poi.evacTile) return reject('No Evacuation Beacon at this location');
      if (Math.hypot(poi.evacTile.x * 16 + 8 - player.x, poi.evacTile.y * 16 + 8 - player.y) > 68) {
        return reject('Physically board the Evacuation Pier Beacon at Sunken Harbor to evacuate');
      }
      const finRcpt = finalizeRunOnce(state, rng, 'evacuated', intentId);
      if (!finRcpt) return reject('Run already finalized');
      state.rngStepCount = rng.stepCount;
      return { accepted: true, receipt: finRcpt, state };
    }

    case 'ABANDON_RUN': {
      const finRcpt = finalizeRunOnce(state, rng, 'abandoned', intentId);
      if (!finRcpt) return reject('Run already finalized');
      state.rngStepCount = rng.stepCount;
      return { accepted: true, receipt: finRcpt, state };
    }
  }
}
