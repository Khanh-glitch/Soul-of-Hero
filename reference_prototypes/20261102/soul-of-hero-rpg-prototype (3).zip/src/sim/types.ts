import type { ApprovalStatus, TargetMaterial } from '../data/catalogs';

export type BiomeId =
  | 'deep_sea'
  | 'shallow_water'
  | 'coast'
  | 'plains'
  | 'forest'
  | 'wetland'
  | 'hills'
  | 'mountain'
  | 'cold'
  | 'hot'
  | 'radiation'
  | 'road'
  | 'poi_floor';

export type WeatherKind = 'clear' | 'overcast' | 'rain' | 'storm' | 'ash_wind';

export type AdventurerGender = 'male' | 'female';

export type RunEndReason =
  | 'evacuated'
  | 'six_stone_convergence'
  | 'abandoned'
  | 'expired_336h';

export interface ItemInstance {
  instanceId: string;
  definitionId: string;
  runId: string;
  count: number;
  durability?: number;
  maxDurability?: number;
  charges?: number;
  maxCharges?: number;
  quality: number;
  containerId: string; // e.g. 'player_bag', 'player_equip:main_hand', 'structure:str_1', 'station_out:str_2', 'cart:cart_1', 'death_bag:bag_1'
  slotIndex: number;
  provenanceSourceId: string;
  provenanceReceiptId: string;
}

export interface FootprintTrace {
  id: string;
  x: number;
  y: number;
  tileX: number;
  tileY: number;
  createdAtUtcSec: number;
  expiresAtUtcSec: number;
  surfaceRetention: number;
  strength: number;
}

export interface TerrainEffect {
  effectId: string;
  sourceInstanceId: string;
  sourceEventId: string;
  tileX: number;
  tileY: number;
  materialBefore: BiomeId;
  type: 'burning' | 'scorched' | 'frozen_ice' | 'cracked_rock';
  intensity: number;
  startUtcSec: number;
  endUtcSec: number;
  spreadDepth: number;
  lastProcessedUtcSec: number;
}

export interface SourceNodeState {
  sourceId: string;
  definitionId: string;
  tileX: number;
  tileY: number;
  stock: number;
  maxStock: number;
  currentUnitHp: number;
  depletedAtUtcSec: number | null;
  poiId?: string;
  isDeepInterior?: boolean;
  fixedCashYield?: number;
}

export interface PlacedStructureState {
  structureId: string;
  definitionId: string;
  tileX: number;
  tileY: number;
  hp: number;
  maxHp: number;
  ownerId: string;
  isOpen?: boolean; // for doors
  fuelRemainingSec: number;
  deployedFromInstanceId?: string;
  createdAtUtcSec: number;
}

export interface StationJobState {
  jobId: string;
  stationStructureId: string; // 'hand' or structureId
  recipeId: string;
  status: 'active' | 'paused_no_fuel' | 'paused_no_power' | 'paused_storm' | 'completed_unclaimed' | 'cancelled';
  progressSec: number;
  requiredSec: number;
  startedAtUtcSec: number;
  lastUpdatedUtcSec: number;
}

export interface HandCartEntity {
  cartId: string;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  durability: number;
  maxDurability: number;
  hitchedByPlayer: boolean;
  deployedFromInstanceId: string;
}

export interface DeathBagEntity {
  bagId: string;
  runId: string;
  x: number;
  y: number;
  createdAtUtcSec: number;
  deathCause: string;
}

export interface PoiRuntimeState {
  poiId: string;
  name: string;
  centerX: number;
  centerY: number;
  bounds: { x: number; y: number; w: number; h: number };
  deepRoomBounds?: { x: number; y: number; w: number; h: number };
  gateTile?: { x: number; y: number };
  emergencyExitTile?: { x: number; y: number };
  gateUnlocked: boolean;
  deepClearedOnce: boolean;
  vendorTile?: { x: number; y: number };
  evacTile?: { x: number; y: number };
  vendorStock: Array<{
    itemId: string;
    priceCash: number;
    remaining: number;
    acceptsUnsecuredPhysicalCash: boolean;
    policyStatus: ApprovalStatus;
  }>;
}

export interface EnemyActorState {
  actorId: string;
  definitionId: string;
  x: number;
  y: number;
  homeX: number;
  homeY: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  respawnAtUtcSec: number | null;
  aiState: 'patrol' | 'chase_sight' | 'follow_trail' | 'return_habitat';
  targetPos: { x: number; y: number } | null;
  trackingFootprintId: string | null;
  visitedFootprintIds: string[];
  lostTimerSec: number;
  attackCooldownRemainingMs: number;
  chilledUntilUtcSec: number;
  facing: 'up' | 'down' | 'left' | 'right';
}

export interface ElderBossActorState {
  bossId: string;
  definitionId: string;
  x: number;
  y: number;
  arenaX: number;
  arenaY: number;
  hp: number;
  maxHp: number;
  form: 'latent' | 'awakened';
  defeated: boolean;
  stoneGranted: boolean;
  telegraph: {
    active: boolean;
    targetX: number;
    targetY: number;
    radiusPx: number;
    startedAtMs: number;
    commitAtMs: number;
  } | null;
  cooldownRemainingMs: number;
  facing: 'up' | 'down' | 'left' | 'right';
}

export interface ActiveCoreCastState {
  castId: string;
  coreInstanceId: string;
  skillId: string;
  targetX: number;
  targetY: number;
  startedAtSimMs: number;
  commitAtSimMs: number;
  endAtSimMs: number;
  committed: boolean;
}

export interface PlayerActorState {
  actorId: string;
  gender: AdventurerGender;
  x: number;
  y: number;
  facing: 'up' | 'down' | 'left' | 'right';
  hp: number;
  maxHp: number;
  hunger: number;
  maxHunger: number;
  thirst: number;
  maxThirst: number;
  stamina: number;
  maxStamina: number;
  temperatureC: number;
  radiationDose: number;
  selectedQuickbarIndex: number; // 0..7
  attackCooldownMs: number;
  lastSwingAtSimMs: number;
  lastSwingAngleRad: number;
  activeCast: ActiveCoreCastState | null;
  distanceSinceLastFootprintPx: number;
  spawnRegionId: string;
  deathsCount: number;
}

export interface ScoreEventRecord {
  scoreKey: string; // unique per run, e.g. 'poi_deep:rust_refinery' or 'elder:elder_ignis'
  label: string;
  points: number;
  utcSec: number;
  receiptId: string;
}

export interface RunHistorySummary {
  runId: string;
  gender: AdventurerGender;
  spawnRegionName: string;
  startedAtUtcSec: number;
  endedAtUtcSec: number;
  elapsedRealSeconds: number;
  endReason: RunEndReason;
  cashSecuredDuringRun: number;
  unsecuredCashLostOnEnd: number;
  elderStonesCollected: string[];
  localUnverifiedScore: number;
  verificationLabel: 'LOCAL_UNVERIFIED';
  qaClockUsed: boolean;
}

export interface ProfileState {
  profileId: string;
  securedCash: number;
  achievements: string[];
  runHistory: RunHistorySummary[];
  depositedReceiptIds: string[]; // idempotency across crash/reload
}

export interface EventReceipt {
  receiptId: string;
  intentId: string;
  actionKind: string;
  runId: string;
  actorId: string;
  utcSec: number;
  revision: number;
  sourceId?: string;
  summary: string;
  details?: Record<string, unknown>;
}

export interface VisualFeedbackEvent {
  id: string;
  kind: 'hit' | 'harvest' | 'cast' | 'pickup' | 'fire' | 'frost' | 'seismic' | 'storm' | 'deposit' | 'warning';
  x: number;
  y: number;
  radiusPx?: number;
  text?: string;
  color: string;
  createdAtSimMs: number;
  durationMs: number;
}

export interface SpawnRegionInfo {
  id: string;
  name: string;
  tileX: number;
  tileY: number;
  description: string;
}

export interface WorldTopology {
  seed: number;
  width: number;
  height: number;
  biomes: BiomeId[]; // width * height flat array
  elevation: number[]; // width * height 0..1
  spawnRegions: SpawnRegionInfo[];
}

export interface GameState {
  schemaVersion: number;
  revision: number;
  rngSeed: number;
  rngStepCount: number;
  profile: ProfileState;
  run: {
    runId: string;
    active: boolean;
    endedReason: RunEndReason | null;
    startedAtUtcSec: number;
    qaClockOffsetSec: number;
    qaAcceleratedUsed: boolean;
    discoveredChunks: number[]; // 16x16 chunk indices (12x12 = 144 chunks)
    scoreEvents: ScoreEventRecord[];
    elderStonesCollected: string[];
    cashSecuredThisRun: number;
    contextualNotesSeen: string[];
  };
  clock: {
    lastSimulatedUtcSec: number;
    elapsedRunSec: number;
    simTimeMs: number;
    phase: 'ordinary' | 'ragnarok_final72' | 'ragnarok_day14_elders' | 'expired';
    daylightFactor: number; // 0.2 (night) .. 1.0 (noon)
    fictionalDayNumber: number;
    weather: WeatherKind;
    nextWeatherShiftUtcSec: number;
  };
  world: {
    seed: number;
    width: number;
    height: number;
    footprints: FootprintTrace[];
    terrainEffects: TerrainEffect[];
    pois: Record<string, PoiRuntimeState>;
  };
  actors: {
    player: PlayerActorState;
    enemies: EnemyActorState[];
    elders: ElderBossActorState[];
  };
  sourceStocks: Record<string, SourceNodeState>;
  entities: {
    structures: Record<string, PlacedStructureState>;
    carts: Record<string, HandCartEntity>;
    deathBags: Record<string, DeathBagEntity>;
  };
  inventory: {
    items: Record<string, ItemInstance>; // single authoritative item custody ledger!
  };
  research: {
    learnedRecipeIds: string[];
  };
  jobs: Record<string, StationJobState>;
  history: {
    recentMessages: string[];
  };
  eventReceipts: EventReceipt[];
  vfxQueue: VisualFeedbackEvent[];
}

export type GameIntent =
  | { kind: 'START_NEW_RUN'; intentId?: string; gender: AdventurerGender; spawnRegionIndex?: number; nowUtcSec: number }
  | {
      kind: 'STEP_SIMULATION';
      intentId?: string;
      dtSec: number;
      nowUtcSec: number;
      moveDx: number;
      moveDy: number;
      sprint: boolean;
      aimWorldX?: number;
      aimWorldY?: number;
    }
  | { kind: 'OFFLINE_CATCHUP'; intentId?: string; nowUtcSec: number }
  | { kind: 'SELECT_QUICKBAR'; intentId?: string; slotIndex: number }
  | { kind: 'ACT_ON_TARGET'; intentId?: string; targetWorldX: number; targetWorldY: number; itemInstanceId?: string }
  | { kind: 'START_CORE_CAST'; intentId?: string; coreInstanceId: string; targetWorldX: number; targetWorldY: number }
  | { kind: 'CANCEL_CORE_CAST'; intentId?: string }
  | { kind: 'USE_ITEM'; intentId?: string; instanceId: string }
  | { kind: 'EQUIP_ITEM'; intentId?: string; instanceId: string }
  | { kind: 'UNEQUIP_ITEM'; intentId?: string; equipSlot: 'main_hand' | 'body' | 'accessory' }
  | { kind: 'TRANSFER_ITEM'; intentId?: string; instanceId: string; toContainerId: string; toSlotIndex?: number }
  | { kind: 'SPLIT_STACK'; intentId?: string; instanceId: string; splitCount: number }
  | { kind: 'BUILD_STRUCTURE'; intentId?: string; structureDefId: string; tileX: number; tileY: number; deployInstanceId?: string }
  | { kind: 'RECLAIM_STRUCTURE'; intentId?: string; structureId: string }
  | { kind: 'REPAIR_STRUCTURE'; intentId?: string; structureId: string }
  | { kind: 'TOGGLE_DOOR'; intentId?: string; structureId: string }
  | { kind: 'ADD_STATION_FUEL'; intentId?: string; structureId: string; fuelInstanceId: string; count?: number }
  | { kind: 'QUEUE_RECIPE_JOB'; intentId?: string; stationStructureId: string; recipeId: string }
  | { kind: 'CANCEL_JOB'; intentId?: string; jobId: string }
  | { kind: 'CLAIM_STATION_OUTPUT'; intentId?: string; structureId: string; instanceId?: string }
  | {
      kind: 'RESEARCH_ACTION';
      intentId?: string;
      stationStructureId: string;
      mode: 'random_spares' | 'directed_spares' | 'specimen_study' | 'blueprint';
      targetRecipeId?: string;
      specimenInstanceId?: string;
    }
  | { kind: 'DEPLOY_CART'; intentId?: string; cartKitInstanceId: string; tileX: number; tileY: number }
  | { kind: 'TOGGLE_HITCH_CART'; intentId?: string; cartId: string }
  | { kind: 'PACK_CART'; intentId?: string; cartId: string }
  | { kind: 'RECOVER_DEATH_BAG'; intentId?: string; bagId: string }
  | { kind: 'UNLOCK_POI_GATE'; intentId?: string; poiId: string; credentialInstanceId?: string }
  | { kind: 'VENDOR_BUY'; intentId?: string; poiId: string; itemId: string; payWithUnsecuredBagCash?: boolean }
  | { kind: 'DEPOSIT_ESCROW'; intentId?: string; escrowStructureId: string; amount: number; clientDepositToken?: string }
  | { kind: 'EVACUATE_RUN'; intentId?: string; poiId: string }
  | { kind: 'ABANDON_RUN'; intentId?: string }
  | { kind: 'QA_ADVANCE_CLOCK'; intentId?: string; advanceSeconds: number };

export interface DispatchResult {
  accepted: boolean;
  reason?: string;
  receipt?: EventReceipt;
  state: GameState;
}

export type MaterialYieldLookup = Record<TargetMaterial, number>;
