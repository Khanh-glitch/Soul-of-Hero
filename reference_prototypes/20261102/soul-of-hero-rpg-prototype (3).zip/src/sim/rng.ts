import { xoroshiro128plus } from 'pure-rand/generator/xoroshiro128plus';
import { uniformInt } from 'pure-rand/distribution/uniformInt';
import type { RandomGenerator } from 'pure-rand/types/RandomGenerator';

/**
 * Deterministic PRNG adapter wrapping `pure-rand` v8.4.2 (MIT, dubzzz/pure-rand).
 * Advances an explicit serializable step counter so simulation transitions and
 * offline catch-up are 100% reproducible without touching Math.random().
 */
export class DeterministicRng {
  private gen: RandomGenerator;
  public readonly seed: number;
  public stepCount: number;

  constructor(seed: number, stepCount = 0) {
    this.seed = seed | 0;
    this.stepCount = stepCount;
    this.gen = xoroshiro128plus((this.seed ^ Math.imul(stepCount + 1, 0x9e3779b1)) | 0);
  }

  public nextInt(minInclusive: number, maxInclusive: number): number {
    if (maxInclusive <= minInclusive) return minInclusive;
    this.stepCount += 1;
    return uniformInt(this.gen, minInclusive, maxInclusive);
  }

  public nextFloat(): number {
    this.stepCount += 1;
    return uniformInt(this.gen, 0, 1_000_000) / 1_000_000;
  }

  public nextId(prefix: string, runId: string, revision: number): string {
    const token = this.nextInt(100000, 999999);
    return `${prefix}_${runId}_r${revision}_s${this.stepCount}_${token}`;
  }
}

export function createSeededNoiseRng(seed: number): () => number {
  const gen = xoroshiro128plus(seed | 0);
  return () => uniformInt(gen, 0, 1_000_000) / 1_000_000;
}
