import React, { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import {
  BookOpen,
  Coins,
  Heart,
  Home,
  Map as MapIcon,
  Shield,
  Sliders,
  Volume2,
  VolumeX,
  Zap,
} from 'pixelarticons/react';
import { sfx } from './audio/sfx';
import { SidePanels, type ActiveDrawer } from './components/SidePanels';
import { BALANCE, ITEM_MAP, SOURCE_MAP, STRUCTURE_MAP } from './data/catalogs';
import { evaluateBuildGhostValidity, renderWorldCanvas } from './render/worldRenderer';
import { countItemInContainer, getItemsInContainer, getPlayerCarryWeightKg } from './sim/custody';
import type { AdventurerGender } from './sim/types';
import { getOrCreateTopology } from './sim/worldGen';
import { gameStore } from './store/gameStore';

const LOGICAL_W = BALANCE.world.logicalCanvasWidth.value; // 640
const LOGICAL_H = BALANCE.world.logicalCanvasHeight.value; // 360

export function App() {
  const state = useSyncExternalStore(
    (cb) => gameStore.subscribe(cb),
    () => gameStore.getSnapshot()
  );
  const onTitle = useSyncExternalStore(
    (cb) => gameStore.subscribe(cb),
    () => gameStore.isOnTitleScreen()
  );
  const feedbackBanner = useSyncExternalStore(
    (cb) => gameStore.subscribe(cb),
    () => gameStore.getFeedbackBanner()
  );

  const [selectedGender, setSelectedGender] = useState<AdventurerGender>('female');
  const [selectedSpawnIdx, setSelectedSpawnIdx] = useState<number>(0);
  const [activeDrawer, setActiveDrawer] = useState<ActiveDrawer>(null);
  const [selectedBuildDefId, setSelectedBuildDefId] = useState<string | null>(null);
  const [muted, setMuted] = useState<boolean>(sfx.muted);
  const [integerScale, setIntegerScale] = useState<number>(1);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pressedKeysRef = useRef<Set<string>>(new Set());
  const mouseWorldRef = useRef<{ x: number; y: number }>({
    x: state.actors.player.x,
    y: state.actors.player.y + 16,
  });

  const topology = useMemo(() => getOrCreateTopology(state.world.seed), [state.world.seed]);

  // Initialize IndexedDB snapshot + settle offline timeline once on mount
  useEffect(() => {
    void gameStore.initializeFromStorage();
  }, []);

  // Auto-clear transient rejection banners after 3.5s
  useEffect(() => {
    if (!feedbackBanner) return;
    const t = window.setTimeout(() => gameStore.clearFeedbackBanner(), 3500);
    return () => window.clearTimeout(t);
  }, [feedbackBanner]);

  // Responsive integer scaling (1x at 640x360, 2x at 1280x720, 3x at 1920x1080)
  useEffect(() => {
    const updateScale = () => {
      const sx = Math.floor(window.innerWidth / LOGICAL_W);
      const sy = Math.floor(window.innerHeight / LOGICAL_H);
      setIntegerScale(Math.max(1, Math.min(sx, sy)));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  // Contextual [E] physical interaction resolver
  const handlePhysicalInteract = () => {
    const cur = gameStore.getSnapshot();
    if (!cur.run.active) return;
    const p = cur.actors.player;

    // 1. Death bag within reach
    const bag = Object.values(cur.entities.deathBags).find(
      (b) => Math.hypot(b.x - p.x, b.y - p.y) <= 60
    );
    if (bag) {
      gameStore.submitIntent({ kind: 'RECOVER_DEATH_BAG', bagId: bag.bagId });
      return;
    }

    // 2. Station with unclaimed output ready
    const readyStation = Object.values(cur.entities.structures).find(
      (s) =>
        s.hp > 0 &&
        Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 68 &&
        getItemsInContainer(cur, `station_out:${s.structureId}`).length > 0
    );
    if (readyStation) {
      gameStore.submitIntent({ kind: 'CLAIM_STATION_OUTPUT', structureId: readyStation.structureId });
      return;
    }

    // 3. Adjacent door toggle
    const door = Object.values(cur.entities.structures).find(
      (s) =>
        s.hp > 0 &&
        STRUCTURE_MAP.get(s.definitionId)?.isDoor &&
        Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 52
    );
    if (door) {
      gameStore.submitIntent({ kind: 'TOGGLE_DOOR', structureId: door.structureId });
      return;
    }

    // 4. Nearby Escrow Chest, Vendor, Evacuation Beacon, Locked Gate, Cart, or Storage Chest -> open Inventory/Interaction drawer
    const hasSpecialInteract =
      Object.values(cur.entities.structures).some(
        (s) =>
          s.hp > 0 &&
          (s.definitionId === 'escrow_chest' || (STRUCTURE_MAP.get(s.definitionId)?.containerSlots ?? 0) > 0) &&
          Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 68
      ) ||
      Object.values(cur.entities.carts).some((c) => Math.hypot(c.x - p.x, c.y - p.y) <= 64) ||
      Object.values(cur.world.pois).some(
        (poi) =>
          (poi.vendorTile && Math.hypot(poi.vendorTile.x * 16 + 8 - p.x, poi.vendorTile.y * 16 + 8 - p.y) <= 68) ||
          (poi.evacTile && Math.hypot(poi.evacTile.x * 16 + 8 - p.x, poi.evacTile.y * 16 + 8 - p.y) <= 68) ||
          (!poi.gateUnlocked &&
            poi.gateTile &&
            Math.hypot(poi.gateTile.x * 16 + 8 - p.x, poi.gateTile.y * 16 + 8 - p.y) <= 68)
      );

    if (hasSpecialInteract) {
      setActiveDrawer('inventory');
      return;
    }

    // 5. Nearby Research Desk -> open Research drawer
    const desk = Object.values(cur.entities.structures).find(
      (s) =>
        s.hp > 0 &&
        s.definitionId === 'research_desk' &&
        Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 68
    );
    if (desk) {
      setActiveDrawer('research');
      return;
    }

    // 6. Nearby Crafting Station -> open Craft drawer
    const bench = Object.values(cur.entities.structures).find(
      (s) =>
        s.hp > 0 &&
        Boolean(STRUCTURE_MAP.get(s.definitionId)?.stationClass) &&
        Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 68
    );
    if (bench) {
      setActiveDrawer('craft');
      return;
    }

    // 7. Nearest harvestable physical source node within reach
    const nearSrc = Object.values(cur.sourceStocks)
      .filter((s) => s.stock > 0 && Math.hypot(s.tileX * 16 + 8 - p.x, s.tileY * 16 + 8 - p.y) <= 44)
      .sort(
        (a, b) =>
          Math.hypot(a.tileX * 16 + 8 - p.x, a.tileY * 16 + 8 - p.y) -
          Math.hypot(b.tileX * 16 + 8 - p.x, b.tileY * 16 + 8 - p.y)
      )[0];
    if (nearSrc) {
      gameStore.submitIntent({
        kind: 'ACT_ON_TARGET',
        targetWorldX: nearSrc.tileX * 16 + 8,
        targetWorldY: nearSrc.tileY * 16 + 8,
      });
    }
  };

  // Keyboard listener (WASD/Arrows + 1-8 Quickbar + remappable panel hotkeys)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      pressedKeysRef.current.add(e.code);

      if (gameStore.isOnTitleScreen()) return;
      const kb = gameStore.keyBindings;

      if (e.code >= 'Digit1' && e.code <= 'Digit8') {
        const idx = Number(e.code.slice(5)) - 1;
        gameStore.submitIntent({ kind: 'SELECT_QUICKBAR', slotIndex: idx });
        const cur = gameStore.getSnapshot();
        const qbItem = Object.values(cur.inventory.items).find(
          (i) => i.containerId === 'player_bag' && i.slotIndex === idx
        );
        if (qbItem) {
          const def = ITEM_MAP.get(qbItem.definitionId);
          if (def?.equipSlot) {
            gameStore.submitIntent({ kind: 'EQUIP_ITEM', instanceId: qbItem.instanceId });
          } else if (def?.capabilities.includes('USE')) {
            gameStore.submitIntent({ kind: 'USE_ITEM', instanceId: qbItem.instanceId });
          }
        }
        return;
      }

      if (e.code === 'KeyX') {
        gameStore.submitIntent({ kind: 'CANCEL_CORE_CAST' });
        setSelectedBuildDefId(null);
        return;
      }

      const toggleDrawer = (d: ActiveDrawer) => {
        setActiveDrawer((prev) => (prev === d ? null : d));
      };

      if (e.code === kb.interact) {
        e.preventDefault();
        handlePhysicalInteract();
      } else if (e.code === kb.inventory) {
        e.preventDefault();
        toggleDrawer('inventory');
      } else if (e.code === kb.craft) {
        e.preventDefault();
        toggleDrawer('craft');
      } else if (e.code === kb.build) {
        e.preventDefault();
        toggleDrawer('build');
      } else if (e.code === kb.research) {
        e.preventDefault();
        toggleDrawer('research');
      } else if (e.code === kb.map) {
        e.preventDefault();
        toggleDrawer('map');
      } else if (e.code === kb.journal) {
        e.preventDefault();
        toggleDrawer('journal');
      } else if (e.code === kb.skills) {
        e.preventDefault();
        toggleDrawer('skills');
      } else if (e.code === kb.menu) {
        e.preventDefault();
        if (selectedBuildDefId) {
          setSelectedBuildDefId(null);
        } else if (activeDrawer && activeDrawer !== 'menu') {
          setActiveDrawer(null);
        } else {
          toggleDrawer('menu');
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      pressedKeysRef.current.delete(e.code);
    };

    const onBlur = () => pressedKeysRef.current.clear();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [activeDrawer, selectedBuildDefId]);

  // Main RequestAnimationFrame Simulation & 640x360 Canvas Render Loop
  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();

    const frame = (now: number) => {
      const dtSec = Math.min(0.1, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      if (!gameStore.isOnTitleScreen() && gameStore.getSnapshot().run.active) {
        const keys = pressedKeysRef.current;
        let dx = 0;
        let dy = 0;
        if (keys.has('KeyW') || keys.has('ArrowUp')) dy -= 1;
        if (keys.has('KeyS') || keys.has('ArrowDown')) dy += 1;
        if (keys.has('KeyA') || keys.has('ArrowLeft')) dx -= 1;
        if (keys.has('KeyD') || keys.has('ArrowRight')) dx += 1;
        const sprint = keys.has('ShiftLeft') || keys.has('ShiftRight');

        gameStore.submitIntent(
          {
            kind: 'STEP_SIMULATION',
            dtSec,
            nowUtcSec: Math.floor(Date.now() / 1000),
            moveDx: dx,
            moveDy: dy,
            sprint,
            aimWorldX: dx !== 0 || dy !== 0 ? undefined : mouseWorldRef.current.x,
            aimWorldY: dx !== 0 || dy !== 0 ? undefined : mouseWorldRef.current.y,
          },
          { silent: true }
        );
      }

      const snap = gameStore.getSnapshot();
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const maxCamX = snap.world.width * 16 - LOGICAL_W;
          const maxCamY = snap.world.height * 16 - LOGICAL_H;
          const camX = Math.max(0, Math.min(maxCamX, snap.actors.player.x - LOGICAL_W / 2));
          const camY = Math.max(0, Math.min(maxCamY, snap.actors.player.y - LOGICAL_H / 2));
          renderWorldCanvas(ctx, snap, {
            camX,
            camY,
            hoverWorldX: mouseWorldRef.current.x,
            hoverWorldY: mouseWorldRef.current.y,
            selectedBuildDefId,
          });
        }
      }

      rafId = window.requestAnimationFrame(frame);
    };

    rafId = window.requestAnimationFrame(frame);
    return () => window.cancelAnimationFrame(rafId);
  }, [selectedBuildDefId]);

  const screenToWorld = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    const snap = gameStore.getSnapshot();
    if (!canvas) return { x: snap.actors.player.x, y: snap.actors.player.y };
    const rect = canvas.getBoundingClientRect();
    const lx = ((clientX - rect.left) / Math.max(1, rect.width)) * LOGICAL_W;
    const ly = ((clientY - rect.top) / Math.max(1, rect.height)) * LOGICAL_H;
    const maxCamX = snap.world.width * 16 - LOGICAL_W;
    const maxCamY = snap.world.height * 16 - LOGICAL_H;
    const camX = Math.max(0, Math.min(maxCamX, snap.actors.player.x - LOGICAL_W / 2));
    const camY = Math.max(0, Math.min(maxCamY, snap.actors.player.y - LOGICAL_H / 2));
    return { x: camX + lx, y: camY + ly };
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    mouseWorldRef.current = screenToWorld(e.clientX, e.clientY);
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (onTitle || !state.run.active) return;
    const worldPos = screenToWorld(e.clientX, e.clientY);
    mouseWorldRef.current = worldPos;

    if (e.button === 2) {
      e.preventDefault();
      if (selectedBuildDefId) {
        setSelectedBuildDefId(null);
      } else if (state.actors.player.activeCast) {
        gameStore.submitIntent({ kind: 'CANCEL_CORE_CAST' });
      }
      return;
    }

    if (e.button === 0) {
      if (selectedBuildDefId) {
        const tx = Math.floor(worldPos.x / 16);
        const ty = Math.floor(worldPos.y / 16);
        const check = evaluateBuildGhostValidity(state, selectedBuildDefId, tx, ty);
        if (check.valid) {
          gameStore.submitIntent({
            kind: 'BUILD_STRUCTURE',
            structureDefId: selectedBuildDefId,
            tileX: tx,
            tileY: ty,
          });
          if (selectedBuildDefId === 'escrow_chest' || selectedBuildDefId === 'homestead_claim_totem') {
            setSelectedBuildDefId(null);
          }
        } else {
          gameStore.submitIntent({
            kind: 'BUILD_STRUCTURE',
            structureDefId: selectedBuildDefId,
            tileX: tx,
            tileY: ty,
          });
        }
        return;
      }

      gameStore.submitIntent({
        kind: 'ACT_ON_TARGET',
        targetWorldX: worldPos.x,
        targetWorldY: worldPos.y,
      });
    }
  };

  const player = state.actors.player;
  const mainHand = getItemsInContainer(state, 'player_equip:main_hand')[0];
  const mainHandDef = mainHand ? ITEM_MAP.get(mainHand.definitionId) : null;
  const carryKg = getPlayerCarryWeightKg(state);
  const bagCash = countItemInContainer(state, 'player_bag', 'ragnarok_cash');
  const remainingHours = Math.max(
    0,
    (BALANCE.clock.maxRunRealSeconds.value - state.clock.elapsedRunSec) / 3600
  );

  // Detect nearest contextual interactable prompt for HUD
  const interactHint = useMemo(() => {
    const bag = Object.values(state.entities.deathBags).find(
      (b) => Math.hypot(b.x - player.x, b.y - player.y) <= 60
    );
    if (bag) return '[E] Recover Death Bag';
    const escrow = Object.values(state.entities.structures).find(
      (s) =>
        s.hp > 0 &&
        s.definitionId === 'escrow_chest' &&
        Math.hypot(s.tileX * 16 + 8 - player.x, s.tileY * 16 + 8 - player.y) <= 64
    );
    if (escrow) return '[E] Deposit Cash (Escrow Chest)';
    const vendor = Object.values(state.world.pois).find(
      (p) => p.vendorTile && Math.hypot(p.vendorTile.x * 16 + 8 - player.x, p.vendorTile.y * 16 + 8 - player.y) <= 68
    );
    if (vendor) return '[E] Trade (Wayfarer Trader)';
    const evac = Object.values(state.world.pois).find(
      (p) => p.evacTile && Math.hypot(p.evacTile.x * 16 + 8 - player.x, p.evacTile.y * 16 + 8 - player.y) <= 68
    );
    if (evac) return '[E] Harbor Evacuation Beacon';
    const src = Object.values(state.sourceStocks).find(
      (s) => s.stock > 0 && Math.hypot(s.tileX * 16 + 8 - player.x, s.tileY * 16 + 8 - player.y) <= 40
    );
    if (src) return `[Click/E] ${SOURCE_MAP.get(src.definitionId)?.name ?? 'Harvest'}`;
    return null;
  }, [state.entities, state.world.pois, state.sourceStocks, player.x, player.y]);

  const frameWidth = LOGICAL_W * integerScale;
  const frameHeight = LOGICAL_H * integerScale;

  return (
    <div className="w-screen h-screen bg-stone-950 flex items-center justify-center overflow-hidden">
      <div
        data-testid="game-viewport"
        style={{ width: `${frameWidth}px`, height: `${frameHeight}px` }}
        className="relative bg-black overflow-hidden border border-stone-800 shadow-2xl"
      >
        {/* Crisp 640x360 Logical World Canvas Integer-Scaled */}
        <canvas
          ref={canvasRef}
          data-testid="world-canvas"
          width={LOGICAL_W}
          height={LOGICAL_H}
          onMouseMove={handleCanvasMouseMove}
          onMouseDown={handleCanvasMouseDown}
          onContextMenu={(e) => e.preventDefault()}
          className="pixel-canvas w-full h-full block cursor-crosshair"
        />

        {/* Top Compact Survival & Clock HUD Strip (fits 640x360 and 1280x720 cleanly without clipping) */}
        {!onTitle && (
          <header
            data-testid="hud-topbar"
            className="absolute top-0 left-0 right-0 h-7 bg-stone-950/90 border-b border-stone-800 px-2 flex items-center justify-between gap-2 text-[10px] z-20 pointer-events-auto"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="flex items-center gap-1 font-bold text-red-300" title="Health">
                <Heart className="w-3.5 h-3.5 text-red-500" />
                {Math.ceil(player.hp)}/{player.maxHp}
              </span>
              <span
                className={player.hunger < 25 ? 'text-orange-400 font-bold' : 'text-amber-200'}
                title="Hunger"
              >
                Food {Math.round(player.hunger)}
              </span>
              <span
                className={player.thirst < 25 ? 'text-sky-400 font-bold' : 'text-sky-200'}
                title="Thirst"
              >
                H2O {Math.round(player.thirst)}
              </span>
              <span className="hidden sm:inline text-stone-300" title="Ambient Temp & Radiation">
                {Math.round(player.temperatureC)}°C
                {player.radiationDose > 1 ? ` · ☢${Math.round(player.radiationDose)}` : ''}
              </span>
              <span
                className={
                  carryKg > BALANCE.player.baseCarryCapacityKg.value ? 'text-orange-300 font-bold' : 'text-stone-400'
                }
                title="Carried Weight"
              >
                {carryKg.toFixed(0)}kg
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`px-1.5 py-0.5 rounded font-bold ${
                  state.clock.phase === 'ordinary'
                    ? 'bg-stone-800 text-stone-200'
                    : 'bg-red-900/90 text-amber-200 animate-pulse'
                }`}
                title="336h Real UTC Run Clock & Weather"
              >
                {state.clock.phase === 'ordinary'
                  ? `D${state.clock.fictionalDayNumber} · ${remainingHours.toFixed(1)}h UTC · ${state.clock.weather}`
                  : `RAGNAROK ${remainingHours.toFixed(1)}h`}
              </span>
              <span
                className="flex items-center gap-1 text-emerald-300 font-bold"
                title="Profile Secured Cash (Bag Unsecured Cash in parentheses)"
              >
                <Coins className="w-3.5 h-3.5" />
                {state.profile.securedCash}
                {bagCash > 0 ? <span className="text-amber-300">(+{bagCash})</span> : null}
              </span>
              <button
                onClick={() => {
                  sfx.muted = !sfx.muted;
                  setMuted(sfx.muted);
                }}
                aria-label="Toggle Mute"
                className="p-0.5 text-stone-300 hover:text-white"
              >
                {muted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </header>
        )}

        {/* Contextual Interaction / Status Toast (Non-blocking) */}
        {!onTitle && (interactHint || feedbackBanner || state.history.recentMessages[0]) && (
          <div className="absolute top-8 left-2 max-w-[330px] pointer-events-none z-20 space-y-1">
            {interactHint && (
              <div className="inline-block bg-amber-950/90 border border-amber-500/70 text-amber-200 px-2 py-0.5 rounded text-[10px] font-bold shadow">
                {interactHint}
              </div>
            )}
            {feedbackBanner ? (
              <div className="bg-red-950/90 border border-red-500/70 text-red-200 px-2 py-0.5 rounded text-[10px] shadow">
                {feedbackBanner}
              </div>
            ) : (
              state.history.recentMessages[0] && (
                <div className="bg-stone-950/75 border border-stone-800/80 text-stone-300 px-2 py-0.5 rounded text-[9px] truncate">
                  {state.history.recentMessages[0]}
                </div>
              )
            )}
          </div>
        )}

        {/* Active Side Drawer Panel */}
        {!onTitle && state.run.active && (
          <SidePanels
            state={state}
            activeDrawer={activeDrawer}
            onClose={() => setActiveDrawer(null)}
            selectedBuildDefId={selectedBuildDefId}
            onSelectBuildDef={setSelectedBuildDefId}
          />
        )}

        {/* Bottom Compact Quickbar (1-8) + Action Tabs HUD */}
        {!onTitle && state.run.active && (
          <footer
            data-testid="hud-bottombar"
            className="absolute bottom-0 left-0 right-0 h-9 bg-stone-950/92 border-t border-stone-800 px-1.5 flex items-center justify-between gap-1 text-[10px] z-20"
          >
            {/* Equipped Main-Hand + 8 Quickbar Slots */}
            <div className="flex items-center gap-1 min-w-0">
              <div
                className="px-1.5 py-0.5 bg-stone-900 border border-amber-600/70 rounded text-amber-200 font-semibold truncate max-w-[120px]"
                title="Equipped Main Hand Tool / Core"
              >
                {mainHand && mainHandDef ? (
                  <>
                    ⚔ {mainHandDef.name.split(' ').slice(-1)[0]}
                    {mainHand.durability !== undefined ? ` (${Math.round(mainHand.durability)})` : ''}
                    {mainHand.charges !== undefined ? ` [${mainHand.charges}c]` : ''}
                  </>
                ) : (
                  '⚔ Bare Hands'
                )}
              </div>

              <div className="flex items-center gap-0.5">
                {Array.from({ length: 8 }).map((_, idx) => {
                  const slotItem = Object.values(state.inventory.items).find(
                    (i) => i.containerId === 'player_bag' && i.slotIndex === idx
                  );
                  const sDef = slotItem ? ITEM_MAP.get(slotItem.definitionId) : null;
                  const active = player.selectedQuickbarIndex === idx;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        gameStore.submitIntent({ kind: 'SELECT_QUICKBAR', slotIndex: idx });
                        if (slotItem && sDef) {
                          if (sDef.equipSlot) {
                            gameStore.submitIntent({ kind: 'EQUIP_ITEM', instanceId: slotItem.instanceId });
                          } else if (sDef.capabilities.includes('USE')) {
                            gameStore.submitIntent({ kind: 'USE_ITEM', instanceId: slotItem.instanceId });
                          }
                        }
                      }}
                      title={sDef ? `${sDef.name} (Key ${idx + 1})` : `Quickbar ${idx + 1}`}
                      className={`w-6 h-6 rounded border flex flex-col items-center justify-center leading-none ${
                        active
                          ? 'bg-amber-900/70 border-amber-400 text-amber-100'
                          : 'bg-stone-900/90 border-stone-700 text-stone-400 hover:border-stone-500'
                      }`}
                    >
                      <span className="text-[8px] opacity-75">{idx + 1}</span>
                      <span className="text-[8px] font-bold truncate max-w-[20px]">
                        {sDef ? sDef.name.slice(0, 2).toUpperCase() : '·'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Key-Hinted Drawer Buttons */}
            <div className="flex items-center gap-0.5 shrink-0">
              {(
                [
                  { id: 'inventory', label: 'I:Bag', icon: <Shield className="w-3 h-3" /> },
                  { id: 'craft', label: 'C:Craft', icon: <Zap className="w-3 h-3" /> },
                  { id: 'build', label: 'B:Build', icon: <Home className="w-3 h-3" /> },
                  { id: 'research', label: 'R:Study', icon: null },
                  { id: 'map', label: 'M:Map', icon: <MapIcon className="w-3 h-3" /> },
                  { id: 'journal', label: 'J:Log', icon: <BookOpen className="w-3 h-3" /> },
                  { id: 'skills', label: 'Tab', icon: null },
                  { id: 'menu', label: 'Esc', icon: <Sliders className="w-3 h-3" /> },
                ] as const
              ).map((btn) => (
                <button
                  key={btn.id}
                  data-testid={`btn-${btn.id}`}
                  onClick={() => setActiveDrawer((cur) => (cur === btn.id ? null : btn.id))}
                  className={`px-1.5 py-1 rounded border flex items-center gap-0.5 font-semibold ${
                    activeDrawer === btn.id
                      ? 'bg-amber-700 border-amber-400 text-white'
                      : 'bg-stone-900 border-stone-700 text-stone-300 hover:bg-stone-800'
                  }`}
                >
                  {btn.icon}
                  <span>{btn.label}</span>
                </button>
              ))}
            </div>
          </footer>
        )}

        {/* Run Finalized Overlay (Evacuation / Six-Stone Convergence / Abandon / 336h Expiration) */}
        {!onTitle && !state.run.active && (
          <div
            data-testid="run-finalized-overlay"
            className="absolute inset-0 bg-stone-950/92 flex items-center justify-center p-3 z-40"
          >
            <div className="max-w-md w-full bg-stone-900 border border-amber-600/80 rounded p-3 space-y-2 text-xs">
              <div className="text-sm font-bold text-amber-300 uppercase tracking-wider">
                Run Finalized: {state.run.endedReason?.replace(/_/g, ' ')}
              </div>
              {state.profile.runHistory[0] && (
                <div className="bg-stone-950 border border-stone-800 rounded p-2 space-y-1 text-[11px]">
                  <div>
                    Run ID: <b>{state.profile.runHistory[0].runId}</b> ({state.profile.runHistory[0].spawnRegionName})
                  </div>
                  <div>
                    Secured Profile Ragnarok Cash: <b className="text-emerald-400">{state.profile.securedCash}</b> (+
                    {state.profile.runHistory[0].cashSecuredDuringRun} this run)
                  </div>
                  <div>
                    Unsecured Physical Cash Wiped:{' '}
                    <b className="text-red-300">{state.profile.runHistory[0].unsecuredCashLostOnEnd}</b>
                  </div>
                  <div>
                    Elder Stones Claimed: <b>{state.profile.runHistory[0].elderStonesCollected.length}/6</b>
                  </div>
                  <div>
                    Local Score:{' '}
                    <b className="text-amber-300">
                      {state.profile.runHistory[0].localUnverifiedScore} pts [
                      {state.profile.runHistory[0].verificationLabel}]
                    </b>
                  </div>
                </div>
              )}
              <div className="text-[10px] text-stone-400">
                All run-local gear, structures, Cores, recipes, and sources have wiped. Only your secured Ragnarok cash, achievements, and island geography knowledge carry forward.
              </div>
              <button
                data-testid="btn-return-title-run2"
                onClick={() => gameStore.setShowTitleScreen(true)}
                className="w-full py-1.5 bg-amber-700 hover:bg-amber-600 rounded font-bold text-white"
              >
                Prepare Next Expedition (Run #{state.profile.runHistory.length + 1})
              </button>
            </div>
          </div>
        )}

        {/* Title / Expedition Launch Screen (Fits cleanly inside 640x360!) */}
        {onTitle && (
          <div
            data-testid="title-screen"
            className="absolute inset-0 bg-stone-950/88 flex items-center justify-center p-2.5 z-40"
          >
            <div className="w-full max-w-[580px] max-h-full overflow-y-auto panel-scroll bg-stone-900/95 border border-stone-700 rounded p-3 space-y-2.5 text-xs shadow-2xl">
              <div className="flex items-start justify-between gap-2 border-b border-stone-800 pb-2">
                <div>
                  <h1 className="text-sm sm:text-base font-extrabold tracking-wide text-amber-300">
                    SOUL OF HERO: WORLD SIMULATION PROTOTYPE
                  </h1>
                  <p className="text-[10px] text-stone-400">
                    Solo PvE Top-Down Survival Action-RPG · 336h Real UTC Clock · Author Your Own Story
                  </p>
                </div>
                <div className="text-right text-[10px] bg-stone-950 border border-stone-800 px-2 py-1 rounded shrink-0">
                  <div className="text-emerald-300 font-bold">
                    Secured Cash: {state.profile.securedCash}
                  </div>
                  <div className="text-stone-400">
                    Runs Completed: {state.profile.runHistory.length}
                  </div>
                </div>
              </div>

              {/* Select Adventurer & Starting Region */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="bg-stone-950/80 border border-stone-800 rounded p-2 space-y-1.5">
                  <div className="text-[10px] uppercase font-bold text-stone-400">1. Select Adventurer</div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {(['female', 'male'] as const).map((g) => (
                      <button
                        key={g}
                        data-testid={`select-gender-${g}`}
                        onClick={() => setSelectedGender(g)}
                        className={`py-1.5 px-2 rounded border font-bold capitalize text-[11px] ${
                          selectedGender === g
                            ? 'bg-amber-800/80 border-amber-400 text-amber-100'
                            : 'bg-stone-900 border-stone-700 text-stone-400'
                        }`}
                      >
                        {g} Adventurer
                      </button>
                    ))}
                  </div>
                  <div className="text-[10px] text-stone-400 leading-snug">
                    Identical world laws, hitboxes, and sandbox freedom. Starts with Rusty Knife, Canteen & Berries. No forced quests or Core locks.
                  </div>
                </div>

                <div className="bg-stone-950/80 border border-stone-800 rounded p-2 space-y-1">
                  <div className="text-[10px] uppercase font-bold text-stone-400">
                    2. Choose Safe Coastal/Woodland Landing
                  </div>
                  <div className="grid grid-cols-2 gap-1">
                    {topology.spawnRegions.map((sp, idx) => (
                      <button
                        key={sp.id}
                        data-testid={`select-spawn-${idx}`}
                        onClick={() => setSelectedSpawnIdx(idx)}
                        className={`p-1 rounded border text-left text-[10px] truncate ${
                          selectedSpawnIdx === idx
                            ? 'bg-emerald-900/80 border-emerald-400 text-emerald-100 font-bold'
                            : 'bg-stone-900 border-stone-800 text-stone-300'
                        }`}
                        title={sp.description}
                      >
                        {idx + 1}. {sp.name.split(' ').slice(0, 2).join(' ')}
                      </button>
                    ))}
                  </div>
                  <div className="text-[9px] text-stone-400 truncate">
                    {topology.spawnRegions[selectedSpawnIdx]?.description}
                  </div>
                </div>
              </div>

              {/* Launch / Resume Buttons */}
              <div className="flex flex-wrap items-center gap-2 pt-0.5">
                <button
                  data-testid="btn-start-new-run"
                  onClick={() => void gameStore.startFreshRun(selectedGender, selectedSpawnIdx)}
                  className="flex-1 py-1.5 px-3 bg-amber-600 hover:bg-amber-500 text-stone-950 font-extrabold rounded text-xs"
                >
                  Launch New Expedition ({topology.spawnRegions[selectedSpawnIdx]?.name.split(' ')[0]})
                </button>
                {state.run.active && state.revision > 1 && (
                  <button
                    data-testid="btn-resume-run"
                    onClick={() => gameStore.setShowTitleScreen(false)}
                    className="py-1.5 px-3 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded text-xs"
                  >
                    Resume Active Run ({state.run.runId})
                  </button>
                )}
              </div>

              {/* Compact Controls & Recent Run History Footer */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-[9px] text-stone-400 border-t border-stone-800 pt-1.5">
                <span>
                  Controls: <b>WASD</b> Move · <b>Shift</b> Sprint · <b>Click</b> Attack/Harvest/Cast · <b>E</b> Interact · <b>I/C/B/R/M/J/Tab/Esc</b> Panels
                </span>
                {state.profile.runHistory.length > 0 && (
                  <span className="text-amber-300">
                    Last Run: {state.profile.runHistory[0].endReason} ({state.profile.runHistory[0].localUnverifiedScore} pts LOCAL_UNVERIFIED)
                  </span>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
