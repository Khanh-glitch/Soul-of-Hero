import { ZZFX, zzfx } from 'zzfx';

export type SfxKind =
  | 'swing'
  | 'hit'
  | 'chop'
  | 'mine'
  | 'craft'
  | 'build'
  | 'cast_start'
  | 'cast_commit'
  | 'deposit'
  | 'hurt'
  | 'ui';

class SoundController {
  public muted = false;
  public volume = 0.28;

  public play(kind: SfxKind): void {
    if (this.muted || typeof window === 'undefined' || typeof AudioContext === 'undefined') {
      return;
    }
    try {
      ZZFX.volume = this.volume;
      switch (kind) {
        case 'swing':
          zzfx(0.8, 0.08, 210, 0.01, 0.04, 0.06, 4, 1.4, -12);
          break;
        case 'hit':
          zzfx(1.0, 0.05, 145, 0.01, 0.04, 0.09, 3, 2.1, -6);
          break;
        case 'chop':
          zzfx(0.9, 0.06, 120, 0.01, 0.03, 0.07, 2, 1.8, -4);
          break;
        case 'mine':
          zzfx(0.9, 0.04, 580, 0.005, 0.03, 0.1, 1, 0.8, 4, 0, 120, 0.03);
          break;
        case 'craft':
          zzfx(0.8, 0.03, 360, 0.01, 0.06, 0.12, 0, 1.1, 0, 0, 140, 0.05);
          break;
        case 'build':
          zzfx(0.9, 0.04, 190, 0.01, 0.05, 0.08, 2, 1.3, 2);
          break;
        case 'cast_start':
          zzfx(0.7, 0.03, 310, 0.08, 0.12, 0.14, 1, 1.2, 6);
          break;
        case 'cast_commit':
          zzfx(1.1, 0.05, 240, 0.02, 0.12, 0.24, 3, 1.7, -8, 4);
          break;
        case 'deposit':
          zzfx(1.0, 0.02, 520, 0.01, 0.1, 0.22, 0, 1.0, 0, 0, 260, 0.07);
          break;
        case 'hurt':
          zzfx(1.0, 0.05, 110, 0.01, 0.06, 0.15, 4, 2.2, -5);
          break;
        case 'ui':
          zzfx(0.5, 0.02, 480, 0.005, 0.02, 0.03, 0, 1.0);
          break;
      }
    } catch {
      // Browser autoplay restriction before first user gesture — safely ignored
    }
  }
}

export const sfx = new SoundController();
