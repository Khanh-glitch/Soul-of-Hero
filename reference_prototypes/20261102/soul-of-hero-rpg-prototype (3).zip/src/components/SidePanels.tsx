import React, { useEffect, useRef, useState } from 'react';
import { Close } from 'pixelarticons/react';
import {
  BALANCE,
  BOSS_MAP,
  ITEM_MAP,
  POI_MAP,
  RECIPES,
  RECIPE_MAP,
  SKILLS,
  STRUCTURES,
  STRUCTURE_MAP,
} from '../data/catalogs';
import {
  countItemInContainer,
  getCartCargoWeightKg,
  getItemsInContainer,
  getPlayerCarryWeightKg,
} from '../sim/custody';
import { isPlayerSheltered, isStructurePowered, isTileOwnedHomestead } from '../sim/engine';
import type { GameState, ItemInstance } from '../sim/types';
import { getOrCreateTopology, tileIndex } from '../sim/worldGen';
import { gameStore, type KeyBindings } from '../store/gameStore';

export type ActiveDrawer =
  | null
  | 'inventory'
  | 'craft'
  | 'build'
  | 'research'
  | 'map'
  | 'journal'
  | 'skills'
  | 'menu';

interface SidePanelsProps {
  state: GameState;
  activeDrawer: ActiveDrawer;
  onClose: () => void;
  selectedBuildDefId: string | null;
  onSelectBuildDef: (id: string | null) => void;
}

export const SidePanels: React.FC<SidePanelsProps> = ({
  state,
  activeDrawer,
  onClose,
  selectedBuildDefId,
  onSelectBuildDef,
}) => {
  const [depositInput, setDepositInput] = useState<number>(50);
  const [remappingKey, setRemappingKey] = useState<keyof KeyBindings | null>(null);
  const [showQaTab, setShowQaTab] = useState(false);
  const mapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const player = state.actors.player;
  const ptx = Math.floor(player.x / 16);
  const pty = Math.floor(player.y / 16);

  // Detect nearby physical interactables within lawful reach
  const nearbyStructures = Object.values(state.entities.structures).filter(
    (s) => s.hp > 0 && Math.hypot(s.tileX * 16 + 8 - player.x, s.tileY * 16 + 8 - player.y) <= 76
  );
  const nearbyContainerStr = nearbyStructures.find((s) => {
    const d = STRUCTURE_MAP.get(s.definitionId);
    return (d?.containerSlots ?? 0) > 0;
  });
  const nearbyEscrowStr = nearbyStructures.find((s) => s.definitionId === 'escrow_chest');
  const nearbyResearchDesk = nearbyStructures.find((s) => s.definitionId === 'research_desk');
  const nearbyCart = Object.values(state.entities.carts).find(
    (c) => Math.hypot(c.x - player.x, c.y - player.y) <= 68
  );
  const nearbyBag = Object.values(state.entities.deathBags).find(
    (b) => Math.hypot(b.x - player.x, b.y - player.y) <= 64
  );
  const nearbyVendorPoi = Object.values(state.world.pois).find(
    (p) => p.vendorTile && Math.hypot(p.vendorTile.x * 16 + 8 - player.x, p.vendorTile.y * 16 + 8 - player.y) <= 68
  );
  const nearbyEvacPoi = Object.values(state.world.pois).find(
    (p) => p.evacTile && Math.hypot(p.evacTile.x * 16 + 8 - player.x, p.evacTile.y * 16 + 8 - player.y) <= 68
  );
  const nearbyLockedGatePoi = Object.values(state.world.pois).find(
    (p) =>
      !p.gateUnlocked &&
      p.gateTile &&
      Math.hypot(p.gateTile.x * 16 + 8 - player.x, p.gateTile.y * 16 + 8 - player.y) <= 68
  );

  // Key remapping listener
  useEffect(() => {
    if (!remappingKey) return;
    const handler = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      gameStore.updateKeyBinding(remappingKey, e.code);
      setRemappingKey(null);
    };
    window.addEventListener('keydown', handler, { once: true });
    return () => window.removeEventListener('keydown', handler);
  }, [remappingKey]);

  // Draw live 192x192 fog-of-war island map when Map drawer is open
  useEffect(() => {
    if (activeDrawer !== 'map' || !mapCanvasRef.current) return;
    const canvas = mapCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const topo = getOrCreateTopology(state.world.seed);
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#0c0a09';
    ctx.fillRect(0, 0, topo.width, topo.height);

    const discovered = new Set(state.run.discoveredChunks);
    const chunksPerRow = Math.ceil(topo.width / 16);

    const biomeColor: Record<string, string> = {
      deep_sea: '#0f3952',
      shallow_water: '#1d6f8a',
      coast: '#d9b982',
      plains: '#5c9c54',
      forest: '#2f6333',
      wetland: '#3f5a36',
      hills: '#78716c',
      mountain: '#44403c',
      cold: '#e2e8f0',
      hot: '#7c2d12',
      radiation: '#65a30d',
      road: '#c28b57',
      poi_floor: '#a8a29e',
    };

    for (let y = 0; y < topo.height; y++) {
      for (let x = 0; x < topo.width; x++) {
        const cIdx = Math.floor(y / 16) * chunksPerRow + Math.floor(x / 16);
        const b = topo.biomes[tileIndex(x, y, topo.width)];
        ctx.fillStyle = biomeColor[b] ?? '#44403c';
        ctx.globalAlpha = discovered.has(cIdx) ? 1.0 : 0.34;
        ctx.fillRect(x, y, 1, 1);
      }
    }
    ctx.globalAlpha = 1.0;

    // POIs (geography landmarks, never hidden monsters!)
    for (const poi of Object.values(state.world.pois)) {
      ctx.fillStyle = poi.evacTile ? '#38bdf8' : poi.vendorTile ? '#facc15' : '#f97316';
      ctx.fillRect(Math.floor(poi.centerX / 16) - 2, Math.floor(poi.centerY / 16) - 2, 4, 4);
    }

    // Owned Homestead Totems
    for (const s of Object.values(state.entities.structures)) {
      if (s.hp > 0 && STRUCTURE_MAP.get(s.definitionId)?.claimsTerritory) {
        ctx.fillStyle = '#34d399';
        ctx.fillRect(s.tileX - 2, s.tileY - 2, 4, 4);
      }
    }

    // Death Bags
    for (const bag of Object.values(state.entities.deathBags)) {
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(Math.floor(bag.x / 16) - 2, Math.floor(bag.y / 16) - 2, 4, 4);
    }

    // Player marker
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(ptx - 2, pty - 2, 5, 5);
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(ptx - 1, pty - 1, 3, 3);
  }, [activeDrawer, state.world.seed, state.run.discoveredChunks, state.entities, ptx, pty, state.world.pois]);

  if (!activeDrawer) return null;

  const bagItems = getItemsInContainer(state, 'player_bag');
  const carryKg = getPlayerCarryWeightKg(state);
  const bagCash = countItemInContainer(state, 'player_bag', 'ragnarok_cash');

  const externalContainerId = nearbyContainerStr
    ? `structure:${nearbyContainerStr.structureId}`
    : nearbyCart
    ? `cart:${nearbyCart.cartId}`
    : nearbyBag
    ? `death_bag:${nearbyBag.bagId}`
    : null;

  const renderItemBadge = (item: ItemInstance) => {
    const def = ITEM_MAP.get(item.definitionId);
    if (!def) return null;
    return (
      <div
        key={item.instanceId}
        className="flex items-center justify-between gap-1.5 bg-stone-900/95 border border-stone-700/80 px-2 py-1 rounded text-[11px]"
      >
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-stone-100 truncate">
            {def.name} {item.count > 1 ? <span className="text-amber-300">x{item.count}</span> : null}
          </div>
          <div className="text-[10px] text-stone-400 flex flex-wrap gap-2">
            <span>{(def.weightKg * item.count).toFixed(1)}kg</span>
            {item.durability !== undefined && (
              <span className={item.durability <= 12 ? 'text-red-400' : 'text-emerald-300'}>
                Dur {Math.round(item.durability)}/{item.maxDurability}
              </span>
            )}
            {item.charges !== undefined && (
              <span className="text-purple-300">
                Chg {item.charges}/{item.maxCharges}
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {def.equipSlot && (
            <button
              onClick={() => gameStore.submitIntent({ kind: 'EQUIP_ITEM', instanceId: item.instanceId })}
              className="px-1.5 py-0.5 bg-sky-900/80 hover:bg-sky-800 border border-sky-600/60 rounded text-[10px]"
            >
              Equip
            </button>
          )}
          {def.capabilities.includes('USE') && (
            <button
              onClick={() => gameStore.submitIntent({ kind: 'USE_ITEM', instanceId: item.instanceId })}
              className="px-1.5 py-0.5 bg-emerald-900/80 hover:bg-emerald-800 border border-emerald-600/60 rounded text-[10px]"
            >
              Use
            </button>
          )}
          {def.deploysEntity === 'hand_cart' && (
            <button
              onClick={() =>
                gameStore.submitIntent({
                  kind: 'DEPLOY_CART',
                  cartKitInstanceId: item.instanceId,
                  tileX: ptx + 1,
                  tileY: pty,
                })
              }
              className="px-1.5 py-0.5 bg-amber-900/80 hover:bg-amber-800 border border-amber-600/60 rounded text-[10px]"
            >
              Deploy
            </button>
          )}
          {def.deploysStructure && (
            <button
              onClick={() => {
                onSelectBuildDef(def.deploysStructure!);
                onClose();
              }}
              className="px-1.5 py-0.5 bg-emerald-900/80 hover:bg-emerald-800 border border-emerald-500/70 rounded text-[10px]"
            >
              Place
            </button>
          )}
          {!def.uniqueInstance && item.count >= 2 && (
            <button
              onClick={() =>
                gameStore.submitIntent({
                  kind: 'SPLIT_STACK',
                  instanceId: item.instanceId,
                  splitCount: Math.floor(item.count / 2),
                })
              }
              title="Split stack in half"
              className="px-1 py-0.5 bg-stone-800 hover:bg-stone-700 border border-stone-600 rounded text-[10px]"
            >
              ½
            </button>
          )}
          {externalContainerId && (
            <button
              onClick={() =>
                gameStore.submitIntent({
                  kind: 'TRANSFER_ITEM',
                  instanceId: item.instanceId,
                  toContainerId: externalContainerId,
                })
              }
              className="px-1.5 py-0.5 bg-amber-800/80 hover:bg-amber-700 border border-amber-500/60 rounded text-[10px]"
            >
              Store→
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <aside
      data-testid={`drawer-${activeDrawer}`}
      className="absolute right-1.5 top-8 bottom-11 w-[290px] sm:w-[360px] bg-stone-950/95 border border-stone-700 rounded shadow-2xl flex flex-col z-30 text-xs"
    >
      {/* Drawer Header */}
      <div className="flex items-center justify-between px-2.5 py-1.5 border-b border-stone-800 bg-stone-900/90 shrink-0">
        <span className="font-bold tracking-wider uppercase text-amber-300 text-[11px]">
          {activeDrawer === 'inventory' && `Custody & Gear (${carryKg}/${BALANCE.player.baseCarryCapacityKg.value}kg)`}
          {activeDrawer === 'craft' && 'Crafting & Station Queues'}
          {activeDrawer === 'build' && 'Construction & Homestead'}
          {activeDrawer === 'research' && 'Knowledge & Specimen Study'}
          {activeDrawer === 'map' && 'Island Topology (Discovered)'}
          {activeDrawer === 'journal' && 'Field Notes & Run Ledger'}
          {activeDrawer === 'skills' && 'Core Drivers & Elder Stones'}
          {activeDrawer === 'menu' && 'Session, Forecast & Controls'}
        </span>
        <button
          onClick={onClose}
          aria-label="Close panel"
          className="p-0.5 text-stone-400 hover:text-white hover:bg-stone-800 rounded"
        >
          <Close className="w-4 h-4" />
        </button>
      </div>

      {/* Scrollable Body */}
      <div className="flex-1 overflow-y-auto panel-scroll p-2 space-y-2.5">
        {activeDrawer === 'inventory' && (
          <>
            {/* Equipped Slots */}
            <div className="bg-stone-900/70 border border-stone-800 rounded p-2 space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-stone-400 font-semibold">Equipped</div>
              {(['main_hand', 'body', 'accessory'] as const).map((slot) => {
                const eq = getItemsInContainer(state, `player_equip:${slot}`)[0];
                const eqDef = eq ? ITEM_MAP.get(eq.definitionId) : null;
                return (
                  <div key={slot} className="flex items-center justify-between text-[11px] bg-stone-950/70 px-2 py-1 rounded">
                    <span className="text-stone-400 capitalize">{slot.replace('_', ' ')}:</span>
                    {eq && eqDef ? (
                      <div className="flex items-center gap-1.5">
                        <span className="text-amber-200 font-medium">{eqDef.name}</span>
                        {eq.durability !== undefined && (
                          <span className="text-[10px] text-stone-400">({Math.round(eq.durability)})</span>
                        )}
                        {eq.charges !== undefined && (
                          <span className="text-[10px] text-purple-300">[{eq.charges}c]</span>
                        )}
                        <button
                          onClick={() => gameStore.submitIntent({ kind: 'UNEQUIP_ITEM', equipSlot: slot })}
                          className="px-1.5 py-0.5 bg-stone-800 hover:bg-stone-700 rounded text-[10px]"
                        >
                          Unequip
                        </button>
                      </div>
                    ) : (
                      <span className="text-stone-600 italic">Empty</span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Nearby Escrow Chest Atomic Deposit UI */}
            {nearbyEscrowStr && (
              <div className="bg-emerald-950/70 border border-emerald-600/70 rounded p-2 space-y-1.5">
                <div className="font-bold text-emerald-300 text-[11px]">
                  Rương Ký Gửi (Owned Escrow Chest)
                </div>
                <div className="text-[10px] text-emerald-100/90">
                  Bag Physical Cash: <b>{bagCash}</b> | Profile Secured Wallet: <b>{state.profile.securedCash}</b>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min={1}
                    max={Math.max(1, bagCash)}
                    value={depositInput}
                    onChange={(e) => setDepositInput(Math.max(1, Number(e.target.value) || 1))}
                    className="w-16 bg-stone-950 border border-emerald-700 rounded px-1.5 py-0.5 text-[11px]"
                  />
                  <button
                    onClick={() =>
                      gameStore.submitIntent({
                        kind: 'DEPOSIT_ESCROW',
                        escrowStructureId: nearbyEscrowStr.structureId,
                        amount: Math.min(bagCash, depositInput),
                      })
                    }
                    disabled={bagCash <= 0}
                    className="px-2 py-0.5 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-40 rounded font-semibold text-[10px]"
                  >
                    Deposit
                  </button>
                  <button
                    onClick={() =>
                      gameStore.submitIntent({
                        kind: 'DEPOSIT_ESCROW',
                        escrowStructureId: nearbyEscrowStr.structureId,
                        amount: bagCash,
                      })
                    }
                    disabled={bagCash <= 0}
                    className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 rounded font-semibold text-[10px]"
                  >
                    Secure All ({bagCash})
                  </button>
                </div>
              </div>
            )}

            {/* Nearby Physical Wayfarer Trader Vendor */}
            {nearbyVendorPoi && (
              <div className="bg-amber-950/60 border border-amber-600/70 rounded p-2 space-y-1.5">
                <div className="font-bold text-amber-300 text-[11px]">
                  Wayfarer Trader ({nearbyVendorPoi.name})
                </div>
                <div className="text-[10px] text-stone-300">
                  Profile Secured Cash: <b className="text-emerald-300">{state.profile.securedCash}</b> | Bag Cash:{' '}
                  <b className="text-amber-300">{bagCash}</b>
                </div>
                <div className="space-y-1">
                  {nearbyVendorPoi.vendorStock.map((v) => {
                    const def = ITEM_MAP.get(v.itemId);
                    return (
                      <div
                        key={v.itemId}
                        className="flex items-center justify-between bg-stone-950/80 px-2 py-1 rounded text-[10px]"
                      >
                        <div>
                          <div className="font-semibold text-stone-100">
                            {def?.name ?? v.itemId} <span className="text-stone-400">({v.remaining} left)</span>
                          </div>
                          <div className="text-amber-300">
                            {v.priceCash} Cash{' '}
                            {v.acceptsUnsecuredPhysicalCash && (
                              <span className="text-emerald-300">[Bag or Profile Cash · PROPOSED]</span>
                            )}
                          </div>
                        </div>
                        <button
                          disabled={v.remaining <= 0}
                          onClick={() =>
                            gameStore.submitIntent({
                              kind: 'VENDOR_BUY',
                              poiId: nearbyVendorPoi.poiId,
                              itemId: v.itemId,
                              payWithUnsecuredBagCash:
                                v.acceptsUnsecuredPhysicalCash &&
                                state.profile.securedCash < v.priceCash &&
                                bagCash >= v.priceCash,
                            })
                          }
                          className="px-2 py-0.5 bg-amber-700 hover:bg-amber-600 disabled:opacity-40 rounded font-semibold"
                        >
                          Buy
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Nearby Harbor Physical Evacuation Beacon */}
            {nearbyEvacPoi && (
              <div className="bg-sky-950/70 border border-sky-500/70 rounded p-2 space-y-1">
                <div className="font-bold text-sky-300 text-[11px]">Harbor Evacuation Cutter Beacon</div>
                <div className="text-[10px] text-stone-300">
                  Physically ends this run once and records history.{' '}
                  {bagCash > 0 && (
                    <span className="text-red-300 font-semibold">
                      Warning: {bagCash} unsecured cash in bag will NOT auto-deposit!
                    </span>
                  )}
                </div>
                <button
                  onClick={() =>
                    gameStore.submitIntent({ kind: 'EVACUATE_RUN', poiId: nearbyEvacPoi.poiId })
                  }
                  className="w-full py-1 bg-sky-700 hover:bg-sky-600 rounded font-bold text-[11px]"
                >
                  Board Evacuation Cutter (End Run)
                </button>
              </div>
            )}

            {/* Nearby Locked POI Deep Gate */}
            {nearbyLockedGatePoi && (
              <div className="bg-orange-950/70 border border-orange-500/70 rounded p-2 space-y-1">
                <div className="font-bold text-orange-300 text-[11px]">
                  {POI_MAP.get(nearbyLockedGatePoi.poiId)?.deepGate?.label}
                </div>
                <button
                  onClick={() =>
                    gameStore.submitIntent({ kind: 'UNLOCK_POI_GATE', poiId: nearbyLockedGatePoi.poiId })
                  }
                  className="px-2 py-0.5 bg-orange-700 hover:bg-orange-600 rounded font-semibold text-[10px]"
                >
                  Use Credential to Unlock Gate
                </button>
              </div>
            )}

            {/* Nearby External Container (Chest, Hand-Cart, or Death Bag) */}
            {externalContainerId && (
              <div className="bg-stone-900/90 border border-amber-700/60 rounded p-2 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 text-[11px]">
                    {nearbyContainerStr && STRUCTURE_MAP.get(nearbyContainerStr.definitionId)?.name}
                    {nearbyCart &&
                      `Cargo Hand-Cart (${getCartCargoWeightKg(state, nearbyCart.cartId)}/120kg)`}
                    {nearbyBag && `Death Recovery Bag (${nearbyBag.deathCause})`}
                  </span>
                  <div className="flex gap-1">
                    {nearbyCart && (
                      <>
                        <button
                          onClick={() =>
                            gameStore.submitIntent({ kind: 'TOGGLE_HITCH_CART', cartId: nearbyCart.cartId })
                          }
                          className="px-1.5 py-0.5 bg-amber-800 hover:bg-amber-700 rounded text-[10px]"
                        >
                          {nearbyCart.hitchedByPlayer ? 'Unhitch' : 'Hitch'}
                        </button>
                        <button
                          onClick={() =>
                            gameStore.submitIntent({ kind: 'PACK_CART', cartId: nearbyCart.cartId })
                          }
                          className="px-1.5 py-0.5 bg-stone-800 hover:bg-stone-700 rounded text-[10px]"
                        >
                          Fold
                        </button>
                      </>
                    )}
                    {nearbyBag && (
                      <button
                        onClick={() =>
                          gameStore.submitIntent({ kind: 'RECOVER_DEATH_BAG', bagId: nearbyBag.bagId })
                        }
                        className="px-2 py-0.5 bg-emerald-700 hover:bg-emerald-600 rounded font-semibold text-[10px]"
                      >
                        Take All
                      </button>
                    )}
                  </div>
                </div>
                <div className="space-y-1">
                  {getItemsInContainer(state, externalContainerId).map((cItem) => {
                    const cDef = ITEM_MAP.get(cItem.definitionId);
                    return (
                      <div
                        key={cItem.instanceId}
                        className="flex items-center justify-between bg-stone-950/80 px-2 py-1 rounded text-[10px]"
                      >
                        <span>
                          {cDef?.name ?? cItem.definitionId}{' '}
                          {cItem.count > 1 ? <b className="text-amber-300">x{cItem.count}</b> : null}
                        </span>
                        <button
                          onClick={() =>
                            gameStore.submitIntent({
                              kind: 'TRANSFER_ITEM',
                              instanceId: cItem.instanceId,
                              toContainerId: 'player_bag',
                            })
                          }
                          className="px-1.5 py-0.5 bg-emerald-800 hover:bg-emerald-700 rounded"
                        >
                          ←Take
                        </button>
                      </div>
                    );
                  })}
                  {getItemsInContainer(state, externalContainerId).length === 0 && (
                    <div className="text-[10px] text-stone-500 italic">Container is empty.</div>
                  )}
                </div>
              </div>
            )}

            {/* Backpack Items */}
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-stone-400 font-semibold">
                Backpack Custody ({bagItems.length}/{BALANCE.player.inventorySlots.value} slots)
              </div>
              {bagItems.map(renderItemBadge)}
              {bagItems.length === 0 && (
                <div className="text-stone-500 italic text-[11px]">Backpack is empty.</div>
              )}
            </div>
          </>
        )}

        {activeDrawer === 'craft' && (
          <>
            {/* Nearby Fueled / Output Stations */}
            {nearbyStructures
              .filter((s) => {
                const d = STRUCTURE_MAP.get(s.definitionId);
                return d?.stationClass || d?.usesFuel;
              })
              .map((st) => {
                const d = STRUCTURE_MAP.get(st.definitionId)!;
                const outs = getItemsInContainer(state, `station_out:${st.structureId}`);
                const fuelsInBag = bagItems.filter((i) => (ITEM_MAP.get(i.definitionId)?.fuelSeconds ?? 0) > 0);
                return (
                  <div key={st.structureId} className="bg-stone-900/80 border border-stone-700 rounded p-2 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-200 text-[11px]">{d.name}</span>
                      <span className="text-[10px] text-stone-400">
                        {d.usesFuel ? `Fuel: ${Math.round(st.fuelRemainingSec)}s` : ''}
                        {d.requiresPower ? (isStructurePowered(state, st) ? ' ⚡Powered' : ' ⚠No Power') : ''}
                      </span>
                    </div>
                    {d.usesFuel && fuelsInBag.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {fuelsInBag.slice(0, 2).map((fi) => (
                          <button
                            key={fi.instanceId}
                            onClick={() =>
                              gameStore.submitIntent({
                                kind: 'ADD_STATION_FUEL',
                                structureId: st.structureId,
                                fuelInstanceId: fi.instanceId,
                                count: 1,
                              })
                            }
                            className="px-1.5 py-0.5 bg-orange-900/80 hover:bg-orange-800 border border-orange-600/50 rounded text-[10px]"
                          >
                            +1 {ITEM_MAP.get(fi.definitionId)?.name.split(' ').pop()}
                          </button>
                        ))}
                      </div>
                    )}
                    {outs.length > 0 && (
                      <div className="flex items-center justify-between bg-emerald-950/60 border border-emerald-700/60 px-2 py-1 rounded text-[10px]">
                        <span>
                          Output Ready:{' '}
                          {outs.map((o) => `${ITEM_MAP.get(o.definitionId)?.name} x${o.count}`).join(', ')}
                        </span>
                        <button
                          onClick={() =>
                            gameStore.submitIntent({
                              kind: 'CLAIM_STATION_OUTPUT',
                              structureId: st.structureId,
                            })
                          }
                          className="px-1.5 py-0.5 bg-emerald-700 hover:bg-emerald-600 rounded font-semibold"
                        >
                          Collect
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}

            {/* Active Jobs */}
            {Object.values(state.jobs).length > 0 && (
              <div className="bg-stone-900/70 border border-stone-800 rounded p-2 space-y-1">
                <div className="text-[10px] uppercase text-stone-400 font-semibold">Active Work Orders</div>
                {Object.values(state.jobs).map((job) => {
                  const rcp = RECIPE_MAP.get(job.recipeId);
                  const pct = Math.min(100, Math.round((job.progressSec / Math.max(1, job.requiredSec)) * 100));
                  return (
                    <div key={job.jobId} className="bg-stone-950 px-2 py-1 rounded space-y-1 text-[10px]">
                      <div className="flex justify-between">
                        <span className="font-semibold text-stone-200">{rcp?.name ?? job.recipeId}</span>
                        <span className="text-amber-300">
                          {job.status !== 'active' ? job.status.replace('paused_', '⚠ ') : `${pct}%`}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-stone-800 rounded overflow-hidden">
                          <div className="h-full bg-amber-400" style={{ width: `${pct}%` }} />
                        </div>
                        <button
                          onClick={() => gameStore.submitIntent({ kind: 'CANCEL_JOB', jobId: job.jobId })}
                          className="text-red-400 hover:underline"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Known Recipes */}
            <div className="space-y-1">
              <div className="text-[10px] uppercase text-stone-400 font-semibold">
                Run-Local Known Recipes ({state.research.learnedRecipeIds.length}/{RECIPES.length})
              </div>
              {RECIPES.filter((r) => state.research.learnedRecipeIds.includes(r.id)).map((rcp) => {
                const matchingStation =
                  rcp.station === 'hand'
                    ? 'hand'
                    : nearbyStructures.find((s) => STRUCTURE_MAP.get(s.definitionId)?.stationClass === rcp.station)
                        ?.structureId ?? null;
                const hasInputs = rcp.inputs.every(
                  (inp) => countItemInContainer(state, 'player_bag', inp.itemId) >= inp.count
                );
                return (
                  <div
                    key={rcp.id}
                    className="flex items-center justify-between gap-2 bg-stone-900/90 border border-stone-800 px-2 py-1.5 rounded text-[10px]"
                  >
                    <div className="min-w-0">
                      <div className="font-semibold text-stone-100">{rcp.name}</div>
                      <div className="text-stone-400">
                        {rcp.inputs
                          .map((i) => `${i.count} ${ITEM_MAP.get(i.itemId)?.name.split(' ').pop() ?? i.itemId}`)
                          .join(' + ')}{' '}
                        · <span className="text-sky-300">[{rcp.station}]</span>
                      </div>
                    </div>
                    <button
                      disabled={!matchingStation || !hasInputs}
                      onClick={() =>
                        matchingStation &&
                        gameStore.submitIntent({
                          kind: 'QUEUE_RECIPE_JOB',
                          stationStructureId: matchingStation,
                          recipeId: rcp.id,
                        })
                      }
                      className="px-2 py-1 bg-amber-700 hover:bg-amber-600 disabled:bg-stone-800 disabled:text-stone-500 rounded font-semibold shrink-0"
                    >
                      {rcp.station === 'hand' ? 'Craft' : 'Queue'}
                    </button>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {activeDrawer === 'build' && (
          <>
            <div className="bg-stone-900/80 border border-stone-800 rounded p-2 text-[10px] text-stone-300">
              Select a piece below, then <b>Left-Click</b> on the world canvas to build. Homestead status here:{' '}
              {isTileOwnedHomestead(state, ptx, pty) ? (
                <span className="text-emerald-400 font-bold">Owned Homestead Territory</span>
              ) : (
                <span className="text-stone-400">Unclaimed Wilds</span>
              )}
              {selectedBuildDefId && (
                <button
                  onClick={() => onSelectBuildDef(null)}
                  className="ml-2 px-1.5 py-0.5 bg-red-900/70 rounded text-red-200"
                >
                  Clear Ghost
                </button>
              )}
            </div>

            {/* Nearby Player Structures Management */}
            {nearbyStructures.filter((s) => s.ownerId === player.actorId).length > 0 && (
              <div className="space-y-1">
                <div className="text-[10px] uppercase text-stone-400 font-semibold">Nearby Owned Structures</div>
                {nearbyStructures
                  .filter((s) => s.ownerId === player.actorId)
                  .slice(0, 6)
                  .map((s) => {
                    const d = STRUCTURE_MAP.get(s.definitionId)!;
                    return (
                      <div
                        key={s.structureId}
                        className="flex items-center justify-between bg-stone-900 px-2 py-1 rounded text-[10px]"
                      >
                        <span>
                          {d.name} ({s.hp}/{s.maxHp} HP)
                        </span>
                        <div className="flex gap-1">
                          {d.isDoor && (
                            <button
                              onClick={() =>
                                gameStore.submitIntent({ kind: 'TOGGLE_DOOR', structureId: s.structureId })
                              }
                              className="px-1.5 py-0.5 bg-sky-800 rounded"
                            >
                              {s.isOpen ? 'Close' : 'Open'}
                            </button>
                          )}
                          {s.hp < s.maxHp && (
                            <button
                              onClick={() =>
                                gameStore.submitIntent({ kind: 'REPAIR_STRUCTURE', structureId: s.structureId })
                              }
                              className="px-1.5 py-0.5 bg-emerald-800 rounded"
                            >
                              Repair
                            </button>
                          )}
                          <button
                            onClick={() =>
                              gameStore.submitIntent({ kind: 'RECLAIM_STRUCTURE', structureId: s.structureId })
                            }
                            className="px-1.5 py-0.5 bg-stone-800 hover:bg-red-900/70 rounded"
                          >
                            Reclaim
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}

            <div className="space-y-1">
              <div className="text-[10px] uppercase text-stone-400 font-semibold">
                Structures Catalog ({STRUCTURES.length})
              </div>
              {STRUCTURES.map((sDef) => {
                const isSelected = selectedBuildDefId === sDef.id;
                const costText = sDef.deployItemOnly
                  ? `Requires ${ITEM_MAP.get(sDef.deployItemOnly)?.name}`
                  : sDef.cost
                      .map((c) => `${c.count} ${ITEM_MAP.get(c.itemId)?.name.split(' ').pop() ?? c.itemId}`)
                      .join(', ');
                return (
                  <div
                    key={sDef.id}
                    className={`flex items-center justify-between gap-2 px-2 py-1.5 rounded border text-[10px] ${
                      isSelected
                        ? 'bg-emerald-950/80 border-emerald-500'
                        : 'bg-stone-900/90 border-stone-800'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="font-semibold text-stone-100">{sDef.name}</div>
                      <div className="text-stone-400 truncate">{costText}</div>
                    </div>
                    <button
                      onClick={() => {
                        onSelectBuildDef(isSelected ? null : sDef.id);
                      }}
                      className="px-2 py-1 bg-emerald-800 hover:bg-emerald-700 rounded font-semibold shrink-0"
                    >
                      {isSelected ? 'Selected' : 'Place'}
                    </button>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {activeDrawer === 'research' && (
          <>
            <div className="bg-stone-900/80 border border-stone-800 rounded p-2 space-y-1.5 text-[10px]">
              <div className="flex justify-between">
                <span>Mechanical Spares in Bag:</span>
                <b className="text-amber-300">{countItemInContainer(state, 'player_bag', 'spares_token')}</b>
              </div>
              <div className="flex justify-between">
                <span>Nearby Research Desk:</span>
                <b className={nearbyResearchDesk ? 'text-emerald-400' : 'text-red-400'}>
                  {nearbyResearchDesk ? 'Ready' : 'None within reach'}
                </b>
              </div>
              <button
                disabled={!nearbyResearchDesk}
                onClick={() =>
                  nearbyResearchDesk &&
                  gameStore.submitIntent({
                    kind: 'RESEARCH_ACTION',
                    stationStructureId: nearbyResearchDesk.structureId,
                    mode: 'random_spares',
                  })
                }
                className="w-full py-1 bg-purple-800 hover:bg-purple-700 disabled:opacity-40 rounded font-semibold text-[11px]"
              >
                Random Discovery ({BALANCE.economyAndTerritory.randomSparesResearchCost.value} Spares)
              </button>
            </div>

            {/* Specimen / Charged Core Destructive Analysis */}
            <div className="space-y-1">
              <div className="text-[10px] uppercase text-stone-400 font-semibold">
                Eligible Specimens & Cores in Bag
              </div>
              {bagItems
                .filter((i) => ITEM_MAP.get(i.definitionId)?.studyEligible)
                .map((spec) => {
                  const def = ITEM_MAP.get(spec.definitionId)!;
                  const alreadyKnown = Boolean(
                    def.learnedRecipeId && state.research.learnedRecipeIds.includes(def.learnedRecipeId)
                  );
                  const depletedBlocked =
                    def.category === 'core' &&
                    !BALANCE.economyAndTerritory.depletedCoreStudyEligible.value &&
                    (spec.charges ?? 0) <= 0;
                  return (
                    <div
                      key={spec.instanceId}
                      className="flex items-center justify-between bg-stone-900 border border-stone-800 px-2 py-1.5 rounded text-[10px]"
                    >
                      <div>
                        <div className="font-semibold text-purple-200">{def.name}</div>
                        <div className="text-stone-400">
                          Unlocks: {RECIPE_MAP.get(def.learnedRecipeId ?? '')?.name ?? def.learnedRecipeId}
                          {depletedBlocked && <span className="text-red-400"> (0 charges: ineligible)</span>}
                        </div>
                      </div>
                      <button
                        disabled={!nearbyResearchDesk || alreadyKnown || depletedBlocked}
                        onClick={() =>
                          nearbyResearchDesk &&
                          gameStore.submitIntent({
                            kind: 'RESEARCH_ACTION',
                            stationStructureId: nearbyResearchDesk.structureId,
                            mode: 'specimen_study',
                            specimenInstanceId: spec.instanceId,
                          })
                        }
                        className="px-2 py-1 bg-purple-700 hover:bg-purple-600 disabled:opacity-40 rounded font-semibold"
                      >
                        {alreadyKnown ? 'Known' : 'Analyze'}
                      </button>
                    </div>
                  );
                })}
            </div>

            {/* Directed Spares Pool */}
            <div className="space-y-1">
              <div className="text-[10px] uppercase text-stone-400 font-semibold">
                Directed Study ({BALANCE.economyAndTerritory.directedSparesResearchCost.value} Spares)
              </div>
              {RECIPES.filter((r) => r.researchPool && !state.research.learnedRecipeIds.includes(r.id)).map((rcp) => (
                <div
                  key={rcp.id}
                  className="flex items-center justify-between bg-stone-900/90 px-2 py-1 rounded text-[10px]"
                >
                  <span>{rcp.name}</span>
                  <button
                    disabled={!nearbyResearchDesk}
                    onClick={() =>
                      nearbyResearchDesk &&
                      gameStore.submitIntent({
                        kind: 'RESEARCH_ACTION',
                        stationStructureId: nearbyResearchDesk.structureId,
                        mode: 'directed_spares',
                        targetRecipeId: rcp.id,
                      })
                    }
                    className="px-2 py-0.5 bg-sky-800 hover:bg-sky-700 disabled:opacity-40 rounded"
                  >
                    Study
                  </button>
                </div>
              ))}
            </div>
          </>
        )}

        {activeDrawer === 'map' && (
          <div className="space-y-2">
            <div className="flex justify-center bg-stone-900 p-1.5 rounded border border-stone-800">
              <canvas
                ref={mapCanvasRef}
                width={192}
                height={192}
                className="pixel-canvas w-[192px] h-[192px] border border-stone-700"
              />
            </div>
            <div className="grid grid-cols-2 gap-1 text-[10px] text-stone-300">
              <div>⬜/🟥 Adventurer ({ptx}, {pty})</div>
              <div>🟩 Homestead Claim</div>
              <div>🟨 Wayfarer Trader</div>
              <div>🟦 Harbor Evac Pier</div>
              <div>🟧 Industrial/Lab POI</div>
              <div>🟥 Death Recovery Bag</div>
            </div>
            <div className="text-[10px] text-stone-400">
              Discovered {state.run.discoveredChunks.length}/144 island sectors. Map shows stable geography and known sites only — never hidden creatures.
            </div>
          </div>
        )}

        {activeDrawer === 'journal' && (
          <div className="space-y-2 text-[10px]">
            <div className="bg-stone-900/80 border border-stone-800 rounded p-2 space-y-1">
              <div className="font-bold text-amber-300">Contextual Survival Opportunities (Optional)</div>
              <p className="text-stone-400">
                No quests or tutorials gate permissions. Any opportunity completed out-of-order is recognized from receipts:
              </p>
              <ul className="space-y-1 text-stone-300">
                <li>
                  {state.eventReceipts.some((r) => r.actionKind === 'ACT_ON_TARGET') ? '✓' : '○'} Harvested or fought with multipurpose tools
                </li>
                <li>
                  {Object.values(state.entities.structures).some((s) => s.ownerId === player.actorId) ? '✓' : '○'}{' '}
                  Constructed an optional Homestead piece
                </li>
                <li>
                  {state.research.learnedRecipeIds.length > RECIPES.filter((r) => r.starterKnown).length ? '✓' : '○'}{' '}
                  Expanded run-local recipe knowledge
                </li>
                <li>
                  {state.run.cashSecuredThisRun > 0 ? '✓' : '○'} Secured Ragnarok Cash via an owned Escrow Chest
                </li>
              </ul>
            </div>

            <div className="bg-stone-900/80 border border-stone-800 rounded p-2 space-y-1">
              <div className="font-bold text-emerald-300">
                Profile Ledger (Secured Cash: {state.profile.securedCash})
              </div>
              <div className="text-stone-400">
                Current Run Score:{' '}
                <b className="text-amber-300">
                  {state.run.scoreEvents.reduce((a, b) => a + b.points, 0)} pts [LOCAL_UNVERIFIED]
                </b>
              </div>
              {state.profile.runHistory.slice(0, 5).map((h) => (
                <div key={h.runId} className="bg-stone-950 p-1.5 rounded border border-stone-800">
                  <div className="font-semibold text-stone-200">
                    {h.runId} · {h.endReason} · +{h.cashSecuredDuringRun} Cash Secured
                  </div>
                  <div className="text-stone-400">
                    Score: {h.localUnverifiedScore} ({h.verificationLabel}) · Stones: {h.elderStonesCollected.length}/6
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeDrawer === 'skills' && (
          <div className="space-y-2 text-[10px]">
            <div className="bg-purple-950/40 border border-purple-700/50 rounded p-2">
              <div className="font-bold text-purple-200">
                Core Skill Drivers [GOLD_SOURCE_NOT_AVAILABLE]
              </div>
              <div className="text-stone-300 mt-0.5">
                Equip any found Core and Left-Click to cast immediately without learning a recipe. Charges debit only at the commit milestone (Press X or Right-Click during windup to cancel at 0 cost).
              </div>
            </div>
            {SKILLS.map((sk) => (
              <div key={sk.id} className="bg-stone-900 border border-stone-800 p-1.5 rounded">
                <div className="font-semibold text-amber-200">
                  {sk.name} · {sk.actorDamage} AoE Dmg · Windup {sk.windupMs}ms
                </div>
                <div className="text-stone-400">{sk.description}</div>
              </div>
            ))}
            <div className="bg-stone-900 border border-stone-800 p-2 rounded space-y-1">
              <div className="font-bold text-amber-300">
                Optional Six Elders ({state.run.elderStonesCollected.length}/6 Unique Stones)
              </div>
              {state.actors.elders.map((el) => {
                const bd = BOSS_MAP.get(el.definitionId);
                return (
                  <div key={el.bossId} className="flex justify-between text-stone-300">
                    <span>{bd?.name.split(',')[0]}</span>
                    <span className={el.defeated ? 'text-emerald-400' : 'text-amber-300'}>
                      {el.defeated ? '✓ Stone Claimed' : `${el.form} (${el.hp} HP)`}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeDrawer === 'menu' && (
          <div className="space-y-2 text-[10px]">
            {/* Non-omniscient Logout Preparation Summary (§9.6 / C09) */}
            <div className="bg-stone-900 border border-stone-700 rounded p-2 space-y-1">
              <div className="font-bold text-amber-300">
                Observable Shelter & Logout Status (Non-Omniscient)
              </div>
              <div>
                Shelter Enclosure:{' '}
                {isPlayerSheltered(state) ? (
                  <b className="text-emerald-400">Roofed & Walled (1 HP Hunger Floor Active)</b>
                ) : (
                  <b className="text-orange-300">Exposed Outdoors</b>
                )}
              </div>
              <div>
                Sky / Barometer ({Math.round(BALANCE.clock.forecastHorizonSeconds.value / 3600)}h est. [PROPOSED]):{' '}
                <b className="text-sky-300 capitalize">{state.clock.weather.replace('_', ' ')}</b>
              </div>
              <div>
                Visible Recent Footprints Nearby:{' '}
                <b>
                  {
                    state.world.footprints.filter(
                      (f) => Math.hypot(f.x - player.x, f.y - player.y) <= 180
                    ).length
                  }
                </b>
              </div>
              <div className="text-stone-400 italic">
                Quit is always immediate; offline simulation settles paid station fuel, crops, weather, and hazards in chronological order.
              </div>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => void gameStore.saveNow()}
                className="py-1.5 bg-emerald-800 hover:bg-emerald-700 rounded font-bold"
              >
                Save Snapshot Now
              </button>
              <button
                onClick={() => {
                  void gameStore.saveNow();
                  gameStore.setShowTitleScreen(true);
                  onClose();
                }}
                className="py-1.5 bg-stone-800 hover:bg-stone-700 rounded font-bold"
              >
                Title Screen (Keep Run)
              </button>
            </div>

            <button
              onClick={() => {
                gameStore.submitIntent({ kind: 'ABANDON_RUN' });
                onClose();
              }}
              className="w-full py-1.5 bg-red-950 hover:bg-red-900 border border-red-700/70 rounded font-bold text-red-200"
            >
              Voluntarily Abandon Current Run (Wipes Run-Local State)
            </button>

            {/* Remappable Keybindings (§4) */}
            <div className="bg-stone-900/80 border border-stone-800 rounded p-2 space-y-1">
              <div className="font-bold text-stone-300">Remappable Keybindings</div>
              <div className="grid grid-cols-2 gap-1">
                {(Object.keys(gameStore.keyBindings) as Array<keyof KeyBindings>).map((k) => (
                  <button
                    key={k}
                    onClick={() => setRemappingKey(k)}
                    className="flex justify-between bg-stone-950 px-1.5 py-0.5 rounded border border-stone-800 hover:border-amber-500"
                  >
                    <span className="capitalize text-stone-400">{k}:</span>
                    <b className="text-amber-200">
                      {remappingKey === k ? 'Press key...' : gameStore.keyBindings[k].replace('Key', '')}
                    </b>
                  </button>
                ))}
              </div>
            </div>

            {/* Dev / QA Balance & Accelerated Clock Overlay (§5 / §16) */}
            <div className="border-t border-stone-800 pt-1.5">
              <button
                onClick={() => setShowQaTab((v) => !v)}
                className="text-stone-400 hover:text-amber-300 underline"
              >
                {showQaTab ? 'Hide Dev/QA Simulation Inspector' : 'Show Dev/QA Clock & Receipt Inspector'}
              </button>
              {showQaTab && (
                <div className="mt-1.5 bg-stone-900 border border-amber-800/50 rounded p-2 space-y-1.5">
                  <div className="text-amber-300 font-semibold">
                    QA Accelerated Clock (Marks run QA / LOCAL_UNVERIFIED)
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    <button
                      onClick={() => gameStore.submitIntent({ kind: 'QA_ADVANCE_CLOCK', advanceSeconds: 3600 })}
                      className="py-1 bg-stone-800 hover:bg-stone-700 rounded"
                    >
                      +1h UTC
                    </button>
                    <button
                      onClick={() => gameStore.submitIntent({ kind: 'QA_ADVANCE_CLOCK', advanceSeconds: 86400 })}
                      className="py-1 bg-stone-800 hover:bg-stone-700 rounded"
                    >
                      +24h UTC
                    </button>
                    <button
                      onClick={() =>
                        gameStore.submitIntent({
                          kind: 'QA_ADVANCE_CLOCK',
                          advanceSeconds: Math.max(
                            60,
                            950400 - state.clock.elapsedRunSec + 60
                          ),
                        })
                      }
                      className="py-1 bg-amber-900/80 hover:bg-amber-800 rounded"
                    >
                      Jump Final 72h
                    </button>
                  </div>
                  <div className="text-[9px] text-stone-400 max-h-24 overflow-y-auto panel-scroll space-y-0.5">
                    {state.eventReceipts
                      .slice(-8)
                      .reverse()
                      .map((r) => (
                        <div key={r.receiptId}>
                          #{r.revision} [{r.actionKind}] {r.summary}
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
