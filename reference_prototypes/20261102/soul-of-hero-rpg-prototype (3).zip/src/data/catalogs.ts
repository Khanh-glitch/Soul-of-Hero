import balanceRaw from './balance.prototype.v1.json';
import itemsRaw from './items.json';
import recipesRaw from './recipes.json';
import sourcesRaw from './sources.json';
import structuresRaw from './structures.json';
import enemiesRaw from './enemies.json';
import bossesRaw from './bosses.json';
import skillsRaw from './skills.json';
import poisRaw from './pois.json';

export type ApprovalStatus =
  | 'LOCKED_CANON'
  | 'PROTOTYPE_TUNING'
  | 'PROPOSED_MECHANISM'
  | 'REQUIRES_SOURCE';

export type ItemCapability =
  | 'ACT_ON_TARGET'
  | 'USE'
  | 'EQUIP'
  | 'DEPLOY'
  | 'TRANSFER'
  | 'TRANSFORM'
  | 'RECLAIM';

export type TargetMaterial = 'wood' | 'stone' | 'ore' | 'scrap' | 'plant';

export interface ItemDefinition {
  id: string;
  name: string;
  category:
    | 'tool_weapon'
    | 'armor'
    | 'core'
    | 'material'
    | 'research'
    | 'ammo'
    | 'consumable'
    | 'credential'
    | 'blueprint'
    | 'deployable'
    | 'currency'
    | 'elder_stone';
  uniqueInstance: boolean;
  maxStack: number;
  weightKg: number;
  maxDurability?: number;
  wearPerAction?: number;
  maxCharges?: number;
  equipSlot?: 'main_hand' | 'body' | 'accessory';
  capabilities: ItemCapability[];
  actorDamage?: number;
  attackRangePx?: number;
  attackCooldownMs?: number;
  rangedProjectile?: boolean;
  harvestProfile?: Record<TargetMaterial, number>;
  armorDefense?: number;
  coldResist?: number;
  heatResist?: number;
  radResist?: number;
  speedBonus?: number;
  skillId?: string;
  studyEligible?: boolean;
  learnedRecipeId?: string;
  fuelSeconds?: number;
  repairAmount?: number;
  hungerRestore?: number;
  thirstRestore?: number;
  hpRestore?: number;
  radClear?: number;
  unlockTag?: string;
  teachesRecipes?: string[];
  deploysEntity?: string;
  deploysStructure?: string;
  requiresOwnedTerritory?: boolean;
  elderId?: string;
  description: string;
}

export interface RecipeIngredient {
  itemId: string;
  count: number;
}

export interface RecipeDefinition {
  id: string;
  name: string;
  station: 'hand' | 'campfire' | 'workbench' | 'stone_furnace' | 'research_desk' | 'garden_plot';
  starterKnown: boolean;
  researchPool?: boolean;
  workSeconds: number;
  fuelRequiredSeconds?: number;
  waterRequired?: number;
  powerRequired?: boolean;
  inputs: RecipeIngredient[];
  outputs: RecipeIngredient[];
}

export interface SourceYieldRule {
  itemId: string;
  min: number;
  max: number;
  chance: number;
}

export interface SourceDefinition {
  id: string;
  name: string;
  economy: 'NATURAL' | 'HUMAN_MADE' | 'RARE';
  material: TargetMaterial;
  maxStock: number;
  hpPerUnit: number;
  flammable: boolean;
  blocksMovement: boolean;
  blocksSight: boolean;
  respawnSeconds: number | null;
  final72Only?: boolean;
  biomes: string[];
  yields: SourceYieldRule[];
}

export interface StructureDefinition {
  id: string;
  name: string;
  category: string;
  stationClass?: string;
  maxHp: number;
  blocksMovement: boolean;
  blocksSight: boolean;
  isFloor?: boolean;
  isRoof?: boolean;
  isDoor?: boolean;
  isBed?: boolean;
  claimsTerritory?: boolean;
  containerSlots?: number;
  usesFuel?: boolean;
  requiresPower?: boolean;
  powerDrawWatts?: number;
  powerOutputWatts?: number;
  powerRadiusTiles?: number;
  turretRangePx?: number;
  turretDamage?: number;
  lightRadiusPx?: number;
  warmthBonus?: number;
  deployItemOnly?: string;
  requiresOwnedTerritory?: boolean;
  cost: RecipeIngredient[];
  reclaimRefund: RecipeIngredient[];
  description: string;
}

export interface EnemyDefinition {
  id: string;
  name: string;
  habitatBiomes: string[];
  maxHp: number;
  damage: number;
  speedPxPerSec: number;
  attackRangePx: number;
  attackCooldownMs: number;
  sightRangePx: number;
  traceSenseRangePx: number;
  canAttackStructures: boolean;
  structureDamage: number;
  respawnSeconds: number;
  drops: SourceYieldRule[];
}

export interface BossPhaseSpec {
  maxHp: number;
  damage: number;
  speedPxPerSec: number;
  telegraphMs: number;
  aoeRadiusPx: number;
  cooldownMs: number;
  terrainEffect?: string;
}

export interface BossDefinition {
  id: string;
  name: string;
  biome: string;
  stoneItemId: string;
  arenaAnchorRatio: { x: number; y: number };
  latent: BossPhaseSpec;
  awakened: BossPhaseSpec;
  palettePrimary: string;
  paletteSecondary: string;
  description: string;
}

export interface SkillDefinition {
  id: string;
  name: string;
  goldSourceStatus: 'GOLD_SOURCE_NOT_AVAILABLE';
  windupMs: number;
  commitMilestoneMs: number;
  recoveryMs: number;
  rangePx: number;
  aoeRadiusPx: number;
  actorDamage: number;
  statusApplied?: string;
  terrainMutation: 'ignite_vegetation' | 'freeze_water' | 'crack_mineral' | null;
  harvestQualityFactor: number;
  vfxColor: string;
  description: string;
}

export interface VendorStockTemplate {
  itemId: string;
  priceCash: number;
  stock: number;
  acceptsUnsecuredPhysicalCash: boolean;
  policyStatus: ApprovalStatus;
}

export interface PoiDefinition {
  id: string;
  name: string;
  anchorRatio: { x: number; y: number };
  footprintTiles: { w: number; h: number };
  outerSources: string[];
  deepGate: {
    type: 'keycard' | 'power_fuse' | 'hazard_radiation';
    requiredUnlockTag: string;
    label: string;
  } | null;
  hasPhysicalVendor: boolean;
  hasFinal72CashChest: boolean;
  final72ChestAccessibleExteriorAnnex?: boolean;
  final72CashAmount?: number;
  hasEvacuationBeacon: boolean;
  vendorStock?: VendorStockTemplate[];
  description: string;
}

export const BALANCE = balanceRaw;
export const ITEMS: ItemDefinition[] = itemsRaw as ItemDefinition[];
export const RECIPES: RecipeDefinition[] = recipesRaw as RecipeDefinition[];
export const SOURCES: SourceDefinition[] = sourcesRaw as SourceDefinition[];
export const STRUCTURES: StructureDefinition[] = structuresRaw as StructureDefinition[];
export const ENEMIES: EnemyDefinition[] = enemiesRaw as EnemyDefinition[];
export const BOSSES: BossDefinition[] = bossesRaw as BossDefinition[];
export const SKILLS: SkillDefinition[] = skillsRaw as SkillDefinition[];
export const POIS: PoiDefinition[] = poisRaw as PoiDefinition[];

export const ITEM_MAP = new Map<string, ItemDefinition>(ITEMS.map((i) => [i.id, i]));
export const RECIPE_MAP = new Map<string, RecipeDefinition>(RECIPES.map((r) => [r.id, r]));
export const SOURCE_MAP = new Map<string, SourceDefinition>(SOURCES.map((s) => [s.id, s]));
export const STRUCTURE_MAP = new Map<string, StructureDefinition>(STRUCTURES.map((s) => [s.id, s]));
export const ENEMY_MAP = new Map<string, EnemyDefinition>(ENEMIES.map((e) => [e.id, e]));
export const BOSS_MAP = new Map<string, BossDefinition>(BOSSES.map((b) => [b.id, b]));
export const SKILL_MAP = new Map<string, SkillDefinition>(SKILLS.map((s) => [s.id, s]));
export const POI_MAP = new Map<string, PoiDefinition>(POIS.map((p) => [p.id, p]));
