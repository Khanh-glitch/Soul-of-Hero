import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import { BALANCE, ITEM_MAP } from '../data/catalogs';
import {
  countItemInContainer,
  getItemsInContainer,
  grantItemToContainer,
  verifyCustodyInvariants,
} from '../sim/custody';
import { createInitialGameState, dispatchIntent } from '../sim/engine';
import {
  clearAllSavedData,
  loadGameStateAtomic,
  resetPersistenceConnectionForTests,
  saveGameStateAtomic,
  validateAndSanitizeLoadedState,
} from '../sim/persistence';
import { DeterministicRng } from '../sim/rng';
import { findTilePath, getOrCreateTopology, isTileWalkable } from '../sim/worldGen';

describe('Soul of Hero — Authoritative C01..C24, Negative Abuse (a)..(t), Property & Persistence Suite', () => {
  it('C24: All 4 safe spawn regions have stable geography, reachable starter resources, and connected road routes', () => {
    const topo1 = getOrCreateTopology();
    const topo2 = getOrCreateTopology();
    expect(topo1.biomes.length).toBe(192 * 192);
    expect(topo1.spawnRegions.length).toBeGreaterThanOrEqual(4);
    expect(topo1.biomes[5000]).toBe(topo2.biomes[5000]);

    for (let idx = 0; idx < 4; idx++) {
      const st = createInitialGameState({ gender: idx % 2 === 0 ? 'female' : 'male', spawnRegionIndex: idx, nowUtcSec: 1_700_000_000 });
      const ptx = Math.floor(st.actors.player.x / 16);
      const pty = Math.floor(st.actors.player.y / 16);
      expect(isTileWalkable(st, topo1, ptx, pty)).toBe(true);

      const nearbySources = Object.values(st.sourceStocks).filter(
        (s) => Math.hypot(s.tileX - ptx, s.tileY - pty) <= 8
      );
      const types = new Set(nearbySources.map((s) => s.definitionId));
      expect(types.has('pine_tree')).toBe(true);
      expect(types.has('stone_outcrop')).toBe(true);
      expect(types.has('berry_bush')).toBe(true);
      expect(types.has('fresh_spring')).toBe(true);
      expect(types.has('roadside_crate') || types.has('roadside_barrel')).toBe(true);
      expect(verifyCustodyInvariants(st).valid).toBe(true);
    }
  });

  it('C01, C02, C05 & (a)(b): Natural harvest, roadside salvage, tool-vs-material separation, depletion & replay rejection', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    const ptx = Math.floor(st.actors.player.x / 16);
    const pty = Math.floor(st.actors.player.y / 16);

    const tree = Object.values(st.sourceStocks).find(
      (s) => s.definitionId === 'pine_tree' && Math.hypot(s.tileX - ptx, s.tileY - pty) <= 6
    )!;
    expect(tree).toBeDefined();

    // Move next to tree
    st.actors.player.x = (tree.tileX + 1) * 16 + 8;
    st.actors.player.y = tree.tileY * 16 + 8;

    // Out-of-range harvest rejected
    const miss = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      targetWorldX: (tree.tileX + 20) * 16,
      targetWorldY: tree.tileY * 16,
    });
    expect(miss.accepted).toBe(false);

    // Harvest tree until depleted
    let guard = 0;
    while (st.sourceStocks[tree.sourceId].stock > 0 && guard < 60) {
      guard++;
      st.actors.player.attackCooldownMs = 0;
      const res = dispatchIntent(st, {
        kind: 'ACT_ON_TARGET',
        intentId: `chop_${guard}`,
        targetWorldX: tree.tileX * 16 + 8,
        targetWorldY: tree.tileY * 16 + 8,
      });
      expect(res.accepted).toBe(true);
      st = res.state;
    }
    expect(st.sourceStocks[tree.sourceId].stock).toBe(0);
    expect(countItemInContainer(st, 'player_bag', 'wood_log')).toBeGreaterThan(0);

    // (a) Repeated harvest on depleted node rejected
    st.actors.player.attackCooldownMs = 0;
    const emptyHit = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      targetWorldX: tree.tileX * 16 + 8,
      targetWorldY: tree.tileY * 16 + 8,
    });
    expect(emptyHit.accepted).toBe(false);

    // (b) Duplicate intentId replay rejected
    const replay = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      intentId: 'chop_1',
      targetWorldX: tree.tileX * 16 + 8,
      targetWorldY: tree.tileY * 16 + 8,
    });
    expect(replay.accepted).toBe(false);

    // C05: Rusty knife CANNOT mine iron_vein (harvestProfile.ore === 0), whereas stone_pickaxe CAN!
    const ironVein = Object.values(st.sourceStocks).find((s) => s.definitionId === 'iron_vein')!;
    st.actors.player.x = (ironVein.tileX + 1) * 16 + 8;
    st.actors.player.y = ironVein.tileY * 16 + 8;
    st.actors.player.attackCooldownMs = 0;

    const knifeOnOre = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      targetWorldX: ironVein.tileX * 16 + 8,
      targetWorldY: ironVein.tileY * 16 + 8,
    });
    expect(knifeOnOre.accepted).toBe(false);

    // Grant & equip stone_pickaxe and mine ore
    const rng = new DeterministicRng(42, 0);
    const pick = grantItemToContainer(st, rng, 'player_bag', 'stone_pickaxe', 1, 'test', 'rcpt_t');
    st = dispatchIntent(st, { kind: 'EQUIP_ITEM', instanceId: pick.createdInstanceIds[0] }).state;
    st.actors.player.attackCooldownMs = 0;
    const pickOnOre1 = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      targetWorldX: ironVein.tileX * 16 + 8,
      targetWorldY: ironVein.tileY * 16 + 8,
    });
    expect(pickOnOre1.accepted).toBe(true);
    st = pickOnOre1.state;
    st.actors.player.attackCooldownMs = 0;
    const pickOnOre2 = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      targetWorldX: ironVein.tileX * 16 + 8,
      targetWorldY: ironVein.tileY * 16 + 8,
    });
    expect(pickOnOre2.accepted).toBe(true);
    expect(countItemInContainer(pickOnOre2.state, 'player_bag', 'iron_ore')).toBeGreaterThan(0);

    // C02: Roadside crate yields salvage / Spares
    const crate = Object.values(st.sourceStocks).find((s) => s.definitionId === 'roadside_crate' && s.stock > 0)!;
    st = pickOnOre2.state;
    st.actors.player.x = (crate.tileX + 1) * 16 + 8;
    st.actors.player.y = crate.tileY * 16 + 8;
    for (let i = 0; i < 6 && st.sourceStocks[crate.sourceId].stock > 0; i++) {
      st.actors.player.attackCooldownMs = 0;
      const r = dispatchIntent(st, {
        kind: 'ACT_ON_TARGET',
        targetWorldX: crate.tileX * 16 + 8,
        targetWorldY: crate.tileY * 16 + 8,
      });
      if (r.accepted) st = r.state;
    }
    expect(st.sourceStocks[crate.sourceId].stock).toBe(0);
  });

  it('C03, C05 & (l): Charged Core immediate cast without recipe, 0-cost pre-commit cancel, committed charge debit & water freeze mutation', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    const topo = getOrCreateTopology(st.world.seed);
    const rng = new DeterministicRng(99, 0);

    // Find a shallow_water tile and stand adjacent on coast
    let waterTx = -1;
    let waterTy = -1;
    let standTx = -1;
    let standTy = -1;
    outer: for (let y = 20; y < 170; y++) {
      for (let x = 20; x < 170; x++) {
        if (topo.biomes[y * topo.width + x] === 'shallow_water' && topo.biomes[y * topo.width + x + 1] === 'coast') {
          waterTx = x;
          waterTy = y;
          standTx = x + 1;
          standTy = y;
          break outer;
        }
      }
    }
    expect(waterTx).toBeGreaterThan(0);
    st.actors.player.x = standTx * 16 + 8;
    st.actors.player.y = standTy * 16 + 8;

    const coreGrant = grantItemToContainer(st, rng, 'player_bag', 'core_frost_pulse', 1, 'reliquary', 'rcpt_core');
    const coreId = coreGrant.createdInstanceIds[0];
    const startCharges = st.inventory.items[coreId].charges!;
    expect(startCharges).toBe(6);

    // Start cast WITHOUT learning any recipe
    const startRes = dispatchIntent(st, {
      kind: 'START_CORE_CAST',
      coreInstanceId: coreId,
      targetWorldX: waterTx * 16 + 8,
      targetWorldY: waterTy * 16 + 8,
    });
    expect(startRes.accepted).toBe(true);
    st = startRes.state;
    // Charge NOT yet debited during windup!
    expect(st.inventory.items[coreId].charges).toBe(6);

    // Cancel before commit milestone -> 0 charge spent!
    const cancelRes = dispatchIntent(st, { kind: 'CANCEL_CORE_CAST' });
    expect(cancelRes.accepted).toBe(true);
    st = cancelRes.state;
    expect(st.inventory.items[coreId].charges).toBe(6);

    // Now cast to full commit milestone (280ms windup)
    st = dispatchIntent(st, {
      kind: 'START_CORE_CAST',
      coreInstanceId: coreId,
      targetWorldX: waterTx * 16 + 8,
      targetWorldY: waterTy * 16 + 8,
    }).state;
    st = dispatchIntent(st, {
      kind: 'STEP_SIMULATION',
      dtSec: 0.25,
      nowUtcSec: st.clock.lastSimulatedUtcSec,
      moveDx: 0,
      moveDy: 0,
      sprint: false,
    }).state;
    st = dispatchIntent(st, {
      kind: 'STEP_SIMULATION',
      dtSec: 0.1,
      nowUtcSec: st.clock.lastSimulatedUtcSec,
      moveDx: 0,
      moveDy: 0,
      sprint: false,
    }).state;

    // 1 charge spent & shallow_water tile frozen into walkable ice bridge (even for hand-cart!)
    expect(st.inventory.items[coreId].charges).toBe(5);
    expect(isTileWalkable(st, topo, waterTx, waterTy, { forCart: true })).toBe(true);
  });

  it('C04 & (f): Four research methods write to single run.learnedRecipeIds; duplicate/depleted specimen blocked', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    const rng = new DeterministicRng(123, 0);
    const ptx = Math.floor(st.actors.player.x / 16);
    const pty = Math.floor(st.actors.player.y / 16);

    // Place a Research Desk adjacent to player
    grantItemToContainer(st, rng, 'player_bag', 'wood_plank', 10, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'scrap_metal', 6, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'electronic_parts', 4, 't', 'r');
    const buildDesk = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'research_desk',
      tileX: ptx + 1,
      tileY: pty,
    });
    expect(buildDesk.accepted).toBe(true);
    st = buildDesk.state;
    const deskId = Object.values(st.entities.structures).find((s) => s.definitionId === 'research_desk')!.structureId;

    // 1. Blueprint study
    const bp = grantItemToContainer(st, rng, 'player_bag', 'blueprint_hand_cart', 1, 't', 'r').createdInstanceIds[0];
    const bpRes = dispatchIntent(st, { kind: 'USE_ITEM', instanceId: bp });
    expect(bpRes.accepted).toBe(true);
    st = bpRes.state;
    expect(st.research.learnedRecipeIds).toContain('rcp_hand_cart_kit');

    // Duplicate blueprint rejected without consuming second copy
    const bp2 = grantItemToContainer(st, rng, 'player_bag', 'blueprint_hand_cart', 1, 't', 'r').createdInstanceIds[0];
    const dupBp = dispatchIntent(st, { kind: 'USE_ITEM', instanceId: bp2 });
    expect(dupBp.accepted).toBe(false);
    expect(st.inventory.items[bp2]).toBeDefined();

    // 2. Random Spares discovery
    grantItemToContainer(st, rng, 'player_bag', 'spares_token', 20, 't', 'r');
    const beforeCount = st.research.learnedRecipeIds.length;
    const randRes = dispatchIntent(st, {
      kind: 'RESEARCH_ACTION',
      stationStructureId: deskId,
      mode: 'random_spares',
    });
    expect(randRes.accepted).toBe(true);
    st = randRes.state;
    expect(st.research.learnedRecipeIds.length).toBe(beforeCount + 1);

    // 3. Directed Spares study
    const dirRes = dispatchIntent(st, {
      kind: 'RESEARCH_ACTION',
      stationStructureId: deskId,
      mode: 'directed_spares',
      targetRecipeId: 'rcp_lead_hazmat_suit',
    });
    expect(dirRes.accepted).toBe(true);
    st = dirRes.state;
    expect(st.research.learnedRecipeIds).toContain('rcp_lead_hazmat_suit');

    // 4. Specimen study: depleted 0-charge Core rejected (PROPOSED_MECHANISM), charged Core succeeds once!
    const depletedCore = grantItemToContainer(
      st,
      rng,
      'player_bag',
      'core_ember_spark',
      1,
      't',
      'r',
      { charges: 0 }
    ).createdInstanceIds[0];
    const depStudy = dispatchIntent(st, {
      kind: 'RESEARCH_ACTION',
      stationStructureId: deskId,
      mode: 'specimen_study',
      specimenInstanceId: depletedCore,
    });
    expect(depStudy.accepted).toBe(false);
    expect(st.inventory.items[depletedCore]).toBeDefined();

    const chargedCore = grantItemToContainer(
      st,
      rng,
      'player_bag',
      'core_ember_spark',
      1,
      't',
      'r',
      { charges: 3 }
    ).createdInstanceIds[0];
    const okStudy = dispatchIntent(st, {
      kind: 'RESEARCH_ACTION',
      stationStructureId: deskId,
      mode: 'specimen_study',
      specimenInstanceId: chargedCore,
    });
    expect(okStudy.accepted).toBe(true);
    st = okStudy.state;
    expect(st.inventory.items[chargedCore]).toBeUndefined();
    expect(st.research.learnedRecipeIds).toContain('rcp_core_ember_wand');
  });

  it('C06, C09 & (g)(h)(i): Furnace running 2h offline with 15m fuel stops at fuel exhaustion; shelter 1-HP floor vs lethal cold', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    const rng = new DeterministicRng(77, 0);
    const ptx = Math.floor(st.actors.player.x / 16);
    const pty = Math.floor(st.actors.player.y / 16);

    // Build walled + roofed shelter & furnace around player
    grantItemToContainer(st, rng, 'player_bag', 'wood_log', 40, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'wood_plank', 30, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'plant_fiber', 30, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'stone_chunk', 25, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'scrap_metal', 10, 't', 'r');

    st = dispatchIntent(st, { kind: 'BUILD_STRUCTURE', structureDefId: 'thatch_roof', tileX: ptx, tileY: pty }).state;
    st = dispatchIntent(st, { kind: 'BUILD_STRUCTURE', structureDefId: 'wood_wall', tileX: ptx - 1, tileY: pty }).state;
    st = dispatchIntent(st, { kind: 'BUILD_STRUCTURE', structureDefId: 'wood_wall', tileX: ptx + 1, tileY: pty }).state;
    st = dispatchIntent(st, { kind: 'BUILD_STRUCTURE', structureDefId: 'wood_wall', tileX: ptx, tileY: pty - 1 }).state;
    st = dispatchIntent(st, { kind: 'BUILD_STRUCTURE', structureDefId: 'stone_furnace', tileX: ptx, tileY: pty + 1 }).state;

    const furnaceId = Object.values(st.entities.structures).find((s) => s.definitionId === 'stone_furnace')!.structureId;

    // Load EXACTLY 15 minutes (900s = 10 wood_log * 90s) of fuel into furnace
    const fuelLogs = Object.values(st.inventory.items).find((i) => i.definitionId === 'wood_log')!;
    st = dispatchIntent(st, {
      kind: 'ADD_STATION_FUEL',
      structureId: furnaceId,
      fuelInstanceId: fuelLogs.instanceId,
      count: 10,
    }).state;
    expect(st.entities.structures[furnaceId].fuelRemainingSec).toBe(900);

    // Queue 25 iron ingots (25 * 60s = 1500s work > 900s fuel!)
    grantItemToContainer(st, rng, 'player_bag', 'iron_ore', 30, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'iron_ore', 20, 't', 'r');
    for (let i = 0; i < 25; i++) {
      const q = dispatchIntent(st, {
        kind: 'QUEUE_RECIPE_JOB',
        stationStructureId: furnaceId,
        recipeId: 'rcp_smelt_iron',
      });
      expect(q.accepted).toBe(true);
      st = q.state;
    }

    // Simulate 2 hours (7200s) offline! Furnace MUST produce 15 ingots (900s / 60s) and pause remaining 10 jobs!
    const catchup = dispatchIntent(st, {
      kind: 'OFFLINE_CATCHUP',
      nowUtcSec: st.clock.lastSimulatedUtcSec + 7200,
    });
    expect(catchup.accepted).toBe(true);
    st = catchup.state;

    expect(st.entities.structures[furnaceId].fuelRemainingSec).toBe(0);
    expect(countItemInContainer(st, `station_out:${furnaceId}`, 'iron_ingot')).toBe(15);
    const remainingJobs = Object.values(st.jobs);
    expect(remainingJobs.length).toBe(10);
    expect(remainingJobs.every((j) => j.status === 'paused_no_fuel')).toBe(true);

    // C09: Offline hunger-only starvation inside valid shelter stops at 1 HP floor over 60h!
    st.actors.player.hunger = 0;
    st.actors.player.thirst = 0;
    st = dispatchIntent(st, {
      kind: 'OFFLINE_CATCHUP',
      nowUtcSec: st.clock.lastSimulatedUtcSec + 60 * 3600,
    }).state;
    expect(st.actors.player.hp).toBe(1);
    expect(st.actors.player.deathsCount).toBe(0);

    // However, freezing in alpine cold biome offline IS lethal (not global immortality!)
    const topo = getOrCreateTopology(st.world.seed);
    const coldIdx = topo.biomes.findIndex((b) => b === 'cold');
    st.actors.player.x = (coldIdx % topo.width) * 16 + 8;
    st.actors.player.y = Math.floor(coldIdx / topo.width) * 16 + 8;
    st = dispatchIntent(st, {
      kind: 'OFFLINE_CATCHUP',
      nowUtcSec: st.clock.lastSimulatedUtcSec + 1800,
    }).state;
    expect(st.actors.player.deathsCount).toBe(1);
  });

  it('C07, C08, C10 & (c)(d)(j)(k): Invalid build rollback, loaded chest reclaim refusal, dynamic door A* pathing, footprint decay vs monster tracking, and unique Death Bag recovery', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    const topo = getOrCreateTopology(st.world.seed);
    const rng = new DeterministicRng(555, 0);
    const ptx = Math.floor(st.actors.player.x / 16);
    const pty = Math.floor(st.actors.player.y / 16);

    // (c) Invalid build on deep_sea debits 0 materials and creates 0 structures
    grantItemToContainer(st, rng, 'player_bag', 'wood_plank', 12, 't', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'scrap_metal', 4, 't', 'r');
    const strCountBefore = Object.keys(st.entities.structures).length;
    const badBuild = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'wooden_chest',
      tileX: 1,
      tileY: 1,
    });
    expect(badBuild.accepted).toBe(false);
    expect(Object.keys(badBuild.state.entities.structures).length).toBe(strCountBefore);
    expect(countItemInContainer(badBuild.state, 'player_bag', 'wood_plank')).toBe(12);

    // Build chest + door and test loaded chest reclaim denial (d)
    st = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'wooden_chest',
      tileX: ptx + 1,
      tileY: pty,
    }).state;
    const chestId = Object.values(st.entities.structures).find((s) => s.definitionId === 'wooden_chest')!.structureId;

    const knife = getItemsInContainer(st, 'player_equip:main_hand')[0];
    const knifeOriginalId = knife.instanceId;
    st = dispatchIntent(st, {
      kind: 'TRANSFER_ITEM',
      instanceId: knifeOriginalId,
      toContainerId: `structure:${chestId}`,
    }).state;
    expect(st.inventory.items[knifeOriginalId].containerId).toBe(`structure:${chestId}`);

    // Reclaiming loaded chest MUST be refused with 0 item loss!
    const loadedReclaim = dispatchIntent(st, { kind: 'RECLAIM_STRUCTURE', structureId: chestId });
    expect(loadedReclaim.accepted).toBe(false);
    expect(loadedReclaim.state.inventory.items[knifeOriginalId]).toBeDefined();

    // Take knife back -> reclaim now succeeds
    st = dispatchIntent(st, {
      kind: 'TRANSFER_ITEM',
      instanceId: knifeOriginalId,
      toContainerId: 'player_bag',
    }).state;
    const cleanReclaim = dispatchIntent(st, { kind: 'RECLAIM_STRUCTURE', structureId: chestId });
    expect(cleanReclaim.accepted).toBe(true);
    st = cleanReclaim.state;

    // Door updates A* navigation immediately
    st = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'wood_door',
      tileX: ptx + 1,
      tileY: pty,
    }).state;
    const doorId = Object.values(st.entities.structures).find((s) => s.definitionId === 'wood_door')!.structureId;
    expect(isTileWalkable(st, topo, ptx + 1, pty)).toBe(false);
    st = dispatchIntent(st, { kind: 'TOGGLE_DOOR', structureId: doorId }).state;
    expect(isTileWalkable(st, topo, ptx + 1, pty)).toBe(true);
    expect(findTilePath(st, topo, ptx, pty, ptx + 2, pty).length).toBeGreaterThan(0);

    // (j) & (k) C08: Monster near home WITHOUT footprint trail never targets home; rain washes footprints away!
    const hound = st.actors.enemies[0];
    hound.x = (ptx + 12) * 16; // outside sightRange (135px < 192px)
    hound.y = pty * 16;
    hound.homeX = hound.x;
    hound.homeY = hound.y;
    st.world.footprints = [];
    st = dispatchIntent(st, {
      kind: 'STEP_SIMULATION',
      dtSec: 0.2,
      nowUtcSec: st.clock.lastSimulatedUtcSec,
      moveDx: 0,
      moveDy: 0,
      sprint: false,
    }).state;
    expect(st.actors.enemies[0].aiState).toBe('patrol');

    // Emit footprints then trigger rain storm -> footprints erode & disappear
    st = dispatchIntent(st, {
      kind: 'STEP_SIMULATION',
      dtSec: 0.25,
      nowUtcSec: st.clock.lastSimulatedUtcSec,
      moveDx: 1,
      moveDy: 0,
      sprint: true,
    }).state;
    expect(st.world.footprints.length).toBeGreaterThan(0);
    st.clock.weather = 'storm';
    st = dispatchIntent(st, {
      kind: 'OFFLINE_CATCHUP',
      nowUtcSec: st.clock.lastSimulatedUtcSec + 300,
    }).state;
    expect(st.world.footprints.length).toBe(0);

    // C10: Death moves carried items to ONE UUID Death Bag conserving knifeOriginalId, respawns in same run, and recovers cleanly
    st.actors.player.hp = 1;
    st.actors.enemies[0].x = st.actors.player.x + 8;
    st.actors.enemies[0].y = st.actors.player.y;
    st = dispatchIntent(st, {
      kind: 'STEP_SIMULATION',
      dtSec: 0.1,
      nowUtcSec: st.clock.lastSimulatedUtcSec,
      moveDx: 0,
      moveDy: 0,
      sprint: false,
    }).state;
    expect(st.run.active).toBe(true);
    expect(st.actors.player.deathsCount).toBe(1);
    const bags = Object.values(st.entities.deathBags);
    expect(bags.length).toBe(1);
    expect(st.inventory.items[knifeOriginalId].containerId).toBe(`death_bag:${bags[0].bagId}`);

    // Walk back to Death Bag and recover
    st.actors.player.x = bags[0].x;
    st.actors.player.y = bags[0].y;
    const rec = dispatchIntent(st, { kind: 'RECOVER_DEATH_BAG', bagId: bags[0].bagId });
    expect(rec.accepted).toBe(true);
    st = rec.state;
    expect(st.inventory.items[knifeOriginalId].containerId).toBe('player_bag');
    expect(Object.keys(st.entities.deathBags).length).toBe(0);
  });

  it('C11, C13 & (m)(n): POI locked deep gate vs outer salvage + Hand-Cart freight conservation & terrain rules', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    const rng = new DeterministicRng(808, 0);

    // C11: Refinery deep gate starts locked; outer lockers work immediately; keycard unlocks deep gate
    const refinery = st.world.pois['rust_refinery'];
    expect(refinery.gateUnlocked).toBe(false);
    st.actors.player.x = refinery.gateTile!.x * 16 - 16;
    st.actors.player.y = refinery.gateTile!.y * 16 + 8;

    const noKey = dispatchIntent(st, { kind: 'UNLOCK_POI_GATE', poiId: 'rust_refinery' });
    expect(noKey.accepted).toBe(false);

    grantItemToContainer(st, rng, 'player_bag', 'industrial_keycard', 1, 'locker', 'r');
    const withKey = dispatchIntent(st, { kind: 'UNLOCK_POI_GATE', poiId: 'rust_refinery' });
    expect(withKey.accepted).toBe(true);
    st = withKey.state;
    expect(st.world.pois['rust_refinery'].gateUnlocked).toBe(true);

    // C13: Deploy Hand-Cart on road, transfer heavy iron ore into cart, verify weight relief & conservation
    const market = st.world.pois['abandoned_market'];
    st.actors.player.x = market.centerX + 24;
    st.actors.player.y = market.centerY + 24;
    const cartKitId = grantItemToContainer(st, rng, 'player_bag', 'hand_cart_kit', 1, 'craft', 'r')
      .createdInstanceIds[0];
    const depCart = dispatchIntent(st, {
      kind: 'DEPLOY_CART',
      cartKitInstanceId: cartKitId,
      tileX: Math.floor(st.actors.player.x / 16) + 1,
      tileY: Math.floor(st.actors.player.y / 16),
    });
    expect(depCart.accepted).toBe(true);
    st = depCart.state;
    const cartId = Object.keys(st.entities.carts)[0];

    const oreId = grantItemToContainer(st, rng, 'player_bag', 'iron_ore', 25, 'quarry', 'r').createdInstanceIds[0];
    const loadRes = dispatchIntent(st, {
      kind: 'TRANSFER_ITEM',
      instanceId: oreId,
      toContainerId: `cart:${cartId}`,
    });
    expect(loadRes.accepted).toBe(true);
    st = loadRes.state;
    expect(countItemInContainer(st, `cart:${cartId}`, 'iron_ore')).toBe(25);
    expect(countItemInContainer(st, 'player_bag', 'iron_ore')).toBe(0);

    // Folding non-empty cart is refused!
    expect(dispatchIntent(st, { kind: 'PACK_CART', cartId }).accepted).toBe(false);
  });

  it('C15..C23 & QA-A06 & (o)..(t): Full Zero-Wallet No-Elder Ragnarok First Escrow -> Deposit Idempotency -> Evacuation -> Run 2 Wipe & Vendor Spend -> Tamper Rejection', () => {
    let st = createInitialGameState({ spawnRegionIndex: 1, nowUtcSec: 1_700_000_000 });
    expect(st.profile.securedCash).toBe(0);

    // (o) C15: Final72 chest at Rust Refinery annex is SEALED before 950,400s!
    const finChest = Object.values(st.sourceStocks).find(
      (s) => s.definitionId === 'ragnarok_treasury_chest' && s.poiId === 'rust_refinery'
    )!;
    expect(finChest).toBeDefined();
    st.actors.player.x = (finChest.tileX + 1) * 16 + 8;
    st.actors.player.y = finChest.tileY * 16 + 8;

    const earlyAttempt = dispatchIntent(st, {
      kind: 'ACT_ON_TARGET',
      targetWorldX: finChest.tileX * 16 + 8,
      targetWorldY: finChest.tileY * 16 + 8,
    });
    expect(earlyAttempt.accepted).toBe(false);

    // Advance QA clock to Final 72h Ragnarok (950,460s elapsed) — ZERO Elders fought!
    st = dispatchIntent(st, { kind: 'QA_ADVANCE_CLOCK', advanceSeconds: 950_460 }).state;
    expect(st.clock.phase).toBe('ragnarok_final72');
    expect(st.actors.elders.every((e) => !e.defeated)).toBe(true);

    // Harvest Rust Refinery annex Final72 Cash Chest (195 physical Ragnarok Cash)
    st.actors.player.x = (finChest.tileX + 1) * 16 + 8;
    st.actors.player.y = finChest.tileY * 16 + 8;
    while (st.sourceStocks[finChest.sourceId].stock > 0) {
      st.actors.player.attackCooldownMs = 0;
      const r = dispatchIntent(st, {
        kind: 'ACT_ON_TARGET',
        targetWorldX: finChest.tileX * 16 + 8,
        targetWorldY: finChest.tileY * 16 + 8,
      });
      expect(r.accepted).toBe(true);
      st = r.state;
    }
    const lootedCash = countItemInContainer(st, 'player_bag', 'ragnarok_cash');
    expect(lootedCash).toBe(195);

    // Verify finite Final72 chest NEVER respawns even after +36h (and if player starved outdoors, recover cash from physical Death Bag!)
    st = dispatchIntent(st, { kind: 'QA_ADVANCE_CLOCK', advanceSeconds: 36 * 3600 }).state;
    expect(st.sourceStocks[finChest.sourceId].stock).toBe(0);
    const cashBag = Object.values(st.entities.deathBags).find(
      (b) => countItemInContainer(st, `death_bag:${b.bagId}`, 'ragnarok_cash') > 0
    );
    if (cashBag) {
      // Proves §14: dying before deposit drops physical cash into Death Bag rather than vanishing or auto-securing!
      expect(countItemInContainer(st, `death_bag:${cashBag.bagId}`, 'ragnarok_cash')).toBe(195);
      st.actors.player.x = cashBag.x;
      st.actors.player.y = cashBag.y;
      st = dispatchIntent(st, { kind: 'RECOVER_DEATH_BAG', bagId: cashBag.bagId }).state;
    }
    expect(countItemInContainer(st, 'player_bag', 'ragnarok_cash')).toBe(195);

    // (p) C16: Walk to Wayfarer Trader at Crossroads Market and buy Escrow Chest for 120 unsecured physical cash (PROPOSED_MECHANISM)
    const market = st.world.pois['abandoned_market'];
    st.actors.player.x = market.vendorTile!.x * 16 + 8;
    st.actors.player.y = (market.vendorTile!.y + 1) * 16 + 8;

    const buyChest = dispatchIntent(st, {
      kind: 'VENDOR_BUY',
      poiId: 'abandoned_market',
      itemId: 'escrow_chest_item',
      payWithUnsecuredBagCash: true,
    });
    expect(buyChest.accepted).toBe(true);
    st = buyChest.state;
    expect(countItemInContainer(st, 'player_bag', 'ragnarok_cash')).toBe(75); // 195 - 120 = +75 positive net!
    expect(countItemInContainer(st, 'player_bag', 'escrow_chest_item')).toBe(1);

    // Pick clean walkable safe-spawn clearing tiles (spawn 1 is at 74, 148)
    st.actors.player.x = 74 * 16 + 8;
    st.actors.player.y = 148 * 16 + 8;
    // Deploying Escrow Chest on UNOWNED wilds MUST fail without losing escrow_chest_item!
    const unownedPlace = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'escrow_chest',
      tileX: 75,
      tileY: 148,
    });
    expect(unownedPlace.accepted).toBe(false);
    expect(countItemInContainer(unownedPlace.state, 'player_bag', 'escrow_chest_item')).toBe(1);

    // Build Homestead Claim Totem (6 wood + 4 stone), then deploy Escrow Chest on owned Homestead land!
    const rng = new DeterministicRng(333, 0);
    grantItemToContainer(st, rng, 'player_bag', 'wood_log', 6, 'tree', 'r');
    grantItemToContainer(st, rng, 'player_bag', 'stone_chunk', 4, 'rock', 'r');
    st = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'homestead_claim_totem',
      tileX: 74,
      tileY: 147,
    }).state;

    const ownedPlace = dispatchIntent(st, {
      kind: 'BUILD_STRUCTURE',
      structureDefId: 'escrow_chest',
      tileX: 75,
      tileY: 148,
    });
    expect(ownedPlace.accepted).toBe(true);
    st = ownedPlace.state;
    const escrowId = Object.values(st.entities.structures).find((s) => s.definitionId === 'escrow_chest')!.structureId;

    // (q) C17: Deposit 60 cash -> Profile Secured Cash becomes +60; leave 15 cash undeclared in bag to test C22 evacuation non-auto-deposit!
    const dep1 = dispatchIntent(st, {
      kind: 'DEPOSIT_ESCROW',
      escrowStructureId: escrowId,
      amount: 60,
      clientDepositToken: 'dep_tok_1',
    });
    expect(dep1.accepted).toBe(true);
    st = dep1.state;
    expect(st.profile.securedCash).toBe(60);
    expect(countItemInContainer(st, 'player_bag', 'ragnarok_cash')).toBe(15);

    // Duplicate deposit token replay rejected idempotently!
    const depDup = dispatchIntent(st, {
      kind: 'DEPOSIT_ESCROW',
      escrowStructureId: escrowId,
      amount: 15,
      clientDepositToken: 'dep_tok_1',
    });
    expect(depDup.accepted).toBe(false);
    expect(depDup.state.profile.securedCash).toBe(60);

    // (r) C22: Travel to Sunken Harbor Evacuation Beacon and physically evacuate
    const harbor = st.world.pois['sunken_harbor'];
    st.actors.player.x = harbor.evacTile!.x * 16 + 8;
    st.actors.player.y = (harbor.evacTile!.y + 1) * 16 + 8;
    const evac = dispatchIntent(st, { kind: 'EVACUATE_RUN', poiId: 'sunken_harbor' });
    expect(evac.accepted).toBe(true);
    st = evac.state;
    expect(st.run.active).toBe(false);
    expect(st.run.endedReason).toBe('evacuated');
    // Undeclared 15 bag cash was NOT auto-deposited — wiped!
    expect(st.profile.securedCash).toBe(60);
    expect(st.profile.runHistory[0].unsecuredCashLostOnEnd).toBe(15);
    expect(st.profile.runHistory[0].verificationLabel).toBe('LOCAL_UNVERIFIED');

    // Second finalize rejected!
    expect(dispatchIntent(st, { kind: 'ABANDON_RUN' }).accepted).toBe(false);

    // (s) C23 & C18: Start Run 2 -> all structures/items/recipes wiped, profile 60 cash persists & buys run-local tool at physical vendor!
    const run2 = dispatchIntent(st, {
      kind: 'START_NEW_RUN',
      gender: 'male',
      spawnRegionIndex: 2,
      nowUtcSec: 1_701_500_000,
    });
    expect(run2.accepted).toBe(true);
    st = run2.state;
    expect(st.run.active).toBe(true);
    expect(st.profile.securedCash).toBe(60);
    expect(
      Object.values(st.entities.structures).some((s) => s.ownerId === st.actors.player.actorId)
    ).toBe(false);

    // Spend 25 secured cash at Crossroads Wayfarer Trader for a run-local Healing Salve
    const m2 = st.world.pois['abandoned_market'];
    st.actors.player.x = m2.vendorTile!.x * 16 + 8;
    st.actors.player.y = (m2.vendorTile!.y + 1) * 16 + 8;
    const vBuy = dispatchIntent(st, {
      kind: 'VENDOR_BUY',
      poiId: 'abandoned_market',
      itemId: 'healing_salve',
    });
    expect(vBuy.accepted).toBe(true);
    st = vBuy.state;
    expect(st.profile.securedCash).toBe(35);
    expect(countItemInContainer(st, 'player_bag', 'healing_salve')).toBe(1);

    // (t) C21: Tampered local save claiming VERIFIED_WORLDWIDE or million score is refused!
    const tampered = structuredClone(st);
    (tampered.profile.runHistory[0] as unknown as { verificationLabel: string }).verificationLabel =
      'VERIFIED_WORLDWIDE';
    expect(validateAndSanitizeLoadedState(tampered).valid).toBe(false);

    const tamperedScore = structuredClone(st);
    tamperedScore.profile.runHistory[0].localUnverifiedScore = 9_999_999;
    expect(validateAndSanitizeLoadedState(tamperedScore).valid).toBe(false);
  });

  it('C19 & C20: Six distinct Elders awaken on Day 14, drop unique Elder Stones once, and unlock six_stone_convergence ending', () => {
    let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
    expect(st.actors.elders.length).toBe(BALANCE.economyAndTerritory.elderCount.value);

    // Advance to Day 14 (1,123,260s) -> all 6 Elders awaken!
    st = dispatchIntent(st, { kind: 'QA_ADVANCE_CLOCK', advanceSeconds: 1_123_260 }).state;
    expect(st.clock.phase).toBe('ragnarok_day14_elders');
    expect(st.actors.elders.every((e) => e.form === 'awakened')).toBe(true);

    // Equip heavy cleaver and defeat all 6 optional Elders
    const rng = new DeterministicRng(909, 0);
    const cleaverId = grantItemToContainer(st, rng, 'player_bag', 'steel_cleaver', 1, 't', 'r', {
      durability: 9999,
    }).createdInstanceIds[0];
    st = dispatchIntent(st, { kind: 'EQUIP_ITEM', instanceId: cleaverId }).state;

    for (const elderId of st.actors.elders.map((e) => e.bossId)) {
      const target = st.actors.elders.find((e) => e.bossId === elderId)!;
      st.actors.player.x = target.x + 16;
      st.actors.player.y = target.y;
      while (!st.actors.elders.find((e) => e.bossId === elderId)!.defeated) {
        st.actors.player.attackCooldownMs = 0;
        const curElder = st.actors.elders.find((e) => e.bossId === elderId)!;
        const hit = dispatchIntent(st, {
          kind: 'ACT_ON_TARGET',
          targetWorldX: curElder.x,
          targetWorldY: curElder.y,
        });
        expect(hit.accepted).toBe(true);
        st = hit.state;
      }
    }

    expect(st.run.elderStonesCollected.length).toBe(6);
    expect(new Set(st.run.elderStonesCollected).size).toBe(6);

    // Evacuate with all 6 unique Elder Stones -> six_stone_convergence ending!
    const harbor = st.world.pois['sunken_harbor'];
    st.actors.player.x = harbor.evacTile!.x * 16 + 8;
    st.actors.player.y = (harbor.evacTile!.y + 1) * 16 + 8;
    st = dispatchIntent(st, { kind: 'EVACUATE_RUN', poiId: 'sunken_harbor' }).state;
    expect(st.run.endedReason).toBe('six_stone_convergence');
  });

  it('Property-based (fast-check): Arbitrary sequences of custody transfers, stack splits, equips & unequips strictly conserve items & unique IDs', () => {
    fc.assert(
      fc.property(
        fc.array(
          fc.record({
            op: fc.constantFrom('split', 'transfer_to_chest', 'transfer_to_bag', 'equip', 'unequip'),
            idx: fc.integer({ min: 0, max: 6 }),
            splitAmt: fc.integer({ min: 1, max: 5 }),
          }),
          { minLength: 15, maxLength: 45 }
        ),
        (ops) => {
          let st = createInitialGameState({ spawnRegionIndex: 0, nowUtcSec: 1_700_000_000 });
          const rng = new DeterministicRng(1010, 0);
          const ptx = Math.floor(st.actors.player.x / 16);
          const pty = Math.floor(st.actors.player.y / 16);

          grantItemToContainer(st, rng, 'player_bag', 'wood_plank', 12, 't', 'r');
          grantItemToContainer(st, rng, 'player_bag', 'scrap_metal', 4, 't', 'r');
          st = dispatchIntent(st, {
            kind: 'BUILD_STRUCTURE',
            structureDefId: 'wooden_chest',
            tileX: ptx + 1,
            tileY: pty,
          }).state;
          const chestId = Object.values(st.entities.structures).find(
            (s) => s.definitionId === 'wooden_chest'
          )!.structureId;

          const hatchetId = grantItemToContainer(st, rng, 'player_bag', 'stone_hatchet', 1, 't', 'r')
            .createdInstanceIds[0];
          grantItemToContainer(st, rng, 'player_bag', 'iron_ore', 16, 't', 'r');

          const totalCountOf = (defId: string) =>
            Object.values(st.inventory.items)
              .filter((i) => i.definitionId === defId)
              .reduce((a, b) => a + b.count, 0);

          const initialOre = totalCountOf('iron_ore');
          const initialHatchets = totalCountOf('stone_hatchet');

          for (const step of ops) {
            const allItems = Object.values(st.inventory.items);
            const target = allItems[step.idx % allItems.length];
            if (!target) continue;

            if (step.op === 'split') {
              st = dispatchIntent(st, {
                kind: 'SPLIT_STACK',
                instanceId: target.instanceId,
                splitCount: step.splitAmt,
              }).state;
            } else if (step.op === 'transfer_to_chest') {
              st = dispatchIntent(st, {
                kind: 'TRANSFER_ITEM',
                instanceId: target.instanceId,
                toContainerId: `structure:${chestId}`,
              }).state;
            } else if (step.op === 'transfer_to_bag') {
              st = dispatchIntent(st, {
                kind: 'TRANSFER_ITEM',
                instanceId: target.instanceId,
                toContainerId: 'player_bag',
              }).state;
            } else if (step.op === 'equip') {
              st = dispatchIntent(st, { kind: 'EQUIP_ITEM', instanceId: target.instanceId }).state;
            } else if (step.op === 'unequip') {
              st = dispatchIntent(st, { kind: 'UNEQUIP_ITEM', equipSlot: 'main_hand' }).state;
            }

            const invCheck = verifyCustodyInvariants(st);
            expect(invCheck.valid).toBe(true);
            expect(totalCountOf('iron_ore')).toBe(initialOre);
            expect(totalCountOf('stone_hatchet')).toBe(initialHatchets);
            expect(st.inventory.items[hatchetId]).toBeDefined();
          }

          // Verify all definitions exist
          for (const item of Object.values(st.inventory.items)) {
            expect(ITEM_MAP.has(item.definitionId)).toBe(true);
          }
        }
      ),
      { numRuns: 25 }
    );
  });

  it('Persistence (§6): Cross-session IndexedDB atomic save, connection close, reopen & offline catch-up conserves unique IDs & receipts', async () => {
    await clearAllSavedData();
    let st = createInitialGameState({ spawnRegionIndex: 3, nowUtcSec: 1_700_000_000 });
    const knifeBefore = getItemsInContainer(st, 'player_equip:main_hand')[0].instanceId;

    // Unlock a POI gate and save atomically to IndexedDB
    st.world.pois['research_outpost'].gateUnlocked = true;
    await saveGameStateAtomic(st, 'primary');

    // Simulate closing browser tab and opening a brand-new IndexedDB connection 1800s later
    resetPersistenceConnectionForTests();
    const reopened = await loadGameStateAtomic('primary');
    expect(reopened.loaded).toBe(true);
    const loadedState = reopened.state!;

    expect(getItemsInContainer(loadedState, 'player_equip:main_hand')[0].instanceId).toBe(knifeBefore);
    expect(loadedState.world.pois['research_outpost'].gateUnlocked).toBe(true);

    const settled = dispatchIntent(loadedState, {
      kind: 'OFFLINE_CATCHUP',
      nowUtcSec: 1_700_001_800,
    });
    expect(settled.accepted).toBe(true);
    expect(getItemsInContainer(settled.state, 'player_equip:main_hand')[0].instanceId).toBe(knifeBefore);
  });
});
