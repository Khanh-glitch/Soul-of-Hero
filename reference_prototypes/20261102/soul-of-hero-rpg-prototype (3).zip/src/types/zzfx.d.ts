declare module 'zzfx' {
  export const ZZFX: {
    volume: number;
    sampleRate: number;
    x: AudioContext | null;
    play: (...parameters: Array<number | undefined>) => AudioBufferSourceNode | false;
    buildSamples: (...parameters: Array<number | undefined>) => Float32Array;
  };
  export function zzfx(...parameters: Array<number | undefined>): AudioBufferSourceNode | false;
}
