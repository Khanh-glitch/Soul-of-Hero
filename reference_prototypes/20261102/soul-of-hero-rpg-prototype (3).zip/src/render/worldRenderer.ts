import {
  BALANCE,
  BOSS_MAP,
  ITEM_MAP,
  POI_MAP,
  STRUCTURE_MAP,
} from '../data/catalogs';
import { countItemInContainer } from '../sim/custody';
import { isTileOwnedHomestead } from '../sim/engine';
import type { BiomeId, GameState } from '../sim/types';
import { getOrCreateTopology, tileIndex } from '../sim/worldGen';
import { drawKenneyTile, getPixelSpriteAtlas, type PixelSpriteAtlas } from './pixelSprites';

export interface RenderViewportInfo {
  camX: number;
  camY: number;
  hoverWorldX: number;
  hoverWorldY: number;
  selectedBuildDefId: string | null;
}

export function evaluateBuildGhostValidity(
  state: GameState,
  structureDefId: string,
  tileX: number,
  tileY: number
): { valid: boolean; reason: string } {
  const sDef = STRUCTURE_MAP.get(structureDefId);
  if (!sDef) return { valid: false, reason: 'Invalid blueprint' };
  const topology = getOrCreateTopology(state.world.seed);
  if (tileX < 2 || tileY < 2 || tileX >= topology.width - 2 || tileY >= topology.height - 2) {
    return { valid: false, reason: 'Out of bounds' };
  }
  const player = state.actors.player;
  if (Math.hypot(tileX * 16 + 8 - player.x, tileY * 16 + 8 - player.y) > 84) {
    return { valid: false, reason: 'Too far (walk closer)' };
  }
  const biome = topology.biomes[tileIndex(tileX, tileY, topology.width)];
  if (biome === 'deep_sea' || biome === 'shallow_water' || biome === 'mountain') {
    return { valid: false, reason: `Blocked by ${biome}` };
  }
  if (sDef.requiresOwnedTerritory && !isTileOwnedHomestead(state, tileX, tileY)) {
    return { valid: false, reason: 'Needs Homestead Totem claim' };
  }
  if (Object.values(state.sourceStocks).some((s) => s.stock > 0 && s.tileX === tileX && s.tileY === tileY)) {
    return { valid: false, reason: 'Clear resource node first' };
  }
  const sameTile = Object.values(state.entities.structures).filter(
    (s) => s.hp > 0 && s.tileX === tileX && s.tileY === tileY
  );
  for (const ex of sameTile) {
    const exDef = STRUCTURE_MAP.get(ex.definitionId);
    if (!exDef) continue;
    if (sDef.isFloor && exDef.isFloor) return { valid: false, reason: 'Floor exists' };
    if (sDef.isRoof && exDef.isRoof) return { valid: false, reason: 'Roof exists' };
    if (!sDef.isFloor && !sDef.isRoof && !exDef.isFloor && !exDef.isRoof) {
      return { valid: false, reason: 'Occupied' };
    }
  }
  if (
    sDef.blocksMovement &&
    !sDef.isDoor &&
    Math.floor(player.x / 16) === tileX &&
    Math.floor(player.y / 16) === tileY
  ) {
    return { valid: false, reason: 'Standing on tile' };
  }
  if (sDef.deployItemOnly) {
    if (countItemInContainer(state, 'player_bag', sDef.deployItemOnly) < 1) {
      return { valid: false, reason: `Need ${ITEM_MAP.get(sDef.deployItemOnly)?.name ?? sDef.deployItemOnly}` };
    }
  } else {
    for (const req of sDef.cost) {
      if (countItemInContainer(state, 'player_bag', req.itemId) < req.count) {
        return {
          valid: false,
          reason: `Need ${req.count} ${ITEM_MAP.get(req.itemId)?.name.split(' ').pop() ?? req.itemId}`,
        };
      }
    }
  }
  return { valid: true, reason: `Place ${sDef.name}` };
}

function drawBiomeTile(
  ctx: CanvasRenderingContext2D,
  atlas: PixelSpriteAtlas,
  biome: BiomeId,
  tx: number,
  ty: number,
  sx: number,
  sy: number,
  animTick: number,
  northBiome: BiomeId
): void {
  const hash = ((tx * 73856093) ^ (ty * 19349663)) >>> 0;

  switch (biome) {
    case 'deep_sea': {
      ctx.fillStyle = '#0f3952';
      ctx.fillRect(sx, sy, 16, 16);
      const waveOffset = ((animTick + (hash % 7)) % 8) < 4 ? 0 : 2;
      ctx.fillStyle = '#174e6e';
      ctx.fillRect(sx + 2 + waveOffset, sy + 5, 5, 1);
      ctx.fillRect(sx + 8 - waveOffset, sy + 11, 4, 1);
      break;
    }
    case 'shallow_water': {
      ctx.fillStyle = '#1d6f8a';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#5cc0d8';
      if (((animTick + tx + ty) & 3) === 0) {
        ctx.fillRect(sx + 3, sy + 4, 4, 1);
      } else {
        ctx.fillRect(sx + 8, sy + 10, 5, 1);
      }
      // Shoreline foam where shallow water meets land
      if (northBiome !== 'deep_sea' && northBiome !== 'shallow_water') {
        ctx.fillStyle = '#e0f2fe';
        ctx.fillRect(sx, sy, 16, 2);
      }
      break;
    }
    case 'coast': {
      ctx.fillStyle = '#d9b982';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#c49f64';
      ctx.fillRect(sx + (hash % 11), sy + ((hash >> 3) % 12), 2, 2);
      ctx.fillStyle = '#ead2a4';
      ctx.fillRect(sx + ((hash >> 5) % 12), sy + ((hash >> 7) % 12), 2, 1);
      break;
    }
    case 'plains': {
      const col = hash % 11 === 0 ? 2 : hash % 3 === 0 ? 1 : 0;
      if (!drawKenneyTile(ctx, atlas, col, 0, sx, sy)) {
        ctx.fillStyle = '#5c9c54';
        ctx.fillRect(sx, sy, 16, 16);
      }
      break;
    }
    case 'forest': {
      if (!drawKenneyTile(ctx, atlas, hash % 5 === 0 ? 1 : 0, 0, sx, sy)) {
        ctx.fillStyle = '#3d743e';
        ctx.fillRect(sx, sy, 16, 16);
      }
      // Subtle forest canopy dappled ground tint
      ctx.fillStyle = 'rgba(20, 52, 26, 0.22)';
      ctx.fillRect(sx, sy, 16, 16);
      break;
    }
    case 'road': {
      const useCobble = hash % 6 === 0;
      if (!drawKenneyTile(ctx, atlas, useCobble ? 7 : 1, useCobble ? 3 : 2, sx, sy)) {
        ctx.fillStyle = '#b98556';
        ctx.fillRect(sx, sy, 16, 16);
      }
      break;
    }
    case 'poi_floor': {
      if (!drawKenneyTile(ctx, atlas, 1, 9, sx, sy)) {
        ctx.fillStyle = '#9ca3af';
        ctx.fillRect(sx, sy, 16, 16);
      }
      break;
    }
    case 'wetland': {
      ctx.fillStyle = '#3f5a36';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#2d4436';
      ctx.fillRect(sx + 2, sy + 3, 7, 5);
      ctx.fillStyle = '#65a30d';
      ctx.fillRect(sx + (hash % 12), sy + 2, 1, 4);
      ctx.fillRect(sx + ((hash >> 4) % 12), sy + 9, 1, 4);
      break;
    }
    case 'hills': {
      ctx.fillStyle = '#716856';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#8b816c';
      ctx.fillRect(sx + 2, sy + 2, 12, 10);
      ctx.fillStyle = '#544d3f';
      ctx.fillRect(sx, sy + 13, 16, 3); // cliff ridge shadow
      break;
    }
    case 'mountain': {
      ctx.fillStyle = '#44403c';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#78716c';
      ctx.fillRect(sx + 2, sy + 1, 12, 7);
      ctx.fillStyle = '#d6d3d1';
      ctx.fillRect(sx + 4, sy + 2, 7, 3); // crag peak highlight
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(sx, sy + 12, 16, 4);
      break;
    }
    case 'cold': {
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(sx + (hash % 8), sy + ((hash >> 3) % 8), 6, 5);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(sx + ((hash >> 5) % 12), sy + 12, 3, 2);
      break;
    }
    case 'hot': {
      ctx.fillStyle = '#3b2621';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#57362e';
      ctx.fillRect(sx + 2, sy + 3, 9, 7);
      if (hash % 5 === 0) {
        ctx.fillStyle = '#ea580c';
        ctx.fillRect(sx + 4, sy + 8, 6, 1);
      }
      break;
    }
    case 'radiation': {
      ctx.fillStyle = '#383d29';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#4c5433';
      ctx.fillRect(sx + 3, sy + 3, 8, 8);
      if (hash % 4 === 0) {
        ctx.fillStyle = '#a3e635';
        ctx.fillRect(sx + (hash % 12), sy + ((hash >> 3) % 12), 2, 2);
      }
      break;
    }
  }
}

export function renderWorldCanvas(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  viewport: RenderViewportInfo
): void {
  const W = BALANCE.world.logicalCanvasWidth.value; // 640
  const H = BALANCE.world.logicalCanvasHeight.value; // 360
  ctx.imageSmoothingEnabled = false;

  const atlas = getPixelSpriteAtlas();
  const topology = getOrCreateTopology(state.world.seed);
  const camX = Math.round(viewport.camX);
  const camY = Math.round(viewport.camY);
  const animTick = Math.floor(state.clock.simTimeMs / 220);

  ctx.fillStyle = '#0c1f2c';
  ctx.fillRect(0, 0, W, H);

  const minTx = Math.max(0, Math.floor(camX / 16) - 1);
  const maxTx = Math.min(topology.width - 1, Math.ceil((camX + W) / 16) + 1);
  const minTy = Math.max(0, Math.floor(camY / 16) - 1);
  const maxTy = Math.min(topology.height - 1, Math.ceil((camY + H) / 16) + 2);

  // 1. Ground Biome Layer
  for (let ty = minTy; ty <= maxTy; ty++) {
    for (let tx = minTx; tx <= maxTx; tx++) {
      const b = topology.biomes[tileIndex(tx, ty, topology.width)];
      const nb = ty > 0 ? topology.biomes[tileIndex(tx, ty - 1, topology.width)] : b;
      drawBiomeTile(ctx, atlas, b, tx, ty, tx * 16 - camX, ty * 16 - camY, animTick, nb);
    }
  }

  // 2. Authorized Terrain Mutations (frozen ice bridges, burning tiles, cracked rock)
  for (const ef of state.world.terrainEffects) {
    if (ef.tileX < minTx || ef.tileX > maxTx || ef.tileY < minTy || ef.tileY > maxTy) continue;
    const sx = ef.tileX * 16 - camX;
    const sy = ef.tileY * 16 - camY;
    if (ef.type === 'frozen_ice') {
      ctx.fillStyle = '#bae6fd';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#f0f9ff';
      ctx.fillRect(sx + 2, sy + 3, 10, 2);
      ctx.fillRect(sx + 4, sy + 10, 8, 2);
    } else if (ef.type === 'burning') {
      ctx.fillStyle = 'rgba(234, 88, 12, 0.55)';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = animTick % 2 === 0 ? '#fde047' : '#f97316';
      ctx.fillRect(sx + 4, sy + 4, 3, 6);
      ctx.fillRect(sx + 9, sy + 3, 3, 7);
    } else if (ef.type === 'cracked_rock') {
      ctx.fillStyle = '#1c1917';
      ctx.fillRect(sx + 3, sy + 7, 10, 2);
      ctx.fillRect(sx + 7, sy + 4, 2, 8);
    }
  }

  // 3. Floor Foundations & Garden Plots
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0 || str.tileX < minTx || str.tileX > maxTx || str.tileY < minTy || str.tileY > maxTy) continue;
    const def = STRUCTURE_MAP.get(str.definitionId);
    if (!def) continue;
    const sx = str.tileX * 16 - camX;
    const sy = str.tileY * 16 - camY;

    if (str.definitionId === 'wood_floor') {
      ctx.fillStyle = '#8c5832';
      ctx.fillRect(sx, sy, 16, 16);
      ctx.fillStyle = '#6e4223';
      ctx.fillRect(sx, sy + 5, 16, 1);
      ctx.fillRect(sx, sy + 11, 16, 1);
      ctx.fillRect(sx, sy, 16, 1);
    } else if (str.definitionId === 'stone_foundation') {
      drawKenneyTile(ctx, atlas, 1, 9, sx, sy);
    } else if (str.definitionId === 'garden_plot') {
      const sprite = atlas.props['garden_plot'];
      if (sprite) ctx.drawImage(sprite, sx, sy + 3);
    }
  }

  // 4. Physical Decaying Player Footprints (C08)
  for (const fp of state.world.footprints) {
    if (fp.tileX < minTx || fp.tileX > maxTx || fp.tileY < minTy || fp.tileY > maxTy) continue;
    const remRatio = Math.max(0.15, Math.min(1, (fp.expiresAtUtcSec - state.clock.lastSimulatedUtcSec) / 360));
    ctx.fillStyle = `rgba(28, 22, 18, ${(0.48 * remRatio).toFixed(2)})`;
    const fx = Math.round(fp.x - camX);
    const fy = Math.round(fp.y - camY);
    ctx.fillRect(fx - 2, fy - 1, 2, 2);
    ctx.fillRect(fx + 1, fy + 1, 2, 2);
  }

  // 5. POI Special Markers (Locked Gates, Emergency Exit Hatches, Wayfarer Vendor, Evacuation Beacon)
  for (const poi of Object.values(state.world.pois)) {
    if (poi.gateTile && !poi.gateUnlocked) {
      const gx = poi.gateTile.x * 16 - camX;
      const gy = poi.gateTile.y * 16 - camY;
      if (gx > -24 && gx < W + 24 && gy > -24 && gy < H + 24) {
        if (!drawKenneyTile(ctx, atlas, 3, 9, gx, gy)) {
          ctx.fillStyle = '#b91c1c';
          ctx.fillRect(gx, gy, 16, 16);
        }
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(gx + 6, gy + 6, 4, 4);
      }
    }
    if (poi.emergencyExitTile) {
      const ex = poi.emergencyExitTile.x * 16 - camX;
      const ey = poi.emergencyExitTile.y * 16 - camY;
      if (ex > -24 && ex < W + 24 && ey > -24 && ey < H + 24) {
        drawKenneyTile(ctx, atlas, 7, 8, ex, ey);
      }
    }
    if (poi.vendorTile) {
      const vx = poi.vendorTile.x * 16 - camX;
      const vy = poi.vendorTile.y * 16 - camY;
      if (vx > -32 && vx < W + 32 && vy > -32 && vy < H + 32) {
        const spr = atlas.props['wayfarer_vendor'];
        if (spr) ctx.drawImage(spr, vx, vy - 2);
        ctx.fillStyle = '#fde047';
        ctx.font = 'bold 7px monospace';
        ctx.fillText('TRADER', vx - 4, vy - 4);
      }
    }
    if (poi.evacTile) {
      const bx = poi.evacTile.x * 16 - camX;
      const by = poi.evacTile.y * 16 - camY;
      if (bx > -32 && bx < W + 32 && by > -32 && by < H + 32) {
        const spr = atlas.props['evac_beacon'];
        if (spr) ctx.drawImage(spr, bx, by - 2);
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 7px monospace';
        ctx.fillText('EVAC PIER', bx - 10, by - 4);
      }
    }
  }

  // 6. Elder Boss Fair AoE Ground Telegraphs (rendered beneath actors!)
  for (const elder of state.actors.elders) {
    if (elder.defeated || !elder.telegraph?.active) continue;
    const tx = Math.round(elder.telegraph.targetX - camX);
    const ty = Math.round(elder.telegraph.targetY - camY);
    if (tx < -100 || tx > W + 100 || ty < -100 || ty > H + 100) continue;
    const bDef = BOSS_MAP.get(elder.definitionId);
    const progress = Math.min(
      1,
      Math.max(
        0,
        (state.clock.simTimeMs - elder.telegraph.startedAtMs) /
          Math.max(1, elder.telegraph.commitAtMs - elder.telegraph.startedAtMs)
      )
    );
    ctx.save();
    ctx.strokeStyle = bDef?.palettePrimary ?? '#ef4444';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(tx, ty, elder.telegraph.radiusPx, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = 'rgba(239, 68, 68, 0.24)';
    ctx.beginPath();
    ctx.arc(tx, ty, elder.telegraph.radiusPx * progress, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // 7. Y-Sorted World Drawables (Sources, Walls, Stations, Carts, Death Bags, Enemies, Player, Elders)
  interface YDrawable {
    sortY: number;
    draw: () => void;
  }
  const drawables: YDrawable[] = [];

  // Sources
  const isFinal72Active =
    state.clock.phase === 'ragnarok_final72' || state.clock.phase === 'ragnarok_day14_elders';

  for (const src of Object.values(state.sourceStocks)) {
    if (src.stock <= 0 || src.tileX < minTx || src.tileX > maxTx || src.tileY < minTy || src.tileY > maxTy) continue;
    const sx = src.tileX * 16 - camX;
    const sy = src.tileY * 16 - camY;

    drawables.push({
      sortY: src.tileY * 16 + 14,
      draw: () => {
        // Drop shadow
        ctx.fillStyle = 'rgba(0,0,0,0.28)';
        ctx.fillRect(sx + 2, sy + 13, 12, 3);

        switch (src.definitionId) {
          case 'pine_tree':
            drawKenneyTile(ctx, atlas, 4, 0, sx, sy - 14);
            drawKenneyTile(ctx, atlas, 4, 1, sx, sy + 2);
            break;
          case 'autumn_oak':
            drawKenneyTile(ctx, atlas, 3, 0, sx, sy - 14);
            drawKenneyTile(ctx, atlas, 3, 1, sx, sy + 2);
            break;
          case 'berry_bush':
            drawKenneyTile(ctx, atlas, 5, 0, sx, sy);
            break;
          case 'herb_patch':
            drawKenneyTile(ctx, atlas, 5, 2, sx, sy);
            break;
          case 'fresh_spring':
            drawKenneyTile(ctx, atlas, 8, 7, sx, sy - 10);
            drawKenneyTile(ctx, atlas, 8, 8, sx, sy + 2);
            break;
          case 'roadside_barrel':
          case 'fuel_drum':
            drawKenneyTile(ctx, atlas, 11, 8, sx, sy);
            break;
          case 'roadside_crate':
          case 'industrial_locker':
          case 'poi_vault_crate':
            drawKenneyTile(ctx, atlas, 10, 7, sx, sy);
            break;
          default: {
            const prop = atlas.props[src.definitionId];
            if (prop) ctx.drawImage(prop, sx, sy);
            if (src.definitionId === 'ragnarok_treasury_chest') {
              ctx.fillStyle = isFinal72Active ? '#34d399' : '#9ca3af';
              ctx.font = 'bold 6px monospace';
              ctx.fillText(isFinal72Active ? '$72H' : 'SEAL', sx, sy - 2);
            }
            break;
          }
        }
      },
    });
  }

  // Non-floor, non-roof Structures
  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0 || str.tileX < minTx || str.tileX > maxTx || str.tileY < minTy || str.tileY > maxTy) continue;
    const sDef = STRUCTURE_MAP.get(str.definitionId);
    if (!sDef || sDef.isFloor || sDef.isRoof || str.definitionId === 'garden_plot') continue;
    const sx = str.tileX * 16 - camX;
    const sy = str.tileY * 16 - camY;

    drawables.push({
      sortY: str.tileY * 16 + 15,
      draw: () => {
        switch (str.definitionId) {
          case 'wood_wall':
            drawKenneyTile(ctx, atlas, 1, 6, sx, sy);
            break;
          case 'stone_wall':
          case 'reinforced_wall':
            drawKenneyTile(ctx, atlas, 5, 6, sx, sy);
            break;
          case 'wood_door':
            if (str.isOpen) {
              drawKenneyTile(ctx, atlas, 2, 6, sx, sy);
            } else {
              drawKenneyTile(ctx, atlas, 1, 7, sx, sy);
            }
            break;
          case 'powered_blast_door':
            if (str.isOpen) {
              drawKenneyTile(ctx, atlas, 6, 6, sx, sy);
            } else {
              drawKenneyTile(ctx, atlas, 5, 7, sx, sy);
            }
            break;
          case 'campfire_lantern':
            ctx.fillStyle = '#fde047';
            ctx.fillRect(sx + 6, sy + 4, 4, 6);
            ctx.fillStyle = '#44403c';
            ctx.fillRect(sx + 7, sy + 10, 2, 5);
            break;
          default: {
            const spr = atlas.props[str.definitionId];
            if (spr) ctx.drawImage(spr, sx, sy);
            if (str.definitionId === 'escrow_chest') {
              ctx.fillStyle = '#34d399';
              ctx.font = 'bold 6px monospace';
              ctx.fillText('ESCROW', sx - 3, sy - 2);
            }
            break;
          }
        }

        // Visible damage bar on damaged structures
        if (str.hp < str.maxHp) {
          ctx.fillStyle = '#1c1917';
          ctx.fillRect(sx + 2, sy - 3, 12, 2);
          ctx.fillStyle = '#f97316';
          ctx.fillRect(sx + 2, sy - 3, Math.round((12 * str.hp) / str.maxHp), 2);
        }
      },
    });
  }

  // Deployed Cargo Hand-Carts (using verified CC0 Kenney Tiny Town Hand-Cart tile col 9, row 4!)
  for (const cart of Object.values(state.entities.carts)) {
    const cx = Math.round(cart.x - camX - 8);
    const cy = Math.round(cart.y - camY - 8);
    if (cx < -32 || cx > W + 32 || cy < -32 || cy > H + 32) continue;
    drawables.push({
      sortY: cart.y + 6,
      draw: () => {
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fillRect(cx + 2, cy + 13, 12, 3);
        if (!drawKenneyTile(ctx, atlas, 9, 4, cx, cy)) {
          ctx.fillStyle = '#b45309';
          ctx.fillRect(cx + 2, cy + 3, 12, 10);
        }
        if (cart.hitchedByPlayer) {
          ctx.fillStyle = '#fde047';
          ctx.fillRect(cx + 7, cy - 2, 2, 2);
        }
      },
    });
  }

  // Death Recovery Bags
  for (const bag of Object.values(state.entities.deathBags)) {
    const bx = Math.round(bag.x - camX - 8);
    const by = Math.round(bag.y - camY - 8);
    if (bx < -32 || bx > W + 32 || by < -32 || by > H + 32) continue;
    drawables.push({
      sortY: bag.y + 4,
      draw: () => {
        const spr = atlas.props['death_bag'];
        if (spr) ctx.drawImage(spr, bx, by);
        ctx.fillStyle = '#fca5a5';
        ctx.font = 'bold 6px monospace';
        ctx.fillText('BAG', bx + 2, by - 2);
      },
    });
  }

  // Ordinary Enemies
  for (const enemy of state.actors.enemies) {
    if (!enemy.alive) continue;
    const ex = Math.round(enemy.x - camX - 8);
    const ey = Math.round(enemy.y - camY - 10);
    if (ex < -32 || ex > W + 32 || ey < -32 || ey > H + 32) continue;
    drawables.push({
      sortY: enemy.y + 6,
      draw: () => {
        ctx.fillStyle = 'rgba(0,0,0,0.32)';
        ctx.fillRect(ex + 3, ey + 13, 10, 3);
        const spr = atlas.enemies[enemy.definitionId];
        if (spr) {
          ctx.drawImage(spr, ex, ey + (animTick % 2 === 0 ? 0 : -1));
        }
        // HP bar & perception state badge (! for sight chase, ? for trail tracking)
        if (enemy.hp < enemy.maxHp || enemy.aiState !== 'patrol') {
          ctx.fillStyle = '#1c1917';
          ctx.fillRect(ex + 2, ey - 4, 12, 2);
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(ex + 2, ey - 4, Math.max(1, Math.round((12 * enemy.hp) / enemy.maxHp)), 2);
        }
        if (enemy.aiState === 'chase_sight') {
          ctx.fillStyle = '#ef4444';
          ctx.font = 'bold 7px monospace';
          ctx.fillText('!', ex + 7, ey - 5);
        } else if (enemy.aiState === 'follow_trail') {
          ctx.fillStyle = '#facc15';
          ctx.font = 'bold 7px monospace';
          ctx.fillText('~', ex + 6, ey - 5);
        }
      },
    });
  }

  // Six Optional Elder Bosses (24x24 pixel sprites)
  for (const elder of state.actors.elders) {
    if (elder.defeated) continue;
    const bx = Math.round(elder.x - camX - 12);
    const by = Math.round(elder.y - camY - 16);
    if (bx < -48 || bx > W + 48 || by < -48 || by > H + 48) continue;
    const bDef = BOSS_MAP.get(elder.definitionId);
    drawables.push({
      sortY: elder.y + 10,
      draw: () => {
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.fillRect(bx + 3, by + 20, 18, 4);
        const spr =
          elder.form === 'awakened'
            ? atlas.eldersAwakened[elder.definitionId]
            : atlas.eldersLatent[elder.definitionId];
        if (spr) ctx.drawImage(spr, bx, by + (animTick % 2 === 0 ? 0 : -1));

        ctx.fillStyle = '#1c1917';
        ctx.fillRect(bx, by - 6, 24, 3);
        ctx.fillStyle = bDef?.palettePrimary ?? '#f97316';
        ctx.fillRect(bx, by - 6, Math.max(1, Math.round((24 * elder.hp) / elder.maxHp)), 3);

        ctx.fillStyle = '#fef08a';
        ctx.font = 'bold 6px monospace';
        const shortName = (bDef?.name.split(',')[0] ?? elder.bossId).toUpperCase();
        ctx.fillText(elder.form === 'awakened' ? `★${shortName}` : shortName, bx - 4, by - 8);
      },
    });
  }

  // Player Adventurer (Female / Male)
  const player = state.actors.player;
  const px = Math.round(player.x - camX - 8);
  const py = Math.round(player.y - camY - 12);
  drawables.push({
    sortY: player.y + 7,
    draw: () => {
      ctx.fillStyle = 'rgba(0,0,0,0.36)';
      ctx.fillRect(px + 3, py + 14, 10, 3);

      const isWalking = player.distanceSinceLastFootprintPx > 1 && animTick % 2 === 1;
      let spr: HTMLCanvasElement | null = null;
      if (player.gender === 'female') {
        spr =
          player.facing === 'up'
            ? atlas.playerSprites.femaleUp0
            : isWalking
            ? atlas.playerSprites.femaleDown1
            : atlas.playerSprites.femaleDown0;
      } else {
        spr =
          player.facing === 'up'
            ? atlas.playerSprites.maleUp0
            : isWalking
            ? atlas.playerSprites.maleDown1
            : atlas.playerSprites.maleDown0;
      }
      if (spr) ctx.drawImage(spr, px, py);

      // Melee weapon swing arc feedback
      const sinceSwing = state.clock.simTimeMs - player.lastSwingAtSimMs;
      if (sinceSwing >= 0 && sinceSwing <= 180) {
        ctx.save();
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(
          Math.round(player.x - camX),
          Math.round(player.y - camY - 4),
          17,
          player.lastSwingAngleRad - 0.75,
          player.lastSwingAngleRad + 0.75
        );
        ctx.stroke();
        ctx.restore();
      }

      // Active Core cast windup halo (charge debited ONLY when ring completes!)
      if (player.activeCast && !player.activeCast.committed) {
        const ratio = Math.min(
          1,
          (state.clock.simTimeMs - player.activeCast.startedAtSimMs) /
            Math.max(1, player.activeCast.commitAtSimMs - player.activeCast.startedAtSimMs)
        );
        ctx.save();
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(
          Math.round(player.x - camX),
          Math.round(player.y - camY - 4),
          13,
          -Math.PI / 2,
          -Math.PI / 2 + Math.PI * 2 * ratio
        );
        ctx.stroke();
        ctx.restore();
      }
    },
  });

  drawables.sort((a, b) => a.sortY - b.sortY);
  for (const d of drawables) {
    d.draw();
  }

  // 8. Overhead Roof Layer with Automatic Indoor Room Entry Fade/Occlusion (§4 / §9.6 / §12)
  const ptx = player.x / 16;
  const pty = player.y / 16;
  const playerUnderAnyRoof = Object.values(state.entities.structures).some((s) => {
    if (s.hp <= 0) return false;
    const d = STRUCTURE_MAP.get(s.definitionId);
    return Boolean(d?.isRoof && Math.hypot(s.tileX + 0.5 - ptx, s.tileY + 0.5 - pty) <= 2.2);
  });

  for (const str of Object.values(state.entities.structures)) {
    if (str.hp <= 0 || str.tileX < minTx || str.tileX > maxTx || str.tileY < minTy || str.tileY > maxTy) continue;
    const sDef = STRUCTURE_MAP.get(str.definitionId);
    if (!sDef?.isRoof) continue;
    const sx = str.tileX * 16 - camX;
    const sy = str.tileY * 16 - camY;
    const distToPlayer = Math.hypot(str.tileX + 0.5 - ptx, str.tileY + 0.5 - pty);
    const fadeRoof = playerUnderAnyRoof && distToPlayer <= 4.5;

    ctx.save();
    ctx.globalAlpha = fadeRoof ? 0.16 : 0.96;
    if (str.definitionId === 'thatch_roof') {
      drawKenneyTile(ctx, atlas, 5, 4, sx, sy);
    } else {
      drawKenneyTile(ctx, atlas, 1, 4, sx, sy);
    }
    ctx.restore();
  }

  // 9. Build Ghost Footprint Preview + Territory Radius Overlay
  if (viewport.selectedBuildDefId) {
    const gtx = Math.floor(viewport.hoverWorldX / 16);
    const gty = Math.floor(viewport.hoverWorldY / 16);
    const check = evaluateBuildGhostValidity(state, viewport.selectedBuildDefId, gtx, gty);
    const gx = gtx * 16 - camX;
    const gy = gty * 16 - camY;

    // Show Homestead Claim Totem ownership rings while building
    ctx.save();
    ctx.strokeStyle = 'rgba(52, 211, 153, 0.35)';
    ctx.setLineDash([3, 3]);
    for (const s of Object.values(state.entities.structures)) {
      if (s.hp > 0 && STRUCTURE_MAP.get(s.definitionId)?.claimsTerritory) {
        ctx.beginPath();
        ctx.arc(
          s.tileX * 16 + 8 - camX,
          s.tileY * 16 + 8 - camY,
          BALANCE.economyAndTerritory.homesteadClaimRadiusTiles.value * 16,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }
    }
    ctx.setLineDash([]);

    ctx.fillStyle = check.valid ? 'rgba(34, 197, 94, 0.32)' : 'rgba(239, 68, 68, 0.36)';
    ctx.fillRect(gx, gy, 16, 16);
    ctx.strokeStyle = check.valid ? '#4ade80' : '#f87171';
    ctx.lineWidth = 1;
    ctx.strokeRect(gx + 0.5, gy + 0.5, 15, 15);

    ctx.fillStyle = 'rgba(12, 10, 9, 0.82)';
    const textW = Math.min(150, check.reason.length * 5 + 8);
    ctx.fillRect(gx - 4, gy - 12, textW, 10);
    ctx.fillStyle = check.valid ? '#86efac' : '#fca5a5';
    ctx.font = '7px monospace';
    ctx.fillText(check.reason, gx - 1, gy - 4);
    ctx.restore();
  }

  // 10. Combat / Skill / Harvest VFX & Floating Numbers
  for (const vfx of state.vfxQueue) {
    const age = state.clock.simTimeMs - vfx.createdAtSimMs;
    if (age < 0 || age > vfx.durationMs) continue;
    const progress = age / vfx.durationMs;
    const vx = Math.round(vfx.x - camX);
    const vy = Math.round(vfx.y - camY - progress * 12);

    ctx.save();
    ctx.globalAlpha = Math.max(0.1, 1 - progress * 0.85);
    if (vfx.radiusPx) {
      ctx.strokeStyle = vfx.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(Math.round(vfx.x - camX), Math.round(vfx.y - camY), vfx.radiusPx * (0.4 + 0.6 * progress), 0, Math.PI * 2);
      ctx.stroke();
    }
    if (vfx.text) {
      ctx.fillStyle = '#0c0a09';
      ctx.font = 'bold 8px monospace';
      ctx.fillText(vfx.text, vx - 9, vy + 1);
      ctx.fillStyle = vfx.color;
      ctx.fillText(vfx.text, vx - 10, vy);
    }
    ctx.restore();
  }

  // 11. Day/Night & Ragnarok Ambient Tint + Warm Workstation Lighting (always readable, never pitch black!)
  const darkness = Math.max(0, 0.44 * (1 - state.clock.daylightFactor));
  if (darkness > 0.04 || state.clock.phase !== 'ordinary') {
    ctx.save();
    if (state.clock.phase !== 'ordinary') {
      ctx.fillStyle = 'rgba(127, 29, 29, 0.13)';
      ctx.fillRect(0, 0, W, H);
    }
    if (darkness > 0.04) {
      ctx.fillStyle = `rgba(10, 18, 36, ${darkness.toFixed(2)})`;
      ctx.fillRect(0, 0, W, H);
    }
    // Warm amber workstation light pools around fueled campfires, furnaces, and lanterns
    ctx.globalCompositeOperation = 'lighter';
    for (const str of Object.values(state.entities.structures)) {
      if (str.hp <= 0) continue;
      const sDef = STRUCTURE_MAP.get(str.definitionId);
      if (!sDef?.lightRadiusPx) continue;
      if (sDef.usesFuel && str.fuelRemainingSec <= 0) continue;
      const lx = str.tileX * 16 + 8 - camX;
      const ly = str.tileY * 16 + 8 - camY;
      if (lx < -120 || lx > W + 120 || ly < -120 || ly > H + 120) continue;
      const grad = ctx.createRadialGradient(lx, ly, 4, lx, ly, sDef.lightRadiusPx);
      grad.addColorStop(0, 'rgba(251, 146, 60, 0.25)');
      grad.addColorStop(1, 'rgba(251, 146, 60, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(lx, ly, sDef.lightRadiusPx, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // 12. Crisp Pixel Weather Particles (Rain / Storm / Volcanic Ash Wind)
  if (state.clock.weather === 'rain' || state.clock.weather === 'storm') {
    ctx.fillStyle = state.clock.weather === 'storm' ? 'rgba(186, 230, 253, 0.65)' : 'rgba(186, 230, 253, 0.45)';
    const dropCount = state.clock.weather === 'storm' ? 55 : 30;
    const tShift = Math.floor(state.clock.simTimeMs * 0.25);
    for (let i = 0; i < dropCount; i++) {
      const rx = ((i * 97 + tShift) % W + W) % W;
      const ry = ((i * 53 + tShift * 2) % H + H) % H;
      ctx.fillRect(rx, ry, 1, 5);
    }
  } else if (state.clock.weather === 'ash_wind' || state.clock.phase !== 'ordinary') {
    ctx.fillStyle = 'rgba(251, 146, 60, 0.55)';
    const tShift = Math.floor(state.clock.simTimeMs * 0.06);
    for (let i = 0; i < 22; i++) {
      const ax = ((i * 83 + tShift) % W + W) % W;
      const ay = ((i * 61 + Math.floor(tShift * 0.4)) % H + H) % H;
      ctx.fillRect(ax, ay, 2, 2);
    }
  }

  // Named POI arrival banner when standing inside a POI courtyard
  for (const poi of Object.values(state.world.pois)) {
    const b = poi.bounds;
    if (ptx >= b.x - 1 && ptx <= b.x + b.w + 1 && pty >= b.y - 1 && pty <= b.y + b.h + 1) {
      const poiDef = POI_MAP.get(poi.poiId);
      ctx.fillStyle = 'rgba(12, 10, 9, 0.72)';
      ctx.fillRect(W / 2 - 110, 28, 220, 14);
      ctx.fillStyle = '#fde68a';
      ctx.font = 'bold 8px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(
        `${poi.name}${poiDef?.deepGate && !poi.gateUnlocked ? ' [DEEP VAULT LOCKED]' : ''}`,
        W / 2,
        38
      );
      ctx.textAlign = 'left';
      break;
    }
  }
}
