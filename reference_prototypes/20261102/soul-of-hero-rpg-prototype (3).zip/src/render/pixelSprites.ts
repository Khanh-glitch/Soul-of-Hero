import { KENNEY_TINY_TOWN_DATA_URL } from '../assets/kenneyTinyTownData';

/**
 * Cohesive indexed pixel-art palette matched to Kenney Tiny Town's dark-ink outline (#1b141a)
 * and natural ruinous island tones.
 */
const PALETTE: Record<string, string> = {
  '.': '', // transparent
  k: '#1b141a', // dark pixel outline
  w: '#f5f5f4', // highlight white
  s: '#f3c6a5', // warm skin
  S: '#d49a76', // shaded skin
  r: '#dc2626', // crimson hood / ember red
  R: '#991b1b', // deep crimson
  g: '#4ade80', // bright leaf / emerald cloak
  G: '#15803d', // deep forest green
  b: '#38bdf8', // sky / frost cyan
  B: '#1d4ed8', // cobalt ranger blue
  y: '#facc15', // gold / brass / flame yellow
  o: '#f97316', // orange / copper / fire
  O: '#9a3412', // rust / burnt sienna
  t: '#b47b4e', // timber / tan leather
  T: '#784828', // dark timber
  m: '#a8a29e', // stone / iron light
  M: '#57534e', // stone / iron dark
  d: '#292524', // charcoal / obsidian
  p: '#c084fc', // aether / void violet
  P: '#6b21a8', // deep void purple
  l: '#a3e635', // toxic / mire lime
};

function bakePixelMatrix(rows: string[], paletteOverrides?: Record<string, string>): HTMLCanvasElement | null {
  if (typeof document === 'undefined') return null;
  const h = rows.length;
  const w = rows[0]?.length ?? 16;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  ctx.imageSmoothingEnabled = false;

  for (let y = 0; y < h; y++) {
    const row = rows[y];
    for (let x = 0; x < w; x++) {
      const ch = row[x];
      if (!ch || ch === '.') continue;
      const color = paletteOverrides?.[ch] ?? PALETTE[ch];
      if (!color) continue;
      ctx.fillStyle = color;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return canvas;
}

// 16x16 Female Adventurer (Crimson hood + ponytail + emerald survival cloak + satchel)
const FEMALE_DOWN_0 = [
  '.....kkkkkk.....',
  '....krrrrrrk....',
  '...krrwwwwrrk...',
  '...krssssssrk...',
  '..kkrsksskskrk..',
  '..krrssssssrrk..',
  '...kkggggggkk...',
  '..kgggyggygggk..',
  '..kgGggggggGgk..',
  '..ksGgtTTtgGsk..',
  '...kGggggggGk...',
  '...kGGGGGGGGk...',
  '....kttkkttk....',
  '....kTTkkTTk....',
  '...kddk..kddk...',
  '...kkk....kkk...',
];

const FEMALE_DOWN_1 = [
  '.....kkkkkk.....',
  '....krrrrrrk....',
  '...krrwwwwrrk...',
  '...krssssssrk...',
  '..kkrsksskskrk..',
  '..krrssssssrrk..',
  '...kkggggggkk...',
  '..ksggyggyggsk..',
  '..kgGggggggGgk..',
  '...kGgtTTtgGk...',
  '...kGggggggGk...',
  '...kGGGGGGGGk...',
  '...kttk..kttk...',
  '...kddk..kTTk...',
  '...kkk...kddk...',
  '..........kkk...',
];

const FEMALE_UP_0 = [
  '.....kkkkkk.....',
  '....krrrrrrk....',
  '...krrrrrrrrk...',
  '...krrrRRrrrk...',
  '..kkrrrRRrrrrk..',
  '..krrrrRRrrrrk..',
  '...kkggggggkk...',
  '..kggGGGGGGggk..',
  '..kgGGGGGGGGgk..',
  '..ksGGtTTtGGsk..',
  '...kGGGGGGGGk...',
  '...kGGGGGGGGk...',
  '....kttkkttk....',
  '....kTTkkTTk....',
  '...kddk..kddk...',
  '...kkk....kkk...',
];

// 16x16 Male Adventurer (Cobalt bandana + tousled hair + tan ranger coat + pauldron)
const MALE_DOWN_0 = [
  '.....kkkkkk.....',
  '....kTTTTTTk....',
  '...kBBBBBBBBk...',
  '...kBssssssBk...',
  '...kskssksksk...',
  '....kssssssk....',
  '...kkttttttkk...',
  '..kmmtyttyttmk..',
  '..kMttttttttMk..',
  '..ksttBBBBttsk..',
  '...kttttttttk...',
  '...kTTTTTTTTk...',
  '....kMMkkMMk....',
  '....kddkkddk....',
  '...kddk..kddk...',
  '...kkk....kkk...',
];

const MALE_DOWN_1 = [
  '.....kkkkkk.....',
  '....kTTTTTTk....',
  '...kBBBBBBBBk...',
  '...kBssssssBk...',
  '...kskssksksk...',
  '....kssssssk....',
  '...kkttttttkk...',
  '..ksmtyttyttsk..',
  '..kMttttttttMk..',
  '...kttBBBBttk...',
  '...kttttttttk...',
  '...kTTTTTTTTk...',
  '...kMMk..kMMk...',
  '...kddk..kddk...',
  '...kkk....kkk...',
  '................',
];

const MALE_UP_0 = [
  '.....kkkkkk.....',
  '....kTTTTTTk....',
  '...kBBBBBBBBk...',
  '...kTTTTTTTTk...',
  '...kTTTTTTTTk...',
  '....kTTTTTTk....',
  '...kkttttttkk...',
  '..kmmTTTTTTmmk..',
  '..kMTTTTTTTTMk..',
  '..ksTTBBBBTTsk..',
  '...kTTTTTTTTk...',
  '...kTTTTTTTTk...',
  '....kMMkkMMk....',
  '....kddkkddk....',
  '...kddk..kddk...',
  '...kkk....kkk...',
];

// 8 Distinct 16x16 Ordinary Enemy Pixel Matrices
const ENEMY_MATRICES: Record<string, string[]> = {
  feral_crawler: [
    '................',
    '....kk....kk....',
    '...kook..kook...',
    '....kOOOOOOk....',
    '...kOOyyyyOOk...',
    '..kOOOrkkrOOOk..',
    '.kkOOOOOOOOOOkk.',
    'ktoOOOOOOOOOOotk',
    '.kkOOOOOOOOOOkk.',
    '..kOOOTTTTOOOk..',
    '.ktoOOTTTTOOotk.',
    '.kk..kkkkkk..kk.',
    '....kdk..kdk....',
    '...kkk....kkk...',
    '................',
    '................',
  ],
  mire_leech: [
    '................',
    '.....kkkkkk.....',
    '...kkGGGGGGkk...',
    '..kGllGGGGllGk..',
    '..kGGkllkllGGk..',
    '.kGGGGGGGGGGGGk.',
    '.kGllGGGGGGllGk.',
    '.kGGGGGGGGGGGGk.',
    '..kGGGllllGGGk..',
    '...kGGGGGGGGk...',
    '....kGGGGGGk....',
    '.....kGGGGk.....',
    '....kGllllGk....',
    '.....kkkkkk.....',
    '................',
    '................',
  ],
  scrap_hound: [
    '..kk........kk..',
    '.kOOk......kOOk.',
    '.kOOkkkkkkkkOOk.',
    '..kOOmmOOmmOOk..',
    '..kOOrkOOrkOOk..',
    '..kOOOOddOOOOk..',
    '...kOOOOOOOOkk..',
    '..kmmOOOOOOmmOk.',
    '..kMOOOOOOOOOOk.',
    '..kOOOOOOOOOOk..',
    '..kOOk....kOOk..',
    '..kTTk....kTTk..',
    '..kddk....kddk..',
    '..kkk......kkk..',
    '................',
    '................',
  ],
  ridge_stalker: [
    '...kk......kk...',
    '..kmmk....kmmk..',
    '...kmmkkkkmmk...',
    '...kttttttttk...',
    '..kttykttkyttk..',
    '..kttttddttttk..',
    '...kttttttttk...',
    '..kTTTTTTTTTTk..',
    '.ktttTTTTTTtttk.',
    '.kTTTTTTTTTTTTk.',
    '..kTTk....kTTk..',
    '..kttk....kttk..',
    '..kddk....kddk..',
    '..kkk......kkk..',
    '................',
    '................',
  ],
  frost_wolf: [
    '..kk........kk..',
    '.kwwk......kwwk.',
    '.kwbkkkkkkkkbwk.',
    '..kwwwwbbwwwwk..',
    '..kwwbkwwkbwwk..',
    '..kwwwwddwwwwk..',
    '...kwwwwwwwwk...',
    '..kbbwwwwwwbbk..',
    '.kwwwwwwwwwwwwk.',
    '..kbbwwwwwwbbk..',
    '..kwwk....kwwk..',
    '..kbbk....kbbk..',
    '..kBBk....kBBk..',
    '..kkk......kkk..',
    '................',
    '................',
  ],
  cinder_beetle: [
    '................',
    '....kkkkkkkk....',
    '..kkddddddddkk..',
    '.kddooyyyyooodk.',
    '.kdorkddddkrodk.',
    'kdddoooooooodddk',
    'kdddyyddddyydddk',
    'kdddoooooooodddk',
    '.kddddyyyyddddk.',
    '.kddooooooooOdk.',
    '..kkddddddddkk..',
    '..kdk.kddk.kdk..',
    '.kkk..kkkk..kkk.',
    '................',
    '................',
    '................',
  ],
  rad_ghoul: [
    '.....kkkkkk.....',
    '....kGGGGGGk....',
    '...kGllllllGk...',
    '...kGlkllklGk...',
    '....kGllllGk....',
    '...kkmmmmmmkk...',
    '..kGMmllllmMGk..',
    '..kGMMMMMMMMGk..',
    '..klGMMllMMGlk..',
    '...kMMMMMMMMk...',
    '...kGGGGGGGGk...',
    '....kMMkkMMk....',
    '....kddkkddk....',
    '...kddk..kddk...',
    '...kkk....kkk...',
    '................',
  ],
  ruin_sentinel: [
    '....kkkkkkkk....',
    '...kmmmmmmmmk...',
    '..kmmyyyyyymmk..',
    '..kmmkrrrrkmmk..',
    '..kmmyyyyyymmk..',
    '...kkkkkkkkkk...',
    '.kkmmmmmmmmmmkk.',
    'kmMyymmmmmmyyMmk',
    'kmMmmmmbbmmmmMmk',
    'kmMmmmmbbmmmmMmk',
    '.kkMMMMMMMMMMkk.',
    '...kMMMkkMMMk...',
    '...kmmk..kmmk...',
    '..kMMMk..kMMMk..',
    '..kkkk....kkkk..',
    '................',
  ],
};

// 24x24 Imposing Elder Boss Silhouette Template (re-paletted & crowned per Elder identity + form!)
const ELDER_24_TEMPLATE = [
  '..kkk..............kkk..',
  '.k111k............k111k.',
  '.k1w11k....kk....k11w1k.',
  '..k1111kkkk11kkkk1111k..',
  '...k2222211ww1122222k...',
  '..k222111111111111222k..',
  '..k2211wwk1111kww1122k..',
  '..k2211wwk1111kww1122k..',
  '...k2221111ww1111222k...',
  '..kk2222222222222222kk..',
  '.k112221111ww111122211k.',
  'k1w12211wwwwwwww11221w1k',
  'k1112211ww1111ww1122111k',
  'k2222211ww1111ww1122222k',
  '.k2222211wwwwww1122222k.',
  '.k22k22211111111222k22k.',
  '..kk.k222222222222k.kk..',
  '.....k222111111222k.....',
  '....k2222k....k2222k....',
  '....k2112k....k2112k....',
  '...k22222k....k22222k...',
  '...kdddddk....kdddddk...',
  '...kkkkkkk....kkkkkkk...',
  '........................',
];

// Authored 16x16 Game-Specific Survival Structures & Nodes
const STRUCTURE_AND_NODE_MATRICES: Record<string, string[]> = {
  homestead_claim_totem: [
    '......kkkk......',
    '.....kyyyyk.....',
    '....kyrrrrrk....',
    '....kyrwwrrk....',
    '....kyrrrrrk....',
    '.....kttttk.....',
    '...kkttttttkk...',
    '..kgyyttttyygk..',
    '...kkttttttkk...',
    '.....kTTTTk.....',
    '.....kttttk.....',
    '.....kTTTTk.....',
    '....kmmmmmmk....',
    '...kmMMMMMMmk...',
    '...kkkkkkkkkk...',
    '................',
  ],
  stone_furnace: [
    '.....kkkkkk.....',
    '....kmmmmmmk....',
    '....kMMMMMMk....',
    '..kkkmmmmmmkkk..',
    '.kmmmmmmmmmmmmk.',
    '.kmMMMMMMMMMMmk.',
    '.kmmmmkkkkmmmmk.',
    '.kmMMkoooookMMmk.',
    '.kmmkoyyyyokmmk.',
    '.kmMkoywwyokMmk.',
    '.kmmkooooookmmk.',
    '.kmMMMMMMMMMMmk.',
    '.kmmmmmmmmmmmmk.',
    '.kMMMMMMMMMMMMk.',
    '..kkkkkkkkkkkk..',
    '................',
  ],
  workbench: [
    '................',
    '................',
    '..kkkkkkkkkkkk..',
    '.kttttttttttttk.',
    '.ktwwwwmmtttttk.',
    '.kttttmmmmttttk.',
    '.kTTTTTTTTTTTTk.',
    '..kTTkTTTTkTTk..',
    '..kttkmmmmkttk..',
    '..kttkMMMMkttk..',
    '..kTTk....kTTk..',
    '..kttk....kttk..',
    '..kddk....kddk..',
    '..kkk......kkk..',
    '................',
    '................',
  ],
  research_desk: [
    '......kkkk......',
    '.....kbbbbk.....',
    '....kbwwwwbk....',
    '..kkkkbbbbkkkk..',
    '.kttttttttttttk.',
    '.ktwwwwttpppttk.',
    '.ktwBBwttpwpttk.',
    '.kttttttttttttk.',
    '.kTTTTTTTTTTTTk.',
    '..kTTkTTTTkTTk..',
    '..kttk....kttk..',
    '..kTTk....kTTk..',
    '..kddk....kddk..',
    '..kkk......kkk..',
    '................',
    '................',
  ],
  sleeping_bed: [
    '..kkkkkkkkkkkk..',
    '.kTTTTTTTTTTTTk.',
    '.kTwwwwrrRRRRtk.',
    '.kTwwwwrrRRRRtk.',
    '.kTwwwwrrRRRRtk.',
    '.kTTTTTTTTTTTTk.',
    '..kTTk....kTTk..',
    '..kkk......kkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  wooden_chest: [
    '................',
    '................',
    '..kkkkkkkkkkkk..',
    '.kttttttttttttk.',
    '.ktTTTTTTTTTTtk.',
    '.kttttkyykttttk.',
    '.kkkkkkyykkkkkk.',
    '.kTTTTkyykTTTTk.',
    '.kttttttttttttk.',
    '.kTTTTTTTTTTTTk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  iron_strongbox: [
    '................',
    '................',
    '..kkkkkkkkkkkk..',
    '.kmmmmmmmmmmmmk.',
    '.kmMMMMMMMMMMmk.',
    '.kmmmmkyykmmmmk.',
    '.kkkkkkyykkkkkk.',
    '.kMMMMkyykMMMMk.',
    '.kmmmmmmmmmmmmk.',
    '.kMMMMMMMMMMMMk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  escrow_chest: [
    '....kkkkkkkk....',
    '...kyyyyyyyyk...',
    '..kyggggggggyk..',
    '.kygGGGGGGGGgyk.',
    '.kyggggyyggggyk.',
    '.kkkkkkyykkkkkk.',
    '.kyGGGkyykGGGyk.',
    '.kyggggyyggggyk.',
    '.kyyyyyyyyyyyyk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  ragnarok_treasury_chest: [
    '...kkkkkkkkkk...',
    '..kyyyyyyyyyyk..',
    '.kyrrrrrrrrrryk.',
    '.kyrRRRRRRRRryk.',
    '.kyrrrryyrrrryk.',
    '.kkkkkkyykkkkkk.',
    '.kyRRRkyykRRRyk.',
    '.kyrrrryyrrrryk.',
    '.kyyyyyyyyyyyyk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  ancient_core_reliquary: [
    '.....kkkkkk.....',
    '....kppppppk....',
    '...kpwwppwwpk...',
    '...kppppppppk...',
    '..kkmmmmmmmmkk..',
    '.kmmppppppppmmk.',
    '.kmMpwwppwwpMmk.',
    '.kmmppppppppmmk.',
    '.kmMMMMMMMMMMmk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  campfire: [
    '......kkkk......',
    '.....koyyok.....',
    '....kooywyok....',
    '....kroywyok....',
    '...kroooyyook...',
    '....kttkkttk....',
    '..kkttttttttkk..',
    '.kmmTTTTTTTTmmk.',
    '.kMMmmmmmmmmMMk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  fuel_generator: [
    '................',
    '...kkkk..kkkk...',
    '..kMMMMkkrrrrk..',
    '.kmmmmmmmmrrrRk.',
    '.kmMyyyyyymmrrk.',
    '.kmmkddddkmmmmk.',
    '.kmMyyyyyymmmmk.',
    '.kMMMMMMMMMMMMk.',
    '..kddk....kddk..',
    '..kkk......kkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  wind_turbine: [
    '..kkk......kkk..',
    '.kwwwk....kwwwk.',
    '..kwwwk..kwwwk..',
    '...kwwwkkwwwk...',
    '....kkkbbkkk....',
    '...kwwwkkwwwk...',
    '..kwwwkmmkwwwk..',
    '.kwwwk.mm.kwwwk.',
    '..kkk..mm..kkk..',
    '......kmmk......',
    '......kMMk......',
    '.....kmmmmk.....',
    '....kMMMMMMk....',
    '....kkkkkkkk....',
    '................',
    '................',
  ],
  auto_turret: [
    '......kkkkkk....',
    '....kkmmmmmmkk..',
    '...kmmbbbbmmmmk.',
    '...kmmbwwbmmmmk.',
    '....kkmmmmkkkk..',
    '.....kMMMMk.....',
    '....kmmmmmmk....',
    '...kmMyyyymMk...',
    '..kmmMMMMMMmmk..',
    '..kkk......kkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  garden_plot: [
    '.kkkkkkkkkkkkkk.',
    'kttttttttttttttk',
    'ktTTTTgGGTgggTtk',
    'ktTgGGTggTTgGTtk',
    'ktTTgTTTTgGGTTtk',
    'ktTgggTgGTTTTgtk',
    'ktTTTTgGGTggTTtk',
    'kttttttttttttttk',
    '.kkkkkkkkkkkkkk.',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  rain_collector: [
    '..kkkkkkkkkkkk..',
    '.kwwwwwwwwwwwwk.',
    '.kwbbbbbbbbbbwk.',
    '..kttttttttttk..',
    '..ktbbbbbbbbtk..',
    '..ktbwwwwbbbtk..',
    '..kttttttttttk..',
    '..kTTk....kTTk..',
    '..kkk......kkk..',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  stone_outcrop: [
    '................',
    '.....kkkkkk.....',
    '...kkmmmmmmkk...',
    '..kmmwwwwmmmmk..',
    '.kmmmmmmmmMMMMk.',
    '.kmmmMMMMmMMMMk.',
    'kmmmmMMMMMMMMMMk',
    'kMMMMMMMMMMMMMMk',
    '.kkkkkkkkkkkkkk.',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  iron_vein: [
    '................',
    '.....kkkkkk.....',
    '...kkmmmmmmkk...',
    '..kmmooooommmk..',
    '.kmmmoOmmOomMMk.',
    '.kmmoOmmmmOomMMk',
    'kmmmmMMMMMMMMMMk',
    'kMMMMMMMMMMMMMMk',
    '.kkkkkkkkkkkkkk.',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  copper_vein: [
    '................',
    '.....kkkkkk.....',
    '...kkmmmmmmkk...',
    '..kmmggggommmk..',
    '.kmmmgommgomMMk.',
    '.kmmgommmmgomMMk',
    'kmmmmMMMMMMMMMMk',
    'kMMMMMMMMMMMMMMk',
    '.kkkkkkkkkkkkkk.',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  sulfur_vent: [
    '................',
    '.....kkkkkk.....',
    '...kkyyyyyykk...',
    '..kyywwwwyyyyk..',
    '.kmmmyymmyymMMk.',
    '.kmmyymmmmyymMMk',
    'kmmmmMMMMMMMMMMk',
    'kMMMMMMMMMMMMMMk',
    '.kkkkkkkkkkkkkk.',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  death_bag: [
    '.....kkkkkk.....',
    '....kttttttk....',
    '.....kyyyyk.....',
    '...kkttttttkk...',
    '..kttwwwwttttk..',
    '..kttwkddkwttk..',
    '..kttwwwwttttk..',
    '..kTTTTTTTTTTk..',
    '...kkkkkkkkkk...',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
    '................',
  ],
  wayfarer_vendor: [
    '.kkkkkkkkkkkkkk.',
    'krrwwrrwwrrwwrrk',
    'kRRwwRRwwRRwwRRk',
    '.kktkkkkkkkkttk.',
    '..kt..kkkk..tk..',
    '..kt.kBBBBk.tk..',
    '..kt.kssssk.tk..',
    '..ktkBBBBBBktk..',
    '.kkkkkkkkkkkkkk.',
    '.ktttttyytttttk.',
    '.kTTTTTTTTTTTTk.',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
  ],
  evac_beacon: [
    '......kkkk......',
    '.....kbbbbk.....',
    '....kbwwwwbk....',
    '....kbwwwwbk....',
    '.....kbbbbk.....',
    '.....kmmmmk.....',
    '.....krrrrk.....',
    '....kmwwwwmk....',
    '....krrrrrrk....',
    '...kmmmmmmmmk...',
    '...kMMMMMMMMk...',
    '..kkkkkkkkkkkk..',
    '................',
    '................',
    '................',
    '................',
  ],
};

export interface PixelSpriteAtlas {
  kenneyImage: HTMLImageElement | null;
  kenneyLoaded: boolean;
  playerSprites: {
    femaleDown0: HTMLCanvasElement | null;
    femaleDown1: HTMLCanvasElement | null;
    femaleUp0: HTMLCanvasElement | null;
    maleDown0: HTMLCanvasElement | null;
    maleDown1: HTMLCanvasElement | null;
    maleUp0: HTMLCanvasElement | null;
  };
  enemies: Record<string, HTMLCanvasElement | null>;
  eldersLatent: Record<string, HTMLCanvasElement | null>;
  eldersAwakened: Record<string, HTMLCanvasElement | null>;
  props: Record<string, HTMLCanvasElement | null>;
}

let cachedAtlas: PixelSpriteAtlas | null = null;

export function getPixelSpriteAtlas(): PixelSpriteAtlas {
  if (cachedAtlas) return cachedAtlas;

  let kenneyImg: HTMLImageElement | null = null;
  const atlas: PixelSpriteAtlas = {
    kenneyImage: null,
    kenneyLoaded: false,
    playerSprites: {
      femaleDown0: bakePixelMatrix(FEMALE_DOWN_0),
      femaleDown1: bakePixelMatrix(FEMALE_DOWN_1),
      femaleUp0: bakePixelMatrix(FEMALE_UP_0),
      maleDown0: bakePixelMatrix(MALE_DOWN_0),
      maleDown1: bakePixelMatrix(MALE_DOWN_1),
      maleUp0: bakePixelMatrix(MALE_UP_0),
    },
    enemies: {},
    eldersLatent: {},
    eldersAwakened: {},
    props: {},
  };

  if (typeof Image !== 'undefined') {
    kenneyImg = new Image();
    kenneyImg.onload = () => {
      atlas.kenneyLoaded = true;
    };
    kenneyImg.src = KENNEY_TINY_TOWN_DATA_URL;
    if (kenneyImg.complete && kenneyImg.naturalWidth > 0) {
      atlas.kenneyLoaded = true;
    }
    atlas.kenneyImage = kenneyImg;
  }

  for (const [eid, mat] of Object.entries(ENEMY_MATRICES)) {
    atlas.enemies[eid] = bakePixelMatrix(mat);
  }

  const elderPalettes: Record<string, { p1: string; p2: string; awk: string }> = {
    elder_ignis: { p1: '#f97316', p2: '#7c2d12', awk: '#fde047' },
    elder_morass: { p1: '#84cc16', p2: '#365314', awk: '#bef264' },
    elder_boreas: { p1: '#38bdf8', p2: '#0c4a6e', awk: '#e0f2fe' },
    elder_volta: { p1: '#facc15', p2: '#713f12', awk: '#fef08a' },
    elder_ferrum: { p1: '#d6d3d1', p2: '#44403c', awk: '#fb923c' },
    elder_umbra: { p1: '#c084fc', p2: '#4c1d95', awk: '#f5d0fe' },
  };

  for (const [bid, pal] of Object.entries(elderPalettes)) {
    atlas.eldersLatent[bid] = bakePixelMatrix(ELDER_24_TEMPLATE, {
      '1': pal.p1,
      '2': pal.p2,
    });
    atlas.eldersAwakened[bid] = bakePixelMatrix(ELDER_24_TEMPLATE, {
      '1': pal.awk,
      '2': pal.p1,
    });
  }

  for (const [pid, mat] of Object.entries(STRUCTURE_AND_NODE_MATRICES)) {
    atlas.props[pid] = bakePixelMatrix(mat);
  }

  cachedAtlas = atlas;
  return atlas;
}

/**
 * Draws a crisp 16x16 tile from the verified CC0 Kenney Tiny Town packed sheet (`12 cols x 11 rows`).
 */
export function drawKenneyTile(
  ctx: CanvasRenderingContext2D,
  atlas: PixelSpriteAtlas,
  col: number,
  row: number,
  dx: number,
  dy: number,
  dw = 16,
  dh = 16
): boolean {
  if (!atlas.kenneyImage || !atlas.kenneyLoaded) return false;
  ctx.drawImage(atlas.kenneyImage, col * 16, row * 16, 16, 16, Math.round(dx), Math.round(dy), dw, dh);
  return true;
}
