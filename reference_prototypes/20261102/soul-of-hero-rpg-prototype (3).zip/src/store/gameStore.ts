import { sfx } from '../audio/sfx';
import { createInitialGameState, dispatchIntent } from '../sim/engine';
import { clearAllSavedData, loadGameStateAtomic, saveGameStateAtomic } from '../sim/persistence';
import type { AdventurerGender, DispatchResult, GameIntent, GameState } from '../sim/types';

export interface KeyBindings {
  interact: string;
  inventory: string;
  craft: string;
  build: string;
  research: string;
  map: string;
  journal: string;
  skills: string;
  menu: string;
}

export const DEFAULT_KEY_BINDINGS: KeyBindings = {
  interact: 'KeyE',
  inventory: 'KeyI',
  craft: 'KeyC',
  build: 'KeyB',
  research: 'KeyR',
  map: 'KeyM',
  journal: 'KeyJ',
  skills: 'Tab',
  menu: 'Escape',
};

type Listener = () => void;

class AuthoritativeGameStore {
  private state: GameState;
  private listeners = new Set<Listener>();
  private initialized = false;
  private showTitleScreen = true;
  private lastSaveAtMs = 0;
  private lastFeedbackBanner: string | null = null;
  public keyBindings: KeyBindings = { ...DEFAULT_KEY_BINDINGS };

  constructor() {
    this.state = createInitialGameState({
      gender: 'female',
      spawnRegionIndex: 0,
      nowUtcSec: Math.floor(Date.now() / 1000),
    });
  }

  public async initializeFromStorage(): Promise<void> {
    if (this.initialized) return;
    this.initialized = true;

    const loaded = await loadGameStateAtomic('primary');
    if (loaded.loaded && loaded.state) {
      this.state = loaded.state;
      this.showTitleScreen = !this.state.run.active;

      // Immediately settle causal offline world timeline on session reopen (§6 / K8 / C09)
      if (this.state.run.active) {
        const nowUtcSec = Math.floor(Date.now() / 1000);
        const catchup = dispatchIntent(this.state, {
          kind: 'OFFLINE_CATCHUP',
          nowUtcSec,
        });
        if (catchup.accepted) {
          this.state = catchup.state;
          await saveGameStateAtomic(this.state, 'primary');
        }
      }
      this.emit();
    } else if (loaded.corruptionError) {
      this.lastFeedbackBanner = `Save warning: ${loaded.corruptionError}`;
      this.emit();
    }
  }

  public getSnapshot(): GameState {
    return this.state;
  }

  public isOnTitleScreen(): boolean {
    return this.showTitleScreen;
  }

  public setShowTitleScreen(val: boolean): void {
    this.showTitleScreen = val;
    this.emit();
  }

  public getFeedbackBanner(): string | null {
    return this.lastFeedbackBanner;
  }

  public clearFeedbackBanner(): void {
    this.lastFeedbackBanner = null;
    this.emit();
  }

  public updateKeyBinding(action: keyof KeyBindings, code: string): void {
    this.keyBindings = { ...this.keyBindings, [action]: code };
    this.emit();
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(): void {
    for (const l of this.listeners) l();
  }

  public submitIntent(intent: GameIntent, options?: { silent?: boolean }): DispatchResult {
    const prevHp = this.state.actors.player.hp;
    const result = dispatchIntent(this.state, intent);

    if (result.accepted) {
      this.state = result.state;
      if (intent.kind === 'START_NEW_RUN') {
        this.showTitleScreen = false;
      }

      // Trigger local WebAudio SFX cues based on committed physical outcomes
      if (!options?.silent && intent.kind !== 'STEP_SIMULATION') {
        if (intent.kind === 'ACT_ON_TARGET') {
          if (result.receipt?.summary.startsWith('Struck')) sfx.play('hit');
          else if (result.receipt?.summary.includes('Tree') || result.receipt?.summary.includes('Oak')) sfx.play('chop');
          else sfx.play('mine');
        } else if (intent.kind === 'START_CORE_CAST') {
          sfx.play('cast_start');
        } else if (intent.kind === 'BUILD_STRUCTURE' || intent.kind === 'DEPLOY_CART') {
          sfx.play('build');
        } else if (intent.kind === 'QUEUE_RECIPE_JOB' || intent.kind === 'RESEARCH_ACTION') {
          sfx.play('craft');
        } else if (intent.kind === 'DEPOSIT_ESCROW') {
          sfx.play('deposit');
        } else {
          sfx.play('ui');
        }
      }

      if (this.state.actors.player.hp < prevHp - 0.5) {
        sfx.play('hurt');
      }

      // Persist immediately after non-tick intents, and periodically every 4s during movement
      const nowMs = Date.now();
      if (intent.kind !== 'STEP_SIMULATION' || nowMs - this.lastSaveAtMs > 4000) {
        this.lastSaveAtMs = nowMs;
        void saveGameStateAtomic(this.state, 'primary');
      }
      this.emit();
    } else if (!options?.silent && result.reason && intent.kind !== 'STEP_SIMULATION') {
      this.lastFeedbackBanner = result.reason;
      this.emit();
    }

    return result;
  }

  public async saveNow(): Promise<void> {
    await saveGameStateAtomic(this.state, 'primary');
    this.lastFeedbackBanner = `Saved durable snapshot & receipts (rev #${this.state.revision}).`;
    this.emit();
  }

  public async startFreshRun(gender: AdventurerGender, spawnRegionIndex: number): Promise<void> {
    this.submitIntent({
      kind: 'START_NEW_RUN',
      gender,
      spawnRegionIndex,
      nowUtcSec: Math.floor(Date.now() / 1000),
    });
    await saveGameStateAtomic(this.state, 'primary');
  }

  public async hardWipeProfileAndStorage(): Promise<void> {
    await clearAllSavedData();
    this.state = createInitialGameState({
      gender: 'female',
      spawnRegionIndex: 0,
      nowUtcSec: Math.floor(Date.now() / 1000),
    });
    this.showTitleScreen = true;
    this.emit();
  }
}

export const gameStore = new AuthoritativeGameStore();

if (typeof window !== 'undefined') {
  (window as unknown as Record<string, unknown>).__SOUL_OF_HERO__ = gameStore;
}
