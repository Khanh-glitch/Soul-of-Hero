# Third-Party Provenance & License Manifest

All runtime assets and libraries are bundled locally for offline-first execution (zero runtime CDN calls, zero external logins, zero scraped commercial sprites).

## 1. Pixel-Art Assets (`src/assets/ninja/**`)
- **Asset Collection:** Ninja Adventure Asset Pack (Godot 4 reference repository subset)
- **Author:** `pixel-boy` (AAA / Sparklin Labs)
- **Source URLs:**
  - Repository: `https://github.com/pixel-boy/NinjaAdventure` (commit `6ac78232d5aedcc85ce5f27d060ea92366f7c24a`)
  - Official Release & License Page: `https://pixel-boy.itch.io/ninja-adventure-asset-pack`
- **License:** **Creative Commons Zero v1.0 Universal (CC0 1.0)** — Public Domain Dedication ("They are released under the Creative Commons Zero (CC0) license. No generative AI was used.")
- **Integrated Files:**
  - `characters/`: `samurai_blue.png` (Male Adventurer base & Female Adventurer pixel-derived variant), `ninja_blue.png` (Wasteland Raider), `samurai_green.png` (Fen Lurker), `pig.png` (Razorback Boar), `shadow.png`
  - `tilesets/`: `tileset_floor.png`, `tileset_interior_floor.png`, `tileset_village_abandoned.png`, `tileset_wall_simple.png`, `tileset_animated.png`
  - `props/` & `weapons/`: `crate.png`, `pot.png`, `grass.png`, `axe.png`, `big_sword.png`, `bone.png`, `book.png`, `club.png`
  - `fx/` & `ui/`: `particle_wood.png`, `particle_rock.png`, `particle_grass.png`, `rain_on_floor.png`, `snow.png`, `heart.png`, `nine_path_panel.png`
- **Original Supplemental Pixel Art (`src/art/pixelSprites.ts`):**
  - Cohesive 16×16 and 32×32 integer pixel-matrix rasters (`#14181e` 1px outline, 3-tone shading, `imageSmoothingEnabled = false`) authored specifically for Soul of Hero's Female Adventurer variant, Frostbite/Caldera/Industrial creatures, 6 Latent/Awakened Elders, 60 item icons, and 22 buildable structures/stations (`GOLD_SOURCE_NOT_AVAILABLE`).

## 2. Runtime & Test Libraries (`package.json`)
| Package | Pinned Version | License | Source URL | Role in SOH |
| --- | --- | --- | --- | --- |
| `simplex-noise` | `4.0.3` | MIT | `https://github.com/jwagner/simplex-noise.js` | Seeded terrain/moisture noise primitive inside `src/engine/worldGen.ts` |
| `idb` | `8.0.2` | ISC | `https://github.com/jakearchibald/idb` | Atomic versioned IndexedDB snapshot & receipt storage in `src/storage/persistence.ts` |
| `react` / `react-dom` | `19.2.6` | MIT | `https://github.com/facebook/react` | Read-only state snapshot UI overlays submitting intents to `dispatch()` |
| `vitest` | `3.0.7` | MIT | `https://github.com/vitest-dev/vitest` | Deterministic causal contract (`C01–C24`) test runner |
| `fast-check` | `3.23.2` | MIT | `https://github.com/dubzzz/fast-check` | Property-based item custody conservation verification |
