# Soul of Hero — Standalone Browser Edition

Offline-first, solo top-down pixel-art survival action RPG built on a single deterministic TypeScript causal engine (`dispatch(intent, currentState)`), crisp `640×360` logical HTML5 Canvas rendering, React snapshot overlays, and atomic IndexedDB persistence.

## Quick Start (Node 20+)

```bash
npm install
npm run dev      # Start local Vite dev server
npm run build    # Produce standalone self-contained dist/index.html
npx vitest run   # Run deterministic + fast-check causal contract suite (C01-C24)
```

## Controls

- **Move:** `W A S D` or Arrow Keys
- **360° Aim & Primary Action (Attack / Harvest / Cast Charged Core):** Mouse Aim + `Left-Click`
- **Cancel Uncommitted Windup / Exit Build Placement:** `Right-Click` or `X` (canceling a Charged Core during windup preserves its charge)
- **Interact (Loot Bag/Vault, Open/Close Door, Insert Fuse, Bind Bed, Hitch Handcart, Evacuate):** `E`
- **Quickbar Slots:** `1` – `8`
- **Backpack, Armor & Adjacent Container/Station/Vendor/Escrow Custody:** `I`
- **Crafting & Toolmaking:** `C`
- **Homestead & Structure Placement / Reclaim:** `B`
- **Research & Specimen Study:** `R`
- **Island Expedition Map:** `M`
- **Combat Profile & Six Elder Stones:** `Tab`
- **Save / Audio / Abandon Run / QA Time Accelerator:** `Esc`

## Editable Balance & Content Catalogs

- `src/data/balance.v1.json` — Editable parameters tagged with `LOCKED_CANON`, `TUNABLE_BALANCE`, `PROPOSED_MECHANISM`, and `GOLD_SOURCE_NOT_AVAILABLE`.
- `src/data/itemsCatalog.ts` — 60 physical items (tools, weapons, 6 Charged Cores, hazard gear, fuels, crops, keys/fuses, blueprints, deployable kits, 6 Elder Stones, and physical Ragnarok Cash).
- `src/data/recipesCatalog.ts` — 35 handcraft, workbench, furnace, campfire, planter, and researchable recipes under one run-local knowledge authority.
- `src/data/structuresCatalog.ts` — 22 buildable foundations, walls, doors, occluding roofs, stations, defenses, Freight Handcart, and `Rương ký gửi` Escrow Vault.

## Provenance & Verification

- Third-party licenses & asset provenance: [`THIRD_PARTY_LICENSES.md`](./THIRD_PARTY_LICENSES.md)
- `K1–K8` & `C01–C24` trace ledger: [`IMPLEMENTATION_EVIDENCE.md`](./IMPLEMENTATION_EVIDENCE.md)
