# Soul of Hero — Implementation Evidence (`K1–K8` & `C01–C24`)

## 1. Authority & Canon Compliance
- **Canonical Reference Consulted:** `docs/survival/CURRENT_PRODUCT_CONTRACT.md` (`Khanh-glitch/Soul-of-Hero`, commit `103e4440-soul-of-hero`, fetched and inspected directly).
- **Single Causal Authority:** `GameState` (`src/engine/types.ts`) mutated exclusively through deterministic `dispatch(intent, currentState)` (`src/engine/dispatcher.ts`). React UI (`src/App.tsx`, `src/components/*`) and Canvas (`src/render/worldRenderer.ts`) are strictly subordinate observers/intent-emitters.
- **Status Markers Preserved (`src/data/balance.v1.json`):**
  - `LOCKED_CANON` (`[CHỐT]`): 336h max UTC run, final 72h Ragnarok (`264h+`), Day 14 Elder awakening (`312h+`), physical items & single K4 run-local recipe authority, non-GPS footprint tracking, offline roofed shelter 1-HP hunger floor, finite final-72 POI Ragnarok Cash, owned-home `Rương ký gửi` atomic deposit, cash-only cross-run profile retention, total run-local wipe on end, `LOCAL_UNVERIFIED` browser score/history.
  - `PROPOSED_MECHANISM` (`[ĐỀ XUẤT]`): Crossroads Escrow Broker selling physical `Rương ký gửi` (`escrow_chest_kit`) for `140` physical unsecured Ragnarok Cash (enabling zero-wallet no-Elder first escrow), and auto-establishing a 9-tile Homestead ownership radius on first foundation floor or Homestead Claim Totem.
  - `TUNABLE_BALANCE` (`[CẦN ĐO]`): All survival drain rates, fuel burn durations, research Spares costs, cart road/marsh multipliers, weather cycle lengths, and score weights in `src/data/balance.v1.json`.
  - `GOLD_SOURCE_NOT_AVAILABLE`: Private Gold sprite/VFX assets are unavailable; cohesive 16×16/32×32 pixel art (`pixel-boy/NinjaAdventure` CC0 + matching integer pixel-matrix rasters) powers all characters, creatures, 6 Elders, items, structures, and directional VFX.

## 2. Eight State Owners (`K1–K8`)
| Owner | Code Authority | Responsibility |
| --- | --- | --- |
| **K1 Custody** | `src/engine/custody.ts`, `src/data/itemsCatalog.ts` | 60 item definitions, single `ItemInstance` ID registry across backpack, armor, chests, stations, carts, drops, and death bags |
| **K2 Environment** | `src/engine/worldGen.ts`, `src/engine/simulation.ts` | Deterministic 200×200 island, 8 biomes, rivers/bridges, weather (`CLEAR`/`RAIN`/`STORM`/`COLD_SNAP`/`ASH_WIND`), brushfire spread/extinguish, decaying footprints |
| **K3 Sources** | `src/engine/worldGen.ts`, `src/engine/dispatcher.ts` | Finite roadside crates, lockers, and Final-72 cash vaults (`respawnDelaySec: null`); timed renewal on natural flora/timber/ore |
| **K4 Knowledge/Work** | `src/data/recipesCatalog.ts`, `src/engine/simulation.ts` | 35 recipes in one run-local `knowledge.unlockedRecipes` list; fuel/water-bounded station jobs |
| **K5 Actors/AI** | `src/engine/simulation.ts`, `src/engine/pathfinding.ts` | Male/Female Adventurer, 360° windup-commit-recovery combat, 6 habitat creatures + 6 Latent/Awakened Elders, sight + footprint tracking |
| **K6 Structures/POIs** | `src/data/structuresCatalog.ts`, `src/engine/dispatcher.ts` | 22 buildable structures with real collision/HP/roof occlusion, owned homestead checks, 4 walled multi-layer POIs with fuse/keycard gates |
| **K7 Freight/Routes** | `src/engine/dispatcher.ts` (`TICK`), `src/engine/pathfinding.ts` | Carry + Handcart weight physics, road vs offroad vs marsh speed multipliers, bridge crossings |
| **K8 Clock/Profile** | `src/engine/simulation.ts`, `src/storage/persistence.ts` | 336h UTC run clock + chronological offline catch-up, separate fictional day/night clock, IndexedDB atomic commits, Run 2 wipe & profile retention |

## 3. Causal Contract Trace Matrix (`C01–C24`)
All 24 contracts are implemented and verified in `src/engine/__tests__/contracts.test.ts` (`npx vitest run` — 9/9 test suites passing, including `fast-check` property conservation):

| Contract | Status | Code Path | Verification Evidence |
| --- | --- | --- | --- |
| **C01** | `PASS` | `dispatcher.ts` (`commitWindupEffect`, `depleteSourceOnce`) | Depletes node stock once, grants physical yield; repeated hits on 0-stock node yield nothing |
| **C02** | `PASS` | `worldGen.ts` (`road_crate`, `oil_barrel`), `dispatcher.ts` | Roadside salvage grants finite `spares`/`scrap_metal` once (`respawnDelaySec: null`) |
| **C03** | `PASS` | `dispatcher.ts` (`PRIMARY_ACTION`, `CANCEL_WINDUP`) | Found Charged Core casts before learning recipe; `CANCEL_WINDUP` before commit spends 0 charges; commit debits 1 charge |
| **C04** | `PASS` | `dispatcher.ts` (`USE_ITEM` blueprint, `RESEARCH_UNLOCK`) | Blueprint, random/directed Spares, and specimen study unlock into `knowledge.unlockedRecipes` once; duplicate rejected with 0 debit |
| **C05** | `PASS` | `dispatcher.ts` (`commitWindupEffect`), `simulation.ts` | Shared swing separates monster HP damage from harvest yield; `core_ember` ignites dry flammable tiles & chops trees |
| **C06** | `PASS` | `simulation.ts` (`advanceStationsAndJobs`) | Furnace smelts only while physical fuel burns (`PAUSED_NO_FUEL` on exhaustion); planter requires water/rain |
| **C07** | `PASS` | `dispatcher.ts` (`BUILD_STRUCTURE`, `RECLAIM_STRUCTURE`) | Atomic material debit + collision; invalid placement rolls back with 0 debit; loaded chest reclaim + `fast-check` splits conserve 100% of items |
| **C08** | `PASS` | `dispatcher.ts` (`footprints`), `simulation.ts` (`TRACK_TRACE`) | Monsters only detect player via line-of-sight or physical footprint encounter; never GPS-locate an unseen home |
| **C09** | `PASS` | `simulation.ts` (`settleChronologicalSeconds`, `advancePlayerSurvival`) | Chronological offline settlement; lawful roof shelter prevents offline hunger death at `1 HP` floor without granting cold/fire immunity |
| **C10** | `PASS` | `simulation.ts` (`handlePlayerDeath`), `dispatcher.ts` (`RESPAWN_AFTER_DEATH`) | Death moves backpack items once into unique `death_bag` at coordinates; same-run respawn & physical `[E]` recovery |
| **C11** | `PASS` | `worldGen.ts` (walled POIs), `dispatcher.ts` (`poi_power_box`, `poi_gate`) | Useful exterior caches + gated inner vault opened via exterior `copper_fuse` / `core_volt` or `blue_keycard` with safe exit |
| **C12** | `PASS` | `recipesCatalog.ts` (`BASELINE_RECIPE_IDS`), `dispatcher.ts` | Zero tutorial/quest gates; crafting, building, and scavenging work in any order |
| **C13** | `PASS` | `dispatcher.ts` (`TICK` freight speed), `balance.v1.json` | Hitched `handcart` +95 kg capacity rolls >2.2× faster on Ring-Road than through Sunken Fen mud |
| **C14** | `PASS` | `simulation.ts` (`advanceEnvironmentAndSources`) | `RAIN`/`STORM` extinguishes fires, accelerates footprint erosion (`4.5×`/`7.5×`), and fills Rain Collectors; no reload respawn exploit |
| **C15** | `PASS` | `worldGen.ts` (`final72_cash_vault`), `dispatcher.ts` (`LOOT_SOURCE`) | Time-locked before `264h`; mints finite physical `ragnarok_cash` once per vault in Final 72h; never dropped by monsters or score |
| **C16** | `PASS` | `dispatcher.ts` (`BUY_ESCROW_CHEST_PHYSICAL`, `DEPOSIT_RAGNAROK_CASH`) | Verified 0-wallet, 0-Elder path: loot non-boss Final-72 vaults → buy `escrow_chest_kit` (`140` cash) → place on owned home → positive deposit |
| **C17** | `PASS` | `dispatcher.ts` (`DEPOSIT_RAGNAROK_CASH`) | Atomic physical cash debit + `profile.securedCash` credit on owned Homestead land; idempotent `requestId` prevents replay |
| **C18** | `PASS` | `dispatcher.ts` (`BUY_SEASON_VENDOR_ITEM`) | Run 2+ physical Season Supply Merchant debits `profile.securedCash` and issues finite stocked run-local items |
| **C19** | `PASS` | `worldGen.ts`, `simulation.ts` (`awakenEldersIfDay14`), `pixelSprites.ts` | 6 distinct regional Elders with `latent` (Days 1–13) and `awakened` (Day 14 / `312h+`) forms, distinct telegraphs, and 6 unique stones |
| **C20** | `PASS` | `simulation.ts` (`recordUniqueScore`) | Once-only accomplishment receipts (deep POI, first escrow, Elder defeat, evacuation, 6-stone convergence); never mints currency |
| **C21** | `PASS` | `types.ts`, `TitleScreen.tsx`, `App.tsx` | All score receipts and run history entries explicitly tagged `LOCAL / UNVERIFIED` (and `QA` when QA time tools are used) |
| **C22** | `PASS` | `dispatcher.ts` (`BEGIN_EVACUATION`), `simulation.ts` (`finalizeRunOnce`) | Physical evacuation channel at West Harbor or South Lighthouse pier; distinct from `ABANDONED` and `EXPIRED_336H`; unbanked cash is NOT auto-secured |
| **C23** | `PASS` | `simulation.ts` (`finalizeRunOnce`), `dispatcher.ts` (`START_NEW_RUN`) | Legal run end wipes all run-local items, Cores, buildings, recipes, bags, stones, and unbanked cash; retains only `profile` fields |
| **C24** | `PASS` | `worldGen.ts` (`getStaticIslandMap`, `spawnRegions`) | Persistent 200×200 island with 4 distinct safe viable starting regions (`Driftwood Meadow`, `Timberwatch Glade`, `Wayfarer's Mile`, `Granite Ford`) |

## 4. Inspected Real-Browser Visual & Interaction Checks
Executed in headless Chromium (`156.0.8078.4`) against `vite preview` at native **`640×360`** and **`1280×720`** (`.evidence_shots/`):
- `01_title_640x360.png` — Verified unclipped `Enter Island ▶`, Male/Female Adventurer cards, 4-region selector, and `History` button at `640×360`.
- `02_world_640x360.png` & `09_pinewood_1280x720.png` — Verified seamless pixel terrain, directional shoreline foam, road curbs, multi-canopy trees, distinct Female/Male Adventurer sprites, and compact readable HUD.
- `05_map_1280x720.png` — Verified 200×200 island geography (harbor bay, central lake, continuous rivers with bridges, eastern isthmus, 8 biomes, 6 Elder sanctums, POIs, vendors, evacuation piers).
- `07_inventory_ragnarok_1280x720.png` & `08_reloaded_title_1280x720.png` — Verified Ragnarok phase HUD, tactile 24-slot custody grid, and real cross-session IndexedDB reload (`Resume Run #1`).
- `10_skills_stones_1280x720.png`, `11_run_finalized_1280x720.png`, `12_history_unverified_1280x720.png` — Verified Core/Elder Stones overview, Run Finalized wipe report, and `LOCAL / UNVERIFIED` Run Archive.

## 5. Honest Limitations
- **Offline Client Time & Leaderboard Trust (`LOCKED_CANON`):** Because this is a standalone browser build with no remote authentication server, system clock and IndexedDB storage reside on the player's machine; all history and scores are labeled `LOCAL / UNVERIFIED`.
- **Gold Original Art (`GOLD_SOURCE_NOT_AVAILABLE`):** Original private Godot Gold sprite sheets/shaders are not publicly accessible; all visuals use verified CC0 `pixel-boy/NinjaAdventure` 16×16 sheets paired with custom integer-pixel rasters authored in the same visual grammar.
