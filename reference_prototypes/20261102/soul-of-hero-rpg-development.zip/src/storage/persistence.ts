import { openDB, IDBPDatabase } from 'idb';
import { GameState, ProfileState } from '../engine/types';

const DB_NAME = 'soul_of_hero_db_v1';
const DB_VERSION = 1;
const SNAPSHOT_KEY = 'active_game_state';
const PROFILE_BACKUP_KEY = 'soh_profile_backup_v1';
const FALLBACK_STORAGE_KEY = 'soh_fallback_snapshot_v1';

let dbPromise: Promise<IDBPDatabase> | null = null;

function getDb(): Promise<IDBPDatabase> {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('snapshots')) {
          db.createObjectStore('snapshots');
        }
        if (!db.objectStoreNames.contains('receipt_ledger')) {
          db.createObjectStore('receipt_ledger', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
}

export function isValidGameStateSnapshot(candidate: unknown): candidate is GameState {
  if (!candidate || typeof candidate !== 'object') return false;
  const s = candidate as Partial<GameState>;
  return (
    s.schemaVersion === 1 &&
    typeof s.revision === 'number' &&
    !!s.profile &&
    typeof s.profile.securedCash === 'number' &&
    !!s.run &&
    !!s.clock &&
    !!s.world &&
    !!s.actors?.player &&
    !!s.custody?.containers?.['player_inv']
  );
}

export async function saveAtomicSnapshot(state: GameState): Promise<void> {
  try {
    const db = await getDb();
    const tx = db.transaction(['snapshots', 'receipt_ledger'], 'readwrite');
    await tx.objectStore('snapshots').put(state, SNAPSHOT_KEY);
    const latestReceipt = state.receipts[0];
    if (latestReceipt) {
      await tx.objectStore('receipt_ledger').put(latestReceipt);
    }
    await tx.done;
  } catch {
    // Fallback to localStorage if IndexedDB is restricted in private/sandbox mode
  }

  try {
    localStorage.setItem(PROFILE_BACKUP_KEY, JSON.stringify(state.profile));
    localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota warnings on fallback
  }
}

export async function loadPersistedSnapshot(): Promise<{
  state: GameState | null;
  profile: ProfileState | null;
  corrupted: boolean;
}> {
  let loaded: unknown = null;
  let hadRawData = false;

  try {
    const db = await getDb();
    loaded = await db.get('snapshots', SNAPSHOT_KEY);
    if (loaded !== undefined && loaded !== null) hadRawData = true;
  } catch {
    // Fallback below
  }

  if (!loaded) {
    try {
      const raw = localStorage.getItem(FALLBACK_STORAGE_KEY);
      if (raw) {
        hadRawData = true;
        loaded = JSON.parse(raw);
      }
    } catch {
      return { state: null, profile: loadBackupProfile(), corrupted: true };
    }
  }

  if (loaded) {
    if (isValidGameStateSnapshot(loaded)) {
      return { state: loaded, profile: loaded.profile, corrupted: false };
    }
    return { state: null, profile: loadBackupProfile(), corrupted: hadRawData };
  }

  return { state: null, profile: loadBackupProfile(), corrupted: false };
}

function loadBackupProfile(): ProfileState | null {
  try {
    const raw = localStorage.getItem(PROFILE_BACKUP_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw) as ProfileState;
    if (typeof p.securedCash === 'number' && Array.isArray(p.runHistory)) {
      return p;
    }
  } catch {
    // ignore
  }
  return null;
}
