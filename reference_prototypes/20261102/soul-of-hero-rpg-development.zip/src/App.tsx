import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import balance from './data/balance.v1.json';
import { ITEMS_CATALOG } from './data/itemsCatalog';
import { STRUCTURES_CATALOG } from './data/structuresCatalog';
import { loadArtAtlas, LoadedArtAtlas } from './art/pixelSprites';
import { soundEngine } from './audio/soundEngine';
import { ActiveModalKind, GameModals } from './components/GameModals';
import { IslandMapModal } from './components/IslandMapModal';
import { TitleScreen } from './components/TitleScreen';
import {
  computeContainerWeightKg,
  computePlayerCarryWeightKg,
  countItemInContainer,
} from './engine/custody';
import { createDefaultProfile, createNewRunGameState, dispatch } from './engine/dispatcher';
import {
  canBuildAtTile,
  getElapsedRunHours,
  isInFinal72Hours,
  isPlayerInLawfulShelter,
} from './engine/simulation';
import { AdventurerGender, GameIntent, GameState, ProfileState, StructureKind } from './engine/types';
import { getStaticIslandMap } from './engine/worldGen';
import { LOGICAL_HEIGHT, LOGICAL_WIDTH, renderGameWorld, TILE_PX } from './render/worldRenderer';
import { loadPersistedSnapshot, saveAtomicSnapshot } from './storage/persistence';

export function App() {
  const [atlas, setAtlas] = useState<LoadedArtAtlas | null>(null);
  const [bootDone, setBootDone] = useState(false);
  const [screen, setScreen] = useState<'title' | 'playing'>('title');
  const [profile, setProfile] = useState<ProfileState>(createDefaultProfile);
  const [savedRun, setSavedRun] = useState<GameState | null>(null);
  const [uiState, setUiState] = useState<GameState | null>(null);
  const [modal, setModal] = useState<ActiveModalKind>('none');
  const [buildPreviewKind, setBuildPreviewKind] = useState<StructureKind | null>(null);
  const [toast, setToast] = useState<{ text: string; isError?: boolean; id: number } | null>(null);

  const stateRef = useRef<GameState | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const keysHeldRef = useRef<Set<string>>(new Set());
  const mouseLogicalRef = useRef<{ x: number; y: number }>({ x: LOGICAL_WIDTH / 2 + 24, y: LOGICAL_HEIGHT / 2 });
  const cameraRef = useRef<{ camX: number; camY: number }>({ camX: 0, camY: 0 });
  const modalRef = useRef<ActiveModalKind>('none');
  const buildKindRef = useRef<StructureKind | null>(null);

  modalRef.current = modal;
  buildKindRef.current = buildPreviewKind;

  const showToast = useCallback((text: string, isError = false) => {
    setToast({ text, isError, id: Date.now() + Math.random() });
  }, []);

  // Boot art atlas & load persisted IndexedDB snapshot
  useEffect(() => {
    let mounted = true;
    (async () => {
      const [loadedAtlas, persisted] = await Promise.all([loadArtAtlas(), loadPersistedSnapshot()]);
      if (!mounted) return;
      setAtlas(loadedAtlas);
      if (persisted.profile) setProfile(persisted.profile);
      if (persisted.state) {
        setSavedRun(persisted.state);
        setProfile(persisted.state.profile);
      }
      if (persisted.corrupted) {
        showToast('Recovered profile backup after corrupted local snapshot', true);
      }
      setBootDone(true);
    })();
    return () => {
      mounted = false;
    };
  }, [showToast]);

  // Unified intent submission -> authoritative deterministic dispatch -> atomic save
  const submitIntent = useCallback(
    (intent: GameIntent) => {
      const cur = stateRef.current;
      if (!cur) return;
      const res = dispatch(intent, cur);
      if (res.accepted) {
        const prevHp = cur.actors.player.hp;
        stateRef.current = res.state;
        setUiState(res.state);
        setProfile(res.state.profile);
        if (res.state.run.active) setSavedRun(res.state);
        else setSavedRun(null);

        if (res.state.actors.player.hp < prevHp - 0.5) {
          soundEngine.playPlayerHurt();
        }
        if (res.receipt && intent.type !== 'TICK') {
          showToast(res.receipt.summary, false);
          void saveAtomicSnapshot(res.state);
        }
      } else if (res.rejectionReason && intent.type !== 'TICK') {
        showToast(res.rejectionReason, true);
      }
    },
    [showToast]
  );

  const handleStartNewRun = useCallback(
    (gender: AdventurerGender, spawnRegionId?: string) => {
      const fresh = createNewRunGameState({
        gender,
        spawnRegionId,
        nowUtcMs: Date.now(),
        existingProfile: profile,
      });
      stateRef.current = fresh;
      setUiState(fresh);
      setProfile(fresh.profile);
      setSavedRun(fresh);
      setModal('none');
      setBuildPreviewKind(null);
      setScreen('playing');
      void saveAtomicSnapshot(fresh);
      showToast(fresh.receipts[0]?.summary ?? 'Expedition started');
    },
    [profile, showToast]
  );

  const handleResumeRun = useCallback(() => {
    if (!savedRun) return;
    const settled = dispatch({ type: 'SETTLE_OFFLINE', nowUtcMs: Date.now(), requestId: `res_${Date.now()}` }, savedRun);
    const active = settled.state;
    stateRef.current = active;
    setUiState(active);
    setProfile(active.profile);
    setModal('none');
    setBuildPreviewKind(null);
    setScreen('playing');
    void saveAtomicSnapshot(active);
    if (settled.receipt) {
      showToast(settled.receipt.summary);
    }
  }, [savedRun, showToast]);

  // Find nearest in-world interaction prompt for [E]
  const computeNearestPrompt = useCallback((s: GameState): { x: number; y: number; label: string; opensInventoryModal?: boolean } | null => {
    const p = s.actors.player;
    if (p.dead || !s.run.active) return null;

    type PromptCand = { x: number; y: number; dist: number; label: string; opensInventoryModal?: boolean };
    let best = null as PromptCand | null;
    const consider = (x: number, y: number, label: string, maxD = 2.5, opensInventoryModal = false) => {
      const d = Math.hypot(x - p.x, y - p.y);
      if (d <= maxD && (!best || d < best.dist)) {
        best = { x, y, dist: d, label, opensInventoryModal };
      }
    };

    for (const ent of Object.values(s.entities)) {
      if (ent.hp <= 0) continue;
      if (ent.kind === 'death_bag') consider(ent.x, ent.y, 'Recover Death Bag', 2.4);
      else if (ent.kind === 'world_drop') consider(ent.x, ent.y, 'Pick Up Loot', 2.35);
      else if (ent.kind === 'wood_door' || ent.kind === 'reinforced_door') {
        consider(ent.x, ent.y, ent.open ? 'Close Door' : 'Open Door', 2.4);
      } else if (ent.kind === 'poi_power_box' && !ent.powered) {
        consider(ent.x, ent.y, 'Insert Fuse (Power Gate)', 2.5);
      } else if (ent.kind === 'poi_gate' && !ent.open) {
        consider(ent.x, ent.y, ent.requiredKeyDefId === 'blue_keycard' ? 'Swipe Passcard' : 'Locked Vault Gate', 2.5);
      } else if (ent.kind === 'bedroll') consider(ent.x, ent.y, 'Bind Respawn Bed', 2.3);
      else if (ent.kind === 'handcart') {
        consider(ent.x, ent.y, p.hitchedCartEntityId === ent.id ? 'Unhitch / Cargo [I]' : 'Hitch Handcart', 2.4);
      } else if (ent.kind === 'evac_beacon') {
        consider(ent.x, ent.y, 'Evacuate Island (Ends Run)', 2.8);
      } else if (ent.kind === 'escrow_chest') {
        consider(ent.x, ent.y, 'Deposit Ragnarok Cash', 2.6, true);
      } else if (ent.kind === 'vendor_escrow_broker') {
        consider(ent.x, ent.y, 'Escrow Broker Shop', 2.8, true);
      } else if (ent.kind === 'vendor_season_shop') {
        consider(ent.x, ent.y, 'Season Supply Shop', 2.8, true);
      } else if (
        ent.kind === 'storage_chest' ||
        ent.kind === 'stone_furnace' ||
        ent.kind === 'campfire' ||
        ent.kind === 'planter_box' ||
        ent.kind === 'rain_collector' ||
        ent.kind === 'generator'
      ) {
        consider(ent.x, ent.y, `Open ${STRUCTURES_CATALOG[ent.kind]?.name ?? ent.kind}`, 2.5, true);
      }
    }

    for (const src of Object.values(s.sources)) {
      if (src.stock <= 0 || src.interactionMode !== 'loot_open') continue;
      if (src.requiresFinal72) {
        consider(
          src.x,
          src.y,
          isInFinal72Hours(s) ? 'Loot Ragnarok Cash Vault!' : 'Sealed Until Final 72h',
          2.4
        );
      } else {
        consider(src.x, src.y, 'Search Cache', 2.4);
      }
    }

    return best ? { x: best.x, y: best.y, label: best.label, opensInventoryModal: best.opensInventoryModal } : null;
  }, []);

  // Keyboard & Blur Focus Recovery Handlers
  useEffect(() => {
    if (screen !== 'playing') return;

    const clearKeys = () => keysHeldRef.current.clear();

    const onKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (stateRef.current?.actors.player.dead && key !== 'escape') return;

      if (e.key === 'Tab') {
        e.preventDefault();
        soundEngine.playUiClick();
        setModal((m) => (m === 'skills' ? 'none' : 'skills'));
        return;
      }

      if (e.key === 'Escape') {
        e.preventDefault();
        soundEngine.playUiClick();
        if (buildKindRef.current) {
          setBuildPreviewKind(null);
        } else if (modalRef.current !== 'none') {
          setModal('none');
        } else {
          setModal('pause');
        }
        return;
      }

      // Quickbar 1-8
      if (key >= '1' && key <= '8') {
        const idx = parseInt(key, 10) - 1;
        submitIntent({ type: 'SELECT_QUICKSLOT', slotIndex: idx });
        return;
      }

      if (key === 'i') {
        soundEngine.playUiClick();
        setModal((m) => (m === 'inventory' ? 'none' : 'inventory'));
        return;
      }
      if (key === 'c') {
        soundEngine.playUiClick();
        setModal((m) => (m === 'craft' ? 'none' : 'craft'));
        return;
      }
      if (key === 'b') {
        soundEngine.playUiClick();
        if (buildKindRef.current) setBuildPreviewKind(null);
        else setModal((m) => (m === 'build' ? 'none' : 'build'));
        return;
      }
      if (key === 'r') {
        soundEngine.playUiClick();
        setModal((m) => (m === 'research' ? 'none' : 'research'));
        return;
      }
      if (key === 'm') {
        soundEngine.playUiClick();
        setModal((m) => (m === 'map' ? 'none' : 'map'));
        return;
      }
      if (key === 'x') {
        submitIntent({ type: 'CANCEL_WINDUP', reason: 'player_cancel' });
        if (buildKindRef.current) setBuildPreviewKind(null);
        return;
      }
      if (key === 'e' && modalRef.current === 'none') {
        const cur = stateRef.current;
        if (!cur) return;
        const prompt = computeNearestPrompt(cur);
        if (prompt?.opensInventoryModal) {
          soundEngine.playUiClick();
          setModal('inventory');
        } else {
          soundEngine.playPickup();
          submitIntent({ type: 'INTERACT_NEAREST', nowMs: Date.now(), requestId: `e_${Date.now()}` });
        }
        return;
      }

      keysHeldRef.current.add(key);
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysHeldRef.current.delete(e.key.toLowerCase());
    };

    const onVisibility = () => {
      clearKeys();
      if (document.visibilityState === 'hidden' && stateRef.current) {
        void saveAtomicSnapshot(stateRef.current);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearKeys);
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearKeys);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [screen, submitIntent, computeNearestPrompt]);

  // Main 60fps Deterministic Simulation + Crisp 640x360 Render Loop
  useEffect(() => {
    if (screen !== 'playing' || !atlas) return;
    let rafId = 0;
    let lastMs = performance.now();
    let lastUiSyncMs = 0;
    let lastAutoSaveMs = performance.now();

    const frame = (perfNow: number) => {
      const dtSec = Math.min(0.08, Math.max(0.005, (perfNow - lastMs) / 1000));
      lastMs = perfNow;
      const wallNowMs = Date.now();

      const cur = stateRef.current;
      if (cur && cur.run.active) {
        // Compute movement vector from WASD / Arrow keys when no modal is blocking movement
        let mx = 0;
        let my = 0;
        if (modalRef.current === 'none') {
          const k = keysHeldRef.current;
          if (k.has('w') || k.has('arrowup')) my -= 1;
          if (k.has('s') || k.has('arrowdown')) my += 1;
          if (k.has('a') || k.has('arrowleft')) mx -= 1;
          if (k.has('d') || k.has('arrowright')) mx += 1;
        }

        const cursorWorldX = (cameraRef.current.camX + mouseLogicalRef.current.x) / TILE_PX;
        const cursorWorldY = (cameraRef.current.camY + mouseLogicalRef.current.y) / TILE_PX;
        const aimRad = Math.atan2(cursorWorldY - cur.actors.player.y, cursorWorldX - cur.actors.player.x);

        const prevVfxCount = cur.world.vfx.length;
        const res = dispatch(
          {
            type: 'TICK',
            dtSec,
            nowUtcMs: wallNowMs,
            moveX: mx,
            moveY: my,
            aimRad,
            aimWorldX: cursorWorldX,
            aimWorldY: cursorWorldY,
          },
          cur
        );

        if (res.accepted) {
          stateRef.current = res.state;

          // Trigger tactile material audio cues when new VFX or footsteps occur
          if ((mx !== 0 || my !== 0) && !res.state.actors.player.dead) {
            const map = getStaticIslandMap(res.state.world.seed);
            const tx = Math.max(0, Math.min(map.width - 1, Math.floor(res.state.actors.player.x)));
            const ty = Math.max(0, Math.min(map.height - 1, Math.floor(res.state.actors.player.y)));
            soundEngine.playFootstep(map.surfaces[ty * map.width + tx], wallNowMs);
          }

          if (res.state.world.vfx.length > prevVfxCount) {
            const newest = res.state.world.vfx[res.state.world.vfx.length - 1];
            if (newest.kind === 'harvest_chips') soundEngine.playHarvestWood();
            else if (newest.kind === 'hit_spark') soundEngine.playMonsterHit();
            else if (
              newest.kind === 'ember_arc' ||
              newest.kind === 'frost_nova' ||
              newest.kind === 'volt_lance' ||
              newest.kind === 'thorn_snare' ||
              newest.kind === 'aegis_pulse'
            ) {
              soundEngine.playCoreCast(newest.kind);
            }
          }

          if (perfNow - lastUiSyncMs > 95 || !res.state.run.active || res.state.actors.player.dead !== cur.actors.player.dead) {
            lastUiSyncMs = perfNow;
            setUiState(res.state);
          }

          if (perfNow - lastAutoSaveMs > 4500) {
            lastAutoSaveMs = perfNow;
            void saveAtomicSnapshot(res.state);
          }
        }
      }

      // Draw crisp 640x360 world canvas
      const drawState = stateRef.current;
      const canvas = canvasRef.current;
      if (drawState && canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const cursorWorldX = (cameraRef.current.camX + mouseLogicalRef.current.x) / TILE_PX;
          const cursorWorldY = (cameraRef.current.camY + mouseLogicalRef.current.y) / TILE_PX;
          const prompt = computeNearestPrompt(drawState);
          const cam = renderGameWorld(ctx, drawState, atlas, {
            buildPreviewKind: buildKindRef.current,
            cursorWorldX,
            cursorWorldY,
            nowMs: wallNowMs,
            nearestPrompt: prompt,
          });
          cameraRef.current = cam;
        }
      }

      rafId = requestAnimationFrame(frame);
    };

    rafId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafId);
  }, [screen, atlas, computeNearestPrompt]);

  // Update mouse logical 640x360 coordinates accurately at any responsive scale
  const updateMouseFromEvent = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { lx: 320, ly: 180 };
    const rect = canvas.getBoundingClientRect();
    const lx = Math.max(0, Math.min(LOGICAL_WIDTH, ((e.clientX - rect.left) / Math.max(1, rect.width)) * LOGICAL_WIDTH));
    const ly = Math.max(0, Math.min(LOGICAL_HEIGHT, ((e.clientY - rect.top) / Math.max(1, rect.height)) * LOGICAL_HEIGHT));
    mouseLogicalRef.current = { x: lx, y: ly };
    return { lx, ly };
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (modal !== 'none') return;
    const cur = stateRef.current;
    if (!cur || !cur.run.active) return;

    const { lx, ly } = updateMouseFromEvent(e);
    const worldX = (cameraRef.current.camX + lx) / TILE_PX;
    const worldY = (cameraRef.current.camY + ly) / TILE_PX;

    // Right-click cancels uncommitted Core/attack windup or exits Build preview!
    if (e.button === 2) {
      e.preventDefault();
      if (buildPreviewKind) {
        setBuildPreviewKind(null);
      } else if (cur.actors.player.activeWindup && !cur.actors.player.activeWindup.committed) {
        submitIntent({ type: 'CANCEL_WINDUP', reason: 'right_click_cancel' });
      }
      return;
    }

    if (e.button !== 0) return;

    // Build Mode Placement Click
    if (buildPreviewKind) {
      const tx = Math.floor(worldX);
      const ty = Math.floor(worldY);
      const check = canBuildAtTile(cur, buildPreviewKind, tx, ty);
      if (!check.ok) {
        showToast(check.reason ?? 'Cannot build here', true);
        return;
      }
      soundEngine.playBuild();
      submitIntent({
        type: 'BUILD_STRUCTURE',
        structureKind: buildPreviewKind,
        tileX: tx,
        tileY: ty,
        requestId: `bld_${tx}_${ty}_${Date.now()}`,
      });
      // If deploying single kit (escrow_chest or handcart), exit preview after placement
      if (buildPreviewKind === 'escrow_chest' || buildPreviewKind === 'handcart') {
        setBuildPreviewKind(null);
      }
      return;
    }

    // Standard 360-degree Aimed Primary Action (Attack / Harvest / Cast Charged Core)
    const aimRad = Math.atan2(worldY - cur.actors.player.y, worldX - cur.actors.player.x);
    soundEngine.playSwing();
    submitIntent({
      type: 'PRIMARY_ACTION',
      aimRad,
      targetWorldX: worldX,
      targetWorldY: worldY,
      nowMs: Date.now(),
    });
  };

  // Current biome & HUD stats
  const hudInfo = useMemo(() => {
    if (!uiState) return null;
    const map = getStaticIslandMap(uiState.world.seed);
    const p = uiState.actors.player;
    const tx = Math.max(0, Math.min(map.width - 1, Math.floor(p.x)));
    const ty = Math.max(0, Math.min(map.height - 1, Math.floor(p.y)));
    const biome = map.biomes[ty * map.width + tx];
    const carryKg = computePlayerCarryWeightKg(uiState);
    const cartEnt = p.hitchedCartEntityId ? uiState.entities[p.hitchedCartEntityId] : null;
    const cartKg = cartEnt?.containerId ? computeContainerWeightKg(uiState, cartEnt.containerId) : 0;
    const maxKg =
      balance.survival.baseCarryCapacityKg + (cartEnt ? balance.movementAndFreight.cartExtraCapacityKg : 0);
    const elapsedH = getElapsedRunHours(uiState);
    const remH = Math.max(0, balance.clock.maxRunRealHours - elapsedH);
    const sheltered = isPlayerInLawfulShelter(uiState);
    const heldCash = countItemInContainer(uiState, 'player_inv', 'ragnarok_cash');
    return { biome, carryKg, cartKg, maxKg, elapsedH, remH, sheltered, heldCash, hasCart: !!cartEnt };
  }, [uiState]);

  if (!bootDone || !atlas) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-[#0b0e14] text-[#ffd166] text-xs font-bold tracking-widest">
        LOADING SOUL OF HERO PIXEL ATLAS...
      </div>
    );
  }

  if (screen === 'title' || !uiState) {
    return (
      <TitleScreen
        atlas={atlas}
        profile={profile}
        savedActiveRun={savedRun}
        onResumeRun={handleResumeRun}
        onStartNewRun={handleStartNewRun}
      />
    );
  }

  const p = uiState.actors.player;
  const inv = uiState.custody.containers['player_inv'];

  return (
    <div className="w-full h-full flex items-center justify-center bg-[#07090d] overflow-hidden">
      {/* Responsive Crisp 16:9 Widescreen Frame around Logical 640x360 Pixel World */}
      <div
        className="relative aspect-video w-full max-h-full max-w-[177.78vh] bg-[#10151e] overflow-hidden shadow-2xl"
        onContextMenu={(e) => e.preventDefault()}
      >
        <canvas
          ref={canvasRef}
          data-testid="game-world-canvas"
          width={LOGICAL_WIDTH}
          height={LOGICAL_HEIGHT}
          onMouseMove={updateMouseFromEvent}
          onMouseDown={handleCanvasMouseDown}
          className="pixelated w-full h-full block cursor-crosshair"
        />

        {/* === COMPACT TOP-LEFT SURVIVAL & FREIGHT HUD === */}
        {hudInfo && uiState.run.active && (
          <div className="absolute top-1.5 left-1.5 pointer-events-none flex flex-col gap-1 max-w-[235px]">
            <div className="pixel-panel px-2 py-1 space-y-1">
              {/* HP & Stamina */}
              <div className="grid grid-cols-2 gap-2 text-[9px]">
                <div>
                  <div className="flex justify-between gap-1 text-[#ffadad] font-bold">
                    <span>HP</span>
                    <span>{Math.ceil(p.hp)}/{p.maxHp}</span>
                  </div>
                  <div className="h-1.5 bg-[#1b1f2a] border border-black">
                    <div
                      className="h-full bg-[#e63946]"
                      style={{ width: `${Math.max(0, Math.min(100, (p.hp / p.maxHp) * 100))}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-[#90e0ef] font-bold">
                    <span>STM</span>
                    <span>{Math.round(p.stamina)}</span>
                  </div>
                  <div className="h-1.5 bg-[#1b1f2a] border border-black">
                    <div
                      className="h-full bg-[#4cc9f0]"
                      style={{ width: `${Math.max(0, Math.min(100, (p.stamina / p.maxStamina) * 100))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Hunger & Warmth */}
              <div className="grid grid-cols-2 gap-1.5 text-[9px]">
                <div>
                  <div className="flex justify-between text-[#ffd166]">
                    <span>FOOD</span>
                    <span>{Math.round(p.hunger)}%</span>
                  </div>
                  <div className="h-1 bg-[#1b1f2a]">
                    <div
                      className="h-full bg-[#f4a261]"
                      style={{ width: `${Math.max(0, Math.min(100, p.hunger))}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-[#caf0f8]">
                    <span>WARM</span>
                    <span>{Math.round(p.warmth)}%</span>
                  </div>
                  <div className="h-1 bg-[#1b1f2a]">
                    <div
                      className="h-full bg-[#ffd166]"
                      style={{ width: `${Math.max(0, Math.min(100, p.warmth))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Physical Cargo & Status Badges */}
              <div className="flex flex-wrap items-center gap-1 text-[8px] pt-0.5 border-t border-[#2d3748]">
                <span className={hudInfo.carryKg + hudInfo.cartKg > hudInfo.maxKg ? 'text-[#ff5964] font-bold' : 'text-[#cbd5e1]'}>
                  {(hudInfo.carryKg + hudInfo.cartKg).toFixed(1)}/{hudInfo.maxKg}kg
                </span>
                {hudInfo.hasCart && (
                  <span className="px-1 bg-[#7f5539] text-[#fff3b0]">CART</span>
                )}
                {hudInfo.sheltered && (
                  <span className="px-1 bg-[#1b4332] text-[#80ed99]">SHELTER</span>
                )}
                {hudInfo.biome === 'tundra' && (
                  <span className="px-1 bg-[#1d3557] text-[#90e0ef]">COLD</span>
                )}
                {hudInfo.biome === 'caldera' && (
                  <span className="px-1 bg-[#78290f] text-[#ffd166]">HEAT</span>
                )}
                {hudInfo.biome === 'industrial' && (
                  <span className="px-1 bg-[#3c096c] text-[#80ed99]">TOXIC</span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* === COMPACT TOP-RIGHT RUN CLOCK, WEATHER, BIOME & CASH HUD === */}
        {hudInfo && uiState.run.active && (
          <div className="absolute top-1.5 right-1.5 pointer-events-none flex flex-col items-end gap-1">
            <div className="pixel-panel px-2 py-1 text-[9px] text-right space-y-0.5">
              <div className="flex items-center justify-end gap-1.5">
                <span
                  className={`px-1 font-bold ${
                    uiState.clock.phase === 'ELDER_AWAKENED_D14'
                      ? 'bg-[#9b2226] text-[#fff3b0]'
                      : uiState.clock.phase === 'RAGNAROK_72H'
                      ? 'bg-[#ca6702] text-white'
                      : 'bg-[#1d3557] text-[#90e0ef]'
                  }`}
                >
                  {uiState.clock.phase === 'ELDER_AWAKENED_D14'
                    ? 'DAY 14 ELDERS AWAKENED'
                    : uiState.clock.phase === 'RAGNAROK_72H'
                    ? 'FINAL 72H RAGNAROK'
                    : 'EXPEDITION'}
                </span>
                <span className="font-bold text-[#f1faee]">{hudInfo.remH.toFixed(1)}h left</span>
              </div>
              <div className="text-[#adb5bd] uppercase">
                {hudInfo.biome.replace('_', ' ')} · {uiState.clock.weather}
                {uiState.clock.isQaAccelerated ? ' · [QA]' : ''}
              </div>
              <div className="flex items-center justify-end gap-2 text-[9px]">
                <span className="text-[#ffd166]">Bag Cash: <strong>{hudInfo.heldCash}</strong></span>
                <span className="text-[#80ed99]">Secured: <strong>{uiState.profile.securedCash}</strong></span>
              </div>
            </div>
          </div>
        )}

        {/* === TOP-CENTER RECEIPT / FEEDBACK TOAST & BUILD BANNER === */}
        <div className="absolute top-1.5 left-1/2 -translate-x-1/2 pointer-events-none flex flex-col items-center gap-1 z-20">
          {buildPreviewKind && (
            <div className="pointer-events-auto pixel-panel-gold px-2.5 py-0.5 text-[10px] flex items-center gap-2">
              <span>
                Placing: <strong className="text-[#ffd166]">{STRUCTURES_CATALOG[buildPreviewKind]?.name}</strong> (Click tile · Right-Click exit)
              </span>
              <button
                type="button"
                onClick={() => setBuildPreviewKind(null)}
                className="pixel-btn px-1.5 text-[9px] cursor-pointer"
              >
                Cancel
              </button>
            </div>
          )}
          {toast && (
            <div
              key={toast.id}
              className={`px-2.5 py-0.5 border text-[10px] shadow ${
                toast.isError
                  ? 'bg-[#3b1219]/95 border-[#ff5964] text-[#ffccd5]'
                  : 'bg-[#122229]/95 border-[#80ed99] text-[#d8f3dc]'
              }`}
            >
              {toast.text}
            </div>
          )}
        </div>

        {/* === BOTTOM QUICKBAR (1-8) + COMPACT ACTION BUTTONS === */}
        {uiState.run.active && !p.dead && (
          <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10 max-w-[98%]">
            {/* 8 Quickbar Slots */}
            <div className="pixel-panel p-1 flex items-center gap-1">
              {uiState.custody.playerQuickbar.map((invIdx, qIdx) => {
                const instId = inv.slots[invIdx];
                const inst = instId ? uiState.custody.items[instId] : null;
                const def = inst ? ITEMS_CATALOG[inst.defId] : null;
                const active = uiState.custody.activeQuickSlot === qIdx;
                return (
                  <button
                    key={qIdx}
                    type="button"
                    data-testid={`quickbar-slot-${qIdx}`}
                    onClick={() => {
                      soundEngine.playUiClick();
                      submitIntent({ type: 'SELECT_QUICKSLOT', slotIndex: qIdx });
                    }}
                    title={def ? `${def.name} (Key ${qIdx + 1})` : `Empty Slot ${qIdx + 1}`}
                    className={`relative w-7 h-7 sm:w-8 sm:h-8 border flex items-center justify-center cursor-pointer ${
                      active ? 'bg-[#2a3d5c] border-[#ffd166]' : 'bg-[#121824] border-[#343e52]'
                    }`}
                  >
                    <span className="absolute top-0 left-0.5 text-[7px] text-[#90e0ef]">{qIdx + 1}</span>
                    {inst && def && atlas.itemIcons[def.iconKey] && (
                      <>
                        <img
                          src={atlas.itemIcons[def.iconKey]}
                          alt=""
                          className="pixelated w-4 h-4 sm:w-5 sm:h-5 object-contain"
                        />
                        {inst.qty > 1 && (
                          <span className="absolute bottom-0 right-0.5 text-[8px] font-bold text-white">
                            {inst.qty}
                          </span>
                        )}
                        {inst.charges !== undefined && (
                          <span className="absolute bottom-0 left-0.5 text-[7px] font-bold text-[#ffd166]">
                            ⚡{inst.charges}
                          </span>
                        )}
                      </>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Compact Panel Buttons */}
            <div className="pixel-panel p-1 flex items-center gap-1 text-[9px] sm:text-[10px]">
              {(
                [
                  ['inventory', 'I Bag'],
                  ['craft', 'C Craft'],
                  ['build', 'B Build'],
                  ['research', 'R Study'],
                  ['map', 'M Map'],
                  ['skills', 'Tab'],
                  ['pause', 'Esc'],
                ] as const
              ).map(([mKey, label]) => (
                <button
                  key={mKey}
                  type="button"
                  data-testid={`hud-btn-${mKey}`}
                  onClick={() => {
                    soundEngine.playUiClick();
                    setBuildPreviewKind(null);
                    setModal((cur) => (cur === mKey ? 'none' : mKey));
                  }}
                  className={`px-1.5 py-1 border cursor-pointer font-bold ${
                    modal === mKey
                      ? 'bg-[#2b3d59] border-[#ffd166] text-[#fff3b0]'
                      : 'bg-[#161e2c] border-[#3d4659] text-[#cbd5e1] hover:border-[#90e0ef]'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* === MODAL OVERLAY CONTAINER === */}
        {modal !== 'none' && uiState.run.active && (
          <div className="absolute inset-0 z-30 bg-black/45 flex items-center justify-center p-2">
            {modal === 'map' ? (
              <IslandMapModal state={uiState} onClose={() => setModal('none')} />
            ) : (
              <GameModals
                modal={modal}
                state={uiState}
                atlas={atlas}
                onDispatch={submitIntent}
                onSelectBuildStructure={(kind) => {
                  setBuildPreviewKind(kind);
                  setModal('none');
                }}
                onClose={() => setModal('none')}
                onForceSave={() => {
                  if (stateRef.current) {
                    void saveAtomicSnapshot(stateRef.current);
                    showToast('Snapshot saved atomically to IndexedDB');
                  }
                }}
                onReturnToTitle={() => {
                  setModal('none');
                  setScreen('title');
                }}
              />
            )}
          </div>
        )}

        {/* === SAME-RUN DEATH & CORPSE-BAG RECOVERY OVERLAY (C10) === */}
        {uiState.run.active && p.dead && (
          <div className="absolute inset-0 z-40 bg-black/65 flex items-center justify-center p-3">
            <div className="pixel-panel-gold max-w-[400px] w-full p-3 space-y-2 text-center">
              <div className="text-sm font-black text-[#ff5964]">ADVENTURER FALLEN — RUN CONTINUES</div>
              <p className="text-[10px] text-[#cbd5e1]">
                Death does NOT end your 336-hour run. Your carried items were placed once into a physical{' '}
                <strong className="text-[#ffd166]">Death Bag</strong> at ({Math.floor(p.x)}, {Math.floor(p.y)}). Trek back to recover them!
              </p>
              <div className="flex flex-wrap justify-center gap-2 pt-1">
                {p.boundBedEntityId && uiState.entities[p.boundBedEntityId]?.hp > 0 && (
                  <button
                    type="button"
                    data-testid="respawn-bed-btn"
                    onClick={() =>
                      submitIntent({
                        type: 'RESPAWN_AFTER_DEATH',
                        useBed: true,
                        requestId: `rsp_bed_${Date.now()}`,
                      })
                    }
                    className="pixel-btn px-3 py-1.5 text-xs font-bold text-[#80ed99] cursor-pointer"
                  >
                    Respawn at Homestead Bed
                  </button>
                )}
                <button
                  type="button"
                  data-testid="respawn-coast-btn"
                  onClick={() =>
                    submitIntent({
                      type: 'RESPAWN_AFTER_DEATH',
                      useBed: false,
                      requestId: `rsp_sp_${Date.now()}`,
                    })
                  }
                  className="pixel-btn px-3 py-1.5 text-xs font-bold text-[#ffd166] cursor-pointer"
                >
                  Respawn at Landing Region
                </button>
              </div>
            </div>
          </div>
        )}

        {/* === RUN FINALIZED SUMMARY OVERLAY (EVACUATION / SIX STONES / ABANDON / 336H EXPIRY — C22, C23) === */}
        {!uiState.run.active && (
          <div className="absolute inset-0 z-40 bg-black/75 flex items-center justify-center p-3">
            <div className="pixel-panel-gold max-w-[460px] w-full p-3 space-y-2 text-[11px]">
              <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
                <span className="text-sm font-black text-[#ffd166]">
                  RUN #{uiState.run.runNumber} FINALIZED: {uiState.run.endReason}
                </span>
                <span className="px-1.5 py-0.5 bg-[#2b2d42] border border-[#ff595e] text-[#ffadad] text-[9px] font-bold">
                  LOCAL / UNVERIFIED
                </span>
              </div>

              {uiState.profile.runHistory[0] && (
                <div className="bg-[#121926] border border-[#2f3b52] p-2 space-y-1 text-[10px]">
                  <div>
                    Ragnarok Cash Escrowed This Run:{' '}
                    <strong className="text-[#80ed99]">+{uiState.profile.runHistory[0].cashDepositedThisRun}</strong>
                  </div>
                  <div>
                    Unbanked Physical Cash Wiped on End:{' '}
                    <strong className="text-[#ffadad]">{uiState.profile.runHistory[0].unbankedCashLostOnEnd}</strong>
                  </div>
                  <div>
                    Cross-Run Profile Secured Wallet:{' '}
                    <strong className="text-[#ffd166]">{uiState.profile.securedCash} Cash</strong>
                  </div>
                  <div>
                    Elders Defeated: <strong>{uiState.profile.runHistory[0].eldersDefeated.length}/6</strong> · Stones Held at End:{' '}
                    <strong>{uiState.profile.runHistory[0].stonesCollected}/6</strong>
                  </div>
                  <div>
                    Run Accomplishment Score: <strong>{uiState.profile.runHistory[0].totalScore}</strong> (Never mints currency)
                  </div>
                </div>
              )}

              <p className="text-[9px] text-[#adb5bd]">
                All run-local inventory, buildings, recipes, Cores, and Elder Stones have been wiped per canon. Only Secured Ragnarok Cash, Achievements, and Run History carry forward.
              </p>

              <button
                type="button"
                data-testid="next-season-title-btn"
                onClick={() => {
                  setModal('none');
                  setScreen('title');
                }}
                className="w-full py-1.5 bg-[#1b4332] hover:bg-[#2d6a4f] border-2 border-[#ffd166] text-[#fff3b0] font-black cursor-pointer"
              >
                Return to Title &amp; Start Next Run ▶
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
