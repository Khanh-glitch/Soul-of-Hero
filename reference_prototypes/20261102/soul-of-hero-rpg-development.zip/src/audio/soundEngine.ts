import { SurfaceType } from '../engine/types';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;
  private volume: number = 0.45;
  private lastFootstepMs: number = 0;

  constructor() {
    try {
      const m = localStorage.getItem('soh_audio_muted');
      const v = localStorage.getItem('soh_audio_vol');
      if (m === '1') this.muted = true;
      if (v) this.volume = Math.max(0, Math.min(1, parseFloat(v)));
    } catch {
      // ignore
    }
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || this.volume <= 0.01) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (Ctor) this.ctx = new Ctor();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setMuted(m: boolean): void {
    this.muted = m;
    try {
      localStorage.setItem('soh_audio_muted', m ? '1' : '0');
    } catch {
      // ignore
    }
  }

  public setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
    try {
      localStorage.setItem('soh_audio_vol', String(this.volume));
    } catch {
      // ignore
    }
  }

  private playTone(
    freqStart: number,
    freqEnd: number,
    durationSec: number,
    type: OscillatorType = 'triangle',
    gainScale: number = 0.25
  ): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), now + durationSec);

    gain.gain.setValueAtTime(this.volume * gainScale, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + durationSec);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + durationSec + 0.01);
  }

  private playNoise(durationSec: number, filterFreq: number, gainScale: number = 0.2): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const sampleCount = Math.max(128, Math.floor(ctx.sampleRate * durationSec));
    const buf = ctx.createBuffer(1, sampleCount, ctx.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < sampleCount; i++) {
      ch[i] = (Math.random() * 2 - 1) * (1 - i / sampleCount);
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(filterFreq, now);
    filter.Q.setValueAtTime(1.4, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(this.volume * gainScale, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + durationSec);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(now);
  }

  public playFootstep(surface: SurfaceType, nowMs: number): void {
    if (nowMs - this.lastFootstepMs < 250) return;
    this.lastFootstepMs = nowMs;
    if (surface === 'road' || surface === 'bridge' || surface === 'stone_floor' || surface === 'wood_floor') {
      this.playNoise(0.045, 1100, 0.09);
    } else if (surface === 'mud' || surface === 'shallow') {
      this.playTone(150, 75, 0.07, 'sine', 0.11);
    } else if (surface === 'snow') {
      this.playNoise(0.06, 2200, 0.08);
    } else {
      this.playNoise(0.05, 750, 0.07);
    }
  }

  public playSwing(): void {
    this.playNoise(0.09, 950, 0.16);
    this.playTone(260, 120, 0.09, 'triangle', 0.12);
  }

  public playHarvestWood(): void {
    this.playTone(170, 72, 0.11, 'square', 0.22);
    this.playNoise(0.07, 600, 0.15);
  }

  public playHarvestStone(): void {
    this.playTone(980, 460, 0.09, 'triangle', 0.22);
    this.playNoise(0.06, 2400, 0.14);
  }

  public playMonsterHit(): void {
    this.playTone(230, 80, 0.12, 'sawtooth', 0.24);
    this.playNoise(0.08, 850, 0.16);
  }

  public playPlayerHurt(): void {
    this.playTone(155, 52, 0.2, 'sawtooth', 0.3);
  }

  public playCoreCast(skill?: string): void {
    if (skill === 'frost_nova') {
      this.playTone(720, 1280, 0.22, 'sine', 0.25);
      this.playNoise(0.18, 2800, 0.16);
    } else if (skill === 'volt_lance') {
      this.playTone(960, 220, 0.18, 'sawtooth', 0.25);
    } else {
      this.playTone(320, 110, 0.24, 'sawtooth', 0.26);
      this.playNoise(0.22, 680, 0.2);
    }
  }

  public playPickup(): void {
    this.playTone(520, 780, 0.09, 'triangle', 0.18);
  }

  public playBuild(): void {
    this.playTone(190, 115, 0.12, 'square', 0.22);
    this.playTone(290, 340, 0.08, 'triangle', 0.14);
  }

  public playDepositCash(): void {
    this.playTone(587, 880, 0.14, 'triangle', 0.24);
    setTimeout(() => this.playTone(880, 1175, 0.18, 'triangle', 0.24), 95);
  }

  public playUiClick(): void {
    this.playTone(440, 520, 0.045, 'triangle', 0.11);
  }
}

export const soundEngine = new SoundEngine();
