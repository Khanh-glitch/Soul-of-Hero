import { STRUCTURES_CATALOG } from '../data/structuresCatalog';
import { GameState, StructureEntity } from './types';
import { getStaticIslandMap, StaticIslandMap } from './worldGen';

export interface PathStepResult {
  reachable: boolean;
  nextX: number;
  nextY: number;
  blockingStructure?: StructureEntity;
}

export function isTileBlockedForActor(
  map: StaticIslandMap,
  state: GameState,
  tx: number,
  ty: number,
  options?: { isCart?: boolean; allowClosedPlayerStructuresAsSoftCost?: boolean }
): { blocked: boolean; structure?: StructureEntity; cost: number } {
  if (tx < 1 || ty < 1 || tx >= map.width - 1 || ty >= map.height - 1) {
    return { blocked: true, cost: Infinity };
  }
  const i = ty * map.width + tx;
  if (options?.isCart) {
    if (!map.cartPassable[i]) return { blocked: true, cost: Infinity };
  } else {
    if (!map.walkable[i]) return { blocked: true, cost: Infinity };
  }

  // Check active solid source nodes (trees, boulders, crates with stock > 0)
  for (const s of Object.values(state.sources)) {
    if (s.stock <= 0) continue;
    if (Math.floor(s.x) === tx && Math.floor(s.y) === ty) {
      if (
        s.kind === 'pine_tree' ||
        s.kind === 'oak_tree' ||
        s.kind === 'boulder' ||
        s.kind === 'iron_vein' ||
        s.kind === 'coal_seam' ||
        s.kind === 'cobalt_crystal' ||
        s.kind === 'final72_cash_vault'
      ) {
        return { blocked: true, cost: Infinity };
      }
    }
  }

  // Check placed / world structures
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0) continue;
    if (ent.kind === 'world_drop' || ent.kind === 'death_bag' || ent.kind === 'handcart') continue;
    if (ent.tileX === tx && ent.tileY === ty) {
      if (ent.kind === 'poi_gate') {
        if (!ent.open) return { blocked: true, structure: ent, cost: Infinity };
        continue;
      }
      if (
        ent.kind === 'poi_power_box' ||
        ent.kind === 'vendor_escrow_broker' ||
        ent.kind === 'vendor_season_shop' ||
        ent.kind === 'evac_beacon'
      ) {
        return { blocked: true, structure: ent, cost: Infinity };
      }
      const def = STRUCTURES_CATALOG[ent.kind];
      if (!def) continue;
      if (def.isDoor && ent.open) continue;
      if (def.blocksMovement) {
        if (options?.allowClosedPlayerStructuresAsSoftCost && ent.owner === 'player') {
          return { blocked: false, structure: ent, cost: 14 };
        }
        return { blocked: true, structure: ent, cost: Infinity };
      }
    }
  }

  const surf = map.surfaces[i];
  const baseCost = surf === 'road' || surf === 'bridge' ? 0.85 : surf === 'mud' ? 1.65 : 1.0;
  return { blocked: false, cost: baseCost };
}

export function findNextPathStep(
  state: GameState,
  fromX: number,
  fromY: number,
  goalX: number,
  goalY: number,
  maxExpanded: number = 140
): PathStepResult {
  const map = getStaticIslandMap(state.world.seed);
  const sx = Math.floor(fromX);
  const sy = Math.floor(fromY);
  const gx = Math.floor(goalX);
  const gy = Math.floor(goalY);

  if (sx === gx && sy === gy) {
    return { reachable: true, nextX: goalX, nextY: goalY };
  }

  // Build quick tile lookup for active blocking sources & entities within bounding window
  const minX = Math.max(1, Math.min(sx, gx) - 10);
  const maxX = Math.min(map.width - 2, Math.max(sx, gx) + 10);
  const minY = Math.max(1, Math.min(sy, gy) - 10);
  const maxY = Math.min(map.height - 2, Math.max(sy, gy) + 10);

  const solidSourceSet = new Set<number>();
  for (const s of Object.values(state.sources)) {
    if (s.stock <= 0) continue;
    const tx = Math.floor(s.x);
    const ty = Math.floor(s.y);
    if (tx < minX || tx > maxX || ty < minY || ty > maxY) continue;
    if (
      s.kind === 'pine_tree' ||
      s.kind === 'oak_tree' ||
      s.kind === 'boulder' ||
      s.kind === 'iron_vein' ||
      s.kind === 'coal_seam' ||
      s.kind === 'cobalt_crystal'
    ) {
      solidSourceSet.add(ty * map.width + tx);
    }
  }

  const structMap = new Map<number, StructureEntity>();
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0) continue;
    if (ent.tileX < minX || ent.tileX > maxX || ent.tileY < minY || ent.tileY > maxY) continue;
    if (ent.kind === 'world_drop' || ent.kind === 'death_bag' || ent.kind === 'handcart') continue;
    if (ent.kind === 'poi_gate') {
      if (!ent.open) structMap.set(ent.tileY * map.width + ent.tileX, ent);
      continue;
    }
    const def = STRUCTURES_CATALOG[ent.kind];
    if (def && !(def.isDoor && ent.open) && def.blocksMovement) {
      structMap.set(ent.tileY * map.width + ent.tileX, ent);
    }
  }

  const startKey = sy * map.width + sx;
  const goalKey = gy * map.width + gx;

  const gScore = new Map<number, number>();
  const cameFrom = new Map<number, number>();
  const openKeys: number[] = [startKey];
  const openF = new Map<number, number>();
  const closed = new Set<number>();

  gScore.set(startKey, 0);
  openF.set(startKey, Math.hypot(gx - sx, gy - sy));

  const dirs = [
    [1, 0, 1],
    [-1, 0, 1],
    [0, 1, 1],
    [0, -1, 1],
    [1, 1, 1.414],
    [-1, 1, 1.414],
    [1, -1, 1.414],
    [-1, -1, 1.414],
  ];

  let bestKey = startKey;
  let bestH = Math.hypot(gx - sx, gy - sy);
  let expanded = 0;

  while (openKeys.length > 0 && expanded < maxExpanded) {
    let bestIdx = 0;
    let lowestF = Infinity;
    for (let i = 0; i < openKeys.length; i++) {
      const f = openF.get(openKeys[i]) ?? Infinity;
      if (f < lowestF) {
        lowestF = f;
        bestIdx = i;
      }
    }
    const current = openKeys[bestIdx];
    openKeys.splice(bestIdx, 1);

    if (current === goalKey) {
      bestKey = goalKey;
      break;
    }

    closed.add(current);
    expanded++;

    const cx = current % map.width;
    const cy = Math.floor(current / map.width);
    const curG = gScore.get(current) ?? 0;

    for (const [dx, dy, stepLen] of dirs) {
      const nx = cx + dx;
      const ny = cy + dy;
      if (nx < minX || nx > maxX || ny < minY || ny > maxY) continue;
      const nKey = ny * map.width + nx;
      if (closed.has(nKey)) continue;
      if (!map.walkable[nKey]) continue;
      if (solidSourceSet.has(nKey) && nKey !== goalKey) continue;

      // Prevent diagonal corner-cutting through walls
      if (dx !== 0 && dy !== 0) {
        const k1 = cy * map.width + nx;
        const k2 = ny * map.width + cx;
        if (!map.walkable[k1] || !map.walkable[k2]) continue;
        if (structMap.has(k1) || structMap.has(k2)) continue;
      }

      const st = structMap.get(nKey);
      let tilePenalty = 1.0;
      if (st) {
        if (st.owner === 'world') continue; // Cannot break permanent POI gate
        tilePenalty = 12.0; // Player wall/door blocks path; monster will walk up and batter it if no easy detour
      }

      const tentativeG = curG + stepLen * tilePenalty;
      if (tentativeG < (gScore.get(nKey) ?? Infinity)) {
        cameFrom.set(nKey, current);
        gScore.set(nKey, tentativeG);
        const h = Math.hypot(gx - nx, gy - ny);
        openF.set(nKey, tentativeG + h);
        if (!openKeys.includes(nKey)) openKeys.push(nKey);
        if (h < bestH) {
          bestH = h;
          bestKey = nKey;
        }
      }
    }
  }

  if (bestKey === startKey) {
    return { reachable: false, nextX: fromX, nextY: fromY };
  }

  let stepKey = bestKey;
  while (cameFrom.has(stepKey) && cameFrom.get(stepKey) !== startKey) {
    stepKey = cameFrom.get(stepKey)!;
  }

  const stepTx = stepKey % map.width;
  const stepTy = Math.floor(stepKey / map.width);
  const blocker = structMap.get(stepKey);

  return {
    reachable: bestKey === goalKey,
    nextX: stepTx + 0.5,
    nextY: stepTy + 0.5,
    blockingStructure: blocker && blocker.owner === 'player' ? blocker : undefined,
  };
}
