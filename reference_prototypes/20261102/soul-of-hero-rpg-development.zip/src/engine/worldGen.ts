import { createNoise2D } from 'simplex-noise';
import balance from '../data/balance.v1.json';
import {
  BiomeId,
  CreatureArchetype,
  ElderId,
  MonsterActor,
  PoiSiteMeta,
  SourceKind,
  SourceNode,
  SpawnRegionMeta,
  StructureEntity,
  SurfaceType,
} from './types';
import { createSeededFunction, nextFloat, nextId, nextInt, RngCursor } from './rng';

export const ISLAND_GEOGRAPHY_SEED = 20261101;
export const WORLD_WIDTH = 200;
export const WORLD_HEIGHT = 200;

export interface StaticIslandMap {
  seed: number;
  width: number;
  height: number;
  biomes: BiomeId[];
  surfaces: SurfaceType[];
  elevation: Uint8Array; // 0 = water, 1 = lowland, 2 = highland, 3 = impassable cliff/poi masonry
  walkable: Uint8Array;
  cartPassable: Uint8Array;
  buildable: Uint8Array;
  flammable: Uint8Array;
  pois: PoiSiteMeta[];
  spawnRegions: SpawnRegionMeta[];
  elderSites: { elderId: ElderId; name: string; x: number; y: number; biome: BiomeId }[];
}

const cachedMaps = new Map<number, StaticIslandMap>();

function idx(x: number, y: number): number {
  return y * WORLD_WIDTH + x;
}

function dist(x1: number, y1: number, x2: number, y2: number): number {
  return Math.hypot(x2 - x1, y2 - y1);
}

function carvePolyline(
  points: [number, number][],
  halfWidth: number,
  cb: (tx: number, ty: number, d: number) => void
) {
  for (let i = 0; i < points.length - 1; i++) {
    const [x0, y0] = points[i];
    const [x1, y1] = points[i + 1];
    const steps = Math.ceil(dist(x0, y0, x1, y1) * 2);
    for (let s = 0; s <= steps; s++) {
      const t = steps === 0 ? 0 : s / steps;
      const cx = x0 + (x1 - x0) * t;
      const cy = y0 + (y1 - y0) * t;
      const r = Math.ceil(halfWidth + 1);
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          const tx = Math.round(cx + dx);
          const ty = Math.round(cy + dy);
          if (tx < 1 || ty < 1 || tx >= WORLD_WIDTH - 1 || ty >= WORLD_HEIGHT - 1) continue;
          const d = Math.hypot(tx - cx, ty - cy);
          if (d <= halfWidth) cb(tx, ty, d);
        }
      }
    }
  }
}

export function getStaticIslandMap(seed: number = ISLAND_GEOGRAPHY_SEED): StaticIslandMap {
  const existing = cachedMaps.get(seed);
  if (existing) return existing;

  const prng = createSeededFunction(seed);
  const elevNoise = createNoise2D(createSeededFunction(seed ^ 0x1a2b3c4d));
  const detailNoise = createNoise2D(createSeededFunction(seed ^ 0x55aa99cc));
  const moistNoise = createNoise2D(createSeededFunction(seed ^ 0x7f3e1b91));

  const size = WORLD_WIDTH * WORLD_HEIGHT;
  const biomes = new Array<BiomeId>(size).fill('ocean');
  const surfaces = new Array<SurfaceType>(size).fill('water');
  const elevation = new Uint8Array(size);
  const walkable = new Uint8Array(size);
  const cartPassable = new Uint8Array(size);
  const buildable = new Uint8Array(size);
  const flammable = new Uint8Array(size);

  // 1. Sculpt main island + Western Harbor Bay + Southern Inlet + Eastern Caldera Isthmus & Peninsula
  for (let y = 0; y < WORLD_HEIGHT; y++) {
    for (let x = 0; x < WORLD_WIDTH; x++) {
      const i = idx(x, y);
      const nx = (x - 94) / 76;
      const ny = (y - 98) / 76;
      const radial = Math.hypot(nx, ny);

      const n1 = elevNoise(x * 0.025, y * 0.025) * 0.24;
      const n2 = detailNoise(x * 0.065, y * 0.065) * 0.1;
      let h = 1.0 - radial * 0.96 + n1 + n2;

      // Carve Western Harbor Bay around (20, 105)
      const bayWest = dist(x, y, 17, 105);
      if (bayWest < 18) h -= ((18 - bayWest) / 18) * 0.55;

      // Carve Southern Tidal Inlet around (66, 182)
      const inletSouth = dist(x, y, 66, 184);
      if (inletSouth < 22) h -= ((22 - inletSouth) / 22) * 0.55;

      // Carve pinch around (147, 118) & (142, 146) to create Eastern Caldera Isthmus at (148, 132)
      const pinchNorth = dist(x, y, 152, 116);
      if (pinchNorth < 12) h -= ((12 - pinchNorth) / 12) * 0.52;
      const pinchSouth = dist(x, y, 139, 154);
      if (pinchSouth < 13) h -= ((13 - pinchSouth) / 13) * 0.52;

      // Boost Southeast Caldera Peninsula centered at (166, 152)
      const calderaDist = dist(x, y, 166, 152);
      if (calderaDist < 24) h = Math.max(h, 0.56 - (calderaDist / 24) * 0.35 + n2 * 0.5);
      // Reinforce Isthmus bridge land at (148, 132)
      const isthmusDist = dist(x, y, 148, 132);
      if (isthmusDist < 6.5) h = Math.max(h, 0.38);

      // Boost Northeast Storm Promontory at (164, 42)
      const neDist = dist(x, y, 163, 43);
      if (neDist < 19) h = Math.max(h, 0.52 - (neDist / 19) * 0.34 + n2 * 0.4);

      // Central Alpine Lake (Crystal Tarn) at (96, 84)
      const lakeDist = dist(x, y, 96, 84) + detailNoise(x * 0.12, y * 0.12) * 2.1;

      if (x <= 3 || y <= 3 || x >= WORLD_WIDTH - 4 || y >= WORLD_HEIGHT - 4 || h < 0.16) {
        biomes[i] = 'ocean';
        surfaces[i] = 'water';
        elevation[i] = 0;
      } else if (h < 0.22) {
        biomes[i] = 'shallow_water';
        surfaces[i] = 'shallow';
        elevation[i] = 0;
        walkable[i] = 1;
      } else if (lakeDist < 8.5) {
        biomes[i] = 'river';
        surfaces[i] = lakeDist > 6.8 ? 'shallow' : 'water';
        elevation[i] = 0;
        walkable[i] = lakeDist > 6.8 ? 1 : 0;
      } else if (h < 0.28) {
        biomes[i] = 'beach';
        surfaces[i] = 'sand';
        elevation[i] = 1;
        walkable[i] = 1;
        cartPassable[i] = 1;
        buildable[i] = 1;
      } else {
        // Assign distinct regional biomes with real gameplay identity
        const moisture = moistNoise(x * 0.03, y * 0.03);
        elevation[i] = h > 0.68 ? 2 : 1;
        walkable[i] = 1;
        cartPassable[i] = 1;
        buildable[i] = 1;

        if (calderaDist < 23 || (x > 148 && y > 128)) {
          biomes[i] = 'caldera';
          surfaces[i] = 'scorch';
          flammable[i] = detailNoise(x * 0.2, y * 0.2) > 0.1 ? 1 : 0;
        } else if (y < 52 + elevNoise(x * 0.04, 10) * 7 && x > 56 && x < 148) {
          biomes[i] = 'tundra';
          surfaces[i] = 'snow';
        } else if (dist(x, y, 155, 94) < 20 + moisture * 4) {
          biomes[i] = 'industrial';
          surfaces[i] = 'toxic_concrete';
        } else if (dist(x, y, 68, 150) < 21 + moisture * 4) {
          biomes[i] = 'marsh';
          surfaces[i] = 'mud';
          // Marsh allows foot & slow cart, floor foundations recommended
        } else if (x < 78 && y < 98) {
          biomes[i] = 'forest';
          surfaces[i] = 'forest_floor';
          flammable[i] = 1;
        } else if (y < 96 && x >= 106) {
          biomes[i] = 'highland';
          surfaces[i] = 'rock';
          if (h > 0.78 && detailNoise(x * 0.14, y * 0.14) > 0.42) {
            // Natural cliff ridges in highlands with passable gaps
            elevation[i] = 3;
            walkable[i] = 0;
            cartPassable[i] = 0;
            buildable[i] = 0;
          }
        } else if (x >= 96 && y >= 96) {
          biomes[i] = 'steppe';
          surfaces[i] = 'grass';
          flammable[i] = 1;
        } else {
          biomes[i] = 'meadow';
          surfaces[i] = 'grass';
          flammable[i] = 1;
        }
      }
    }
  }

  // 2. Carve Two Continuous Rivers from Central Lake (96,84) to the Sea
  const swRiver: [number, number][] = [
    [94, 89],
    [86, 104],
    [78, 120],
    [72, 142],
    [67, 168],
    [66, 182],
  ];
  const neRiver: [number, number][] = [
    [102, 82],
    [118, 74],
    [136, 67],
    [156, 61],
    [178, 57],
  ];

  const paintRiver = (pts: [number, number][]) => {
    carvePolyline(pts, 2.2, (tx, ty, d) => {
      const i = idx(tx, ty);
      if (biomes[i] === 'ocean') return;
      biomes[i] = 'river';
      if (d <= 1.25) {
        surfaces[i] = 'water';
        elevation[i] = 0;
        walkable[i] = 0;
        cartPassable[i] = 0;
        buildable[i] = 0;
      } else {
        surfaces[i] = 'shallow';
        elevation[i] = 0;
        walkable[i] = 1;
        cartPassable[i] = 0;
        buildable[i] = 0;
      }
    });
  };
  paintRiver(swRiver);
  paintRiver(neRiver);

  // 3. Carve Connected Ring Road + Spur Roads (Automatically lays Timber/Stone Bridges over Rivers!)
  const roadSegments: [number, number][][] = [
    // Main Island Ring Road
    [
      [48, 134], // SW Driftwood Meadow
      [44, 105], // Harbor Customs Depot
      [46, 70],  // WNW Timberwatch Glade
      [72, 52],  // North-West Pass
      [98, 46],  // North Tundra Approach
      [124, 72], // NE Granite Ford (crosses neRiver -> Bridge!)
      [138, 96], // Industrial Perimeter
      [118, 132], // SE Wayfarer's Mile
      [96, 112], // Crossroads Trading Outpost
      [81, 114], // Crosses swRiver -> Central Bridge!
      [62, 124],
      [48, 134],
    ],
    // Harbor Evacuation Pier Spur
    [
      [44, 105],
      [28, 105],
    ],
    // South Evacuation Lighthouse Pier Spur (crosses swRiver edge cleanly)
    [
      [96, 112],
      [99, 142],
      [102, 168],
    ],
    // Eastern Caldera Isthmus Freight Spur
    [
      [118, 132],
      [148, 132],
      [158, 144],
    ],
    // Northeast Promontory Trail
    [
      [124, 72],
      [148, 54],
      [160, 46],
    ],
    // Sunken Fen Causeway Spur
    [
      [62, 124],
      [68, 144],
    ],
  ];

  for (const seg of roadSegments) {
    carvePolyline(seg, 1.55, (tx, ty) => {
      const i = idx(tx, ty);
      const wasWater = surfaces[i] === 'water' || surfaces[i] === 'shallow';
      surfaces[i] = wasWater ? 'bridge' : 'road';
      if (biomes[i] === 'ocean') biomes[i] = 'beach';
      elevation[i] = 1;
      walkable[i] = 1;
      cartPassable[i] = 1;
      buildable[i] = 0; // Keep roads & bridges clear for freight & carts!
      flammable[i] = 0;
    });
  }

  // Ensure West & South Evacuation Jetties are solid walkable pier/sand pads
  for (const [px, py] of [
    [28, 105],
    [102, 168],
  ]) {
    for (let dy = -3; dy <= 3; dy++) {
      for (let dx = -3; dx <= 3; dx++) {
        const i = idx(px + dx, py + dy);
        surfaces[i] = Math.abs(dx) <= 1 && Math.abs(dy) <= 1 ? 'bridge' : 'sand';
        if (biomes[i] === 'ocean' || biomes[i] === 'shallow_water') biomes[i] = 'beach';
        elevation[i] = 1;
        walkable[i] = 1;
        cartPassable[i] = 1;
        buildable[i] = 0;
      }
    }
  }

  // 4. Define 4 Distinct Safe Viable Spawn Regions (MAP-SPAWN-04, C24)
  const spawnRegions: SpawnRegionMeta[] = [
    {
      id: 'spawn_meadow',
      name: 'Driftwood Meadow (SW Coast)',
      biome: 'meadow',
      x: 48,
      y: 138,
      summary: 'Temperate coastal grassland with berries, oak groves, and quick access to West Harbor.',
    },
    {
      id: 'spawn_pinewood',
      name: 'Timberwatch Glade (WNW Forest)',
      biome: 'forest',
      x: 46,
      y: 66,
      summary: 'Sheltered woodland rich in timber, amber resin, game trails, and quiet homestead clearings.',
    },
    {
      id: 'spawn_steppe',
      name: "Wayfarer's Mile (SE Crossroads)",
      biome: 'steppe',
      x: 116,
      y: 136,
      summary: 'Open highway plains lined with salvage crates, iron boulders, and fast cart routes.',
    },
    {
      id: 'spawn_foothills',
      name: 'Granite Ford (NE Foothills)',
      biome: 'highland',
      x: 122,
      y: 76,
      summary: 'River-bridge highlands offering rich stone, coal, iron seams, and northern frontier access.',
    },
  ];

  for (const sp of spawnRegions) {
    for (let dy = -5; dy <= 5; dy++) {
      for (let dx = -5; dx <= 5; dx++) {
        const i = idx(sp.x + dx, sp.y + dy);
        if (surfaces[i] === 'water' || surfaces[i] === 'shallow' || elevation[i] === 3) {
          biomes[i] = sp.biome;
          surfaces[i] = sp.biome === 'forest' ? 'forest_floor' : sp.biome === 'highland' ? 'rock' : 'grass';
          elevation[i] = 1;
        }
        walkable[i] = 1;
        cartPassable[i] = 1;
        if (surfaces[i] !== 'road' && surfaces[i] !== 'bridge') {
          buildable[i] = 1;
        }
      }
    }
  }

  // 5. Stamp Authored Multi-Layer Walled POI Compounds (Exterior Yard + Gated Vault Room, C11 & C15)
  const pois: PoiSiteMeta[] = [
    {
      id: 'poi_trading_outpost',
      name: 'Crossroads Quartermaster Outpost',
      kind: 'trading_outpost',
      x: 96,
      y: 112,
      radius: 7,
      hasDeepVault: false,
      hasFinal72Vault: false,
    },
    {
      id: 'poi_relay_bunker',
      name: 'Abandoned Relay Bunker',
      kind: 'relay_bunker',
      x: 74,
      y: 88,
      radius: 8,
      hasDeepVault: true,
      deepKeyHint: 'Power exterior junction with Heavy Industrial Fuse or Arc-Lance Core',
      hasFinal72Vault: true,
    },
    {
      id: 'poi_harbor_depot',
      name: 'Harbor Customs Depot',
      kind: 'harbor_depot',
      x: 42,
      y: 102,
      radius: 8,
      hasDeepVault: true,
      deepKeyHint: 'Unlock inner customs cage with Relay Security Passcard',
      hasFinal72Vault: true,
    },
    {
      id: 'poi_quarantine_lab',
      name: 'Quarantine Med-Lab',
      kind: 'quarantine_lab',
      x: 110,
      y: 152,
      radius: 8,
      hasDeepVault: true,
      deepKeyHint: 'Toxic inner ward — Unlock with Relay Security Passcard',
      hasFinal72Vault: true,
    },
    {
      id: 'poi_industrial_vault',
      name: 'Reactor Sub-Vault',
      kind: 'ragnarok_pavilion',
      x: 142,
      y: 94,
      radius: 8,
      hasDeepVault: true,
      deepKeyHint: 'Power exterior junction with Heavy Industrial Fuse or Arc-Lance Core',
      hasFinal72Vault: true,
    },
    {
      id: 'poi_evac_west',
      name: 'West Harbor Evacuation Pier',
      kind: 'evac_pier',
      x: 28,
      y: 105,
      radius: 5,
      hasDeepVault: false,
      hasFinal72Vault: false,
    },
    {
      id: 'poi_evac_south',
      name: 'South Lighthouse Evacuation Jetty',
      kind: 'evac_pier',
      x: 102,
      y: 168,
      radius: 5,
      hasDeepVault: false,
      hasFinal72Vault: false,
    },
  ];

  // Build physical masonry rooms for the 4 walled deep-vault POIs:
  // Inner room is 5x5 tiles [cx-2..cx+2, cy-4..cy] with masonry walls (elevation=3, walkable=0)
  // and ONE south doorway at (cx, cy) where the locked `poi_gate` entity stands!
  // Exterior courtyard is [cx-4..cx+4, cy+1..cy+4] completely walkable with exterior caches!
  for (const poi of pois) {
    if (poi.kind === 'evac_pier') continue;
    const cx = poi.x;
    const cy = poi.y;
    for (let dy = -5; dy <= 5; dy++) {
      for (let dx = -5; dx <= 5; dx++) {
        const tx = cx + dx;
        const ty = cy + dy;
        const i = idx(tx, ty);
        surfaces[i] = poi.kind === 'quarantine_lab' ? 'toxic_concrete' : 'stone_floor';
        elevation[i] = 1;
        walkable[i] = 1;
        cartPassable[i] = 1;
        buildable[i] = 0; // Cannot build player walls inside POI footprint
        flammable[i] = 0;
      }
    }

    if (poi.hasDeepVault) {
      for (let dy = -4; dy <= 0; dy++) {
        for (let dx = -2; dx <= 2; dx++) {
          const isBorder = dy === -4 || dy === 0 || dx === -2 || dx === 2;
          const isGateDoorway = dx === 0 && dy === 0;
          const i = idx(cx + dx, cy + dy);
          if (isBorder && !isGateDoorway) {
            elevation[i] = 3; // Permanent POI masonry wall!
            walkable[i] = 0;
            cartPassable[i] = 0;
          }
        }
      }
    }
  }

  // 6. Six Geographically Distinct Optional Elder Arenas (MAP-U5, C19)
  const elderSites: { elderId: ElderId; name: string; x: number; y: number; biome: BiomeId }[] = [
    { elderId: 'elder_verdant', name: 'Sylvan Canopy Sanctum', x: 36, y: 38, biome: 'forest' },
    { elderId: 'elder_mire', name: 'Sunken Hydra Temple', x: 68, y: 154, biome: 'marsh' },
    { elderId: 'elder_glacial', name: 'Frostbite Monolith Spire', x: 98, y: 30, biome: 'tundra' },
    { elderId: 'elder_caldera', name: 'Magma Wyrm Crater', x: 166, y: 154, biome: 'caldera' },
    { elderId: 'elder_ferric', name: 'Rust Sovereign Foundry', x: 160, y: 94, biome: 'industrial' },
    { elderId: 'elder_abyssal', name: 'Storm-Break Kraken Altar', x: 162, y: 43, biome: 'highland' },
  ];

  for (const es of elderSites) {
    for (let dy = -6; dy <= 6; dy++) {
      for (let dx = -6; dx <= 6; dx++) {
        if (Math.hypot(dx, dy) <= 6) {
          const i = idx(es.x + dx, es.y + dy);
          biomes[i] = es.biome;
          surfaces[i] =
            es.biome === 'tundra'
              ? 'snow'
              : es.biome === 'caldera'
              ? 'scorch'
              : es.biome === 'marsh'
              ? 'mud'
              : es.biome === 'industrial'
              ? 'toxic_concrete'
              : es.biome === 'highland'
              ? 'rock'
              : 'forest_floor';
          elevation[i] = 1;
          walkable[i] = 1;
          cartPassable[i] = 1;
          buildable[i] = 0;
        }
      }
    }
  }

  // Use prng once to keep TS strict linter happy if unused
  void prng();

  const map: StaticIslandMap = {
    seed,
    width: WORLD_WIDTH,
    height: WORLD_HEIGHT,
    biomes,
    surfaces,
    elevation,
    walkable,
    cartPassable,
    buildable,
    flammable,
    pois,
    spawnRegions,
    elderSites,
  };
  cachedMaps.set(seed, map);
  return map;
}

export function populateRunWorldEntities(
  map: StaticIslandMap,
  cursor: RngCursor
): {
  sources: Record<string, SourceNode>;
  entities: Record<string, StructureEntity>;
  monsters: Record<string, MonsterActor>;
} {
  const sources: Record<string, SourceNode> = {};
  const entities: Record<string, StructureEntity> = {};
  const monsters: Record<string, MonsterActor> = {};
  const occupiedTiles = new Set<string>();

  const markTile = (tx: number, ty: number) => occupiedTiles.add(`${tx},${ty}`);
  const isOccupied = (tx: number, ty: number) => occupiedTiles.has(`${tx},${ty}`);

  const addSource = (
    kind: SourceKind,
    tx: number,
    ty: number,
    opts?: Partial<SourceNode>
  ): SourceNode | null => {
    if (tx < 2 || ty < 2 || tx >= map.width - 2 || ty >= map.height - 2) return null;
    const i = idx(tx, ty);
    if (!map.walkable[i] || isOccupied(tx, ty)) return null;
    markTile(tx, ty);

    const id = nextId(cursor, 'src');
    const biome = map.biomes[i];

    const presets: Record<
      SourceKind,
      Omit<SourceNode, 'id' | 'kind' | 'regionId' | 'x' | 'y' | 'depletedAtElapsedSec'>
    > = {
      pine_tree: {
        hp: 45,
        maxHp: 45,
        stock: 1,
        maxStock: 1,
        requiredTag: 'wood',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'wood_log', min: 3, max: 5, chance: 1 },
          { defId: 'pine_resin', min: 1, max: 2, chance: 0.55 },
        ],
        respawnDelaySec: 240,
      },
      oak_tree: {
        hp: 50,
        maxHp: 50,
        stock: 1,
        maxStock: 1,
        requiredTag: 'wood',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'wood_log', min: 4, max: 6, chance: 1 },
          { defId: 'plant_fiber', min: 1, max: 2, chance: 0.5 },
        ],
        respawnDelaySec: 260,
      },
      dead_wood: {
        hp: 24,
        maxHp: 24,
        stock: 1,
        maxStock: 1,
        requiredTag: 'wood',
        interactionMode: 'harvest_hit',
        yieldTable: [{ defId: 'wood_log', min: 2, max: 3, chance: 1 }],
        respawnDelaySec: 180,
      },
      boulder: {
        hp: 55,
        maxHp: 55,
        stock: 1,
        maxStock: 1,
        requiredTag: 'stone',
        interactionMode: 'harvest_hit',
        yieldTable: [{ defId: 'stone_chunk', min: 3, max: 5, chance: 1 }],
        respawnDelaySec: 300,
      },
      iron_vein: {
        hp: 70,
        maxHp: 70,
        stock: 1,
        maxStock: 1,
        requiredTag: 'ore',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'iron_ore', min: 2, max: 4, chance: 1 },
          { defId: 'stone_chunk', min: 1, max: 2, chance: 0.7 },
        ],
        respawnDelaySec: 360,
      },
      coal_seam: {
        hp: 60,
        maxHp: 60,
        stock: 1,
        maxStock: 1,
        requiredTag: 'ore',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'coal_lump', min: 2, max: 4, chance: 1 },
          { defId: 'stone_chunk', min: 1, max: 2, chance: 0.5 },
        ],
        respawnDelaySec: 320,
      },
      cobalt_crystal: {
        hp: 95,
        maxHp: 95,
        stock: 1,
        maxStock: 1,
        requiredTag: 'ore',
        interactionMode: 'harvest_hit',
        yieldTable: [{ defId: 'cobalt_ore', min: 2, max: 3, chance: 1 }],
        respawnDelaySec: null, // Rare finite crystal veins per run
      },
      sulfur_vent: {
        hp: 65,
        maxHp: 65,
        stock: 1,
        maxStock: 1,
        requiredTag: 'ore',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'sulfur_powder', min: 2, max: 4, chance: 1 },
          { defId: 'coal_lump', min: 1, max: 2, chance: 0.5 },
        ],
        respawnDelaySec: 360,
      },
      berry_bush: {
        hp: 18,
        maxHp: 18,
        stock: 1,
        maxStock: 1,
        requiredTag: 'flora',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'wild_berries', min: 2, max: 4, chance: 1 },
          { defId: 'plant_fiber', min: 2, max: 3, chance: 1 },
          { defId: 'grain_seed', min: 1, max: 2, chance: 0.35 },
        ],
        respawnDelaySec: 150,
      },
      marsh_herb: {
        hp: 18,
        maxHp: 18,
        stock: 1,
        maxStock: 1,
        requiredTag: 'flora',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'marsh_herb_leaf', min: 2, max: 3, chance: 1 },
          { defId: 'plant_fiber', min: 2, max: 4, chance: 1 },
        ],
        respawnDelaySec: 170,
      },
      peat_bog: {
        hp: 30,
        maxHp: 30,
        stock: 1,
        maxStock: 1,
        requiredTag: 'flora',
        interactionMode: 'harvest_hit',
        yieldTable: [{ defId: 'peat_brick', min: 2, max: 4, chance: 1 }],
        respawnDelaySec: 220,
      },
      road_crate: {
        hp: 28,
        maxHp: 28,
        stock: 1,
        maxStock: 1,
        requiredTag: 'salvage',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'spares', min: 4, max: 8, chance: 1 },
          { defId: 'scrap_metal', min: 1, max: 3, chance: 0.85 },
          { defId: 'travel_ration', min: 1, max: 1, chance: 0.25 },
          { defId: 'bp_handcart', min: 1, max: 1, chance: 0.14 },
        ],
        respawnDelaySec: null, // Finite roadside salvage per run (C02)
      },
      oil_barrel: {
        hp: 36,
        maxHp: 36,
        stock: 1,
        maxStock: 1,
        requiredTag: 'salvage',
        interactionMode: 'harvest_hit',
        yieldTable: [
          { defId: 'scrap_metal', min: 2, max: 4, chance: 1 },
          { defId: 'spares', min: 3, max: 6, chance: 0.9 },
          { defId: 'biofuel_can', min: 1, max: 1, chance: 0.35 },
        ],
        respawnDelaySec: null,
      },
      industrial_locker: {
        hp: 40,
        maxHp: 40,
        stock: 1,
        maxStock: 1,
        interactionMode: 'loot_open',
        yieldTable: [
          { defId: 'spares', min: 8, max: 14, chance: 1 },
          { defId: 'circuit_board', min: 1, max: 2, chance: 0.75 },
          { defId: 'blue_keycard', min: 1, max: 1, chance: 0.4 },
          { defId: 'filter_mask', min: 1, max: 1, chance: 0.25 },
        ],
        respawnDelaySec: null,
      },
      poi_exterior_cache: {
        hp: 40,
        maxHp: 40,
        stock: 1,
        maxStock: 1,
        interactionMode: 'loot_open',
        yieldTable: [
          { defId: 'spares', min: 6, max: 11, chance: 1 },
          { defId: 'scrap_metal', min: 2, max: 4, chance: 1 },
          { defId: 'copper_fuse', min: 1, max: 1, chance: 0.55 },
          { defId: 'blue_keycard', min: 1, max: 1, chance: 0.45 },
          { defId: 'bp_iron_tools', min: 1, max: 1, chance: 0.35 },
        ],
        respawnDelaySec: null,
      },
      poi_deep_locker: {
        hp: 50,
        maxHp: 50,
        stock: 1,
        maxStock: 1,
        interactionMode: 'loot_open',
        yieldTable: [
          { defId: 'spares', min: 16, max: 24, chance: 1 },
          { defId: 'iron_ingot', min: 3, max: 5, chance: 1 },
          { defId: 'circuit_board', min: 2, max: 3, chance: 1 },
          { defId: 'depleted_core_shell', min: 1, max: 2, chance: 0.85 },
          { defId: 'core_ember', min: 1, max: 1, chance: 0.45 },
          { defId: 'core_volt', min: 1, max: 1, chance: 0.4 },
          { defId: 'core_frost', min: 1, max: 1, chance: 0.35 },
          { defId: 'bp_turret_defense', min: 1, max: 1, chance: 0.55 },
        ],
        respawnDelaySec: null,
      },
      final72_cash_vault: {
        hp: 100,
        maxHp: 100,
        stock: 1,
        maxStock: 1,
        requiresFinal72: true,
        interactionMode: 'loot_open',
        yieldTable: [
          {
            defId: 'ragnarok_cash',
            min: balance.landAndEscrow.nonBossFinal72ChestCashYieldMin,
            max: balance.landAndEscrow.nonBossFinal72ChestCashYieldMax,
            chance: 1,
          },
        ],
        respawnDelaySec: null, // Strictly finite once-per-run Final-72 cash source (C15)
      },
    };

    const node: SourceNode = {
      id,
      kind,
      regionId: biome,
      x: tx + 0.5,
      y: ty + 0.5,
      depletedAtElapsedSec: null,
      ...presets[kind],
      ...opts,
    };
    sources[id] = node;
    return node;
  };

  // 1. Place Fixed World Entities: Vendors, Evacuation Beacons, POI Gates & Power Junctions
  const placeFixedStructure = (
    kind: StructureEntity['kind'],
    tx: number,
    ty: number,
    extra?: Partial<StructureEntity>
  ) => {
    markTile(tx, ty);
    const id = nextId(cursor, 'ent');
    entities[id] = {
      id,
      kind,
      tileX: tx,
      tileY: ty,
      x: tx + 0.5,
      y: ty + 0.5,
      hp: 9999,
      maxHp: 9999,
      owner: 'world',
      createdAtSec: 0,
      provenance: 'world_authored',
      ...extra,
    };
  };

  // Crossroads Quartermaster Outpost (96, 112)
  placeFixedStructure('vendor_escrow_broker', 94, 110);
  placeFixedStructure('vendor_season_shop', 98, 110);

  // Two No-Boss Evacuation Beacons (West Harbor & South Lighthouse Pier)
  placeFixedStructure('evac_beacon', 28, 105);
  placeFixedStructure('evac_beacon', 102, 168);

  // Populate the 4 Multi-Layer Walled POIs (Exterior loot + Gated Inner Room + Final-72 Vaults)
  for (const poi of map.pois) {
    if (!poi.hasDeepVault) continue;
    const cx = poi.x;
    const cy = poi.y;
    const usesPowerFuse = poi.kind === 'relay_bunker' || poi.kind === 'ragnarok_pavilion';

    // Seal doorway at (cx, cy) with a locked `poi_gate`
    placeFixedStructure('poi_gate', cx, cy, {
      open: false,
      powered: !usesPowerFuse,
      linkedPoiId: poi.id,
      requiredKeyDefId: usesPowerFuse ? 'copper_fuse' : 'blue_keycard',
    });

    if (usesPowerFuse) {
      // Exterior power junction box right outside the masonry wall at (cx + 3, cy + 1)
      placeFixedStructure('poi_power_box', cx + 3, cy + 1, {
        powered: false,
        linkedPoiId: poi.id,
        requiredKeyDefId: 'copper_fuse',
      });
    }

    // Useful Exterior Courtyard Sources (accessible early without keys, C11!)
    addSource('poi_exterior_cache', cx - 3, cy + 2, { poiId: poi.id });
    addSource('road_crate', cx + 3, cy + 3, { poiId: poi.id });
    addSource('oil_barrel', cx - 3, cy + 4, { poiId: poi.id });

    // Deep Inner Vault Sources behind `poi_gate` ([cx-1..cx+1, cy-3..cy-1])
    addSource('poi_deep_locker', cx - 1, cy - 3, { poiId: poi.id, requiresDeepAccess: true });
    addSource('industrial_locker', cx + 1, cy - 3, { poiId: poi.id, requiresDeepAccess: true });

    // Final-72 Special Ragnarok Cash Vaults (C15 & C16):
    // For Relay Bunker & Harbor Depot, place an armored Final-72 Ragnarok Vault in the accessible exterior pavilion
    // so a zero-wallet player need NOT fight any Elder or get RNG-locked out of buying their first Escrow Chest!
    // Deep vaults at Quarantine Lab & Reactor Sub-Vault hold larger Final-72 Ragnarok Cash caches!
    if (poi.id === 'poi_relay_bunker' || poi.id === 'poi_harbor_depot') {
      addSource('final72_cash_vault', cx + 2, cy + 2, {
        poiId: poi.id,
        requiresFinal72: true,
        yieldTable: [
          {
            defId: 'ragnarok_cash',
            min: 145,
            max: 175,
            chance: 1,
          },
        ],
      });
    } else if (poi.hasFinal72Vault) {
      addSource('final72_cash_vault', cx, cy - 2, {
        poiId: poi.id,
        requiresDeepAccess: true,
        requiresFinal72: true,
        yieldTable: [
          {
            defId: 'ragnarok_cash',
            min: balance.landAndEscrow.deepFinal72ChestCashYield,
            max: balance.landAndEscrow.deepFinal72ChestCashYield + 40,
            chance: 1,
          },
        ],
      });
    }
  }

  // 2. Guarantee Balanced Starter Resources Around All 4 Viable Spawn Regions (MAP-SPAWN-04, C24)
  for (const sp of map.spawnRegions) {
    markTile(sp.x, sp.y);
    addSource('oak_tree', sp.x - 3, sp.y - 2);
    addSource('pine_tree', sp.x + 4, sp.y - 2);
    addSource('boulder', sp.x - 4, sp.y + 3);
    addSource('boulder', sp.x + 3, sp.y + 4);
    addSource('berry_bush', sp.x + 2, sp.y + 2);
    addSource('berry_bush', sp.x - 2, sp.y + 3);
    addSource('road_crate', sp.x + 5, sp.y + 1);
    // Guarantee an early discoverable Charged Core shrine pedestal within optional exploring distance (~11 tiles) of each spawn (C03!)
    const coreChoices = ['core_ember', 'core_gale', 'core_frost', 'core_thorn'];
    const coreDef = coreChoices[map.spawnRegions.indexOf(sp) % coreChoices.length];
    addSource('poi_exterior_cache', sp.x + 8, sp.y - 6, {
      yieldTable: [
        { defId: coreDef, min: 1, max: 1, chance: 1 },
        { defId: 'spares', min: 5, max: 8, chance: 1 },
      ],
    });
  }

  // 3. Distribute Rich Biome-Authentic Natural & Roadside Sources Across the 200x200 Island
  for (let ty = 6; ty < map.height - 6; ty += 2) {
    for (let tx = 6; tx < map.width - 6; tx += 2) {
      const jx = tx + (nextFloat(cursor) > 0.5 ? 1 : 0);
      const jy = ty + (nextFloat(cursor) > 0.5 ? 1 : 0);
      const i = idx(jx, jy);
      if (!map.walkable[i] || isOccupied(jx, jy)) continue;

      const surf = map.surfaces[i];
      const biome = map.biomes[i];

      // Roadside salvage crates & oil barrels (adjacent to road tiles, never blocking road center!)
      if (surf !== 'road' && surf !== 'bridge') {
        const nearRoad =
          map.surfaces[idx(jx + 1, jy)] === 'road' ||
          map.surfaces[idx(jx - 1, jy)] === 'road' ||
          map.surfaces[idx(jx, jy + 1)] === 'road' ||
          map.surfaces[idx(jx, jy - 1)] === 'road';
        if (nearRoad && nextFloat(cursor) < 0.085) {
          addSource(nextFloat(cursor) < 0.68 ? 'road_crate' : 'oil_barrel', jx, jy);
          continue;
        }
      }

      if (surf === 'road' || surf === 'bridge' || surf === 'stone_floor') continue;
      const roll = nextFloat(cursor);

      if (biome === 'forest') {
        if (roll < 0.22) addSource('pine_tree', jx, jy);
        else if (roll < 0.28) addSource('oak_tree', jx, jy);
        else if (roll < 0.32) addSource('berry_bush', jx, jy);
        else if (roll < 0.35) addSource('boulder', jx, jy);
      } else if (biome === 'meadow') {
        if (roll < 0.09) addSource('oak_tree', jx, jy);
        else if (roll < 0.16) addSource('berry_bush', jx, jy);
        else if (roll < 0.20) addSource('boulder', jx, jy);
      } else if (biome === 'steppe') {
        if (roll < 0.06) addSource('dead_wood', jx, jy);
        else if (roll < 0.12) addSource('boulder', jx, jy);
        else if (roll < 0.16) addSource('iron_vein', jx, jy);
        else if (roll < 0.20) addSource('berry_bush', jx, jy);
      } else if (biome === 'highland') {
        if (roll < 0.12) addSource('boulder', jx, jy);
        else if (roll < 0.19) addSource('iron_vein', jx, jy);
        else if (roll < 0.24) addSource('coal_seam', jx, jy);
        else if (roll < 0.27) addSource('pine_tree', jx, jy);
      } else if (biome === 'marsh') {
        if (roll < 0.11) addSource('marsh_herb', jx, jy);
        else if (roll < 0.18) addSource('peat_bog', jx, jy);
        else if (roll < 0.23) addSource('dead_wood', jx, jy);
      } else if (biome === 'tundra') {
        if (roll < 0.07) addSource('cobalt_crystal', jx, jy);
        else if (roll < 0.13) addSource('iron_vein', jx, jy);
        else if (roll < 0.18) addSource('pine_tree', jx, jy);
      } else if (biome === 'caldera') {
        if (roll < 0.11) addSource('sulfur_vent', jx, jy);
        else if (roll < 0.17) addSource('coal_seam', jx, jy);
        else if (roll < 0.21) addSource('iron_vein', jx, jy);
      } else if (biome === 'industrial') {
        if (roll < 0.06) addSource('industrial_locker', jx, jy);
        else if (roll < 0.13) addSource('oil_barrel', jx, jy);
        else if (roll < 0.17) addSource('road_crate', jx, jy);
      } else if (biome === 'beach') {
        if (roll < 0.05) addSource('dead_wood', jx, jy);
        else if (roll < 0.08) addSource('boulder', jx, jy);
      }
    }
  }

  // 4. Populate Habitat-Authentic Common Monsters (Never inside safe spawn buffer or Trading Outpost!)
  const isNearSafeZone = (tx: number, ty: number) => {
    for (const sp of map.spawnRegions) {
      if (dist(tx, ty, sp.x, sp.y) < 12) return true;
    }
    // Trading outpost & evac piers kept clear of static spawns
    if (dist(tx, ty, 96, 112) < 12) return true;
    if (dist(tx, ty, 28, 105) < 9 || dist(tx, ty, 102, 168) < 9) return true;
    return false;
  };

  const monsterTemplates: Record<
    CreatureArchetype,
    {
      name: string;
      hp: number;
      speed: number;
      damage: number;
      range: number;
      sight: number;
      loot: MonsterActor['lootTable'];
    }
  > = {
    wild_boar: {
      name: 'Razorback Boar',
      hp: 55,
      speed: 3.1,
      damage: 14,
      range: 1.5,
      sight: 6.5,
      loot: [
        { defId: 'raw_meat', min: 1, max: 2, chance: 1 },
        { defId: 'beast_hide', min: 1, max: 2, chance: 0.85 },
      ],
    },
    marsh_kappa: {
      name: 'Fen Lurker',
      hp: 72,
      speed: 2.8,
      damage: 17,
      range: 2.2,
      sight: 7.0,
      loot: [
        { defId: 'marsh_herb_leaf', min: 1, max: 3, chance: 0.9 },
        { defId: 'peat_brick', min: 1, max: 2, chance: 0.7 },
        { defId: 'raw_meat', min: 1, max: 1, chance: 0.6 },
      ],
    },
    ruin_sentinel: {
      name: 'Wasteland Raider',
      hp: 82,
      speed: 3.25,
      damage: 19,
      range: 1.75,
      sight: 7.5,
      loot: [
        { defId: 'spares', min: 4, max: 8, chance: 1 },
        { defId: 'scrap_metal', min: 1, max: 2, chance: 0.75 },
        { defId: 'copper_fuse', min: 1, max: 1, chance: 0.25 },
      ],
    },
    frost_wolf: {
      name: 'Glacial Direwolf',
      hp: 90,
      speed: 3.7,
      damage: 22,
      range: 1.65,
      sight: 8.0,
      loot: [
        { defId: 'beast_hide', min: 2, max: 3, chance: 1 },
        { defId: 'raw_meat', min: 1, max: 2, chance: 0.9 },
      ],
    },
    cinder_crawler: {
      name: 'Caldera Carapace',
      hp: 105,
      speed: 2.75,
      damage: 24,
      range: 1.85,
      sight: 7.2,
      loot: [
        { defId: 'sulfur_powder', min: 2, max: 3, chance: 1 },
        { defId: 'coal_lump', min: 1, max: 2, chance: 0.8 },
      ],
    },
    blight_husk: {
      name: 'Contaminated Husk',
      hp: 96,
      speed: 2.9,
      damage: 21,
      range: 1.9,
      sight: 7.5,
      loot: [
        { defId: 'spares', min: 5, max: 10, chance: 1 },
        { defId: 'circuit_board', min: 1, max: 1, chance: 0.45 },
        { defId: 'blue_keycard', min: 1, max: 1, chance: 0.22 },
      ],
    },
  };

  for (let ty = 12; ty < map.height - 12; ty += 9) {
    for (let tx = 12; tx < map.width - 12; tx += 9) {
      const mx = tx + nextInt(cursor, -2, 2);
      const my = ty + nextInt(cursor, -2, 2);
      const i = idx(mx, my);
      if (!map.walkable[i] || isOccupied(mx, my) || isNearSafeZone(mx, my)) continue;
      if (nextFloat(cursor) > 0.46) continue;

      const biome = map.biomes[i];
      let arch: CreatureArchetype | null = null;
      if (biome === 'forest' || biome === 'meadow') arch = 'wild_boar';
      else if (biome === 'marsh') arch = 'marsh_kappa';
      else if (biome === 'steppe' || biome === 'highland') arch = 'ruin_sentinel';
      else if (biome === 'tundra') arch = 'frost_wolf';
      else if (biome === 'caldera') arch = 'cinder_crawler';
      else if (biome === 'industrial') arch = 'blight_husk';

      if (!arch) continue;
      const tpl = monsterTemplates[arch];
      const id = nextId(cursor, 'mob');
      monsters[id] = {
        id,
        isElder: false,
        archetype: arch,
        name: tpl.name,
        x: mx + 0.5,
        y: my + 0.5,
        homeX: mx + 0.5,
        homeY: my + 0.5,
        leashRadius: 16,
        hp: tpl.hp,
        maxHp: tpl.hp,
        speed: tpl.speed,
        attackDamage: tpl.damage,
        attackRange: tpl.range,
        sightRange: tpl.sight,
        facingRad: nextFloat(cursor) * Math.PI * 2,
        aiState: 'PATROL',
        trackingTraceId: null,
        patrolTarget: null,
        telegraph: null,
        cooldownUntilSec: 0,
        hitFlashUntilSec: 0,
        lootTable: tpl.loot,
        lootGranted: false,
      };
    }
  }

  // 5. Populate the Six Distinct Optional Elders in Latent Form (Awaken at Hour 312 / Day 14, C19!)
  const elderConfigs: Record<
    ElderId,
    { name: string; hp: number; dmg: number; speed: number; stoneDefId: string; coreDrop: string }
  > = {
    elder_verdant: {
      name: 'Sylvan Behemoth',
      hp: 460,
      dmg: 32,
      speed: 2.5,
      stoneDefId: 'stone_verdant',
      coreDrop: 'core_thorn',
    },
    elder_mire: {
      name: 'Mire Leviathan',
      hp: 490,
      dmg: 34,
      speed: 2.4,
      stoneDefId: 'stone_mire',
      coreDrop: 'core_aegis',
    },
    elder_glacial: {
      name: 'Glacial Warden',
      hp: 520,
      dmg: 36,
      speed: 2.55,
      stoneDefId: 'stone_glacial',
      coreDrop: 'core_frost',
    },
    elder_caldera: {
      name: 'Caldera Tyrant',
      hp: 560,
      dmg: 40,
      speed: 2.65,
      stoneDefId: 'stone_caldera',
      coreDrop: 'core_ember',
    },
    elder_ferric: {
      name: 'Rust Sovereign',
      hp: 540,
      dmg: 38,
      speed: 2.6,
      stoneDefId: 'stone_ferric',
      coreDrop: 'core_volt',
    },
    elder_abyssal: {
      name: 'Abyssal Herald',
      hp: 530,
      dmg: 37,
      speed: 2.7,
      stoneDefId: 'stone_abyssal',
      coreDrop: 'core_gale',
    },
  };

  for (const es of map.elderSites) {
    const cfg = elderConfigs[es.elderId];
    const id = es.elderId;
    monsters[id] = {
      id,
      isElder: true,
      archetype: es.elderId,
      name: cfg.name,
      elderForm: 'latent',
      stoneDefId: cfg.stoneDefId,
      x: es.x + 0.5,
      y: es.y + 0.5,
      homeX: es.x + 0.5,
      homeY: es.y + 0.5,
      leashRadius: 15,
      hp: cfg.hp,
      maxHp: cfg.hp,
      speed: cfg.speed,
      attackDamage: cfg.dmg,
      attackRange: 2.9,
      sightRange: 9.0,
      facingRad: Math.PI * 0.5,
      aiState: 'PATROL',
      trackingTraceId: null,
      patrolTarget: null,
      telegraph: null,
      cooldownUntilSec: 0,
      hitFlashUntilSec: 0,
      lootTable: [
        { defId: cfg.stoneDefId, min: 1, max: 1, chance: 1 },
        { defId: cfg.coreDrop, min: 1, max: 1, chance: 1 },
        { defId: 'cobalt_ingot', min: 2, max: 4, chance: 1 },
      ],
      lootGranted: false,
    };
  }

  return { sources, entities, monsters };
}
