import balance from '../data/balance.v1.json';
import { ITEMS_CATALOG } from '../data/itemsCatalog';
import { BASELINE_RECIPE_IDS, RECIPES_CATALOG } from '../data/recipesCatalog';
import { STRUCTURES_CATALOG } from '../data/structuresCatalog';
import {
  computeContainerWeightKg,
  computePlayerCarryWeightKg,
  countItemInContainer,
  createContainer,
  debitItemsFromContainer,
  getActiveQuickbarItem,
  hasItemsInContainer,
  mintNewItemToContainerOrDrop,
  transferExistingInstance,
} from './custody';
import { isTileBlockedForActor } from './pathfinding';
import { nextFloat, nextId, nextInt, RngCursor } from './rng';
import {
  advanceEnvironmentAndSources,
  advanceMonstersAndCombat,
  advancePlayerSurvival,
  advanceStationsAndJobs,
  awakenEldersIfDay14,
  canBuildAtTile,
  computeRunPhase,
  damageMonster,
  finalizeRunOnce,
  getElapsedRunHours,
  isInFinal72Hours,
  isTileOnOwnedLand,
  recordUniqueScore,
  settleChronologicalSeconds,
} from './simulation';
import {
  AdventurerGender,
  CommitReceipt,
  DispatchResult,
  FootprintTrace,
  GameIntent,
  GameState,
  ProfileState,
  StructureEntity,
} from './types';
import { getStaticIslandMap, ISLAND_GEOGRAPHY_SEED, populateRunWorldEntities } from './worldGen';

export function createDefaultProfile(): ProfileState {
  return {
    profileId: 'local_adventurer_profile',
    securedCash: 0,
    achievements: [],
    runHistory: [],
    totalRunsStarted: 0,
  };
}

export function createNewRunGameState(options: {
  gender: AdventurerGender;
  spawnRegionId?: string;
  nowUtcMs: number;
  existingProfile?: ProfileState;
  runSeedOffset?: number;
}): GameState {
  const profile: ProfileState = options.existingProfile
    ? structuredClone(options.existingProfile)
    : createDefaultProfile();
  profile.totalRunsStarted += 1;

  const runNumber = profile.totalRunsStarted;
  const cursor: RngCursor = {
    rngState: ((ISLAND_GEOGRAPHY_SEED ^ (runNumber * 0x9e3779b9) ^ (options.runSeedOffset ?? 0)) >>> 0) || 1234567,
    nextIdCounter: 100,
  };

  const map = getStaticIslandMap(ISLAND_GEOGRAPHY_SEED);
  const chosenSpawn =
    map.spawnRegions.find((s) => s.id === options.spawnRegionId) ??
    map.spawnRegions[nextInt(cursor, 0, map.spawnRegions.length - 1)];

  const { sources, entities, monsters } = populateRunWorldEntities(map, cursor);

  const state: GameState = {
    schemaVersion: 1,
    revision: 1,
    rngState: cursor.rngState,
    nextIdCounter: cursor.nextIdCounter,
    profile,
    run: {
      runId: `run_${runNumber}_${options.nowUtcMs}`,
      runNumber,
      active: true,
      endReason: null,
      cashDepositedThisRun: 0,
      eldersDefeated: [],
      scoreReceipts: [],
    },
    clock: {
      runStartUtcMs: options.nowUtcMs,
      lastSettledUtcMs: options.nowUtcMs,
      qaAcceleratedMs: 0,
      isQaAccelerated: false,
      elapsedSimSec: 0,
      fictionalDaySec: balance.clock.fictionalDayLengthSeconds * 0.28, // crisp morning light!
      fictionalTimeScale: 1,
      weather: 'CLEAR',
      weatherRemainingSec: balance.tracesAndWeather.weatherCycleBaseSec,
      phase: 'EXPEDITION',
    },
    world: {
      seed: ISLAND_GEOGRAPHY_SEED,
      width: map.width,
      height: map.height,
      pois: map.pois,
      spawnRegions: map.spawnRegions,
      elderSites: map.elderSites,
      homesteads: [],
      footprints: [],
      fires: [],
      scorchedTiles: [],
      projectiles: [],
      vfx: [],
      vendorStocks: {
        escrowBrokerKits: 3,
        seasonShop: {
          iron_axe: { defId: 'iron_axe', priceSecuredCash: 60, stock: 2 },
          iron_pickaxe: { defId: 'iron_pickaxe', priceSecuredCash: 60, stock: 2 },
          salvage_crowbar: { defId: 'salvage_crowbar', priceSecuredCash: 45, stock: 2 },
          fur_parka: { defId: 'fur_parka', priceSecuredCash: 75, stock: 1 },
          filter_mask: { defId: 'filter_mask', priceSecuredCash: 70, stock: 1 },
          handcart_kit: { defId: 'handcart_kit', priceSecuredCash: 85, stock: 1 },
          travel_ration_pack: { defId: 'travel_ration', priceSecuredCash: 25, stock: 5 },
          core_gale: { defId: 'core_gale', priceSecuredCash: 120, stock: 1 },
        },
      },
    },
    actors: {
      player: {
        id: 'player',
        gender: options.gender,
        x: chosenSpawn.x + 0.5,
        y: chosenSpawn.y + 0.5,
        vx: 0,
        vy: 0,
        facingRad: Math.PI * 0.5,
        hp: balance.survival.playerMaxHp,
        maxHp: balance.survival.playerMaxHp,
        stamina: balance.survival.playerMaxStamina,
        maxStamina: balance.survival.playerMaxStamina,
        hunger: balance.survival.playerMaxHunger,
        maxHunger: balance.survival.playerMaxHunger,
        warmth: balance.survival.playerMaxWarmth,
        maxWarmth: balance.survival.playerMaxWarmth,
        toxicShieldSec: 0,
        dead: false,
        spawnRegionId: chosenSpawn.id,
        boundBedEntityId: null,
        hitchedCartEntityId: null,
        lastFootprintPos: { x: chosenSpawn.x + 0.5, y: chosenSpawn.y + 0.5 },
        lastFootprintId: null,
        activeWindup: null,
        lastAttackCooldownUntilMs: 0,
        invulnUntilMs: 0,
      },
      monsters,
    },
    sources,
    entities,
    custody: {
      items: {},
      containers: {
        player_inv: createContainer('player_inv', 'player_inv', 24),
      },
      playerQuickbar: [0, 1, 2, 3, 4, 5, 6, 7],
      equippedHeadId: null,
      equippedBodyId: null,
      activeQuickSlot: 0,
    },
    knowledge: {
      unlockedRecipes: [...BASELINE_RECIPE_IDS],
      discoveredPois: [],
      studiedSpecimens: [],
      completedOptionalMilestones: [],
    },
    jobs: {},
    receipts: [],
    processedRequestIds: [],
  };

  // Humble starter kit: Flint Knife, 3 Sunberries, 1 Bandage — no Core, no compulsory quest!
  const starterCursor: RngCursor = { rngState: state.rngState, nextIdCounter: state.nextIdCounter };
  mintNewItemToContainerOrDrop(state, starterCursor, 'player_inv', 'flint_knife', 1, 'starter_kit');
  mintNewItemToContainerOrDrop(state, starterCursor, 'player_inv', 'wild_berries', 3, 'starter_kit');
  mintNewItemToContainerOrDrop(state, starterCursor, 'player_inv', 'herbal_bandage', 1, 'starter_kit');
  state.rngState = starterCursor.rngState;
  state.nextIdCounter = starterCursor.nextIdCounter;

  appendReceipt(state, starterCursor, 'START_NEW_RUN', `Started Run #${runNumber} at ${chosenSpawn.name}`);
  state.rngState = starterCursor.rngState;
  state.nextIdCounter = starterCursor.nextIdCounter;
  return state;
}

function appendReceipt(
  state: GameState,
  cursor: RngCursor,
  action: string,
  summary: string,
  requestId?: string
): CommitReceipt {
  const rec: CommitReceipt = {
    id: nextId(cursor, 'rcp'),
    seq: state.revision,
    requestId,
    action,
    atSimSec: Math.round(state.clock.elapsedSimSec * 100) / 100,
    summary,
  };
  state.receipts.unshift(rec);
  if (state.receipts.length > 120) state.receipts.length = 120;
  if (requestId) {
    state.processedRequestIds.push(requestId);
    if (state.processedRequestIds.length > 300) {
      state.processedRequestIds.shift();
    }
  }
  return rec;
}

function reject(state: GameState, reason: string): DispatchResult {
  return { accepted: false, state, rejectionReason: reason };
}

function commit(
  nextState: GameState,
  cursor: RngCursor,
  action: string,
  summary: string,
  requestId?: string
): DispatchResult {
  nextState.revision += 1;
  nextState.rngState = cursor.rngState;
  nextState.nextIdCounter = cursor.nextIdCounter;
  const receipt = appendReceipt(nextState, cursor, action, summary, requestId);
  nextState.rngState = cursor.rngState;
  nextState.nextIdCounter = cursor.nextIdCounter;
  return { accepted: true, state: nextState, receipt };
}

function commitWindupEffect(state: GameState, cursor: RngCursor, nowMs: number): void {
  const player = state.actors.player;
  const w = player.activeWindup;
  if (!w || w.committed) return;
  w.committed = true;

  const map = getStaticIslandMap(state.world.seed);

  // 1. Evacuation Channel Completion (C22)
  if (w.kind === 'evac_channel') {
    const beacon = w.targetEntityId ? state.entities[w.targetEntityId] : undefined;
    if (beacon && Math.hypot(beacon.x - player.x, beacon.y - player.y) <= 3.8) {
      player.activeWindup = null;
      finalizeRunOnce(state, cursor, 'EVACUATED', state.clock.lastSettledUtcMs);
    }
    return;
  }

  // 2. Charged Core Execution (Debits 1 charge AT COMMIT, never during canceled windup! C03, C05)
  if (w.kind === 'core' && w.itemInstanceId) {
    const inst = state.custody.items[w.itemInstanceId];
    const def = inst ? ITEMS_CATALOG[inst.defId] : undefined;
    if (!inst || !def || (inst.charges ?? 0) <= 0) return;

    inst.charges = (inst.charges ?? 1) - 1;
    player.stamina = Math.max(0, player.stamina - (def.staminaCost ?? 10));

    const skill = w.coreSkill ?? def.coreSkill;
    const range = def.rangeTiles ?? 3.5;
    const dmg = def.damage ?? 45;

    if (skill === 'ember_arc') {
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'ember_arc',
        x: player.x,
        y: player.y,
        angleRad: w.aimAngleRad,
        radius: range,
        createdAtMs: nowMs,
        durationMs: 360,
      });
      // Hit enemies in wide fiery crescent
      for (const mob of Object.values(state.actors.monsters)) {
        if (mob.aiState === 'DEAD') continue;
        const d = Math.hypot(mob.x - player.x, mob.y - player.y);
        const ang = Math.atan2(mob.y - player.y, mob.x - player.x);
        const diff = Math.abs(Math.atan2(Math.sin(ang - w.aimAngleRad), Math.cos(ang - w.aimAngleRad)));
        if (d <= range && diff <= 1.05) {
          damageMonster(state, cursor, mob, dmg, player.x, player.y, nowMs);
        }
      }
      // Lawful environmental consequences: fell timber / ignite flammable dry brush in arc! (C05)
      for (const s of Object.values(state.sources)) {
        if (s.stock <= 0) continue;
        const d = Math.hypot(s.x - player.x, s.y - player.y);
        const ang = Math.atan2(s.y - player.y, s.x - player.x);
        const diff = Math.abs(Math.atan2(Math.sin(ang - w.aimAngleRad), Math.cos(ang - w.aimAngleRad)));
        if (d <= range * 0.9 && diff <= 0.95 && (s.kind === 'pine_tree' || s.kind === 'oak_tree' || s.kind === 'berry_bush')) {
          s.hp -= 35;
          if (s.hp <= 0) {
            depleteSourceOnce(state, cursor, s, nowMs, true);
          }
        }
      }
      const fx = Math.floor(player.x + Math.cos(w.aimAngleRad) * 2.0);
      const fy = Math.floor(player.y + Math.sin(w.aimAngleRad) * 2.0);
      if (
        fx > 1 &&
        fy > 1 &&
        fx < map.width - 1 &&
        fy < map.height - 1 &&
        map.flammable[fy * map.width + fx] &&
        state.clock.weather !== 'RAIN' &&
        state.clock.weather !== 'STORM'
      ) {
        state.world.fires.push({ tileX: fx, tileY: fy, expiresAtSec: state.clock.elapsedSimSec + 8 });
      }
    } else if (skill === 'frost_nova') {
      const cx = player.x + Math.cos(w.aimAngleRad) * Math.min(2.2, Math.hypot(w.targetX - player.x, w.targetY - player.y));
      const cy = player.y + Math.sin(w.aimAngleRad) * Math.min(2.2, Math.hypot(w.targetX - player.x, w.targetY - player.y));
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'frost_nova',
        x: cx,
        y: cy,
        radius: 2.8,
        createdAtMs: nowMs,
        durationMs: 420,
      });
      for (const mob of Object.values(state.actors.monsters)) {
        if (mob.aiState !== 'DEAD' && Math.hypot(mob.x - cx, mob.y - cy) <= 2.8) {
          damageMonster(state, cursor, mob, dmg, cx, cy, nowMs);
          mob.cooldownUntilSec = Math.max(mob.cooldownUntilSec, state.clock.elapsedSimSec + 1.8);
        }
      }
      // Extinguish nearby fires!
      state.world.fires = state.world.fires.filter((f) => Math.hypot(f.tileX + 0.5 - cx, f.tileY + 0.5 - cy) > 3.2);
    } else if (skill === 'gale_dash') {
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'gale_dash',
        x: player.x,
        y: player.y,
        angleRad: w.aimAngleRad,
        radius: 3.4,
        createdAtMs: nowMs,
        durationMs: 300,
      });
      for (let step = 1; step <= 6; step++) {
        const nx = player.x + Math.cos(w.aimAngleRad) * 0.55;
        const ny = player.y + Math.sin(w.aimAngleRad) * 0.55;
        if (!isTileBlockedForActor(map, state, Math.floor(nx), Math.floor(ny)).blocked) {
          player.x = nx;
          player.y = ny;
        } else {
          break;
        }
      }
      player.invulnUntilMs = Math.max(player.invulnUntilMs, nowMs + 280);
      for (const mob of Object.values(state.actors.monsters)) {
        if (mob.aiState !== 'DEAD' && Math.hypot(mob.x - player.x, mob.y - player.y) <= 2.0) {
          damageMonster(state, cursor, mob, dmg, player.x, player.y, nowMs);
        }
      }
    } else if (skill === 'volt_lance') {
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'volt_lance',
        x: player.x,
        y: player.y,
        angleRad: w.aimAngleRad,
        radius: range,
        createdAtMs: nowMs,
        durationMs: 280,
      });
      state.world.projectiles.push({
        id: nextId(cursor, 'prj'),
        ownerId: 'player',
        fromPlayer: true,
        kind: 'volt_bolt',
        x: player.x + Math.cos(w.aimAngleRad) * 0.6,
        y: player.y + Math.sin(w.aimAngleRad) * 0.6,
        vx: Math.cos(w.aimAngleRad) * 16,
        vy: Math.sin(w.aimAngleRad) * 16,
        damage: dmg,
        radius: 0.45,
        expiresAtSec: state.clock.elapsedSimSec + 0.65,
      });
    } else if (skill === 'thorn_snare') {
      const cx = player.x + Math.cos(w.aimAngleRad) * Math.min(3.2, Math.hypot(w.targetX - player.x, w.targetY - player.y));
      const cy = player.y + Math.sin(w.aimAngleRad) * Math.min(3.2, Math.hypot(w.targetX - player.x, w.targetY - player.y));
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'thorn_snare',
        x: cx,
        y: cy,
        radius: 2.4,
        createdAtMs: nowMs,
        durationMs: 480,
      });
      for (const mob of Object.values(state.actors.monsters)) {
        if (mob.aiState !== 'DEAD' && Math.hypot(mob.x - cx, mob.y - cy) <= 2.5) {
          damageMonster(state, cursor, mob, dmg, cx, cy, nowMs);
          mob.cooldownUntilSec = Math.max(mob.cooldownUntilSec, state.clock.elapsedSimSec + 2.2);
        }
      }
    } else if (skill === 'aegis_pulse') {
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'aegis_pulse',
        x: player.x,
        y: player.y,
        radius: 2.8,
        createdAtMs: nowMs,
        durationMs: 380,
      });
      player.hp = Math.min(player.maxHp, player.hp + 28);
      player.warmth = Math.min(player.maxWarmth, player.warmth + 25);
      for (const mob of Object.values(state.actors.monsters)) {
        if (mob.aiState !== 'DEAD' && Math.hypot(mob.x - player.x, mob.y - player.y) <= 2.8) {
          damageMonster(state, cursor, mob, dmg, player.x, player.y, nowMs);
        }
      }
    }

    // Transform empty Core into Reusable Dormant Core Lattice!
    if ((inst.charges ?? 0) <= 0) {
      inst.defId = 'depleted_core_shell';
      inst.charges = undefined;
    }
    return;
  }

  // 3. Ranged Projectile Attack (Bow + Wooden Arrow)
  if (w.kind === 'projectile' && w.itemInstanceId) {
    const inst = state.custody.items[w.itemInstanceId];
    const def = inst ? ITEMS_CATALOG[inst.defId] : undefined;
    if (!inst || !def) return;
    if (!debitItemsFromContainer(state, 'player_inv', [{ defId: 'wooden_arrow', qty: 1 }])) return;

    player.stamina = Math.max(0, player.stamina - (def.staminaCost ?? 8));
    const spd = def.projectileSpeed ?? 13.5;
    state.world.projectiles.push({
      id: nextId(cursor, 'prj'),
      ownerId: 'player',
      fromPlayer: true,
      kind: 'arrow',
      x: player.x + Math.cos(w.aimAngleRad) * 0.5,
      y: player.y + Math.sin(w.aimAngleRad) * 0.5,
      vx: Math.cos(w.aimAngleRad) * spd,
      vy: Math.sin(w.aimAngleRad) * spd,
      damage: def.damage ?? 26,
      radius: 0.3,
      expiresAtSec: state.clock.elapsedSimSec + 0.75,
    });
    decrementToolDurability(state, inst.id);
    return;
  }

  // 4. True 360-Degree Melee Attack & Physical Source Harvesting (Separate Actor Damage vs Extractable Yield! C01, C02, C05)
  const inst = w.itemInstanceId ? state.custody.items[w.itemInstanceId] : null;
  const def = inst ? ITEMS_CATALOG[inst.defId] : null;
  const dmg = def?.damage ?? balance.combat.unarmedDamage;
  const range = def?.rangeTiles ?? balance.combat.unarmedRangeTiles;
  const halfArcRad = (((def?.attackArcDeg ?? 80) * Math.PI) / 180) * 0.5;
  player.stamina = Math.max(0, player.stamina - (def?.staminaCost ?? 4));

  state.world.vfx.push({
    id: nextId(cursor, 'vfx'),
    kind: 'slash_arc',
    x: player.x,
    y: player.y,
    angleRad: w.aimAngleRad,
    radius: range,
    createdAtMs: nowMs,
    durationMs: 190,
  });

  let usedTool = false;

  // 4a. Check combat hits against Monsters & Elders
  for (const mob of Object.values(state.actors.monsters)) {
    if (mob.aiState === 'DEAD') continue;
    const hitAllowance = mob.isElder ? 0.75 : 0.4;
    const d = Math.hypot(mob.x - player.x, mob.y - player.y);
    if (d <= range + hitAllowance) {
      const ang = Math.atan2(mob.y - player.y, mob.x - player.x);
      const diff = Math.abs(Math.atan2(Math.sin(ang - w.aimAngleRad), Math.cos(ang - w.aimAngleRad)));
      if (diff <= halfArcRad + 0.25 || d <= 0.85) {
        damageMonster(state, cursor, mob, dmg, player.x, player.y, nowMs);
        state.world.vfx.push({
          id: nextId(cursor, 'vfx'),
          kind: 'hit_spark',
          x: mob.x,
          y: mob.y,
          createdAtMs: nowMs,
          durationMs: 200,
        });
        usedTool = true;
      }
    }
  }

  // 4b. Check harvest hits against physical SourceNodes (only closest eligible source in swing cone)
  let bestSource: (typeof state.sources)[string] | null = null;
  let bestDist = Infinity;
  for (const s of Object.values(state.sources)) {
    if (s.stock <= 0 || s.interactionMode !== 'harvest_hit') continue;
    const d = Math.hypot(s.x - player.x, s.y - player.y);
    if (d <= range + 0.45) {
      const ang = Math.atan2(s.y - player.y, s.x - player.x);
      const diff = Math.abs(Math.atan2(Math.sin(ang - w.aimAngleRad), Math.cos(ang - w.aimAngleRad)));
      if ((diff <= halfArcRad + 0.22 || d <= 0.9) && d < bestDist) {
        bestDist = d;
        bestSource = s;
      }
    }
  }

  if (bestSource) {
    const reqTag = bestSource.requiredTag;
    const tagPower = reqTag ? def?.harvestPower?.[reqTag] ?? 0 : 1;

    // Cobalt crystal requires Iron Pickaxe (ore power >= 4)
    if (bestSource.kind === 'cobalt_crystal' && tagPower < 4) {
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'floating_text',
        x: bestSource.x,
        y: bestSource.y - 0.5,
        text: 'Needs Iron Pick!',
        color: '#98c1d9',
        createdAtMs: nowMs,
        durationMs: 700,
      });
    } else if ((bestSource.kind === 'iron_vein' || bestSource.kind === 'coal_seam' || bestSource.kind === 'sulfur_vent') && tagPower < 2) {
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'floating_text',
        x: bestSource.x,
        y: bestSource.y - 0.5,
        text: 'Needs Pickaxe',
        color: '#e0fbfc',
        createdAtMs: nowMs,
        durationMs: 700,
      });
    } else {
      // Bare hand / knife can gather flora, dead wood, boulders slowly, or break road crates; specialized tools excel!
      const effectiveHarvestDmg = tagPower > 0 ? 8 + tagPower * 7 : reqTag === 'stone' ? 5 : 7;
      bestSource.hp -= effectiveHarvestDmg;
      usedTool = true;
      state.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'harvest_chips',
        x: bestSource.x,
        y: bestSource.y,
        createdAtMs: nowMs,
        durationMs: 240,
      });
      if (bestSource.hp <= 0) {
        depleteSourceOnce(state, cursor, bestSource, nowMs, false);
      }
    }
  }

  if (usedTool && inst) {
    decrementToolDurability(state, inst.id);
  }
}

function decrementToolDurability(state: GameState, instanceId: string): void {
  const inst = state.custody.items[instanceId];
  if (!inst || inst.durability === undefined) return;
  inst.durability -= 1;
  if (inst.durability <= 0) {
    const cont = state.custody.containers[inst.containerId];
    if (cont) {
      const idx = cont.slots.indexOf(instanceId);
      if (idx !== -1) cont.slots[idx] = null;
    }
    delete state.custody.items[instanceId];
  }
}

function depleteSourceOnce(
  state: GameState,
  cursor: RngCursor,
  source: GameState['sources'][string],
  nowMs: number,
  intoDropOnly: boolean
): string[] {
  if (source.stock <= 0) return [];
  source.stock -= 1;
  source.hp = 0;
  source.depletedAtElapsedSec = state.clock.elapsedSimSec;

  const grantedSummary: string[] = [];
  for (const y of source.yieldTable) {
    if (nextFloat(cursor) <= y.chance) {
      const qty = nextInt(cursor, y.min, y.max);
      if (qty <= 0) continue;
      mintNewItemToContainerOrDrop(
        state,
        cursor,
        intoDropOnly ? '__drop_only__' : 'player_inv',
        y.defId,
        qty,
        `source:${source.id}`,
        { x: source.x, y: source.y }
      );
      const name = ITEMS_CATALOG[y.defId]?.name ?? y.defId;
      grantedSummary.push(`+${qty} ${name}`);
    }
  }

  if (grantedSummary.length > 0) {
    state.world.vfx.push({
      id: nextId(cursor, 'vfx'),
      kind: 'floating_text',
      x: source.x,
      y: source.y - 0.5,
      text: grantedSummary[0],
      color: source.kind === 'final72_cash_vault' ? '#ffd166' : '#a8e6cf',
      createdAtMs: nowMs,
      durationMs: 850,
    });
  }

  // Optional milestone recognition (C12 — works in any order, zero permission gates!)
  if (
    (source.kind === 'road_crate' || source.kind === 'oil_barrel') &&
    !state.knowledge.completedOptionalMilestones.includes('first_road_salvage')
  ) {
    state.knowledge.completedOptionalMilestones.push('first_road_salvage');
  }

  if (source.requiresDeepAccess && source.poiId) {
    recordUniqueScore(
      state,
      cursor,
      `poi_deep_${source.poiId}`,
      `Breached Deep Vault at ${source.poiId}`,
      balance.scoring.poiDeepClearScore
    );
  }

  return grantedSummary;
}

export function dispatch(intent: GameIntent, currentState: GameState): DispatchResult {
  // Check duplicate requestId idempotency across ALL state-mutating commands
  if ('requestId' in intent && intent.requestId && currentState.processedRequestIds.includes(intent.requestId)) {
    return reject(currentState, 'Duplicate requestId ignored (idempotent)');
  }

  if (intent.type === 'START_NEW_RUN') {
    const fresh = createNewRunGameState({
      gender: intent.gender,
      spawnRegionId: intent.spawnRegionId,
      nowUtcMs: intent.nowUtcMs,
      existingProfile: currentState.profile,
    });
    if (intent.requestId) fresh.processedRequestIds.push(intent.requestId);
    return { accepted: true, state: fresh, receipt: fresh.receipts[0] };
  }

  // Reject in-run actions once run has ended
  if (!currentState.run.active && intent.type !== 'QA_ADVANCE_TIME') {
    return reject(currentState, 'Run has already ended');
  }

  // Fast-path UI selection intents
  if (intent.type === 'SELECT_QUICKSLOT') {
    if (intent.slotIndex < 0 || intent.slotIndex > 7) return reject(currentState, 'Invalid quickslot');
    const next = structuredClone(currentState);
    next.custody.activeQuickSlot = intent.slotIndex;
    next.revision += 1;
    return { accepted: true, state: next };
  }

  if (intent.type === 'ADJUST_FICTIONAL_CLOCK') {
    const next = structuredClone(currentState);
    const len = balance.clock.fictionalDayLengthSeconds;
    next.clock.fictionalDaySec = (((next.clock.fictionalDaySec + intent.deltaSec) % len) + len) % len;
    next.revision += 1;
    return { accepted: true, state: next };
  }

  if (intent.type === 'CANCEL_WINDUP') {
    if (!currentState.actors.player.activeWindup || currentState.actors.player.activeWindup.committed) {
      return reject(currentState, 'No uncommitted windup to cancel');
    }
    const next = structuredClone(currentState);
    next.actors.player.activeWindup = null;
    const cursor: RngCursor = { rngState: next.rngState, nextIdCounter: next.nextIdCounter };
    return commit(next, cursor, 'CANCEL_WINDUP', `Canceled windup (${intent.reason}) — zero charge used`);
  }

  // Real-time simulation TICK
  if (intent.type === 'TICK') {
    const dt = Math.max(0.001, Math.min(0.1, intent.dtSec));
    const next = structuredClone(currentState);
    const cursor: RngCursor = { rngState: next.rngState, nextIdCounter: next.nextIdCounter };
    const player = next.actors.player;
    const map = getStaticIslandMap(next.world.seed);

    next.clock.elapsedSimSec += dt;
    next.clock.lastSettledUtcMs = intent.nowUtcMs;
    next.clock.fictionalDaySec =
      (next.clock.fictionalDaySec + dt * next.clock.fictionalTimeScale) %
      balance.clock.fictionalDayLengthSeconds;

    const hours = getElapsedRunHours(next);
    next.clock.phase = computeRunPhase(hours, next.run.active);
    awakenEldersIfDay14(next);

    if (hours >= balance.clock.maxRunRealHours) {
      finalizeRunOnce(next, cursor, 'EXPIRED_336H', intent.nowUtcMs);
      next.rngState = cursor.rngState;
      next.nextIdCounter = cursor.nextIdCounter;
      next.revision += 1;
      return { accepted: true, state: next };
    }

    // Expire completed visual effects
    if (next.world.vfx.length > 0) {
      next.world.vfx = next.world.vfx.filter((v) => intent.nowUtcMs - v.createdAtMs < v.durationMs);
    }

    // Player Aim, Windup Commit, Movement, Cart Freight & Footprint Trace Emission
    if (!player.dead) {
      player.facingRad = intent.aimRad;

      // Check active windup commit & recovery
      if (player.activeWindup) {
        if (!player.activeWindup.committed && intent.nowUtcMs >= player.activeWindup.commitAtMs) {
          commitWindupEffect(next, cursor, intent.nowUtcMs);
        }
        if (player.activeWindup && intent.nowUtcMs >= player.activeWindup.endAtMs) {
          player.activeWindup = null;
        }
      }

      // Movement & Freight Tradeoffs (K7, C13)
      const mag = Math.hypot(intent.moveX, intent.moveY);
      const isChannelingEvac = player.activeWindup?.kind === 'evac_channel';
      if (mag > 0.01 && isChannelingEvac) {
        // Moving cancels evacuation channel cleanly
        player.activeWindup = null;
      }

      const tx = Math.max(0, Math.min(map.width - 1, Math.floor(player.x)));
      const ty = Math.max(0, Math.min(map.height - 1, Math.floor(player.y)));
      let surf = map.surfaces[ty * map.width + tx];
      // Check if standing on player-built floor
      for (const ent of Object.values(next.entities)) {
        if (ent.hp > 0 && ent.tileX === tx && ent.tileY === ty) {
          if (ent.kind === 'wood_floor') surf = 'wood_floor';
          else if (ent.kind === 'stone_floor') surf = 'stone_floor';
        }
      }

      let surfMult = balance.movementAndFreight.grassSpeedMultiplier;
      if (surf === 'road' || surf === 'bridge' || surf === 'wood_floor' || surf === 'stone_floor') {
        surfMult = balance.movementAndFreight.roadSpeedMultiplier;
      } else if (surf === 'forest_floor') {
        surfMult = balance.movementAndFreight.forestSpeedMultiplier;
      } else if (surf === 'sand' || surf === 'scorch') {
        surfMult = balance.movementAndFreight.sandSpeedMultiplier;
      } else if (surf === 'snow') {
        surfMult = balance.movementAndFreight.snowSpeedMultiplier;
      } else if (surf === 'mud') {
        surfMult = balance.movementAndFreight.marshSpeedMultiplier;
      } else if (surf === 'shallow') {
        surfMult = balance.movementAndFreight.shallowWaterSpeedMultiplier;
      }

      // Carry weight + Hitched Cart physics
      const cart = player.hitchedCartEntityId ? next.entities[player.hitchedCartEntityId] : undefined;
      if (cart && (cart.hp <= 0 || Math.hypot(cart.x - player.x, cart.y - player.y) > 4.0)) {
        player.hitchedCartEntityId = null;
      }

      const playerWeight = computePlayerCarryWeightKg(next);
      const cartWeight = cart?.containerId ? computeContainerWeightKg(next, cart.containerId) : 0;
      const maxCap =
        balance.survival.baseCarryCapacityKg + (cart ? balance.movementAndFreight.cartExtraCapacityKg : 0);
      const totalLoad = playerWeight + cartWeight;

      let weightMult = 1.0;
      if (totalLoad > maxCap) {
        const overRatio = (totalLoad - maxCap) / maxCap;
        weightMult = Math.max(balance.survival.overweightSlowFloor, 1.0 - overRatio * 0.75);
      }

      let cartMult = 1.0;
      if (cart) {
        if (surf === 'road' || surf === 'bridge' || surf === 'stone_floor' || surf === 'wood_floor') {
          cartMult = balance.movementAndFreight.cartRoadSpeedMultiplier;
        } else if (surf === 'mud') {
          cartMult = balance.movementAndFreight.cartMarshSpeedMultiplier;
        } else {
          cartMult = balance.movementAndFreight.cartOffroadSpeedMultiplier;
        }
      }

      const speed = balance.movementAndFreight.baseWalkSpeedTilesPerSec * surfMult * weightMult * cartMult;
      const dirX = mag > 0.01 ? intent.moveX / mag : 0;
      const dirY = mag > 0.01 ? intent.moveY / mag : 0;

      // Apply knockback decay
      player.vx *= Math.max(0, 1 - balance.combat.knockbackDecay * dt);
      player.vy *= Math.max(0, 1 - balance.combat.knockbackDecay * dt);

      const stepX = (dirX * speed + player.vx) * dt;
      const stepY = (dirY * speed + player.vy) * dt;

      const candX = player.x + stepX;
      const candY = player.y + stepY;

      // Check collision radius 0.28 around player
      const canMoveX =
        !isTileBlockedForActor(map, next, Math.floor(candX + 0.26), Math.floor(player.y)).blocked &&
        !isTileBlockedForActor(map, next, Math.floor(candX - 0.26), Math.floor(player.y)).blocked;
      const canMoveY =
        !isTileBlockedForActor(map, next, Math.floor(player.x), Math.floor(candY + 0.26)).blocked &&
        !isTileBlockedForActor(map, next, Math.floor(player.x), Math.floor(candY - 0.26)).blocked;

      const prevX = player.x;
      const prevY = player.y;
      if (canMoveX) player.x = candX;
      if (canMoveY) player.y = candY;

      // Pull hitched Handcart behind player if terrain is cartPassable!
      if (cart && (player.x !== prevX || player.y !== prevY)) {
        const dCart = Math.hypot(player.x - cart.x, player.y - cart.y);
        if (dCart > 1.05) {
          const pullAng = Math.atan2(player.y - cart.y, player.x - cart.x);
          const ncx = player.x - Math.cos(pullAng) * 0.95;
          const ncy = player.y - Math.sin(pullAng) * 0.95;
          if (!isTileBlockedForActor(map, next, Math.floor(ncx), Math.floor(ncy), { isCart: true }).blocked) {
            cart.x = ncx;
            cart.y = ncy;
            cart.tileX = Math.floor(ncx);
            cart.tileY = Math.floor(ncy);
          } else {
            // Cart blocked by water/cliff: stop player pull smoothly
            player.x = prevX;
            player.y = prevY;
          }
        }
      }

      // Discover nearby POIs organically
      for (const poi of next.world.pois) {
        if (
          !next.knowledge.discoveredPois.includes(poi.id) &&
          Math.hypot(player.x - poi.x, player.y - poi.y) <= poi.radius + 3
        ) {
          next.knowledge.discoveredPois.push(poi.id);
        }
      }

      // Emit surface-specific decaying FootprintTrace breadcrumb chain! (K2+K5, C08)
      const movedFromLastFp = Math.hypot(
        player.x - player.lastFootprintPos.x,
        player.y - player.lastFootprintPos.y
      );
      if (movedFromLastFp >= balance.tracesAndWeather.footprintEmitIntervalTiles && surf !== 'shallow') {
        let durMult = 1.0;
        if (surf === 'mud') durMult = balance.tracesAndWeather.footprintMarshMultiplier;
        else if (surf === 'snow') durMult = balance.tracesAndWeather.footprintSnowMultiplier;
        else if (surf === 'road' || surf === 'bridge' || surf === 'stone_floor' || surf === 'wood_floor') {
          durMult = balance.tracesAndWeather.footprintRoadMultiplier;
        }
        const fpId = nextId(cursor, 'fp');
        const lifeSec = balance.tracesAndWeather.footprintBaseDurationSec * durMult;
        const fp: FootprintTrace = {
          id: fpId,
          x: player.x,
          y: player.y,
          surface: surf,
          createdAtSec: next.clock.elapsedSimSec,
          expiresAtSec: next.clock.elapsedSimSec + lifeSec,
          strength: 1.0,
          nextTraceId: null,
        };
        if (player.lastFootprintId) {
          const prevFp = next.world.footprints.find((f) => f.id === player.lastFootprintId);
          if (prevFp) prevFp.nextTraceId = fpId;
        }
        next.world.footprints.push(fp);
        if (next.world.footprints.length > 260) {
          next.world.footprints.shift();
        }
        player.lastFootprintPos = { x: player.x, y: player.y };
        player.lastFootprintId = fpId;
      }
    }

    advanceEnvironmentAndSources(next, cursor, dt);
    advanceStationsAndJobs(next, cursor, dt);
    advancePlayerSurvival(next, cursor, dt, false);
    advanceMonstersAndCombat(next, cursor, dt, intent.nowUtcMs);

    next.rngState = cursor.rngState;
    next.nextIdCounter = cursor.nextIdCounter;
    next.revision += 1;
    return { accepted: true, state: next };
  }

  // All discrete state-mutating commands operate on a clean deep clone for 100% atomic rollback safety
  const next = structuredClone(currentState);
  const cursor: RngCursor = { rngState: next.rngState, nextIdCounter: next.nextIdCounter };
  const player = next.actors.player;

  switch (intent.type) {
    case 'SETTLE_OFFLINE': {
      const deltaSec = Math.max(0, (intent.nowUtcMs - next.clock.lastSettledUtcMs) / 1000);
      if (deltaSec < 1) {
        next.clock.lastSettledUtcMs = intent.nowUtcMs;
        return { accepted: true, state: next };
      }
      settleChronologicalSeconds(next, cursor, deltaSec, intent.nowUtcMs);
      return commit(
        next,
        cursor,
        'SETTLE_OFFLINE',
        `Settled ${Math.round(deltaSec)}s of chronological offline time`,
        intent.requestId
      );
    }

    case 'QA_ADVANCE_TIME': {
      if (intent.hours <= 0 && !intent.forceWeather) return reject(currentState, 'Hours must be positive');
      next.clock.isQaAccelerated = true;
      const deltaSec = Math.max(0, intent.hours * 3600);
      next.clock.qaAcceleratedMs += deltaSec * 1000;
      if (intent.forceWeather) {
        next.clock.weather = intent.forceWeather;
        next.clock.weatherRemainingSec = balance.tracesAndWeather.weatherCycleBaseSec;
      }
      if (deltaSec > 0) {
        if (intent.preserveVitals) {
          const savedHp = player.hp;
          const savedFood = player.hunger;
          const savedWarmth = player.warmth;
          next.clock.elapsedSimSec = Math.min(
            balance.clock.maxRunRealHours * 3600 - 1,
            next.clock.elapsedSimSec + deltaSec
          );
          next.clock.lastSettledUtcMs += deltaSec * 1000;
          next.clock.phase = computeRunPhase(getElapsedRunHours(next), next.run.active);
          awakenEldersIfDay14(next);
          advanceEnvironmentAndSources(next, cursor, Math.min(deltaSec, 3600));
          advanceStationsAndJobs(next, cursor, Math.min(deltaSec, 3600));
          player.hp = savedHp;
          player.hunger = savedFood;
          player.warmth = savedWarmth;
        } else {
          settleChronologicalSeconds(next, cursor, deltaSec, next.clock.lastSettledUtcMs + deltaSec * 1000);
        }
      }
      return commit(
        next,
        cursor,
        'QA_ADVANCE_TIME',
        `[QA/UNVERIFIED] Advanced +${intent.hours.toFixed(1)}h${intent.forceWeather ? ` (${intent.forceWeather})` : ''}`,
        intent.requestId
      );
    }

    case 'PRIMARY_ACTION': {
      if (player.dead) return reject(currentState, 'Cannot act while dead');
      if (player.activeWindup || intent.nowMs < player.lastAttackCooldownUntilMs) {
        return reject(currentState, 'Action already in windup/recovery');
      }

      const activeItem = getActiveQuickbarItem(next);
      const def = activeItem ? ITEMS_CATALOG[activeItem.defId] : null;

      // If holding a consumable / blueprint in active hand, use it directly
      if (activeItem && def && (def.category === 'consumable' || def.category === 'blueprint')) {
        return dispatch({ type: 'USE_ITEM', instanceId: activeItem.id, requestId: intent.requestId }, currentState);
      }

      player.facingRad = intent.aimRad;

      if (activeItem && def?.category === 'core') {
        if ((activeItem.charges ?? 0) <= 0) return reject(currentState, 'Core has no charges remaining');
        if (player.stamina < (def.staminaCost ?? 10)) return reject(currentState, 'Not enough stamina');
        const windupMs = def.windupMs ?? 250;
        const cooldownMs = def.cooldownMs ?? 700;
        player.activeWindup = {
          kind: 'core',
          itemInstanceId: activeItem.id,
          defId: def.id,
          coreSkill: def.coreSkill,
          aimAngleRad: intent.aimRad,
          targetX: intent.targetWorldX,
          targetY: intent.targetWorldY,
          startedAtMs: intent.nowMs,
          commitAtMs: intent.nowMs + windupMs,
          endAtMs: intent.nowMs + cooldownMs,
          committed: false,
        };
        player.lastAttackCooldownUntilMs = intent.nowMs + cooldownMs;
        return commit(next, cursor, 'PRIMARY_ACTION', `Began ${def.name} windup`, intent.requestId);
      }

      if (activeItem && def?.projectileSpeed) {
        if (countItemInContainer(next, 'player_inv', 'wooden_arrow') < 1) {
          return reject(currentState, 'Requires Fletched Arrows in inventory');
        }
        const windupMs = def.windupMs ?? 170;
        const cooldownMs = def.cooldownMs ?? 500;
        player.activeWindup = {
          kind: 'projectile',
          itemInstanceId: activeItem.id,
          defId: def.id,
          aimAngleRad: intent.aimRad,
          targetX: intent.targetWorldX,
          targetY: intent.targetWorldY,
          startedAtMs: intent.nowMs,
          commitAtMs: intent.nowMs + windupMs,
          endAtMs: intent.nowMs + cooldownMs,
          committed: false,
        };
        player.lastAttackCooldownUntilMs = intent.nowMs + cooldownMs;
        return commit(next, cursor, 'PRIMARY_ACTION', `Drew ${def.name}`, intent.requestId);
      }

      // Melee tool / weapon / unarmed swing
      const windupMs = def?.windupMs ?? 90;
      const cooldownMs = def?.cooldownMs ?? balance.combat.unarmedCooldownMs;
      player.activeWindup = {
        kind: 'melee',
        itemInstanceId: activeItem?.id ?? null,
        defId: def?.id ?? 'unarmed',
        aimAngleRad: intent.aimRad,
        targetX: intent.targetWorldX,
        targetY: intent.targetWorldY,
        startedAtMs: intent.nowMs,
        commitAtMs: intent.nowMs + windupMs,
        endAtMs: intent.nowMs + cooldownMs,
        committed: false,
      };
      player.lastAttackCooldownUntilMs = intent.nowMs + cooldownMs;
      return commit(next, cursor, 'PRIMARY_ACTION', `Swung ${def?.name ?? 'Fist'}`, intent.requestId);
    }

    case 'INTERACT_NEAREST': {
      if (player.dead) return reject(currentState, 'Cannot interact while dead');

      // 1. Priority: Loot nearby World Drop or Death Bag within 2.3 tiles (C10)
      let bestDrop: StructureEntity | null = null;
      let bestDropDist = 2.35;
      for (const ent of Object.values(next.entities)) {
        if (ent.kind !== 'world_drop' && ent.kind !== 'death_bag') continue;
        const d = Math.hypot(ent.x - player.x, ent.y - player.y);
        if (d <= bestDropDist) {
          bestDropDist = d;
          bestDrop = ent;
        }
      }
      if (bestDrop && bestDrop.containerId) {
        const cont = next.custody.containers[bestDrop.containerId];
        let movedCount = 0;
        if (cont) {
          for (const slotId of [...cont.slots]) {
            if (!slotId) continue;
            const res = transferExistingInstance(next, cursor, slotId, 'player_inv');
            if (res.ok) movedCount++;
          }
        }
        if (movedCount === 0) return reject(currentState, 'Inventory is full');
        return commit(
          next,
          cursor,
          'INTERACT_LOOT_BAG',
          `Recovered ${movedCount} item stack(s) from ${bestDrop.kind === 'death_bag' ? 'Death Bag' : 'ground drop'}`,
          intent.requestId
        );
      }

      // 2. Check nearby unlocked/ready `loot_open` SourceNodes first (deferring sealed Final-72 vaults if an interactive entity like a Power Box is right here!)
      let bestOpenableNode: (typeof next.sources)[string] | null = null;
      let bestOpenableDist = 2.4;
      let sealedFinal72Nearby: (typeof next.sources)[string] | null = null;
      let lockedDeepNodeNearby: (typeof next.sources)[string] | null = null;

      for (const s of Object.values(next.sources)) {
        if (s.stock <= 0 || s.interactionMode !== 'loot_open') continue;
        const d = Math.hypot(s.x - player.x, s.y - player.y);
        if (d > 2.4) continue;
        if (s.requiresFinal72 && !isInFinal72Hours(next)) {
          sealedFinal72Nearby = s;
          continue;
        }
        if (s.requiresDeepAccess && s.poiId) {
          const gate = Object.values(next.entities).find(
            (e) => e.kind === 'poi_gate' && e.linkedPoiId === s.poiId
          );
          if (gate && !gate.open) {
            lockedDeepNodeNearby = s;
            continue;
          }
        }
        if (d <= bestOpenableDist) {
          bestOpenableDist = d;
          bestOpenableNode = s;
        }
      }

      if (bestOpenableNode) {
        const yields = depleteSourceOnce(next, cursor, bestOpenableNode, intent.nowMs, false);
        return commit(
          next,
          cursor,
          'LOOT_SOURCE',
          `Opened ${bestOpenableNode.kind}: ${yields.join(', ') || 'Empty'}`,
          intent.requestId
        );
      }

      // 3. Check nearby interactive Entities (Doors, POI Gates, Power Boxes, Beds, Carts, Evacuation Beacons)
      let bestEnt: StructureEntity | null = null;
      let bestEntDist = 2.5;
      for (const ent of Object.values(next.entities)) {
        if (ent.hp <= 0) continue;
        if (
          ent.kind === 'wood_door' ||
          ent.kind === 'reinforced_door' ||
          ent.kind === 'poi_gate' ||
          ent.kind === 'poi_power_box' ||
          ent.kind === 'bedroll' ||
          ent.kind === 'handcart' ||
          ent.kind === 'evac_beacon'
        ) {
          const d = Math.hypot(ent.x - player.x, ent.y - player.y);
          if (d <= bestEntDist) {
            bestEntDist = d;
            bestEnt = ent;
          }
        }
      }

      if (bestEnt) {
        if (bestEnt.kind === 'wood_door' || bestEnt.kind === 'reinforced_door') {
          bestEnt.open = !bestEnt.open;
          return commit(
            next,
            cursor,
            'TOGGLE_DOOR',
            `${bestEnt.open ? 'Opened' : 'Closed'} ${STRUCTURES_CATALOG[bestEnt.kind].name}`,
            intent.requestId
          );
        }
        if (bestEnt.kind === 'poi_power_box') {
          if (bestEnt.powered) return reject(currentState, 'Junction box is already energized');
          if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'copper_fuse', qty: 1 }])) {
            return reject(currentState, 'Requires Heavy Industrial Fuse (or hit with Arc-Lance Core)');
          }
          bestEnt.powered = true;
          for (const g of Object.values(next.entities)) {
            if (g.kind === 'poi_gate' && g.linkedPoiId === bestEnt.linkedPoiId) {
              g.powered = true;
              g.open = true;
            }
          }
          return commit(
            next,
            cursor,
            'POWER_POI_GATE',
            'Installed Heavy Industrial Fuse — Inner vault gate energized and opened!',
            intent.requestId
          );
        }
        if (bestEnt.kind === 'poi_gate') {
          if (bestEnt.open) return reject(currentState, 'Vault gate is already open');
          if (bestEnt.requiredKeyDefId === 'copper_fuse' && !bestEnt.powered) {
            return reject(currentState, 'Power the exterior Junction Box with a Heavy Industrial Fuse first');
          }
          if (bestEnt.requiredKeyDefId === 'blue_keycard') {
            if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'blue_keycard', qty: 1 }])) {
              return reject(currentState, 'Requires Relay Security Passcard in inventory');
            }
          }
          bestEnt.open = true;
          return commit(next, cursor, 'UNLOCK_POI_GATE', 'Unlocked POI Inner Vault Gate!', intent.requestId);
        }
        if (bestEnt.kind === 'bedroll') {
          player.boundBedEntityId = bestEnt.id;
          return commit(next, cursor, 'BIND_BED', 'Bound Homestead Bunk Bed as same-run respawn point', intent.requestId);
        }
        if (bestEnt.kind === 'handcart') {
          player.hitchedCartEntityId = player.hitchedCartEntityId === bestEnt.id ? null : bestEnt.id;
          return commit(
            next,
            cursor,
            'TOGGLE_CART_HITCH',
            player.hitchedCartEntityId ? 'Hitched Freight Handcart' : 'Unhitched Freight Handcart',
            intent.requestId
          );
        }
        if (bestEnt.kind === 'evac_beacon') {
          return dispatch(
            { type: 'BEGIN_EVACUATION', beaconEntityId: bestEnt.id, nowMs: intent.nowMs, requestId: intent.requestId },
            currentState
          );
        }
      }

      if (sealedFinal72Nearby) {
        return reject(
          currentState,
          `Ragnarok Vault is time-locked until Final 72h (Hour ${balance.clock.ragnarokStartHour}+)`
        );
      }
      if (lockedDeepNodeNearby) {
        return reject(currentState, 'Unlock or power the POI security gate first');
      }

      return reject(currentState, 'Nothing nearby to interact with');
    }

    case 'TOGGLE_DOOR_OR_GATE': {
      const ent = next.entities[intent.entityId];
      if (!ent || Math.hypot(ent.x - player.x, ent.y - player.y) > 3.2) {
        return reject(currentState, 'Door/gate out of reach');
      }
      if (ent.kind === 'wood_door' || ent.kind === 'reinforced_door') {
        ent.open = !ent.open;
        return commit(next, cursor, 'TOGGLE_DOOR', `${ent.open ? 'Opened' : 'Closed'} door`, intent.requestId);
      }
      if (ent.kind === 'poi_gate') {
        if (ent.open) return reject(currentState, 'Gate already open');
        if (ent.requiredKeyDefId === 'blue_keycard') {
          if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'blue_keycard', qty: 1 }])) {
            return reject(currentState, 'Requires Relay Security Passcard');
          }
          ent.open = true;
          return commit(next, cursor, 'UNLOCK_POI_GATE', 'Unlocked POI Vault Gate', intent.requestId);
        }
        return reject(currentState, 'Power exterior junction box first');
      }
      return reject(currentState, 'Target is not a door or gate');
    }

    case 'TOGGLE_CART_HITCH': {
      const cart = next.entities[intent.cartEntityId];
      if (!cart || cart.kind !== 'handcart' || Math.hypot(cart.x - player.x, cart.y - player.y) > 3.2) {
        return reject(currentState, 'Handcart out of reach');
      }
      player.hitchedCartEntityId = player.hitchedCartEntityId === cart.id ? null : cart.id;
      return commit(
        next,
        cursor,
        'TOGGLE_CART_HITCH',
        player.hitchedCartEntityId ? 'Hitched Handcart' : 'Unhitched Handcart',
        intent.requestId
      );
    }

    case 'USE_ITEM': {
      if (player.dead) return reject(currentState, 'Cannot use items while dead');
      const inst = next.custody.items[intent.instanceId];
      if (!inst || inst.containerId !== 'player_inv') {
        return reject(currentState, 'Item must be in your backpack');
      }
      const def = ITEMS_CATALOG[inst.defId];
      if (!def) return reject(currentState, 'Unknown item');

      if (def.category === 'armor') {
        return dispatch({ type: 'EQUIP_ITEM', instanceId: inst.id, requestId: intent.requestId }, currentState);
      }

      if (def.category === 'blueprint' && def.unlocksRecipeId) {
        const toUnlock = [def.unlocksRecipeId];
        if (def.id === 'bp_iron_tools') toUnlock.push('craft_iron_pickaxe');
        const newOnes = toUnlock.filter((r) => !next.knowledge.unlockedRecipes.includes(r));
        if (newOnes.length === 0) {
          return reject(currentState, 'Recipe already unlocked in this run');
        }
        next.knowledge.unlockedRecipes.push(...newOnes);
        inst.qty -= 1;
        if (inst.qty <= 0) {
          const inv = next.custody.containers['player_inv'];
          const sIdx = inv.slots.indexOf(inst.id);
          if (sIdx !== -1) inv.slots[sIdx] = null;
          delete next.custody.items[inst.id];
        }
        return commit(
          next,
          cursor,
          'LEARN_BLUEPRINT',
          `Learned run recipe: ${newOnes.map((r) => RECIPES_CATALOG[r]?.name ?? r).join(', ')}`,
          intent.requestId
        );
      }

      if (def.category === 'consumable') {
        if (def.healHp) player.hp = Math.min(player.maxHp, player.hp + def.healHp);
        if (def.restoreHunger) player.hunger = Math.min(player.maxHunger, player.hunger + def.restoreHunger);
        if (def.restoreWarmth) player.warmth = Math.min(player.maxWarmth, player.warmth + def.restoreWarmth);
        if (def.restoreStamina) player.stamina = Math.min(player.maxStamina, player.stamina + def.restoreStamina);
        if (def.cureToxicSec) player.toxicShieldSec = Math.max(player.toxicShieldSec, def.cureToxicSec);

        inst.qty -= 1;
        if (inst.qty <= 0) {
          const inv = next.custody.containers['player_inv'];
          const sIdx = inv.slots.indexOf(inst.id);
          if (sIdx !== -1) inv.slots[sIdx] = null;
          delete next.custody.items[inst.id];
        }
        return commit(next, cursor, 'USE_CONSUMABLE', `Used ${def.name}`, intent.requestId);
      }

      return reject(currentState, `${def.name} cannot be consumed directly`);
    }

    case 'EQUIP_ITEM': {
      const inst = next.custody.items[intent.instanceId];
      if (!inst || inst.containerId !== 'player_inv') return reject(currentState, 'Item must be in inventory');
      const def = ITEMS_CATALOG[inst.defId];
      if (!def || !def.equipSlot) return reject(currentState, 'Item is not wearable armor');

      const inv = next.custody.containers['player_inv'];
      const slotIdx = inv.slots.indexOf(inst.id);
      if (slotIdx === -1) return reject(currentState, 'Slot mismatch');

      const prevEquippedId = def.equipSlot === 'head' ? next.custody.equippedHeadId : next.custody.equippedBodyId;
      inv.slots[slotIdx] = prevEquippedId;
      if (prevEquippedId && next.custody.items[prevEquippedId]) {
        next.custody.items[prevEquippedId].containerId = 'player_inv';
      }
      inst.containerId = `equip:${def.equipSlot}`;
      if (def.equipSlot === 'head') next.custody.equippedHeadId = inst.id;
      else next.custody.equippedBodyId = inst.id;

      return commit(next, cursor, 'EQUIP_ITEM', `Equipped ${def.name}`, intent.requestId);
    }

    case 'UNEQUIP_SLOT': {
      const eqId = intent.slot === 'head' ? next.custody.equippedHeadId : next.custody.equippedBodyId;
      if (!eqId || !next.custody.items[eqId]) return reject(currentState, 'Nothing equipped in slot');
      const inv = next.custody.containers['player_inv'];
      const emptyIdx = inv.slots.findIndex((s) => s === null);
      if (emptyIdx === -1) return reject(currentState, 'Inventory is full');

      inv.slots[emptyIdx] = eqId;
      next.custody.items[eqId].containerId = 'player_inv';
      if (intent.slot === 'head') next.custody.equippedHeadId = null;
      else next.custody.equippedBodyId = null;
      return commit(next, cursor, 'UNEQUIP_SLOT', `Unequipped ${intent.slot}`, intent.requestId);
    }

    case 'TRANSFER_ITEM': {
      const inst = next.custody.items[intent.instanceId];
      if (!inst) return reject(currentState, 'Item instance not found');
      const fromCont = next.custody.containers[inst.containerId];
      const toCont = next.custody.containers[intent.toContainerId];
      if (!fromCont || !toCont) return reject(currentState, 'Container missing');

      // Physical proximity check for non-player containers (no remote item teleportation! K1/K7, C07)
      for (const c of [fromCont, toCont]) {
        if (c.ownerEntityId) {
          const ent = next.entities[c.ownerEntityId];
          if (!ent || Math.hypot(ent.x - player.x, ent.y - player.y) > 4.2) {
            return reject(currentState, 'Must stand near container/cart/station to transfer items');
          }
        }
      }

      const res = transferExistingInstance(
        next,
        cursor,
        intent.instanceId,
        intent.toContainerId,
        intent.toSlotIndex,
        intent.splitQty
      );
      if (!res.ok) return reject(currentState, res.reason ?? 'Transfer failed');
      return commit(next, cursor, 'TRANSFER_ITEM', `Transferred ${ITEMS_CATALOG[inst.defId]?.name ?? inst.defId}`, intent.requestId);
    }

    case 'DROP_ITEM': {
      const inst = next.custody.items[intent.instanceId];
      if (!inst || inst.containerId !== 'player_inv') return reject(currentState, 'Item not in backpack');
      const inv = next.custody.containers['player_inv'];
      const idx = inv.slots.indexOf(inst.id);
      if (idx === -1) return reject(currentState, 'Item slot missing');

      const dropQty = intent.qty && intent.qty > 0 && intent.qty < inst.qty ? Math.floor(intent.qty) : inst.qty;
      let droppedInstId = inst.id;
      if (dropQty < inst.qty) {
        inst.qty -= dropQty;
        droppedInstId = nextId(cursor, 'itm');
        next.custody.items[droppedInstId] = {
          ...inst,
          id: droppedInstId,
          qty: dropQty,
        };
      } else {
        inv.slots[idx] = null;
      }

      const entId = nextId(cursor, 'drop');
      const contId = `drop:${entId}`;
      const cont = createContainer(contId, 'drop', 4, entId);
      cont.slots[0] = droppedInstId;
      next.custody.items[droppedInstId].containerId = contId;
      next.custody.containers[contId] = cont;
      next.entities[entId] = {
        id: entId,
        kind: 'world_drop',
        tileX: Math.floor(player.x),
        tileY: Math.floor(player.y),
        x: player.x + Math.cos(player.facingRad) * 0.45,
        y: player.y + Math.sin(player.facingRad) * 0.45,
        hp: 100,
        maxHp: 100,
        owner: 'world',
        containerId: contId,
        createdAtSec: next.clock.elapsedSimSec,
        provenance: 'player_drop',
      };

      return commit(
        next,
        cursor,
        'DROP_ITEM',
        `Dropped ${dropQty}x ${ITEMS_CATALOG[inst.defId]?.name ?? inst.defId}`,
        intent.requestId
      );
    }

    case 'CRAFT_RECIPE': {
      if (player.dead) return reject(currentState, 'Cannot craft while dead');
      const recipe = RECIPES_CATALOG[intent.recipeId];
      if (!recipe) return reject(currentState, 'Unknown recipe');
      if (!next.knowledge.unlockedRecipes.includes(recipe.id)) {
        return reject(currentState, 'Recipe not unlocked in this run');
      }
      if (recipe.workSeconds > 0) {
        return reject(currentState, 'Timed recipes must run as physical jobs inside their station');
      }

      if (recipe.station === 'workbench') {
        const nearBench = Object.values(next.entities).some(
          (e) => e.hp > 0 && e.kind === 'workbench' && Math.hypot(e.x - player.x, e.y - player.y) <= 4.0
        );
        if (!nearBench) return reject(currentState, 'Must stand near an Artisan Workbench');
      }

      const count = Math.max(1, Math.floor(intent.qty ?? 1));
      const totalInputs = recipe.inputs.map((i) => ({ defId: i.defId, qty: i.qty * count }));
      if (!hasItemsInContainer(next, 'player_inv', totalInputs)) {
        return reject(currentState, 'Insufficient crafting materials in backpack');
      }

      debitItemsFromContainer(next, 'player_inv', totalInputs);
      mintNewItemToContainerOrDrop(
        next,
        cursor,
        'player_inv',
        recipe.output.defId,
        recipe.output.qty * count,
        `craft:${recipe.id}`,
        { x: player.x, y: player.y }
      );

      if (!next.knowledge.completedOptionalMilestones.includes('first_tool_crafted')) {
        next.knowledge.completedOptionalMilestones.push('first_tool_crafted');
      }

      return commit(
        next,
        cursor,
        'CRAFT_RECIPE',
        `Crafted ${recipe.output.qty * count}x ${ITEMS_CATALOG[recipe.output.defId]?.name ?? recipe.name}`,
        intent.requestId
      );
    }

    case 'START_STATION_JOB': {
      const station = next.entities[intent.stationEntityId];
      if (!station || station.hp <= 0 || Math.hypot(station.x - player.x, station.y - player.y) > 4.2) {
        return reject(currentState, 'Station out of reach');
      }
      const recipe = RECIPES_CATALOG[intent.recipeId];
      if (!recipe || recipe.workSeconds <= 0) return reject(currentState, 'Invalid timed station recipe');
      if (!next.knowledge.unlockedRecipes.includes(recipe.id)) {
        return reject(currentState, 'Recipe not unlocked in this run');
      }
      const stDef = STRUCTURES_CATALOG[station.kind];
      if (stDef?.stationTag !== recipe.station) {
        return reject(currentState, `Recipe requires ${recipe.station}`);
      }
      if (!station.containerId || !hasItemsInContainer(next, station.containerId, recipe.inputs)) {
        return reject(currentState, 'Place required raw inputs into the station Input slot first');
      }

      // Compute max batches from station input container
      let maxBatches = 99;
      for (const req of recipe.inputs) {
        const have = countItemInContainer(next, station.containerId, req.defId);
        maxBatches = Math.min(maxBatches, Math.floor(have / req.qty));
      }
      if (maxBatches <= 0) return reject(currentState, 'Insufficient input materials in station');

      // Remove any existing job on this station
      for (const j of Object.values(next.jobs)) {
        if (j.stationEntityId === station.id) delete next.jobs[j.id];
      }

      const jobId = nextId(cursor, 'job');
      next.jobs[jobId] = {
        id: jobId,
        stationEntityId: station.id,
        recipeId: recipe.id,
        progressSec: 0,
        durationSec: recipe.workSeconds,
        status: 'RUNNING',
        batchesRemaining: maxBatches,
      };
      // Trigger immediate 0.01s check to pull initial fuel/water status truthfully
      advanceStationsAndJobs(next, cursor, 0.01);

      return commit(
        next,
        cursor,
        'START_STATION_JOB',
        `Started ${recipe.name} (${maxBatches} batch${maxBatches > 1 ? 'es' : ''}) at ${stDef?.name ?? station.kind}`,
        intent.requestId
      );
    }

    case 'RESEARCH_UNLOCK': {
      // Single run-local recipe authority K4 (C04!)
      const bench = next.entities[intent.stationEntityId];
      if (!bench || bench.hp <= 0 || bench.kind !== 'research_table' || Math.hypot(bench.x - player.x, bench.y - player.y) > 4.2) {
        return reject(currentState, 'Must stand near an intact Drawing & Research Table');
      }

      if (intent.mode === 'specimen') {
        if (!intent.specimenInstanceId) return reject(currentState, 'Select a physical specimen to study');
        const inst = next.custody.items[intent.specimenInstanceId];
        if (!inst || inst.containerId !== 'player_inv') {
          return reject(currentState, 'Specimen must be in your backpack');
        }
        const def = ITEMS_CATALOG[inst.defId];
        const recipeId = def?.studyRecipeId;
        if (!recipeId || !RECIPES_CATALOG[recipeId]) {
          return reject(currentState, 'This item has no studyable crafting schematic');
        }
        if (next.knowledge.unlockedRecipes.includes(recipeId)) {
          return reject(currentState, 'Recipe is already unlocked in this run');
        }
        const studySpares = 6;
        if (!hasItemsInContainer(next, 'player_inv', [{ defId: 'spares', qty: studySpares }])) {
          return reject(currentState, `Specimen study requires ${studySpares} Mechanical Spares`);
        }

        // Consume 1 specimen + study Spares atomically once
        debitItemsFromContainer(next, 'player_inv', [{ defId: 'spares', qty: studySpares }]);
        inst.qty -= 1;
        if (inst.qty <= 0) {
          const inv = next.custody.containers['player_inv'];
          const sIdx = inv.slots.indexOf(inst.id);
          if (sIdx !== -1) inv.slots[sIdx] = null;
          delete next.custody.items[inst.id];
        }
        next.knowledge.unlockedRecipes.push(recipeId);
        if (!next.knowledge.studiedSpecimens.includes(def.id)) {
          next.knowledge.studiedSpecimens.push(def.id);
        }
        return commit(
          next,
          cursor,
          'RESEARCH_SPECIMEN',
          `Studied ${def.name} -> Unlocked ${RECIPES_CATALOG[recipeId].name}`,
          intent.requestId
        );
      }

      if (intent.mode === 'directed') {
        const rId = intent.targetRecipeId;
        const recipe = rId ? RECIPES_CATALOG[rId] : undefined;
        if (!recipe || recipe.baselineUnlocked) return reject(currentState, 'Invalid research target');
        if (next.knowledge.unlockedRecipes.includes(recipe.id)) {
          return reject(currentState, 'Recipe already unlocked in this run');
        }
        const cost =
          recipe.directedSparesCost ??
          Math.round(
            (recipe.researchTier === 2
              ? balance.workAndResearch.randomResearchTier2Spares
              : balance.workAndResearch.randomResearchTier1Spares) *
              balance.workAndResearch.directedResearchSparesMultiplier
          );
        if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'spares', qty: cost }])) {
          return reject(currentState, `Requires ${cost} Mechanical Spares`);
        }
        next.knowledge.unlockedRecipes.push(recipe.id);
        return commit(
          next,
          cursor,
          'RESEARCH_DIRECTED',
          `Researched ${recipe.name} (-${cost} Spares)`,
          intent.requestId
        );
      }

      // Random Tier 1 or Tier 2 Spares Discovery
      const tier = intent.mode === 'random_t2' ? 2 : 1;
      const pool = Object.values(RECIPES_CATALOG).filter(
        (r) => !r.baselineUnlocked && r.researchTier === tier && !next.knowledge.unlockedRecipes.includes(r.id)
      );
      if (pool.length === 0) {
        return reject(currentState, `All Tier ${tier} schematics are already unlocked in this run`);
      }
      const cost =
        tier === 2
          ? balance.workAndResearch.randomResearchTier2Spares
          : balance.workAndResearch.randomResearchTier1Spares;
      if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'spares', qty: cost }])) {
        return reject(currentState, `Requires ${cost} Mechanical Spares`);
      }
      const chosen = pool[nextInt(cursor, 0, pool.length - 1)];
      next.knowledge.unlockedRecipes.push(chosen.id);
      return commit(
        next,
        cursor,
        'RESEARCH_RANDOM',
        `Discovered Tier ${tier} Schematic: ${chosen.name} (-${cost} Spares)`,
        intent.requestId
      );
    }

    case 'BUILD_STRUCTURE': {
      if (player.dead) return reject(currentState, 'Cannot build while dead');
      const def = STRUCTURES_CATALOG[intent.structureKind];
      if (!def) return reject(currentState, 'Unknown structure');

      const check = canBuildAtTile(next, intent.structureKind, intent.tileX, intent.tileY);
      if (!check.ok) return reject(currentState, check.reason ?? 'Invalid placement');

      if (!hasItemsInContainer(next, 'player_inv', def.buildCost)) {
        return reject(currentState, 'Insufficient building materials in backpack');
      }

      // Atomic debit & placement receipt (C07!)
      debitItemsFromContainer(next, 'player_inv', def.buildCost);

      const entId = nextId(cursor, 'str');
      const entity: StructureEntity = {
        id: entId,
        kind: intent.structureKind,
        tileX: intent.tileX,
        tileY: intent.tileY,
        x: intent.tileX + 0.5,
        y: intent.tileY + 0.5,
        hp: def.maxHp,
        maxHp: def.maxHp,
        owner: 'player',
        open: def.isDoor ? false : undefined,
        powered: false,
        fuelRemainingSec: 0,
        waterStored: 0,
        createdAtSec: next.clock.elapsedSimSec,
        provenance: 'player_built',
      };

      // Attach physical containers for chests, carts, furnaces, campfires, planters, collectors, generators
      if (def.id === 'storage_chest' || def.id === 'handcart') {
        const cId = `${def.id === 'handcart' ? 'cart' : 'chest'}:${entId}`;
        next.custody.containers[cId] = createContainer(
          cId,
          def.id === 'handcart' ? 'cart' : 'chest',
          def.storageSlots ?? 12,
          entId
        );
        entity.containerId = cId;
      } else if (def.stationTag === 'furnace' || def.stationTag === 'campfire' || def.stationTag === 'planter') {
        const inId = `stin:${entId}`;
        const fuelId = `stfuel:${entId}`;
        const outId = `stout:${entId}`;
        next.custody.containers[inId] = createContainer(inId, 'station_in', 3, entId);
        next.custody.containers[fuelId] = createContainer(fuelId, 'station_fuel', 2, entId);
        next.custody.containers[outId] = createContainer(outId, 'station_out', 3, entId);
        entity.containerId = inId;
        entity.fuelContainerId = fuelId;
        entity.outputContainerId = outId;
      } else if (def.stationTag === 'collector') {
        const outId = `stout:${entId}`;
        next.custody.containers[outId] = createContainer(outId, 'station_out', def.storageSlots ?? 4, entId);
        entity.outputContainerId = outId;
      } else if (def.stationTag === 'generator') {
        const fuelId = `stfuel:${entId}`;
        next.custody.containers[fuelId] = createContainer(fuelId, 'station_fuel', def.storageSlots ?? 3, entId);
        entity.fuelContainerId = fuelId;
      }

      next.entities[entId] = entity;

      // Establish Homestead Land Claim on Homestead Stake or first Foundation if none exists (PROPOSED_MECHANISM)
      if (
        def.id === 'homestead_stake' ||
        (balance.landAndEscrow.autoClaimOnFirstFoundation &&
          def.isFloor &&
          next.world.homesteads.length === 0)
      ) {
        next.world.homesteads.push({
          id: nextId(cursor, 'clm'),
          stakeEntityId: def.id === 'homestead_stake' ? entId : null,
          centerX: entity.x,
          centerY: entity.y,
          radiusTiles: balance.landAndEscrow.homesteadClaimRadiusTiles,
        });
      }

      if (def.id === 'bedroll') {
        player.boundBedEntityId = entId;
      }

      return commit(
        next,
        cursor,
        'BUILD_STRUCTURE',
        `Placed ${def.name} at (${intent.tileX}, ${intent.tileY})`,
        intent.requestId
      );
    }

    case 'RECLAIM_STRUCTURE': {
      const ent = next.entities[intent.entityId];
      if (!ent || ent.owner !== 'player' || ent.hp <= 0) {
        return reject(currentState, 'Cannot reclaim this object');
      }
      if (Math.hypot(ent.x - player.x, ent.y - player.y) > 4.5) {
        return reject(currentState, 'Move closer to reclaim structure');
      }
      const def = STRUCTURES_CATALOG[ent.kind];
      if (!def || !def.reclaimable) return reject(currentState, 'Structure cannot be reclaimed');

      // Conserve 100% of held items across all attached containers (transfer exact ItemInstance IDs to player_inv, overflow to world_drop — ZERO duplication or loss! C07)
      const overflowIds: string[] = [];
      for (const cId of [ent.containerId, ent.fuelContainerId, ent.outputContainerId]) {
        if (!cId) continue;
        const cont = next.custody.containers[cId];
        if (!cont) continue;
        for (let i = 0; i < cont.slots.length; i++) {
          const itemId = cont.slots[i];
          if (!itemId) continue;
          const res = transferExistingInstance(next, cursor, itemId, 'player_inv');
          if (!res.ok) {
            overflowIds.push(itemId);
            cont.slots[i] = null;
          }
        }
        delete next.custody.containers[cId];
      }

      if (overflowIds.length > 0) {
        const dropEntId = nextId(cursor, 'drop');
        const dropContId = `drop:${dropEntId}`;
        const dropCont = createContainer(dropContId, 'drop', overflowIds.length, dropEntId);
        for (let i = 0; i < overflowIds.length; i++) {
          next.custody.items[overflowIds[i]].containerId = dropContId;
          dropCont.slots[i] = overflowIds[i];
        }
        next.custody.containers[dropContId] = dropCont;
        next.entities[dropEntId] = {
          id: dropEntId,
          kind: 'world_drop',
          tileX: ent.tileX,
          tileY: ent.tileY,
          x: ent.x,
          y: ent.y,
          hp: 100,
          maxHp: 100,
          owner: 'world',
          containerId: dropContId,
          createdAtSec: next.clock.elapsedSimSec,
          provenance: `reclaim_contents:${ent.id}`,
        };
      }

      // Refund deployable kit 1:1, or 50% (ceil) of raw building materials
      if (def.deployItemId) {
        mintNewItemToContainerOrDrop(next, cursor, 'player_inv', def.deployItemId, 1, `reclaim:${ent.id}`, {
          x: ent.x,
          y: ent.y,
        });
      } else {
        const hpRatio = Math.max(0.25, ent.hp / def.maxHp);
        for (const cost of def.buildCost) {
          const refund = Math.max(1, Math.floor(cost.qty * 0.5 * hpRatio));
          mintNewItemToContainerOrDrop(next, cursor, 'player_inv', cost.defId, refund, `reclaim:${ent.id}`, {
            x: ent.x,
            y: ent.y,
          });
        }
      }

      if (player.boundBedEntityId === ent.id) player.boundBedEntityId = null;
      if (player.hitchedCartEntityId === ent.id) player.hitchedCartEntityId = null;
      for (const j of Object.values(next.jobs)) {
        if (j.stationEntityId === ent.id) delete next.jobs[j.id];
      }
      if (ent.kind === 'homestead_stake') {
        next.world.homesteads = next.world.homesteads.filter((h) => h.stakeEntityId !== ent.id);
      }
      delete next.entities[ent.id];

      return commit(next, cursor, 'RECLAIM_STRUCTURE', `Reclaimed ${def.name}`, intent.requestId);
    }

    case 'REPAIR_STRUCTURE': {
      const ent = next.entities[intent.entityId];
      if (!ent || ent.owner !== 'player' || ent.hp >= ent.maxHp) {
        return reject(currentState, 'Structure does not need repair');
      }
      if (Math.hypot(ent.x - player.x, ent.y - player.y) > 4.2) {
        return reject(currentState, 'Too far to repair');
      }
      const def = STRUCTURES_CATALOG[ent.kind];
      const primaryMat = def?.buildCost[0]?.defId ?? 'wood_log';
      if (primaryMat === 'escrow_chest_kit' || primaryMat === 'handcart_kit') {
        if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'wood_log', qty: 2 }])) {
          return reject(currentState, 'Requires 2 Timber Logs to repair');
        }
      } else {
        if (!debitItemsFromContainer(next, 'player_inv', [{ defId: primaryMat, qty: 1 }])) {
          return reject(currentState, `Requires 1 ${ITEMS_CATALOG[primaryMat]?.name ?? primaryMat} to repair`);
        }
      }
      ent.hp = ent.maxHp;
      return commit(next, cursor, 'REPAIR_STRUCTURE', `Repaired ${def?.name ?? ent.kind}`, intent.requestId);
    }

    case 'RESPAWN_AFTER_DEATH': {
      if (!player.dead) return reject(currentState, 'Player is alive');
      let rx = player.x;
      let ry = player.y;

      const bed = player.boundBedEntityId ? next.entities[player.boundBedEntityId] : undefined;
      if (intent.useBed && bed && bed.hp > 0) {
        rx = bed.x;
        ry = bed.y;
      } else {
        const sp =
          next.world.spawnRegions.find((s) => s.id === player.spawnRegionId) ?? next.world.spawnRegions[0];
        rx = sp.x + 0.5;
        ry = sp.y + 0.5;
      }

      player.x = rx;
      player.y = ry;
      player.vx = 0;
      player.vy = 0;
      player.hp = Math.round(player.maxHp * 0.75);
      player.hunger = Math.max(45, player.hunger);
      player.warmth = Math.max(60, player.warmth);
      player.stamina = player.maxStamina;
      player.dead = false;
      player.lastFootprintPos = { x: rx, y: ry };
      player.lastFootprintId = null;

      // Grant a humble spare Flint Knife on empty-handed respawn so player is never helpless on corpse run
      mintNewItemToContainerOrDrop(next, cursor, 'player_inv', 'flint_knife', 1, 'respawn_knife');

      return commit(
        next,
        cursor,
        'RESPAWN_SAME_RUN',
        `Respawned within same run at ${intent.useBed && bed ? 'Homestead Bed' : 'Coastal Spawn'} — Death Bag awaits recovery`,
        intent.requestId
      );
    }

    case 'BUY_ESCROW_CHEST_PHYSICAL': {
      // C16: Purchase Rương ký gửi with physical unsecured Ragnarok Cash from physical vendor!
      const vendor = next.entities[intent.vendorEntityId];
      if (!vendor || vendor.kind !== 'vendor_escrow_broker' || Math.hypot(vendor.x - player.x, vendor.y - player.y) > 4.0) {
        return reject(currentState, 'Must stand at the Crossroads Ragnarok Escrow Broker');
      }
      if (next.world.vendorStocks.escrowBrokerKits <= 0) {
        return reject(currentState, 'Broker has no more Rương ký gửi in stock this run');
      }
      const price = balance.landAndEscrow.escrowChestVendorPricePhysicalCash;
      if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'ragnarok_cash', qty: price }])) {
        return reject(currentState, `Requires ${price} physical Ragnarok Cash in your backpack`);
      }
      next.world.vendorStocks.escrowBrokerKits -= 1;
      mintNewItemToContainerOrDrop(
        next,
        cursor,
        'player_inv',
        'escrow_chest_kit',
        1,
        `vendor_escrow:${vendor.id}`,
        { x: player.x, y: player.y }
      );
      return commit(
        next,
        cursor,
        'BUY_ESCROW_CHEST',
        `Purchased physical Rương ký gửi (-${price} physical Ragnarok Cash)`,
        intent.requestId
      );
    }

    case 'DEPOSIT_RAGNAROK_CASH': {
      // C17: Atomic physical cash debit -> profile securedCash credit at an owned home Rương ký gửi!
      const chest = next.entities[intent.escrowEntityId];
      if (!chest || chest.kind !== 'escrow_chest' || chest.owner !== 'player' || chest.hp <= 0) {
        return reject(currentState, 'Valid Rương ký gửi not found');
      }
      if (Math.hypot(chest.x - player.x, chest.y - player.y) > 4.0) {
        return reject(currentState, 'Must stand beside your Rương ký gửi to deposit');
      }
      if (!isTileOnOwnedLand(next, chest.tileX, chest.tileY)) {
        return reject(currentState, 'Rương ký gửi must stand on genuinely owned Homestead land');
      }

      const heldCash = countItemInContainer(next, 'player_inv', 'ragnarok_cash');
      if (heldCash <= 0) {
        return reject(currentState, 'No physical Ragnarok Cash in your backpack to deposit');
      }
      const depositAmt =
        intent.amount && intent.amount > 0 ? Math.min(heldCash, Math.floor(intent.amount)) : heldCash;
      if (depositAmt <= 0) return reject(currentState, 'Deposit amount must be positive');

      if (!debitItemsFromContainer(next, 'player_inv', [{ defId: 'ragnarok_cash', qty: depositAmt }])) {
        return reject(currentState, 'Failed to debit physical Ragnarok Cash');
      }

      next.profile.securedCash += depositAmt;
      next.run.cashDepositedThisRun += depositAmt;

      recordUniqueScore(
        next,
        cursor,
        'first_escrow_deposit',
        'Secured Ragnarok Cash via Owned Homestead Escrow',
        balance.scoring.firstEscrowDepositScore
      );

      next.world.vfx.push({
        id: nextId(cursor, 'vfx'),
        kind: 'deposit_gleam',
        x: chest.x,
        y: chest.y,
        createdAtMs: Date.now(),
        durationMs: 650,
      });

      return commit(
        next,
        cursor,
        'DEPOSIT_RAGNAROK_CASH',
        `Atomically deposited +${depositAmt} Ragnarok Cash into Profile (Secured Wallet: ${next.profile.securedCash})`,
        intent.requestId
      );
    }

    case 'BUY_SEASON_VENDOR_ITEM': {
      // C18: Spend Profile Secured Cash at physical vendor for finite stocked RUN-LOCAL items!
      const vendor = next.entities[intent.vendorEntityId];
      if (!vendor || vendor.kind !== 'vendor_season_shop' || Math.hypot(vendor.x - player.x, player.y - vendor.y) > 4.0) {
        return reject(currentState, 'Must stand at the Crossroads Season Supply Merchant');
      }
      const offer = next.world.vendorStocks.seasonShop[intent.offerKey];
      if (!offer || offer.stock <= 0) {
        return reject(currentState, 'Vendor item is out of stock for this run');
      }
      if (next.profile.securedCash < offer.priceSecuredCash) {
        return reject(currentState, `Requires ${offer.priceSecuredCash} Profile Secured Ragnarok Cash`);
      }

      next.profile.securedCash -= offer.priceSecuredCash;
      offer.stock -= 1;
      const qty = intent.offerKey === 'travel_ration_pack' ? 3 : 1;
      mintNewItemToContainerOrDrop(
        next,
        cursor,
        'player_inv',
        offer.defId,
        qty,
        `season_vendor:${intent.offerKey}`,
        { x: player.x, y: player.y }
      );

      return commit(
        next,
        cursor,
        'BUY_SEASON_VENDOR_ITEM',
        `Purchased run-local ${qty}x ${ITEMS_CATALOG[offer.defId]?.name ?? offer.defId} (-${offer.priceSecuredCash} Secured Cash)`,
        intent.requestId
      );
    }

    case 'BEGIN_EVACUATION': {
      if (player.dead) return reject(currentState, 'Cannot evacuate while dead');
      const beacon = next.entities[intent.beaconEntityId];
      if (!beacon || beacon.kind !== 'evac_beacon' || Math.hypot(beacon.x - player.x, beacon.y - player.y) > 3.8) {
        return reject(currentState, 'Must stand at a Coastal Evacuation Pier Beacon');
      }
      player.activeWindup = {
        kind: 'evac_channel',
        itemInstanceId: null,
        defId: 'evacuation',
        aimAngleRad: player.facingRad,
        targetX: beacon.x,
        targetY: beacon.y,
        startedAtMs: intent.nowMs,
        commitAtMs: intent.nowMs + 1400,
        endAtMs: intent.nowMs + 1450,
        committed: false,
        targetEntityId: beacon.id,
      };
      return commit(
        next,
        cursor,
        'BEGIN_EVACUATION',
        'Signaling Evacuation Launch — hold position for 1.4s (unbanked physical cash is NOT auto-secured!)',
        intent.requestId
      );
    }

    case 'ABANDON_RUN': {
      finalizeRunOnce(next, cursor, 'ABANDONED', intent.nowUtcMs);
      return commit(
        next,
        cursor,
        'ABANDON_RUN',
        'Abandoned Run — all run-local items, structures, recipes, and unbanked cash wiped',
        intent.requestId
      );
    }
  }
}
