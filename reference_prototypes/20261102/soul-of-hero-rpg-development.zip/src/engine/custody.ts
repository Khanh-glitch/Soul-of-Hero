import { ITEMS_CATALOG } from '../data/itemsCatalog';
import { ContainerState, GameState, ItemInstance } from './types';
import { nextId, RngCursor } from './rng';

export function createContainer(
  id: string,
  kind: ContainerState['kind'],
  capacitySlots: number,
  ownerEntityId?: string
): ContainerState {
  return {
    id,
    kind,
    capacitySlots,
    slots: new Array<string | null>(capacitySlots).fill(null),
    ownerEntityId,
  };
}

export function countItemInContainer(state: GameState, containerId: string, defId: string): number {
  const c = state.custody.containers[containerId];
  if (!c) return 0;
  let total = 0;
  for (const instId of c.slots) {
    if (!instId) continue;
    const inst = state.custody.items[instId];
    if (inst && inst.defId === defId) total += inst.qty;
  }
  return total;
}

export function hasItemsInContainer(
  state: GameState,
  containerId: string,
  reqs: { defId: string; qty: number }[]
): boolean {
  for (const r of reqs) {
    if (countItemInContainer(state, containerId, r.defId) < r.qty) return false;
  }
  return true;
}

export function debitItemsFromContainer(
  state: GameState,
  containerId: string,
  reqs: { defId: string; qty: number }[]
): boolean {
  if (!hasItemsInContainer(state, containerId, reqs)) return false;
  const c = state.custody.containers[containerId];
  for (const r of reqs) {
    let remaining = r.qty;
    for (let i = 0; i < c.slots.length && remaining > 0; i++) {
      const instId = c.slots[i];
      if (!instId) continue;
      const inst = state.custody.items[instId];
      if (!inst || inst.defId !== r.defId) continue;
      const take = Math.min(inst.qty, remaining);
      inst.qty -= take;
      remaining -= take;
      if (inst.qty <= 0) {
        c.slots[i] = null;
        delete state.custody.items[instId];
      }
    }
  }
  return true;
}

export function spawnWorldDrop(
  state: GameState,
  cursor: RngCursor,
  x: number,
  y: number,
  instanceIds: string[],
  provenance: string
): string | null {
  if (instanceIds.length === 0) return null;
  const entId = nextId(cursor, 'drop');
  const contId = `drop:${entId}`;
  const cont = createContainer(contId, 'drop', Math.max(4, instanceIds.length), entId);
  for (let i = 0; i < instanceIds.length; i++) {
    const inst = state.custody.items[instanceIds[i]];
    if (!inst) continue;
    inst.containerId = contId;
    cont.slots[i] = inst.id;
  }
  state.custody.containers[contId] = cont;
  state.entities[entId] = {
    id: entId,
    kind: 'world_drop',
    tileX: Math.floor(x),
    tileY: Math.floor(y),
    x,
    y,
    hp: 100,
    maxHp: 100,
    owner: 'world',
    containerId: contId,
    createdAtSec: state.clock.elapsedSimSec,
    provenance,
  };
  return entId;
}

export function mintNewItemToContainerOrDrop(
  state: GameState,
  cursor: RngCursor,
  targetContainerId: string,
  defId: string,
  qty: number,
  provenance: string,
  dropFallbackPos?: { x: number; y: number }
): { placedQty: number; droppedQty: number; instanceIds: string[] } {
  const def = ITEMS_CATALOG[defId];
  if (!def || qty <= 0) return { placedQty: 0, droppedQty: 0, instanceIds: [] };

  const cont = state.custody.containers[targetContainerId];
  let rem = qty;
  let placedQty = 0;
  const createdIds: string[] = [];

  if (cont) {
    // 1. Stack onto existing matching stacks if stackable
    if (def.maxStack > 1) {
      for (let i = 0; i < cont.slots.length && rem > 0; i++) {
        const slotId = cont.slots[i];
        if (!slotId) continue;
        const inst = state.custody.items[slotId];
        if (inst && inst.defId === defId && inst.qty < def.maxStack) {
          const add = Math.min(rem, def.maxStack - inst.qty);
          inst.qty += add;
          rem -= add;
          placedQty += add;
          if (!createdIds.includes(inst.id)) createdIds.push(inst.id);
        }
      }
    }
    // 2. Fill empty slots
    for (let i = 0; i < cont.slots.length && rem > 0; i++) {
      if (cont.slots[i] !== null) continue;
      const chunk = Math.min(rem, def.maxStack);
      let id = nextId(cursor, 'itm');
      while (state.custody.items[id]) id = nextId(cursor, 'itm');
      const inst: ItemInstance = {
        id,
        defId,
        qty: chunk,
        durability: def.maxDurability,
        charges: def.maxCharges,
        quality: 'common',
        provenance,
        containerId: targetContainerId,
      };
      state.custody.items[id] = inst;
      cont.slots[i] = id;
      createdIds.push(id);
      rem -= chunk;
      placedQty += chunk;
    }
  }

  let droppedQty = 0;
  if (rem > 0 && dropFallbackPos) {
    const overflowIds: string[] = [];
    while (rem > 0) {
      const chunk = Math.min(rem, def.maxStack);
      const id = nextId(cursor, 'itm');
      const inst: ItemInstance = {
        id,
        defId,
        qty: chunk,
        durability: def.maxDurability,
        charges: def.maxCharges,
        quality: 'common',
        provenance,
        containerId: 'pending_drop',
      };
      state.custody.items[id] = inst;
      overflowIds.push(id);
      createdIds.push(id);
      rem -= chunk;
      droppedQty += chunk;
    }
    spawnWorldDrop(state, cursor, dropFallbackPos.x, dropFallbackPos.y, overflowIds, provenance);
  }

  return { placedQty, droppedQty, instanceIds: createdIds };
}

export function transferExistingInstance(
  state: GameState,
  cursor: RngCursor,
  instanceId: string,
  toContainerId: string,
  toSlotIndex?: number,
  splitQty?: number
): { ok: boolean; reason?: string } {
  const inst = state.custody.items[instanceId];
  if (!inst) return { ok: false, reason: 'Item instance not found' };
  const fromCont = state.custody.containers[inst.containerId];
  const toCont = state.custody.containers[toContainerId];
  if (!fromCont || !toCont) return { ok: false, reason: 'Container unavailable' };

  const def = ITEMS_CATALOG[inst.defId];
  const fromIdx = fromCont.slots.indexOf(instanceId);
  if (fromIdx === -1) return { ok: false, reason: 'Item not in source container slot' };

  const moveQty = splitQty && splitQty > 0 && splitQty < inst.qty ? Math.floor(splitQty) : inst.qty;

  // Handle partial stack split cleanly (conserves total quantity strictly)
  if (moveQty < inst.qty) {
    let destSlot = toSlotIndex !== undefined && toCont.slots[toSlotIndex] === null ? toSlotIndex : -1;
    if (destSlot === -1) destSlot = toCont.slots.findIndex((s) => s === null);
    if (destSlot === -1) return { ok: false, reason: 'Destination container is full' };

    inst.qty -= moveQty;
    let splitId = nextId(cursor, 'itm');
    while (state.custody.items[splitId]) splitId = nextId(cursor, 'itm');
    state.custody.items[splitId] = {
      ...inst,
      id: splitId,
      qty: moveQty,
      containerId: toContainerId,
    };
    toCont.slots[destSlot] = splitId;
    return { ok: true };
  }

  // Moving the entire instance:
  // 1. If specific target slot given:
  if (toSlotIndex !== undefined && toSlotIndex >= 0 && toSlotIndex < toCont.capacitySlots) {
    const occupantId = toCont.slots[toSlotIndex];
    if (occupantId === instanceId) return { ok: true };
    if (occupantId === null) {
      fromCont.slots[fromIdx] = null;
      toCont.slots[toSlotIndex] = instanceId;
      inst.containerId = toContainerId;
      cleanupEmptyDropOrBag(state, fromCont);
      return { ok: true };
    }
    const occ = state.custody.items[occupantId];
    if (occ && occ.defId === inst.defId && def.maxStack > 1 && occ.qty < def.maxStack) {
      const space = def.maxStack - occ.qty;
      const merged = Math.min(space, inst.qty);
      occ.qty += merged;
      inst.qty -= merged;
      if (inst.qty <= 0) {
        fromCont.slots[fromIdx] = null;
        delete state.custody.items[instanceId];
        cleanupEmptyDropOrBag(state, fromCont);
      }
      return { ok: true };
    }
    // Swap two slots cleanly!
    fromCont.slots[fromIdx] = occupantId;
    occ.containerId = fromCont.id;
    toCont.slots[toSlotIndex] = instanceId;
    inst.containerId = toCont.id;
    return { ok: true };
  }

  // 2. Auto-merge onto matching stacks in target container first
  if (def.maxStack > 1) {
    for (let i = 0; i < toCont.slots.length && inst.qty > 0; i++) {
      const occId = toCont.slots[i];
      if (!occId || occId === instanceId) continue;
      const occ = state.custody.items[occId];
      if (occ && occ.defId === inst.defId && occ.qty < def.maxStack) {
        const add = Math.min(inst.qty, def.maxStack - occ.qty);
        occ.qty += add;
        inst.qty -= add;
      }
    }
    if (inst.qty <= 0) {
      fromCont.slots[fromIdx] = null;
      delete state.custody.items[instanceId];
      cleanupEmptyDropOrBag(state, fromCont);
      return { ok: true };
    }
  }

  // 3. Move remaining instance to first empty slot in target container
  const emptyIdx = toCont.slots.findIndex((s) => s === null);
  if (emptyIdx === -1) return { ok: false, reason: 'Destination container is full' };
  fromCont.slots[fromIdx] = null;
  toCont.slots[emptyIdx] = instanceId;
  inst.containerId = toContainerId;
  cleanupEmptyDropOrBag(state, fromCont);
  return { ok: true };
}

export function cleanupEmptyDropOrBag(state: GameState, cont: ContainerState): void {
  if (cont.kind !== 'drop' && cont.kind !== 'death_bag') return;
  const hasAny = cont.slots.some((s) => s !== null);
  if (!hasAny && cont.ownerEntityId) {
    delete state.entities[cont.ownerEntityId];
    delete state.custody.containers[cont.id];
  }
}

export function computeContainerWeightKg(state: GameState, containerId: string): number {
  const c = state.custody.containers[containerId];
  if (!c) return 0;
  let total = 0;
  for (const id of c.slots) {
    if (!id) continue;
    const inst = state.custody.items[id];
    if (!inst) continue;
    const def = ITEMS_CATALOG[inst.defId];
    if (def) total += def.weightKg * inst.qty;
  }
  return Math.round(total * 100) / 100;
}

export function computePlayerCarryWeightKg(state: GameState): number {
  let w = computeContainerWeightKg(state, 'player_inv');
  for (const eqId of [state.custody.equippedHeadId, state.custody.equippedBodyId]) {
    if (!eqId) continue;
    const inst = state.custody.items[eqId];
    if (inst && ITEMS_CATALOG[inst.defId]) {
      w += ITEMS_CATALOG[inst.defId].weightKg * inst.qty;
    }
  }
  return Math.round(w * 100) / 100;
}

export function getActiveQuickbarItem(state: GameState): ItemInstance | null {
  const inv = state.custody.containers['player_inv'];
  if (!inv) return null;
  const invSlot = state.custody.playerQuickbar[state.custody.activeQuickSlot] ?? state.custody.activeQuickSlot;
  const instId = inv.slots[invSlot];
  if (!instId) return null;
  return state.custody.items[instId] ?? null;
}
