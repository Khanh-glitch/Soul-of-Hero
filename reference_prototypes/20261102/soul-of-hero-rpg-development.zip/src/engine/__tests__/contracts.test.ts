import { describe, expect, it } from 'vitest';
import fc from 'fast-check';
import balance from '../../data/balance.v1.json';
import { ELDER_STONE_IDS } from '../../data/itemsCatalog';
import { countItemInContainer, mintNewItemToContainerOrDrop } from '../custody';
import { createNewRunGameState, dispatch } from '../dispatcher';
import { RngCursor } from '../rng';
import { getStaticIslandMap } from '../worldGen';

function makeCursor(state: ReturnType<typeof createNewRunGameState>): RngCursor {
  return { rngState: state.rngState, nextIdCounter: state.nextIdCounter };
}

describe('Soul of Hero Authoritative Causal Engine (K1-K8 & C01-C24)', () => {
  it('C24 & C12: Stable island geography with 4 distinct safe viable spawns and zero tutorial gates', () => {
    const map1 = getStaticIslandMap();
    const map2 = getStaticIslandMap();
    expect(map1.width).toBe(200);
    expect(map1.height).toBe(200);
    expect(map1.spawnRegions.length).toBe(4);
    expect(map1.surfaces).toEqual(map2.surfaces);

    for (const sp of map1.spawnRegions) {
      const s = createNewRunGameState({ gender: 'female', spawnRegionId: sp.id, nowUtcMs: 1_000_000 });
      // Spawn tile walkable and free of hostile monsters within safe radius
      expect(map1.walkable[sp.y * map1.width + sp.x]).toBe(1);
      const nearbyHostile = Object.values(s.actors.monsters).filter(
        (m) => Math.hypot(m.x - s.actors.player.x, m.y - s.actors.player.y) < 10
      );
      expect(nearbyHostile.length).toBe(0);

      // Starter survival resources exist within immediate reach
      const nearbySources = Object.values(s.sources).filter(
        (n) => Math.hypot(n.x - s.actors.player.x, n.y - s.actors.player.y) <= 10
      );
      expect(nearbySources.some((n) => n.kind === 'oak_tree' || n.kind === 'pine_tree')).toBe(true);
      expect(nearbySources.some((n) => n.kind === 'boulder')).toBe(true);
      expect(nearbySources.some((n) => n.kind === 'berry_bush')).toBe(true);

      // Can immediately craft without completing any quest prompt (C12)
      const cursor = makeCursor(s);
      mintNewItemToContainerOrDrop(s, cursor, 'player_inv', 'wood_log', 3, 'test');
      mintNewItemToContainerOrDrop(s, cursor, 'player_inv', 'stone_chunk', 3, 'test');
      mintNewItemToContainerOrDrop(s, cursor, 'player_inv', 'plant_fiber', 2, 'test');
      const crafted = dispatch({ type: 'CRAFT_RECIPE', recipeId: 'craft_stone_hatchet', requestId: 'c12_craft' }, s);
      expect(crafted.accepted).toBe(true);
      expect(countItemInContainer(crafted.state, 'player_inv', 'stone_hatchet')).toBe(1);
    }
  });

  it('C01, C02 & C05: Shared swing separates enemy damage from harvest yield; finite road crate depletes once', () => {
    let state = createNewRunGameState({ gender: 'male', spawnRegionId: 'spawn_meadow', nowUtcMs: 1_000_000 });
    const crate = Object.values(state.sources).find(
      (n) => n.kind === 'road_crate' && Math.hypot(n.x - state.actors.player.x, n.y - state.actors.player.y) < 12
    )!;
    expect(crate).toBeDefined();

    // Position player beside the roadside crate
    state.actors.player.x = crate.x - 1.0;
    state.actors.player.y = crate.y;

    let nowMs = 1_005_000;
    while (state.sources[crate.id].stock > 0) {
      const swing = dispatch(
        { type: 'PRIMARY_ACTION', aimRad: 0, targetWorldX: crate.x, targetWorldY: crate.y, nowMs },
        state
      );
      expect(swing.accepted).toBe(true);
      state = swing.state;
      nowMs += 400;
      state = dispatch(
        { type: 'TICK', dtSec: 0.05, nowUtcMs: nowMs, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: crate.x, aimWorldY: crate.y },
        state
      ).state;
    }

    const sparesAfterFirstDeplete = countItemInContainer(state, 'player_inv', 'spares');
    expect(sparesAfterFirstDeplete).toBeGreaterThan(0);
    expect(state.sources[crate.id].stock).toBe(0);

    // Adversarial repeated harvest on depleted crate grants ZERO extra items
    nowMs += 600;
    state = dispatch(
      { type: 'PRIMARY_ACTION', aimRad: 0, targetWorldX: crate.x, targetWorldY: crate.y, nowMs },
      state
    ).state;
    nowMs += 400;
    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: nowMs, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: crate.x, aimWorldY: crate.y },
      state
    ).state;
    expect(countItemInContainer(state, 'player_inv', 'spares')).toBe(sparesAfterFirstDeplete);

    // Hitting a monster deals HP damage without minting tree/crate yield (C05)
    const mob = Object.values(state.actors.monsters).find((m) => !m.isElder)!;
    state.actors.player.x = mob.x - 1.0;
    state.actors.player.y = mob.y;
    const prevHp = mob.hp;
    nowMs += 600;
    state = dispatch(
      { type: 'PRIMARY_ACTION', aimRad: 0, targetWorldX: mob.x, targetWorldY: mob.y, nowMs },
      state
    ).state;
    nowMs += 300;
    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: nowMs, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: mob.x, aimWorldY: mob.y },
      state
    ).state;
    expect(state.actors.monsters[mob.id].hp).toBeLessThan(prevHp);
  });

  it('C03 & C05: Found Charged Core casts before learning recipe; canceling windup preserves charge; commit debits once', () => {
    let state = createNewRunGameState({ gender: 'female', spawnRegionId: 'spawn_meadow', nowUtcMs: 2_000_000 });
    expect(state.knowledge.unlockedRecipes.includes('craft_core_ember')).toBe(false);

    const cursor = makeCursor(state);
    // Clear slot 0 and place found Charged Ember Core in quickslot 0
    const knifeId = state.custody.containers['player_inv'].slots[0]!;
    state = dispatch({ type: 'DROP_ITEM', instanceId: knifeId }, state).state;
    const minted = mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'core_ember', 1, 'found_shrine');
    const coreId = minted.instanceIds[0];
    const startCharges = state.custody.items[coreId].charges!;
    expect(startCharges).toBe(12);

    // Start windup, then cancel BEFORE commitAtMs -> ZERO charge used!
    let nowMs = 2_010_000;
    const started = dispatch(
      { type: 'PRIMARY_ACTION', aimRad: 0, targetWorldX: state.actors.player.x + 2, targetWorldY: state.actors.player.y, nowMs },
      state
    );
    expect(started.accepted).toBe(true);
    state = started.state;
    const canceled = dispatch({ type: 'CANCEL_WINDUP', reason: 'test_dodge' }, state);
    expect(canceled.accepted).toBe(true);
    state = canceled.state;
    expect(state.custody.items[coreId].charges).toBe(startCharges);

    // Cast again and let TICK pass commitAtMs -> debits exactly 1 charge and ignites flammable meadow tile!
    nowMs += 1000;
    state = dispatch(
      { type: 'PRIMARY_ACTION', aimRad: 0, targetWorldX: state.actors.player.x + 2, targetWorldY: state.actors.player.y, nowMs },
      state
    ).state;
    nowMs += 350;
    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: nowMs, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: state.actors.player.x + 2, aimWorldY: state.actors.player.y },
      state
    ).state;
    expect(state.custody.items[coreId].charges).toBe(startCharges - 1);
    expect(state.world.fires.length).toBeGreaterThanOrEqual(1);
  });

  it('C04: Blueprint, Spares research, and Specimen study share ONE run-local recipe authority without double-spend', () => {
    let state = createNewRunGameState({ gender: 'male', spawnRegionId: 'spawn_meadow', nowUtcMs: 3_000_000 });
    const px = Math.floor(state.actors.player.x);
    const py = Math.floor(state.actors.player.y);

    const cursor = makeCursor(state);
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'wood_log', 20, 'test');
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'spares', 60, 'test');
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'scrap_metal', 10, 'test');
    const bp = mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'bp_handcart', 1, 'test');
    const spec = mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'salvage_crowbar', 1, 'test');

    // Place floor (auto-claims homestead) & Research Table
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: px + 1, tileY: py }, state).state;
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'research_table', tileX: px + 1, tileY: py }, state).state;
    const bench = Object.values(state.entities).find((e) => e.kind === 'research_table')!;

    // 1. Blueprint unlock
    state = dispatch({ type: 'USE_ITEM', instanceId: bp.instanceIds[0] }, state).state;
    expect(state.knowledge.unlockedRecipes).toContain('craft_handcart_kit');

    // Attempt Directed research on already-unlocked recipe -> rejected with zero Spares debit!
    const sparesBeforeReject = countItemInContainer(state, 'player_inv', 'spares');
    const dupRes = dispatch(
      { type: 'RESEARCH_UNLOCK', stationEntityId: bench.id, mode: 'directed', targetRecipeId: 'craft_handcart_kit' },
      state
    );
    expect(dupRes.accepted).toBe(false);
    expect(countItemInContainer(dupRes.state, 'player_inv', 'spares')).toBe(sparesBeforeReject);

    // 2. Specimen study consumes specimen + 6 Spares and unlocks craft_salvage_crowbar
    const specRes = dispatch(
      { type: 'RESEARCH_UNLOCK', stationEntityId: bench.id, mode: 'specimen', specimenInstanceId: spec.instanceIds[0] },
      state
    );
    expect(specRes.accepted).toBe(true);
    state = specRes.state;
    expect(state.knowledge.unlockedRecipes).toContain('craft_salvage_crowbar');
    expect(countItemInContainer(state, 'player_inv', 'salvage_crowbar')).toBe(0);

    // 3. Random Tier 1 discovery
    const randRes = dispatch({ type: 'RESEARCH_UNLOCK', stationEntityId: bench.id, mode: 'random_t1' }, state);
    expect(randRes.accepted).toBe(true);
  });

  it('C06 & C09: Furnace stops at exact fuel exhaustion offline; shelter prevents offline hunger death at 1 HP', () => {
    let state = createNewRunGameState({ gender: 'female', spawnRegionId: 'spawn_meadow', nowUtcMs: 4_000_000 });
    const px = Math.floor(state.actors.player.x);
    const py = Math.floor(state.actors.player.y);

    const cursor = makeCursor(state);
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'wood_log', 20, 'test');
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'stone_chunk', 20, 'test');
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'plant_fiber', 10, 'test');
    const oreMint = mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'iron_ore', 10, 'test');
    const fuelMint = mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'wood_log', 1, 'fuel_only');

    // Build floor + roof directly over player (lawful shelter!) and furnace adjacent
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: px, tileY: py }, state).state;
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'thatch_roof', tileX: px, tileY: py }, state).state;
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'stone_furnace', tileX: px + 1, tileY: py }, state).state;

    const furnace = Object.values(state.entities).find((e) => e.kind === 'stone_furnace')!;

    // Load 10 Iron Ore (5 batches * 12s = 60s needed) into Furnace Input, and ONLY 1 Wood Log (30s fuel = max 2 ingots!)
    state = dispatch(
      { type: 'TRANSFER_ITEM', instanceId: oreMint.instanceIds[0], toContainerId: furnace.containerId! },
      state
    ).state;
    state = dispatch(
      { type: 'TRANSFER_ITEM', instanceId: fuelMint.instanceIds[0], toContainerId: furnace.fuelContainerId!, splitQty: 1 },
      state
    ).state;

    state = dispatch({ type: 'START_STATION_JOB', stationEntityId: furnace.id, recipeId: 'smelt_iron_ore' }, state).state;

    // Simulate 3 full real hours offline!
    const threeHoursLater = state.clock.lastSettledUtcMs + 3 * 3600 * 1000;
    const settled = dispatch({ type: 'SETTLE_OFFLINE', nowUtcMs: threeHoursLater }, state);
    expect(settled.accepted).toBe(true);
    state = settled.state;

    // 30s fuel / 12s per ingot = 2 ingots produced, 3rd paused at 6s when fuel ran out! Zero magic offline completion!
    expect(countItemInContainer(state, furnace.outputContainerId!, 'iron_ingot')).toBe(2);
    expect(countItemInContainer(state, furnace.containerId!, 'iron_ore')).toBe(6);
    const activeJob = Object.values(state.jobs)[0];
    expect(activeJob.status).toBe('PAUSED_NO_FUEL');

    // Player starved to 0 hunger over 3 hours offline, but lawful roof shelter held HP at >= 1 HP!
    expect(state.actors.player.hunger).toBe(0);
    expect(state.actors.player.dead).toBe(false);
    expect(state.actors.player.hp).toBeGreaterThanOrEqual(balance.survival.offlineShelterHungerMinHp);
  });

  it('C07 & Property Test: Invalid build rollback with zero debit, duplicate requestId rejection, and loaded chest reclaim conservation', () => {
    let state = createNewRunGameState({ gender: 'male', spawnRegionId: 'spawn_meadow', nowUtcMs: 5_000_000 });
    const cursor = makeCursor(state);
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'wood_log', 12, 'test');
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'plant_fiber', 6, 'test');
    mintNewItemToContainerOrDrop(state, cursor, 'player_inv', 'iron_ingot', 7, 'test');

    const woodBefore = countItemInContainer(state, 'player_inv', 'wood_log');
    // Invalid placement on deep ocean (tile 0,0) -> rejected, ZERO wood debited!
    const badBuild = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: 0, tileY: 0 }, state);
    expect(badBuild.accepted).toBe(false);
    expect(countItemInContainer(badBuild.state, 'player_inv', 'wood_log')).toBe(woodBefore);

    const px = Math.floor(state.actors.player.x);
    const py = Math.floor(state.actors.player.y);
    const okFloor = dispatch(
      { type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: px + 1, tileY: py, requestId: 'dup_floor_1' },
      state
    );
    expect(okFloor.accepted).toBe(true);
    state = okFloor.state;

    // Duplicate requestId -> idempotent rejection!
    const replayFloor = dispatch(
      { type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: px + 2, tileY: py, requestId: 'dup_floor_1' },
      state
    );
    expect(replayFloor.accepted).toBe(false);

    // Build chest, put 7 Iron Ingots inside, then RECLAIM loaded chest -> all 7 Iron Ingots conserved!
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'storage_chest', tileX: px + 1, tileY: py }, state).state;
    const chest = Object.values(state.entities).find((e) => e.kind === 'storage_chest')!;
    const ingotId = Object.values(state.custody.items).find((i) => i.defId === 'iron_ingot')!.id;

    state = dispatch({ type: 'TRANSFER_ITEM', instanceId: ingotId, toContainerId: chest.containerId! }, state).state;
    expect(countItemInContainer(state, 'player_inv', 'iron_ingot')).toBe(0);
    expect(countItemInContainer(state, chest.containerId!, 'iron_ingot')).toBe(7);

    state = dispatch({ type: 'RECLAIM_STRUCTURE', entityId: chest.id }, state).state;
    expect(state.entities[chest.id]).toBeUndefined();
    expect(countItemInContainer(state, 'player_inv', 'iron_ingot')).toBe(7);

    // Property-based conservation test across arbitrary splits & container transfers!
    fc.assert(
      fc.property(fc.array(fc.integer({ min: 1, max: 15 }), { minLength: 3, maxLength: 12 }), (splits) => {
        let s = createNewRunGameState({ gender: 'male', spawnRegionId: 'spawn_meadow', nowUtcMs: 5_100_000 });
        const cur = makeCursor(s);
        mintNewItemToContainerOrDrop(s, cur, 'player_inv', 'wood_log', 40, 'prop');
        mintNewItemToContainerOrDrop(s, cur, 'player_inv', 'plant_fiber', 10, 'prop');
        s.nextIdCounter = cur.nextIdCounter;
        const ptx = Math.floor(s.actors.player.x);
        const pty = Math.floor(s.actors.player.y);
        s = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: ptx + 1, tileY: pty }, s).state;
        s = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'storage_chest', tileX: ptx + 1, tileY: pty }, s).state;
        const ch = Object.values(s.entities).find((e) => e.kind === 'storage_chest')!;
        expect(ch).toBeDefined();

        const cur2 = makeCursor(s);
        mintNewItemToContainerOrDrop(s, cur2, 'player_inv', 'spares', 50, 'prop_spares');
        s.nextIdCounter = cur2.nextIdCounter;
        const initialSpares = 50;

        for (const q of splits) {
          const allSpares = Object.values(s.custody.items).filter((i) => i.defId === 'spares');
          if (allSpares.length === 0) break;
          const pick = allSpares[0];
          const dest = ch && pick.containerId === 'player_inv' ? ch.containerId! : 'player_inv';
          s = dispatch({ type: 'TRANSFER_ITEM', instanceId: pick.id, toContainerId: dest, splitQty: q }, s).state;
        }

        const finalTotal = Object.values(s.custody.items)
          .filter((i) => i.defId === 'spares')
          .reduce((sum, i) => sum + i.qty, 0);
        expect(finalTotal).toBe(initialSpares);
      }),
      { numRuns: 20 }
    );
  });

  it('C08 & C14: Monsters track physical footprints only and lose trail in STORM; never GPS-locate an unseen home', () => {
    let state = createNewRunGameState({ gender: 'female', spawnRegionId: 'spawn_meadow', nowUtcMs: 6_000_000 });
    // Build an unobserved home at spawn_meadow
    const px = Math.floor(state.actors.player.x);
    const py = Math.floor(state.actors.player.y);
    const cur = makeCursor(state);
    mintNewItemToContainerOrDrop(state, cur, 'player_inv', 'wood_log', 10, 'test');
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: px + 1, tileY: py }, state).state;

    // Pick a distant monster 50+ tiles away — it has ZERO footprints near it and never targets the home
    const farMob = Object.values(state.actors.monsters).find(
      (m) => !m.isElder && Math.hypot(m.x - px, m.y - py) > 40
    )!;
    expect(farMob.aiState).toBe('PATROL');

    // Walk near a closer monster to emit footprints, then hide out of sight & trigger STORM erosion
    const nearMob = Object.values(state.actors.monsters).find(
      (m) => !m.isElder && Math.hypot(m.x - px, m.y - py) < 28
    )!;
    state.actors.player.x = nearMob.x + 2.0;
    state.actors.player.y = nearMob.y;
    state.actors.player.lastFootprintPos = { x: nearMob.x + 5, y: nearMob.y };
    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: 6_001_000, moveX: -1, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;
    expect(state.world.footprints.length).toBeGreaterThan(0);

    // Move player far away so monster only sees footprint, not player
    state.actors.player.x = px + 0.5;
    state.actors.player.y = py + 0.5;
    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: 6_002_000, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;
    expect(state.actors.monsters[nearMob.id].aiState).toBe('TRACK_TRACE');

    // Heavy STORM washes away footprints -> monster loses trail and returns to habitat!
    state = dispatch({ type: 'QA_ADVANCE_TIME', hours: 0.05, forceWeather: 'STORM', preserveVitals: true }, state).state;
    expect(state.world.footprints.length).toBe(0);
    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: 6_200_000, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;
    expect(state.actors.monsters[nearMob.id].aiState).toBe('RETURN');
  });

  it('C10, C11 & C13: Unique Death Bag recovery, POI fuse/keycard gate access, and Road vs Marsh cart freight speed', () => {
    let state = createNewRunGameState({ gender: 'male', spawnRegionId: 'spawn_steppe', nowUtcMs: 7_000_000 });
    const cur = makeCursor(state);
    mintNewItemToContainerOrDrop(state, cur, 'player_inv', 'iron_ingot', 12, 'test');

    // C13: Deploy & hitch Handcart; measure distance moved in 1s on ROAD vs MARSH mud
    mintNewItemToContainerOrDrop(state, cur, 'player_inv', 'handcart_kit', 1, 'test');
    const map = getStaticIslandMap(state.world.seed);
    let roadTile = { x: 96, y: 112 };
    let marshTile = { x: 68, y: 148 };
    for (let y = 20; y < 180; y++) {
      for (let x = 20; x < 180; x++) {
        if (map.surfaces[y * map.width + x] === 'road' && map.surfaces[y * map.width + x + 1] === 'road') {
          roadTile = { x, y };
        }
        if (map.surfaces[y * map.width + x] === 'mud' && map.surfaces[y * map.width + x + 1] === 'mud') {
          marshTile = { x, y };
        }
      }
    }

    state.actors.player.x = roadTile.x + 0.5;
    state.actors.player.y = roadTile.y + 0.5;
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'handcart', tileX: roadTile.x, tileY: roadTile.y }, state).state;
    const cart = Object.values(state.entities).find((e) => e.kind === 'handcart')!;
    state = dispatch({ type: 'TOGGLE_CART_HITCH', cartEntityId: cart.id }, state).state;

    const r0 = state.actors.player.x;
    state = dispatch(
      { type: 'TICK', dtSec: 0.1, nowUtcMs: 7_001_000, moveX: 1, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;
    const roadStep = state.actors.player.x - r0;

    state.actors.player.x = marshTile.x + 0.5;
    state.actors.player.y = marshTile.y + 0.5;
    state.entities[cart.id].x = marshTile.x + 0.2;
    state.entities[cart.id].y = marshTile.y + 0.5;
    const m0 = state.actors.player.x;
    state = dispatch(
      { type: 'TICK', dtSec: 0.1, nowUtcMs: 7_002_000, moveX: 1, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;
    const marshStep = state.actors.player.x - m0;
    expect(roadStep).toBeGreaterThan(marshStep * 2.2);

    // C11: POI deep locker blocked while gate locked, accessible once exterior power box receives copper_fuse
    const relayPoi = state.world.pois.find((p) => p.id === 'poi_relay_bunker')!;
    const deepLocker = Object.values(state.sources).find((s) => s.poiId === relayPoi.id && s.requiresDeepAccess)!;
    const powerBox = Object.values(state.entities).find((e) => e.kind === 'poi_power_box' && e.linkedPoiId === relayPoi.id)!;

    state.actors.player.x = deepLocker.x;
    state.actors.player.y = deepLocker.y + 1.5;
    const blockedLoot = dispatch({ type: 'INTERACT_NEAREST', nowMs: 7_010_000 }, state);
    expect(blockedLoot.accepted).toBe(false);

    mintNewItemToContainerOrDrop(state, makeCursor(state), 'player_inv', 'copper_fuse', 1, 'test');
    state.actors.player.x = powerBox.x;
    state.actors.player.y = powerBox.y + 1.0;
    const powered = dispatch({ type: 'INTERACT_NEAREST', nowMs: 7_011_000 }, state);
    expect(powered.accepted).toBe(true);
    state = powered.state;

    state.actors.player.x = deepLocker.x;
    state.actors.player.y = deepLocker.y + 0.5;
    const openedDeep = dispatch({ type: 'INTERACT_NEAREST', nowMs: 7_012_000 }, state);
    expect(openedDeep.accepted).toBe(true);
    state = openedDeep.state;

    // C10: Starvation death creates ONE unique Death Bag; respawn & physical recovery restores exact items
    const deathX = 80.5;
    const deathY = 120.5;
    state.actors.player.x = deathX;
    state.actors.player.y = deathY;
    state.actors.player.hunger = 0;
    state.actors.player.hp = 0.005;
    state = dispatch(
      { type: 'TICK', dtSec: 0.1, nowUtcMs: 7_020_000, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;

    expect(state.actors.player.dead).toBe(true);
    expect(state.run.active).toBe(true);
    const bags = Object.values(state.entities).filter((e) => e.kind === 'death_bag');
    expect(bags.length).toBe(1);
    expect(countItemInContainer(state, 'player_inv', 'iron_ingot')).toBe(0);

    state = dispatch({ type: 'RESPAWN_AFTER_DEATH', useBed: false }, state).state;
    expect(state.actors.player.dead).toBe(false);

    // Walk back to Death Bag and press E to recover
    state.actors.player.x = deathX;
    state.actors.player.y = deathY;
    const rec = dispatch({ type: 'INTERACT_NEAREST', nowMs: 7_030_000 }, state);
    expect(rec.accepted).toBe(true);
    state = rec.state;
    expect(countItemInContainer(state, 'player_inv', 'iron_ingot')).toBeGreaterThanOrEqual(12);
    expect(Object.values(state.entities).filter((e) => e.kind === 'death_bag').length).toBe(0);
  });

  it('C15-C23: Full No-Boss Zero-Wallet First Escrow -> Evacuation -> Total Run Wipe -> Run 2 Vendor Spend & Day 14 Elders', () => {
    let state = createNewRunGameState({ gender: 'female', spawnRegionId: 'spawn_meadow', nowUtcMs: 8_000_000 });
    expect(state.profile.securedCash).toBe(0);

    // Find the two non-boss exterior Final-72 Ragnarok Cash Vaults (Relay Bunker & Harbor Depot)
    const nonBossCashVaults = Object.values(state.sources).filter(
      (s) => s.kind === 'final72_cash_vault' && !s.requiresDeepAccess
    );
    expect(nonBossCashVaults.length).toBeGreaterThanOrEqual(2);

    // C15: Cannot open Ragnarok Cash Vault before Final 72h (Hour 264)
    state.actors.player.x = nonBossCashVaults[0].x;
    state.actors.player.y = nonBossCashVaults[0].y + 0.8;
    const earlyTry = dispatch({ type: 'INTERACT_NEAREST', nowMs: 8_001_000 }, state);
    expect(earlyTry.accepted).toBe(false);
    expect(countItemInContainer(state, 'player_inv', 'ragnarok_cash')).toBe(0);

    // Advance into Final 72h (Hour 265)
    state = dispatch({ type: 'QA_ADVANCE_TIME', hours: 265, preserveVitals: true }, state).state;
    expect(state.clock.phase).toBe('RAGNAROK_72H');

    // Loot both non-boss Final-72 vaults ONCE each
    for (const v of nonBossCashVaults) {
      state.actors.player.x = v.x;
      state.actors.player.y = v.y + 0.8;
      const lootRes = dispatch({ type: 'INTERACT_NEAREST', nowMs: 8_010_000 }, state);
      expect(lootRes.accepted).toBe(true);
      state = lootRes.state;

      // Re-looting depleted vault is rejected (finite once!)
      const reloot = dispatch({ type: 'INTERACT_NEAREST', nowMs: 8_011_000 }, state);
      expect(reloot.accepted).toBe(false);
    }

    const totalLootedCash = countItemInContainer(state, 'player_inv', 'ragnarok_cash');
    expect(totalLootedCash).toBeGreaterThan(balance.landAndEscrow.escrowChestVendorPricePhysicalCash + 40);

    // C16: Travel to Crossroads Escrow Broker (zero Elders defeated!) and buy physical Rương ký gửi
    const broker = Object.values(state.entities).find((e) => e.kind === 'vendor_escrow_broker')!;
    state.actors.player.x = broker.x;
    state.actors.player.y = broker.y + 1.0;
    const bought = dispatch({ type: 'BUY_ESCROW_CHEST_PHYSICAL', vendorEntityId: broker.id }, state);
    expect(bought.accepted).toBe(true);
    state = bought.state;
    expect(countItemInContainer(state, 'player_inv', 'escrow_chest_kit')).toBe(1);

    // Return to owned Homestead land, place Rương ký gửi, and deposit partial cash leaving 20 unbanked to test C22!
    const homeX = 52;
    const homeY = 136;
    state.actors.player.x = homeX + 0.5;
    state.actors.player.y = homeY + 0.5;
    mintNewItemToContainerOrDrop(state, makeCursor(state), 'player_inv', 'wood_log', 4, 'test');

    // Cannot place Rương ký gửi before owning Homestead land!
    const unownedPlace = dispatch(
      { type: 'BUILD_STRUCTURE', structureKind: 'escrow_chest', tileX: homeX + 1, tileY: homeY },
      state
    );
    expect(unownedPlace.accepted).toBe(false);

    // Claim land with foundation floor, then place Rương ký gửi
    state = dispatch({ type: 'BUILD_STRUCTURE', structureKind: 'wood_floor', tileX: homeX + 1, tileY: homeY }, state).state;
    const placedEscrow = dispatch(
      { type: 'BUILD_STRUCTURE', structureKind: 'escrow_chest', tileX: homeX + 1, tileY: homeY },
      state
    );
    expect(placedEscrow.accepted).toBe(true);
    state = placedEscrow.state;

    const escrowEnt = Object.values(state.entities).find((e) => e.kind === 'escrow_chest')!;
    const remainingCash = countItemInContainer(state, 'player_inv', 'ragnarok_cash');
    const depositAmount = remainingCash - 20; // Keep 20 unbanked cash in backpack to verify evacuation does NOT auto-secure it!

    const depRes = dispatch(
      { type: 'DEPOSIT_RAGNAROK_CASH', escrowEntityId: escrowEnt.id, amount: depositAmount, requestId: 'dep_once_1' },
      state
    );
    expect(depRes.accepted).toBe(true);
    state = depRes.state;
    expect(state.profile.securedCash).toBe(depositAmount);
    expect(countItemInContainer(state, 'player_inv', 'ragnarok_cash')).toBe(20);

    // C17: Duplicate deposit replay with same requestId does NOT double-credit
    const replayDep = dispatch(
      { type: 'DEPOSIT_RAGNAROK_CASH', escrowEntityId: escrowEnt.id, amount: 20, requestId: 'dep_once_1' },
      state
    );
    expect(replayDep.accepted).toBe(false);
    expect(state.profile.securedCash).toBe(depositAmount);

    // C19: Verify Day 14 (Hour 313) awakens all 6 distinct optional Elders
    state = dispatch({ type: 'QA_ADVANCE_TIME', hours: 48, preserveVitals: true }, state).state;
    expect(state.clock.phase).toBe('ELDER_AWAKENED_D14');
    const elders = Object.values(state.actors.monsters).filter((m) => m.isElder);
    expect(elders.length).toBe(6);
    expect(elders.every((e) => e.elderForm === 'awakened')).toBe(true);
    expect(new Set(elders.map((e) => e.stoneDefId)).size).toBe(6);
    expect(ELDER_STONE_IDS.length).toBe(6);

    // C20 & C21: Score receipts are LOCAL_UNVERIFIED and never generate cash
    expect(state.run.scoreReceipts.length).toBeGreaterThanOrEqual(1);
    expect(state.run.scoreReceipts.every((r) => r.verification === 'LOCAL_UNVERIFIED')).toBe(true);

    // C22 & C23: Physical Evacuation at West Harbor Pier finalizes run ONCE, wipes all run-local items/buildings/20 unbanked cash, retains ONLY profile fields!
    const evacBeacon = Object.values(state.entities).find((e) => e.kind === 'evac_beacon')!;
    state.actors.player.x = evacBeacon.x;
    state.actors.player.y = evacBeacon.y + 0.5;
    const evacStart = dispatch({ type: 'BEGIN_EVACUATION', beaconEntityId: evacBeacon.id, nowMs: 9_000_000 }, state);
    expect(evacStart.accepted).toBe(true);
    state = evacStart.state;

    state = dispatch(
      { type: 'TICK', dtSec: 0.05, nowUtcMs: 9_002_000, moveX: 0, moveY: 0, aimRad: 0, aimWorldX: 0, aimWorldY: 0 },
      state
    ).state;

    expect(state.run.active).toBe(false);
    expect(state.run.endReason).toBe('EVACUATED');
    expect(state.profile.securedCash).toBe(depositAmount); // Unbanked 20 was NOT auto-secured!
    expect(state.profile.runHistory[0].unbankedCashLostOnEnd).toBe(20);
    expect(state.profile.runHistory[0].verification).toBe('LOCAL_UNVERIFIED');
    expect(Object.keys(state.custody.items).length).toBe(0);
    expect(Object.keys(state.entities).length).toBe(0);

    // C18 & C23: Start Run 2 -> recipes, home, and items wiped; spend Profile Secured Cash at physical Season Vendor for RUN-LOCAL item!
    const run2 = dispatch(
      { type: 'START_NEW_RUN', gender: 'male', spawnRegionId: 'spawn_steppe', nowUtcMs: 10_000_000 },
      state
    ).state;
    expect(run2.run.runNumber).toBe(2);
    expect(run2.profile.securedCash).toBe(depositAmount);
    expect(run2.world.homesteads.length).toBe(0);
    expect(countItemInContainer(run2, 'player_inv', 'salvage_crowbar')).toBe(0);

    const seasonShop = Object.values(run2.entities).find((e) => e.kind === 'vendor_season_shop')!;
    run2.actors.player.x = seasonShop.x;
    run2.actors.player.y = seasonShop.y + 1.0;
    const buyRun2 = dispatch(
      { type: 'BUY_SEASON_VENDOR_ITEM', vendorEntityId: seasonShop.id, offerKey: 'salvage_crowbar' },
      run2
    );
    expect(buyRun2.accepted).toBe(true);
    expect(countItemInContainer(buyRun2.state, 'player_inv', 'salvage_crowbar')).toBe(1);
    expect(buyRun2.state.profile.securedCash).toBe(depositAmount - 45);
  });
});
