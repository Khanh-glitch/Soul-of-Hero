export type AdventurerGender = 'male' | 'female';

export type BiomeId =
  | 'ocean'
  | 'shallow_water'
  | 'river'
  | 'beach'
  | 'meadow'
  | 'forest'
  | 'steppe'
  | 'highland'
  | 'marsh'
  | 'tundra'
  | 'caldera'
  | 'industrial';

export type SurfaceType =
  | 'water'
  | 'shallow'
  | 'sand'
  | 'grass'
  | 'forest_floor'
  | 'road'
  | 'bridge'
  | 'rock'
  | 'mud'
  | 'snow'
  | 'scorch'
  | 'toxic_concrete'
  | 'wood_floor'
  | 'stone_floor';

export type WeatherKind = 'CLEAR' | 'RAIN' | 'STORM' | 'COLD_SNAP' | 'ASH_WIND';

export type RunPhase =
  | 'EXPEDITION'
  | 'ESCALATION_D12'
  | 'RAGNAROK_72H'
  | 'ELDER_AWAKENED_D14'
  | 'ENDED';

export type RunEndReason = 'EVACUATED' | 'ABANDONED' | 'EXPIRED_336H' | 'SIX_STONES_CONVERGENCE';

export type ItemCategory =
  | 'tool_weapon'
  | 'core'
  | 'armor'
  | 'resource'
  | 'salvage'
  | 'consumable'
  | 'seed'
  | 'key_utility'
  | 'blueprint'
  | 'deployable'
  | 'currency'
  | 'elder_stone';

export type HarvestTag = 'wood' | 'stone' | 'ore' | 'salvage' | 'flora' | 'meat' | 'dig';

export type CoreSkillId =
  | 'ember_arc'
  | 'gale_dash'
  | 'frost_nova'
  | 'thorn_snare'
  | 'volt_lance'
  | 'aegis_pulse';

export interface ItemDefinition {
  id: string;
  name: string;
  category: ItemCategory;
  description: string;
  maxStack: number;
  weightKg: number;
  iconKey: string;
  // Tool / weapon stats
  damage?: number;
  rangeTiles?: number;
  windupMs?: number;
  cooldownMs?: number;
  staminaCost?: number;
  maxDurability?: number;
  harvestPower?: Partial<Record<HarvestTag, number>>;
  attackArcDeg?: number;
  projectileSpeed?: number;
  // Core skill stats (usable immediately when found with charges > 0, C03)
  coreSkill?: CoreSkillId;
  maxCharges?: number;
  canIgniteBrush?: boolean;
  canChopTrees?: boolean;
  // Armor / wearables
  equipSlot?: 'head' | 'body';
  armorDefense?: number;
  coldResist?: number;
  heatResist?: number;
  toxicResist?: number;
  // Consumable stats
  healHp?: number;
  restoreHunger?: number;
  restoreWarmth?: number;
  restoreStamina?: number;
  cureToxicSec?: number;
  // Fuel / blueprint / deployable metadata
  fuelSeconds?: number;
  powerFuelSeconds?: number;
  unlocksRecipeId?: string;
  deploysStructureId?: string;
  studyRecipeId?: string;
}

export interface ItemInstance {
  id: string;
  defId: string;
  qty: number;
  durability?: number;
  charges?: number;
  quality?: 'common' | 'sturdy' | 'relic';
  provenance: string;
  containerId: string;
}

export interface ContainerState {
  id: string;
  kind: 'player_inv' | 'chest' | 'station_in' | 'station_fuel' | 'station_out' | 'cart' | 'drop' | 'death_bag';
  capacitySlots: number;
  slots: (string | null)[];
  ownerEntityId?: string;
}

export interface CustodyState {
  items: Record<string, ItemInstance>;
  containers: Record<string, ContainerState>;
  playerQuickbar: number[]; // indices 0..7 mapping to player_inv slot indices
  equippedHeadId: string | null;
  equippedBodyId: string | null;
  activeQuickSlot: number; // 0..7
}

export type SourceKind =
  | 'pine_tree'
  | 'oak_tree'
  | 'dead_wood'
  | 'boulder'
  | 'iron_vein'
  | 'coal_seam'
  | 'cobalt_crystal'
  | 'sulfur_vent'
  | 'berry_bush'
  | 'marsh_herb'
  | 'peat_bog'
  | 'road_crate'
  | 'oil_barrel'
  | 'industrial_locker'
  | 'poi_exterior_cache'
  | 'poi_deep_locker'
  | 'final72_cash_vault';

export interface SourceNode {
  id: string;
  kind: SourceKind;
  regionId: string;
  poiId?: string;
  requiresDeepAccess?: boolean;
  requiresFinal72?: boolean;
  x: number; // tile + 0.5 world coordinates
  y: number;
  hp: number;
  maxHp: number;
  stock: number;
  maxStock: number;
  requiredTag?: HarvestTag;
  interactionMode: 'harvest_hit' | 'loot_open';
  yieldTable: { defId: string; min: number; max: number; chance: number }[];
  respawnDelaySec: number | null; // null = strictly finite for the entire run
  depletedAtElapsedSec: number | null;
}

export type StructureKind =
  | 'wood_floor'
  | 'stone_floor'
  | 'wood_wall'
  | 'stone_wall'
  | 'wood_door'
  | 'reinforced_door'
  | 'thatch_roof'
  | 'slate_roof'
  | 'homestead_stake'
  | 'bedroll'
  | 'campfire'
  | 'workbench'
  | 'stone_furnace'
  | 'research_table'
  | 'planter_box'
  | 'rain_collector'
  | 'storage_chest'
  | 'spike_barricade'
  | 'generator'
  | 'shock_turret'
  | 'handcart'
  | 'escrow_chest'
  // World-authored entities
  | 'poi_gate'
  | 'poi_power_box'
  | 'vendor_escrow_broker'
  | 'vendor_season_shop'
  | 'evac_beacon'
  | 'world_drop'
  | 'death_bag';

export interface StructureDefinition {
  id: StructureKind;
  name: string;
  category: 'foundation' | 'enclosure' | 'station' | 'storage_utility' | 'defense_transport';
  description: string;
  maxHp: number;
  blocksMovement: boolean;
  isFloor?: boolean;
  isRoof?: boolean;
  isDoor?: boolean;
  requiresOwnedLand?: boolean;
  requiresFloorUnder?: boolean;
  stationTag?: 'campfire' | 'workbench' | 'furnace' | 'research' | 'planter' | 'collector' | 'generator';
  storageSlots?: number;
  reclaimable: boolean;
  buildCost: { defId: string; qty: number }[];
  recipeId?: string; // if locked behind recipe; undefined = baseline buildable
  deployItemId?: string; // if placed by consuming a physical deployable item (e.g. escrow_chest_kit, handcart_kit)
}

export interface StructureEntity {
  id: string;
  kind: StructureKind;
  tileX: number;
  tileY: number;
  x: number; // dynamic world pos (used for moving handcart, drops, bags)
  y: number;
  hp: number;
  maxHp: number;
  owner: 'player' | 'world';
  open?: boolean; // doors & POI gates
  powered?: boolean; // POI gates / turrets
  linkedPoiId?: string;
  requiredKeyDefId?: string; // e.g. 'blue_keycard' or 'copper_fuse'
  containerId?: string;
  fuelContainerId?: string;
  outputContainerId?: string;
  fuelRemainingSec?: number;
  waterStored?: number;
  createdAtSec: number;
  provenance: string;
}

export interface RecipeDefinition {
  id: string;
  name: string;
  category: 'handcraft' | 'workbench' | 'smelting' | 'cooking' | 'farming' | 'utility';
  station: 'none' | 'workbench' | 'campfire' | 'furnace' | 'planter';
  baselineUnlocked: boolean;
  researchTier?: 1 | 2;
  directedSparesCost?: number;
  inputs: { defId: string; qty: number }[];
  output: { defId: string; qty: number };
  workSeconds: number; // 0 = instant hand/bench craft, >0 = physical timed job on station
  requiresFuel?: boolean;
  requiresWater?: boolean;
}

export interface WorkJob {
  id: string;
  stationEntityId: string;
  recipeId: string;
  progressSec: number;
  durationSec: number;
  status: 'RUNNING' | 'PAUSED_NO_FUEL' | 'PAUSED_NO_WATER' | 'PAUSED_OUTPUT_FULL' | 'COMPLETED';
  batchesRemaining: number;
}

export interface FootprintTrace {
  id: string;
  x: number;
  y: number;
  surface: SurfaceType;
  createdAtSec: number;
  expiresAtSec: number;
  strength: number; // 0..1
  nextTraceId: string | null; // forms a directional breadcrumb chain!
}

export type CreatureArchetype =
  | 'wild_boar'
  | 'marsh_kappa'
  | 'ruin_sentinel'
  | 'frost_wolf'
  | 'cinder_crawler'
  | 'blight_husk';

export type ElderId =
  | 'elder_verdant'
  | 'elder_mire'
  | 'elder_glacial'
  | 'elder_caldera'
  | 'elder_ferric'
  | 'elder_abyssal';

export interface ActiveWindup {
  kind: 'melee' | 'projectile' | 'core' | 'evac_channel';
  itemInstanceId: string | null;
  defId: string;
  coreSkill?: CoreSkillId;
  aimAngleRad: number;
  targetX: number;
  targetY: number;
  startedAtMs: number;
  commitAtMs: number;
  endAtMs: number;
  committed: boolean;
  targetEntityId?: string;
}

export interface PlayerActor {
  id: 'player';
  gender: AdventurerGender;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facingRad: number;
  hp: number;
  maxHp: number;
  stamina: number;
  maxStamina: number;
  hunger: number;
  maxHunger: number;
  warmth: number;
  maxWarmth: number;
  toxicShieldSec: number;
  dead: boolean;
  spawnRegionId: string;
  boundBedEntityId: string | null;
  hitchedCartEntityId: string | null;
  lastFootprintPos: { x: number; y: number };
  lastFootprintId: string | null;
  activeWindup: ActiveWindup | null;
  lastAttackCooldownUntilMs: number;
  invulnUntilMs: number;
}

export interface NpcTelegraph {
  kind: 'charge_line' | 'cone_slash' | 'aoe_ring' | 'flame_cone' | 'frost_cross' | 'lightning_arc' | 'spit_lob';
  originX: number;
  originY: number;
  targetX: number;
  targetY: number;
  angleRad: number;
  radiusTiles: number;
  startedAtSec: number;
  commitAtSec: number;
  damage: number;
  ignitesTerrain?: boolean;
  breaksTrees?: boolean;
}

export interface MonsterActor {
  id: string;
  isElder: boolean;
  archetype: CreatureArchetype | ElderId;
  name: string;
  elderForm?: 'latent' | 'awakened';
  stoneDefId?: string;
  x: number;
  y: number;
  homeX: number;
  homeY: number;
  leashRadius: number;
  hp: number;
  maxHp: number;
  speed: number;
  attackDamage: number;
  attackRange: number;
  sightRange: number;
  facingRad: number;
  aiState: 'PATROL' | 'TRACK_TRACE' | 'CHASE' | 'TELEGRAPH' | 'RETURN' | 'DEAD';
  trackingTraceId: string | null;
  patrolTarget: { x: number; y: number } | null;
  telegraph: NpcTelegraph | null;
  cooldownUntilSec: number;
  hitFlashUntilSec: number;
  lootTable: { defId: string; min: number; max: number; chance: number }[];
  lootGranted: boolean;
}

export interface WorldProjectile {
  id: string;
  ownerId: string;
  fromPlayer: boolean;
  kind: 'arrow' | 'volt_bolt' | 'acid_spit' | 'frost_shard' | 'ember_orb';
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  radius: number;
  expiresAtSec: number;
  ignites?: boolean;
}

export interface WorldVfxEvent {
  id: string;
  kind:
    | 'slash_arc'
    | 'hit_spark'
    | 'harvest_chips'
    | 'ember_arc'
    | 'frost_nova'
    | 'thorn_snare'
    | 'volt_lance'
    | 'aegis_pulse'
    | 'gale_dash'
    | 'explosion_ring'
    | 'deposit_gleam'
    | 'floating_text';
  x: number;
  y: number;
  angleRad?: number;
  radius?: number;
  text?: string;
  color?: string;
  createdAtMs: number;
  durationMs: number;
}

export interface PoiSiteMeta {
  id: string;
  name: string;
  kind: 'relay_bunker' | 'quarantine_lab' | 'harbor_depot' | 'quarry_munitions' | 'ragnarok_pavilion' | 'trading_outpost' | 'evac_pier';
  x: number;
  y: number;
  radius: number;
  hasDeepVault: boolean;
  deepKeyHint?: string;
  hasFinal72Vault: boolean;
}

export interface SpawnRegionMeta {
  id: string;
  name: string;
  biome: BiomeId;
  x: number;
  y: number;
  summary: string;
}

export interface HomesteadClaim {
  id: string;
  stakeEntityId: string | null;
  centerX: number;
  centerY: number;
  radiusTiles: number;
}

export interface DynamicFireTile {
  tileX: number;
  tileY: number;
  expiresAtSec: number;
}

export interface WorldState {
  seed: number;
  width: number;
  height: number;
  pois: PoiSiteMeta[];
  spawnRegions: SpawnRegionMeta[];
  elderSites: { elderId: ElderId; name: string; x: number; y: number; biome: BiomeId }[];
  homesteads: HomesteadClaim[];
  footprints: FootprintTrace[];
  fires: DynamicFireTile[];
  scorchedTiles: string[]; // "x,y"
  projectiles: WorldProjectile[];
  vfx: WorldVfxEvent[];
  vendorStocks: {
    escrowBrokerKits: number;
    seasonShop: Record<string, { defId: string; priceSecuredCash: number; stock: number }>;
  };
}

export interface ClockState {
  runStartUtcMs: number;
  lastSettledUtcMs: number;
  qaAcceleratedMs: number;
  isQaAccelerated: boolean;
  elapsedSimSec: number; // total simulated seconds within run
  fictionalDaySec: number; // adjustable fictional day/night clock
  fictionalTimeScale: number;
  weather: WeatherKind;
  weatherRemainingSec: number;
  phase: RunPhase;
}

export interface KnowledgeState {
  unlockedRecipes: string[];
  discoveredPois: string[];
  studiedSpecimens: string[];
  completedOptionalMilestones: string[];
}

export interface ScoreReceipt {
  id: string;
  code: string;
  label: string;
  points: number;
  atElapsedHours: number;
  verification: 'LOCAL_UNVERIFIED';
}

export interface RunHistoryRecord {
  runId: string;
  runNumber: number;
  gender: AdventurerGender;
  spawnRegionName: string;
  startedUtcMs: number;
  endedUtcMs: number;
  elapsedHours: number;
  endReason: RunEndReason;
  cashDepositedThisRun: number;
  unbankedCashLostOnEnd: number;
  eldersDefeated: ElderId[];
  stonesCollected: number;
  totalScore: number;
  verification: 'LOCAL_UNVERIFIED';
  qaUsed: boolean;
}

export interface ProfileState {
  profileId: string;
  securedCash: number;
  achievements: string[];
  runHistory: RunHistoryRecord[];
  totalRunsStarted: number;
}

export interface RunState {
  runId: string;
  runNumber: number;
  active: boolean;
  endReason: RunEndReason | null;
  cashDepositedThisRun: number;
  eldersDefeated: ElderId[];
  scoreReceipts: ScoreReceipt[];
}

export interface CommitReceipt {
  id: string;
  seq: number;
  requestId?: string;
  action: string;
  atSimSec: number;
  summary: string;
}

export interface GameState {
  schemaVersion: 1;
  revision: number;
  rngState: number;
  nextIdCounter: number;
  profile: ProfileState;
  run: RunState;
  clock: ClockState;
  world: WorldState;
  actors: {
    player: PlayerActor;
    monsters: Record<string, MonsterActor>;
  };
  sources: Record<string, SourceNode>;
  entities: Record<string, StructureEntity>;
  custody: CustodyState;
  knowledge: KnowledgeState;
  jobs: Record<string, WorkJob>;
  receipts: CommitReceipt[];
  processedRequestIds: string[];
}

export type GameIntent =
  | { type: 'START_NEW_RUN'; gender: AdventurerGender; spawnRegionId?: string; nowUtcMs: number; requestId?: string }
  | {
      type: 'TICK';
      dtSec: number;
      nowUtcMs: number;
      moveX: number;
      moveY: number;
      aimRad: number;
      aimWorldX: number;
      aimWorldY: number;
    }
  | { type: 'SETTLE_OFFLINE'; nowUtcMs: number; requestId?: string }
  | { type: 'SELECT_QUICKSLOT'; slotIndex: number }
  | { type: 'PRIMARY_ACTION'; aimRad: number; targetWorldX: number; targetWorldY: number; nowMs: number; requestId?: string }
  | { type: 'CANCEL_WINDUP'; reason: string }
  | { type: 'INTERACT_NEAREST'; nowMs: number; requestId?: string }
  | { type: 'USE_ITEM'; instanceId: string; requestId?: string }
  | { type: 'EQUIP_ITEM'; instanceId: string; requestId?: string }
  | { type: 'UNEQUIP_SLOT'; slot: 'head' | 'body'; requestId?: string }
  | {
      type: 'TRANSFER_ITEM';
      instanceId: string;
      toContainerId: string;
      toSlotIndex?: number;
      splitQty?: number;
      requestId?: string;
    }
  | { type: 'DROP_ITEM'; instanceId: string; qty?: number; requestId?: string }
  | { type: 'CRAFT_RECIPE'; recipeId: string; stationEntityId?: string; qty?: number; requestId?: string }
  | { type: 'START_STATION_JOB'; stationEntityId: string; recipeId: string; requestId?: string }
  | {
      type: 'RESEARCH_UNLOCK';
      stationEntityId: string;
      mode: 'random_t1' | 'random_t2' | 'directed' | 'specimen';
      targetRecipeId?: string;
      specimenInstanceId?: string;
      requestId?: string;
    }
  | { type: 'BUILD_STRUCTURE'; structureKind: StructureKind; tileX: number; tileY: number; requestId?: string }
  | { type: 'RECLAIM_STRUCTURE'; entityId: string; requestId?: string }
  | { type: 'REPAIR_STRUCTURE'; entityId: string; requestId?: string }
  | { type: 'TOGGLE_DOOR_OR_GATE'; entityId: string; requestId?: string }
  | { type: 'TOGGLE_CART_HITCH'; cartEntityId: string; requestId?: string }
  | { type: 'RESPAWN_AFTER_DEATH'; useBed: boolean; requestId?: string }
  | { type: 'BUY_ESCROW_CHEST_PHYSICAL'; vendorEntityId: string; requestId?: string }
  | { type: 'DEPOSIT_RAGNAROK_CASH'; escrowEntityId: string; amount?: number; requestId?: string }
  | { type: 'BUY_SEASON_VENDOR_ITEM'; vendorEntityId: string; offerKey: string; requestId?: string }
  | { type: 'BEGIN_EVACUATION'; beaconEntityId: string; nowMs: number; requestId?: string }
  | { type: 'ABANDON_RUN'; nowUtcMs: number; requestId?: string }
  | { type: 'ADJUST_FICTIONAL_CLOCK'; deltaSec: number }
  | {
      type: 'QA_ADVANCE_TIME';
      hours: number;
      forceWeather?: WeatherKind;
      preserveVitals?: boolean;
      requestId?: string;
    };

export interface DispatchResult {
  accepted: boolean;
  state: GameState;
  receipt?: CommitReceipt;
  rejectionReason?: string;
}
