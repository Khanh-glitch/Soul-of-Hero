export interface RngCursor {
  rngState: number;
  nextIdCounter: number;
}

export function createSeededFunction(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function nextFloat(cursor: RngCursor): number {
  let a = (cursor.rngState + 0x6d2b79f5) >>> 0;
  cursor.rngState = a;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

export function nextInt(cursor: RngCursor, minInclusive: number, maxInclusive: number): number {
  if (maxInclusive <= minInclusive) return minInclusive;
  const f = nextFloat(cursor);
  return minInclusive + Math.floor(f * (maxInclusive - minInclusive + 1));
}

export function nextId(cursor: RngCursor, prefix: string): string {
  cursor.nextIdCounter += 1;
  return `${prefix}_${cursor.nextIdCounter}`;
}
