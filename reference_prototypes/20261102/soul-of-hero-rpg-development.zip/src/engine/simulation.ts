import balance from '../data/balance.v1.json';
import { ELDER_STONE_IDS, ITEMS_CATALOG } from '../data/itemsCatalog';
import { BASELINE_RECIPE_IDS, RECIPES_CATALOG } from '../data/recipesCatalog';
import { STRUCTURES_CATALOG } from '../data/structuresCatalog';
import {
  countItemInContainer,
  createContainer,
  debitItemsFromContainer,
  hasItemsInContainer,
  mintNewItemToContainerOrDrop,
} from './custody';
import { findNextPathStep, isTileBlockedForActor } from './pathfinding';
import { nextFloat, nextId, nextInt, RngCursor } from './rng';
import {
  ElderId,
  FootprintTrace,
  GameState,
  MonsterActor,
  NpcTelegraph,
  RunEndReason,
  RunPhase,
  ScoreReceipt,
  WeatherKind,
} from './types';
import { getStaticIslandMap } from './worldGen';

export function getElapsedRunHours(state: GameState): number {
  return state.clock.elapsedSimSec / 3600;
}

export function isInFinal72Hours(state: GameState): boolean {
  const h = getElapsedRunHours(state);
  return h >= balance.clock.ragnarokStartHour && h < balance.clock.maxRunRealHours;
}

export function computeRunPhase(elapsedHours: number, active: boolean): RunPhase {
  if (!active || elapsedHours >= balance.clock.maxRunRealHours) return 'ENDED';
  if (elapsedHours >= balance.clock.elderAwakenHour) return 'ELDER_AWAKENED_D14';
  if (elapsedHours >= balance.clock.ragnarokStartHour) return 'RAGNAROK_72H';
  return 'EXPEDITION';
}

export function isTileOnOwnedLand(state: GameState, tx: number, ty: number): boolean {
  for (const h of state.world.homesteads) {
    if (Math.hypot(tx + 0.5 - h.centerX, ty + 0.5 - h.centerY) <= h.radiusTiles) {
      return true;
    }
  }
  return false;
}

export function isPlayerInLawfulShelter(state: GameState): boolean {
  const px = Math.floor(state.actors.player.x);
  const py = Math.floor(state.actors.player.y);
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0) continue;
    if ((ent.kind === 'thatch_roof' || ent.kind === 'slate_roof') && ent.tileX === px && ent.tileY === py) {
      return true;
    }
  }
  return false;
}

export function isNearLitHeatSource(state: GameState, x: number, y: number): boolean {
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0) continue;
    if (
      (ent.kind === 'campfire' || ent.kind === 'stone_furnace') &&
      (ent.fuelRemainingSec ?? 0) > 0 &&
      Math.hypot(ent.x - x, ent.y - y) <= 4.2
    ) {
      return true;
    }
  }
  return false;
}

export function recordUniqueScore(
  state: GameState,
  cursor: RngCursor,
  code: string,
  label: string,
  points: number
): ScoreReceipt | null {
  if (!state.run.active) return null;
  if (state.run.scoreReceipts.some((r) => r.code === code)) return null;
  const rec: ScoreReceipt = {
    id: nextId(cursor, 'scr'),
    code,
    label,
    points,
    atElapsedHours: Math.round(getElapsedRunHours(state) * 100) / 100,
    verification: 'LOCAL_UNVERIFIED',
  };
  state.run.scoreReceipts.push(rec);
  if (!state.profile.achievements.includes(code)) {
    state.profile.achievements.push(code);
  }
  return rec;
}

export function awakenEldersIfDay14(state: GameState): void {
  if (getElapsedRunHours(state) < balance.clock.elderAwakenHour) return;
  for (const mob of Object.values(state.actors.monsters)) {
    if (mob.isElder && mob.aiState !== 'DEAD' && mob.elderForm === 'latent') {
      mob.elderForm = 'awakened';
      const ratio = mob.hp / Math.max(1, mob.maxHp);
      mob.maxHp = Math.round(mob.maxHp * 1.45);
      mob.hp = Math.round(mob.maxHp * Math.max(0.65, ratio));
      mob.attackDamage = Math.round(mob.attackDamage * 1.35);
      mob.speed = Math.round(mob.speed * 1.18 * 100) / 100;
      mob.sightRange = 12.5;
      mob.leashRadius = 22;
    }
  }
}

export function advanceStationsAndJobs(state: GameState, cursor: RngCursor, dtSec: number): void {
  if (dtSec <= 0) return;

  // 1. Rain Collectors fill clean_water during RAIN / STORM
  if (state.clock.weather === 'RAIN' || state.clock.weather === 'STORM') {
    const rate = state.clock.weather === 'STORM' ? 1.6 : 1.0;
    for (const ent of Object.values(state.entities)) {
      if (ent.hp <= 0 || ent.kind !== 'rain_collector' || !ent.outputContainerId) continue;
      ent.waterStored = (ent.waterStored ?? 0) + dtSec * rate;
      while ((ent.waterStored ?? 0) >= 35) {
        const res = mintNewItemToContainerOrDrop(
          state,
          cursor,
          ent.outputContainerId,
          'clean_water',
          1,
          `collector:${ent.id}`
        );
        if (res.placedQty === 0) {
          ent.waterStored = 35; // output full, cap reservoir
          break;
        }
        ent.waterStored! -= 35;
      }
    }
  }

  // 2. Generators burn physical fuel to power nearby Shock Turrets
  const activeGenerators: { x: number; y: number }[] = [];
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0 || ent.kind !== 'generator') continue;
    let remStep = dtSec;
    while (remStep > 0) {
      if ((ent.fuelRemainingSec ?? 0) <= 0 && ent.fuelContainerId) {
        // Try pulling one fuel item from fuel container
        const fc = state.custody.containers[ent.fuelContainerId];
        if (fc) {
          let consumed = false;
          for (const slotId of fc.slots) {
            if (!slotId) continue;
            const inst = state.custody.items[slotId];
            if (!inst) continue;
            const def = ITEMS_CATALOG[inst.defId];
            const pSec = def?.powerFuelSeconds ?? def?.fuelSeconds ?? 0;
            if (pSec > 0 && debitItemsFromContainer(state, ent.fuelContainerId, [{ defId: inst.defId, qty: 1 }])) {
              ent.fuelRemainingSec = (ent.fuelRemainingSec ?? 0) + pSec;
              consumed = true;
              break;
            }
          }
          if (!consumed) break;
        } else {
          break;
        }
      }
      if ((ent.fuelRemainingSec ?? 0) <= 0) break;
      const burn = Math.min(remStep, ent.fuelRemainingSec ?? 0);
      ent.fuelRemainingSec = (ent.fuelRemainingSec ?? 0) - burn;
      remStep -= burn;
    }
    if ((ent.fuelRemainingSec ?? 0) > 0) {
      activeGenerators.push({ x: ent.x, y: ent.y });
    }
  }

  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0 || ent.kind !== 'shock_turret') continue;
    ent.powered = activeGenerators.some((g) => Math.hypot(g.x - ent.x, g.y - ent.y) <= 7.5);
  }

  // 3. Burn passive campfire fuel if lit even without an active cooking job (provides warmth!)
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0 || (ent.kind !== 'campfire' && ent.kind !== 'stone_furnace')) continue;
    const hasRunningJob = Object.values(state.jobs).some(
      (j) => j.stationEntityId === ent.id && j.status === 'RUNNING'
    );
    if (!hasRunningJob && (ent.fuelRemainingSec ?? 0) > 0) {
      ent.fuelRemainingSec = Math.max(0, (ent.fuelRemainingSec ?? 0) - dtSec);
    }
  }

  // 4. Settle Workstation Jobs Chronologically (Stops strictly on fuel/water exhaustion! C06)
  for (const job of Object.values(state.jobs)) {
    if (job.status === 'COMPLETED' || job.batchesRemaining <= 0) continue;
    const station = state.entities[job.stationEntityId];
    const recipe = RECIPES_CATALOG[job.recipeId];
    if (!station || station.hp <= 0 || !recipe || !station.containerId || !station.outputContainerId) {
      delete state.jobs[job.id];
      continue;
    }

    let timeBudget = dtSec;
    let safety = 0;

    while (timeBudget > 0.0001 && job.batchesRemaining > 0 && safety++ < 200) {
      // Ensure inputs are still present before finishing/starting a batch
      if (job.progressSec === 0 && !hasItemsInContainer(state, station.containerId, recipe.inputs)) {
        job.batchesRemaining = 0;
        job.status = 'COMPLETED';
        break;
      }

      // Check output space
      const outCont = state.custody.containers[station.outputContainerId];
      const outDef = ITEMS_CATALOG[recipe.output.defId];
      const canFitOutput =
        outCont &&
        outDef &&
        outCont.slots.some((s) => {
          if (s === null) return true;
          const it = state.custody.items[s];
          return it && it.defId === recipe.output.defId && it.qty + recipe.output.qty <= outDef.maxStack;
        });
      if (!canFitOutput) {
        job.status = 'PAUSED_OUTPUT_FULL';
        break;
      }

      // Resource gate: Fuel or Water
      let availableResourceSec = timeBudget;
      if (recipe.requiresFuel) {
        if ((station.fuelRemainingSec ?? 0) <= 0 && station.fuelContainerId) {
          const fc = state.custody.containers[station.fuelContainerId];
          if (fc) {
            for (const sId of fc.slots) {
              if (!sId) continue;
              const inst = state.custody.items[sId];
              const fSec = inst ? ITEMS_CATALOG[inst.defId]?.fuelSeconds ?? 0 : 0;
              if (inst && fSec > 0) {
                debitItemsFromContainer(state, station.fuelContainerId, [{ defId: inst.defId, qty: 1 }]);
                station.fuelRemainingSec = (station.fuelRemainingSec ?? 0) + fSec;
                break;
              }
            }
          }
        }
        if ((station.fuelRemainingSec ?? 0) <= 0) {
          job.status = 'PAUSED_NO_FUEL';
          break;
        }
        availableResourceSec = Math.min(timeBudget, station.fuelRemainingSec ?? 0);
      } else if (recipe.requiresWater) {
        const raining = state.clock.weather === 'RAIN' || state.clock.weather === 'STORM';
        if (!raining && (station.waterStored ?? 0) <= 0 && station.fuelContainerId) {
          if (countItemInContainer(state, station.fuelContainerId, 'clean_water') >= 1) {
            debitItemsFromContainer(state, station.fuelContainerId, [{ defId: 'clean_water', qty: 1 }]);
            station.waterStored = (station.waterStored ?? 0) + 35;
          }
        }
        if (!raining && (station.waterStored ?? 0) <= 0) {
          job.status = 'PAUSED_NO_WATER';
          break;
        }
        availableResourceSec = raining ? timeBudget : Math.min(timeBudget, station.waterStored ?? 0);
      }

      job.status = 'RUNNING';
      const neededForBatch = Math.max(0.001, job.durationSec - job.progressSec);
      const step = Math.min(availableResourceSec, neededForBatch);

      job.progressSec += step;
      timeBudget -= step;
      if (recipe.requiresFuel) {
        station.fuelRemainingSec = Math.max(0, (station.fuelRemainingSec ?? 0) - step);
      } else if (recipe.requiresWater && state.clock.weather !== 'RAIN' && state.clock.weather !== 'STORM') {
        station.waterStored = Math.max(0, (station.waterStored ?? 0) - step);
      }

      if (job.progressSec + 0.0001 >= job.durationSec) {
        // Atomically debit input & produce output in physical station slot!
        if (debitItemsFromContainer(state, station.containerId, recipe.inputs)) {
          mintNewItemToContainerOrDrop(
            state,
            cursor,
            station.outputContainerId,
            recipe.output.defId,
            recipe.output.qty,
            `job:${station.kind}:${recipe.id}`
          );
        }
        job.progressSec = 0;
        if (hasItemsInContainer(state, station.containerId, recipe.inputs)) {
          job.batchesRemaining = Math.max(1, job.batchesRemaining - 1);
        } else {
          job.batchesRemaining = 0;
          job.status = 'COMPLETED';
          break;
        }
      }
    }
  }
}

export function advanceEnvironmentAndSources(state: GameState, cursor: RngCursor, dtSec: number): void {
  if (dtSec <= 0) return;
  const map = getStaticIslandMap(state.world.seed);

  // 1. Weather Clock
  state.clock.weatherRemainingSec -= dtSec;
  if (state.clock.weatherRemainingSec <= 0) {
    const roll = nextFloat(cursor);
    const inRag = isInFinal72Hours(state);
    let nextW: WeatherKind = 'CLEAR';
    if (inRag) {
      if (roll < 0.25) nextW = 'STORM';
      else if (roll < 0.5) nextW = 'ASH_WIND';
      else if (roll < 0.72) nextW = 'RAIN';
      else if (roll < 0.86) nextW = 'COLD_SNAP';
      else nextW = 'CLEAR';
    } else {
      if (roll < 0.46) nextW = 'CLEAR';
      else if (roll < 0.72) nextW = 'RAIN';
      else if (roll < 0.84) nextW = 'STORM';
      else if (roll < 0.93) nextW = 'COLD_SNAP';
      else nextW = 'ASH_WIND';
    }
    state.clock.weather = nextW;
    state.clock.weatherRemainingSec = balance.tracesAndWeather.weatherCycleBaseSec * (0.7 + nextFloat(cursor) * 0.7);
  }

  // 2. Footprint Trace Decay (Rain & Storm accelerate decay dramatically! C08, C14)
  const decayMult =
    state.clock.weather === 'STORM'
      ? balance.tracesAndWeather.stormTraceDecayMultiplier
      : state.clock.weather === 'RAIN'
      ? balance.tracesAndWeather.rainTraceDecayMultiplier
      : 1.0;

  if (state.world.footprints.length > 0) {
    const extraErode = (decayMult - 1.0) * dtSec;
    const nowSec = state.clock.elapsedSimSec;
    const survivingIds = new Set<string>();
    const kept: FootprintTrace[] = [];
    for (const fp of state.world.footprints) {
      fp.expiresAtSec -= extraErode;
      const totalLife = Math.max(1, fp.expiresAtSec - fp.createdAtSec);
      const rem = fp.expiresAtSec - nowSec;
      if (rem > 0) {
        fp.strength = Math.max(0.05, Math.min(1, rem / totalLife));
        kept.push(fp);
        survivingIds.add(fp.id);
      }
    }
    for (const fp of kept) {
      if (fp.nextTraceId && !survivingIds.has(fp.nextTraceId)) {
        fp.nextTraceId = null;
      }
    }
    state.world.footprints = kept;
  }

  // 3. Dynamic Ground Fires (Extinguished by rain, bounded spread on flammable brush, damages trees/wood walls, C05)
  if (state.world.fires.length > 0) {
    const wet = state.clock.weather === 'RAIN' || state.clock.weather === 'STORM';
    const nextFires = [];
    for (const f of state.world.fires) {
      if (wet) f.expiresAtSec -= dtSec * 3.5;
      if (f.expiresAtSec > state.clock.elapsedSimSec) {
        nextFires.push(f);
        const key = `${f.tileX},${f.tileY}`;
        if (!state.world.scorchedTiles.includes(key) && state.world.scorchedTiles.length < 400) {
          state.world.scorchedTiles.push(key);
        }
        // Damage flammable wood structures or trees on that tile
        for (const s of Object.values(state.sources)) {
          if (
            s.stock > 0 &&
            (s.kind === 'pine_tree' || s.kind === 'oak_tree' || s.kind === 'berry_bush') &&
            Math.floor(s.x) === f.tileX &&
            Math.floor(s.y) === f.tileY
          ) {
            s.hp -= 12 * dtSec;
            if (s.hp <= 0) {
              s.stock = 0;
              s.depletedAtElapsedSec = state.clock.elapsedSimSec;
              mintNewItemToContainerOrDrop(state, cursor, '__none__', 'coal_lump', 1, 'fire_char', {
                x: s.x,
                y: s.y,
              });
            }
          }
        }
        // Bounded 1-tile spread chance on dry flammable tiles
        if (!wet && state.world.fires.length < 18 && nextFloat(cursor) < 0.12 * dtSec) {
          const dirs = [
            [1, 0],
            [-1, 0],
            [0, 1],
            [0, -1],
          ];
          const [dx, dy] = dirs[nextInt(cursor, 0, 3)];
          const nx = f.tileX + dx;
          const ny = f.tileY + dy;
          if (nx > 2 && ny > 2 && nx < map.width - 2 && ny < map.height - 2) {
            if (
              map.flammable[ny * map.width + nx] &&
              !state.world.fires.some((ef) => ef.tileX === nx && ef.tileY === ny)
            ) {
              nextFires.push({
                tileX: nx,
                tileY: ny,
                expiresAtSec: state.clock.elapsedSimSec + 7,
              });
            }
          }
        }
      }
    }
    state.world.fires = nextFires;
  }

  // 4. Lawful Renewable Natural Sources (Never respawns finite road crates, POI caches, or Final-72 vaults! C14, C15)
  const rainBoost = state.clock.weather === 'RAIN' ? 0.8 : 1.0;
  for (const s of Object.values(state.sources)) {
    if (s.stock <= 0 && s.respawnDelaySec !== null && s.depletedAtElapsedSec !== null) {
      const delay =
        s.kind === 'berry_bush' || s.kind === 'marsh_herb' ? s.respawnDelaySec * rainBoost : s.respawnDelaySec;
      if (state.clock.elapsedSimSec - s.depletedAtElapsedSec >= delay) {
        s.stock = s.maxStock;
        s.hp = s.maxHp;
        s.depletedAtElapsedSec = null;
      }
    }
  }
}

export function handlePlayerDeath(state: GameState, cursor: RngCursor, cause: string): void {
  const player = state.actors.player;
  if (player.dead) return;
  player.hp = 0;
  player.dead = true;
  player.activeWindup = null;
  player.hitchedCartEntityId = null;

  // Move all eligible carried items in player_inv ONCE into a unique physical Death Bag at coordinates (C10!)
  const inv = state.custody.containers['player_inv'];
  const carriedIds: string[] = [];
  if (inv) {
    for (let i = 0; i < inv.slots.length; i++) {
      const id = inv.slots[i];
      if (id && state.custody.items[id]) {
        carriedIds.push(id);
        inv.slots[i] = null;
      }
    }
  }

  if (carriedIds.length > 0) {
    const bagEntId = nextId(cursor, 'bag');
    const bagContId = `bag:${bagEntId}`;
    const bagCont = createContainer(bagContId, 'death_bag', Math.max(8, carriedIds.length), bagEntId);
    for (let i = 0; i < carriedIds.length; i++) {
      const inst = state.custody.items[carriedIds[i]];
      if (inst) {
        inst.containerId = bagContId;
        bagCont.slots[i] = inst.id;
      }
    }
    state.custody.containers[bagContId] = bagCont;
    state.entities[bagEntId] = {
      id: bagEntId,
      kind: 'death_bag',
      tileX: Math.floor(player.x),
      tileY: Math.floor(player.y),
      x: player.x,
      y: player.y,
      hp: 9999,
      maxHp: 9999,
      owner: 'player',
      containerId: bagContId,
      createdAtSec: state.clock.elapsedSimSec,
      provenance: `death:${cause}`,
    };
  }
}

export function advancePlayerSurvival(
  state: GameState,
  cursor: RngCursor,
  dtSec: number,
  isOfflineCatchup: boolean
): void {
  const player = state.actors.player;
  if (player.dead || !state.run.active || dtSec <= 0) return;

  const map = getStaticIslandMap(state.world.seed);
  const tx = Math.max(0, Math.min(map.width - 1, Math.floor(player.x)));
  const ty = Math.max(0, Math.min(map.height - 1, Math.floor(player.y)));
  const biome = map.biomes[ty * map.width + tx];
  const sheltered = isPlayerInLawfulShelter(state);
  const warmed = isNearLitHeatSource(state, player.x, player.y);

  const headDef = state.custody.equippedHeadId
    ? ITEMS_CATALOG[state.custody.items[state.custody.equippedHeadId]?.defId ?? '']
    : undefined;
  const bodyDef = state.custody.equippedBodyId
    ? ITEMS_CATALOG[state.custody.items[state.custody.equippedBodyId]?.defId ?? '']
    : undefined;

  const coldResist = Math.min(0.95, (headDef?.coldResist ?? 0) + (bodyDef?.coldResist ?? 0));
  const heatResist = Math.min(0.9, (headDef?.heatResist ?? 0) + (bodyDef?.heatResist ?? 0));
  const toxicResist = Math.min(0.95, (headDef?.toxicResist ?? 0) + (bodyDef?.toxicResist ?? 0));

  if (player.toxicShieldSec > 0) {
    player.toxicShieldSec = Math.max(0, player.toxicShieldSec - dtSec);
  }

  // Stamina regeneration
  if (!isOfflineCatchup) {
    player.stamina = Math.min(
      player.maxStamina,
      player.stamina + balance.survival.staminaRegenPerSecond * dtSec
    );
  }

  // Hunger drain (elevated in scorching Caldera unless heat-resistant)
  const isHot = biome === 'caldera' || state.clock.weather === 'ASH_WIND';
  const heatMult = isHot ? 1 + (balance.survival.heatHungerMultiplier - 1) * (1 - heatResist) : 1.0;
  const hungerLoss = (balance.survival.hungerDrainPerMinute / 60) * heatMult * dtSec;
  player.hunger = Math.max(0, player.hunger - hungerLoss);

  // Starvation damage — Offline lawful shelter enforces min 1 HP from hunger alone ([CHỐT] C09!)
  if (player.hunger <= 0) {
    const starveDmg = (balance.survival.starvationHpDrainPerMinute / 60) * dtSec;
    if (isOfflineCatchup && sheltered) {
      if (player.hp > balance.survival.offlineShelterHungerMinHp) {
        player.hp = Math.max(balance.survival.offlineShelterHungerMinHp, player.hp - starveDmg);
      }
    } else {
      player.hp -= starveDmg;
      if (player.hp <= 0) {
        handlePlayerDeath(state, cursor, 'starvation');
        return;
      }
    }
  }

  // Cold / Warmth physics
  const isCold = biome === 'tundra' || state.clock.weather === 'COLD_SNAP';
  if (warmed) {
    player.warmth = Math.min(player.maxWarmth, player.warmth + 18 * dtSec);
  } else if (isCold) {
    const shelterFactor = sheltered ? 0.55 : 1.0;
    const chill =
      (balance.survival.coldWarmthDrainPerMinute / 60) * (1 - coldResist) * shelterFactor * dtSec;
    player.warmth = Math.max(0, player.warmth - chill);
  } else {
    player.warmth = Math.min(player.maxWarmth, player.warmth + 6 * dtSec);
  }

  if (player.warmth <= 0) {
    const freezeDmg = (balance.survival.freezingHpDrainPerMinute / 60) * dtSec;
    player.hp -= freezeDmg;
    if (player.hp <= 0) {
      handlePlayerDeath(state, cursor, 'hypothermia');
      return;
    }
  }

  // Toxic Industrial / Quarantine Ward exposure
  const inQuarantineVault = state.world.pois.some(
    (p) => p.kind === 'quarantine_lab' && Math.abs(player.x - p.x) <= 2 && player.y <= p.y && player.y >= p.y - 4
  );
  if ((biome === 'industrial' || inQuarantineVault) && player.toxicShieldSec <= 0) {
    if (toxicResist < 0.8) {
      const toxDmg = balance.survival.toxicHpDrainPerSecond * (1 - toxicResist) * dtSec;
      player.hp -= toxDmg;
      if (player.hp <= 0) {
        handlePlayerDeath(state, cursor, 'toxic_exposure');
        return;
      }
    }
  }

  // Standing in active ground fire
  if (state.world.fires.some((f) => f.tileX === tx && f.tileY === ty)) {
    player.hp -= 14 * dtSec;
    if (player.hp <= 0) {
      handlePlayerDeath(state, cursor, 'fire');
      return;
    }
  }
}

export function applyDamageToPlayer(
  state: GameState,
  cursor: RngCursor,
  rawDamage: number,
  fromX: number,
  fromY: number,
  nowMs: number,
  cause: string
): number {
  const player = state.actors.player;
  if (player.dead || nowMs < player.invulnUntilMs) return 0;

  const headDef = state.custody.equippedHeadId
    ? ITEMS_CATALOG[state.custody.items[state.custody.equippedHeadId]?.defId ?? '']
    : undefined;
  const bodyDef = state.custody.equippedBodyId
    ? ITEMS_CATALOG[state.custody.items[state.custody.equippedBodyId]?.defId ?? '']
    : undefined;
  const armor = (headDef?.armorDefense ?? 0) + (bodyDef?.armorDefense ?? 0);
  const dmg = Math.max(2, Math.round(rawDamage * (100 / (100 + armor * 2.5))));

  player.hp -= dmg;
  player.invulnUntilMs = nowMs + 340;

  // Interrupt evac channel if hit
  if (player.activeWindup?.kind === 'evac_channel') {
    player.activeWindup = null;
  }

  // Knockback impulse
  const ang = Math.atan2(player.y - fromY, player.x - fromX);
  player.vx += Math.cos(ang) * 4.2;
  player.vy += Math.sin(ang) * 4.2;

  state.world.vfx.push({
    id: nextId(cursor, 'vfx'),
    kind: 'floating_text',
    x: player.x,
    y: player.y - 0.5,
    text: `-${dmg}`,
    color: '#ff5964',
    createdAtMs: nowMs,
    durationMs: 650,
  });

  if (player.hp <= 0) {
    handlePlayerDeath(state, cursor, cause);
  }
  return dmg;
}

function hasClearSightLine(state: GameState, x0: number, y0: number, x1: number, y1: number): boolean {
  const map = getStaticIslandMap(state.world.seed);
  const d = Math.hypot(x1 - x0, y1 - y0);
  const steps = Math.ceil(d * 2);
  for (let s = 1; s < steps; s++) {
    const t = s / steps;
    const tx = Math.floor(x0 + (x1 - x0) * t);
    const ty = Math.floor(y0 + (y1 - y0) * t);
    if (map.elevation[ty * map.width + tx] === 3) return false;
    for (const ent of Object.values(state.entities)) {
      if (ent.hp <= 0 || ent.tileX !== tx || ent.tileY !== ty) continue;
      if (ent.kind === 'wood_wall' || ent.kind === 'stone_wall') return false;
      if ((ent.kind === 'wood_door' || ent.kind === 'reinforced_door' || ent.kind === 'poi_gate') && !ent.open) {
        return false;
      }
    }
  }
  return true;
}

export function advanceMonstersAndCombat(
  state: GameState,
  cursor: RngCursor,
  dtSec: number,
  nowMs: number
): void {
  const player = state.actors.player;
  const nowSec = state.clock.elapsedSimSec;
  const map = getStaticIslandMap(state.world.seed);

  // 1. Powered Shock Turrets fire at nearby hostile monsters
  for (const turret of Object.values(state.entities)) {
    if (turret.hp <= 0 || turret.kind !== 'shock_turret' || !turret.powered) continue;
    // Use waterStored field as cooldown timestamp on turret
    if ((turret.waterStored ?? 0) > nowSec) continue;
    let nearest: MonsterActor | null = null;
    let bestD = 6.5;
    for (const mob of Object.values(state.actors.monsters)) {
      if (mob.aiState === 'DEAD') continue;
      const d = Math.hypot(mob.x - turret.x, mob.y - turret.y);
      if (d < bestD) {
        bestD = d;
        nearest = mob;
      }
    }
    if (nearest) {
      turret.waterStored = nowSec + 1.8;
      const ang = Math.atan2(nearest.y - turret.y, nearest.x - turret.x);
      state.world.projectiles.push({
        id: nextId(cursor, 'prj'),
        ownerId: turret.id,
        fromPlayer: true,
        kind: 'volt_bolt',
        x: turret.x,
        y: turret.y,
        vx: Math.cos(ang) * 12,
        vy: Math.sin(ang) * 12,
        damage: 24,
        radius: 0.35,
        expiresAtSec: nowSec + 1.1,
      });
    }
  }

  // 2. Advance Projectiles
  if (state.world.projectiles.length > 0) {
    const remProj = [];
    for (const p of state.world.projectiles) {
      p.x += p.vx * dtSec;
      p.y += p.vy * dtSec;
      if (p.expiresAtSec <= nowSec) continue;
      const tx = Math.floor(p.x);
      const ty = Math.floor(p.y);
      if (tx < 1 || ty < 1 || tx >= map.width - 1 || ty >= map.height - 1) continue;
      if (map.elevation[ty * map.width + tx] === 3) continue;

      let hit = false;
      if (p.fromPlayer) {
        for (const mob of Object.values(state.actors.monsters)) {
          if (mob.aiState === 'DEAD') continue;
          const hitR = (mob.isElder ? 0.95 : 0.55) + p.radius;
          if (Math.hypot(mob.x - p.x, mob.y - p.y) <= hitR) {
            damageMonster(state, cursor, mob, p.damage, p.x, p.y, nowMs);
            hit = true;
            break;
          }
        }
        // Volt bolt can also energize an unpowered POI junction box!
        if (!hit && p.kind === 'volt_bolt') {
          for (const ent of Object.values(state.entities)) {
            if (ent.kind === 'poi_power_box' && !ent.powered && Math.hypot(ent.x - p.x, ent.y - p.y) <= 0.9) {
              ent.powered = true;
              for (const g of Object.values(state.entities)) {
                if (g.kind === 'poi_gate' && g.linkedPoiId === ent.linkedPoiId) {
                  g.powered = true;
                  g.open = true;
                }
              }
              hit = true;
              break;
            }
          }
        }
      } else if (!player.dead) {
        if (Math.hypot(player.x - p.x, player.y - p.y) <= 0.5 + p.radius) {
          applyDamageToPlayer(state, cursor, p.damage, p.x, p.y, nowMs, 'projectile');
          if (p.ignites && map.flammable[ty * map.width + tx]) {
            state.world.fires.push({ tileX: tx, tileY: ty, expiresAtSec: nowSec + 7 });
          }
          hit = true;
        }
      }
      if (!hit) remProj.push(p);
    }
    state.world.projectiles = remProj;
  }

  // 3. Advance Monsters & Elders (Lawful Sight + Footprint Trace Tracking ONLY — Never Home GPS! C08, C19)
  const traceById = new Map<string, FootprintTrace>();
  for (const fp of state.world.footprints) traceById.set(fp.id, fp);

  for (const mob of Object.values(state.actors.monsters)) {
    if (mob.aiState === 'DEAD') continue;

    // Only simulate active AI within 38 tiles of player or while tracking a trace
    const distToPlayer = Math.hypot(player.x - mob.x, player.y - mob.y);
    if (distToPlayer > 38 && mob.aiState === 'PATROL') continue;

    // Resolve active telegraph windup
    if (mob.aiState === 'TELEGRAPH' && mob.telegraph) {
      const tel = mob.telegraph;
      if (nowSec >= tel.commitAtSec) {
        commitMonsterTelegraph(state, cursor, mob, tel, nowMs);
        mob.telegraph = null;
        mob.cooldownUntilSec = nowSec + (mob.isElder ? (mob.elderForm === 'awakened' ? 1.5 : 2.1) : 1.35);
        mob.aiState = 'CHASE';
      }
      continue;
    }

    const canSeePlayer =
      !player.dead &&
      distToPlayer <= mob.sightRange &&
      hasClearSightLine(state, mob.x, mob.y, player.x, player.y);

    if (canSeePlayer) {
      mob.aiState = 'CHASE';
      mob.trackingTraceId = null;
    } else if (mob.aiState === 'CHASE') {
      // Lost direct line of sight: check for nearby fresh footprint within 3 tiles to continue tracking
      const nearbyFp = findFreshestFootprintNear(state.world.footprints, mob.x, mob.y, 3.2);
      if (nearbyFp) {
        mob.aiState = 'TRACK_TRACE';
        mob.trackingTraceId = nearbyFp.id;
      } else {
        mob.aiState = 'RETURN';
      }
    } else if (mob.aiState === 'PATROL') {
      // Check if monster physically encounters an unexpired player footprint in its habitat! (C08)
      const encounteredFp = findFreshestFootprintNear(state.world.footprints, mob.x, mob.y, 2.7);
      if (encounteredFp) {
        mob.aiState = 'TRACK_TRACE';
        mob.trackingTraceId = encounteredFp.id;
      }
    }

    if (mob.aiState === 'CHASE' && !player.dead) {
      mob.facingRad = Math.atan2(player.y - mob.y, player.x - mob.x);

      // Start telegraph attack if in range and off cooldown
      if (distToPlayer <= mob.attackRange && nowSec >= mob.cooldownUntilSec) {
        mob.telegraph = buildMonsterTelegraph(mob, player.x, player.y, nowSec, cursor);
        mob.aiState = 'TELEGRAPH';
        continue;
      }

      // Navigate toward visible player respecting walls/doors
      moveMonsterToward(state, cursor, mob, player.x, player.y, dtSec, nowSec);
    } else if (mob.aiState === 'TRACK_TRACE') {
      const fp = mob.trackingTraceId ? traceById.get(mob.trackingTraceId) : undefined;
      if (!fp) {
        // Trail decayed (e.g. washed away by rain!) -> Monster loses trail and returns to habitat! (C08)
        mob.trackingTraceId = null;
        mob.aiState = 'RETURN';
      } else {
        const dFp = Math.hypot(fp.x - mob.x, fp.y - mob.y);
        if (dFp <= 0.75) {
          if (fp.nextTraceId && traceById.has(fp.nextTraceId)) {
            mob.trackingTraceId = fp.nextTraceId;
          } else {
            // Reached end of footprint trail without spotting player
            mob.trackingTraceId = null;
            mob.aiState = 'RETURN';
          }
        } else {
          moveMonsterToward(state, cursor, mob, fp.x, fp.y, dtSec, nowSec);
        }
      }
    } else if (mob.aiState === 'RETURN') {
      const dHome = Math.hypot(mob.homeX - mob.x, mob.homeY - mob.y);
      if (dHome <= 1.0) {
        mob.aiState = 'PATROL';
      } else {
        moveMonsterToward(state, cursor, mob, mob.homeX, mob.homeY, dtSec, nowSec);
      }
    } else if (mob.aiState === 'PATROL') {
      if (!mob.patrolTarget || Math.hypot(mob.patrolTarget.x - mob.x, mob.patrolTarget.y - mob.y) < 0.8) {
        const ang = nextFloat(cursor) * Math.PI * 2;
        const r = 1.5 + nextFloat(cursor) * 3.5;
        mob.patrolTarget = {
          x: mob.homeX + Math.cos(ang) * r,
          y: mob.homeY + Math.sin(ang) * r,
        };
      }
      moveMonsterToward(state, cursor, mob, mob.patrolTarget.x, mob.patrolTarget.y, dtSec * 0.55, nowSec);
    }
  }
}

function findFreshestFootprintNear(
  footprints: FootprintTrace[],
  x: number,
  y: number,
  radius: number
): FootprintTrace | null {
  let best: FootprintTrace | null = null;
  for (const fp of footprints) {
    if (Math.hypot(fp.x - x, fp.y - y) <= radius) {
      if (!best || fp.createdAtSec > best.createdAtSec) {
        best = fp;
      }
    }
  }
  return best;
}

function moveMonsterToward(
  state: GameState,
  cursor: RngCursor,
  mob: MonsterActor,
  goalX: number,
  goalY: number,
  dtSec: number,
  nowSec: number
): void {
  const step = findNextPathStep(state, mob.x, mob.y, goalX, goalY, 90);
  if (step.blockingStructure) {
    const st = step.blockingStructure;
    const dSt = Math.hypot(st.x - mob.x, st.y - mob.y);
    if (dSt <= 1.65) {
      if (nowSec >= mob.cooldownUntilSec) {
        st.hp -= mob.attackDamage;
        mob.cooldownUntilSec = nowSec + 1.25;
        if (st.kind === 'spike_barricade') {
          damageMonster(state, cursor, mob, 14, st.x, st.y, Date.now());
        }
        if (st.hp <= 0) {
          destroyStructureConservingContents(state, cursor, st.id);
        }
      }
      return;
    }
  }

  const tx = step.nextX;
  const ty = step.nextY;
  const ang = Math.atan2(ty - mob.y, tx - mob.x);
  mob.facingRad = ang;
  const map = getStaticIslandMap(state.world.seed);
  const nx = mob.x + Math.cos(ang) * mob.speed * dtSec;
  const ny = mob.y + Math.sin(ang) * mob.speed * dtSec;

  if (!isTileBlockedForActor(map, state, Math.floor(nx), Math.floor(mob.y)).blocked) {
    mob.x = nx;
  }
  if (!isTileBlockedForActor(map, state, Math.floor(mob.x), Math.floor(ny)).blocked) {
    mob.y = ny;
  }
}

function buildMonsterTelegraph(
  mob: MonsterActor,
  targetX: number,
  targetY: number,
  nowSec: number,
  cursor: RngCursor
): NpcTelegraph {
  const ang = Math.atan2(targetY - mob.y, targetX - mob.x);
  const awakened = mob.elderForm === 'awakened';

  if (mob.isElder) {
    const roll = nextFloat(cursor);
    switch (mob.archetype as ElderId) {
      case 'elder_verdant':
        return {
          kind: roll < 0.5 ? 'charge_line' : 'aoe_ring',
          originX: mob.x,
          originY: mob.y,
          targetX,
          targetY,
          angleRad: ang,
          radiusTiles: awakened ? 3.2 : 2.5,
          startedAtSec: nowSec,
          commitAtSec: nowSec + (awakened ? 0.65 : 0.8),
          damage: mob.attackDamage,
          breaksTrees: true,
        };
      case 'elder_mire':
        return {
          kind: roll < 0.55 ? 'spit_lob' : 'aoe_ring',
          originX: mob.x,
          originY: mob.y,
          targetX,
          targetY,
          angleRad: ang,
          radiusTiles: awakened ? 3.0 : 2.3,
          startedAtSec: nowSec,
          commitAtSec: nowSec + 0.75,
          damage: mob.attackDamage,
        };
      case 'elder_glacial':
        return {
          kind: 'frost_cross',
          originX: mob.x,
          originY: mob.y,
          targetX,
          targetY,
          angleRad: ang,
          radiusTiles: awakened ? 3.8 : 3.0,
          startedAtSec: nowSec,
          commitAtSec: nowSec + 0.72,
          damage: mob.attackDamage,
        };
      case 'elder_caldera':
        return {
          kind: 'flame_cone',
          originX: mob.x,
          originY: mob.y,
          targetX,
          targetY,
          angleRad: ang,
          radiusTiles: awakened ? 4.0 : 3.2,
          startedAtSec: nowSec,
          commitAtSec: nowSec + 0.78,
          damage: mob.attackDamage,
          ignitesTerrain: true,
        };
      case 'elder_ferric':
        return {
          kind: 'lightning_arc',
          originX: mob.x,
          originY: mob.y,
          targetX,
          targetY,
          angleRad: ang,
          radiusTiles: awakened ? 4.2 : 3.3,
          startedAtSec: nowSec,
          commitAtSec: nowSec + 0.7,
          damage: mob.attackDamage,
        };
      case 'elder_abyssal':
        return {
          kind: roll < 0.5 ? 'cone_slash' : 'aoe_ring',
          originX: mob.x,
          originY: mob.y,
          targetX,
          targetY,
          angleRad: ang,
          radiusTiles: awakened ? 3.6 : 2.8,
          startedAtSec: nowSec,
          commitAtSec: nowSec + 0.72,
          damage: mob.attackDamage,
        };
    }
  }

  // Distinct tells per common creature archetype
  if (mob.archetype === 'wild_boar' || mob.archetype === 'frost_wolf') {
    return {
      kind: 'charge_line',
      originX: mob.x,
      originY: mob.y,
      targetX,
      targetY,
      angleRad: ang,
      radiusTiles: 2.2,
      startedAtSec: nowSec,
      commitAtSec: nowSec + 0.52,
      damage: mob.attackDamage,
    };
  }
  if (mob.archetype === 'marsh_kappa' || mob.archetype === 'blight_husk') {
    return {
      kind: 'spit_lob',
      originX: mob.x,
      originY: mob.y,
      targetX,
      targetY,
      angleRad: ang,
      radiusTiles: 1.6,
      startedAtSec: nowSec,
      commitAtSec: nowSec + 0.58,
      damage: mob.attackDamage,
    };
  }
  if (mob.archetype === 'cinder_crawler') {
    return {
      kind: 'flame_cone',
      originX: mob.x,
      originY: mob.y,
      targetX,
      targetY,
      angleRad: ang,
      radiusTiles: 2.1,
      startedAtSec: nowSec,
      commitAtSec: nowSec + 0.62,
      damage: mob.attackDamage,
      ignitesTerrain: true,
    };
  }
  return {
    kind: 'cone_slash',
    originX: mob.x,
    originY: mob.y,
    targetX,
    targetY,
    angleRad: ang,
    radiusTiles: 1.9,
    startedAtSec: nowSec,
    commitAtSec: nowSec + 0.5,
    damage: mob.attackDamage,
  };
}

function commitMonsterTelegraph(
  state: GameState,
  cursor: RngCursor,
  mob: MonsterActor,
  tel: NpcTelegraph,
  nowMs: number
): void {
  const player = state.actors.player;
  const map = getStaticIslandMap(state.world.seed);
  const nowSec = state.clock.elapsedSimSec;

  if (tel.kind === 'spit_lob') {
    const ang = tel.angleRad;
    state.world.projectiles.push({
      id: nextId(cursor, 'prj'),
      ownerId: mob.id,
      fromPlayer: false,
      kind: 'acid_spit',
      x: mob.x,
      y: mob.y,
      vx: Math.cos(ang) * 7.5,
      vy: Math.sin(ang) * 7.5,
      damage: tel.damage,
      radius: 0.35,
      expiresAtSec: nowSec + 1.4,
    });
    return;
  }

  if (tel.kind === 'charge_line') {
    const stepX = mob.x + Math.cos(tel.angleRad) * 1.4;
    const stepY = mob.y + Math.sin(tel.angleRad) * 1.4;
    if (!isTileBlockedForActor(map, state, Math.floor(stepX), Math.floor(stepY)).blocked) {
      mob.x = stepX;
      mob.y = stepY;
    }
  }

  const dPlayer = Math.hypot(player.x - mob.x, player.y - mob.y);
  const angToPlayer = Math.atan2(player.y - mob.y, player.x - mob.x);
  const angDiff = Math.abs(Math.atan2(Math.sin(angToPlayer - tel.angleRad), Math.cos(angToPlayer - tel.angleRad)));

  let hitPlayer = false;
  if (tel.kind === 'aoe_ring') {
    hitPlayer = dPlayer <= tel.radiusTiles;
  } else if (tel.kind === 'frost_cross') {
    const dx = Math.abs(player.x - mob.x);
    const dy = Math.abs(player.y - mob.y);
    hitPlayer = (dx <= 0.9 && dy <= tel.radiusTiles) || (dy <= 0.9 && dx <= tel.radiusTiles);
  } else if (tel.kind === 'flame_cone' || tel.kind === 'cone_slash' || tel.kind === 'lightning_arc') {
    hitPlayer = dPlayer <= tel.radiusTiles && angDiff <= 0.72;
  } else if (tel.kind === 'charge_line') {
    hitPlayer = dPlayer <= 1.65;
  }

  if (hitPlayer && !player.dead) {
    applyDamageToPlayer(state, cursor, tel.damage, mob.x, mob.y, nowMs, mob.name);
  }

  // Lawful environmental consequences from Elder/fire attacks! (C05, C19)
  if (tel.ignitesTerrain) {
    const fx = Math.floor(mob.x + Math.cos(tel.angleRad) * 1.8);
    const fy = Math.floor(mob.y + Math.sin(tel.angleRad) * 1.8);
    if (fx > 1 && fy > 1 && fx < map.width - 1 && fy < map.height - 1) {
      if (map.flammable[fy * map.width + fx]) {
        state.world.fires.push({ tileX: fx, tileY: fy, expiresAtSec: nowSec + 8 });
      }
    }
  }
  if (tel.breaksTrees) {
    for (const s of Object.values(state.sources)) {
      if (
        s.stock > 0 &&
        (s.kind === 'pine_tree' || s.kind === 'oak_tree') &&
        Math.hypot(s.x - mob.x, s.y - mob.y) <= tel.radiusTiles
      ) {
        s.stock = 0;
        s.depletedAtElapsedSec = nowSec;
        mintNewItemToContainerOrDrop(state, cursor, '__none__', 'wood_log', 2, `elder_smash:${mob.id}`, {
          x: s.x,
          y: s.y,
        });
      }
    }
  }

  state.world.vfx.push({
    id: nextId(cursor, 'vfx'),
    kind: tel.kind === 'flame_cone' ? 'ember_arc' : tel.kind === 'frost_cross' ? 'frost_nova' : 'explosion_ring',
    x: mob.x,
    y: mob.y,
    angleRad: tel.angleRad,
    radius: tel.radiusTiles,
    createdAtMs: nowMs,
    durationMs: 360,
  });
}

export function damageMonster(
  state: GameState,
  cursor: RngCursor,
  mob: MonsterActor,
  damage: number,
  fromX: number,
  fromY: number,
  nowMs: number
): void {
  if (mob.aiState === 'DEAD') return;
  mob.hp -= damage;
  mob.hitFlashUntilSec = state.clock.elapsedSimSec + 0.16;

  // Aggro onto attacker
  if (mob.aiState !== 'TELEGRAPH') {
    mob.aiState = 'CHASE';
  }

  // Slight physical knockback on non-Elders
  if (!mob.isElder) {
    const map = getStaticIslandMap(state.world.seed);
    const ang = Math.atan2(mob.y - fromY, mob.x - fromX);
    const kx = mob.x + Math.cos(ang) * 0.35;
    const ky = mob.y + Math.sin(ang) * 0.35;
    if (!isTileBlockedForActor(map, state, Math.floor(kx), Math.floor(ky)).blocked) {
      mob.x = kx;
      mob.y = ky;
    }
  }

  state.world.vfx.push({
    id: nextId(cursor, 'vfx'),
    kind: 'floating_text',
    x: mob.x,
    y: mob.y - 0.6,
    text: `${damage}`,
    color: '#ffe66d',
    createdAtMs: nowMs,
    durationMs: 550,
  });

  if (mob.hp <= 0) {
    mob.hp = 0;
    mob.aiState = 'DEAD';
    mob.telegraph = null;

    if (!mob.lootGranted) {
      mob.lootGranted = true;
      for (const entry of mob.lootTable) {
        if (nextFloat(cursor) <= entry.chance) {
          const qty = nextInt(cursor, entry.min, entry.max);
          mintNewItemToContainerOrDrop(state, cursor, '__none__', entry.defId, qty, `kill:${mob.id}`, {
            x: mob.x,
            y: mob.y,
          });
        }
      }

      if (mob.isElder) {
        const elderId = mob.archetype as ElderId;
        if (!state.run.eldersDefeated.includes(elderId)) {
          state.run.eldersDefeated.push(elderId);
        }
        const pts =
          mob.elderForm === 'awakened'
            ? balance.scoring.elderAwakenedDefeatScore
            : balance.scoring.elderLatentDefeatScore;
        recordUniqueScore(
          state,
          cursor,
          `elder_${elderId}_${mob.elderForm}`,
          `Defeated ${mob.name} (${mob.elderForm})`,
          pts
        );
      }
    }
  }
}

export function destroyStructureConservingContents(
  state: GameState,
  cursor: RngCursor,
  entityId: string
): void {
  const ent = state.entities[entityId];
  if (!ent) return;
  const droppedIds: string[] = [];

  for (const cId of [ent.containerId, ent.fuelContainerId, ent.outputContainerId]) {
    if (!cId) continue;
    const cont = state.custody.containers[cId];
    if (!cont) continue;
    for (let i = 0; i < cont.slots.length; i++) {
      const id = cont.slots[i];
      if (id && state.custody.items[id]) {
        droppedIds.push(id);
        cont.slots[i] = null;
      }
    }
    delete state.custody.containers[cId];
  }

  if (state.actors.player.boundBedEntityId === entityId) {
    state.actors.player.boundBedEntityId = null;
  }
  if (state.actors.player.hitchedCartEntityId === entityId) {
    state.actors.player.hitchedCartEntityId = null;
  }

  for (const job of Object.values(state.jobs)) {
    if (job.stationEntityId === entityId) delete state.jobs[job.id];
  }

  if (ent.kind === 'homestead_stake') {
    state.world.homesteads = state.world.homesteads.filter((h) => h.stakeEntityId !== entityId);
  }

  const dropX = ent.x;
  const dropY = ent.y;
  delete state.entities[entityId];

  if (droppedIds.length > 0) {
    const dEntId = nextId(cursor, 'drop');
    const dContId = `drop:${dEntId}`;
    const dCont = createContainer(dContId, 'drop', droppedIds.length, dEntId);
    for (let i = 0; i < droppedIds.length; i++) {
      const it = state.custody.items[droppedIds[i]];
      if (it) {
        it.containerId = dContId;
        dCont.slots[i] = it.id;
      }
    }
    state.custody.containers[dContId] = dCont;
    state.entities[dEntId] = {
      id: dEntId,
      kind: 'world_drop',
      tileX: Math.floor(dropX),
      tileY: Math.floor(dropY),
      x: dropX,
      y: dropY,
      hp: 100,
      maxHp: 100,
      owner: 'world',
      containerId: dContId,
      createdAtSec: state.clock.elapsedSimSec,
      provenance: `destroyed:${ent.kind}`,
    };
  }
}

export function countPlayerHeldUnbankedCash(state: GameState): number {
  let total = 0;
  for (const it of Object.values(state.custody.items)) {
    if (it.defId === 'ragnarok_cash') total += it.qty;
  }
  return total;
}

export function countCollectedElderStones(state: GameState): number {
  const found = new Set<string>();
  for (const it of Object.values(state.custody.items)) {
    if ((ELDER_STONE_IDS as readonly string[]).includes(it.defId)) {
      found.add(it.defId);
    }
  }
  return found.size;
}

export function finalizeRunOnce(
  state: GameState,
  cursor: RngCursor,
  reason: RunEndReason,
  nowUtcMs: number
): void {
  if (!state.run.active) return; // Idempotent exact-once guard (C22, C23!)

  const stonesCount = countCollectedElderStones(state);
  let finalReason = reason;
  if (reason === 'EVACUATED' && stonesCount >= 6) {
    finalReason = 'SIX_STONES_CONVERGENCE';
    recordUniqueScore(
      state,
      cursor,
      'six_stones_convergence',
      'Evacuated with All Six Elder Stones',
      balance.scoring.sixStonesConvergenceScore
    );
  } else if (reason === 'EVACUATED') {
    recordUniqueScore(
      state,
      cursor,
      'clean_evacuation',
      'Completed Physical Island Evacuation',
      balance.scoring.evacuationSuccessScore
    );
  }

  const unbankedLost = countPlayerHeldUnbankedCash(state);
  const totalScore = state.run.scoreReceipts.reduce((acc, r) => acc + r.points, 0);
  const spMeta =
    state.world.spawnRegions.find((s) => s.id === state.actors.player.spawnRegionId)?.name ??
    state.actors.player.spawnRegionId;

  // Record LOCAL_UNVERIFIED run history into Profile (C21, C23)
  state.profile.runHistory.unshift({
    runId: state.run.runId,
    runNumber: state.run.runNumber,
    gender: state.actors.player.gender,
    spawnRegionName: spMeta,
    startedUtcMs: state.clock.runStartUtcMs,
    endedUtcMs: nowUtcMs,
    elapsedHours: Math.round(getElapsedRunHours(state) * 100) / 100,
    endReason: finalReason,
    cashDepositedThisRun: state.run.cashDepositedThisRun,
    unbankedCashLostOnEnd: unbankedLost,
    eldersDefeated: [...state.run.eldersDefeated],
    stonesCollected: stonesCount,
    totalScore,
    verification: 'LOCAL_UNVERIFIED',
    qaUsed: state.clock.isQaAccelerated,
  });

  // Mark run ENDED and WIPE ALL RUN-LOCAL DATA (items, equipment, cores, blueprints, recipes, buildings, carts, bags, physical cash, stones! C23!)
  state.run.active = false;
  state.run.endReason = finalReason;
  state.clock.phase = 'ENDED';

  state.custody = {
    items: {},
    containers: {
      player_inv: createContainer('player_inv', 'player_inv', 24),
    },
    playerQuickbar: [0, 1, 2, 3, 4, 5, 6, 7],
    equippedHeadId: null,
    equippedBodyId: null,
    activeQuickSlot: 0,
  };
  state.knowledge = {
    unlockedRecipes: [...BASELINE_RECIPE_IDS],
    discoveredPois: [],
    studiedSpecimens: [],
    completedOptionalMilestones: [],
  };
  state.jobs = {};
  state.sources = {};
  state.entities = {};
  state.actors.monsters = {};
  state.world.homesteads = [];
  state.world.footprints = [];
  state.world.fires = [];
  state.world.scorchedTiles = [];
  state.world.projectiles = [];
  state.world.vfx = [];
  state.actors.player.hitchedCartEntityId = null;
  state.actors.player.boundBedEntityId = null;
  state.actors.player.activeWindup = null;
}

export function settleChronologicalSeconds(
  state: GameState,
  cursor: RngCursor,
  totalDeltaSec: number,
  nowUtcMs: number
): void {
  if (!state.run.active || totalDeltaSec <= 0) return;

  const maxAllowedSec = balance.clock.maxRunRealHours * 3600 - state.clock.elapsedSimSec;
  const clampedTotal = Math.min(totalDeltaSec, Math.max(0, maxAllowedSec));

  // Adaptive step size bounded by max steps so 100+ offline hours settle in <15ms while preserving chronological order!
  const stepSec = Math.max(10, clampedTotal / balance.workAndResearch.OfflineSettlementMaxSteps);
  let remaining = clampedTotal;

  while (remaining > 0.001 && state.run.active) {
    const dt = Math.min(stepSec, remaining);
    remaining -= dt;
    state.clock.elapsedSimSec += dt;
    state.clock.fictionalDaySec =
      (state.clock.fictionalDaySec + dt * state.clock.fictionalTimeScale) %
      balance.clock.fictionalDayLengthSeconds;

    const hours = getElapsedRunHours(state);
    state.clock.phase = computeRunPhase(hours, state.run.active);
    awakenEldersIfDay14(state);

    advanceEnvironmentAndSources(state, cursor, dt);
    advanceStationsAndJobs(state, cursor, dt);
    advancePlayerSurvival(state, cursor, dt, true);

    // Physical danger if player logged out right next to a live monster in open sight (no invented raids!)
    if (!state.actors.player.dead) {
      for (const mob of Object.values(state.actors.monsters)) {
        if (mob.aiState === 'DEAD') continue;
        const d = Math.hypot(mob.x - state.actors.player.x, mob.y - state.actors.player.y);
        if (d <= mob.sightRange * 0.65 && hasClearSightLine(state, mob.x, mob.y, state.actors.player.x, state.actors.player.y)) {
          applyDamageToPlayer(state, cursor, mob.attackDamage * 0.5, mob.x, mob.y, nowUtcMs, `offline_${mob.name}`);
          break;
        }
      }
    }
  }

  state.clock.lastSettledUtcMs = nowUtcMs;
  if (getElapsedRunHours(state) >= balance.clock.maxRunRealHours && state.run.active) {
    finalizeRunOnce(state, cursor, 'EXPIRED_336H', nowUtcMs);
  }
}

export function canBuildAtTile(
  state: GameState,
  structureKind: keyof typeof STRUCTURES_CATALOG,
  tx: number,
  ty: number
): { ok: boolean; reason?: string } {
  const def = STRUCTURES_CATALOG[structureKind];
  if (!def) return { ok: false, reason: 'Unknown structure' };

  const map = getStaticIslandMap(state.world.seed);
  if (tx < 2 || ty < 2 || tx >= map.width - 2 || ty >= map.height - 2) {
    return { ok: false, reason: 'Out of island bounds' };
  }

  const i = ty * map.width + tx;
  if (structureKind === 'handcart') {
    if (!map.cartPassable[i]) return { ok: false, reason: 'Terrain not passable for Handcart' };
  } else if (!map.buildable[i]) {
    return { ok: false, reason: 'Cannot build on water, roads, cliffs, or inside POIs' };
  }

  if (def.recipeId && !state.knowledge.unlockedRecipes.includes(def.recipeId)) {
    return { ok: false, reason: `Requires run recipe: ${RECIPES_CATALOG[def.recipeId]?.name ?? def.recipeId}` };
  }

  if (def.requiresOwnedLand && !isTileOnOwnedLand(state, tx, ty)) {
    return { ok: false, reason: 'Must be placed on owned Homestead land (place Floor or Homestead Totem first)' };
  }

  // Distance check from player (within 4.5 tiles)
  if (Math.hypot(tx + 0.5 - state.actors.player.x, ty + 0.5 - state.actors.player.y) > 4.8) {
    return { ok: false, reason: 'Target tile is too far away' };
  }

  // Check active solid sources on tile
  for (const s of Object.values(state.sources)) {
    if (s.stock > 0 && Math.floor(s.x) === tx && Math.floor(s.y) === ty) {
      return { ok: false, reason: 'Clear resource node on tile first' };
    }
  }

  // Check existing structures on same tile (allow floor + wall/station + roof layering!)
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0 || ent.tileX !== tx || ent.tileY !== ty) continue;
    if (ent.kind === 'world_drop' || ent.kind === 'death_bag') continue;
    const eDef = STRUCTURES_CATALOG[ent.kind];
    if (def.isFloor && eDef?.isFloor) return { ok: false, reason: 'Floor already built here' };
    if (def.isRoof && eDef?.isRoof) return { ok: false, reason: 'Roof already built here' };
    if (!def.isFloor && !def.isRoof && !eDef?.isFloor && !eDef?.isRoof) {
      return { ok: false, reason: 'Tile already occupied by a structure' };
    }
  }

  // Avoid trapping player inside solid block on exact player center if blocksMovement & not a door
  if (
    def.blocksMovement &&
    !def.isDoor &&
    Math.hypot(tx + 0.5 - state.actors.player.x, ty + 0.5 - state.actors.player.y) < 0.55
  ) {
    return { ok: false, reason: 'Step aside from tile before placing solid structure' };
  }

  return { ok: true };
}
