import React, { useEffect, useRef } from 'react';
import { GameState, SurfaceType } from '../engine/types';
import { getStaticIslandMap } from '../engine/worldGen';

interface IslandMapModalProps {
  state: GameState;
  onClose: () => void;
}

const SURFACE_MAP_COLOR: Record<SurfaceType, string> = {
  water: '#1d4e6b',
  shallow: '#468faf',
  sand: '#e9c46a',
  grass: '#588157',
  forest_floor: '#344e41',
  road: '#b08968',
  bridge: '#ddb892',
  rock: '#6c757d',
  mud: '#4a4e3a',
  snow: '#dee2e6',
  scorch: '#78290f',
  toxic_concrete: '#495057',
  wood_floor: '#ca6702',
  stone_floor: '#adb5bd',
};

export const IslandMapModal: React.FC<IslandMapModalProps> = ({ state, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    const map = getStaticIslandMap(state.world.seed);
    ctx.clearRect(0, 0, 200, 200);

    for (let y = 0; y < map.height; y++) {
      for (let x = 0; x < map.width; x++) {
        const i = y * map.width + x;
        if (map.elevation[i] === 3) {
          ctx.fillStyle = '#212529';
        } else {
          ctx.fillStyle = SURFACE_MAP_COLOR[map.surfaces[i]] ?? '#588157';
        }
        ctx.fillRect(x, y, 1, 1);
      }
    }

    // Owned Homestead circles
    for (const h of state.world.homesteads) {
      ctx.strokeStyle = '#ffd166';
      ctx.strokeRect(
        Math.round(h.centerX - h.radiusTiles),
        Math.round(h.centerY - h.radiusTiles),
        h.radiusTiles * 2,
        h.radiusTiles * 2
      );
    }

    // POIs & Evac Piers
    for (const poi of state.world.pois) {
      ctx.fillStyle =
        poi.kind === 'evac_pier'
          ? '#4cc9f0'
          : poi.kind === 'trading_outpost'
          ? '#ffd166'
          : '#f4a261';
      ctx.fillRect(poi.x - 2, poi.y - 2, 5, 5);
    }

    // Six Elder Sanctums
    for (const es of state.world.elderSites) {
      const defeated = state.run.eldersDefeated.includes(es.elderId);
      ctx.fillStyle = defeated ? '#6c757d' : '#ff006e';
      ctx.fillRect(es.x - 2, es.y - 2, 5, 5);
    }

    // Death Bags
    for (const ent of Object.values(state.entities)) {
      if (ent.kind === 'death_bag') {
        ctx.fillStyle = '#ff5964';
        ctx.fillRect(Math.round(ent.x) - 2, Math.round(ent.y) - 2, 5, 5);
      }
    }

    // Player Marker
    const px = Math.round(state.actors.player.x);
    const py = Math.round(state.actors.player.y);
    ctx.fillStyle = '#14181e';
    ctx.fillRect(px - 3, py - 3, 7, 7);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(px - 2, py - 2, 5, 5);
  }, [state]);

  return (
    <div className="pixel-panel w-[92%] max-w-[540px] max-h-[85%] p-2.5 flex flex-col gap-2 overflow-y-auto">
      <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
        <span className="text-xs sm:text-sm font-bold text-[#ffd166]">
          ISLAND GEOGRAPHY &amp; LOGISTICS ATLAS [M]
        </span>
        <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
          ✕
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-start">
        <div className="sm:col-span-6 flex justify-center bg-[#0d121a] border border-[#343e52] p-1.5">
          <canvas
            ref={canvasRef}
            width={200}
            height={200}
            className="pixelated w-[190px] h-[190px] sm:w-[210px] sm:h-[210px] border border-[#5c677d]"
          />
        </div>

        <div className="sm:col-span-6 space-y-1.5 text-[10px]">
          <div className="bg-[#131a26] border border-[#2d3748] p-1.5 space-y-0.5">
            <div className="text-[#90e0ef] font-bold">Adventurer Position</div>
            <div>
              Tile: <strong>({Math.floor(state.actors.player.x)}, {Math.floor(state.actors.player.y)})</strong>
            </div>
            <div>
              Homesteads Owned: <strong>{state.world.homesteads.length}</strong>
            </div>
          </div>

          <div className="bg-[#131a26] border border-[#2d3748] p-1.5 space-y-1">
            <div className="text-[#ffd166] font-bold">Legend &amp; Landmarks</div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2.5 h-2.5 bg-white border border-black" /> You
              <span className="inline-block w-2.5 h-2.5 bg-[#ffd166] ml-2" /> Crossroads Vendor (96,112)
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2.5 h-2.5 bg-[#4cc9f0]" /> Evacuation Piers (28,105 &amp; 102,168)
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2.5 h-2.5 bg-[#f4a261]" /> Multi-Layer POIs &amp; Final-72 Vaults
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2.5 h-2.5 bg-[#ff006e]" /> Six Optional Elder Sanctums
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2.5 h-2.5 bg-[#ff5964]" /> Recoverable Death Bag
            </div>
          </div>

          <div className="text-[9px] text-[#adb5bd] leading-snug">
            Brown Ring-Roads speed Freight Handcarts &amp; erode footprints faster. Rain/Storm washes trails clean.
          </div>
        </div>
      </div>
    </div>
  );
};
