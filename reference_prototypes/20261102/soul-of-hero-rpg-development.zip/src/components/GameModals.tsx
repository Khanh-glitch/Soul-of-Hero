import React, { useMemo, useState } from 'react';
import balance from '../data/balance.v1.json';
import { ELDER_STONE_IDS, ITEMS_CATALOG } from '../data/itemsCatalog';
import { RECIPES_CATALOG } from '../data/recipesCatalog';
import { PLAYABLE_STRUCTURE_KINDS, STRUCTURES_CATALOG } from '../data/structuresCatalog';
import { LoadedArtAtlas } from '../art/pixelSprites';
import { soundEngine } from '../audio/soundEngine';
import {
  computeContainerWeightKg,
  computePlayerCarryWeightKg,
  countItemInContainer,
  getActiveQuickbarItem,
} from '../engine/custody';
import { getElapsedRunHours, isTileOnOwnedLand } from '../engine/simulation';
import { GameIntent, GameState, StructureEntity, StructureKind, WeatherKind } from '../engine/types';

export type ActiveModalKind = 'none' | 'inventory' | 'craft' | 'build' | 'research' | 'map' | 'skills' | 'pause';

interface GameModalsProps {
  modal: ActiveModalKind;
  state: GameState;
  atlas: LoadedArtAtlas;
  onDispatch: (intent: GameIntent) => void;
  onSelectBuildStructure: (kind: StructureKind) => void;
  onClose: () => void;
  onForceSave: () => void;
  onReturnToTitle: () => void;
}

export const GameModals: React.FC<GameModalsProps> = ({
  modal,
  state,
  atlas,
  onDispatch,
  onSelectBuildStructure,
  onClose,
  onForceSave,
  onReturnToTitle,
}) => {
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [buildTab, setBuildTab] = useState<'all' | 'foundation' | 'enclosure' | 'station' | 'storage_utility' | 'defense_transport'>('all');
  const [muted, setMuted] = useState(soundEngine.isMuted());
  const [vol, setVol] = useState(soundEngine.getVolume());

  const player = state.actors.player;
  const inv = state.custody.containers['player_inv'];

  // Find nearest interactive container / station / vendor / escrow entity within 4.0 tiles
  const nearbyEntities = useMemo(() => {
    const list: StructureEntity[] = [];
    for (const ent of Object.values(state.entities)) {
      if (ent.hp <= 0) continue;
      if (Math.hypot(ent.x - player.x, ent.y - player.y) <= 4.1) {
        list.push(ent);
      }
    }
    list.sort((a, b) => Math.hypot(a.x - player.x, a.y - player.y) - Math.hypot(b.x - player.x, b.y - player.y));
    return list;
  }, [state.entities, player.x, player.y]);

  const contextEntity = useMemo(() => {
    return (
      nearbyEntities.find(
        (e) =>
          e.kind === 'escrow_chest' ||
          e.kind === 'vendor_escrow_broker' ||
          e.kind === 'vendor_season_shop' ||
          e.kind === 'stone_furnace' ||
          e.kind === 'campfire' ||
          e.kind === 'planter_box' ||
          e.kind === 'rain_collector' ||
          e.kind === 'generator' ||
          e.kind === 'storage_chest' ||
          e.kind === 'handcart' ||
          e.kind === 'death_bag' ||
          e.kind === 'world_drop'
      ) ?? null
    );
  }, [nearbyEntities]);

  const nearWorkbench = nearbyEntities.some((e) => e.kind === 'workbench');
  const nearbyResearchBench = nearbyEntities.find((e) => e.kind === 'research_table') ?? null;

  const renderIcon = (iconKey: string, sizeClass = 'w-5 h-5') => {
    const src = atlas.itemIcons[iconKey];
    if (!src) return <span className={`${sizeClass} inline-block bg-[#2b3547]`} />;
    return <img src={src} alt="" className={`pixelated ${sizeClass} object-contain shrink-0`} />;
  };

  if (modal === 'none') return null;

  // 1. INVENTORY & CUSTODY / STATION / ESCROW / VENDOR PANEL [I]
  if (modal === 'inventory') {
    const selectedInst = selectedItemId ? state.custody.items[selectedItemId] : null;
    const selectedDef = selectedInst ? ITEMS_CATALOG[selectedInst.defId] : null;
    const carryKg = computePlayerCarryWeightKg(state);
    const cartEnt = player.hitchedCartEntityId ? state.entities[player.hitchedCartEntityId] : null;
    const cartKg = cartEnt?.containerId ? computeContainerWeightKg(state, cartEnt.containerId) : 0;
    const maxKg =
      balance.survival.baseCarryCapacityKg + (cartEnt ? balance.movementAndFreight.cartExtraCapacityKg : 0);

    const primaryDestContainerId =
      contextEntity?.containerId ?? contextEntity?.fuelContainerId ?? null;

    return (
      <div className="pixel-panel w-[95%] max-w-[610px] max-h-[84%] p-2.5 flex flex-col gap-2 overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-[#ffd166]">PHYSICAL CUSTODY &amp; PACK [I]</span>
            <span className="text-[10px] text-[#90e0ef]">
              Load: {(carryKg + cartKg).toFixed(1)} / {maxKg} kg
            </span>
          </div>
          <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
            ✕
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          {/* Left: Backpack 24 Slots + Armor */}
          <div className="sm:col-span-7 space-y-1.5">
            {/* Equipped Head & Body Armor */}
            <div className="flex items-center gap-1.5 bg-[#121824] border border-[#2d3748] p-1 text-[10px]">
              <span className="text-[#adb5bd] font-bold">Armor:</span>
              {(['head', 'body'] as const).map((slot) => {
                const eqId = slot === 'head' ? state.custody.equippedHeadId : state.custody.equippedBodyId;
                const eqInst = eqId ? state.custody.items[eqId] : null;
                const eqDef = eqInst ? ITEMS_CATALOG[eqInst.defId] : null;
                return (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => {
                      if (eqId) onDispatch({ type: 'UNEQUIP_SLOT', slot, requestId: `uneq_${Date.now()}` });
                    }}
                    className="pixel-btn px-1.5 py-0.5 flex items-center gap-1 text-[10px] cursor-pointer"
                    title={eqDef ? `Click to unequip ${eqDef.name}` : `Empty ${slot} slot`}
                  >
                    {eqDef ? renderIcon(eqDef.iconKey, 'w-4 h-4') : null}
                    <span>{eqDef ? eqDef.name : `[${slot.toUpperCase()}: None]`}</span>
                  </button>
                );
              })}
            </div>

            {/* 24-Slot Backpack Grid (Slots 0..7 are Quickbar 1..8) */}
            <div className="grid grid-cols-6 gap-1 bg-[#0f141e] border border-[#2d3748] p-1.5">
              {inv.slots.map((instId, idx) => {
                const inst = instId ? state.custody.items[instId] : null;
                const def = inst ? ITEMS_CATALOG[inst.defId] : null;
                const isSelected = instId !== null && instId === selectedItemId;
                const isQuick = idx < 8;
                return (
                  <button
                    key={idx}
                    type="button"
                    data-testid={`inv-slot-${idx}`}
                    onClick={() => {
                      soundEngine.playUiClick();
                      setSelectedItemId(instId);
                    }}
                    onDoubleClick={() => {
                      if (!instId) return;
                      if (primaryDestContainerId) {
                        onDispatch({
                          type: 'TRANSFER_ITEM',
                          instanceId: instId,
                          toContainerId: primaryDestContainerId,
                          requestId: `tr_${Date.now()}_${idx}`,
                        });
                      } else {
                        onDispatch({ type: 'USE_ITEM', instanceId: instId, requestId: `use_${Date.now()}_${idx}` });
                      }
                    }}
                    className={`relative h-9 border flex items-center justify-center cursor-pointer ${
                      isSelected
                        ? 'bg-[#2a3b57] border-[#ffd166]'
                        : isQuick
                        ? 'bg-[#172133] border-[#415a77]'
                        : 'bg-[#121824] border-[#2b3446]'
                    }`}
                  >
                    {isQuick && (
                      <span className="absolute top-0 left-0.5 text-[8px] text-[#90e0ef] opacity-80">
                        {idx + 1}
                      </span>
                    )}
                    {inst && def && (
                      <>
                        {renderIcon(def.iconKey, 'w-5 h-5')}
                        {inst.qty > 1 && (
                          <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-white drop-shadow">
                            {inst.qty}
                          </span>
                        )}
                        {inst.charges !== undefined && (
                          <span className="absolute bottom-0 left-0.5 text-[8px] font-bold text-[#ffd166]">
                            ⚡{inst.charges}
                          </span>
                        )}
                      </>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Selected Item Inspector & Actions */}
            {selectedInst && selectedDef ? (
              <div className="bg-[#141c2b] border border-[#415a77] p-1.5 text-[10px] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#ffd166]">
                    {selectedDef.name} (x{selectedInst.qty})
                  </span>
                  <span className="text-[#8d99ae]">
                    {(selectedDef.weightKg * selectedInst.qty).toFixed(2)} kg
                    {selectedInst.durability !== undefined ? ` · Dur ${selectedInst.durability}` : ''}
                    {selectedInst.charges !== undefined ? ` · Charges ${selectedInst.charges}` : ''}
                  </span>
                </div>
                <p className="text-[#cbd5e1] text-[9px] leading-tight">{selectedDef.description}</p>
                <div className="flex flex-wrap gap-1 pt-0.5">
                  {(selectedDef.category === 'consumable' ||
                    selectedDef.category === 'blueprint' ||
                    selectedDef.category === 'armor') && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({
                          type: 'USE_ITEM',
                          instanceId: selectedInst.id,
                          requestId: `use_${Date.now()}`,
                        })
                      }
                      className="pixel-btn px-2 py-0.5 text-[10px] text-[#80ed99] cursor-pointer"
                    >
                      {selectedDef.category === 'armor'
                        ? 'Equip'
                        : selectedDef.category === 'blueprint'
                        ? 'Learn Schematic'
                        : 'Use / Eat'}
                    </button>
                  )}

                  {selectedDef.deploysStructureId && (
                    <button
                      type="button"
                      onClick={() => {
                        onSelectBuildStructure(selectedDef.deploysStructureId as StructureKind);
                      }}
                      className="pixel-btn px-2 py-0.5 text-[10px] text-[#ffd166] cursor-pointer"
                    >
                      Place in World ▶
                    </button>
                  )}

                  {selectedInst.containerId === 'player_inv' && primaryDestContainerId && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({
                          type: 'TRANSFER_ITEM',
                          instanceId: selectedInst.id,
                          toContainerId: primaryDestContainerId,
                          requestId: `xfer_${Date.now()}`,
                        })
                      }
                      className="pixel-btn px-2 py-0.5 text-[10px] text-[#90e0ef] cursor-pointer"
                    >
                      Move to Container →
                    </button>
                  )}

                  {selectedInst.containerId === 'player_inv' && contextEntity?.fuelContainerId && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({
                          type: 'TRANSFER_ITEM',
                          instanceId: selectedInst.id,
                          toContainerId: contextEntity.fuelContainerId!,
                          requestId: `fuel_${Date.now()}`,
                        })
                      }
                      className="pixel-btn px-2 py-0.5 text-[10px] text-[#f4a261] cursor-pointer"
                    >
                      Load as Fuel/Water →
                    </button>
                  )}

                  {selectedInst.containerId !== 'player_inv' && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({
                          type: 'TRANSFER_ITEM',
                          instanceId: selectedInst.id,
                          toContainerId: 'player_inv',
                          requestId: `take_${Date.now()}`,
                        })
                      }
                      className="pixel-btn px-2 py-0.5 text-[10px] text-[#80ed99] cursor-pointer"
                    >
                      ← Take to Backpack
                    </button>
                  )}

                  {selectedInst.qty > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({
                          type: 'TRANSFER_ITEM',
                          instanceId: selectedInst.id,
                          toContainerId: selectedInst.containerId,
                          splitQty: Math.floor(selectedInst.qty / 2),
                          requestId: `split_${Date.now()}`,
                        })
                      }
                      className="pixel-btn px-2 py-0.5 text-[10px] cursor-pointer"
                    >
                      Split Half
                    </button>
                  )}

                  {selectedInst.containerId === 'player_inv' && (
                    <button
                      type="button"
                      onClick={() => {
                        onDispatch({
                          type: 'DROP_ITEM',
                          instanceId: selectedInst.id,
                          requestId: `drop_${Date.now()}`,
                        });
                        setSelectedItemId(null);
                      }}
                      className="pixel-btn px-2 py-0.5 text-[10px] text-[#ffadad] cursor-pointer ml-auto"
                    >
                      Drop
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-[10px] text-[#8d99ae] bg-[#121824] border border-[#2b3446] p-1.5">
                Click any slot to inspect, transfer, split, equip, or deploy. Double-click to quick-use/transfer.
              </div>
            )}
          </div>

          {/* Right: Context Physical Station / Container / Escrow Chest / Vendor Panel */}
          <div className="sm:col-span-5 bg-[#101622] border border-[#343e52] p-2 flex flex-col gap-1.5 text-[10px]">
            {!contextEntity ? (
              <div className="text-[#8d99ae] space-y-1 my-auto text-center py-4">
                <div className="font-bold text-[#cbd5e1]">No Adjacent Container / Station</div>
                <p className="text-[9px]">
                  Stand beside a Chest, Handcart, Furnace, Campfire, Planter, Rương ký gửi, or Crossroads Vendor to interact physically.
                </p>
              </div>
            ) : contextEntity.kind === 'escrow_chest' ? (
              <div className="space-y-2">
                <div className="font-bold text-[#ffd166] border-b border-[#3d4659] pb-1">
                  RƯƠNG KÝ GỬI (OWNED ESCROW VAULT)
                </div>
                <div className="text-[9px] text-[#cbd5e1]">
                  Atomically converts held physical Ragnarok Cash into permanent Profile Secured Cash. Repeatable; does not end run.
                </div>
                <div className="bg-[#162030] border border-[#3a4a63] p-1.5 space-y-0.5">
                  <div>
                    Held Physical Cash:{' '}
                    <strong className="text-[#ffd166]">
                      {countItemInContainer(state, 'player_inv', 'ragnarok_cash')}
                    </strong>
                  </div>
                  <div>
                    Profile Secured Wallet:{' '}
                    <strong className="text-[#80ed99]">{state.profile.securedCash}</strong>
                  </div>
                  <div>
                    Land Status:{' '}
                    <strong className={isTileOnOwnedLand(state, contextEntity.tileX, contextEntity.tileY) ? 'text-[#80ed99]' : 'text-[#ff5964]'}>
                      {isTileOnOwnedLand(state, contextEntity.tileX, contextEntity.tileY)
                        ? 'Owned Homestead Land ✓'
                        : 'Unclaimed Land ✕'}
                    </strong>
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="deposit-cash-btn"
                  disabled={countItemInContainer(state, 'player_inv', 'ragnarok_cash') <= 0}
                  onClick={() => {
                    soundEngine.playDepositCash();
                    onDispatch({
                      type: 'DEPOSIT_RAGNAROK_CASH',
                      escrowEntityId: contextEntity.id,
                      requestId: `dep_${Date.now()}`,
                    });
                  }}
                  className="w-full py-1.5 bg-[#1b4332] hover:bg-[#2d6a4f] border border-[#ffd166] text-[#fff3b0] font-bold cursor-pointer disabled:opacity-40"
                >
                  Deposit All Held Cash Atomically ▶
                </button>
              </div>
            ) : contextEntity.kind === 'vendor_escrow_broker' ? (
              <div className="space-y-2">
                <div className="font-bold text-[#ffd166] border-b border-[#3d4659] pb-1">
                  CROSSROADS ESCROW BROKER
                </div>
                <div className="text-[9px] text-[#cbd5e1]">
                  Sells physical Rương ký gửi for physical Ragnarok Cash. Carry it home and place on owned Homestead land to deposit.
                </div>
                <div className="bg-[#162030] border border-[#3a4a63] p-1.5 space-y-0.5">
                  <div>
                    Price: <strong className="text-[#ffd166]">{balance.landAndEscrow.escrowChestVendorPricePhysicalCash} Physical Cash</strong>
                  </div>
                  <div>
                    Broker Stock: <strong>{state.world.vendorStocks.escrowBrokerKits}</strong> left
                  </div>
                  <div>
                    Your Physical Cash: <strong>{countItemInContainer(state, 'player_inv', 'ragnarok_cash')}</strong>
                  </div>
                </div>
                <button
                  type="button"
                  data-testid="buy-escrow-chest-btn"
                  disabled={
                    state.world.vendorStocks.escrowBrokerKits <= 0 ||
                    countItemInContainer(state, 'player_inv', 'ragnarok_cash') <
                      balance.landAndEscrow.escrowChestVendorPricePhysicalCash
                  }
                  onClick={() =>
                    onDispatch({
                      type: 'BUY_ESCROW_CHEST_PHYSICAL',
                      vendorEntityId: contextEntity.id,
                      requestId: `buy_esc_${Date.now()}`,
                    })
                  }
                  className="w-full py-1.5 bg-[#7f5539] hover:bg-[#9c6644] border border-[#ffd166] text-[#fff3b0] font-bold cursor-pointer disabled:opacity-40"
                >
                  Buy Rương Ký Gửi ({balance.landAndEscrow.escrowChestVendorPricePhysicalCash} Cash)
                </button>
              </div>
            ) : contextEntity.kind === 'vendor_season_shop' ? (
              <div className="space-y-1.5">
                <div className="font-bold text-[#90e0ef] border-b border-[#3d4659] pb-1 flex justify-between">
                  <span>SEASON SUPPLY VENDOR</span>
                  <span className="text-[#80ed99]">Wallet: {state.profile.securedCash}</span>
                </div>
                <div className="text-[9px] text-[#adb5bd]">
                  Spends cross-run Secured Cash to issue stocked RUN-LOCAL supplies (wiped at run end).
                </div>
                <div className="space-y-1 max-h-[175px] overflow-y-auto pr-0.5">
                  {Object.entries(state.world.vendorStocks.seasonShop).map(([offerKey, offer]) => {
                    const def = ITEMS_CATALOG[offer.defId];
                    if (!def) return null;
                    return (
                      <div
                        key={offerKey}
                        className="flex items-center justify-between bg-[#161f2e] border border-[#2d384c] p-1"
                      >
                        <div className="flex items-center gap-1">
                          {renderIcon(def.iconKey, 'w-4 h-4')}
                          <div>
                            <div className="font-bold text-[10px]">{def.name}</div>
                            <div className="text-[8px] text-[#adb5bd]">Stock: {offer.stock}</div>
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={offer.stock <= 0 || state.profile.securedCash < offer.priceSecuredCash}
                          onClick={() =>
                            onDispatch({
                              type: 'BUY_SEASON_VENDOR_ITEM',
                              vendorEntityId: contextEntity.id,
                              offerKey,
                              requestId: `sv_${offerKey}_${Date.now()}`,
                            })
                          }
                          className="pixel-btn px-1.5 py-0.5 text-[9px] text-[#ffd166] cursor-pointer"
                        >
                          {offer.priceSecuredCash} Cash
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* Physical Chest / Cart / Death Bag / Workstation Slots */
              <div className="space-y-1.5">
                <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
                  <span className="font-bold text-[#90e0ef]">
                    {STRUCTURES_CATALOG[contextEntity.kind]?.name ?? contextEntity.kind.toUpperCase()}
                  </span>
                  {contextEntity.kind === 'handcart' && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({
                          type: 'TOGGLE_CART_HITCH',
                          cartEntityId: contextEntity.id,
                          requestId: `hitch_${Date.now()}`,
                        })
                      }
                      className="pixel-btn px-1.5 py-0.5 text-[9px] text-[#ffd166] cursor-pointer"
                    >
                      {player.hitchedCartEntityId === contextEntity.id ? 'Unhitch' : 'Hitch Cart'}
                    </button>
                  )}
                </div>

                {/* Primary / Input Container */}
                {contextEntity.containerId && state.custody.containers[contextEntity.containerId] && (
                  <div>
                    <div className="text-[9px] text-[#adb5bd] mb-0.5">
                      {contextEntity.outputContainerId ? 'Raw Input Slots:' : 'Storage Slots:'}
                    </div>
                    <div className="grid grid-cols-4 gap-1 bg-[#0c1018] p-1 border border-[#2b3446]">
                      {state.custody.containers[contextEntity.containerId].slots.map((sId, i) => {
                        const inst = sId ? state.custody.items[sId] : null;
                        const def = inst ? ITEMS_CATALOG[inst.defId] : null;
                        return (
                          <button
                            key={i}
                            type="button"
                            onClick={() => setSelectedItemId(sId)}
                            onDoubleClick={() => {
                              if (sId) {
                                onDispatch({
                                  type: 'TRANSFER_ITEM',
                                  instanceId: sId,
                                  toContainerId: 'player_inv',
                                  requestId: `pull_${Date.now()}_${i}`,
                                });
                              }
                            }}
                            className={`relative h-8 border flex items-center justify-center cursor-pointer ${
                              sId && sId === selectedItemId
                                ? 'bg-[#2a3b57] border-[#ffd166]'
                                : 'bg-[#141b29] border-[#2d3748]'
                            }`}
                          >
                            {inst && def && (
                              <>
                                {renderIcon(def.iconKey, 'w-4 h-4')}
                                {inst.qty > 1 && (
                                  <span className="absolute bottom-0 right-0.5 text-[8px] font-bold">{inst.qty}</span>
                                )}
                              </>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Station Fuel / Water Slots */}
                {contextEntity.fuelContainerId && state.custody.containers[contextEntity.fuelContainerId] && (
                  <div>
                    <div className="text-[9px] text-[#f4a261] mb-0.5 flex justify-between">
                      <span>{contextEntity.kind === 'planter_box' ? 'Water Flask Slot:' : 'Physical Fuel Slot:'}</span>
                      <span>
                        {contextEntity.kind === 'planter_box'
                          ? `Moisture: ${Math.round(contextEntity.waterStored ?? 0)}s`
                          : `Burn left: ${Math.round(contextEntity.fuelRemainingSec ?? 0)}s`}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-1 bg-[#0c1018] p-1 border border-[#2b3446]">
                      {state.custody.containers[contextEntity.fuelContainerId].slots.map((sId, i) => {
                        const inst = sId ? state.custody.items[sId] : null;
                        const def = inst ? ITEMS_CATALOG[inst.defId] : null;
                        return (
                          <button
                            key={i}
                            type="button"
                            onClick={() => setSelectedItemId(sId)}
                            className="relative h-8 border bg-[#141b29] border-[#2d3748] flex items-center justify-center cursor-pointer"
                          >
                            {inst && def && (
                              <>
                                {renderIcon(def.iconKey, 'w-4 h-4')}
                                {inst.qty > 1 && (
                                  <span className="absolute bottom-0 right-0.5 text-[8px] font-bold">{inst.qty}</span>
                                )}
                              </>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Station Output Slots */}
                {contextEntity.outputContainerId && state.custody.containers[contextEntity.outputContainerId] && (
                  <div>
                    <div className="text-[9px] text-[#80ed99] mb-0.5">Physical Output Slots:</div>
                    <div className="grid grid-cols-4 gap-1 bg-[#0c1018] p-1 border border-[#2b3446]">
                      {state.custody.containers[contextEntity.outputContainerId].slots.map((sId, i) => {
                        const inst = sId ? state.custody.items[sId] : null;
                        const def = inst ? ITEMS_CATALOG[inst.defId] : null;
                        return (
                          <button
                            key={i}
                            type="button"
                            onClick={() => {
                              if (sId) {
                                onDispatch({
                                  type: 'TRANSFER_ITEM',
                                  instanceId: sId,
                                  toContainerId: 'player_inv',
                                  requestId: `out_${Date.now()}_${i}`,
                                });
                              }
                            }}
                            title="Click to collect finished output"
                            className="relative h-8 border bg-[#142421] border-[#2d6a4f] flex items-center justify-center cursor-pointer"
                          >
                            {inst && def && (
                              <>
                                {renderIcon(def.iconKey, 'w-4 h-4')}
                                {inst.qty > 1 && (
                                  <span className="absolute bottom-0 right-0.5 text-[8px] font-bold">{inst.qty}</span>
                                )}
                              </>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Start Timed Station Jobs */}
                {STRUCTURES_CATALOG[contextEntity.kind]?.stationTag && (
                  <div className="space-y-1 pt-0.5">
                    {Object.values(RECIPES_CATALOG)
                      .filter(
                        (r) =>
                          r.station === STRUCTURES_CATALOG[contextEntity.kind]?.stationTag &&
                          r.workSeconds > 0 &&
                          state.knowledge.unlockedRecipes.includes(r.id)
                      )
                      .map((r) => (
                        <button
                          key={r.id}
                          type="button"
                          onClick={() =>
                            onDispatch({
                              type: 'START_STATION_JOB',
                              stationEntityId: contextEntity.id,
                              recipeId: r.id,
                              requestId: `job_${r.id}_${Date.now()}`,
                            })
                          }
                          className="w-full pixel-btn px-2 py-1 text-left text-[9px] flex justify-between items-center cursor-pointer"
                        >
                          <span>▶ {r.name} ({r.workSeconds}s)</span>
                          <span className="text-[#ffd166]">
                            {r.inputs.map((inp) => `${inp.qty}x ${ITEMS_CATALOG[inp.defId]?.name.split(' ')[0]}`).join('+')}
                          </span>
                        </button>
                      ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 2. CRAFTING PANEL [C]
  if (modal === 'craft') {
    const unlockedInstant = Object.values(RECIPES_CATALOG).filter(
      (r) => r.workSeconds === 0 && state.knowledge.unlockedRecipes.includes(r.id)
    );
    return (
      <div className="pixel-panel w-[94%] max-w-[560px] max-h-[82%] p-2.5 flex flex-col gap-2 overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-[#ffd166]">CRAFTING &amp; TOOLMAKING [C]</span>
            <span className={`text-[10px] px-1.5 py-0.5 border ${nearWorkbench ? 'bg-[#1b4332] border-[#52b788] text-[#d8f3dc]' : 'bg-[#1d2636] border-[#495057] text-[#adb5bd]'}`}>
              {nearWorkbench ? 'Artisan Workbench In Range ✓' : 'Field Handcraft Only (Build Workbench for more)'}
            </span>
          </div>
          <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
            ✕
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 overflow-y-auto pr-0.5">
          {unlockedInstant.map((r) => {
            const outDef = ITEMS_CATALOG[r.output.defId];
            const needsBench = r.station === 'workbench' && !nearWorkbench;
            const hasMats = r.inputs.every((inp) => countItemInContainer(state, 'player_inv', inp.defId) >= inp.qty);
            const canCraft = !needsBench && hasMats;

            return (
              <div
                key={r.id}
                className="bg-[#131a26] border border-[#2f3b52] p-1.5 flex flex-col justify-between gap-1 text-[10px]"
              >
                <div className="flex items-center gap-1.5">
                  {outDef && renderIcon(outDef.iconKey, 'w-5 h-5')}
                  <div>
                    <div className="font-bold text-[#f1faee]">
                      {r.name} {r.output.qty > 1 ? `x${r.output.qty}` : ''}
                    </div>
                    <div className="text-[9px] text-[#8d99ae]">
                      {r.station === 'workbench' ? 'Requires Workbench' : 'Field Handcraft'}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 text-[9px]">
                  {r.inputs.map((inp) => {
                    const have = countItemInContainer(state, 'player_inv', inp.defId);
                    const ok = have >= inp.qty;
                    return (
                      <span
                        key={inp.defId}
                        className={`px-1 py-0.5 border ${
                          ok ? 'bg-[#162822] border-[#2d6a4f] text-[#b7e4c7]' : 'bg-[#2a171d] border-[#6a2d38] text-[#ffadad]'
                        }`}
                      >
                        {ITEMS_CATALOG[inp.defId]?.name}: {have}/{inp.qty}
                      </span>
                    );
                  })}
                </div>

                <button
                  type="button"
                  data-testid={`craft-btn-${r.id}`}
                  disabled={!canCraft}
                  onClick={() => {
                    soundEngine.playBuild();
                    onDispatch({
                      type: 'CRAFT_RECIPE',
                      recipeId: r.id,
                      requestId: `cr_${r.id}_${Date.now()}`,
                    });
                  }}
                  className="pixel-btn py-1 text-[10px] font-bold text-[#ffd166] cursor-pointer"
                >
                  {needsBench ? 'Need Workbench Nearby' : !hasMats ? 'Missing Materials' : 'Craft Now'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 3. BUILD & HOMESTEAD ENGINEERING PANEL [B]
  if (modal === 'build') {
    const structs = PLAYABLE_STRUCTURE_KINDS.map((k) => STRUCTURES_CATALOG[k]).filter(
      (d) => buildTab === 'all' || d.category === buildTab
    );
    const playerBuiltNearby = nearbyEntities.filter((e) => e.owner === 'player');

    return (
      <div className="pixel-panel w-[95%] max-w-[590px] max-h-[84%] p-2.5 flex flex-col gap-2 overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
          <span className="text-xs sm:text-sm font-bold text-[#ffd166]">
            HOMESTEAD &amp; STRUCTURE ENGINEERING [B]
          </span>
          <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
            ✕
          </button>
        </div>

        <div className="flex flex-wrap gap-1 text-[10px]">
          {(
            [
              ['all', 'All (22)'],
              ['foundation', 'Floors/Claim'],
              ['enclosure', 'Walls/Roofs'],
              ['station', 'Stations'],
              ['storage_utility', 'Storage/Escrow'],
              ['defense_transport', 'Defense/Cart'],
            ] as const
          ).map(([tabKey, label]) => (
            <button
              key={tabKey}
              type="button"
              onClick={() => setBuildTab(tabKey)}
              className={`px-2 py-0.5 border cursor-pointer ${
                buildTab === tabKey ? 'bg-[#283852] border-[#ffd166] text-[#fff3b0]' : 'bg-[#141b27] border-[#343e52]'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-[195px] overflow-y-auto pr-0.5">
          {structs.map((st) => {
            const recipeLocked = st.recipeId && !state.knowledge.unlockedRecipes.includes(st.recipeId);
            const hasMats = st.buildCost.every(
              (c) => countItemInContainer(state, 'player_inv', c.defId) >= c.qty
            );
            return (
              <div
                key={st.id}
                className="bg-[#131a26] border border-[#2f3b52] p-1.5 flex flex-col justify-between gap-1 text-[10px]"
              >
                <div className="flex items-center gap-1.5">
                  {renderIcon(st.id, 'w-5 h-5')}
                  <div>
                    <div className="font-bold text-[#f1faee]">{st.name}</div>
                    <div className="text-[9px] text-[#adb5bd] line-clamp-1">{st.description}</div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1 text-[9px]">
                  {st.buildCost.map((c) => {
                    const have = countItemInContainer(state, 'player_inv', c.defId);
                    return (
                      <span
                        key={c.defId}
                        className={`px-1 border ${
                          have >= c.qty
                            ? 'bg-[#162822] border-[#2d6a4f] text-[#b7e4c7]'
                            : 'bg-[#2a171d] border-[#6a2d38] text-[#ffadad]'
                        }`}
                      >
                        {ITEMS_CATALOG[c.defId]?.name}: {have}/{c.qty}
                      </span>
                    );
                  })}
                </div>
                <button
                  type="button"
                  data-testid={`select-build-${st.id}`}
                  disabled={!!recipeLocked || !hasMats}
                  onClick={() => {
                    soundEngine.playUiClick();
                    onSelectBuildStructure(st.id);
                  }}
                  className="pixel-btn py-0.5 text-[10px] font-bold text-[#90e0ef] cursor-pointer"
                >
                  {recipeLocked
                    ? 'Locked Behind Research'
                    : !hasMats
                    ? 'Missing Materials'
                    : 'Select & Place on Tile ▶'}
                </button>
              </div>
            );
          })}
        </div>

        {/* Nearby Reclaim / Repair Bar */}
        {playerBuiltNearby.length > 0 && (
          <div className="border-t border-[#343e52] pt-1.5">
            <div className="text-[9px] text-[#adb5bd] mb-1">Nearby Player Structures (Safe Reclaim Conserves Contents):</div>
            <div className="flex flex-wrap gap-1 max-h-[56px] overflow-y-auto">
              {playerBuiltNearby.map((ent) => (
                <div
                  key={ent.id}
                  className="flex items-center gap-1 bg-[#161f2e] border border-[#3a475e] px-1.5 py-0.5 text-[9px]"
                >
                  <span>
                    {STRUCTURES_CATALOG[ent.kind]?.name ?? ent.kind} ({ent.hp}/{ent.maxHp})
                  </span>
                  {ent.hp < ent.maxHp && (
                    <button
                      type="button"
                      onClick={() =>
                        onDispatch({ type: 'REPAIR_STRUCTURE', entityId: ent.id, requestId: `rep_${Date.now()}` })
                      }
                      className="text-[#80ed99] underline cursor-pointer"
                    >
                      Repair
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() =>
                      onDispatch({ type: 'RECLAIM_STRUCTURE', entityId: ent.id, requestId: `rec_${Date.now()}` })
                    }
                    className="text-[#ffd166] underline cursor-pointer"
                  >
                    Reclaim
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // 4. RESEARCH & SINGLE RUN-LOCAL KNOWLEDGE AUTHORITY [R]
  if (modal === 'research') {
    const sparesOwned = countItemInContainer(state, 'player_inv', 'spares');
    const lockedRecipes = Object.values(RECIPES_CATALOG).filter(
      (r) => !r.baselineUnlocked && !state.knowledge.unlockedRecipes.includes(r.id)
    );
    const studyableItemsInInv = inv.slots
      .map((sId) => (sId ? state.custody.items[sId] : null))
      .filter((inst) => {
        if (!inst) return false;
        const rId = ITEMS_CATALOG[inst.defId]?.studyRecipeId;
        return !!rId && !state.knowledge.unlockedRecipes.includes(rId);
      });

    return (
      <div className="pixel-panel w-[95%] max-w-[580px] max-h-[84%] p-2.5 flex flex-col gap-2 overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-[#ffd166]">RUN SCHEMATICS &amp; RESEARCH [R]</span>
            <span className="text-[10px] text-[#90e0ef]">Spares Held: <strong>{sparesOwned}</strong></span>
          </div>
          <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
            ✕
          </button>
        </div>

        {!nearbyResearchBench ? (
          <div className="bg-[#241b18] border border-[#e07a5f] p-2 text-[10px] text-[#ffd166]">
            Build and stand beside a <strong>Drawing &amp; Research Table</strong> to spend Mechanical Spares or study physical specimens. (You can still read found Blueprints directly from your Backpack!)
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              disabled={sparesOwned < balance.workAndResearch.randomResearchTier1Spares}
              onClick={() =>
                onDispatch({
                  type: 'RESEARCH_UNLOCK',
                  stationEntityId: nearbyResearchBench.id,
                  mode: 'random_t1',
                  requestId: `rt1_${Date.now()}`,
                })
              }
              className="pixel-btn p-1.5 text-[10px] text-left cursor-pointer"
            >
              <div className="font-bold text-[#80ed99]">Random Tier 1 Discovery</div>
              <div className="text-[9px] text-[#adb5bd]">Cost: {balance.workAndResearch.randomResearchTier1Spares} Spares</div>
            </button>
            <button
              type="button"
              disabled={sparesOwned < balance.workAndResearch.randomResearchTier2Spares}
              onClick={() =>
                onDispatch({
                  type: 'RESEARCH_UNLOCK',
                  stationEntityId: nearbyResearchBench.id,
                  mode: 'random_t2',
                  requestId: `rt2_${Date.now()}`,
                })
              }
              className="pixel-btn p-1.5 text-[10px] text-left cursor-pointer"
            >
              <div className="font-bold text-[#4cc9f0]">Random Tier 2 Discovery</div>
              <div className="text-[9px] text-[#adb5bd]">Cost: {balance.workAndResearch.randomResearchTier2Spares} Spares</div>
            </button>
          </div>
        )}

        {/* Specimen Study Section */}
        {nearbyResearchBench && studyableItemsInInv.length > 0 && (
          <div className="bg-[#131d28] border border-[#3a506b] p-1.5 space-y-1">
            <div className="text-[10px] font-bold text-[#ffd166]">
              Study Found Specimen (Consumes Specimen + 6 Spares → Unlocks Crafting Recipe):
            </div>
            <div className="flex flex-wrap gap-1">
              {studyableItemsInInv.map((inst) => {
                if (!inst) return null;
                const def = ITEMS_CATALOG[inst.defId];
                return (
                  <button
                    key={inst.id}
                    type="button"
                    disabled={sparesOwned < 6}
                    onClick={() =>
                      onDispatch({
                        type: 'RESEARCH_UNLOCK',
                        stationEntityId: nearbyResearchBench.id,
                        mode: 'specimen',
                        specimenInstanceId: inst.id,
                        requestId: `spec_${inst.id}_${Date.now()}`,
                      })
                    }
                    className="pixel-btn px-2 py-0.5 text-[10px] flex items-center gap-1 cursor-pointer"
                  >
                    {renderIcon(def.iconKey, 'w-4 h-4')}
                    <span>Study {def.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Directed Research Catalog */}
        <div className="text-[10px] font-bold text-[#90e0ef]">
          Undiscovered Run Schematics ({lockedRecipes.length} remaining · Unlocked: {state.knowledge.unlockedRecipes.length}):
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-[165px] overflow-y-auto pr-0.5">
          {lockedRecipes.map((r) => {
            const cost = r.directedSparesCost ?? 20;
            const outDef = ITEMS_CATALOG[r.output.defId];
            return (
              <div
                key={r.id}
                className="bg-[#121824] border border-[#2d3748] p-1.5 flex items-center justify-between gap-1 text-[10px]"
              >
                <div className="flex items-center gap-1.5">
                  {outDef && renderIcon(outDef.iconKey, 'w-4 h-4')}
                  <div>
                    <div className="font-bold">{r.name}</div>
                    <div className="text-[9px] text-[#8d99ae]">Tier {r.researchTier ?? 1}</div>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={!nearbyResearchBench || sparesOwned < cost}
                  onClick={() =>
                    nearbyResearchBench &&
                    onDispatch({
                      type: 'RESEARCH_UNLOCK',
                      stationEntityId: nearbyResearchBench.id,
                      mode: 'directed',
                      targetRecipeId: r.id,
                      requestId: `dir_${r.id}_${Date.now()}`,
                    })
                  }
                  className="pixel-btn px-2 py-0.5 text-[9px] text-[#ffd166] cursor-pointer shrink-0"
                >
                  {cost} Spares
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 5. SKILLS, ACTIVE CORE & SIX ELDERS OVERVIEW [Tab]
  if (modal === 'skills') {
    const activeInst = getActiveQuickbarItem(state);
    const activeDef = activeInst ? ITEMS_CATALOG[activeInst.defId] : null;
    const ownedStones = new Set(
      Object.values(state.custody.items)
        .map((i) => i.defId)
        .filter((d) => (ELDER_STONE_IDS as readonly string[]).includes(d))
    );

    return (
      <div className="pixel-panel w-[92%] max-w-[520px] max-h-[82%] p-2.5 flex flex-col gap-2 overflow-y-auto text-[10px]">
        <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
          <span className="text-xs sm:text-sm font-bold text-[#ffd166]">
            COMBAT PROFILE, CHARGED CORES &amp; ELDER STONES [Tab]
          </span>
          <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
            ✕
          </button>
        </div>

        <div className="bg-[#141c2b] border border-[#3a4a63] p-2 space-y-1">
          <div className="font-bold text-[#90e0ef]">
            Equipped Active Slot [{state.custody.activeQuickSlot + 1}]:{' '}
            <span className="text-[#ffd166]">{activeDef ? activeDef.name : 'Unarmed Strike'}</span>
          </div>
          <p className="text-[#cbd5e1] text-[9px]">
            {activeDef
              ? activeDef.description
              : 'Select slots 1–8 to wield tools, bows, or found Charged Cores. Every Core works immediately on pickup without needing a crafting recipe.'}
          </p>
          <div className="text-[#80ed99] text-[9px]">
            Tip: Right-Click or press <strong>X</strong> during a Core windup BEFORE contact to cancel safely with zero charge spent!
          </div>
        </div>

        <div className="space-y-1">
          <div className="font-bold text-[#ffadad]">
            Six Optional Island Elders ({ownedStones.size} / 6 Run-Local Stones Held · Awaken at Hour 312 / Day 14)
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {ELDER_STONE_IDS.map((sId) => {
              const def = ITEMS_CATALOG[sId];
              const has = ownedStones.has(sId);
              return (
                <div
                  key={sId}
                  className={`p-1.5 border flex items-center gap-1.5 ${
                    has ? 'bg-[#1b4332] border-[#80ed99]' : 'bg-[#121824] border-[#2d3748] opacity-75'
                  }`}
                >
                  {renderIcon(def.iconKey, 'w-5 h-5')}
                  <div>
                    <div className="font-bold text-[9px]">{def.name.replace(' Elder Stone', '')}</div>
                    <div className="text-[8px]">{has ? 'Collected ★' : 'Unclaimed'}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // 6. PAUSE / SAVE / AUDIO / QA CLOCK ACCELERATOR [Esc]
  if (modal === 'pause') {
    const elapsedH = getElapsedRunHours(state);
    return (
      <div className="pixel-panel w-[92%] max-w-[490px] max-h-[84%] p-2.5 flex flex-col gap-2 overflow-y-auto text-[10px]">
        <div className="flex items-center justify-between border-b border-[#3d4659] pb-1">
          <span className="text-xs sm:text-sm font-bold text-[#ffd166]">
            EXPEDITION MENU &amp; PERSISTENCE [Esc]
          </span>
          <button type="button" onClick={onClose} className="pixel-btn px-2 py-0.5 text-xs cursor-pointer">
            Resume
          </button>
        </div>

        {/* Audio & Fictional Day-Night Controls */}
        <div className="bg-[#131a26] border border-[#2d3748] p-2 space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <span className="font-bold text-[#90e0ef]">Local Sound Engine</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const nextM = !muted;
                  soundEngine.setMuted(nextM);
                  setMuted(nextM);
                }}
                className="pixel-btn px-2 py-0.5 cursor-pointer"
              >
                {muted ? 'Unmute 🔇' : 'Mute 🔊'}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={vol}
                onChange={(e) => {
                  const v = parseFloat(e.target.value);
                  soundEngine.setVolume(v);
                  setVol(v);
                }}
                className="w-24"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span>Separate Fictional Day/Night Clock:</span>
            <button
              type="button"
              onClick={() => onDispatch({ type: 'ADJUST_FICTIONAL_CLOCK', deltaSec: 150 })}
              className="pixel-btn px-2 py-0.5 cursor-pointer"
            >
              Shift Daylight +6h ☀/☾
            </button>
          </div>
        </div>

        {/* Save / Quit to Title / Abandon Run */}
        <div className="grid grid-cols-3 gap-1.5">
          <button
            type="button"
            onClick={() => {
              soundEngine.playUiClick();
              onForceSave();
            }}
            className="pixel-btn py-1.5 font-bold text-[#80ed99] cursor-pointer"
          >
            Save Snapshot
          </button>
          <button
            type="button"
            onClick={() => {
              onForceSave();
              onReturnToTitle();
            }}
            className="pixel-btn py-1.5 font-bold text-[#90e0ef] cursor-pointer"
          >
            Save &amp; Title
          </button>
          <button
            type="button"
            data-testid="abandon-run-btn"
            onClick={() =>
              onDispatch({
                type: 'ABANDON_RUN',
                nowUtcMs: Date.now(),
                requestId: `abn_${Date.now()}`,
              })
            }
            className="pixel-btn py-1.5 font-bold text-[#ff5964] cursor-pointer"
            title="Ends run immediately and wipes all run-local items, buildings, and unbanked cash"
          >
            Abandon Run
          </button>
        </div>

        {/* QA-ONLY Chronological Time & Weather Verification Controls (Explicitly Marked QA / UNVERIFIED) */}
        <div className="bg-[#1b1626] border border-[#9d4edd] p-2 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[#e0aaff]">QA CHRONOLOGICAL TIME &amp; WEATHER</span>
            <span className="px-1.5 py-0.5 bg-[#3c096c] text-[#ffadad] text-[9px] font-bold">
              QA / LOCAL_UNVERIFIED
            </span>
          </div>
          <div className="text-[9px] text-[#cbd5e1]">
            Elapsed: <strong>{elapsedH.toFixed(2)}h / 336h</strong> · Phase: <strong>{state.clock.phase}</strong> · Settles real station fuel, weather &amp; shelter rules chronologically.
          </div>
          <div className="flex flex-wrap gap-1">
            <button
              type="button"
              data-testid="qa-plus-1h"
              onClick={() => onDispatch({ type: 'QA_ADVANCE_TIME', hours: 1, requestId: `qa1_${Date.now()}` })}
              className="pixel-btn px-2 py-0.5 cursor-pointer"
            >
              +1h Offline Catch-up
            </button>
            <button
              type="button"
              data-testid="qa-enter-final72"
              onClick={() => {
                const diff = Math.max(0.5, balance.clock.ragnarokStartHour - elapsedH + 0.2);
                onDispatch({
                  type: 'QA_ADVANCE_TIME',
                  hours: diff,
                  preserveVitals: true,
                  requestId: `qa72_${Date.now()}`,
                });
              }}
              className="pixel-btn px-2 py-0.5 text-[#ffd166] cursor-pointer"
            >
              Enter Final 72h (264h+)
            </button>
            <button
              type="button"
              data-testid="qa-enter-day14"
              onClick={() => {
                const diff = Math.max(0.5, balance.clock.elderAwakenHour - elapsedH + 0.2);
                onDispatch({
                  type: 'QA_ADVANCE_TIME',
                  hours: diff,
                  preserveVitals: true,
                  requestId: `qa14_${Date.now()}`,
                });
              }}
              className="pixel-btn px-2 py-0.5 text-[#ffadad] cursor-pointer"
            >
              Day 14 Awaken Elders (312h+)
            </button>
            {(['CLEAR', 'RAIN', 'STORM'] as WeatherKind[]).map((w) => (
              <button
                key={w}
                type="button"
                onClick={() =>
                  onDispatch({ type: 'QA_ADVANCE_TIME', hours: 0, forceWeather: w, requestId: `qaw_${w}_${Date.now()}` })
                }
                className="pixel-btn px-1.5 py-0.5 text-[#90e0ef] cursor-pointer"
              >
                {w}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return null;
};
