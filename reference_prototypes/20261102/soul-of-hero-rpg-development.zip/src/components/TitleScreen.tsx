import React, { useEffect, useRef, useState } from 'react';
import { LoadedArtAtlas } from '../art/pixelSprites';
import { soundEngine } from '../audio/soundEngine';
import { createNewRunGameState } from '../engine/dispatcher';
import { getElapsedRunHours } from '../engine/simulation';
import { AdventurerGender, GameState, ProfileState } from '../engine/types';
import { getStaticIslandMap, ISLAND_GEOGRAPHY_SEED } from '../engine/worldGen';
import { LOGICAL_HEIGHT, LOGICAL_WIDTH, renderGameWorld } from '../render/worldRenderer';

interface TitleScreenProps {
  atlas: LoadedArtAtlas;
  profile: ProfileState;
  savedActiveRun: GameState | null;
  onResumeRun: () => void;
  onStartNewRun: (gender: AdventurerGender, spawnRegionId?: string) => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  atlas,
  profile,
  savedActiveRun,
  onResumeRun,
  onStartNewRun,
}) => {
  const [gender, setGender] = useState<AdventurerGender>('male');
  const [spawnChoice, setSpawnChoice] = useState<string>('random');
  const [showHistory, setShowHistory] = useState(false);

  const bgCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const malePreviewRef = useRef<HTMLCanvasElement | null>(null);
  const femalePreviewRef = useRef<HTMLCanvasElement | null>(null);

  const map = getStaticIslandMap(ISLAND_GEOGRAPHY_SEED);

  // Render live animated 640x360 island vista in background + animated Male/Female Adventurer sprites
  useEffect(() => {
    const previewState = createNewRunGameState({
      gender: 'male',
      spawnRegionId: 'spawn_meadow',
      nowUtcMs: Date.now(),
    });
    let animId = 0;

    const loop = (now: number) => {
      if (bgCanvasRef.current) {
        const ctx = bgCanvasRef.current.getContext('2d');
        if (ctx) {
          // Gentle scenic pan around Driftwood Meadow & Harbor Coast
          previewState.actors.player.x = 46 + Math.sin(now * 0.00025) * 4;
          previewState.actors.player.y = 132 + Math.cos(now * 0.0002) * 3;
          renderGameWorld(ctx, previewState, atlas, {
            buildPreviewKind: null,
            cursorWorldX: -10,
            cursorWorldY: -10,
            nowMs: now,
            nearestPrompt: null,
          });
          ctx.fillStyle = 'rgba(10, 14, 22, 0.56)';
          ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
        }
      }

      const frameRow = Math.floor(now / 180) % 4;
      const drawAvatar = (canvas: HTMLCanvasElement | null, sheet: HTMLImageElement | HTMLCanvasElement) => {
        if (!canvas) return;
        const c = canvas.getContext('2d');
        if (!c) return;
        c.imageSmoothingEnabled = false;
        c.clearRect(0, 0, 32, 32);
        c.drawImage(atlas.images.shadow, 10, 22, 12, 8);
        c.drawImage(sheet, 0, frameRow * 16, 16, 16, 8, 8, 16, 16);
      };

      drawAvatar(malePreviewRef.current, atlas.images.samuraiBlue);
      drawAvatar(femalePreviewRef.current, atlas.femaleAdventurerSheet);

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [atlas]);

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-[#0b0e14] overflow-hidden">
      {/* Live 640x360 Crisp Pixel Island Backdrop */}
      <canvas
        ref={bgCanvasRef}
        width={LOGICAL_WIDTH}
        height={LOGICAL_HEIGHT}
        className="pixelated absolute inset-0 w-full h-full object-cover pointer-events-none"
      />

      {/* Main Compact Pixel-Framed Title Container (Guaranteed <= 344px tall so 640x360 has zero clipping!) */}
      <div className="relative z-10 w-[94%] max-w-[600px] max-h-[94%] pixel-panel-gold p-2.5 sm:p-4 flex flex-col justify-between gap-2 overflow-y-auto">
        {/* Top Banner */}
        <div className="flex items-center justify-between gap-2 border-b border-[#3d4659] pb-1.5">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base sm:text-xl font-black tracking-wider text-[#ffd166] drop-shadow">
                SOUL OF HERO
              </span>
              <span className="text-[10px] px-1.5 py-0.5 bg-[#1b263b] border border-[#4cc9f0] text-[#90e0ef]">
                336H SANDBOX RPG
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-[#adb5bd]">
              Offline-First Solo Survival · Persistent Island · Final 72h Ragnarok
            </p>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <div
              className="px-2 py-1 bg-[#141b26] border border-[#e9c46a] text-[10px] sm:text-xs text-[#ffd166]"
              title="Cross-run Secured Ragnarok Cash"
            >
              Secured: <strong>{profile.securedCash}</strong> Cash
            </div>
            <button
              type="button"
              data-testid="toggle-history-btn"
              onClick={() => {
                soundEngine.playUiClick();
                setShowHistory((v) => !v);
              }}
              className="pixel-btn px-2 py-1 text-[10px] sm:text-xs text-[#f1faee] cursor-pointer"
            >
              {showHistory ? 'Back' : `History (${profile.runHistory.length})`}
            </button>
          </div>
        </div>

        {showHistory ? (
          <div className="flex-1 min-h-[190px] max-h-[235px] overflow-y-auto bg-[#0f141d] border border-[#343e52] p-2 space-y-2">
            <div className="flex items-center justify-between text-[10px] text-[#ffb703] border-b border-[#293241] pb-1">
              <span>PERSONAL RUN ARCHIVE &amp; MILESTONES</span>
              <span className="px-1.5 py-0.5 bg-[#2b2d42] border border-[#ff595e] text-[#ffadad] font-bold">
                LOCAL / UNVERIFIED
              </span>
            </div>

            {profile.achievements.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {profile.achievements.map((ach) => (
                  <span
                    key={ach}
                    className="text-[9px] px-1.5 py-0.5 bg-[#1b4332] border border-[#52b788] text-[#d8f3dc]"
                  >
                    ★ {ach}
                  </span>
                ))}
              </div>
            )}

            {profile.runHistory.length === 0 ? (
              <div className="text-xs text-[#8d99ae] py-6 text-center">
                No finalized runs yet. Evacuate at a coastal beacon, or survive the 336h cycle to record history.
              </div>
            ) : (
              <div className="space-y-1.5">
                {profile.runHistory.map((h) => (
                  <div
                    key={h.runId}
                    className="p-1.5 bg-[#161e2c] border border-[#3a475e] text-[10px] flex flex-wrap items-center justify-between gap-1"
                  >
                    <div>
                      <span className="font-bold text-[#ffd166]">Run #{h.runNumber}</span>{' '}
                      <span className="text-[#adb5bd]">({h.gender === 'female' ? 'Female' : 'Male'} · {h.spawnRegionName})</span>
                      <div className="text-[#90e0ef]">
                        Outcome: <strong>{h.endReason}</strong> · {h.elapsedHours}h elapsed · Stones: {h.stonesCollected}/6
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[#80ed99]">Escrowed: +{h.cashDepositedThisRun} Cash</div>
                      <div className="text-[#adb5bd]">
                        Score: <strong>{h.totalScore}</strong>{' '}
                        <span className="text-[#ffadad]">[{h.verification}{h.qaUsed ? ' · QA' : ''}]</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Adventurer Selection + Spawn Region Selection */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
              {/* Two Original Adventurers */}
              <div className="sm:col-span-6 space-y-1">
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#90e0ef]">
                  1. Choose Adventurer
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    data-testid="select-male-btn"
                    onClick={() => {
                      soundEngine.playUiClick();
                      setGender('male');
                    }}
                    className={`p-1.5 border text-left cursor-pointer flex items-center gap-1.5 ${
                      gender === 'male'
                        ? 'bg-[#1f3047] border-[#ffd166] text-[#fff3b0]'
                        : 'bg-[#131924] border-[#3d4659] text-[#adb5bd]'
                    }`}
                  >
                    <canvas
                      ref={malePreviewRef}
                      width={32}
                      height={32}
                      className="pixelated w-9 h-9 shrink-0 bg-[#0d121a] border border-[#2f394d]"
                    />
                    <div className="leading-tight">
                      <div className="text-[11px] font-bold">Male</div>
                      <div className="text-[9px] opacity-80">Adventurer</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    data-testid="select-female-btn"
                    onClick={() => {
                      soundEngine.playUiClick();
                      setGender('female');
                    }}
                    className={`p-1.5 border text-left cursor-pointer flex items-center gap-1.5 ${
                      gender === 'female'
                        ? 'bg-[#382128] border-[#ffd166] text-[#fff3b0]'
                        : 'bg-[#131924] border-[#3d4659] text-[#adb5bd]'
                    }`}
                  >
                    <canvas
                      ref={femalePreviewRef}
                      width={32}
                      height={32}
                      className="pixelated w-9 h-9 shrink-0 bg-[#0d121a] border border-[#2f394d]"
                    />
                    <div className="leading-tight">
                      <div className="text-[11px] font-bold">Female</div>
                      <div className="text-[9px] opacity-80">Adventurer</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Starting Region Choice */}
              <div className="sm:col-span-6 space-y-1">
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#90e0ef]">
                  2. Landing Region (4 Safe Starts)
                </div>
                <select
                  aria-label="Landing Region"
                  data-testid="spawn-region-select"
                  value={spawnChoice}
                  onChange={(e) => {
                    soundEngine.playUiClick();
                    setSpawnChoice(e.target.value);
                  }}
                  className="w-full bg-[#131924] border border-[#5c677d] px-2 py-1.5 text-[11px] text-[#f1faee] focus:outline-none focus:border-[#ffd166]"
                >
                  <option value="random">Random Viable Region (Unscripted)</option>
                  {map.spawnRegions.map((sp) => (
                    <option key={sp.id} value={sp.id}>
                      {sp.name}
                    </option>
                  ))}
                </select>
                <div className="text-[9px] text-[#adb5bd] leading-snug line-clamp-2">
                  {spawnChoice === 'random'
                    ? 'Land in one of four resource-rich coastal, woodland, steppe, or foothill regions. No tutorial gates.'
                    : map.spawnRegions.find((s) => s.id === spawnChoice)?.summary}
                </div>
              </div>
            </div>

            {/* Compact Controls Primer */}
            <div className="bg-[#10151f] border border-[#2b3547] px-2 py-1 text-[9px] sm:text-[10px] text-[#cbd5e1] flex flex-wrap gap-x-3 gap-y-0.5 justify-between">
              <span><strong>WASD</strong> Move</span>
              <span><strong>Mouse+Click</strong> 360° Aim / Harvest / Fight</span>
              <span><strong>E</strong> Loot / Door / Hitch</span>
              <span><strong>I/C/B/R/M</strong> Bag / Craft / Build / Study / Map</span>
            </div>
          </>
        )}

        {/* Bottom Primary CTA Row — Always Visible & Reachable */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-[#3d4659]">
          {savedActiveRun && savedActiveRun.run.active ? (
            <button
              type="button"
              data-testid="resume-run-btn"
              onClick={() => {
                soundEngine.playUiClick();
                onResumeRun();
              }}
              className="flex-1 min-w-[160px] py-1.5 px-3 bg-[#1b4332] hover:bg-[#2d6a4f] border-2 border-[#74c69d] text-[#f1faee] text-xs font-bold cursor-pointer"
            >
              ▶ Resume Run #{savedActiveRun.run.runNumber} ({getElapsedRunHours(savedActiveRun).toFixed(1)}h / 336h)
            </button>
          ) : (
            <div className="text-[9px] text-[#8d99ae]">
              Starter Kit: Flint Knife, Sunberries, Poultice · Build anywhere lawful
            </div>
          )}

          <button
            type="button"
            data-testid="start-run-btn"
            onClick={() => {
              soundEngine.playUiClick();
              onStartNewRun(gender, spawnChoice === 'random' ? undefined : spawnChoice);
            }}
            className="py-1.5 px-4 bg-[#9b2226] hover:bg-[#ae2012] border-2 border-[#ffd166] text-[#fff3b0] text-xs sm:text-sm font-black tracking-wide cursor-pointer ml-auto"
          >
            {savedActiveRun?.run.active ? 'Start Fresh Run' : 'Enter Island ▶'}
          </button>
        </div>
      </div>
    </div>
  );
};
