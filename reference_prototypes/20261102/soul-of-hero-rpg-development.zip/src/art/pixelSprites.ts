import shadowUrl from '../assets/ninja/characters/shadow.png';
import ninjaBlueUrl from '../assets/ninja/characters/ninja_blue.png';
import samuraiBlueUrl from '../assets/ninja/characters/samurai_blue.png';
import samuraiGreenUrl from '../assets/ninja/characters/samurai_green.png';
import pigUrl from '../assets/ninja/characters/pig.png';

import tilesetFloorUrl from '../assets/ninja/tilesets/tileset_floor.png';
import tilesetInteriorUrl from '../assets/ninja/tilesets/tileset_interior_floor.png';
import tilesetVillageUrl from '../assets/ninja/tilesets/tileset_village_abandoned.png';
import tilesetWallUrl from '../assets/ninja/tilesets/tileset_wall_simple.png';
import tilesetAnimatedUrl from '../assets/ninja/tilesets/tileset_animated.png';

import crateUrl from '../assets/ninja/props/crate.png';
import potUrl from '../assets/ninja/props/pot.png';
import grassPropUrl from '../assets/ninja/props/grass.png';

import axeUrl from '../assets/ninja/weapons/axe.png';
import axeHandUrl from '../assets/ninja/weapons/axe_hand.png';
import bigSwordUrl from '../assets/ninja/weapons/big_sword.png';
import bigSwordHandUrl from '../assets/ninja/weapons/big_sword_hand.png';
import boneUrl from '../assets/ninja/weapons/bone.png';
import bookUrl from '../assets/ninja/weapons/book.png';
import clubUrl from '../assets/ninja/weapons/club.png';
import clubHandUrl from '../assets/ninja/weapons/club_hand.png';

import particleWoodUrl from '../assets/ninja/fx/particle_wood.png';
import particleRockUrl from '../assets/ninja/fx/particle_rock.png';
import particleGrassUrl from '../assets/ninja/fx/particle_grass.png';
import rainFloorUrl from '../assets/ninja/fx/rain_on_floor.png';
import snowFxUrl from '../assets/ninja/fx/snow.png';
import heartUrl from '../assets/ninja/ui/heart.png';

export interface LoadedArtAtlas {
  ready: boolean;
  images: Record<string, HTMLImageElement>;
  femaleAdventurerSheet: HTMLCanvasElement;
  customCreatures: Record<string, HTMLCanvasElement[]>;
  elders: Record<string, { latent: HTMLCanvasElement[]; awakened: HTMLCanvasElement[] }>;
  structures: Record<string, HTMLCanvasElement>;
  itemIcons: Record<string, string>; // crisp 16x16 dataURLs for UI + Canvas
  itemCanvases: Record<string, HTMLCanvasElement>;
}

let singletonAtlas: LoadedArtAtlas | null = null;
let loadPromise: Promise<LoadedArtAtlas> | null = null;

function makePixelCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  if (ctx) ctx.imageSmoothingEnabled = false;
  return c;
}

function drawMatrix(
  rows: string[],
  palette: Record<string, string>,
  w: number = 16,
  h: number = 16
): HTMLCanvasElement {
  const c = makePixelCanvas(w, h);
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  for (let y = 0; y < rows.length && y < h; y++) {
    const row = rows[y];
    for (let x = 0; x < row.length && x < w; x++) {
      const ch = row[x];
      if (ch === '.' || ch === ' ') continue;
      const col = palette[ch];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  return c;
}

function buildFemaleAdventurerFromMale(maleImg: HTMLImageElement): HTMLCanvasElement {
  const c = makePixelCanvas(64, 112);
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(maleImg, 0, 0);

  const imgData = ctx.getImageData(0, 0, 64, 112);
  const d = imgData.data;

  // Recolor blue tunic & dark hair into warm Crimson-Terracotta Explorer Tunic + Auburn Braided Hair + Gold Band
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 20) continue;
    const r = d[i];
    const g = d[i + 1];
    const b = d[i + 2];

    // Blue-teal tunic pixels in samurai_blue -> Crimson/terracotta explorer tunic
    if (b > r + 18 && g > r + 10) {
      if (b > 155) {
        d[i] = 232;
        d[i + 1] = 118;
        d[i + 2] = 84;
      } else if (b > 110) {
        d[i] = 196;
        d[i + 1] = 72;
        d[i + 2] = 49;
      } else {
        d[i] = 136;
        d[i + 1] = 43;
        d[i + 2] = 32;
      }
    } else if (r > 35 && r < 85 && g > 35 && g < 85 && b > 45 && b < 98) {
      // Dark slate hair -> rich chestnut-auburn explorer hair
      d[i] = Math.min(255, r + 52);
      d[i + 1] = Math.min(255, g + 16);
      d[i + 2] = Math.max(20, b - 18);
    }
  }
  ctx.putImageData(imgData, 0, 0);

  // Add crisp 1px pixel-art gold headband & braided ponytail silhouette accents per 16x16 cell
  for (let row = 0; row < 7; row++) {
    for (let col = 0; col < 4; col++) {
      const ox = col * 16;
      const oy = row * 16;
      ctx.fillStyle = '#f4d35e';
      if (col === 0 && row < 6) {
        // Facing down: gold brow band + side braid pixel
        ctx.fillRect(ox + 5, oy + 4, 6, 1);
        ctx.fillStyle = '#14181e';
        ctx.fillRect(ox + 12, oy + 7, 2, 3);
        ctx.fillStyle = '#8d3b24';
        ctx.fillRect(ox + 12, oy + 8, 1, 2);
      } else if (col === 1 && row < 6) {
        // Facing up: braided ponytail down back
        ctx.fillStyle = '#14181e';
        ctx.fillRect(ox + 6, oy + 6, 4, 5);
        ctx.fillStyle = '#8d3b24';
        ctx.fillRect(ox + 7, oy + 6, 2, 4);
        ctx.fillStyle = '#f4d35e';
        ctx.fillRect(ox + 7, oy + 9, 2, 1);
      } else if (col === 2 && row < 6) {
        // Facing left: trailing ponytail on right
        ctx.fillStyle = '#f4d35e';
        ctx.fillRect(ox + 4, oy + 4, 4, 1);
        ctx.fillStyle = '#14181e';
        ctx.fillRect(ox + 12, oy + 6, 3, 3);
        ctx.fillStyle = '#8d3b24';
        ctx.fillRect(ox + 12, oy + 7, 2, 1);
      } else if (col === 3 && row < 6) {
        // Facing right: trailing ponytail on left
        ctx.fillStyle = '#f4d35e';
        ctx.fillRect(ox + 8, oy + 4, 4, 1);
        ctx.fillStyle = '#14181e';
        ctx.fillRect(ox + 1, oy + 6, 3, 3);
        ctx.fillStyle = '#8d3b24';
        ctx.fillRect(ox + 2, oy + 7, 2, 1);
      }
    }
  }

  return c;
}

const COMMON_PAL: Record<string, string> = {
  o: '#14181e', // 1px NinjaAdventure dark outline
  w: '#f4f7f5',
  c: '#a8dadc',
  b: '#457b9d',
  d: '#1d3557',
  r: '#e63946',
  y: '#ffd166',
  a: '#f4a261',
  m: '#9d4edd',
  g: '#52b788',
  k: '#2d6a4f',
  s: '#8d99ae',
  z: '#4a4e69',
  n: '#9c6644',
  l: '#ddb892',
};

function buildCustomCreatureFrames(): Record<string, HTMLCanvasElement[]> {
  // 1. Frost Wolf (16x16 crisp quadruped direwolf, 2 stride frames)
  const wolf0 = drawMatrix(
    [
      '................',
      '..oo.......oo...',
      '.oowoo...oowoo..',
      '.owcwooooowcwo..',
      '..owccccccccwo..',
      '.oowryccccyrwoo.',
      '.occccccccccbco.',
      '..ooocccccccbo..',
      '...occcccccbbco.',
      '..occcbbbbbbbco.',
      '..ocbo.oobo.obo.',
      '..ocbo..obo.obo.',
      '..oowo..owo.owo.',
      '..ooo...ooo.ooo.',
      '................',
      '................',
    ],
    COMMON_PAL
  );
  const wolf1 = drawMatrix(
    [
      '................',
      '..oo.......oo...',
      '.oowoo...oowoo..',
      '.owcwooooowcwo..',
      '.oowryccccyrwoo.',
      '.occccccccccbco.',
      '..ooocccccccbco.',
      '..occcccccccbbco',
      '..occcbbbbbbbco.',
      '.oocbo..oobo.obo',
      '.oowo....owo.owo',
      '.ooo.....ooo.ooo',
      '................',
      '................',
      '................',
      '................',
    ],
    COMMON_PAL
  );

  // 2. Cinder Crawler (16x16 volcanic armored scarab with glowing magma seams)
  const cinder0 = drawMatrix(
    [
      '................',
      '....oooooooo....',
      '...oozzzzzzo....',
      '..oozzyaayzzo...',
      '.oozzzaaaazzzo..',
      '.ozzyarrrrayzo..',
      'oozzaarrrraazzo.',
      'ooyzzzaaaazzzyo.',
      '.oozzzzzzzzzzo..',
      '.o.ozzzaazzzo.o.',
      'o..oozzzzzzoo..o',
      '...o.oo..oo.o...',
      '..o..o....o..o..',
      '................',
      '................',
      '................',
    ],
    COMMON_PAL
  );
  const cinder1 = drawMatrix(
    [
      '................',
      '....oooooooo....',
      '...oozzzzzzo....',
      '..oozzayyazzo...',
      '.oozzarrrrazzo..',
      '.ozzyaryyrayzo..',
      'oozzaarrrraazzo.',
      'oo.zzzaaaazzz.oo',
      'o..ozzzzzzzzo..o',
      '...ozzzaazzzo...',
      '..o.oozzzzoo.o..',
      '.o...oo..oo...o.',
      '................',
      '................',
      '................',
      '................',
    ],
    COMMON_PAL
  );

  // 3. Blight Husk (16x16 mutated industrial spore-shambler)
  const husk0 = drawMatrix(
    [
      '................',
      '....ooooooo.....',
      '...ookggggko....',
      '..ookgmygymko...',
      '..okggkkkkggko..',
      '..ookkgyygkkoo..',
      '.oozzkkkkkkzzoo.',
      '.ozzgkzzzzkgzzo.',
      '.ozzgkzzzzkgzzo.',
      '..oozzzzzzzzoo..',
      '...ozzoooozzo...',
      '...ozzo..ozzo...',
      '...okko..okko...',
      '...ooo....ooo...',
      '................',
      '................',
    ],
    COMMON_PAL
  );
  const husk1 = drawMatrix(
    [
      '................',
      '....ooooooo.....',
      '...ookggggko....',
      '..ookgymymgko...',
      '..okggkkkkggko..',
      '.oookkgyygkkooo.',
      'oozzkkkkkkkkzzoo',
      'ozzzgkzzzzkgzzzo',
      '.oo.zzzzzzzz.oo.',
      '...ozzoooozzo...',
      '..ozzo....ozzo..',
      '..okko....okko..',
      '..ooo......ooo..',
      '................',
      '................',
      '................',
    ],
    COMMON_PAL
  );

  return {
    frost_wolf: [wolf0, wolf1],
    cinder_crawler: [cinder0, cinder1],
    blight_husk: [husk0, husk1],
  };
}

function buildSymmetric32Sprite(
  halfRows16: string[],
  palette: Record<string, string>,
  awakenedGlowColor?: string
): HTMLCanvasElement {
  const c = makePixelCanvas(32, 32);
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  if (awakenedGlowColor) {
    // Crisp pixel ground rune ring under Awakened Elder
    ctx.fillStyle = '#14181e';
    ctx.fillRect(6, 27, 20, 4);
    ctx.fillStyle = awakenedGlowColor;
    ctx.fillRect(7, 28, 18, 2);
  }

  for (let y = 0; y < halfRows16.length && y < 32; y++) {
    const row = halfRows16[y];
    for (let x = 0; x < 16 && x < row.length; x++) {
      const ch = row[x];
      if (ch === '.' || ch === ' ') continue;
      const col = palette[ch];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 1, 1);
      ctx.fillRect(31 - x, y, 1, 1);
    }
  }
  return c;
}

function buildSixElders(): Record<string, { latent: HTMLCanvasElement[]; awakened: HTMLCanvasElement[] }> {
  // Each Elder has a unique 32x32 pixel anatomy, silhouette, palette, and Awakened transformation!
  const makePair = (
    rowsA: string[],
    rowsB: string[],
    latentPal: Record<string, string>,
    awakenedPal: Record<string, string>,
    glow: string
  ) => ({
    latent: [buildSymmetric32Sprite(rowsA, latentPal), buildSymmetric32Sprite(rowsB, latentPal)],
    awakened: [
      buildSymmetric32Sprite(rowsA, awakenedPal, glow),
      buildSymmetric32Sprite(rowsB, awakenedPal, glow),
    ],
  });

  // 1. Sylvan Behemoth (Antlered Bark-Colossus)
  const verdantA = [
    '..oo........oo..',
    '.oano......oano.',
    '.oanoo....oano..',
    '..oanoo..oanoo..',
    '...ooanooanoo...',
    '....oookggkoo...',
    '...ookggggggkoo.',
    '..okgggkkkkgggko',
    '..okggkoooookgko',
    '..okgkoannnaokgo',
    '.ookkoanneeyooko',
    '.okggoannnnnaoko',
    '.okgggoaaaaaoogo',
    '..ookkoonnnnoooo',
    '..oannnnnnnnnnao',
    '.ooannnkggknnnno',
    '.oannnnkggknnnno',
    '.oannnoannnaonno',
    '.oanno.annna.ono',
    '.oano..annna..oo',
    '..oo...annna....',
    '......oannnao...',
    '.....oann.nnao..',
    '.....oano.onao..',
    '.....oano..onao.',
    '.....okko..okko.',
    '....ookko..okkoo',
    '....oooo....oooo',
    '................',
  ];
  const verdantB = verdantA.map((r, idx) => (idx >= 15 && idx <= 20 ? r.replace('.o', 'o.') : r));

  // 2. Mire Leviathan (Twin-Crested Bog Hydra)
  const mireA = [
    '................',
    '...oooo.........',
    '..okggkooo......',
    '.okggggymko.....',
    '.okgyyggggko....',
    '.okgoooggkko....',
    '..ookkggkko..ooo',
    '....ookggko.okgo',
    '.....okggkookggo',
    '....ookgggkkggko',
    '...ookggggggggko',
    '..ookgggmmmmggko',
    '..okgggmmwwmmgko',
    '..okgggmwwwwmgko',
    '.ookggggmmmmggko',
    '.okgggggggggggko',
    '.okggkkkkkkkkggo',
    '.okgkoooooooooko',
    '..ookggggggggkoo',
    '..ookgmmmmmmgkoo',
    '...ookggggggkoo.',
    '....ookkkkkkoo..',
    '...ookggggggkoo.',
    '..ookggkoookggko',
    '..okggko...okgko',
    '..oooo......oooo',
    '................',
  ];
  const mireB = mireA.slice(1).concat(['................']);

  // 3. Glacial Warden (Floating Runic Cryo-Monolith)
  const glacialA = [
    '............oooo',
    '...........ocwwo',
    '..ooo.....ocwcwo',
    '.ocwco...ocwccwo',
    '.occco..ocwcccwo',
    '..ooo...occcbbwo',
    '........occbddbo',
    '..oooo..ocbdyydo',
    '.ocwwco.ocbdywdo',
    '.occcco.ocbddbbo',
    '..oooo..occbbbco',
    '.......oocccccwo',
    '......ocwcccccwo',
    '.....ocwwcbbccwo',
    '.....ocwcbbddcwo',
    '....ocwwcbdyydwo',
    '....occccbdbbcco',
    '.....oocccccccoo',
    '..ooo..occcccco.',
    '.ocwco..ocbbcco.',
    '.ocbco...ocbco..',
    '..ooo....ocbco..',
    '..........occo..',
    '..........oooo..',
    '.........ocwwco.',
    '..........oooo..',
    '................',
  ];
  const glacialB = ['................', ...glacialA.slice(0, -1)];

  // 4. Caldera Tyrant (Horned Obsidian Magma-Wyrm)
  const calderaA = [
    '.oo..........oo.',
    '.oyoo.......oyo.',
    '..oyao.....oyao.',
    '..ozaoo...ozaoo.',
    '...ozzaooozaoo..',
    '.oooozzzzzzzzo..',
    'ozzzzzaarrazzzo.',
    'ozzaaaarrrrazzzo',
    'ozzarrozzzzorazo',
    'ozzarozyyyyzorzo',
    '.oozzozzyyzzoozo',
    '...oozzzzzzzzrzo',
    '..oozzarrrrrazzo',
    '.oozzaryyyyyrazo',
    '.ozzzarrrrrrrazo',
    '.ozzzaozzzzzorzo',
    '.ozzaoozzzzzorzo',
    '..oo..ozzyyzzzzo',
    '......ozzyyzzzzo',
    '.....oozzzzzzzzo',
    '....oozzzzozzzzo',
    '....ozzzzo.ozzzo',
    '...oozzzo..ozzzo',
    '...oyyao...oyyao',
    '...oooo....oooo.',
    '................',
  ];
  const calderaB = calderaA.map((r, i) => (i >= 5 && i <= 11 ? r.replace('ozz', 'ooz') : r));

  // 5. Rust Sovereign (Multi-Armed Reactor Dreadnought)
  const ferricA = [
    '..........oooo..',
    '...ooo...osssso.',
    '..oyyyo..oswwso.',
    '..oycyo.ooszzsoo',
    '...ooo..oszzzzso',
    '.oooooooszzcczso',
    'ossssssszzcwwczo',
    'oswwwwsszzcwwczo',
    'oszzzzsszzzcczzo',
    'oszo.oosssssssss',
    'oszo..oszzzzzzzs',
    'oszo..oszzyyyyzs',
    'oszo..oszyrccyzs',
    'oozo..oszyrccyzs',
    '.ozo..oszzyyyyzs',
    '.ooo..ooszzzzzso',
    '.......ossssssso',
    '......ooszzoozzo',
    '.....ossszo.ozzo',
    '.....oszzo..ozzo',
    '.....oszzo..ozzo',
    '....ooszzo..ozzo',
    '....osssso..osso',
    '....ooooo...oooo',
    '................',
  ];
  const ferricB = ferricA.map((r, i) => (i >= 9 && i <= 15 ? r.replace('oszo', 'osso') : r));

  // 6. Abyssal Herald (Storm-Break Kraken Idol)
  const abyssalA = [
    '.........oooooo.',
    '........odbbbbdo',
    '.......odbbccbdo',
    '......odbbccccbo',
    '.....odbbccccccb',
    '.....odbbccooocb',
    '.....odbbcoayyoc',
    '.....odbbcoaywoc',
    '......odbbcooocb',
    '..ooo..odbbbbbbd',
    '.odbdo..oddddddo',
    '.odcbdooodbbbbdo',
    '..odccbbbbccccbo',
    '...odcccccccccbo',
    '..oodbbbbbbbbbdo',
    '.odbbdooodbbbbdo',
    'odbbdo..odbbddo.',
    'odbdo..odbbdo...',
    'odbo...odbdo....',
    '.oo....odbo..oo.',
    '.......odbo.odbo',
    '........odoodbdo',
    '.........ooooo..',
    '................',
  ];
  const abyssalB = ['................', ...abyssalA];

  return {
    elder_verdant: makePair(
      verdantA,
      verdantB,
      { o: '#14181e', a: '#7f5539', n: '#582f0e', g: '#52b788', k: '#2d6a4f', e: '#ffd166', y: '#fff3b0' },
      { o: '#14181e', a: '#9c6644', n: '#582f0e', g: '#74c69d', k: '#1b4332', e: '#ff595e', y: '#ffd166' },
      '#74c69d'
    ),
    elder_mire: makePair(
      mireA,
      mireB,
      { o: '#14181e', g: '#52b788', k: '#1b4332', m: '#7209b7', y: '#b5e48c', w: '#f72585' },
      { o: '#14181e', g: '#80ed99', k: '#22577a', m: '#b5179e', y: '#ffd166', w: '#ffbe0b' },
      '#b5179e'
    ),
    elder_glacial: makePair(
      glacialA,
      glacialB,
      { o: '#14181e', w: '#ffffff', c: '#a8dadc', b: '#457b9d', d: '#1d3557', y: '#90e0ef' },
      { o: '#14181e', w: '#ffffff', c: '#caf0f8', b: '#00b4d8', d: '#03045e', y: '#ffd166' },
      '#00f5d4'
    ),
    elder_caldera: makePair(
      calderaA,
      calderaB,
      { o: '#14181e', z: '#3d343b', r: '#d62828', a: '#f77f00', y: '#fcbf49' },
      { o: '#14181e', z: '#221d23', r: '#ff2a54', a: '#ff7b00', y: '#fff3b0' },
      '#ff5400'
    ),
    elder_ferric: makePair(
      ferricA,
      ferricB,
      { o: '#14181e', s: '#8d99ae', w: '#edf2f4', z: '#4a4e69', y: '#f4a261', c: '#4cc9f0', r: '#e63946' },
      { o: '#14181e', s: '#adb5bd', w: '#ffffff', z: '#2b2d42', y: '#ffd166', c: '#00f5d4', r: '#ff006e' },
      '#4cc9f0'
    ),
    elder_abyssal: makePair(
      abyssalA,
      abyssalB,
      { o: '#14181e', d: '#1d3557', b: '#2a6f97', c: '#61a5c2', a: '#f77f00', y: '#ffd166', w: '#ffffff' },
      { o: '#14181e', d: '#03045e', b: '#0077b6', c: '#48cae4', a: '#ff006e', y: '#ffbe0b', w: '#ffffff' },
      '#48cae4'
    ),
  };
}

function buildItemAndStructureIcons(images: Record<string, HTMLImageElement>): {
  itemIcons: Record<string, string>;
  itemCanvases: Record<string, HTMLCanvasElement>;
  structures: Record<string, HTMLCanvasElement>;
} {
  const itemCanvases: Record<string, HTMLCanvasElement> = {};
  const structures: Record<string, HTMLCanvasElement> = {};

  const stampCenteredImage = (img: HTMLImageElement): HTMLCanvasElement => {
    const c = makePixelCanvas(16, 16);
    const ctx = c.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    const dx = Math.floor((16 - img.width) / 2);
    const dy = Math.floor((16 - img.height) / 2);
    ctx.drawImage(img, dx, dy);
    return c;
  };

  // Reuse verified CC0 pixel-boy weapon/prop sprites directly where exact fit
  itemCanvases['iron_axe'] = stampCenteredImage(images.axe);
  itemCanvases['iron_broadsword'] = stampCenteredImage(images.bigSword);
  itemCanvases['wooden_club'] = stampCenteredImage(images.club);
  itemCanvases['blueprint_scroll'] = stampCenteredImage(images.book);

  const P = {
    o: '#14181e',
    w: '#f8f9fa',
    s: '#adb5bd',
    z: '#495057',
    n: '#9c6644',
    d: '#582f0e',
    l: '#ddb892',
    r: '#e63946',
    a: '#f4a261',
    y: '#ffd166',
    g: '#52b788',
    k: '#2d6a4f',
    c: '#4cc9f0',
    b: '#4361ee',
    m: '#b5179e',
  };

  const defs: Record<string, string[]> = {
    flint_knife: [
      '..........ooo...',
      '.........oswo...',
      '........osswo...',
      '.......ossswo...',
      '......osssso....',
      '.....oozzso.....',
      '....ondoo.......',
      '...ondno........',
      '..ondno.........',
      '..onoo..........',
      '................',
    ],
    stone_hatchet: [
      '.....oooooo.....',
      '....oswwwwso....',
      '...ossssssszo...',
      '...osssznnzzo...',
      '....oooonnooo...',
      '.......onno.....',
      '......onno......',
      '.....onno.......',
      '....onno........',
      '....ooo.........',
    ],
    stone_pickaxe: [
      '...oooooooooo...',
      '..oswwwwwwwwso..',
      '.osszzooonnzzso.',
      '.oo..o..onno..oo',
      '........onno....',
      '.......onno.....',
      '......onno......',
      '.....onno.......',
      '.....ooo........',
    ],
    iron_pickaxe: [
      '...oooooooooo...',
      '..ocwwwwwwwwco..',
      '.occssooonnssco.',
      '.oo..o..onno..oo',
      '........onno....',
      '.......onno.....',
      '......onno......',
      '.....onno.......',
      '.....ooo........',
    ],
    salvage_crowbar: [
      '........ooooo...',
      '.......orrrro...',
      '.......orrooo...',
      '......orro......',
      '.....orro.......',
      '....ozzo........',
      '...ozzo.........',
      '..orro..........',
      '.orro...........',
      '.ooo............',
    ],
    hunting_spear: [
      '...........ooo..',
      '..........oswo..',
      '.........osswo..',
      '........oonno...',
      '.......onno.....',
      '......onno......',
      '.....onno.......',
      '....onno........',
      '...onno.........',
      '..onno..........',
      '..ooo...........',
    ],
    shortbow: [
      '....ooooo.......',
      '...onnnnoo......',
      '..onno..owo.....',
      '.onno....owo....',
      '.onno.....owo...',
      '.onno....owo....',
      '..onno..owo.....',
      '...onnnnoo......',
      '....ooooo.......',
    ],
    cobalt_greatsword: [
      '...........oooo.',
      '..........ocwwo.',
      '.........occwwo.',
      '........occcwo..',
      '.......occcco...',
      '.....ooyccco....',
      '....oyyycco.....',
      '....onnyyo......',
      '...onno.o.......',
      '..oyyo..........',
      '..ooo...........',
    ],
    wooden_arrow: [
      '..........ooo...',
      '.........oswo...',
      '........oonno...',
      '.......onno.....',
      '......onno......',
      '.....onno.......',
      '....owwo........',
      '...owwo.........',
      '...ooo..........',
    ],
    core_ember: [
      '....oooooooo....',
      '..ooyyyyyyyyoo..',
      '.ooyarrrrrrayoo.',
      '.oyarrrwwrrrryo.',
      '.oyarrwwwwrrryo.',
      '.oyarrrwwrrrryo.',
      '.ooyarrrrrrayoo.',
      '..ooyyyyyyyyoo..',
      '....oooooooo....',
    ],
    core_frost: [
      '....oooooooo....',
      '..ooccccccccoo..',
      '.oocbbbbbbbbcoo.',
      '.ocbbccwwccbbco.',
      '.ocbbcwwwwcbbco.',
      '.ocbbccwwccbbco.',
      '.oocbbbbbbbbcoo.',
      '..ooccccccccoo..',
      '....oooooooo....',
    ],
    core_gale: [
      '....oooooooo....',
      '..ooggggggggoo..',
      '.oogccccccccgoo.',
      '.ogccggwwggccgo.',
      '.ogccgwwwwgccgo.',
      '.ogccggwwggccgo.',
      '.oogccccccccgoo.',
      '..ooggggggggoo..',
      '....oooooooo....',
    ],
    core_volt: [
      '....oooooooo....',
      '..ooccccccccoo..',
      '.oocyyyyyyyycoo.',
      '.ocyyccwwccyyco.',
      '.ocyycwwwwcyyco.',
      '.ocyyccwwccyyco.',
      '.oocyyyyyyyycoo.',
      '..ooccccccccoo..',
      '....oooooooo....',
    ],
    core_thorn: [
      '....oooooooo....',
      '..ookkkkkkkkoo..',
      '.ookggggggggkoo.',
      '.okggkkyykkgkko.',
      '.okggkywwykggko.',
      '.okggkkyykkgkko.',
      '.ookggggggggkoo.',
      '..ookkkkkkkkoo..',
      '....oooooooo....',
    ],
    core_aegis: [
      '....oooooooo....',
      '..ooyyyyyyyyoo..',
      '.ooywwwwwwwwyoo.',
      '.oywwccccccwwyo.',
      '.oywwcwwwwcwwyo.',
      '.oywwccccccwwyo.',
      '.ooywwwwwwwwyoo.',
      '..ooyyyyyyyyoo..',
      '....oooooooo....',
    ],
    fiber_tunic: [
      '...ooo....ooo...',
      '..ogggoooogggo..',
      '.oggggggggggggo.',
      '.ookggggggggkoo.',
      '...okggggggko...',
      '...okggggggko...',
      '...okkkkkkkko...',
      '...oooooooooo...',
    ],
    fur_parka: [
      '...oooooooooo...',
      '..owwwwwwwwwwo..',
      '.ownnnnnnnnnnwo.',
      '.oonnnnnnnnnnoo.',
      '...onnnwwnnno...',
      '...onnnwwnnno...',
      '...owwwwwwwwo...',
      '...oooooooooo...',
    ],
    iron_cuirass: [
      '...ooo....ooo...',
      '..osssoooossso..',
      '.oswwwwwwwwwwso.',
      '.oozsssssssszoo.',
      '...osssssssso...',
      '...oszzzzzzso...',
      '...osssssssso...',
      '...oooooooooo...',
    ],
    straw_hat: [
      '.....oooooo.....',
      '....oyyyyyyo....',
      '...oyyaaaayyo...',
      '.oooyyyyyyyyooo.',
      'oyyyyyyyyyyyyyyo',
      '.oooooooooooooo.',
    ],
    filter_mask: [
      '....oooooooo....',
      '...ozzzzzzzzo...',
      '..ozcccccccczo..',
      '..ozzzzzzzzzzo..',
      '..ookkoookkkoo..',
      '..okgko..okgko..',
      '...ooo....ooo...',
    ],
    cobalt_helm: [
      '....oooooooo....',
      '...occcccccco...',
      '..ocwwbbbbwwco..',
      '..ocbboooobbco..',
      '..ocbbo..obbco..',
      '..occco..occco..',
      '...ooo....ooo...',
    ],
    wood_log: [
      '................',
      '...oooooooooo...',
      '..onllllllllno..',
      '.onlnnnnnnnnlno.',
      '.onndddddddddno.',
      '..oooooooooooo..',
    ],
    plant_fiber: [
      '....oo..oo......',
      '...oggooggoo....',
      '..oggkogggko....',
      '...okgoogkgo....',
      '..ooyyyyyyoo....',
      '...oggkoggo.....',
      '....oo..oo......',
    ],
    stone_chunk: [
      '.....oooooo.....',
      '...ooswwwwsoo...',
      '..ossssssssszo..',
      '..oszzzzzzzzzo..',
      '...oooooooooo...',
    ],
    iron_ore: [
      '.....oooooo.....',
      '...ooszzaasoo...',
      '..ossaaassaaazo.',
      '..oszzzzazzzzzo.',
      '...oooooooooo...',
    ],
    iron_ingot: [
      '................',
      '....ooooooooo...',
      '...oswwwwwwwso..',
      '..ossssssssszo..',
      '..ozzzzzzzzzoo..',
      '...oooooooooo...',
    ],
    coal_lump: [
      '.....oooooo.....',
      '...oozzzzzzoo...',
      '..ozzsszzzzzzo..',
      '..ozzzzzzzzzzo..',
      '...oooooooooo...',
    ],
    peat_brick: [
      '................',
      '...oooooooooo...',
      '..ondddkkdddno..',
      '..onddddddddoo..',
      '...oooooooooo...',
    ],
    cobalt_ore: [
      '......oooo......',
      '....oocwwcoo....',
      '...ocwccccbco...',
      '..occcbbbbbbco..',
      '...oooooooooo...',
    ],
    cobalt_ingot: [
      '................',
      '....ooooooooo...',
      '...ocwwwwwwwco..',
      '..occcccccccbo..',
      '..obbbbbbbbboo..',
      '...oooooooooo...',
    ],
    sulfur_powder: [
      '......oooo......',
      '....ooyyyyo.....',
      '...oyyyyyyyyo...',
      '..oyyaaaaaayyo..',
      '..oooooooooooo..',
    ],
    beast_hide: [
      '..ooo......ooo..',
      '.onnnnoooonnnno.',
      '..onllllllllno..',
      '..onllllllllno..',
      '.onnnnoooonnnno.',
      '..ooo......ooo..',
    ],
    pine_resin: [
      '......oooo......',
      '.....oyyyyo.....',
      '....oyyaayyo....',
      '...oyaaaaaaao...',
      '....oyaaaaao....',
      '.....oooooo.....',
    ],
    clean_water: [
      '.....oooooo.....',
      '.....onnnno.....',
      '....ooccccoo....',
      '...ocwwwwwwco...',
      '...occcccccco...',
      '...ocbbbbbbco...',
      '....oooooooo....',
    ],
    biofuel_can: [
      '....oooooo......',
      '...orrrrrrooo...',
      '..orrrrrrroyo...',
      '..orryyyyrroo...',
      '..orryyyyrro....',
      '..orrrrrrrro....',
      '...oooooooo.....',
    ],
    spares: [
      '....ooo..ooo....',
      '...osssoossso...',
      '..oszzzozzzzso..',
      '...osssoyyyyo...',
      '....ooooyyyyo...',
      '........oooo....',
    ],
    scrap_metal: [
      '...oooooooooo...',
      '..ossszzaasszo..',
      '.osszzaaaasszo..',
      '..oozzzzzzzzoo..',
      '....oooooooo....',
    ],
    circuit_board: [
      '..oooooooooooo..',
      '.okggggggggggko.',
      '.okgyygyygyygko.',
      '.okggccccccggko.',
      '.okgyygyygyygko.',
      '..oooooooooooo..',
    ],
    depleted_core_shell: [
      '....oooooooo....',
      '..oossssssssoo..',
      '.ooszzzzzzzzsoo.',
      '.oszzssoosszzso.',
      '.oszzso..oszzso.',
      '.ooszzzzzzzzsoo.',
      '..oossssssssoo..',
      '....oooooooo....',
    ],
    wild_berries: [
      '......oooo......',
      '.....okggko.....',
      '...oorroorroo...',
      '..orwrroorwrro..',
      '...oorroorroo...',
      '.....orrrro.....',
      '......oooo......',
    ],
    raw_meat: [
      '....oooooooo....',
      '..oorrrrrrrroo..',
      '.oorrwwrrrrrroo.',
      '.oorrwwrrrrrroo.',
      '..ooorrrrrrooo..',
      '.....oowwoo.....',
      '......oooo......',
    ],
    roasted_meat: [
      '....oooooooo....',
      '..oonnaaaaaaoo..',
      '.oonnaayyaaaaoo.',
      '.oonnddddddaaoo.',
      '..ooonnnnnnooo..',
      '.....oolloo.....',
      '......oooo......',
    ],
    grain_seed: [
      '....oo....oo....',
      '...oyyo..oyyo...',
      '...oo..oo..oo...',
      '......oyyo......',
      '.......oo.......',
    ],
    golden_grain: [
      '.....oo..oo.....',
      '....oyyooyyo....',
      '...oyyooyyo.....',
      '....oyyyyo......',
      '.....oggo.......',
      '.....oggo.......',
      '......oo........',
    ],
    travel_ration: [
      '................',
      '...oooooooooo...',
      '..oyllllllllao..',
      '.oylaaaaaaaaano.',
      '.onnnnnnnnnnnno.',
      '..oooooooooooo..',
    ],
    herbal_bandage: [
      '..oooooooooooo..',
      '.owwwwwwwwwwwwo.',
      '.owwwwggwwwwwo..',
      '.owwwggggwwwwo..',
      '.owwwwggwwwwwo..',
      '..oooooooooooo..',
    ],
    antidote_tonic: [
      '.....oooooo.....',
      '.....onnnno.....',
      '....ooggggoo....',
      '...ogwwwwwwgo...',
      '...oggggggggo...',
      '...okkkkkkkko...',
      '....oooooooo....',
    ],
    marsh_herb_leaf: [
      '.......ooo......',
      '.....oogggo.....',
      '...oogggkggo....',
      '..oggccggkgo....',
      '...ooggkggo.....',
      '....okkooo......',
      '...okko.........',
    ],
    copper_fuse: [
      '....oooooooo....',
      '...oaaaaaaaao...',
      '...occcccccco...',
      '...ocwwwwwwco...',
      '...occcccccco...',
      '...oaaaaaaaao...',
      '....oooooooo....',
    ],
    blue_keycard: [
      '..oooooooooooo..',
      '.occcccccccccco.',
      '.ocwwwwbbbbbcco.',
      '.ocbbbbbbbbbbco.',
      '.ocyyyybbbbbbco.',
      '..oooooooooooo..',
    ],
    handcart_kit: [
      '..oooooooooooo..',
      '.onllllllllllno.',
      '.onnnnnnnnnnnno.',
      '..oozzzzzzzzoo..',
      '...ozzo..ozzo...',
      '...oooo..oooo...',
    ],
    escrow_chest_kit: [
      '..oooooooooooo..',
      '.oyyyyyyyyyyyyo.',
      '.oybbbbbbbbbbbyo',
      '.oyyyyyccyyyyyyo',
      '.oybbbbccbbbbbyo',
      '.oyyyyyyyyyyyyo.',
      '..oooooooooooo..',
    ],
    ragnarok_cash: [
      '..oooooooooooo..',
      '.oyyyyyyyyyyyyo.',
      '.oyggggyyggggyo.',
      '.oygyyyyyyyygyo.',
      '.oyggggyyggggyo.',
      '.oyyyyyyyyyyyyo.',
      '..oooooooooooo..',
    ],
    stone_verdant: [
      '.....oooooo.....',
      '...ookggggkoo...',
      '..okggwwwwggko..',
      '..okggwggwggko..',
      '...ookggggkoo...',
      '.....oooooo.....',
    ],
    stone_mire: [
      '.....oooooo.....',
      '...oommmmmmoo...',
      '..ommmwwwwmmmo..',
      '..ommmwggwmmmo..',
      '...oommmmmmoo...',
      '.....oooooo.....',
    ],
    stone_glacial: [
      '.....oooooo.....',
      '...ooccccccoo...',
      '..occcwwwwccco..',
      '..occcwbbwccco..',
      '...ooccccccoo...',
      '.....oooooo.....',
    ],
    stone_caldera: [
      '.....oooooo.....',
      '...oorrrrrroo...',
      '..orrrwwwwrrro..',
      '..orrrwyywrrro..',
      '...oorrrrrroo...',
      '.....oooooo.....',
    ],
    stone_ferric: [
      '.....oooooo.....',
      '...ooyyyyyyoo...',
      '..oyyywwwwyyyo..',
      '..oyyywccwyyyo..',
      '...ooyyyyyyoo...',
      '.....oooooo.....',
    ],
    stone_abyssal: [
      '.....oooooo.....',
      '...oobbbbbboo...',
      '..obbbwwwwbbbo..',
      '..obbbwccwbbbo..',
      '...oobbbbbboo...',
      '.....oooooo.....',
    ],
  };

  for (const [key, rows] of Object.entries(defs)) {
    const padTop = Math.floor((16 - rows.length) / 2);
    const padded = [...new Array<string>(Math.max(0, padTop)).fill('................'), ...rows];
    itemCanvases[key] = drawMatrix(padded, P);
  }

  // Author crisp 16x16 world sprites for structures & stations
  const structDefs: Record<string, string[]> = {
    homestead_stake: [
      '......oooo......',
      '.....oyyyyo.....',
      '....oyrrrrryo...',
      '.....oyyyyo.....',
      '......onno......',
      '.....onllno.....',
      '.....onnnno.....',
      '.....onnnno.....',
      '....oonnnnoo....',
      '...oooooooooo...',
    ],
    bedroll: [
      '..oooooooooooo..',
      '.onwwwwbbbbbno..',
      '.onwwwwbbbbbbno.',
      '.onwwwwbbbbbbno.',
      '.onnnnnnnnnnnno.',
      '..oooooooooooo..',
    ],
    campfire: [
      '......oooo......',
      '.....oyyyyo.....',
      '....oyarryyo....',
      '...oyarrrrayo...',
      '..oosnnnnnnsoo..',
      '.osszzzzzzzzsso.',
      '..oooooooooooo..',
    ],
    workbench: [
      '.oooooooooooooo.',
      'onllllllllllllno',
      'onnnssnnnnyyynno',
      'onnnnnnnnnnnnnno',
      '.oonno....onnoo.',
      '..onno....onno..',
      '..oooo....oooo..',
    ],
    stone_furnace: [
      '..oooooooooooo..',
      '.osssssssssssso.',
      '.oszzzzzzzzzzso.',
      '.oszzoooooozzso.',
      '.oszzoarryozzzo.',
      '.oszzoarryozzzo.',
      '.oszzzzzzzzzzso.',
      '..oooooooooooo..',
    ],
    research_table: [
      '.oooooooooooooo.',
      'onbbbbbbbbbbbbno',
      'onbbwwwwccyybbno',
      'onnnnnnnnnnnnnno',
      '.oonno....onnoo.',
      '..onno....onno..',
      '..oooo....oooo..',
    ],
    planter_box: [
      '.oooooooooooooo.',
      'onnddddddddddno.',
      'onndggdkkdggdno.',
      'onndggddddggdno.',
      'onnnnnnnnnnnnno.',
      '.oooooooooooooo.',
    ],
    rain_collector: [
      '..oooooooooooo..',
      '.onccccccccccno.',
      '.oncwwwwwwwwcno.',
      '..onccccccccno..',
      '..onnnnnnnnnno..',
      '..onnnnnnnnnno..',
      '...oooooooooo...',
    ],
    storage_chest: [
      '..oooooooooooo..',
      '.onllllllllllno.',
      '.onnnnnnnnnnnno.',
      '.onnnnyyyynnnno.',
      '.onnnnnnnnnnnno.',
      '.onddddddddddno.',
      '..oooooooooooo..',
    ],
    spike_barricade: [
      '..oo...oo...oo..',
      '.ollo.ollo.ollo.',
      '.onnooonnooonno.',
      'oonnnnnnnnnnnnoo',
      '.onno.onno.onno.',
      '.oooo.oooo.oooo.',
    ],
    generator: [
      '..oooooooooooo..',
      '.orrrrrrrrrrrro.',
      '.orryyzzzzccrro.',
      '.orryyzzzzccrro.',
      '.ozzzzzzzzzzzzo.',
      '..oooooooooooo..',
    ],
    shock_turret: [
      '......oooo......',
      '....oocwwcoo....',
      '....occcccco....',
      '.....ossso......',
      '....oszzzzso....',
      '...osssyyssso...',
      '..oooooooooooo..',
    ],
    handcart: [
      '.oooooooooooo...',
      'onllllllllllnoo.',
      'onnnnnnnnnnnnno.',
      'onddddddddddno..',
      '.oozzoooozzoo...',
      '..ozzo..ozzo....',
      '..oooo..oooo....',
    ],
    escrow_chest: [
      '.oooooooooooooo.',
      'oyyyyyyyyyyyyyyo',
      'oybbbbbbbbbbbbyo',
      'oyyyyyccccyyyyyo',
      'oybbbbccccbbbbyo',
      'oybbbbbbbbbbbbyo',
      'oyyyyyyyyyyyyyyo',
      '.oooooooooooooo.',
    ],
    vendor_escrow_broker: [
      '..oooooooooooo..',
      '.oyyyyyyyyyyyyo.',
      '.orrrrrrrrrrrro.',
      '.oowwoooooowwoo.',
      '..onnooyyooonno.',
      '.onllllllllllno.',
      '.onnnnnnnnnnnno.',
      '..oooooooooooo..',
    ],
    vendor_season_shop: [
      '..oooooooooooo..',
      '.occcccccccccco.',
      '.obbbbbbbbbbbbo.',
      '.oowwoooooowwoo.',
      '..onnooccooonno.',
      '.onllllllllllno.',
      '.onnnnnnnnnnnno.',
      '..oooooooooooo..',
    ],
    evac_beacon: [
      '......oooo......',
      '.....ocwwco.....',
      '....ocwwwwco....',
      '.....occcco.....',
      '......osso......',
      '.....oszzso.....',
      '....osyyyyso....',
      '...oszzzzzzso...',
      '..oooooooooooo..',
    ],
    poi_power_box: [
      '...oooooooooo...',
      '..osssssssssso..',
      '..oszyyyyyyzso..',
      '..oszyrrrrryso..',
      '..oszzzzzzzzso..',
      '...oooooooooo...',
    ],
    death_bag: [
      '.....oooooo.....',
      '....oyyyyyyo....',
      '...oonnnnnnoo...',
      '..onllllllllno..',
      '..onllrrrrllno..',
      '..onnnnnnnnnno..',
      '...oooooooooo...',
    ],
    world_drop: [
      '.....oooooo.....',
      '....onllllno....',
      '...onnnnnnnno...',
      '...onddddddno...',
      '....oooooooo....',
    ],
  };

  for (const [key, rows] of Object.entries(structDefs)) {
    const padTop = Math.floor((16 - rows.length) / 2);
    const padded = [...new Array<string>(Math.max(0, padTop)).fill('................'), ...rows];
    structures[key] = drawMatrix(padded, P);
  }

  const itemIcons: Record<string, string> = {};
  for (const [k, canvas] of Object.entries(itemCanvases)) {
    itemIcons[k] = canvas.toDataURL('image/png');
  }
  for (const [k, canvas] of Object.entries(structures)) {
    if (!itemIcons[k]) itemIcons[k] = canvas.toDataURL('image/png');
  }

  return { itemIcons, itemCanvases, structures };
}

function loadImg(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    img.src = src;
  });
}

export function loadArtAtlas(): Promise<LoadedArtAtlas> {
  if (singletonAtlas) return Promise.resolve(singletonAtlas);
  if (loadPromise) return loadPromise;

  const manifest: Record<string, string> = {
    shadow: shadowUrl,
    ninjaBlue: ninjaBlueUrl,
    samuraiBlue: samuraiBlueUrl,
    samuraiGreen: samuraiGreenUrl,
    pig: pigUrl,
    tilesetFloor: tilesetFloorUrl,
    tilesetInterior: tilesetInteriorUrl,
    tilesetVillage: tilesetVillageUrl,
    tilesetWall: tilesetWallUrl,
    tilesetAnimated: tilesetAnimatedUrl,
    crate: crateUrl,
    pot: potUrl,
    grassProp: grassPropUrl,
    axe: axeUrl,
    axeHand: axeHandUrl,
    bigSword: bigSwordUrl,
    bigSwordHand: bigSwordHandUrl,
    bone: boneUrl,
    book: bookUrl,
    club: clubUrl,
    clubHand: clubHandUrl,
    particleWood: particleWoodUrl,
    particleRock: particleRockUrl,
    particleGrass: particleGrassUrl,
    rainFloor: rainFloorUrl,
    snowFx: snowFxUrl,
    heart: heartUrl,
  };

  loadPromise = (async () => {
    const entries = await Promise.all(
      Object.entries(manifest).map(async ([k, url]) => [k, await loadImg(url)] as const)
    );
    const images: Record<string, HTMLImageElement> = Object.fromEntries(entries);
    const femaleAdventurerSheet = buildFemaleAdventurerFromMale(images.samuraiBlue);
    const customCreatures = buildCustomCreatureFrames();
    const elders = buildSixElders();
    const { itemIcons, itemCanvases, structures } = buildItemAndStructureIcons(images);

    singletonAtlas = {
      ready: true,
      images,
      femaleAdventurerSheet,
      customCreatures,
      elders,
      structures,
      itemIcons,
      itemCanvases,
    };
    return singletonAtlas;
  })();

  return loadPromise;
}

export function getLoadedArtAtlas(): LoadedArtAtlas | null {
  return singletonAtlas;
}
