import balance from '../data/balance.v1.json';
import { ITEMS_CATALOG } from '../data/itemsCatalog';
import { STRUCTURES_CATALOG } from '../data/structuresCatalog';
import { LoadedArtAtlas } from '../art/pixelSprites';
import { getActiveQuickbarItem } from '../engine/custody';
import { canBuildAtTile, isInFinal72Hours } from '../engine/simulation';
import { GameState, NpcTelegraph, SourceNode, StructureEntity, StructureKind } from '../engine/types';
import { getStaticIslandMap, StaticIslandMap } from '../engine/worldGen';

export const LOGICAL_WIDTH = 640;
export const LOGICAL_HEIGHT = 360;
export const TILE_PX = 16;
const CHUNK_TILES = 16;
const CHUNK_PX = CHUNK_TILES * TILE_PX;

interface ChunkCache {
  seed: number;
  chunks: Map<string, HTMLCanvasElement>;
}

let chunkCache: ChunkCache | null = null;

function hash2D(x: number, y: number): number {
  let n = Math.imul(x, 374761393) + Math.imul(y, 668265263);
  n = (n ^ (n >>> 13)) >>> 0;
  return (Math.imul(n, 1274126177) >>> 0) / 4294967296;
}

function getOrBuildChunkCanvas(
  map: StaticIslandMap,
  atlas: LoadedArtAtlas,
  cx: number,
  cy: number
): HTMLCanvasElement {
  if (!chunkCache || chunkCache.seed !== map.seed) {
    chunkCache = { seed: map.seed, chunks: new Map() };
  }
  const key = `${cx},${cy}`;
  const hit = chunkCache.chunks.get(key);
  if (hit) return hit;

  const canvas = document.createElement('canvas');
  canvas.width = CHUNK_PX;
  canvas.height = CHUNK_PX;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  const floorImg = atlas.images.tilesetFloor;
  const intImg = atlas.images.tilesetInterior;
  const wallImg = atlas.images.tilesetWall;
  const grassProp = atlas.images.grassProp;

  const startX = cx * CHUNK_TILES;
  const startY = cy * CHUNK_TILES;

  for (let ly = 0; ly < CHUNK_TILES; ly++) {
    const ty = startY + ly;
    if (ty >= map.height) continue;
    for (let lx = 0; lx < CHUNK_TILES; lx++) {
      const tx = startX + lx;
      if (tx >= map.width) continue;

      const i = ty * map.width + tx;
      const biome = map.biomes[i];
      const surf = map.surfaces[i];
      const elev = map.elevation[i];
      const px = lx * TILE_PX;
      const py = ly * TILE_PX;
      const h = hash2D(tx, ty);

      // Base tile blit from verified seamless interior cells of CC0 NinjaAdventure 16x16 tilesets
      const variantCol = Math.floor(h * 5); // 0..4
      if (surf === 'water') {
        const wCol = h > 0.65 ? 5 : h > 0.35 ? 6 : 1;
        ctx.drawImage(floorImg, wCol * 16, 22 * 16, 16, 16, px, py, 16, 16);
        ctx.fillStyle = biome === 'ocean' ? 'rgba(26, 78, 114, 0.42)' : 'rgba(38, 108, 145, 0.28)';
        ctx.fillRect(px, py, 16, 16);
        if (h > 0.82) {
          ctx.fillStyle = '#dff6ff';
          ctx.fillRect(px + 3, py + 7, 4, 1);
          ctx.fillRect(px + 9, py + 11, 3, 1);
        }
      } else if (surf === 'shallow') {
        const wCol = h > 0.5 ? 5 : 1;
        ctx.drawImage(floorImg, wCol * 16, 22 * 16, 16, 16, px, py, 16, 16);
        // Crisp directional coastline foam & wet sand rim where adjacent to dry land!
        const nLand = ty > 0 && map.elevation[i - map.width] > 0;
        const sLand = ty < map.height - 1 && map.elevation[i + map.width] > 0;
        const wLand = tx > 0 && map.elevation[i - 1] > 0;
        const eLand = tx < map.width - 1 && map.elevation[i + 1] > 0;
        ctx.fillStyle = '#ffffff';
        if (nLand) {
          ctx.fillRect(px + 1, py + 1, 6, 1);
          ctx.fillRect(px + 9, py + 2, 5, 1);
        }
        if (sLand) {
          ctx.fillRect(px + 2, py + 14, 5, 1);
          ctx.fillRect(px + 9, py + 13, 5, 1);
        }
        if (wLand) {
          ctx.fillRect(px + 1, py + 2, 1, 5);
          ctx.fillRect(px + 2, py + 9, 1, 5);
        }
        if (eLand) {
          ctx.fillRect(px + 14, py + 2, 1, 5);
          ctx.fillRect(px + 13, py + 9, 1, 5);
        }
      } else if (surf === 'sand') {
        ctx.drawImage(floorImg, variantCol * 16, 5 * 16, 16, 16, px, py, 16, 16);
        if (h > 0.78) {
          ctx.fillStyle = '#d08c3f';
          ctx.fillRect(px + 5, py + 9, 2, 1);
        }
      } else if (surf === 'scorch') {
        ctx.drawImage(floorImg, 12 * 16, 8 * 16, 16, 16, px, py, 16, 16);
        ctx.fillStyle = 'rgba(72, 24, 18, 0.44)';
        ctx.fillRect(px, py, 16, 16);
        if (h > 0.74) {
          ctx.fillStyle = '#ff7b00';
          ctx.fillRect(px + 6, py + 6, 2, 1);
        }
      } else if (surf === 'snow') {
        const sCol = h > 0.6 ? 4 : 0;
        ctx.drawImage(floorImg, sCol * 16, 19 * 16, 16, 16, px, py, 16, 16);
        if (h > 0.72) {
          ctx.fillStyle = '#bcd4e6';
          ctx.fillRect(px + 4, py + 10, 3, 1);
        }
      } else if (surf === 'mud') {
        const mCol = h > 0.5 ? 14 : 12;
        const mRow = h > 0.5 ? 18 : 15;
        ctx.drawImage(floorImg, mCol * 16, mRow * 16, 16, 16, px, py, 16, 16);
        ctx.fillStyle = 'rgba(42, 58, 38, 0.32)';
        ctx.fillRect(px, py, 16, 16);
        if (h > 0.64) {
          ctx.fillStyle = '#386641';
          ctx.fillRect(px + 3, py + 4, 2, 2);
        }
      } else if (surf === 'toxic_concrete') {
        ctx.drawImage(intImg, 13 * 16, 15 * 16, 16, 16, px, py, 16, 16);
        if (h > 0.78) {
          ctx.fillStyle = '#80ed99';
          ctx.fillRect(px + 6, py + 8, 2, 1);
        }
      } else if (surf === 'stone_floor') {
        ctx.drawImage(intImg, 13 * 16, 10 * 16, 16, 16, px, py, 16, 16);
      } else if (surf === 'road') {
        const rRow = h > 0.5 ? 11 : 8;
        const rCol = h > 0.5 ? 14 : 12;
        ctx.drawImage(floorImg, rCol * 16, rRow * 16, 16, 16, px, py, 16, 16);
        // Crisp pixel road-verge stones where road meets grass/sand
        const nNotRoad = ty > 0 && map.surfaces[i - map.width] !== 'road' && map.surfaces[i - map.width] !== 'bridge';
        const sNotRoad =
          ty < map.height - 1 && map.surfaces[i + map.width] !== 'road' && map.surfaces[i + map.width] !== 'bridge';
        const wNotRoad = tx > 0 && map.surfaces[i - 1] !== 'road' && map.surfaces[i - 1] !== 'bridge';
        const eNotRoad = tx < map.width - 1 && map.surfaces[i + 1] !== 'road' && map.surfaces[i + 1] !== 'bridge';
        ctx.fillStyle = '#6c584c';
        if (nNotRoad) ctx.fillRect(px + 1, py, 14, 2);
        if (sNotRoad) ctx.fillRect(px + 1, py + 14, 14, 2);
        if (wNotRoad) ctx.fillRect(px, py + 1, 2, 14);
        if (eNotRoad) ctx.fillRect(px + 14, py + 1, 2, 14);
      } else if (surf === 'bridge') {
        ctx.fillStyle = '#7f5539';
        ctx.fillRect(px, py, 16, 16);
        ctx.fillStyle = '#582f0e';
        ctx.fillRect(px, py, 16, 2);
        ctx.fillRect(px, py + 14, 16, 2);
        ctx.fillStyle = '#b08968';
        for (let bx = 1; bx < 16; bx += 4) {
          ctx.fillRect(px + bx, py + 2, 2, 12);
        }
      } else if (surf === 'rock') {
        const rkCol = h > 0.66 ? 15 : h > 0.33 ? 13 : 11;
        ctx.drawImage(floorImg, rkCol * 16, 19 * 16, 16, 16, px, py, 16, 16);
      } else if (surf === 'forest_floor') {
        const fCol = h > 0.66 ? 15 : h > 0.33 ? 13 : 11;
        ctx.drawImage(floorImg, fCol * 16, 12 * 16, 16, 16, px, py, 16, 16);
        if (h > 0.82) {
          ctx.drawImage(grassProp, 0, 0, 16, 16, px, py, 16, 16);
        }
      } else {
        // Seamless Meadow / Steppe grass (row 12, cols 0..4)
        ctx.drawImage(floorImg, variantCol * 16, 12 * 16, 16, 16, px, py, 16, 16);
        if (h > 0.85) {
          ctx.drawImage(grassProp, 0, 0, 16, 16, px, py, 16, 16);
        } else if (h < 0.06) {
          ctx.fillStyle = h < 0.03 ? '#ffd166' : '#ff758f';
          ctx.fillRect(px + 7, py + 6, 2, 2);
        }
      }

      // Soft pixel grass-verge fringe where grass/forest meets sand beach!
      if (surf === 'sand') {
        ctx.fillStyle = '#99b83c';
        if (ty > 0 && (map.surfaces[i - map.width] === 'grass' || map.surfaces[i - map.width] === 'forest_floor')) {
          ctx.fillRect(px, py, 16, 2);
          ctx.fillRect(px + 3, py + 2, 3, 1);
          ctx.fillRect(px + 10, py + 2, 4, 1);
        }
        if (
          ty < map.height - 1 &&
          (map.surfaces[i + map.width] === 'grass' || map.surfaces[i + map.width] === 'forest_floor')
        ) {
          ctx.fillRect(px, py + 14, 16, 2);
          ctx.fillRect(px + 2, py + 13, 4, 1);
          ctx.fillRect(px + 11, py + 13, 3, 1);
        }
      }

      // Cliff / POI Masonry Walls (elevation === 3)
      if (elev === 3) {
        if (surf === 'stone_floor' || surf === 'toxic_concrete') {
          // Crisp POI Vault Masonry Wall from CC0 tileset_wall_simple.png
          ctx.drawImage(wallImg, 5 * 16, 5 * 16, 16, 16, px, py, 16, 16);
          ctx.fillStyle = '#14181e';
          ctx.strokeRect(px + 0.5, py + 0.5, 15, 15);
        } else {
          // Highland Rock Cliff Block
          ctx.drawImage(wallImg, 0, 5 * 16, 16, 16, px, py, 16, 16);
        }
      } else if (elev === 2 && ty < map.height - 1 && map.elevation[i + map.width] < 2) {
        // Subtle plateau south lip depth shadow
        ctx.fillStyle = 'rgba(20, 24, 30, 0.28)';
        ctx.fillRect(px, py + 13, 16, 3);
      }
    }
  }

  chunkCache.chunks.set(key, canvas);
  return canvas;
}

export interface RenderViewportOptions {
  buildPreviewKind: StructureKind | null;
  cursorWorldX: number;
  cursorWorldY: number;
  nowMs: number;
  nearestPrompt: { x: number; y: number; label: string } | null;
}

export function renderGameWorld(
  ctx: CanvasRenderingContext2D,
  state: GameState,
  atlas: LoadedArtAtlas,
  opts: RenderViewportOptions
): { camX: number; camY: number } {
  ctx.imageSmoothingEnabled = false;
  const map = getStaticIslandMap(state.world.seed);
  const player = state.actors.player;

  // Restrained pixel-snapped hit/impact camera shake
  let shakeX = 0;
  let shakeY = 0;
  if (opts.nowMs < player.invulnUntilMs) {
    shakeX = ((Math.floor(opts.nowMs / 35) % 2) * 2 - 1) * 2;
    shakeY = ((Math.floor(opts.nowMs / 45) % 2) * 2 - 1) * 1;
  }

  const maxCamX = map.width * TILE_PX - LOGICAL_WIDTH;
  const maxCamY = map.height * TILE_PX - LOGICAL_HEIGHT;
  const camX = Math.max(0, Math.min(maxCamX, Math.round(player.x * TILE_PX - LOGICAL_WIDTH / 2) + shakeX));
  const camY = Math.max(0, Math.min(maxCamY, Math.round(player.y * TILE_PX - LOGICAL_HEIGHT / 2) + shakeY));

  ctx.fillStyle = '#1b3a4b';
  ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);

  // 1. Blit Visible Cached 16x16 Tile Chunks
  const minCx = Math.max(0, Math.floor(camX / CHUNK_PX));
  const maxCx = Math.min(Math.ceil(map.width / CHUNK_TILES) - 1, Math.floor((camX + LOGICAL_WIDTH) / CHUNK_PX));
  const minCy = Math.max(0, Math.floor(camY / CHUNK_PX));
  const maxCy = Math.min(Math.ceil(map.height / CHUNK_TILES) - 1, Math.floor((camY + LOGICAL_HEIGHT) / CHUNK_PX));

  for (let cy = minCy; cy <= maxCy; cy++) {
    for (let cx = minCx; cx <= maxCx; cx++) {
      const chunk = getOrBuildChunkCanvas(map, atlas, cx, cy);
      ctx.drawImage(chunk, cx * CHUNK_PX - camX, cy * CHUNK_PX - camY);
    }
  }

  const minTileX = Math.max(0, Math.floor(camX / TILE_PX) - 3);
  const maxTileX = Math.min(map.width - 1, Math.ceil((camX + LOGICAL_WIDTH) / TILE_PX) + 3);
  const minTileY = Math.max(0, Math.floor(camY / TILE_PX) - 3);
  const maxTileY = Math.min(map.height - 1, Math.ceil((camY + LOGICAL_HEIGHT) / TILE_PX) + 4);

  // 2. Render Scorched Tiles, Homestead Territory Borders & Floor Foundations
  for (const key of state.world.scorchedTiles) {
    const [sxStr, syStr] = key.split(',');
    const sx = Number(sxStr);
    const sy = Number(syStr);
    if (sx < minTileX || sx > maxTileX || sy < minTileY || sy > maxTileY) continue;
    ctx.fillStyle = 'rgba(22, 18, 20, 0.45)';
    ctx.fillRect(sx * 16 - camX + 1, sy * 16 - camY + 1, 14, 14);
  }

  // Subtle pixel corner posts showing player's owned Homestead boundary
  for (const h of state.world.homesteads) {
    const hScreenX = Math.round(h.centerX * 16 - camX);
    const hScreenY = Math.round(h.centerY * 16 - camY);
    const rPx = h.radiusTiles * 16;
    if (
      hScreenX + rPx >= 0 &&
      hScreenX - rPx <= LOGICAL_WIDTH &&
      hScreenY + rPx >= 0 &&
      hScreenY - rPx <= LOGICAL_HEIGHT
    ) {
      ctx.strokeStyle = 'rgba(244, 211, 94, 0.28)';
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(hScreenX - rPx + 0.5, hScreenY - rPx + 0.5, rPx * 2, rPx * 2);
      ctx.setLineDash([]);
    }
  }

  // Floor Foundations
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0) continue;
    if (ent.tileX < minTileX || ent.tileX > maxTileX || ent.tileY < minTileY || ent.tileY > maxTileY) continue;
    const px = ent.tileX * 16 - camX;
    const py = ent.tileY * 16 - camY;
    if (ent.kind === 'wood_floor') {
      ctx.drawImage(atlas.images.tilesetInterior, 1 * 16, 2 * 16, 16, 16, px, py, 16, 16);
      ctx.fillStyle = '#582f0e';
      ctx.fillRect(px, py, 16, 1);
      ctx.fillRect(px, py + 15, 16, 1);
    } else if (ent.kind === 'stone_floor') {
      ctx.drawImage(atlas.images.tilesetInterior, 1 * 16, 14 * 16, 16, 16, px, py, 16, 16);
    }
  }

  // 3. Surface-Specific Decaying Footprint Traces (C08)
  for (const fp of state.world.footprints) {
    const fx = Math.round(fp.x * 16 - camX);
    const fy = Math.round(fp.y * 16 - camY);
    if (fx < -8 || fx > LOGICAL_WIDTH + 8 || fy < -8 || fy > LOGICAL_HEIGHT + 8) continue;
    ctx.globalAlpha = Math.max(0.15, fp.strength * 0.7);
    ctx.fillStyle =
      fp.surface === 'snow'
        ? '#729ea1'
        : fp.surface === 'mud'
        ? '#231f20'
        : fp.surface === 'sand'
        ? '#b07d3b'
        : '#3d2c1e';
    ctx.fillRect(fx - 2, fy - 1, 2, 2);
    ctx.fillRect(fx + 1, fy + 1, 2, 2);
  }
  ctx.globalAlpha = 1;

  // 4. Build Placement Tile Preview Ghost
  if (opts.buildPreviewKind && !player.dead) {
    const btx = Math.floor(opts.cursorWorldX);
    const bty = Math.floor(opts.cursorWorldY);
    const check = canBuildAtTile(state, opts.buildPreviewKind, btx, bty);
    const bpx = btx * 16 - camX;
    const bpy = bty * 16 - camY;
    ctx.fillStyle = check.ok ? 'rgba(82, 183, 136, 0.35)' : 'rgba(230, 57, 70, 0.38)';
    ctx.fillRect(bpx, bpy, 16, 16);
    ctx.strokeStyle = check.ok ? '#74c69d' : '#ff5964';
    ctx.strokeRect(bpx + 0.5, bpy + 0.5, 15, 15);
    const spr = atlas.structures[opts.buildPreviewKind];
    if (spr) {
      ctx.globalAlpha = 0.72;
      ctx.drawImage(spr, bpx, bpy);
      ctx.globalAlpha = 1;
    }
  }

  // 5. Crisp Pixel Enemy & Elder Attack Telegraphs (Ground Layer)
  for (const mob of Object.values(state.actors.monsters)) {
    if (mob.aiState !== 'TELEGRAPH' || !mob.telegraph) continue;
    drawCrispTelegraph(ctx, mob.telegraph, state.clock.elapsedSimSec, camX, camY);
  }

  // 6. Collect & Y-Sort All Visible World Renderables (Sources, Structures, Monsters, Elders, Player)
  type DrawItem = { sortY: number; draw: () => void };
  const drawList: DrawItem[] = [];

  // 6a. Source Nodes (Trees, Stumps, Rocks, Ore Veins, Bushes, Crates, Lockers, Final-72 Vaults)
  for (const s of Object.values(state.sources)) {
    const tx = Math.floor(s.x);
    const ty = Math.floor(s.y);
    if (tx < minTileX || tx > maxTileX || ty < minTileY || ty > maxTileY) continue;
    const sx = Math.round(s.x * 16 - camX);
    const sy = Math.round(s.y * 16 - camY);

    if (s.stock <= 0) {
      // Depleted tree leaves a crisp tree stump from CC0 tileset_village_abandoned.png!
      if (s.kind === 'pine_tree' || s.kind === 'oak_tree') {
        drawList.push({
          sortY: s.y,
          draw: () => {
            ctx.drawImage(atlas.images.tilesetVillage, 112, 112, 16, 16, sx - 8, sy - 8, 16, 16);
          },
        });
      }
      continue;
    }

    drawList.push({
      sortY: s.y,
      draw: () => drawSourceNode(ctx, atlas, state, s, sx, sy, opts.nowMs),
    });
  }

  // 6b. Non-Floor, Non-Roof Structures & Entities
  const roofsToDraw: StructureEntity[] = [];
  for (const ent of Object.values(state.entities)) {
    if (ent.hp <= 0) continue;
    const def = STRUCTURES_CATALOG[ent.kind];
    if (def?.isFloor) continue;
    if (def?.isRoof) {
      if (ent.tileX >= minTileX && ent.tileX <= maxTileX && ent.tileY >= minTileY && ent.tileY <= maxTileY) {
        roofsToDraw.push(ent);
      }
      continue;
    }
    const ex = Math.floor(ent.x);
    const ey = Math.floor(ent.y);
    if (ex < minTileX || ex > maxTileX || ey < minTileY || ey > maxTileY) continue;

    drawList.push({
      sortY: ent.y,
      draw: () => drawStructureEntity(ctx, atlas, state, ent, camX, camY, opts.nowMs),
    });
  }

  // 6c. Dynamic Ground Fires
  for (const f of state.world.fires) {
    if (f.tileX < minTileX || f.tileX > maxTileX || f.tileY < minTileY || f.tileY > maxTileY) continue;
    const fx = f.tileX * 16 - camX;
    const fy = f.tileY * 16 - camY;
    const flick = Math.floor(opts.nowMs / 100 + f.tileX) % 2;
    drawList.push({
      sortY: f.tileY + 0.6,
      draw: () => {
        ctx.fillStyle = '#14181e';
        ctx.fillRect(fx + 3, fy + 6, 10, 8);
        ctx.fillStyle = '#e63946';
        ctx.fillRect(fx + 4, fy + 4 + flick, 8, 9 - flick);
        ctx.fillStyle = '#ffd166';
        ctx.fillRect(fx + 6, fy + 6, 4, 6);
      },
    });
  }

  // 6d. Monsters & Six Elders
  for (const mob of Object.values(state.actors.monsters)) {
    if (mob.aiState === 'DEAD') continue;
    if (mob.x < minTileX || mob.x > maxTileX || mob.y < minTileY || mob.y > maxTileY) continue;
    drawList.push({
      sortY: mob.y,
      draw: () => drawMonsterOrElder(ctx, atlas, state, mob, camX, camY, opts.nowMs),
    });
  }

  // 6e. Player Adventurer
  drawList.push({
    sortY: player.y,
    draw: () => drawPlayerAdventurer(ctx, atlas, state, camX, camY, opts.nowMs),
  });

  drawList.sort((a, b) => a.sortY - b.sortY);
  for (const item of drawList) item.draw();

  // 7. Projectiles
  for (const p of state.world.projectiles) {
    const px = Math.round(p.x * 16 - camX);
    const py = Math.round(p.y * 16 - camY);
    if (px < -16 || px > LOGICAL_WIDTH + 16 || py < -16 || py > LOGICAL_HEIGHT + 16) continue;
    ctx.fillStyle = '#14181e';
    ctx.fillRect(px - 3, py - 3, 6, 6);
    ctx.fillStyle =
      p.kind === 'volt_bolt' ? '#4cc9f0' : p.kind === 'acid_spit' ? '#80ed99' : '#ffd166';
    ctx.fillRect(px - 2, py - 2, 4, 4);
  }

  // 8. Roof Layer with Smooth Interior Occlusion (fades cleanly when Adventurer is under a roof!)
  const playerUnderRoof = roofsToDraw.some(
    (r) => Math.abs(r.tileX + 0.5 - player.x) <= 2.5 && Math.abs(r.tileY + 0.5 - player.y) <= 2.5 &&
      roofsToDraw.some((r2) => r2.tileX === Math.floor(player.x) && r2.tileY === Math.floor(player.y))
  );
  for (const r of roofsToDraw) {
    const rx = r.tileX * 16 - camX;
    const ry = r.tileY * 16 - camY;
    const distP = Math.hypot(r.tileX + 0.5 - player.x, r.tileY + 0.5 - player.y);
    ctx.globalAlpha = playerUnderRoof && distP < 4.5 ? 0.16 : 0.96;
    if (r.kind === 'thatch_roof') {
      ctx.fillStyle = '#14181e';
      ctx.fillRect(rx, ry, 16, 16);
      ctx.fillStyle = '#ca6702';
      ctx.fillRect(rx + 1, ry + 1, 14, 14);
      ctx.fillStyle = '#ee9b00';
      for (let sy = 2; sy < 14; sy += 4) ctx.fillRect(rx + 2, ry + sy, 12, 2);
    } else {
      ctx.fillStyle = '#14181e';
      ctx.fillRect(rx, ry, 16, 16);
      ctx.fillStyle = '#4a4e69';
      ctx.fillRect(rx + 1, ry + 1, 14, 14);
      ctx.fillStyle = '#8d99ae';
      for (let sy = 2; sy < 14; sy += 4) ctx.fillRect(rx + 2, ry + sy, 12, 1);
    }
  }
  ctx.globalAlpha = 1;

  // 9. True 360-Degree Pixel Combat & Core VFX Layer
  for (const v of state.world.vfx) {
    drawPixelVfx(ctx, atlas, v, camX, camY, opts.nowMs);
  }

  // 10. Atmospheric Weather Particles & Restrained Warm/Cool Day-Night Tint
  drawWeatherAndAtmosphere(ctx, atlas, state, camX, camY, opts.nowMs);

  // 11. Crisp In-World Cursor Reticle & [E] Interaction Tag
  const curScreenX = Math.round(opts.cursorWorldX * 16 - camX);
  const curScreenY = Math.round(opts.cursorWorldY * 16 - camY);
  if (curScreenX >= 0 && curScreenX <= LOGICAL_WIDTH && curScreenY >= 0 && curScreenY <= LOGICAL_HEIGHT) {
    ctx.fillStyle = '#fff3b0';
    ctx.fillRect(curScreenX - 4, curScreenY, 3, 1);
    ctx.fillRect(curScreenX + 2, curScreenY, 3, 1);
    ctx.fillRect(curScreenX, curScreenY - 4, 1, 3);
    ctx.fillRect(curScreenX, curScreenY + 2, 1, 3);
  }

  if (opts.nearestPrompt && !player.dead) {
    const px = Math.round(opts.nearestPrompt.x * 16 - camX);
    const py = Math.round(opts.nearestPrompt.y * 16 - camY) - 16;
    const text = `[E] ${opts.nearestPrompt.label}`;
    ctx.font = 'bold 9px monospace';
    const tw = Math.ceil(ctx.measureText(text).width);
    const bx = Math.max(4, Math.min(LOGICAL_WIDTH - tw - 12, Math.round(px - tw / 2 - 4)));
    const by = Math.max(12, py - 10);
    ctx.fillStyle = 'rgba(15, 20, 28, 0.88)';
    ctx.fillRect(bx, by, tw + 8, 13);
    ctx.strokeStyle = '#ffd166';
    ctx.strokeRect(bx + 0.5, by + 0.5, tw + 7, 12);
    ctx.fillStyle = '#fff3b0';
    ctx.fillText(text, bx + 4, by + 10);
  }

  return { camX, camY };
}

function drawSourceNode(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedArtAtlas,
  state: GameState,
  s: SourceNode,
  sx: number,
  sy: number,
  nowMs: number
): void {
  const vil = atlas.images.tilesetVillage;

  if (s.kind === 'oak_tree') {
    // Multi-canopy lush 64x48 Oak Tree from CC0 tileset_village_abandoned.png
    ctx.drawImage(atlas.images.shadow, sx - 6, sy + 2);
    ctx.drawImage(vil, 0, 96, 64, 48, sx - 32, sy - 40, 64, 48);
  } else if (s.kind === 'pine_tree') {
    // 32x32 Canopy Woodland Tree from CC0 tileset_village_abandoned.png
    ctx.drawImage(atlas.images.shadow, sx - 6, sy + 2);
    ctx.drawImage(vil, 64, 96, 32, 32, sx - 16, sy - 25, 32, 32);
  } else if (s.kind === 'dead_wood') {
    ctx.drawImage(vil, 96, 96, 16, 32, sx - 8, sy - 20, 16, 32);
  } else if (s.kind === 'boulder') {
    ctx.drawImage(vil, 112, 80, 32, 32, sx - 12, sy - 14, 24, 24);
  } else if (s.kind === 'iron_vein' || s.kind === 'coal_seam' || s.kind === 'cobalt_crystal' || s.kind === 'sulfur_vent') {
    ctx.drawImage(vil, 112, 80, 32, 32, sx - 11, sy - 13, 22, 22);
    const oreCol =
      s.kind === 'iron_vein'
        ? '#e07a5f'
        : s.kind === 'coal_seam'
        ? '#212529'
        : s.kind === 'cobalt_crystal'
        ? '#4cc9f0'
        : '#ffd166';
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 5, sy - 6, 4, 4);
    ctx.fillRect(sx + 1, sy - 3, 4, 4);
    ctx.fillStyle = oreCol;
    ctx.fillRect(sx - 4, sy - 5, 2, 2);
    ctx.fillRect(sx + 2, sy - 2, 2, 2);
  } else if (s.kind === 'berry_bush' || s.kind === 'marsh_herb') {
    ctx.drawImage(vil, 64, 80, 16, 16, sx - 8, sy - 9, 16, 16);
    ctx.fillStyle = s.kind === 'berry_bush' ? '#ff4d6d' : '#90e0ef';
    ctx.fillRect(sx - 4, sy - 4, 2, 2);
    ctx.fillRect(sx + 2, sy - 5, 2, 2);
    ctx.fillRect(sx, sy - 1, 2, 2);
  } else if (s.kind === 'peat_bog') {
    ctx.drawImage(atlas.itemCanvases['peat_brick'], sx - 8, sy - 8);
  } else if (s.kind === 'road_crate') {
    ctx.drawImage(atlas.images.crate, sx - 7, sy - 8);
  } else if (s.kind === 'oil_barrel') {
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 6, sy - 10, 12, 15);
    ctx.fillStyle = '#bc4749';
    ctx.fillRect(sx - 5, sy - 9, 10, 13);
    ctx.fillStyle = '#f2e8cf';
    ctx.fillRect(sx - 5, sy - 4, 10, 2);
  } else if (s.kind === 'poi_exterior_cache' || s.kind === 'industrial_locker' || s.kind === 'poi_deep_locker') {
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 7, sy - 9, 14, 14);
    ctx.fillStyle = s.kind === 'poi_deep_locker' ? '#3a86ff' : '#6c757d';
    ctx.fillRect(sx - 6, sy - 8, 12, 12);
    ctx.fillStyle = '#ffd166';
    ctx.fillRect(sx - 2, sy - 3, 4, 2);
  } else if (s.kind === 'final72_cash_vault') {
    const unlocked = isInFinal72Hours(state);
    const pulse = Math.floor(nowMs / 250) % 2 === 0;
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 8, sy - 10, 16, 16);
    ctx.fillStyle = unlocked ? '#ffb703' : '#495057';
    ctx.fillRect(sx - 7, sy - 9, 14, 14);
    ctx.fillStyle = unlocked ? (pulse ? '#ffffff' : '#80ed99') : '#e63946';
    ctx.fillRect(sx - 3, sy - 4, 6, 4);
  }

  // Compact damage bar if partially harvested
  if (s.hp < s.maxHp && s.hp > 0) {
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 7, sy - 14, 14, 3);
    ctx.fillStyle = '#ffd166';
    ctx.fillRect(sx - 6, sy - 13, Math.max(1, Math.round((s.hp / s.maxHp) * 12)), 1);
  }
}

function drawStructureEntity(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedArtAtlas,
  state: GameState,
  ent: StructureEntity,
  camX: number,
  camY: number,
  nowMs: number
): void {
  const sx = Math.round(ent.x * 16 - camX);
  const sy = Math.round(ent.y * 16 - camY);

  if (ent.kind === 'wood_wall') {
    ctx.drawImage(atlas.images.tilesetWall, 0, 0, 16, 16, sx - 8, sy - 8, 16, 16);
  } else if (ent.kind === 'stone_wall') {
    ctx.drawImage(atlas.images.tilesetWall, 0, 5 * 16, 16, 16, sx - 8, sy - 8, 16, 16);
  } else if (ent.kind === 'wood_door' || ent.kind === 'reinforced_door' || ent.kind === 'poi_gate') {
    const col = ent.kind === 'poi_gate' ? '#3a86ff' : ent.kind === 'reinforced_door' ? '#adb5bd' : '#9c6644';
    ctx.fillStyle = '#14181e';
    if (ent.open) {
      // Open door swung flush against left jamb
      ctx.fillRect(sx - 8, sy - 8, 4, 16);
      ctx.fillStyle = col;
      ctx.fillRect(sx - 7, sy - 7, 2, 14);
    } else {
      ctx.fillRect(sx - 8, sy - 5, 16, 10);
      ctx.fillStyle = col;
      ctx.fillRect(sx - 7, sy - 4, 14, 8);
      ctx.fillStyle = ent.kind === 'poi_gate' && !ent.powered ? '#e63946' : '#ffd166';
      ctx.fillRect(sx - 1, sy - 1, 2, 2);
    }
  } else {
    const spr = atlas.structures[ent.kind];
    if (spr) {
      ctx.drawImage(spr, sx - 8, sy - 8);
    }

    // Animated flame flicker when furnace or campfire has active fuel!
    if ((ent.kind === 'campfire' || ent.kind === 'stone_furnace') && (ent.fuelRemainingSec ?? 0) > 0) {
      const f = Math.floor(nowMs / 120) % 2;
      ctx.fillStyle = f === 0 ? '#ffd166' : '#ff595e';
      ctx.fillRect(sx - 2, sy - 3 - f, 4, 3);
    }

    // Active workstation job progress bar above station
    const activeJob = Object.values(state.jobs).find(
      (j) => j.stationEntityId === ent.id && j.status !== 'COMPLETED'
    );
    if (activeJob) {
      ctx.fillStyle = '#14181e';
      ctx.fillRect(sx - 8, sy - 13, 16, 3);
      ctx.fillStyle = activeJob.status === 'RUNNING' ? '#52b788' : '#e63946';
      const pct = Math.min(1, activeJob.progressSec / Math.max(1, activeJob.durationSec));
      ctx.fillRect(sx - 7, sy - 12, Math.max(1, Math.round(pct * 14)), 1);
    }

    // Pulsing beacon ring on Death Bag, Escrow Chest, Vendors & Evac Beacons
    if (ent.kind === 'death_bag' || ent.kind === 'escrow_chest' || ent.kind === 'evac_beacon') {
      const p = Math.floor(nowMs / 300) % 2;
      ctx.fillStyle =
        ent.kind === 'death_bag' ? '#ff5964' : ent.kind === 'escrow_chest' ? '#ffd166' : '#4cc9f0';
      ctx.fillRect(sx - 1, sy - 12 - p, 2, 2);
    }
  }

  // Damage bar for damaged player structures
  if (ent.owner === 'player' && ent.hp < ent.maxHp) {
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 7, sy + 7, 14, 3);
    ctx.fillStyle = '#74c69d';
    ctx.fillRect(sx - 6, sy + 8, Math.max(1, Math.round((ent.hp / ent.maxHp) * 12)), 1);
  }
}

function angleToSpriteCol(rad: number): number {
  // NinjaAdventure 4-col order: DOWN=0 (pi/2), UP=1 (-pi/2), LEFT=2 (pi), RIGHT=3 (0)
  const deg = ((rad * 180) / Math.PI + 360) % 360;
  if (deg >= 45 && deg < 135) return 0; // Down
  if (deg >= 135 && deg < 225) return 2; // Left
  if (deg >= 225 && deg < 315) return 1; // Up
  return 3; // Right
}

function drawMonsterOrElder(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedArtAtlas,
  state: GameState,
  mob: GameState['actors']['monsters'][string],
  camX: number,
  camY: number,
  nowMs: number
): void {
  const sx = Math.round(mob.x * 16 - camX);
  const sy = Math.round(mob.y * 16 - camY);
  const frameIdx = Math.floor(nowMs / 180) % 2;
  const isFlashing = state.clock.elapsedSimSec < mob.hitFlashUntilSec;

  if (mob.isElder) {
    const elderPack = atlas.elders[mob.archetype];
    const frames = mob.elderForm === 'awakened' ? elderPack?.awakened : elderPack?.latent;
    const spr = frames ? frames[frameIdx % frames.length] : null;
    ctx.drawImage(atlas.images.shadow, sx - 10, sy + 7, 20, 10);
    if (spr) {
      ctx.drawImage(spr, sx - 16, sy - 20);
      if (isFlashing) {
        ctx.globalCompositeOperation = 'source-atop';
        ctx.fillStyle = 'rgba(255,255,255,0.6)';
        ctx.fillRect(sx - 16, sy - 20, 32, 32);
        ctx.globalCompositeOperation = 'source-over';
      }
    }
    // Crisp Elder health & form nameplate
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 18, sy - 27, 36, 4);
    ctx.fillStyle = mob.elderForm === 'awakened' ? '#ff006e' : '#f77f00';
    ctx.fillRect(sx - 17, sy - 26, Math.max(1, Math.round((mob.hp / mob.maxHp) * 34)), 2);
    return;
  }

  ctx.drawImage(atlas.images.shadow, sx - 6, sy + 3);
  if (mob.archetype === 'wild_boar') {
    const f = frameIdx;
    ctx.save();
    ctx.translate(sx, sy);
    if (Math.cos(mob.facingRad) < 0) ctx.scale(-1, 1);
    ctx.drawImage(atlas.images.pig, f * 16, 0, 16, 16, -8, -10, 16, 16);
    ctx.restore();
  } else if (mob.archetype === 'marsh_kappa' || mob.archetype === 'ruin_sentinel') {
    const sheet = mob.archetype === 'marsh_kappa' ? atlas.images.samuraiGreen : atlas.images.ninjaBlue;
    const col = angleToSpriteCol(mob.facingRad);
    const row = mob.aiState === 'TELEGRAPH' ? 4 : Math.floor(nowMs / 150) % 4;
    ctx.drawImage(sheet, col * 16, row * 16, 16, 16, sx - 8, sy - 11, 16, 16);
  } else {
    const customFrames = atlas.customCreatures[mob.archetype];
    if (customFrames) {
      ctx.drawImage(customFrames[frameIdx % customFrames.length], sx - 8, sy - 10);
    }
  }

  // Tracking indicator ("!") when following player footprints or chasing
  if (mob.aiState === 'TRACK_TRACE') {
    ctx.fillStyle = '#ffd166';
    ctx.fillRect(sx - 1, sy - 17, 2, 3);
    ctx.fillRect(sx - 1, sy - 13, 2, 1);
  }

  if (mob.hp < mob.maxHp) {
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 7, sy - 15, 14, 3);
    ctx.fillStyle = '#e63946';
    ctx.fillRect(sx - 6, sy - 14, Math.max(1, Math.round((mob.hp / mob.maxHp) * 12)), 1);
  }
}

function drawPlayerAdventurer(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedArtAtlas,
  state: GameState,
  camX: number,
  camY: number,
  nowMs: number
): void {
  const player = state.actors.player;
  const sx = Math.round(player.x * 16 - camX);
  const sy = Math.round(player.y * 16 - camY);

  // Hitched cart tow rope
  if (player.hitchedCartEntityId && state.entities[player.hitchedCartEntityId]) {
    const cart = state.entities[player.hitchedCartEntityId];
    const cx = Math.round(cart.x * 16 - camX);
    const cy = Math.round(cart.y * 16 - camY);
    ctx.strokeStyle = '#ddb892';
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(cx, cy);
    ctx.stroke();
  }

  ctx.drawImage(atlas.images.shadow, sx - 6, sy + 3);
  const sheet = player.gender === 'female' ? atlas.femaleAdventurerSheet : atlas.images.samuraiBlue;

  if (player.dead) {
    ctx.drawImage(sheet, 0, 6 * 16, 16, 16, sx - 8, sy - 9, 16, 16);
    return;
  }

  const col = angleToSpriteCol(player.facingRad);
  const isMoving =
    Math.hypot(player.x - player.lastFootprintPos.x, player.y - player.lastFootprintPos.y) > 0.08 &&
    Math.floor(nowMs / 100) % 2 >= 0;
  let row = 0;
  if (player.activeWindup) {
    row = player.activeWindup.kind === 'core' ? 6 : 4;
  } else if (isMoving && Math.hypot(player.vx, player.vy) < 0.5) {
    // Animate stride based on world position so standing still is crisp idle row 0!
    const phase = Math.floor((player.x * 3.5 + player.y * 3.5)) % 4;
    row = ((phase % 4) + 4) % 4;
  }

  if (nowMs < player.invulnUntilMs && Math.floor(nowMs / 55) % 2 === 0) {
    ctx.globalAlpha = 0.55;
  }
  ctx.drawImage(sheet, col * 16, row * 16, 16, 16, sx - 8, sy - 11, 16, 16);
  ctx.globalAlpha = 1;

  // True 360-degree cursor-aimed held weapon/Core indicator & windup telegraph
  const activeItem = getActiveQuickbarItem(state);
  if (activeItem) {
    const def = ITEMS_CATALOG[activeItem.defId];
    const hx = Math.round(sx + Math.cos(player.facingRad) * 7);
    const hy = Math.round(sy - 3 + Math.sin(player.facingRad) * 7);
    if (def?.category === 'core') {
      ctx.fillStyle = '#14181e';
      ctx.fillRect(hx - 2, hy - 2, 5, 5);
      ctx.fillStyle =
        def.coreSkill === 'ember_arc'
          ? '#ff595e'
          : def.coreSkill === 'frost_nova'
          ? '#4cc9f0'
          : def.coreSkill === 'volt_lance'
          ? '#ffd166'
          : '#80ed99';
      ctx.fillRect(hx - 1, hy - 1, 3, 3);
    } else if (def?.category === 'tool_weapon') {
      ctx.fillStyle = '#14181e';
      ctx.fillRect(hx - 2, hy - 2, 4, 4);
      ctx.fillStyle = '#edf2f4';
      ctx.fillRect(hx - 1, hy - 1, 2, 2);
    }
  }

  // Windup / Evacuation Channel progress bar right over player
  if (player.activeWindup && !player.activeWindup.committed) {
    const total = Math.max(1, player.activeWindup.commitAtMs - player.activeWindup.startedAtMs);
    const pct = Math.max(0, Math.min(1, (nowMs - player.activeWindup.startedAtMs) / total));
    ctx.fillStyle = '#14181e';
    ctx.fillRect(sx - 9, sy - 17, 18, 4);
    ctx.fillStyle = player.activeWindup.kind === 'evac_channel' ? '#4cc9f0' : '#ffd166';
    ctx.fillRect(sx - 8, sy - 16, Math.round(pct * 16), 2);
  }
}

function drawCrispTelegraph(
  ctx: CanvasRenderingContext2D,
  tel: NpcTelegraph,
  nowSec: number,
  camX: number,
  camY: number
): void {
  const ox = Math.round(tel.originX * 16 - camX);
  const oy = Math.round(tel.originY * 16 - camY);
  const pct = Math.max(0.15, Math.min(1, (nowSec - tel.startedAtSec) / Math.max(0.1, tel.commitAtSec - tel.startedAtSec)));
  const rPx = Math.round(tel.radiusTiles * 16);

  ctx.save();
  ctx.strokeStyle = tel.kind === 'frost_cross' ? '#4cc9f0' : '#ff4d6d';
  ctx.lineWidth = 1;

  if (tel.kind === 'charge_line' || tel.kind === 'spit_lob') {
    const ex = Math.round(ox + Math.cos(tel.angleRad) * rPx);
    const ey = Math.round(oy + Math.sin(tel.angleRad) * rPx);
    ctx.setLineDash([3, 2]);
    ctx.beginPath();
    ctx.moveTo(ox, oy);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#ff4d6d';
    ctx.fillRect(ex - 2, ey - 2, 5, 5);
  } else if (tel.kind === 'frost_cross') {
    ctx.strokeRect(ox - rPx, oy - 6, rPx * 2, 12);
    ctx.strokeRect(ox - 6, oy - rPx, 12, rPx * 2);
  } else if (tel.kind === 'aoe_ring') {
    // Stepped pixel octagon telegraph instead of blurry translucent circle!
    const curR = Math.round(rPx * pct);
    drawPixelOctagon(ctx, ox, oy, rPx, 'rgba(255, 77, 109, 0.75)');
    drawPixelOctagon(ctx, ox, oy, curR, '#ffd166');
  } else {
    // Cone slash / Flame cone / Lightning arc stepped rays
    for (const offset of [-0.55, 0, 0.55]) {
      const a = tel.angleRad + offset;
      ctx.beginPath();
      ctx.moveTo(ox, oy);
      ctx.lineTo(Math.round(ox + Math.cos(a) * rPx * pct), Math.round(oy + Math.sin(a) * rPx * pct));
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawPixelOctagon(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, color: string): void {
  const k = Math.round(r * 0.7);
  ctx.strokeStyle = color;
  ctx.beginPath();
  ctx.moveTo(cx - k, cy - r);
  ctx.lineTo(cx + k, cy - r);
  ctx.lineTo(cx + r, cy - k);
  ctx.lineTo(cx + r, cy + k);
  ctx.lineTo(cx + k, cy + r);
  ctx.lineTo(cx - k, cy + r);
  ctx.lineTo(cx - r, cy + k);
  ctx.lineTo(cx - r, cy - k);
  ctx.closePath();
  ctx.stroke();
}

function drawPixelVfx(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedArtAtlas,
  v: GameState['world']['vfx'][number],
  camX: number,
  camY: number,
  nowMs: number
): void {
  const age = nowMs - v.createdAtMs;
  if (age < 0 || age >= v.durationMs) return;
  const pct = age / v.durationMs;
  const vx = Math.round(v.x * 16 - camX);
  const vy = Math.round(v.y * 16 - camY);

  if (v.kind === 'floating_text' && v.text) {
    const lift = Math.round(pct * 14);
    ctx.font = 'bold 9px monospace';
    ctx.fillStyle = '#14181e';
    ctx.fillText(v.text, vx - 8 + 1, vy - lift + 1);
    ctx.fillStyle = v.color ?? '#ffffff';
    ctx.fillText(v.text, vx - 8, vy - lift);
    return;
  }

  if (v.kind === 'slash_arc' || v.kind === 'ember_arc') {
    const r = Math.round((v.radius ?? 1.8) * 16);
    const baseA = v.angleRad ?? 0;
    const isEmber = v.kind === 'ember_arc';
    const steps = isEmber ? 11 : 7;
    for (let i = 0; i < steps; i++) {
      const t = i / (steps - 1) - 0.5;
      const a = baseA + t * (isEmber ? 1.7 : 1.3);
      const px = Math.round(vx + Math.cos(a) * r * (0.7 + pct * 0.3));
      const py = Math.round(vy + Math.sin(a) * r * (0.7 + pct * 0.3));
      ctx.fillStyle = isEmber ? (i % 2 === 0 ? '#ff595e' : '#ffd166') : '#ffffff';
      ctx.fillRect(px - 2, py - 2, isEmber ? 4 : 3, isEmber ? 4 : 3);
    }
    return;
  }

  if (v.kind === 'harvest_chips' || v.kind === 'hit_spark') {
    const partImg = v.kind === 'harvest_chips' ? atlas.images.particleWood : atlas.images.particleRock;
    const frame = Math.min(3, Math.floor(pct * 4));
    ctx.drawImage(partImg, frame * 16, 0, 16, 16, vx - 8, vy - 8, 16, 16);
    return;
  }

  if (v.kind === 'frost_nova' || v.kind === 'aegis_pulse' || v.kind === 'explosion_ring' || v.kind === 'deposit_gleam') {
    const r = Math.round((v.radius ?? 2.5) * 16 * (0.35 + pct * 0.65));
    const col =
      v.kind === 'frost_nova'
        ? '#4cc9f0'
        : v.kind === 'deposit_gleam'
        ? '#ffd166'
        : v.kind === 'aegis_pulse'
        ? '#caf0f8'
        : '#ff595e';
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4 + pct * 0.5;
      const px = Math.round(vx + Math.cos(a) * r);
      const py = Math.round(vy + Math.sin(a) * r);
      ctx.fillStyle = '#14181e';
      ctx.fillRect(px - 2, py - 2, 5, 5);
      ctx.fillStyle = col;
      ctx.fillRect(px - 1, py - 1, 3, 3);
    }
    return;
  }

  if (v.kind === 'thorn_snare') {
    for (let i = -2; i <= 2; i++) {
      ctx.fillStyle = '#1b4332';
      ctx.fillRect(vx + i * 6 - 1, vy - 6, 3, 10);
      ctx.fillStyle = '#80ed99';
      ctx.fillRect(vx + i * 6, vy - 8, 1, 4);
    }
    return;
  }

  if (v.kind === 'volt_lance' || v.kind === 'gale_dash') {
    const a = v.angleRad ?? 0;
    const col = v.kind === 'volt_lance' ? '#4cc9f0' : '#b7e4c7';
    for (let d = 4; d <= 36; d += 5) {
      const px = Math.round(vx + Math.cos(a) * d);
      const py = Math.round(vy + Math.sin(a) * d);
      ctx.fillStyle = col;
      ctx.fillRect(px - 1, py - 1, 3, 3);
    }
  }
}

function drawWeatherAndAtmosphere(
  ctx: CanvasRenderingContext2D,
  atlas: LoadedArtAtlas,
  state: GameState,
  camX: number,
  camY: number,
  nowMs: number
): void {
  const w = state.clock.weather;

  if (w === 'RAIN' || w === 'STORM') {
    const count = w === 'STORM' ? 65 : 36;
    ctx.fillStyle = w === 'STORM' ? '#caf0f8' : '#90e0ef';
    for (let i = 0; i < count; i++) {
      const rx = ((i * 97 + Math.floor(nowMs * 0.22)) % LOGICAL_WIDTH + LOGICAL_WIDTH) % LOGICAL_WIDTH;
      const ry = ((i * 53 + Math.floor(nowMs * 0.45)) % LOGICAL_HEIGHT + LOGICAL_HEIGHT) % LOGICAL_HEIGHT;
      ctx.fillRect(rx, ry, 1, 5);
      ctx.fillRect(rx - 1, ry + 5, 1, 3);
    }
    // Puddle splash frames from CC0 rain_on_floor.png
    const splashFrame = Math.floor(nowMs / 140) % 3;
    for (let i = 0; i < 8; i++) {
      const sx = ((i * 131 - camX) % LOGICAL_WIDTH + LOGICAL_WIDTH) % LOGICAL_WIDTH;
      const sy = ((i * 89 - camY) % LOGICAL_HEIGHT + LOGICAL_HEIGHT) % LOGICAL_HEIGHT;
      ctx.drawImage(atlas.images.rainFloor, splashFrame * 8, 0, 8, 8, sx, sy, 8, 8);
    }
  } else if (w === 'COLD_SNAP') {
    const flakeFrame = Math.floor(nowMs / 250) % 7;
    for (let i = 0; i < 28; i++) {
      const sx = ((i * 83 + Math.floor(nowMs * 0.04)) % LOGICAL_WIDTH + LOGICAL_WIDTH) % LOGICAL_WIDTH;
      const sy = ((i * 67 + Math.floor(nowMs * 0.09)) % LOGICAL_HEIGHT + LOGICAL_HEIGHT) % LOGICAL_HEIGHT;
      ctx.drawImage(atlas.images.snowFx, flakeFrame * 8, 0, 8, 8, sx, sy, 8, 8);
    }
  } else if (w === 'ASH_WIND') {
    for (let i = 0; i < 30; i++) {
      const sx = ((i * 79 + Math.floor(nowMs * 0.16)) % LOGICAL_WIDTH + LOGICAL_WIDTH) % LOGICAL_WIDTH;
      const sy = ((i * 61 + Math.floor(nowMs * 0.05)) % LOGICAL_HEIGHT + LOGICAL_HEIGHT) % LOGICAL_HEIGHT;
      ctx.fillStyle = i % 3 === 0 ? '#ff7b00' : '#adb5bd';
      ctx.fillRect(sx, sy, 2, 2);
    }
  }

  // Restrained Day/Night & Ragnarok Ambient Grading (NEVER blacks out the screen!)
  const dayLen = balance.clock.fictionalDayLengthSeconds;
  const dayProgress = state.clock.fictionalDaySec / dayLen;
  const isNight = dayProgress > balance.clock.daylightRatio;

  if (state.clock.phase === 'RAGNAROK_72H' || state.clock.phase === 'ELDER_AWAKENED_D14') {
    ctx.fillStyle = 'rgba(130, 28, 42, 0.13)';
    ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);
  }

  if (isNight) {
    ctx.fillStyle = 'rgba(16, 26, 52, 0.24)';
    ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);

    // Warm pixel light pools around fueled campfires & furnaces at night
    for (const ent of Object.values(state.entities)) {
      if (
        ent.hp > 0 &&
        (ent.kind === 'campfire' || ent.kind === 'stone_furnace') &&
        (ent.fuelRemainingSec ?? 0) > 0
      ) {
        const lx = Math.round(ent.x * 16 - camX);
        const ly = Math.round(ent.y * 16 - camY);
        ctx.fillStyle = 'rgba(255, 190, 92, 0.14)';
        ctx.fillRect(lx - 40, ly - 40, 80, 80);
        ctx.fillStyle = 'rgba(255, 214, 112, 0.16)';
        ctx.fillRect(lx - 22, ly - 22, 44, 44);
      }
    }
  }
}
