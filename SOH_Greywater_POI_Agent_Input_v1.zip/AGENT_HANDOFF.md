# SOH AGENT HANDOFF — GREYWATER POI DETAIL PILOT

**Inputs are pinned at the Git commit supplied by the owner, not at a conversation attachment URL.**

## Phase 0 (mandatory custody)
- Fetch the source-only input branch and recover `SOH_Greywater_POI_Agent_Input_v1.zip` from the **specified Git SHA**.
- Extract, run `sha256sum -c INPUT_SHA256.txt`, inspect file tree; list actual paths read from source.
- Report the resolved SHA, package checksum, and paths. Do not silently work on a guessed/old input.

## Objective
Extend Map Studio v3, preserving its editor and geography, with a **real Greywater POI Detail Layer and editor** using the original prototype's actual `art.ts`, `render.ts`, and `world.ts` visual and placement logic as the reference.

This is an art-first, production-independent POI pilot. Existing Bridge is an experiment only; do not declare it accepted just because it renders.

## Required development
1. The existing `.sohmap.json` format remains backward compatible. Add a versioned, keyed-by-POI-ID detail record for local buildings/footprints, doors, roofs, pathways, vegetation, props, interactions, seed and hand edits.
2. `foot` is a site boundary, not finished interior layout. Honor roads, rivers, collision and geographic anchors.
3. Preserve exact prototype pixel grammar where feasible, with documented source mappings and scaling constraints. Explicitly distinguish direct source reuse from newly authored adaptation.
4. Clicking Greywater must open an editable detailed scene, **not just zoom the camera**.
5. Support deterministic regenerate, manual edits, freeze/lock, undo/redo, save/reopen, export, and at least one playable walk-and-interact test.
6. One site only: Greywater. No automatic mass conversion of 81 POIs, no new Veyra procedural decorations, no production merge.

## Acceptance
- Concrete changed Map Studio source committed on agent branch.
- Authentic 1x screenshots and exact-camera before/after (not AI illustration).
- Demonstrated edit -> save -> reload fidelity, one traversal, one building entrance with proper occlusion, one interaction, and negative regression tests of geography.
- Separate PASS/FAIL/NOT TESTED for visual, editor, runtime, topology and Godot integration.
- Source SHA, input custody, actual test commands and output artifact links.
- Human owner alone accepts final visual quality. If it looks inferior to prototype, hold and explain why.

**Stop** on producing an inspectable Greywater pilot and handoff; no automatic new rounds.
