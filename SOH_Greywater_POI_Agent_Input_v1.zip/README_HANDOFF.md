# SOH — GREYWATER POI DETAIL PILOT — INPUT HANDOFF

This archive is a SOURCE INPUT PACKAGE, not a completed implementation, not a production build.

## Files

- `01_original_prototype.zip`: original Soul of Hero prototype (`src/game/art.ts`, `src/game/render.ts`, `src/game/world.ts`), treated as the reference for artistic grammar and object composition.
- `02_map_studio_v3.zip`: the existing Map Studio source. Edit this app, do not replace it with a viewer.
- `03_existing_style_bridge_kit.zip`: earlier style bridge experiment and supporting seed/evidence. Reference only; NOT accepted as production visual or POI editor.
- `04_map_studio_default_seed.sohmap.json`: a *default* Map Studio seed, NOT a user-customized save.
- `INPUT_SHA256.txt`: exact checksums for the four inputs.
- `AGENT_HANDOFF.md`: action and verification contract.

## Workflow — user

1. Go to the Soul-of-Hero GitHub repository. Create a NEW source-only branch `input/greywater-poi-pilot-20261102` from a stable commit. Do not merge it into production.
2. In that branch use **Add file > Upload files**, upload this single `SOH_Greywater_POI_Agent_Input_v1.zip` archive and commit it to the branch root.
3. Copy the resulting Git commit SHA. Send agent: repository `Khanh-glitch/Soul-of-Hero`, branch `input/greywater-poi-pilot-20261102`, file `SOH_Greywater_POI_Agent_Input_v1.zip`, and exact commit SHA.
4. Agent must confirm SHA-256 of extracted inputs against `INPUT_SHA256.txt`, then work on its own branch. It may fetch the input branch but must not merge it.
5. Agent returns exact output commit, real screenshot/video evidence, test outcomes, playable pilot and blockers to Control Tower for human visual review.

## Workflow — agent shell, if the current repo is already cloned and `git fetch` access works

```bash
git fetch origin input/greywater-poi-pilot-20261102
# Use the PINNED commit SHA if available (not the moving branch HEAD):
git show <INPUT_COMMIT_SHA>:SOH_Greywater_POI_Agent_Input_v1.zip > /tmp/greywater-input.zip
mkdir -p /tmp/greywater-input
python3 -m zipfile -e /tmp/greywater-input.zip /tmp/greywater-input
cd /tmp/greywater-input
sha256sum -c INPUT_SHA256.txt
```

If `git show` or fetch fails, STOP and report exact blocker. Do not pretend attached sandbox links or filenames are accessible.

## Scope and safeguards

Do not change canonical geography, GOLD, A0/A3 gameplay authority or production state.
Do not extrapolate visual acceptance from CI. Do not produce yet another standalone bridge instead of editing Map Studio.
No claim of user-artwork rights beyond the license contained in each input.
