var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/engine/math.ts
function hash2(x, y) {
  let h = x * 374761393 + y * 668265263;
  h = (h ^ h >> 13) * 1274126177;
  return ((h ^ h >> 16) >>> 0) / 4294967296;
}
function hash3(x, y, z) {
  let h = x * 374761393 + y * 668265263 + z * 2147483647;
  h = (h ^ h >> 13) * 1274126177;
  return ((h ^ h >> 16) >>> 0) / 4294967296;
}
function vnoise(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf);
  const v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi), b = hash2(xi + 1, yi), c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
function vnoise3(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
  const n = (i, j, k) => hash3(xi + i, yi + j, zi + k);
  const x00 = lerp(n(0, 0, 0), n(1, 0, 0), u);
  const x10 = lerp(n(0, 1, 0), n(1, 1, 0), u);
  const x01 = lerp(n(0, 0, 1), n(1, 0, 1), u);
  const x11 = lerp(n(0, 1, 1), n(1, 1, 1), u);
  return lerp(lerp(x00, x10, v), lerp(x01, x11, v), w);
}
function fbm(x, y, oct = 4, lac = 2, gain = 0.5) {
  let a = 0.5, s = 0, n = 0;
  for (let i = 0; i < oct; i++) {
    s += a * vnoise(x, y);
    n += a;
    x *= lac;
    y *= lac;
    a *= gain;
  }
  return s / n;
}
function curl(x, y, t, e = 0.6) {
  const n1 = vnoise3(x + e, y, t) - vnoise3(x - e, y, t);
  const n2 = vnoise3(x, y + e, t) - vnoise3(x, y - e, t);
  return [n2 / (2 * e), -n1 / (2 * e)];
}
function ramp(stops, t) {
  t = clamp(t);
  for (let i = 0; i < stops.length - 1; i++) {
    const a = stops[i], b = stops[i + 1];
    if (t >= a[0] && t <= b[0]) {
      const k = (t - a[0]) / (b[0] - a[0] || 1e-6);
      return [lerp(a[1], b[1], k), lerp(a[2], b[2], k), lerp(a[3], b[3], k)];
    }
  }
  const l = stops[stops.length - 1];
  return [l[1], l[2], l[3]];
}
function catmull(pts, u) {
  const n = pts.length;
  if (n === 0) return { x: 0, y: 0 };
  if (n === 1) return pts[0];
  const f = clamp(u) * (n - 1);
  const i = Math.min(Math.floor(f), n - 2);
  const t = f - i;
  const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(n - 1, i + 2)];
  const t2 = t * t, t3 = t2 * t;
  return {
    x: 0.5 * (2 * p1.x + (-p0.x + p2.x) * t + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3),
    y: 0.5 * (2 * p1.y + (-p0.y + p2.y) * t + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3)
  };
}
var TAU, clamp, lerp, smoothstep, seg, easeOut, easeIn, easeInOut, backOut, RNG, RAMPS, R;
var init_math = __esm({
  "src/engine/math.ts"() {
    "use strict";
    TAU = Math.PI * 2;
    clamp = (v, a = 0, b = 1) => v < a ? a : v > b ? b : v;
    lerp = (a, b, t) => a + (b - a) * t;
    smoothstep = (e0, e1, x) => {
      const t = clamp((x - e0) / (e1 - e0 || 1e-6));
      return t * t * (3 - 2 * t);
    };
    seg = (t, a, b) => clamp((t - a) / (b - a || 1e-6));
    easeOut = (t, p = 3) => 1 - Math.pow(1 - clamp(t), p);
    easeIn = (t, p = 3) => Math.pow(clamp(t), p);
    easeInOut = (t) => {
      const x = clamp(t);
      return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
    };
    backOut = (t, s = 1.7) => {
      const x = clamp(t) - 1;
      return x * x * ((s + 1) * x + s) + 1;
    };
    RNG = class {
      s;
      constructor(seed = 1) {
        this.s = seed >>> 0 || 1;
      }
      next() {
        let x = this.s;
        x ^= x << 13;
        x ^= x >>> 17;
        x ^= x << 5;
        this.s = x >>> 0;
        return this.s / 4294967296;
      }
      range(a, b) {
        return a + (b - a) * this.next();
      }
      int(a, b) {
        return Math.floor(this.range(a, b + 1));
      }
      sign() {
        return this.next() < 0.5 ? -1 : 1;
      }
      pick(arr) {
        return arr[Math.floor(this.next() * arr.length) % arr.length];
      }
      angle() {
        return this.next() * TAU;
      }
      gauss(sd = 1) {
        let u = 0, v = 0;
        while (u === 0) u = this.next();
        while (v === 0) v = this.next();
        return Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * v) * sd;
      }
    };
    RAMPS = {
      // fire: black -> deep crimson -> orange -> gold -> white hot
      fire: [
        [0, 0.05, 0.01, 0.02],
        [0.18, 0.42, 0.04, 0.08],
        [0.38, 0.95, 0.17, 0.06],
        [0.6, 1.5, 0.6, 0.1],
        [0.82, 2.2, 1.5, 0.5],
        [1, 3, 2.8, 2.2]
      ],
      ash: [
        [0, 0.03, 0.02, 0.03],
        [0.5, 0.18, 0.12, 0.14],
        [1, 0.42, 0.3, 0.3]
      ],
      water: [
        [0, 0.01, 0.04, 0.1],
        [0.25, 0.03, 0.18, 0.42],
        [0.5, 0.08, 0.45, 0.8],
        [0.75, 0.4, 0.86, 1.1],
        [1, 1.6, 2, 2.2]
      ],
      frost: [
        [0, 0.03, 0.08, 0.16],
        [0.3, 0.12, 0.3, 0.55],
        [0.6, 0.45, 0.75, 1],
        [0.85, 0.9, 1.3, 1.6],
        [1, 2.2, 2.6, 3]
      ],
      volt: [
        [0, 0.03, 0.03, 0.12],
        [0.22, 0.18, 0.1, 0.55],
        [0.45, 0.35, 0.5, 1.4],
        [0.7, 0.8, 1.2, 2.2],
        [1, 2.6, 2.9, 3.2]
      ],
      verdant: [
        [0, 0.03, 0.06, 0.04],
        [0.22, 0.08, 0.22, 0.1],
        [0.45, 0.16, 0.5, 0.2],
        [0.68, 0.5, 1, 0.35],
        [0.86, 1.1, 1.7, 0.7],
        [1, 2.2, 2.6, 1.8]
      ],
      bio: [
        [0, 0.04, 0.08, 0.1],
        [0.3, 0.06, 0.4, 0.38],
        [0.55, 0.2, 0.9, 0.7],
        [0.8, 0.9, 1.6, 1],
        [1, 2, 2.4, 1.8]
      ],
      astral: [
        [0, 0.03, 0.02, 0.07],
        [0.25, 0.22, 0.08, 0.35],
        [0.5, 0.55, 0.25, 0.85],
        [0.72, 0.9, 0.7, 1.5],
        [0.9, 1.6, 1.5, 2.4],
        [1, 3, 2.9, 3]
      ],
      gold: [
        [0, 0.08, 0.04, 0.01],
        [0.4, 0.6, 0.28, 0.05],
        [0.7, 1.3, 0.9, 0.25],
        [1, 2.6, 2.3, 1.4]
      ],
      bloom: [
        [0, 0.1, 0.02, 0.08],
        [0.35, 0.5, 0.1, 0.3],
        [0.65, 1.1, 0.4, 0.6],
        [0.85, 1.8, 1, 1.1],
        [1, 2.6, 2.2, 2.2]
      ]
    };
    R = (name, t) => ramp(RAMPS[name], t);
  }
});

// src/engine/framebuffer.ts
function tm(x) {
  if (x <= 0) return 0;
  const a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
  const v = x * (a * x + b) / (x * (c * x + d) + e);
  return v > 1 ? 1 : Math.pow(v, 1 / 1.42);
}
var BAYER8, Framebuffer, W_K;
var init_framebuffer = __esm({
  "src/engine/framebuffer.ts"() {
    "use strict";
    init_math();
    BAYER8 = [
      [0, 32, 8, 40, 2, 34, 10, 42],
      [48, 16, 56, 24, 50, 18, 58, 26],
      [12, 44, 4, 36, 14, 46, 6, 38],
      [60, 28, 52, 20, 62, 30, 54, 22],
      [3, 35, 11, 43, 1, 33, 9, 41],
      [51, 19, 59, 27, 49, 17, 57, 25],
      [15, 47, 7, 39, 13, 45, 5, 37],
      [63, 31, 55, 23, 61, 29, 53, 21]
    ];
    Framebuffer = class {
      W;
      H;
      buf;
      // HDR linear
      bg;
      // static arena layer
      base;
      // world-before-spell (to isolate spell light)
      trail;
      // persistence of spell light
      post;
      tmpA;
      bw;
      bh;
      bloomA;
      bloomB;
      out;
      exposure = 1;
      flash = [0, 0, 0];
      bloomAmt = 0.75;
      levels = 26;
      warp = null;
      shear = 0;
      // post params (set by the Lab from the World each frame)
      cam = { x: 0, y: 0, zoom: 1, rot: 0 };
      waves = [];
      chroma = 0;
      impactFrames = 0;
      impactTint = [1, 1, 1];
      constructor(W3, H2) {
        this.W = W3;
        this.H = H2;
        const n = W3 * H2 * 3;
        this.buf = new Float32Array(n);
        this.bg = new Float32Array(n);
        this.base = new Float32Array(n);
        this.trail = new Float32Array(n);
        this.post = new Float32Array(n);
        this.tmpA = new Float32Array(n);
        this.bw = W3 >> 2;
        this.bh = H2 >> 2;
        this.bloomA = new Float32Array(this.bw * this.bh * 3);
        this.bloomB = new Float32Array(this.bw * this.bh * 3);
        this.out = new ImageData(W3, H2);
      }
      clear() {
        this.buf.fill(0);
        this.exposure = 1;
        this.flash[0] = this.flash[1] = this.flash[2] = 0;
        this.bloomAmt = 0.75;
        this.warp = null;
        this.shear = 0;
      }
      idx(x, y) {
        return (y * this.W + x) * 3;
      }
      /** sub-pixel additive splat (bilinear). Integer coords hit one pixel exactly. */
      add(x, y, r, g, b, a = 1) {
        const x0 = Math.floor(x), y0 = Math.floor(y);
        const fx = x - x0, fy = y - y0;
        const W3 = this.W, H2 = this.H, buf = this.buf;
        if (fx < 0.02 && fy < 0.02) {
          if (x0 < 0 || y0 < 0 || x0 >= W3 || y0 >= H2) return;
          const i = (y0 * W3 + x0) * 3;
          buf[i] += r * a;
          buf[i + 1] += g * a;
          buf[i + 2] += b * a;
          return;
        }
        const w00 = (1 - fx) * (1 - fy) * a, w10 = fx * (1 - fy) * a, w01 = (1 - fx) * fy * a, w11 = fx * fy * a;
        if (x0 >= 0 && y0 >= 0 && x0 < W3 && y0 < H2) {
          const i = (y0 * W3 + x0) * 3;
          buf[i] += r * w00;
          buf[i + 1] += g * w00;
          buf[i + 2] += b * w00;
        }
        if (x0 + 1 >= 0 && y0 >= 0 && x0 + 1 < W3 && y0 < H2) {
          const i = (y0 * W3 + x0 + 1) * 3;
          buf[i] += r * w10;
          buf[i + 1] += g * w10;
          buf[i + 2] += b * w10;
        }
        if (x0 >= 0 && y0 + 1 >= 0 && x0 < W3 && y0 + 1 < H2) {
          const i = ((y0 + 1) * W3 + x0) * 3;
          buf[i] += r * w01;
          buf[i + 1] += g * w01;
          buf[i + 2] += b * w01;
        }
        if (x0 + 1 >= 0 && y0 + 1 >= 0 && x0 + 1 < W3 && y0 + 1 < H2) {
          const i = ((y0 + 1) * W3 + x0 + 1) * 3;
          buf[i] += r * w11;
          buf[i + 1] += g * w11;
          buf[i + 2] += b * w11;
        }
      }
      /** crisp single-pixel write */
      addPx(x, y, r, g, b, a = 1) {
        x |= 0;
        y |= 0;
        if (x < 0 || y < 0 || x >= this.W || y >= this.H) return;
        const i = (y * this.W + x) * 3;
        this.buf[i] += r * a;
        this.buf[i + 1] += g * a;
        this.buf[i + 2] += b * a;
      }
      blend(x, y, r, g, b, a) {
        x = Math.floor(x);
        y = Math.floor(y);
        if (x < 0 || y < 0 || x >= this.W || y >= this.H || a <= 0) return;
        if (a > 1) a = 1;
        const i = (y * this.W + x) * 3;
        this.buf[i] += (r - this.buf[i]) * a;
        this.buf[i + 1] += (g - this.buf[i + 1]) * a;
        this.buf[i + 2] += (b - this.buf[i + 2]) * a;
      }
      mul(x, y, m) {
        x = Math.floor(x);
        y = Math.floor(y);
        if (x < 0 || y < 0 || x >= this.W || y >= this.H) return;
        const i = (y * this.W + x) * 3;
        this.buf[i] *= m;
        this.buf[i + 1] *= m;
        this.buf[i + 2] *= m;
      }
      get(x, y, o) {
        x = clamp(x | 0, 0, this.W - 1);
        y = clamp(y | 0, 0, this.H - 1);
        const i = (y * this.W + x) * 3;
        o[0] = this.buf[i];
        o[1] = this.buf[i + 1];
        o[2] = this.buf[i + 2];
        return o;
      }
      drawBackground(warp) {
        const { W: W3, H: H2, bg, buf } = this;
        if (!warp) {
          buf.set(bg);
          return;
        }
        for (let y = 0; y < H2; y++) {
          for (let x = 0; x < W3; x++) {
            const w = warp(x, y);
            const o = (y * W3 + x) * 3;
            if (!w) {
              buf[o] = 0;
              buf[o + 1] = 0;
              buf[o + 2] = 0;
              continue;
            }
            let sx = w[0] | 0, sy = w[1] | 0;
            const m = w[2];
            if (sx < 0) sx = 0;
            else if (sx >= W3) sx = W3 - 1;
            if (sy < 0) sy = 0;
            else if (sy >= H2) sy = H2 - 1;
            const i = (sy * W3 + sx) * 3;
            buf[o] = bg[i] * m;
            buf[o + 1] = bg[i + 1] * m;
            buf[o + 2] = bg[i + 2] * m;
          }
        }
      }
      scaleAll(m) {
        const b = this.buf;
        for (let i = 0; i < b.length; i++) b[i] *= m;
      }
      markBase() {
        this.base.set(this.buf);
      }
      /** persistence: spell light leaves a decaying afterimage (doctrine 3.4) */
      applyTrail(persist, decay, advance) {
        const { buf, base, trail } = this;
        for (let i = 0; i < buf.length; i++) {
          const fx = buf[i] - base[i];
          const tr = trail[i];
          buf[i] += tr * persist;
          if (advance) {
            const d = tr * decay;
            trail[i] = fx > d ? fx : d;
          }
        }
      }
      resetTrail() {
        this.trail.fill(0);
      }
      snapshot(dst) {
        dst.set(this.buf);
      }
      // ---- post -------------------------------------------------------------
      /** camera transform + refraction + chromatic aberration, bilinear on HDR */
      resample() {
        const { W: W3, H: H2, buf, post } = this;
        const cx = W3 / 2, cy = H2 / 2;
        const iz = 1 / this.cam.zoom;
        const cr = Math.cos(-this.cam.rot), sr = Math.sin(-this.cam.rot);
        const camX = this.cam.x, camY = this.cam.y;
        const ca = this.chroma;
        const waves = this.waves;
        const nw = waves.length;
        const wr = [];
        for (const w of waves) wr.push(w.speed * (1 - Math.exp(-w.age * 3)) / 3);
        const sample = (sx, sy, c) => {
          if (sx < 0) sx = 0;
          else if (sx > W3 - 1.001) sx = W3 - 1.001;
          if (sy < 0) sy = 0;
          else if (sy > H2 - 1.001) sy = H2 - 1.001;
          const x0 = sx | 0, y0 = sy | 0;
          const fx = sx - x0, fy = sy - y0;
          const i = (y0 * W3 + x0) * 3 + c;
          const a = buf[i], b = buf[i + 3], d = buf[i + W3 * 3], e = buf[i + W3 * 3 + 3];
          return (a + (b - a) * fx) * (1 - fy) + (d + (e - d) * fx) * fy;
        };
        for (let y = 0; y < H2; y++) {
          for (let x = 0; x < W3; x++) {
            const u = (x + 0.5 - cx) * iz, v = (y + 0.5 - cy) * iz;
            let sx = u * cr - v * sr + cx - camX - 0.5;
            let sy = u * sr + v * cr + cy - camY - 0.5;
            let lr = 0, lg = 0, lb = 0;
            for (let k = 0; k < nw; k++) {
              const w = waves[k];
              const dx = sx - w.x, dy = (sy - w.y) * w.squash;
              const d = Math.sqrt(dx * dx + dy * dy) + 1e-4;
              const q = (d - wr[k]) / w.width;
              if (q > 2.6 || q < -2.6) continue;
              const env = 1 - w.age / w.life;
              const prof = q * Math.exp(-q * q * 1.6);
              const off = -prof * w.amp * env * env;
              sx += dx / d * off;
              sy += dy / d * off / w.squash;
              const brk = 0.35 + 0.65 * vnoise(dx * 0.07 + k * 9, dy * 0.07);
              const li = Math.exp(-q * q * 3) * env * 0.05 * brk * (w.amp / 4);
              lr += w.tint[0] * li;
              lg += w.tint[1] * li;
              lb += w.tint[2] * li;
            }
            const o = (y * W3 + x) * 3;
            if (ca > 0.12) {
              let dx = x - cx, dy = y - cy;
              const dl = Math.sqrt(dx * dx + dy * dy) + 1e-4;
              const k = ca * dl / (cx * 1.2);
              dx = dx / dl * k;
              dy = dy / dl * k;
              post[o] = sample(sx + dx, sy + dy, 0) + lr;
              post[o + 1] = sample(sx, sy, 1) + lg;
              post[o + 2] = sample(sx - dx, sy - dy, 2) + lb;
            } else {
              post[o] = sample(sx, sy, 0) + lr;
              post[o + 1] = sample(sx, sy, 1) + lg;
              post[o + 2] = sample(sx, sy, 2) + lb;
            }
          }
        }
        return post;
      }
      present(ctx) {
        const { W: W3, H: H2, bw, bh, bloomA, bloomB } = this;
        const idle = Math.abs(this.cam.x) < 0.01 && Math.abs(this.cam.y) < 0.01 && Math.abs(this.cam.zoom - 1) < 5e-4 && Math.abs(this.cam.rot) < 2e-4 && this.waves.length === 0 && this.chroma <= 0.12;
        const buf = idle ? this.buf : this.resample();
        bloomA.fill(0);
        for (let y = 0; y < H2; y++) {
          const by = (y >> 2) * bw;
          for (let x = 0; x < W3; x++) {
            const i = (y * W3 + x) * 3;
            const o = (by + (x >> 2)) * 3;
            const l = buf[i] * 0.3 + buf[i + 1] * 0.55 + buf[i + 2] * 0.15;
            if (l > 0.65) {
              const k = (l - 0.65) / (l + 1e-5) * 0.0625;
              bloomA[o] += buf[i] * k;
              bloomA[o + 1] += buf[i + 1] * k;
              bloomA[o + 2] += buf[i + 2] * k;
            }
          }
        }
        for (let pass = 0; pass < 2; pass++) {
          for (let y = 0; y < bh; y++) {
            for (let x = 0; x < bw; x++) {
              const o = (y * bw + x) * 3;
              for (let c = 0; c < 3; c++) {
                let s = 0;
                for (let k = -3; k <= 3; k++) {
                  const xx = clamp(x + k, 0, bw - 1) | 0;
                  s += bloomA[(y * bw + xx) * 3 + c] * W_K[k + 3];
                }
                bloomB[o + c] = s;
              }
            }
          }
          for (let y = 0; y < bh; y++) {
            for (let x = 0; x < bw; x++) {
              const o = (y * bw + x) * 3;
              for (let c = 0; c < 3; c++) {
                let s = 0;
                for (let k = -3; k <= 3; k++) {
                  const yy = clamp(y + k, 0, bh - 1) | 0;
                  s += bloomB[(yy * bw + x) * 3 + c] * W_K[k + 3];
                }
                bloomA[o + c] = s;
              }
            }
          }
        }
        const data = this.out.data;
        const q = this.levels - 1;
        let ex = this.exposure;
        const imf = this.impactFrames;
        if (imf === 1) ex *= 1.4;
        const fr = this.flash[0], fg = this.flash[1], fb2 = this.flash[2];
        const bAmt = this.bloomAmt;
        const cx = W3 * 0.5, cy = H2 * 0.5;
        const invR = 1 / Math.hypot(cx, cy);
        const it = this.impactTint;
        const itm = Math.max(it[0], it[1], it[2]) || 1;
        const tr = it[0] / itm, tg = it[1] / itm, tb = it[2] / itm;
        for (let y = 0; y < H2; y++) {
          let byf = (y + 0.5) * 0.25 - 0.5;
          if (byf < 0) byf = 0;
          else if (byf > bh - 1.001) byf = bh - 1.001;
          const by0 = byf | 0, by1 = Math.min(bh - 1, by0 + 1), bfy = byf - by0;
          const bayerRow = BAYER8[y & 7];
          for (let x = 0; x < W3; x++) {
            const i = (y * W3 + x) * 3;
            let bx = (x + 0.5) * 0.25 - 0.5;
            if (bx < 0) bx = 0;
            else if (bx > bw - 1.001) bx = bw - 1.001;
            const bx0 = bx | 0, bfx = bx - bx0;
            const i00 = (by0 * bw + bx0) * 3, i01 = (by1 * bw + bx0) * 3;
            const w00 = (1 - bfx) * (1 - bfy), w10 = bfx * (1 - bfy), w01 = (1 - bfx) * bfy, w11 = bfx * bfy;
            const br = bloomA[i00] * w00 + bloomA[i00 + 3] * w10 + bloomA[i01] * w01 + bloomA[i01 + 3] * w11;
            const bg2 = bloomA[i00 + 1] * w00 + bloomA[i00 + 4] * w10 + bloomA[i01 + 1] * w01 + bloomA[i01 + 4] * w11;
            const bb = bloomA[i00 + 2] * w00 + bloomA[i00 + 5] * w10 + bloomA[i01 + 2] * w01 + bloomA[i01 + 5] * w11;
            let r = (buf[i] + br * bAmt + fr) * ex;
            let g = (buf[i + 1] + bg2 * bAmt + fg) * ex;
            let b = (buf[i + 2] + bb * bAmt + fb2) * ex;
            const d = Math.hypot(x - cx, y - cy) * invR;
            const vig = 1 - 0.38 * d * d;
            r = tm(r * vig);
            g = tm(g * vig);
            b = tm(b * vig);
            if (imf >= 2) {
              const l = r * 0.3 + g * 0.55 + b * 0.15;
              if (imf === 3) {
                const v = l > 0.2 ? 1 : 0;
                r = v;
                g = v * 0.97;
                b = v * 0.93;
              } else {
                if (l > 0.2) {
                  r = 0.02;
                  g = 0.015;
                  b = 0.03;
                } else {
                  r = 0.35 + 0.65 * tr;
                  g = 0.35 + 0.65 * tg;
                  b = 0.35 + 0.65 * tb;
                }
              }
            }
            const dth = (bayerRow[x & 7] / 64 - 0.5) * 0.8 / q;
            const o = y * W3 + x << 2;
            data[o] = (clamp(r + dth) * q + 0.5 | 0) / q * 255;
            data[o + 1] = (clamp(g + dth) * q + 0.5 | 0) / q * 255;
            data[o + 2] = (clamp(b + dth) * q + 0.5 | 0) / q * 255;
            data[o + 3] = 255;
          }
        }
        ctx.putImageData(this.out, 0, 0);
      }
    };
    W_K = [0.0702, 0.1311, 0.1907, 0.216, 0.1907, 0.1311, 0.0702];
  }
});

// src/engine/draw.ts
function field(fb, x0, y0, x1, y1, fn) {
  const xa = Math.max(0, Math.floor(x0));
  const ya = Math.max(0, Math.floor(y0));
  const xb = Math.min(fb.W - 1, Math.ceil(x1));
  const yb = Math.min(fb.H - 1, Math.ceil(y1));
  const o = [0, 0, 0];
  const buf = fb.buf;
  for (let y = ya; y <= yb; y++) {
    let i = (y * fb.W + xa) * 3;
    for (let x = xa; x <= xb; x++, i += 3) {
      o[0] = 0;
      o[1] = 0;
      o[2] = 0;
      fn(x, y, o);
      if (o[0] !== 0 || o[1] !== 0 || o[2] !== 0) {
        buf[i] += o[0];
        buf[i + 1] += o[1];
        buf[i + 2] += o[2];
      }
    }
  }
}
function fieldMul(fb, x0, y0, x1, y1, fn) {
  const xa = Math.max(0, Math.floor(x0));
  const ya = Math.max(0, Math.floor(y0));
  const xb = Math.min(fb.W - 1, Math.ceil(x1));
  const yb = Math.min(fb.H - 1, Math.ceil(y1));
  const buf = fb.buf;
  for (let y = ya; y <= yb; y++) {
    let i = (y * fb.W + xa) * 3;
    for (let x = xa; x <= xb; x++, i += 3) {
      const m = fn(x, y);
      if (m !== 1) {
        buf[i] *= m;
        buf[i + 1] *= m;
        buf[i + 2] *= m;
      }
    }
  }
}
function glow(fb, cx, cy, r, c, k = 1, _pow = 2) {
  if (r <= 0 || k <= 0) return;
  const inv = 1 / r;
  field(fb, cx - r, cy - r, cx + r, cy + r, (x, y, o) => {
    const dx = (x + 0.5 - cx) * inv, dy = (y + 0.5 - cy) * inv;
    const d2 = dx * dx + dy * dy;
    if (d2 >= 1) return;
    const m = 1 - d2;
    const f = m * m * m * k;
    o[0] = c[0] * f;
    o[1] = c[1] * f;
    o[2] = c[2] * f;
  });
}
function pulseRing(fb, cx, cy, r, w, c, k = 1, squash = 1, rough = 0.22, seed = 0) {
  if (k <= 3e-3 || w <= 0) return;
  k *= 0.5;
  const ro = r * (1 + rough) + w * 3;
  field(fb, cx - ro - 1, cy - ro / squash - 1, cx + ro + 1, cy + ro / squash + 1, (x, y, o) => {
    const dx = x + 0.5 - cx, dy = (y + 0.5 - cy) * squash;
    const d = Math.hypot(dx, dy);
    const a = Math.atan2(dy, dx);
    const rr = r * (1 + rough * (Math.sin(a * 3 + seed) * 0.34 + Math.sin(a * 7 - seed * 1.7) * 0.2 + Math.sin(a * 13 + seed * 0.6) * 0.1));
    const q = (d - rr) / w;
    let f;
    if (q > 0) f = Math.exp(-q * q * 9);
    else f = Math.exp(q * 2.4) * 0.55;
    if (f < 0.02) return;
    const brk = 0.3 + 0.7 * vnoise(Math.cos(a) * 3.5 + seed * 3 + r * 0.02, Math.sin(a) * 3.5 + r * 0.03);
    const ff = f * f * k * brk;
    o[0] = c[0] * ff;
    o[1] = c[1] * ff;
    o[2] = c[2] * ff;
  });
}
function streak(fb, x0, y0, x1, y1, w0, w1, c, k = 1) {
  const dx = x1 - x0, dy = y1 - y0;
  const len = Math.hypot(dx, dy);
  if (len < 1e-3) {
    glow(fb, x0, y0, Math.max(w0, 0.8), c, k);
    return;
  }
  const wMax = Math.max(w0, w1) + 1;
  const minX = Math.min(x0, x1) - wMax, maxX = Math.max(x0, x1) + wMax;
  const minY = Math.min(y0, y1) - wMax, maxY = Math.max(y0, y1) + wMax;
  const il2 = 1 / (len * len);
  field(fb, minX, minY, maxX, maxY, (x, y, o) => {
    const px0 = x + 0.5 - x0, py0 = y + 0.5 - y0;
    let t = (px0 * dx + py0 * dy) * il2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = px0 - dx * t, qy = py0 - dy * t;
    const d = Math.hypot(qx, qy);
    const w = lerp(w0, w1, t);
    if (d > w) return;
    let f = 1 - d / w;
    f = f * f * k;
    o[0] = c[0] * f;
    o[1] = c[1] * f;
    o[2] = c[2] * f;
  });
}
function line(fb, x0, y0, x1, y1, c, a = 1) {
  x0 |= 0;
  y0 |= 0;
  x1 |= 0;
  y1 |= 0;
  const dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  const dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  let guard = 0;
  for (; ; ) {
    fb.add(x0, y0, c[0], c[1], c[2], a);
    if (x0 === x1 && y0 === y1 || guard++ > 4e3) break;
    const e2 = 2 * err;
    if (e2 >= dy) {
      err += dy;
      x0 += sx;
    }
    if (e2 <= dx) {
      err += dx;
      y0 += sy;
    }
  }
}
function ribbon(fb, pts, widthFn, colFn, opts = {}) {
  const n = pts.length;
  if (n < 2) return;
  const alpha = opts.alpha ?? 1;
  for (let i = 0; i < n - 1; i++) {
    const t02 = i / (n - 1), t1 = (i + 1) / (n - 1);
    const p0 = pts[i], p1 = pts[i + 1];
    let nx = -(p1.y - p0.y), ny = p1.x - p0.x;
    const l = Math.hypot(nx, ny) || 1;
    nx /= l;
    ny /= l;
    const w0 = widthFn(t02, i), w1 = widthFn(t1, i + 1);
    const segLen = Math.hypot(p1.x - p0.x, p1.y - p0.y);
    const steps = Math.max(1, Math.ceil(segLen));
    for (let s = 0; s < steps; s++) {
      const u = s / steps;
      const t = lerp(t02, t1, u);
      const cx = lerp(p0.x, p1.x, u), cy = lerp(p0.y, p1.y, u);
      const w = lerp(w0, w1, u);
      const iw = Math.ceil(w);
      for (let k = -iw; k <= iw; k++) {
        const e = Math.abs(k) / (w || 1);
        if (e > 1) continue;
        const c = colFn(t, i, e);
        if (!c) continue;
        const x = cx + nx * k, y = cy + ny * k;
        if (opts.blend) fb.blend(x, y, c[0], c[1], c[2], alpha);
        else fb.add(x, y, c[0], c[1], c[2], alpha);
      }
    }
  }
}
function boltPath(x0, y0, x1, y1, chaos, seed, depth = 5) {
  let pts = [
    { x: x0, y: y0 },
    { x: x1, y: y1 }
  ];
  let amp = chaos;
  let s = seed;
  for (let d = 0; d < depth; d++) {
    const next = [pts[0]];
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1];
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
      let nx = -(b.y - a.y), ny = b.x - a.x;
      const l = Math.hypot(nx, ny) || 1;
      nx /= l;
      ny /= l;
      const r = hash2(s++, i * 31 + d * 7) - 0.5;
      next.push({ x: mx + nx * r * amp, y: my + ny * r * amp });
      next.push(b);
    }
    pts = next;
    amp *= 0.55;
  }
  return pts;
}
function boltDraw(fb, pts, w, sheath, core, k = 1) {
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    streak(fb, a.x, a.y, b.x, b.y, w, w, sheath, k * 0.9);
  }
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    line(fb, a.x, a.y, b.x, b.y, core, k);
  }
}
var init_draw = __esm({
  "src/engine/draw.ts"() {
    "use strict";
    init_math();
  }
});

// src/engine/arena.ts
function buildFloor(fb) {
  const { W: W3, H: H2, bg } = fb;
  for (let y = 0; y < H2; y++) {
    for (let x = 0; x < W3; x++) {
      const i = (y * W3 + x) * 3;
      const depth = y / H2;
      let base = 0.03 + depth * 0.016;
      const n = fbm(x * 0.09, y * 0.12, 4);
      base += (n - 0.5) * 0.016;
      const tx = x % 26, ty = y % 18;
      const jitter = hash2(Math.floor(x / 26), Math.floor(y / 18));
      if (tx === 0 || ty === 0) base *= 0.62 + jitter * 0.16;
      if (tx === 1 || ty === 1) base *= 0.86;
      const tileN = hash2(Math.floor(x / 26) * 7 + 3, Math.floor(y / 18) * 13 + 5);
      if (tileN > 0.9) base *= 0.82;
      else if (tileN < 0.07) base *= 1.14;
      let r = base * 0.95, g = base * 1, b = base * 1.35;
      const dC = Math.hypot(x - CASTER.x, (y - CASTER.y) * 1.3);
      const warm = Math.max(0, 1 - dC / 70) * 0.018;
      r += warm * 1.2;
      g += warm * 0.8;
      b += warm * 0.5;
      bg[i] = r;
      bg[i + 1] = g;
      bg[i + 2] = b;
    }
  }
  etchCircle(fb, ARENA_C.x, ARENA_C.y, 96, 0.013, 1.65);
  etchCircle(fb, ARENA_C.x, ARENA_C.y, 62, 9e-3, 1.65);
  for (let k = 0; k < 24; k++) {
    const a = k / 24 * TAU;
    const r0 = k % 6 === 0 ? 88 : 92;
    for (let r = r0; r < 96; r += 0.6) {
      const x = Math.round(ARENA_C.x + Math.cos(a) * r);
      const y = Math.round(ARENA_C.y + Math.sin(a) * r / 1.65);
      if (x < 0 || y < 0 || x >= W3 || y >= H2) continue;
      const i = (y * W3 + x) * 3;
      bg[i] += 9e-3;
      bg[i + 1] += 0.011;
      bg[i + 2] += 0.018;
    }
  }
}
function etchCircle(fb, cx, cy, r, k, squash) {
  const steps = Math.ceil(r * 7);
  for (let i = 0; i < steps; i++) {
    const a = i / steps * TAU;
    const x = Math.round(cx + Math.cos(a) * r);
    const y = Math.round(cy + Math.sin(a) * r / squash);
    if (x < 0 || y < 0 || x >= fb.W || y >= fb.H) continue;
    const idx = (y * fb.W + x) * 3;
    fb.bg[idx] += k * 0.8;
    fb.bg[idx + 1] += k * 0.9;
    fb.bg[idx + 2] += k * 1.4;
  }
}
function drawCaster(fb, t, accent, intensity, kick = 0) {
  const bx = Math.round(CASTER.x - 5 + kick * 0.5);
  const by = Math.round(CASTER.y - 14 + Math.sin(t * 2.1) * 0.5);
  for (let y = -4; y <= 5; y++)
    for (let x = -9; x <= 9; x++) {
      const d = Math.hypot(x / 9, (y - 1) / 3.6);
      if (d > 1) continue;
      fb.mul(CASTER.x + x, CASTER.y + y, lerp(0.35, 1, d));
    }
  for (let y = 0; y < CASTER_SPR.length; y++) {
    const row = CASTER_SPR[y];
    for (let x = 0; x < row.length; x++) {
      const ch = row[x];
      if (ch === "." || ch === " ") continue;
      const c = CASTER_PAL[ch];
      if (!c) continue;
      fb.blend(bx + x, by + y, c[0], c[1], c[2], 1);
    }
  }
  const k = 0.5 + intensity;
  for (let y = 0; y < CASTER_SPR.length; y++) {
    const row = CASTER_SPR[y];
    for (let x = 0; x < row.length; x++) {
      if (row[x] === "." || row[x] === " ") continue;
      const right = x + 1 >= row.length || row[x + 1] === "." || row[x + 1] === " ";
      if (right)
        fb.add(bx + x, by + y, accent[0], accent[1], accent[2], 0.22 * k);
    }
  }
  const fx = CASTER.x + 7 + kick * 0.8, fy = CASTER.y - 8;
  const ik = Math.min(1.1, intensity);
  glow(fb, fx, fy, 2.5 + ik * 3.4, accent, 0.2 + ik * 0.28);
  fb.add(fx, fy, accent[0], accent[1], accent[2], 0.5 + ik * 0.5);
}
function drawDust(fb, t) {
  for (let i = 0; i < 44; i++) {
    const s = hash2(i * 3 + 1, 7);
    const s2 = hash2(i * 5 + 2, 11);
    const sp = 0.3 + s2 * 0.6;
    const x = (s * VIEW_W + t * 7 * sp) % VIEW_W;
    const y = (s2 * VIEW_H + Math.sin(t * 0.6 + i) * 6 + VIEW_H) % VIEW_H;
    const a = 0.03 + 0.045 * (0.5 + 0.5 * Math.sin(t * 2 + i * 2.3));
    fb.add(x, y, 0.5, 0.56, 0.8, a);
  }
}
var VIEW_W, VIEW_H, CASTER, ARENA_C, ANCHORS, CASTER_SPR, CASTER_PAL;
var init_arena = __esm({
  "src/engine/arena.ts"() {
    "use strict";
    init_draw();
    init_math();
    VIEW_W = 416;
    VIEW_H = 234;
    CASTER = { x: 104, y: 150 };
    ARENA_C = { x: 232, y: 124 };
    ANCHORS = [
      { x: 316, y: 86 },
      { x: 348, y: 162 },
      { x: 236, y: 196 },
      { x: 196, y: 70 }
    ];
    CASTER_SPR = [
      "....ooo....",
      "...o222o...",
      "..o23332o..",
      "..o23332o..",
      "..o21112o..",
      ".o2211122o.",
      ".o221112 o.",
      "o22111112 o",
      "o22111112 o",
      ".o2111112o.",
      ".o211111 o.",
      "..o21112o..",
      "..o2111o...",
      "..o211o....",
      "...oo o....",
      "..o11 o....",
      "..ooo oo..."
    ];
    CASTER_PAL = {
      o: [0.012, 0.012, 0.022],
      "1": [0.1, 0.1, 0.15],
      "2": [0.17, 0.17, 0.26],
      "3": [0.26, 0.27, 0.4]
    };
  }
});

// src/engine/enemies.ts
function mirror(half) {
  const shade = { "3": "2", "2": "1" };
  return half.map(
    (h) => h + h.slice(0, h.length - 1).split("").reverse().map((c) => shade[c] ?? c).join("")
  );
}
function mk(half, pal, mass, hp) {
  const rows = mirror(half);
  return { rows, w: Math.max(...rows.map((r) => r.length)), h: rows.length, pal, mass, hp };
}
function makeFormation() {
  return FORMATION.map(([type, x, y], id) => {
    const spr = SPR[type];
    return {
      id,
      type,
      spr,
      x,
      y,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      hx: x,
      hy: y,
      hp: spr.hp,
      maxHp: spr.hp,
      lag: spr.hp,
      lagDelay: 0,
      mass: spr.mass,
      flash: 0,
      flashTint: [1, 1, 1],
      sq: 0,
      sqv: 0,
      lean: 0,
      stagger: 0,
      burn: 0,
      char: 0,
      wet: 0,
      freeze: 0,
      shock: 0,
      root: 0,
      warp: 0,
      spore: 0,
      dead: false,
      deathT: 0,
      kind: "fire",
      cutAng: 0,
      kdx: 0,
      kdy: 0,
      hpShow: 0,
      seed: id * 97 + 13
    };
  });
}
function updateEnemy(e, dt, W3) {
  if (e.dead) return;
  const s = e.spr;
  if (e.burn > 0) {
    e.hp -= e.burn * 10 * dt;
    e.lagDelay = Math.max(e.lagDelay, 0.2);
    e.char = Math.min(1, e.char + e.burn * dt * 0.45);
    e.burn = Math.max(0, e.burn - dt * 0.2);
    if (W3.rand() < e.burn * 0.6)
      W3.emit({ x: e.x + (W3.rand() - 0.5) * s.w, y: e.y, z: s.h * W3.rand(), vx: (W3.rand() - 0.5) * 20, vy: -8 - W3.rand() * 24, vz: 0, life: 0.5 + W3.rand() * 0.8, kind: 0 });
  }
  e.wet = Math.max(0, e.wet - dt * 0.25);
  if (e.wet > 0.3 && W3.rand() < 0.12)
    W3.emit({ x: e.x + (W3.rand() - 0.5) * s.w * 0.8, y: e.y, z: s.h * (0.3 + W3.rand() * 0.6), vx: 0, vy: 0, vz: 0, life: 0.6, kind: 4 });
  e.freeze = Math.max(0, e.freeze - dt * 0.1);
  e.shock = Math.max(0, e.shock - dt * 0.8);
  if (e.shock > 0.3 && W3.rand() < 0.3)
    W3.emit({ x: e.x + (W3.rand() - 0.5) * s.w, y: e.y, z: s.h * W3.rand(), vx: (W3.rand() - 0.5) * 140, vy: (W3.rand() - 0.5) * 60, vz: 40, life: 0.2, kind: 2 });
  e.root = Math.max(0, e.root - dt * 0.16);
  e.warp = Math.max(0, e.warp - dt * 0.7);
  e.spore = Math.max(0, e.spore - dt * 0.08);
  if (e.spore > 0.2 && W3.rand() < 0.15)
    W3.emit({ x: e.x + (W3.rand() - 0.5) * s.w, y: e.y, z: s.h * W3.rand(), vx: (W3.rand() - 0.5) * 10, vy: -6, vz: 0, life: 1.2, kind: 3 });
  e.flash -= dt;
  e.stagger -= dt;
  e.hpShow -= dt;
  if (e.lag > e.hp) {
    e.lagDelay -= dt;
    if (e.lagDelay <= 0) e.lag = Math.max(e.hp, e.lag - e.maxHp * dt * 0.9);
  }
  if (e.hp <= 0) {
    killEnemy(e, "fire", W3);
    return;
  }
  const frozen = e.freeze > 0.5;
  if (e.z > 0 || e.vz > 0) {
    e.vz -= 560 * dt;
    e.z += e.vz * dt;
    if (e.z <= 0) {
      e.z = 0;
      if (e.vz < -110) {
        e.sq = -0.34 * Math.min(1, -e.vz / 320);
        e.sqv = 0;
        W3.shake(0.035 * e.mass);
        for (let i = 0; i < 7; i++) {
          const a = W3.rand() * TAU;
          W3.emit({ x: e.x, y: e.y, z: 0, vx: Math.cos(a) * 50, vy: Math.sin(a) * 22, vz: 0, life: 0.6, kind: 1 });
        }
      }
      e.vz = e.vz < -170 ? -e.vz * 0.28 : 0;
    }
  }
  const grounded = e.z <= 0.01;
  const fr = grounded ? frozen ? 1.1 : 6.5 : 0.5;
  e.vx *= Math.exp(-fr * dt);
  e.vy *= Math.exp(-fr * dt);
  e.x += e.vx * dt;
  e.y += e.vy * dt;
  if (e.x < 18 || e.x > VIEW_W - 18) {
    e.x = clamp(e.x, 18, VIEW_W - 18);
    e.vx *= -0.4;
    e.sq = -0.2;
  }
  if (e.y < 34 || e.y > VIEW_H - 6) {
    e.y = clamp(e.y, 34, VIEW_H - 6);
    e.vy *= -0.4;
    e.sq = -0.2;
  }
  const spd = Math.hypot(e.vx, e.vy);
  if (grounded && spd > 70 && W3.rand() < 0.6)
    W3.emit({ x: e.x, y: e.y, z: 0, vx: -e.vx * 0.2 + (W3.rand() - 0.5) * 20, vy: -e.vy * 0.2, vz: 0, life: 0.5, kind: frozen ? 5 : 1 });
  if (!frozen) {
    e.sqv += (-260 * e.sq - 12 * e.sqv) * dt;
    e.sq += e.sqv * dt;
    const lt = clamp(e.vx * 5e-3, -0.55, 0.55);
    e.lean += (lt - e.lean) * Math.min(1, dt * 10);
  }
  if (grounded && e.stagger <= 0 && !frozen && e.root < 0.3) {
    const dx = e.hx - e.x, dy = e.hy - e.y;
    const d = Math.hypot(dx, dy);
    if (d > 1.5 && spd < 20) {
      e.vx += dx / d * 60 * dt;
      e.vy += dy / d * 60 * dt;
    }
  }
}
function damageEnemy(e, o, W3) {
  if (e.dead) return;
  const f = o.force ?? 0.4;
  let dmg = o.dmg ?? 8;
  let shatter = false;
  if (e.freeze > 0.55 && f > 0.45) {
    shatter = true;
    dmg *= 1.8;
    e.freeze = 0;
  }
  if (o.element === "volt" && e.wet > 0.3) dmg *= 1.5;
  if (o.element === "verdant" && e.spore > 0.3) {
    dmg += 40 * e.spore;
    for (let i = 0; i < 24; i++) {
      const a = W3.rand() * TAU;
      W3.emit({ x: e.x, y: e.y, z: e.spr.h * 0.5, vx: Math.cos(a) * 70, vy: Math.sin(a) * 40, vz: 0, life: 1.4, kind: 3 });
    }
    e.spore = 0;
  }
  dmg = Math.max(1, Math.round(dmg));
  e.hp -= dmg;
  e.lagDelay = 0.4;
  e.hpShow = 2.4;
  W3.popup(e.x + (W3.rand() - 0.5) * 8, e.y - e.z - e.spr.h - 4, dmg, o.element, dmg >= 80);
  e.flash = 0.1;
  e.flashTint = ELEMENT_TINT[o.element];
  const hold = e.root > 0.4 ? 0.25 : 1;
  const kb = f * 240 / e.mass * hold;
  e.vx += (o.dirx ?? 0) * kb;
  e.vy += (o.diry ?? 0) * kb * 0.7;
  const lift = (o.lift ?? f * 0.35) * hold;
  if (lift > 0) {
    e.vz += lift * 230 / Math.sqrt(e.mass);
    if (e.z <= 0) e.z = 0.01;
  }
  e.sq = -0.38 * Math.min(1, f + 0.25);
  e.sqv = 0;
  e.stagger = Math.max(e.stagger, 0.25 + f * 0.6);
  e.lean = clamp(e.lean + (o.dirx ?? 0) * f * 0.8, -0.7, 0.7);
  const amt = o.status ?? 0.3 + f * 0.5;
  if (!shatter)
    switch (o.element) {
      case "fire":
        e.burn = Math.min(1.2, e.burn + amt);
        break;
      case "water":
        e.wet = 1;
        break;
      case "ice":
        e.freeze = Math.min(1, e.freeze + amt);
        break;
      case "volt":
        e.shock = Math.min(1, e.shock + amt);
        break;
      case "verdant":
        e.root = Math.min(1, e.root + amt * 0.8);
        break;
      case "astral":
        e.warp = Math.min(1, e.warp + amt);
        break;
    }
  if (e.hp <= 0) killEnemy(e, shatter ? "ice" : o.cut !== void 0 ? "cut" : o.element, W3, o);
}
function killEnemy(e, kind, W3, o) {
  if (e.dead) return;
  e.dead = true;
  e.hp = 0;
  e.deathT = W3.simT;
  e.kind = kind;
  e.cutAng = o?.cut ?? 0;
  e.kdx = o?.dirx ?? 0;
  e.kdy = o?.diry ?? 0;
  W3.freeze(0.05, W3.stopDelay > 0 ? W3.stopDelay : 0.03);
  W3.shake(0.12);
  W3.chroma = Math.max(W3.chroma, 1.5);
}
function drawSprite(fb, e, o) {
  const s = e.spr;
  const sX = o.scaleX ?? 1, sY = o.scaleY ?? 1, ln = o.lean ?? 0;
  const fx0 = e.x + (o.ox ?? 0), fy0 = e.y - e.z + (o.oy ?? 0);
  const hh = Math.ceil(s.h * sY) + 2;
  const hw = Math.ceil(s.w * sX / 2 + Math.abs(ln) * s.h * sY) + 3;
  const a = o.alpha ?? 1;
  for (let Y = Math.floor(fy0 - hh); Y <= Math.ceil(fy0); Y++) {
    if (Y < 0 || Y >= fb.H) continue;
    const ly = fy0 - (Y + 0.5);
    if (ly < 0) continue;
    const hy = ly / sY;
    const row = Math.floor(s.h - hy);
    if (row < 0 || row >= s.h) continue;
    const str = s.rows[row];
    const shift = o.rowShift ? o.rowShift(row) : 0;
    for (let X = Math.floor(fx0 - hw); X <= Math.ceil(fx0 + hw); X++) {
      if (X < 0 || X >= fb.W) continue;
      const lx = X + 0.5 - fx0;
      const col = Math.floor((lx - ln * hy * sY) / sX + s.w / 2 - shift);
      if (col < 0 || col >= str.length) continue;
      const ch = str[col];
      if (empty(ch)) continue;
      const base = s.pal[ch];
      if (!base) continue;
      const c = o.tint ? o.tint(base, ch, col, row, X, Y) : base;
      if (!c) continue;
      const i = (Y * fb.W + X) * 3;
      if (o.additive) {
        fb.buf[i] += c[0] * a;
        fb.buf[i + 1] += c[1] * a;
        fb.buf[i + 2] += c[2] * a;
      } else {
        fb.buf[i] = c[0];
        fb.buf[i + 1] = c[1];
        fb.buf[i + 2] = c[2];
      }
    }
  }
}
function eachPixel(e, fn) {
  const s = e.spr;
  for (let row = 0; row < s.h; row++) {
    const str = s.rows[row];
    for (let col = 0; col < str.length; col++) {
      const ch = str[col];
      if (empty(ch)) continue;
      const base = s.pal[ch];
      if (base) fn(col, row, ch, base);
    }
  }
}
function sampleLight(fb, e) {
  let r = 0, g = 0, b = 0, n = 0;
  const cx = e.x, cy = e.y - e.z - e.spr.h * 0.5;
  for (let k = 0; k < 12; k++) {
    const a = k / 12 * TAU;
    for (const rad of [7, 15, 24]) {
      const x = Math.round(cx + Math.cos(a) * rad), y = Math.round(cy + Math.sin(a) * rad * 0.8);
      if (x < 0 || y < 0 || x >= fb.W || y >= fb.H) continue;
      const i = (y * fb.W + x) * 3;
      r += Math.max(0, fb.buf[i] - fb.base[i]);
      g += Math.max(0, fb.buf[i + 1] - fb.base[i + 1]);
      b += Math.max(0, fb.buf[i + 2] - fb.base[i + 2]);
      n++;
    }
  }
  return n ? [r / n, g / n, b / n] : [0, 0, 0];
}
function renderEnemies(fb, W3) {
  const order = [...W3.enemies].sort((a, b) => a.y - b.y);
  for (const e of order) if (e.dead) drawResidue(fb, e, W3);
  for (const e of order) {
    if (e.dead) continue;
    const s = e.spr;
    const rx = s.w * 0.55 * (1 - Math.min(0.55, e.z / 70)), ry = rx / 2.6;
    for (let y = -Math.ceil(ry); y <= Math.ceil(ry); y++)
      for (let x = -Math.ceil(rx); x <= Math.ceil(rx); x++) {
        const d = Math.hypot(x / rx, y / ry);
        if (d < 1) fb.mul(e.x + x, e.y + 1 + y, lerp(0.35, 1, d * d));
      }
  }
  const lights = /* @__PURE__ */ new Map();
  for (const e of order) if (!e.dead) lights.set(e.id, sampleLight(fb, e));
  for (const e of order) {
    if (e.dead) drawDeath(fb, e, W3);
    else drawAlive(fb, e, W3, lights.get(e.id));
  }
  drawFx(fb, W3);
}
function drawAlive(fb, e, W3, L) {
  const s = e.spr;
  const t = W3.simT;
  const frame = Math.floor(W3.clock * 30);
  const frozen = e.freeze > 0.5;
  const breathe = frozen ? 0 : Math.sin(t * 3 + e.seed) * 0.035;
  const air = e.z > 0 ? clamp(e.vz * 12e-4, -0.15, 0.25) : 0;
  const scaleY = 1 + e.sq + breathe + air;
  const scaleX = 1 - e.sq * 0.6 - breathe * 0.5 - air * 0.4;
  const jit = e.shock > 0.15 && hash2(frame, e.id) > 0.5 ? hash2(frame, e.id + 9) > 0.5 ? 1 : -1 : 0;
  const xray = e.shock > 0.15 && hash2(frame * 3, e.id * 7) < e.shock * 0.45;
  const lit = [Math.min(9, 0.85 + L[0] * 5), Math.min(9, 0.85 + L[1] * 5), Math.min(9, 0.85 + L[2] * 5)];
  if (e.warp > 0.05) {
    const off = e.warp * (4 + 2 * Math.sin(t * 9));
    drawSprite(fb, e, { ox: -off, scaleX, scaleY, lean: e.lean, additive: true, alpha: e.warp * 0.8, tint: () => [0.9, 0.05, 0.35] });
    drawSprite(fb, e, { ox: off, oy: -1, scaleX, scaleY, lean: e.lean, additive: true, alpha: e.warp * 0.8, tint: () => [0.15, 0.35, 1.2] });
  }
  const rowShift = e.warp > 0.1 ? (row) => hash2(row + frame * 13, e.id) > 0.8 ? Math.round((hash2(row, frame) - 0.5) * e.warp * 8) : 0 : void 0;
  drawSprite(fb, e, {
    ox: jit,
    scaleX,
    scaleY,
    lean: e.lean,
    rowShift,
    tint: (base, ch, col, row, X, Y) => {
      const i = (Y * fb.W + X) * 3;
      const fr = Math.max(0, fb.buf[i] - fb.base[i]) * 0.4, fg = Math.max(0, fb.buf[i + 1] - fb.base[i + 1]) * 0.4, fbb = Math.max(0, fb.buf[i + 2] - fb.base[i + 2]) * 0.4;
      if (e.flash > 0) {
        if (e.flash > 0.05) return [1.5, 1.5, 1.5];
        return [e.flashTint[0] * 0.8, e.flashTint[1] * 0.8, e.flashTint[2] * 0.8];
      }
      if (xray) {
        if (ch === "o") return [1, 1.3, 2.9];
        if (ch === "e") return [3, 3, 3];
        return [0.02, 0.02, 0.06];
      }
      let r = base[0], g = base[1], b = base[2];
      if (ch === "e") {
        const k = frozen ? 0.25 : 1;
        return [r * k + fr, g * k + fg, b * k + fbb];
      }
      if (e.char > 0) {
        const k = 1 - e.char * 0.85;
        r *= k;
        g *= k;
        b *= k;
      }
      if (e.wet > 0) {
        r *= 1 - e.wet * 0.3;
        g *= 1 - e.wet * 0.12;
        b += e.wet * 0.03;
      }
      if (e.freeze > 0) {
        const f = Math.min(1, e.freeze) * 0.8;
        const lightness = ch === "o" ? 0.05 : ch === "3" ? 0.42 : ch === "2" ? 0.3 : 0.2;
        r = lerp(r, lightness * 0.55, f);
        g = lerp(g, lightness * 0.85, f);
        b = lerp(b, lightness * 1.3, f);
      }
      r *= lit[0];
      g *= lit[1];
      b *= lit[2];
      const above = row > 0 ? s.rows[row - 1][col] : void 0;
      if (empty(above)) {
        r += 0.06;
        g += 0.07;
        b += 0.11;
      }
      if (ch === "o") {
        r += L[0] * 1.4;
        g += L[1] * 1.4;
        b += L[2] * 1.4;
      }
      if (e.burn > 0.05 && hash2(col * 3 + e.seed, row * 5) > 0.76) {
        const c = fireCol(e.burn * (0.45 + 0.4 * Math.sin(t * 9 + col + row)));
        r += c[0] * 0.6;
        g += c[1] * 0.6;
        b += c[2] * 0.6;
      }
      if (e.spore > 0.05 && hash2(col + e.seed, row * 3) > 0.84) {
        const k = e.spore * (0.5 + 0.5 * Math.sin(t * 4 + col));
        r += 0.2 * k;
        g += 0.9 * k;
        b += 0.6 * k;
      }
      return [r + fr, g + fg, b + fbb];
    }
  });
  const fy0 = e.y - e.z;
  if (e.burn > 0.05) {
    for (let col = 0; col < s.w; col++) {
      let top = -1;
      for (let r = 0; r < s.h; r++)
        if (!empty(s.rows[r][col])) {
          top = r;
          break;
        }
      if (top < 0) continue;
      const hy = s.h - top;
      const X = e.x + (col - s.w / 2 + 0.5) * scaleX + e.lean * hy * scaleY + jit;
      const Y = fy0 - hy * scaleY;
      const Lf = Math.min(1.2, e.burn) * (2 + 6 * vnoise(col * 0.6 + e.seed, t * 7));
      for (let k = 0; k < Lf; k++) {
        const u = k / Lf;
        const c = fireCol((1 - u) * Math.min(1, e.burn) * 0.95 + 0.05);
        fb.add(X + Math.sin(t * 11 + col + k * 0.7) * u * 1.3, Y - k, c[0], c[1], c[2], 0.85 * (1 - u * 0.4));
      }
    }
    glow(fb, e.x, fy0 - s.h * 0.5, s.w, [1.2, 0.4, 0.1], 0.12 * Math.min(1, e.burn));
  }
  if (e.root > 0.08) {
    for (let v = 0; v < 2; v++) {
      const baseRow = s.h * (0.5 + v * 0.3);
      const reach = clamp(e.root * 1.5);
      for (let x = -s.w / 2; x <= s.w / 2; x += 0.5) {
        if ((x + s.w / 2) / s.w > reach) break;
        const Y = fy0 - (s.h - baseRow) * scaleY + Math.sin(x * 0.9 + e.seed + v * 2) * 1.6;
        const X = e.x + x * scaleX + jit;
        fb.blend(X, Y, 0.07, 0.3 + 0.1 * v, 0.08, 1);
        if (Math.abs(x * 2 % 6) < 0.5) {
          fb.add(X, Y - 1, 0.3, 0.6, 0.25, 0.8);
          fb.add(X + 1, Y - 2, 0.25, 0.7, 0.25, 0.6 * e.root);
        }
      }
    }
  }
  if (e.freeze > 0.3) {
    const k = clamp((e.freeze - 0.3) / 0.35);
    const cx = e.x, cy = fy0 - s.h * 0.5, rx = s.w * 0.62 + 2, ry = s.h * 0.62 + 2;
    const sides = 7;
    for (let Y = Math.floor(cy - ry - 1); Y <= Math.ceil(cy + ry + 1); Y++)
      for (let X = Math.floor(cx - rx - 1); X <= Math.ceil(cx + rx + 1); X++) {
        const dx = (X + 0.5 - cx) / rx, dy = (Y + 0.5 - cy) / ry;
        const a = Math.atan2(dy, dx) + Math.PI;
        const st = TAU / sides;
        const si = Math.floor(a / st) % sides;
        const fr = a / st - Math.floor(a / st);
        const rad = lerp(0.82 + hash2(e.seed, si) * 0.3, 0.82 + hash2(e.seed, (si + 1) % sides) * 0.3, fr);
        const d = Math.hypot(dx, dy);
        if (d > rad) continue;
        const shade = 0.5 + 0.5 * hash2(si, e.seed + 3);
        if (rad - d < 0.1) fb.add(X, Y, 0.55 * k, 0.85 * k, 1.25 * k, 1);
        else fb.add(X, Y, 0.035 * k * shade, 0.07 * k * shade, 0.12 * k * shade, 1);
      }
    const gl = (W3.clock * 0.7 + e.seed) % 1;
    fb.add(cx - rx * 0.4 + gl * rx * 0.8, cy - ry * 0.5 + gl * ry * 0.4, 2, 2.4, 2.8, 0.6 * k);
  }
  if (e.shock > 0.2 && hash2(frame, e.id * 3) > 0.4) {
    const r1 = hash2(frame, e.id + 1), r2 = hash2(frame + 7, e.id + 2);
    const x0 = e.x + (r1 - 0.5) * s.w, y0 = fy0 - s.h * (0.2 + 0.6 * r2);
    const x1 = e.x + (r2 - 0.5) * s.w, y1 = fy0 - s.h * (0.2 + 0.6 * r1);
    const pts = boltPath(x0, y0, x1, y1, 5, frame * 31 + e.id, 3);
    for (let i = 0; i < pts.length - 1; i++) line(fb, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, [1.6, 1.9, 3.2], e.shock);
  }
}
function drawDeath(fb, e, W3) {
  const age = W3.simT - e.deathT;
  const s = e.spr;
  const fy0 = e.y - e.z;
  const ox = e.x - s.w / 2, oy = fy0 - s.h;
  const frame = Math.floor(W3.clock * 30);
  switch (e.kind) {
    case "fire": {
      const D = 1.5, u = age / D;
      if (u > 1.7) return;
      if (u < 1) glow(fb, e.x, fy0 - s.h * 0.5, s.w * 1.1, [1.4, 0.5, 0.12], 0.45 * (1 - u));
      eachPixel(e, (col, row, _ch, base) => {
        const thr = row / s.h * 0.45 + hash2(col * 3 + e.seed, row * 7) * 0.5;
        const local = u * 1.3 - thr;
        const px = ox + col, py = oy + row;
        if (local < 0) {
          const k = clamp(u * 2.4);
          let r = base[0] * (1 - k * 0.92), g = base[1] * (1 - k * 0.92), b = base[2] * (1 - k * 0.92);
          if (local > -0.1) {
            const fc = fireCol(0.45 + (1 + local / 0.1) * 0.55);
            r += fc[0];
            g += fc[1];
            b += fc[2];
          }
          fb.blend(px, py, r, g, b, 1);
        } else {
          const a = local * D;
          if (a > 1) return;
          const hx = hash2(col + e.seed * 3, row) - 0.5;
          const qx = px + hx * 16 * a + Math.sin(a * 5 + col) * 1.5 + e.kdx * a * 14;
          const qy = py - a * 14 - a * a * 12;
          const heat = 0.8 - a * 1.8;
          const c = heat > 0.1 ? fireCol(heat) : [0.08, 0.065, 0.065];
          if (dith(qx, qy, 1 - a)) fb.add(qx, qy, c[0], c[1], c[2], 1);
        }
      });
      return;
    }
    case "water": {
      if (age < 0.13) {
        const k = age / 0.13;
        drawSprite(fb, e, { scaleX: 1 + 0.5 * k, scaleY: 1 - 0.45 * k, tint: (b) => [b[0] * 0.6 + 0.1 * k, b[1] * 0.7 + 0.3 * k, b[2] + 0.7 * k] });
        return;
      }
      const a = age - 0.13;
      if (a > 1.3) return;
      eachPixel(e, (col, row) => {
        const hx = hash2(col + e.seed, row * 3) - 0.5, hy = hash2(col * 5, row + e.seed) - 0.5;
        const lx = col - s.w / 2, lz = (s.h - row) * 0.55;
        const vx = lx * 9 + hx * 60 + e.kdx * 50, vy = hy * 40 + e.kdy * 30, vz = 40 + hash2(row, col + e.seed) * 120;
        const tl = (vz + Math.sqrt(vz * vz + 1200 * lz)) / 600;
        const aa = Math.min(a, tl);
        const z = Math.max(0, lz + vz * aa - 300 * aa * aa);
        const qx = e.x + lx * 1.45 + vx * aa, qy = e.y + vy * aa * 0.6 - z;
        const br = 0.6 + 0.4 * hx;
        if (dith(qx, qy, 1 - a / 1.3)) fb.add(qx, qy, 0.32 * br, 0.75 * br, 1.5 * br, 1);
      });
      return;
    }
    case "ice": {
      if (age < 0.06) {
        drawSprite(fb, e, { tint: () => [1.8, 2.3, 2.8] });
        return;
      }
      const a = age - 0.06;
      if (a > 2.4) return;
      const N = 6;
      const sx = [], sy = [];
      for (let k = 0; k < N; k++) {
        sx.push(hash2(e.seed, k) * s.w);
        sy.push(hash2(k, e.seed) * s.h);
      }
      const melt = 1 - clamp((a - 1.3) / 1.1);
      eachPixel(e, (col, row, ch, base) => {
        let k = 0, bd = 1e9;
        for (let j = 0; j < N; j++) {
          const d = (col - sx[j]) ** 2 + (row - sy[j]) ** 2;
          if (d < bd) {
            bd = d;
            k = j;
          }
        }
        let dx = sx[k] - s.w / 2, dy = sy[k] - s.h / 2;
        const dl = Math.hypot(dx, dy) || 1;
        dx /= dl;
        dy /= dl;
        const sp = 45 + hash2(k, 3) * 70;
        const vx = dx * sp + e.kdx * 70, vy = dy * sp * 0.4 + e.kdy * 40;
        const vz = 50 + hash2(k, 5 + e.seed) * 110, z0 = s.h - sy[k];
        const tl = (vz + Math.sqrt(vz * vz + 1400 * z0)) / 700;
        const aa = Math.min(a, tl);
        const z = Math.max(0, z0 + vz * aa - 350 * aa * aa);
        const ang = (hash2(k, 7) - 0.5) * 12 * aa;
        const rx = col - sx[k], ry = row - sy[k];
        const qx = e.x + (sx[k] - s.w / 2) + vx * aa + rx * Math.cos(ang) - ry * Math.sin(ang);
        const qy = e.y + vy * aa - z + rx * Math.sin(ang) + ry * Math.cos(ang);
        if (!dith(qx, qy, melt)) return;
        const lum = ch === "o" ? 0.12 : base[0] + base[1] + base[2];
        let c = [0.18 + lum * 0.6, 0.32 + lum * 0.9, 0.55 + lum * 1.3];
        if (hash2(k, Math.floor(W3.clock * 12)) > 0.86) c = [1.4, 1.9, 2.5];
        fb.blend(qx, qy, c[0], c[1], c[2], 1);
      });
      return;
    }
    case "volt": {
      if (age < 0.12) {
        drawSprite(fb, e, { tint: (_b, ch) => ch === "o" ? [1.4, 1.7, 3.2] : ch === "e" ? [3, 3, 3] : [0.02, 0.02, 0.07] });
        glow(fb, e.x, fy0 - s.h * 0.5, s.w * 1.4, [0.6, 0.8, 2], 0.8);
        return;
      }
      const a = age - 0.12;
      if (a > 0.9) return;
      eachPixel(e, (col, row, ch, base) => {
        const thr = row / s.h * 0.35 + hash2(col, row + e.seed) * 0.25;
        const rel = a * 1.6 - thr;
        const px = ox + col, py = oy + row;
        if (rel < 0) {
          const xr = hash2(frame, row + e.id) > 0.6;
          const c = xr ? ch === "o" ? [1.2, 1.5, 3] : [0.02, 0.02, 0.06] : [base[0] * 1.6, base[1] * 1.6, base[2] * 2];
          fb.blend(px, py, c[0], c[1], c[2], 1);
        } else {
          if (rel > 0.4) return;
          const dir = hash2(row, e.seed) > 0.5 ? 1 : -1;
          const qx = px + dir * (rel * 260 + hash2(col, row) * 20);
          const len = 2 + rel * 12;
          const c = voltCol(0.95 - rel * 1.2);
          for (let k = 0; k < len; k++) {
            const f = (1 - k / len) * (1 - rel / 0.4);
            fb.add(qx - dir * k, py, c[0] * f, c[1] * f, c[2] * f, 1);
          }
        }
      });
      return;
    }
    case "verdant": {
      const D = 1.7, u = age / D;
      if (u > 1) return;
      const sink = easeIn(u, 2.2) * s.h;
      const k = clamp(age * 1.6);
      eachPixel(e, (col, row, _ch, base) => {
        const py = oy + row + sink;
        if (py > e.y + 0.5) return;
        let r = lerp(base[0], 0.06, k), g = lerp(base[1], 0.26, k), b = lerp(base[2], 0.07, k);
        if (hash2(col + e.seed, row) > 0.82) {
          g += 0.35 * k * (0.5 + 0.5 * Math.sin(age * 8 + col));
          r += 0.1 * k;
        }
        fb.blend(ox + col, py, r, g, b, 1);
      });
      return;
    }
    case "astral": {
      const yy = fy0 - 2;
      if (age < 0.2) {
        const rs = (row) => hash2(row + frame * 7, e.id) > 0.5 ? Math.round((hash2(row, frame) - 0.5) * 14) : 0;
        drawSprite(fb, e, { ox: -3, additive: true, alpha: 0.9, rowShift: rs, tint: () => [1, 0.05, 0.4] });
        drawSprite(fb, e, { ox: 3, additive: true, alpha: 0.9, rowShift: rs, tint: () => [0.15, 0.4, 1.3] });
        drawSprite(fb, e, { rowShift: rs, tint: (b) => [b[0] + 0.5, b[1] + 0.3, b[2] + 0.8] });
        return;
      }
      if (age < 0.42) {
        const k = (age - 0.2) / 0.22;
        drawSprite(fb, e, {
          scaleX: lerp(1, 1.9, k),
          scaleY: lerp(1, 0.07, easeIn(k, 2)),
          tint: (b) => [b[0] + 1.4 * k, b[1] + 0.8 * k, b[2] + 2 * k]
        });
        return;
      }
      if (age < 0.58) {
        const k = (age - 0.42) / 0.16;
        const L = lerp(s.w * 0.95, 0, easeIn(k, 2));
        for (let x = -L; x <= L; x++) fb.add(e.x + x, yy, 2.4, 1.6, 3, 1);
        glow(fb, e.x, yy, 6, [1.4, 0.8, 2.2], 0.6);
        return;
      }
      if (age < 0.8) {
        const k = (age - 0.58) / 0.22;
        glow(fb, e.x, yy, 4 * (1 - k) + 1, [2, 1.3, 2.8], 1.6 * (1 - k));
        for (let d = 1; d < 7 * (1 - k); d++) {
          fb.add(e.x + d, yy, 1.5, 1, 2, 1 - k);
          fb.add(e.x - d, yy, 1.5, 1, 2, 1 - k);
          fb.add(e.x, yy + d * 0.6, 1.5, 1, 2, 1 - k);
          fb.add(e.x, yy - d * 0.6, 1.5, 1, 2, 1 - k);
        }
      }
      return;
    }
    case "cut": {
      const a = age;
      if (a > 1.7) return;
      const ca = Math.cos(e.cutAng), sa = Math.sin(e.cutAng);
      const sep = easeOut(clamp(a / 0.55), 3);
      eachPixel(e, (col, row, _ch, base) => {
        const lx = col - s.w / 2 + 0.5, ly = row - s.h * 0.55;
        const dist = -lx * sa + ly * ca;
        const side = dist >= 0 ? 1 : -1;
        const slide = side * sep * 7;
        let qx = ox + col + ca * slide - sa * side * sep * 2;
        let qy = oy + row + sa * slide + ca * side * sep * 2 + (side > 0 ? sep * 2 : 0);
        const local = (a - 0.6) / 0.9 - hash2(col + e.seed, row) * 0.8;
        if (local > 0) {
          if (local > 0.35) return;
          qy -= local * 24;
          qx += (hash2(row, col) - 0.5) * local * 20;
          if (dith(qx, qy, 1 - local / 0.35)) fb.add(qx, qy, 0.5, 0.18, 0.06, 1);
          return;
        }
        const ch = clamp(a * 1.4);
        let r = base[0] * (1 - ch * 0.8), g = base[1] * (1 - ch * 0.8), b = base[2] * (1 - ch * 0.8);
        if (Math.abs(dist) < 1.4) {
          const fc = fireCol(1 - a * 0.7);
          r += fc[0];
          g += fc[1];
          b += fc[2];
        }
        fb.blend(qx, qy, r, g, b, 1);
      });
      return;
    }
  }
}
function drawResidue(fb, e, W3) {
  const age = W3.simT - e.deathT;
  const t = W3.simT;
  const ellipse = (rx, ry, m) => {
    for (let y = -Math.ceil(ry); y <= Math.ceil(ry); y++)
      for (let x = -Math.ceil(rx); x <= Math.ceil(rx); x++) {
        const d = Math.hypot(x / rx, y / ry);
        if (d < 1) fb.mul(e.x + x, e.y + y, lerp(m, 1, d * d));
      }
  };
  switch (e.kind) {
    case "fire":
    case "cut": {
      if (age < 0.7) return;
      const k = clamp((age - 0.7) * 2);
      ellipse(7, 2.6, lerp(1, 0.45, k));
      for (let i = 0; i < 16; i++) {
        const x = e.x + (hash2(i, e.seed) - 0.5) * 12, y = e.y + (hash2(e.seed, i) - 0.5) * 4;
        fb.add(x, y, 0.07, 0.06, 0.06, k);
        const fl = vnoise(i * 3.1, t * 2.5);
        if (fl > 0.6) {
          const c = fireCol((fl - 0.6) * 1.6 * Math.max(0, 1 - (age - 0.7) / 6));
          fb.add(x, y, c[0], c[1], c[2], 1);
        }
      }
      return;
    }
    case "water": {
      const k = clamp(age * 3) * Math.max(0, 1 - age / 5);
      ellipse(9, 3.4, lerp(1, 0.6, k));
      for (let i = 0; i < 18; i++) {
        const a = i / 18 * TAU;
        fb.add(e.x + Math.cos(a) * 9, e.y + Math.sin(a) * 3.4, 0.05, 0.12, 0.22, k * 0.8);
      }
      return;
    }
    case "ice": {
      if (age < 0.6) return;
      const k = Math.max(0, 1 - (age - 0.6) / 3.5);
      for (let i = 0; i < 12; i++) {
        const x = e.x + (hash2(i, e.seed + 1) - 0.5) * 34, y = e.y + (hash2(e.seed + 1, i) - 0.5) * 12;
        if (dith(x, y, k)) fb.add(x, y, 0.35, 0.6, 0.95, 1);
      }
      return;
    }
    case "volt": {
      const k = Math.max(0, 1 - age / 5);
      ellipse(8, 3, lerp(1, 0.5, k));
      if (age < 3 && hash2(Math.floor(W3.clock * 20), e.id) > 0.7) {
        const a = hash2(Math.floor(W3.clock * 20), 3) * TAU;
        streak(fb, e.x, e.y, e.x + Math.cos(a) * 5, e.y + Math.sin(a) * 2, 0.8, 0.3, [0.8, 1.1, 2.6], k);
      }
      return;
    }
    case "verdant": {
      for (let i = 0; i < 6; i++) {
        const g = backOut(clamp((age - 0.6 - i * 0.12) * 2.2), 2.4);
        if (g <= 0) continue;
        const x = e.x + (hash2(i, e.seed) - 0.5) * 14, y = e.y + (hash2(e.seed, i) - 0.5) * 4;
        const hgt = (3 + hash2(i, 9) * 4) * g;
        for (let k = 0; k < hgt; k++) fb.blend(x + Math.sin(t * 2 + i) * k * 0.08, y - k, 0.05, 0.25, 0.06, 1);
        const fx = x + Math.sin(t * 2 + i) * hgt * 0.08, fy = y - hgt;
        const pc = i % 2 ? [1.6, 0.55, 0.9] : [1.8, 1.4, 0.45];
        for (const [dx, dy] of [
          [0, -1],
          [1, 0],
          [-1, 0],
          [0, 1]
        ])
          fb.blend(fx + dx * g, fy + dy * g, pc[0] * 0.5, pc[1] * 0.5, pc[2] * 0.5, 1);
        fb.add(fx, fy, 2, 1.8, 0.8, 1);
      }
      return;
    }
    case "astral": {
      if (age < 0.8 || age > 1.9) return;
      if (hash2(Math.floor(W3.clock * 15), e.id) < 0.25) return;
      for (let y = 0; y < 5; y++)
        for (let x = 0; x < 5; x++) {
          const sx = clamp(Math.round(e.x + x + 9), 0, fb.W - 1), sy = clamp(Math.round(e.y + y - 14), 0, fb.H - 1);
          const i = (sy * fb.W + sx) * 3;
          const dx = Math.round(e.x - 2 + x), dy = Math.round(e.y - 4 + y);
          fb.blend(dx, dy, fb.bg[i] * 1.6 + 0.04, fb.bg[i + 1] * 1.3, fb.bg[i + 2] * 1.9 + 0.06, 1);
        }
      return;
    }
  }
}
function drawFx(fb, W3) {
  for (const p of W3.fx) {
    const l = p.life / p.max;
    const x = p.x, y = p.y - p.z;
    switch (p.kind) {
      case 0: {
        const c = fireCol(l * 0.9);
        fb.add(x, y, c[0], c[1], c[2], 1);
        break;
      }
      case 1:
        if (dith(x, y, l * 0.8)) fb.add(x, y, 0.07, 0.065, 0.075, 1);
        break;
      case 2: {
        const c = voltCol(0.6 + l * 0.4);
        fb.add(x, y, c[0], c[1], c[2], l);
        break;
      }
      case 3: {
        const tw = 0.5 + 0.5 * Math.sin(W3.clock * 9 + p.seed);
        fb.add(x, y, 0.25 * tw, 1 * tw, 0.7 * tw, l);
        break;
      }
      case 4:
        fb.add(x, y, 0.3, 0.7, 1.4, l);
        break;
      case 5:
        fb.add(x, y, 0.8, 1.2, 1.7, l);
        break;
    }
  }
  for (const z of W3.zaps) {
    const k = z.life / z.max;
    const d = Math.hypot(z.x1 - z.x0, z.y1 - z.y0);
    const pts = boltPath(z.x0, z.y0, z.x1, z.y1, d * 0.3, z.seed * 131 + Math.floor(W3.clock * 30) * 7, 4);
    for (let i = 0; i < pts.length - 1; i++) {
      streak(fb, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, 1.4, 1.4, [z.tint[0] * 0.4, z.tint[1] * 0.4, z.tint[2] * 0.4], k);
      line(fb, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, [2.6, 2.8, 3.2], k);
    }
  }
}
function drawNum(fb, x, y, val, col, scale, alpha) {
  const str = String(val);
  const w = str.length * 4 * scale - scale;
  const x0 = Math.round(x - w / 2), y0 = Math.round(y);
  for (let pass = 0; pass < 2; pass++)
    for (let d = 0; d < str.length; d++) {
      const g = DIG[str.charCodeAt(d) - 48];
      if (!g) continue;
      for (let py = 0; py < 5; py++)
        for (let px = 0; px < 3; px++) {
          if (g[py * 3 + px] !== "1") continue;
          for (let sy = 0; sy < scale; sy++)
            for (let sx = 0; sx < scale; sx++) {
              const X = x0 + d * 4 * scale + px * scale + sx, Y = y0 + py * scale + sy;
              if (!dith(X, Y, alpha)) continue;
              if (pass === 0) {
                for (const [ox, oy] of [
                  [1, 0],
                  [-1, 0],
                  [0, 1],
                  [0, -1],
                  [1, 1]
                ])
                  fb.blend(X + ox, Y + oy, 5e-3, 4e-3, 0.01, 1);
              } else fb.blend(X, Y, col[0], col[1], col[2], 1);
            }
        }
    }
}
function renderOverlay(fb, W3) {
  for (const e of W3.enemies) {
    if (e.dead || e.hpShow <= 0) continue;
    const s = e.spr;
    const w = e.type === "brute" ? 22 : 14;
    const y = Math.round(e.y - e.z - s.h * (1 + e.sq) - 5);
    const x0 = Math.round(e.x - w / 2);
    const a = clamp(e.hpShow / 0.5);
    for (let x = -1; x <= w; x++)
      for (let yy = -1; yy <= 1; yy++) if (dith(x0 + x, y + yy, a)) fb.blend(x0 + x, y + yy, 8e-3, 5e-3, 0.012, 1);
    const hpW = Math.round(Math.max(0, e.hp) / e.maxHp * w);
    const lagW = Math.round(Math.max(0, e.lag) / e.maxHp * w);
    for (let x = 0; x < lagW; x++) if (dith(x0 + x, y, a)) fb.blend(x0 + x, y, x < hpW ? 0.75 : 0.7, x < hpW ? 0.1 : 0.6, x < hpW ? 0.08 : 0.5, 1);
  }
  for (const p of W3.popups) {
    const a = p.age;
    const rise = easeOut(Math.min(1, a / 0.22), 3) * 10 + a * 6;
    const scale = p.big ? 2 : 1;
    const m = Math.max(p.col[0], p.col[1], p.col[2]);
    const col = a < 0.08 ? [0.62, 0.62, 0.62] : [p.col[0] / m * 0.55 + 0.18, p.col[1] / m * 0.55 + 0.18, p.col[2] / m * 0.55 + 0.18];
    drawNum(fb, p.x, p.y - rise, p.val, col, scale, 1 - clamp((a - 0.6) / 0.4));
  }
}
var OUT, SPR, FORMATION, B4, dith, fireCol, voltCol, empty, DIG;
var init_enemies = __esm({
  "src/engine/enemies.ts"() {
    "use strict";
    init_math();
    init_draw();
    init_arena();
    init_world();
    OUT = [6e-3, 4e-3, 0.01];
    SPR = {
      brute: mk(
        [
          ".h........",
          ".hh...oooo",
          "..hhoo3333",
          "...ho33322",
          "...o3e2222",
          "..oo322222",
          ".o33o32222",
          "o332o32222",
          "o32oo32222",
          "o2o.o32222",
          ".oo.o32222",
          ".....o3222",
          "....o3221o",
          "....o221o.",
          "....o11o..",
          "....ooo..."
        ],
        { o: OUT, "1": [0.06, 0.075, 0.1], "2": [0.13, 0.15, 0.2], "3": [0.26, 0.28, 0.33], h: [0.6, 0.53, 0.42], e: [2.4, 0.45, 0.2] },
        2.6,
        260
      ),
      husk: mk(
        [
          "....ooo",
          "...o333",
          "..o3322",
          "..o3e22",
          "..o3222",
          "...o322",
          "..oo222",
          ".o3o222",
          "o32o222",
          "o2.o222",
          "...o221",
          "...o21o",
          "...o1o.",
          "...oo.."
        ],
        { o: OUT, "1": [0.1, 0.065, 0.09], "2": [0.19, 0.125, 0.16], "3": [0.32, 0.22, 0.25], h: [0.55, 0.47, 0.38], e: [2.4, 1.6, 0.3] },
        1,
        100
      ),
      crawler: mk(
        ["o..o..oo", ".o.o.o33", "..o.o333", "oo.o3e32", "..oo3222", ".o.o2222", "o...oooo"],
        { o: OUT, "1": [0.06, 0.1, 0.065], "2": [0.12, 0.19, 0.11], "3": [0.23, 0.32, 0.16], h: [0.5, 0.5, 0.38], e: [1.2, 2.4, 0.4] },
        0.7,
        70
      )
    };
    FORMATION = [
      ["brute", 228, 136],
      ["husk", 316, 90],
      ["crawler", 348, 165],
      ["husk", 272, 115],
      ["crawler", 190, 82],
      ["husk", 258, 194],
      ["crawler", 166, 166]
    ];
    B4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
    dith = (x, y, a) => a > (B4[((y | 0) & 3) << 2 | (x | 0) & 3] + 0.5) / 16;
    fireCol = (h) => R("fire", Math.floor(clamp(h) * 9) / 9);
    voltCol = (h) => R("volt", Math.floor(clamp(h) * 8) / 8);
    empty = (ch) => !ch || ch === " " || ch === ".";
    DIG = [
      "111101101101111",
      "010110010010111",
      "111001111100111",
      "111001111001111",
      "101101111001001",
      "111100111001111",
      "111100111101111",
      "111001001010010",
      "111101111101111",
      "111101111001111"
    ];
  }
});

// src/engine/world.ts
function applyStatus(e, el, amt) {
  switch (el) {
    case "fire":
      e.burn = Math.max(e.burn, amt);
      break;
    case "water":
      e.wet = Math.max(e.wet, amt);
      break;
    case "ice":
      e.freeze = Math.max(e.freeze, amt);
      break;
    case "volt":
      e.shock = Math.max(e.shock, amt);
      break;
    case "verdant":
      e.root = Math.max(e.root, amt);
      break;
    case "astral":
      e.warp = Math.max(e.warp, amt);
      break;
  }
}
var ELEMENT_TINT, World, W;
var init_world = __esm({
  "src/engine/world.ts"() {
    "use strict";
    init_math();
    init_arena();
    init_enemies();
    ELEMENT_TINT = {
      fire: [2.2, 0.85, 0.22],
      water: [0.45, 1.25, 2.2],
      ice: [1.1, 1.75, 2.5],
      volt: [1.1, 1.35, 2.9],
      verdant: [0.8, 2, 0.65],
      astral: [1.8, 0.85, 2.6]
    };
    World = class {
      simT = 0;
      clock = 0;
      hitstop = 0;
      stopDelay = 0;
      pendingStop = 0;
      rampFrom = 1;
      rampDur = 0;
      rampAge = 1;
      trauma = 0;
      kx = 0;
      ky = 0;
      kvx = 0;
      kvy = 0;
      zoomS = 0;
      zoomV = 0;
      focusX = VIEW_W / 2;
      focusY = VIEW_H / 2;
      focusAmt = 0;
      focusTarget = 0;
      focusHold = 0;
      inhaleAmt = 0;
      inhaleTarget = 0;
      inhaleHold = 0;
      impactFrames = 0;
      impactTint = [1, 1, 1];
      chroma = 0;
      casterKick = 0;
      casterKickV = 0;
      waves = [];
      popups = [];
      fx = [];
      zaps = [];
      enemies = [];
      fired = /* @__PURE__ */ new Set();
      cds = /* @__PURE__ */ new Map();
      seedN = 1;
      reset() {
        this.simT = 0;
        this.clock = 0;
        this.hitstop = 0;
        this.stopDelay = 0;
        this.pendingStop = 0;
        this.rampAge = 1;
        this.rampDur = 0;
        this.trauma = 0;
        this.kx = this.ky = this.kvx = this.kvy = 0;
        this.zoomS = this.zoomV = 0;
        this.focusAmt = this.focusTarget = this.focusHold = 0;
        this.inhaleAmt = this.inhaleTarget = this.inhaleHold = 0;
        this.impactFrames = 0;
        this.chroma = 0;
        this.casterKick = this.casterKickV = 0;
        this.waves = [];
        this.popups = [];
        this.fx = [];
        this.zaps = [];
        this.fired.clear();
        this.cds.clear();
        this.seedN = 1;
        this.enemies = makeFormation();
      }
      rand() {
        return hash2(this.seedN++, 9173);
      }
      // ---------------------------------------------------------------- timing
      once(key, cond = true) {
        if (!cond || this.fired.has(key)) return false;
        this.fired.add(key);
        return true;
      }
      timeScale() {
        if (this.stopDelay > 0) return 1;
        if (this.rampDur <= 0 || this.rampAge >= this.rampDur) return 1;
        const u = this.rampAge / this.rampDur;
        return lerp(this.rampFrom, 1, u * u);
      }
      /**
       * Hit-stop. With a delay, the release keeps exploding at full speed for a
       * few frames (under the impact frames) and the freeze then holds on the
       * first big drawing of the explosion, not on an empty onset frame.
       */
      freeze(sec, delay = 0) {
        if (delay > 0) {
          this.pendingStop = Math.max(this.pendingStop, sec);
          if (this.stopDelay <= 0) this.stopDelay = delay;
        } else this.hitstop = Math.max(this.hitstop, sec);
      }
      // ---------------------------------------------------------------- camera
      shake(a) {
        this.trauma = clamp(this.trauma + a, 0, 1);
      }
      /** tiny per-frame tremor during tension */
      tremor(dt, k) {
        this.trauma = clamp(Math.max(this.trauma, k), 0, 1);
        void dt;
      }
      kick(vx, vy) {
        this.kvx += vx;
        this.kvy += vy;
      }
      punch(z) {
        this.zoomV += z;
      }
      focus(x, y, amt) {
        this.focusX = x;
        this.focusY = y;
        this.focusTarget = clamp(amt, 0, 1);
        this.focusHold = 0.08;
      }
      inhale(k) {
        this.inhaleTarget = clamp(k, 0, 1);
        this.inhaleHold = 0.08;
      }
      camera() {
        const s = clamp(this.trauma) ** 2;
        const c = this.clock;
        const n1 = (vnoise(c * 26, 1.3) - 0.5) * 2;
        const n2 = (vnoise(c * 26, 7.7) - 0.5) * 2;
        const n3 = (vnoise(c * 19, 13.1) - 0.5) * 2;
        const fa = this.focusAmt;
        return {
          x: 10 * s * n1 + this.kx + (VIEW_W / 2 - this.focusX) * fa * 0.3,
          y: 7 * s * n2 + this.ky + (VIEW_H / 2 - this.focusY) * fa * 0.3,
          rot: 0.03 * s * n3,
          zoom: 1 + this.zoomS + fa * 0.07
        };
      }
      /** real-time tick: runs during hit-stop too (shake keeps going) */
      tick(dt) {
        this.clock += dt;
        this.trauma = Math.max(0, this.trauma - dt * 1.35);
        this.kvx += (-260 * this.kx - 16 * this.kvx) * dt;
        this.kvy += (-260 * this.ky - 16 * this.kvy) * dt;
        this.kx += this.kvx * dt;
        this.ky += this.kvy * dt;
        this.zoomV += (-300 * this.zoomS - 18 * this.zoomV) * dt;
        this.zoomS += this.zoomV * dt;
        this.casterKickV += (-320 * this.casterKick - 18 * this.casterKickV) * dt;
        this.casterKick += this.casterKickV * dt;
        this.focusHold -= dt;
        if (this.focusHold <= 0) this.focusTarget = 0;
        const fr = this.focusTarget > this.focusAmt ? 2.4 : 5;
        this.focusAmt += (this.focusTarget - this.focusAmt) * Math.min(1, dt * fr);
        this.inhaleHold -= dt;
        if (this.inhaleHold <= 0) this.inhaleTarget = 0;
        const ir = this.inhaleTarget > this.inhaleAmt ? 6 : 9;
        this.inhaleAmt += (this.inhaleTarget - this.inhaleAmt) * Math.min(1, dt * ir);
        if (this.impactFrames > 0) this.impactFrames--;
        this.chroma *= Math.exp(-dt * 7);
        if (this.stopDelay > 0) {
          this.stopDelay -= dt;
          if (this.stopDelay <= 0) {
            this.hitstop = Math.max(this.hitstop, this.pendingStop);
            this.pendingStop = 0;
          }
        }
        if (this.hitstop <= 0 && this.stopDelay <= 0) this.rampAge += dt;
      }
      /** simulation update (frozen during hit-stop, scaled by speed ramp) */
      update(dt) {
        this.simT += dt;
        for (const w of this.waves) w.age += dt;
        this.waves = this.waves.filter((w) => w.age < w.life);
        for (const e of this.enemies) updateEnemy(e, dt, this);
        for (const p of this.popups) p.age += dt;
        this.popups = this.popups.filter((p) => p.age < 1);
        for (const p of this.fx) {
          p.life -= dt;
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.z += p.vz * dt;
          if (p.kind === 0 || p.kind === 3) {
            p.vy -= 18 * dt;
            p.vx *= Math.exp(-1.4 * dt);
          } else if (p.kind === 1) {
            p.vx *= Math.exp(-3 * dt);
            p.vy *= Math.exp(-3 * dt);
          } else {
            p.vz -= 320 * dt;
            if (p.z < 0) {
              p.z = 0;
              p.vz = -p.vz * 0.3;
              p.vx *= 0.5;
              p.vy *= 0.5;
            }
          }
        }
        this.fx = this.fx.filter((p) => p.life > 0);
        for (const z of this.zaps) z.life -= dt;
        this.zaps = this.zaps.filter((z) => z.life > 0);
      }
      // ---------------------------------------------------------------- beats
      /** TELL: the caster's hand snaps, a tiny freeze, a small refraction */
      castSnap(el, k = 1, x = 111, y = 142) {
        this.casterKickV -= 70 * k;
        this.shake(0.12 * k);
        this.freeze(0.03 * k);
        this.chroma = Math.max(this.chroma, 0.8 * k);
        this.wave(x, y, 1.6 * k, 160, 6, 0.35, el);
        this.punch(0.25 * k);
      }
      /** LAST BEAT */
      settle(k = 1) {
        this.shake(0.07 * k);
        this.punch(-0.2 * k);
      }
      wave(x, y, amp, speed, width, life, el, squash = 1.45) {
        this.waves.push({ x, y, age: 0, speed, width, amp, life, squash, tint: ELEMENT_TINT[el] });
      }
      zap(x0, y0, x1, y1, life, el = "volt") {
        this.zaps.push({ x0, y0, x1, y1, life, max: life, seed: this.seedN++, tint: ELEMENT_TINT[el] });
      }
      emit(p) {
        if (this.fx.length > 900) return;
        this.fx.push({ ...p, max: p.life, seed: this.seedN++ });
      }
      /** the central STRIKE call */
      impact(x, y, o) {
        const f = o.force ?? 1;
        this.freeze(o.hitstop ?? 0.03 + f * 0.09, f >= 0.6 ? 0.05 : 0);
        this.rampFrom = o.ramp ?? clamp(0.62 - f * 0.18, 0.3, 0.9);
        this.rampDur = 0.1 + f * 0.12;
        this.rampAge = 0;
        this.shake(o.shake ?? 0.2 + f * 0.4);
        const dx = VIEW_W / 2 - x, dy = VIEW_H / 2 - y;
        const dl = Math.hypot(dx, dy) || 1;
        this.kick(dx / dl * f * 110 + (o.dirx ?? 0) * f * 60, dy / dl * f * 80 + (o.diry ?? 0) * f * 60);
        this.punch(o.zoom ?? f * 0.9);
        if (o.frame ?? f >= 1) {
          this.impactFrames = 3;
          this.impactTint = ELEMENT_TINT[o.element];
        }
        this.chroma = Math.max(this.chroma, 1 + f * 2.2);
        const wa = o.wave ?? 1;
        if (wa > 0) this.wave(x, y, wa * (2 + f * 4), 230 + f * 160, 8 + f * 8, 0.55 + f * 0.3, o.element);
        const R2 = o.radius ?? 80;
        if (R2 > 0 && (o.dmg ?? 0) > 0)
          for (const e of this.enemies) {
            if (e.dead) continue;
            const ex = e.x - x, ey = (e.y - y) * 1.3;
            const d = Math.hypot(ex, ey);
            if (d > R2 + 6) continue;
            const fall = 1 - Math.pow(d / (R2 + 6), 2) * 0.7;
            const nd = d || 1;
            this.hit(
              e,
              {
                ...o,
                dmg: (o.dmg ?? 0) * fall,
                force: f * fall,
                dirx: o.dirx ?? ex / nd,
                diry: o.diry ?? ey / nd
              },
              false
            );
          }
        for (let i = 0; i < 10 + f * 16; i++) {
          const a = this.rand() * Math.PI * 2;
          const sp = 30 + this.rand() * 120 * f;
          this.emit({ x, y, z: 0, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.6, vz: 0, life: 0.5 + this.rand() * 0.7, kind: 1 });
        }
      }
      /** a strike without damage — a beat for structure / tells */
      thump(x, y, force, el, extra = {}) {
        this.impact(x, y, { element: el, force, radius: 0, dmg: 0, frame: false, ...extra });
      }
      hit(e, o, solo = true) {
        if (e.dead) return;
        if (solo) {
          const f = o.force ?? 0.4;
          this.freeze(o.hitstop ?? 0.02 + f * 0.04);
          this.shake(0.05 + f * 0.12);
        }
        damageEnemy(e, o, this);
      }
      sweep(key, x, y, r, o, cd = 0.4) {
        for (const e of this.enemies) {
          if (e.dead) continue;
          if (Math.hypot(e.x - x, e.y - 6 - y) > r + 6) continue;
          const k = key + ":" + e.id;
          const last = this.cds.get(k);
          if (last !== void 0 && this.simT - last < cd) continue;
          this.cds.set(k, this.simT);
          this.hit(e, o, true);
        }
      }
      lineHit(key, x0, y0, x1, y1, w, o, solo = false) {
        const dx = x1 - x0, dy = y1 - y0;
        const l2 = dx * dx + dy * dy || 1;
        const hits = [];
        for (const e of this.enemies) {
          if (e.dead) continue;
          const k = key + ":" + e.id;
          if (this.cds.has(k)) continue;
          const py = e.y - 5;
          const u = clamp(((e.x - x0) * dx + (py - y0) * dy) / l2);
          const qx = x0 + dx * u, qy = y0 + dy * u;
          const d = Math.hypot(e.x - qx, py - qy);
          if (d > w + 5) continue;
          this.cds.set(k, this.simT);
          let nx = -dy, ny = dx;
          const nl = Math.hypot(nx, ny) || 1;
          nx /= nl;
          ny /= nl;
          const side = (e.x - qx) * nx + (py - qy) * ny >= 0 ? 1 : -1;
          this.hit(e, { dirx: nx * side, diry: ny * side, ...o }, solo);
          hits.push(e);
        }
        return hits;
      }
      pull(x, y, R2, str, swirl, dt, el) {
        for (const e of this.enemies) {
          if (e.dead) continue;
          const dx = x - e.x, dy = y - e.y;
          const d = Math.hypot(dx, dy) || 1;
          if (d > R2) continue;
          const f = (1 - d / R2) * (e.root > 0.4 ? 0.25 : 1);
          e.vx += (dx / d * str - dy / d * swirl) * f * dt / Math.sqrt(e.mass);
          e.vy += (dy / d * str + dx / d * swirl) * f * dt / Math.sqrt(e.mass);
          e.stagger = Math.max(e.stagger, 0.1);
          if (el === "astral") e.warp = Math.min(1, e.warp + f * dt * 2);
          if (el === "water") e.wet = 1;
        }
      }
      still(dt) {
        for (const e of this.enemies) {
          e.vx *= Math.exp(-30 * dt);
          e.vy *= Math.exp(-30 * dt);
        }
      }
      status(x, y, R2, el, amt) {
        for (const e of this.enemies) {
          if (e.dead) continue;
          if (Math.hypot(e.x - x, (e.y - y) * 1.2) > R2) continue;
          applyStatus(e, el, amt);
        }
      }
      kill(e, kind) {
        killEnemy(e, kind, this);
      }
      alive() {
        return this.enemies.filter((e) => !e.dead);
      }
      nearest(x, y) {
        let best = null, bd = 1e9;
        for (const e of this.enemies) {
          const d = Math.hypot(e.x - x, e.y - y);
          if (d < bd) {
            bd = d;
            best = e;
          }
        }
        return best;
      }
      popup(x, y, val, el, big) {
        this.popups.push({ x, y, val, age: 0, col: ELEMENT_TINT[el], big });
      }
    };
    W = new World();
  }
});

// src/spells/choreo.ts
var HAND, chest, CHOREO;
var init_choreo = __esm({
  "src/spells/choreo.ts"() {
    "use strict";
    init_world();
    init_arena();
    init_math();
    HAND = { x: CASTER.x + 7, y: CASTER.y - 8 };
    chest = (e) => ({ x: e.x, y: e.y - e.z - e.spr.h * 0.55 });
    CHOREO = {
      // ===================================================================== PYRE
      1: (_s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("fire");
        if (t > 0.3 && t < 3.92) W.focus(ARENA_C.x, ARENA_C.y, 0.2 + 0.8 * seg(t, 1, 3.85));
        if (W.once("lock", t >= 1.55)) {
          W.shake(0.14);
          W.punch(0.35);
          W.wave(ARENA_C.x, ARENA_C.y, 1.5, 200, 6, 0.4, "fire");
        }
        if (t > 3 && t < 3.93) {
          const k = seg(t, 3, 3.86);
          W.inhale(k);
          W.tremor(dt, 0.18 * k);
          W.pull(ARENA_C.x, ARENA_C.y, 170, 260 * k, 40 * k, dt);
        }
        if (W.once("strike", t >= 3.95))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "fire", force: 1.3, radius: 140, dmg: 85, hitstop: 0.17, lift: 0.9 });
        if (W.once("petals", t >= 4.3))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "fire", force: 0.45, radius: 200, dmg: 16, hitstop: 0, frame: false, wave: 0.7, shake: 0.12, zoom: 0.2 });
        if (W.once("end", t >= 6.1)) W.settle();
      },
      2: (s, t) => {
        if (W.once("tell", t > 0.01)) W.castSnap("fire");
        if (W.once("crack", t >= 0.38)) W.thump(CASTER.x + 10, CASTER.y + 3, 0.5, "fire", { hitstop: 0.06 });
        const h = s.head;
        if (t > 0.9 && s.impactT < 0) {
          const sp = t > 4.55 ? 1 : 0.55;
          W.sweep("head", h.x, h.y, 13, { element: "fire", dmg: 9, force: sp, dirx: Math.cos(h.a), diry: Math.sin(h.a), status: 0.45, lift: 0.4 }, 0.6);
          for (const k of [50, 120, 190]) {
            const p = s.hist[k];
            if (p) W.sweep("body" + k, p.x, p.y, 8, { element: "fire", dmg: 4, force: 0.25, dirx: 0, diry: -1, status: 0.3 }, 0.5);
          }
        }
        if (t > 4.2 && s.impactT < 0) W.focus(ANCHORS[0].x, ANCHORS[0].y, seg(t, 4.2, 4.7));
        if (s.impactT > 0 && W.once("bite"))
          W.impact(ANCHORS[0].x, ANCHORS[0].y, { element: "fire", force: 1.4, radius: 85, dmg: 120, hitstop: 0.18, lift: 1 });
        if (W.once("end", t >= 6.5)) W.settle();
      },
      3: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("fire", 0.8);
        s.ms.forEach((m, i) => {
          const u = seg(t, m.t0, m.t0 + m.dur);
          if (u > 0.6 && u < 1) W.tremor(dt, 0.05 + m.size * 6e-3);
          if (W.once("m" + i, m.hit === 1))
            W.impact(m.tx, m.ty, {
              element: "fire",
              force: 0.35 + m.size / 24,
              radius: m.size * 4.2,
              dmg: m.size * 3,
              hitstop: 0.03 + m.size * 5e-3,
              frame: m.size >= 15,
              lift: 0.7
            });
        });
        if (t > 4.9 && t < 5.45) {
          W.inhale(seg(t, 4.9, 5.4) * 0.8);
          W.focus(ARENA_C.x, ARENA_C.y, seg(t, 4.9, 5.4) * 0.6);
        }
        if (W.once("sigil", t >= 5.45))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "fire", force: 1.15, radius: 210, dmg: 40, hitstop: 0.14, frame: true, lift: 0.6 });
        if (W.once("end", t >= 6.6)) W.settle();
      },
      4: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("fire", 0.3);
        const cut = s.CUT_T;
        if (t > 0.2 && t < cut) {
          W.focus(208, s.cutY, 0.15 + 0.85 * seg(t, 1.2, cut));
          W.inhale(seg(t, 2, cut) * 0.9);
          if (t > 2.3) W.tremor(dt, 0.12 * seg(t, 2.3, cut));
          W.pull(208, s.cutY, 140, 40 * seg(t, 0.5, cut), 0, dt);
        }
        if (W.once("cut", t >= cut)) {
          const ca = Math.cos(s.cutA), sa = Math.sin(s.cutA);
          W.impact(208, s.cutY, { element: "fire", force: 1.6, radius: 0, hitstop: 0.24, frame: true, wave: 0.4, shake: 0.55 });
          W.kick(-sa * 160, ca * 160);
          W.lineHit("blade", 18, s.lineY(18), 400, s.lineY(400), 9, { element: "fire", dmg: 150, force: 0.9, cut: s.cutA, status: 0.9, lift: 0.2 });
          void ca;
        }
        s.sections.forEach((sec, i) => {
          if (W.once("sec" + i, t >= cut + 0.12 + sec.delay / 1.5 + 0.25)) {
            const x = (sec.x0 + sec.x1) / 2;
            W.impact(x, s.lineY(x), { element: "fire", force: 0.25 + sec.depth * 0.25, radius: 34, dmg: 14, hitstop: 0.012, frame: false, wave: 0.6, shake: 0.08, zoom: 0.1, lift: 0.6 });
          }
        });
        if (W.once("end", t >= 6.6)) W.settle(0.6);
      },
      // ===================================================================== TIDE
      5: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("water");
        if (t > 0.8 && t < 4.3) {
          W.focus(ARENA_C.x, ARENA_C.y, 0.2 + 0.6 * seg(t, 0.8, 4.2));
          W.pull(ARENA_C.x, ARENA_C.y, 90 * seg(t, 0.8, 3.6) + 20, -60, 30, dt, "water");
        }
        if (t >= 4.3 && t < s.BURST) {
          W.inhale(0.7);
          W.still(dt);
          W.focus(ARENA_C.x, ARENA_C.y, 1);
        }
        if (W.once("strike", t >= s.BURST))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "water", force: 1.25, radius: 150, dmg: 75, hitstop: 0.16, lift: 1.1 });
        if (W.once("end", t >= 6.4)) W.settle();
      },
      6: (s, t) => {
        if (W.once("tell", t > 0.01)) W.castSnap("water");
        s.strokes.forEach((st, si) => {
          const u = seg(t, st.t0, st.t0 + st.dur);
          if (W.once("stk" + si, u > 0)) {
            W.shake(0.06);
            W.casterKickV -= 30;
          }
          if (u > 0 && u < 1) {
            const p = catmull(st.ctrl, u), q = catmull(st.ctrl, Math.max(0, u - 0.04));
            const dx = p.x - q.x, dy = p.y - q.y, dl = Math.hypot(dx, dy) || 1;
            W.sweep("st" + si, p.x, p.y, 9, { element: "water", dmg: 7, force: 0.45, dirx: dx / dl, diry: dy / dl }, 1);
          }
        });
        if (t > 4.75 && t < s.WAVE) {
          W.inhale(seg(t, 4.75, s.WAVE) * 0.6);
          W.focus(ARENA_C.x, ARENA_C.y, 0.6);
        }
        if (W.once("strike", t >= s.WAVE)) W.thump(ARENA_C.x, ARENA_C.y, 1.1, "water", { hitstop: 0.12, frame: true });
        const waves = seg(t, s.WAVE, s.WAVE + 1.7);
        for (let w = 0; w < 3; w++) {
          const u = clamp((waves - w * 0.14) * 1.5);
          if (u <= 0 || u >= 1) continue;
          const ang = -0.5 + w * 0.55;
          const dirx = Math.cos(ang), diry = Math.sin(ang) * 0.5;
          const travel = lerp(-60, 480, easeOut(u, 1.6));
          const ox = 20 + dirx * travel, oy = 60 + diry * travel + w * 40;
          const P = (i) => {
            const curve = i * i / 300;
            return { x: ox - curve * dirx * 1.4 - diry * i * 1.6, y: oy - curve * diry + dirx * i };
          };
          const a = P(-70), m = P(0), b = P(70);
          const dl = Math.hypot(dirx, diry);
          const o = { element: "water", dmg: 30, force: 0.95, dirx: dirx / dl, diry: diry / dl, lift: 0.5 };
          const hits = [...W.lineHit("wave" + w, a.x, a.y, m.x, m.y, 8, o), ...W.lineHit("wave" + w, m.x, m.y, b.x, b.y, 8, o)];
          if (hits.length) {
            W.freeze(0.05);
            W.shake(0.12);
          }
        }
        if (W.once("end", t >= 6.5)) W.settle();
      },
      7: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("ice");
        const reach = 26 + 110 * seg(t, 0.4, 3.6);
        if (t > 0.3 && t < s.BREAK) W.status(ARENA_C.x, ARENA_C.y, reach, "ice", Math.min(0.9, 0.35 + seg(t, 0.4, 3) * 0.6));
        if (t > 1 && t < s.BREAK) W.focus(ARENA_C.x, ARENA_C.y, 0.2 + 0.5 * seg(t, 1, 4.5));
        s.pieces.forEach((p, i) => {
          if (p.tier >= 1 && W.once("pc" + i, t >= p.delay)) W.shake(0.025);
        });
        if (t > 4.2 && t < s.BREAK) {
          const k = seg(t, 4.2, s.BREAK);
          W.inhale(k * 0.7);
          W.tremor(dt, 0.2 * k);
          W.focus(ARENA_C.x + 40, ARENA_C.y, 0.8);
        }
        if (W.once("strike", t >= s.BREAK))
          W.impact(ARENA_C.x + 40, ARENA_C.y, { element: "ice", force: 1.25, radius: 190, dmg: 70, hitstop: 0.2, lift: 0.5 });
        if (W.once("end", t >= 7)) W.settle();
      },
      8: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("water");
        const rage = seg(t, 2.4, s.STOP);
        if (t > 0.6 && t < s.STOP) {
          W.pull(ARENA_C.x, ARENA_C.y, 180, 50 + 150 * rage, 70 + 170 * rage, dt, "water");
          W.focus(ARENA_C.x, ARENA_C.y, 0.2 + 0.6 * seg(t, 0.6, s.STOP));
          W.tremor(dt, 0.04 + 0.16 * rage);
          for (const e of W.alive())
            if (Math.hypot(e.x - ARENA_C.x, (e.y - ARENA_C.y) * 1.5) < 30) W.sweep("throat", e.x, e.y - 6, 4, { element: "water", dmg: 6, force: 0.1 }, 0.35);
        }
        if (t >= s.STOP && t < s.SURGE) {
          W.still(dt);
          W.inhale(1);
          W.focus(ARENA_C.x, ARENA_C.y, 1);
        }
        if (W.once("stop", t >= s.STOP)) W.trauma = 0;
        if (W.once("strike", t >= s.SURGE))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "water", force: 1.55, radius: 220, dmg: 90, hitstop: 0.22, lift: 1.2 });
        if (W.once("end", t >= 6.5)) W.settle();
      },
      // ===================================================================== TEMPEST
      9: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("volt", 0.7);
        s.events.forEach((ev, k) => {
          if (ev.fail) return;
          if (W.once("ev" + k, t >= ev.t0)) {
            const en = W.enemies[s.enemyOf[ev.b]];
            if (en && !en.dead) {
              const A = s.nodes[ev.a], B = s.nodes[ev.b];
              const dx = B.x - A.x, dy = B.y - A.y, dl = Math.hypot(dx, dy) || 1;
              W.hit(en, { element: "volt", dmg: 16, force: 0.3, dirx: dx / dl, diry: dy / dl, status: 0.6, hitstop: 0.05 });
            }
            W.chroma = Math.max(W.chroma, 1.2);
          }
        });
        if (t > s.FINAL - 0.5 && t < s.FINAL) {
          W.inhale(seg(t, s.FINAL - 0.5, s.FINAL) * 0.7);
          W.tremor(dt, 0.12);
        }
        if (W.once("final", t >= s.FINAL)) W.thump(ARENA_C.x, ARENA_C.y, 1.2, "volt", { hitstop: 0.14, frame: true });
        const succ = s.events.filter((e) => !e.fail);
        const fin = seg(t, s.FINAL, s.FINAL + 1);
        succ.forEach((ev, i) => {
          if (W.once("fin" + i, t > s.FINAL && fin >= i * 0.028 + 0.02)) {
            const en = W.enemies[s.enemyOf[ev.b]];
            if (en) W.hit(en, { element: "volt", dmg: 22, force: 0.55, dirx: 0, diry: -0.3, status: 0.8, lift: 0.3 }, false);
          }
        });
        if (W.once("end", t >= 6.3)) W.settle();
      },
      10: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("volt", 0.7);
        const T = s.T;
        const wind = seg(t, 3.2, 4.45);
        if (t > 0.2 && t < s.STRIKE) {
          W.status(T.x, T.y, 90, "volt", 0.15 + 0.35 * wind);
          W.pull(T.x, T.y, 110, 30 + 60 * wind, 40 * wind, dt);
          W.focus(T.x, T.y, 0.15 + 0.6 * seg(t, 0.5, 4.4));
          W.tremor(dt, 0.04 + 0.12 * wind);
        }
        if (t >= 4.45 && t < s.STRIKE) {
          W.inhale(seg(t, 4.45, s.STRIKE));
          W.focus(T.x, T.y, 1);
        }
        if (W.once("strike", t >= s.STRIKE)) {
          W.impact(T.x, T.y, { element: "volt", force: 1.65, radius: 55, dmg: 150, hitstop: 0.22, lift: 0.4 });
          W.impact(T.x, T.y, { element: "volt", force: 0.3, radius: 150, dmg: 15, hitstop: 0, frame: false, wave: 0, shake: 0 });
        }
        s.relight.forEach((r, i) => {
          if (W.once("rl" + i, t >= r.t0))
            W.impact(r.x, r.y, { element: "volt", force: 0.2, radius: 18, dmg: 6, hitstop: 0.01, frame: false, wave: 0.3, shake: 0.04, zoom: 0.05 });
        });
        if (W.once("end", t >= 6.5)) W.settle();
      },
      11: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("volt");
        const energy = seg(t, 1.5, s.SYNC);
        if (t > 1.6 && t < s.SYNC) {
          const slot = Math.floor(t / (0.42 - energy * 0.25));
          if (W.once("arc" + slot)) {
            const al = W.alive().filter((e) => Math.hypot(e.x - ARENA_C.x, e.y - ARENA_C.y) < 160);
            if (al.length) {
              const e = al[slot % al.length];
              const a = slot * 2.39;
              const c = chest(e);
              W.zap(ARENA_C.x + Math.cos(a) * 50, ARENA_C.y + Math.sin(a) * 30, c.x, c.y, 0.14);
              W.hit(e, { element: "volt", dmg: 5, force: 0.15, status: 0.4, hitstop: 0.015, dirx: (e.x - ARENA_C.x) / 100, diry: 0 });
            }
          }
          W.focus(ARENA_C.x, ARENA_C.y, 0.2 + 0.6 * energy);
          W.tremor(dt, 0.1 * energy);
        }
        if (t > s.SYNC - 0.35 && t < s.SYNC) W.inhale(seg(t, s.SYNC - 0.35, s.SYNC));
        if (W.once("strike", t >= s.SYNC))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "volt", force: 1.3, radius: 190, dmg: 70, hitstop: 0.17, lift: 0.5 });
        if (W.once("end", t >= 6.8)) W.settle();
      },
      12: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("volt", 0.8);
        s.E.forEach((e, i) => {
          if (e.instant && W.once("draw" + i, t >= e.t0)) {
            W.shake(0.05);
            W.chroma = Math.max(W.chroma, 0.8);
          }
          if (W.once("blow" + i, e.blow > 0)) {
            const A = s.N[e.a], B = s.N[e.b];
            W.impact((A.x + B.x) / 2, (A.y + B.y) / 2, { element: "volt", force: 0.3, radius: 26, dmg: 14, hitstop: 0.012, frame: false, wave: 0.4, shake: 0.05, zoom: 0.05 });
          }
        });
        if (t > s.CIRCUIT && t < s.RUPTURE) W.focus(ARENA_C.x, ARENA_C.y, 0.3 + 0.6 * seg(t, s.CIRCUIT, s.RUPTURE));
        if (t > s.RUPTURE - 0.4 && t < s.RUPTURE) {
          W.inhale(seg(t, s.RUPTURE - 0.4, s.RUPTURE));
          W.tremor(dt, 0.2);
        }
        if (W.once("strike", t >= s.RUPTURE))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "volt", force: 1.45, radius: 210, dmg: 85, hitstop: 0.2, lift: 0.6 });
        if (W.once("end", t >= 7.1)) W.settle();
      },
      // ===================================================================== VERDANT
      13: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("verdant", 0.8);
        if (t < s.SNAP)
          for (const b of s.roots) {
            if (b.grow <= 0) continue;
            const p = b.pts[Math.min(b.pts.length - 1, Math.floor(b.grow * (b.pts.length - 1)))];
            W.status(p.x, p.y, 14, "verdant", 1);
          }
        s.flowers.forEach((f, i) => {
          if (W.once("fl" + i, t >= f.t0)) {
            W.shake(0.03);
            W.wave(f.x, f.y, 1.2, 120, 5, 0.3, "verdant");
          }
        });
        if (t > 2 && t < s.SNAP) W.focus(ARENA_C.x - 20, ARENA_C.y, 0.2 + 0.5 * seg(t, 2, s.SNAP));
        if (t > s.SNAP - 0.5 && t < s.SNAP) {
          W.inhale(seg(t, s.SNAP - 0.5, s.SNAP) * 0.8);
          W.tremor(dt, 0.15);
          for (const e of W.alive()) if (e.root > 0.3) e.sq = -0.12 * seg(t, s.SNAP - 0.5, s.SNAP);
        }
        if (W.once("snap", t >= s.SNAP)) {
          W.thump(CASTER.x + 60, CASTER.y - 10, 1.15, "verdant", { hitstop: 0.17, frame: true });
          for (const e of W.alive())
            if (e.root > 0.25) W.hit(e, { element: "verdant", dmg: 75, force: 0.8, dirx: 0, diry: -0.2, lift: 1.5, status: 0 }, false);
        }
        if (W.once("end", t >= 7)) W.settle(0.6);
      },
      14: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("verdant", 0.5);
        if (t < s.BLOOM)
          for (const c of s.colonies) {
            if (t - c.born < 0.4) continue;
            for (const e of W.alive()) if (Math.hypot(e.x - c.x, e.y - 6 - c.y) < 24) e.spore = Math.max(e.spore, 0.85);
          }
        if (t > 3.2 && t < s.BLOOM) W.focus(ARENA_C.x, ARENA_C.y, 0.15 + 0.45 * seg(t, 3.2, s.BLOOM));
        if (t > s.BLOOM - 0.45 && t < s.BLOOM) {
          W.inhale(seg(t, s.BLOOM - 0.45, s.BLOOM) * 0.8);
          W.tremor(dt, 0.08);
        }
        if (W.once("bloom", t >= s.BLOOM))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "verdant", force: 0.8, radius: 240, dmg: 30, hitstop: 0.13, frame: true, lift: 0.6 });
        if (W.once("end", t >= 7)) W.settle(0.5);
      },
      15: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("verdant");
        s.tendrils.forEach((td, i) => {
          const h = td.pts[0];
          const sp = Math.hypot(h.vx, h.vy);
          if (sp > 160 && t > 0.6)
            W.sweep("td" + i, h.x, h.y, 9, { element: "verdant", dmg: 9, force: clamp(sp / 600, 0.25, 0.9), dirx: h.vx / sp, diry: h.vy / sp, status: 0.25 }, 0.5);
        });
        if (t > s.CURL && t < s.OPEN) {
          const k = seg(t, s.CURL, s.OPEN);
          W.focus(ARENA_C.x, ARENA_C.y, 0.3 + 0.7 * k);
          W.inhale(k * 0.8);
          W.tremor(dt, 0.14 * k);
          W.pull(ARENA_C.x, ARENA_C.y, 150, 120 * k, 0, dt);
        }
        if (W.once("open", t >= s.OPEN))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "verdant", force: 1.2, radius: 175, dmg: 60, hitstop: 0.17, lift: 0.9 });
        if (W.once("end", t >= 6.8)) W.settle();
      },
      16: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("verdant", 0.4);
        if (t < s.CRACK) W.focus(ARENA_C.x, ARENA_C.y, 0.5 * seg(t, 0.3, s.CRACK));
        if (t > s.CRACK - 0.4 && t < s.CRACK) W.inhale(seg(t, s.CRACK - 0.4, s.CRACK) * 0.6);
        if (W.once("crack", t >= s.CRACK)) W.thump(ARENA_C.x, ARENA_C.y, 0.55, "verdant", { hitstop: 0.1, frame: false, zoom: 0.6 });
        if (t > s.CRACK && t < s.BLOOM) {
          W.pull(ARENA_C.x, ARENA_C.y, 30 + 110 * seg(t, s.CRACK, s.BLOOM), -70, 15, dt);
          W.focus(ARENA_C.x, ARENA_C.y, 0.3 + 0.4 * seg(t, s.CRACK, s.BLOOM));
        }
        if (t > s.BLOOM - 0.4 && t < s.BLOOM) {
          W.inhale(seg(t, s.BLOOM - 0.4, s.BLOOM));
          W.tremor(dt, 0.12);
        }
        if (W.once("bloom", t >= s.BLOOM))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "verdant", force: 0.95, radius: 210, dmg: 50, hitstop: 0.15, frame: true, lift: 1.2 });
        if (t > s.FOLD) W.pull(ARENA_C.x, ARENA_C.y, 220, 60, 20, dt);
        if (W.once("end", t >= 7.7)) W.settle(0.5);
      },
      // ===================================================================== ASTRAL
      17: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("astral", 0.6);
        const k = seg(t, 0.6, s.COLLAPSE);
        if (t > 0.4 && t < s.REBOUND) {
          const col = seg(t, s.COLLAPSE, s.REBOUND);
          W.pull(ARENA_C.x, ARENA_C.y, 230, 70 + 170 * k + 600 * col, 60 + 90 * k, dt, "astral");
          W.focus(ARENA_C.x, ARENA_C.y, 0.2 + 0.7 * k);
          W.tremor(dt, 0.05 + 0.15 * k);
          const rh = s.rh(t);
          for (const e of W.alive()) if (Math.hypot(e.x - ARENA_C.x, (e.y - 6 - ARENA_C.y) * 1.5) < rh + 4) W.kill(e, "astral");
        }
        if (t > s.COLLAPSE && t < s.REBOUND) W.inhale(1);
        if (W.once("strike", t >= s.REBOUND))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "astral", force: 1.65, radius: 260, dmg: 90, hitstop: 0.22, lift: 1 });
        if (W.once("end", t >= 7)) W.settle();
      },
      18: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("astral");
        const tgt = W.nearest(s.P1.x, s.P1.y);
        if (tgt && W.once("echo", t >= (1 - 0.48) / 0.55)) {
          W.hit(tgt, { element: "astral", dmg: 8, force: 0.35, dirx: 1, diry: 0, hitstop: 0.06 });
          W.wave(s.P1.x, s.P1.y, 1.8, 160, 6, 0.4, "astral");
        }
        if (W.once("real", t >= 1 / 0.55))
          W.impact(s.P1.x, s.P1.y, { element: "astral", force: 0.75, radius: 34, dmg: 26, hitstop: 0.08, frame: false });
        if (t > s.FREEZE && t < s.SYNC) {
          W.still(dt);
          for (const e of W.alive()) e.warp = Math.max(e.warp, 0.35);
          W.focus(ARENA_C.x, ARENA_C.y, 0.3 + 0.5 * seg(t, s.FREEZE, s.SYNC));
        }
        s.crystals.forEach((c, i) => {
          const act = t - c.fire;
          if (!tgt) return;
          if (c.mode === 0 && W.once("fwd" + i, act > 0 && c.s + act * 0.9 >= 1))
            W.hit(tgt, { element: "astral", dmg: 12, force: 0.4, dirx: 1, diry: 0, hitstop: 0.04 });
          if (c.mode === 1 && W.once("rev" + i, act > 0)) {
            tgt.vx -= 120;
            tgt.flash = 0.1;
            W.shake(0.06);
          }
          if (c.mode === 2 && W.once("rel" + i, act > 0))
            W.impact(c.x + c.ox, c.y + c.oy, { element: "astral", force: 0.3, radius: 40, dmg: 10, hitstop: 0.02, frame: false, wave: 0.6, shake: 0.06 });
        });
        if (t > s.SYNC - 0.4 && t < s.SYNC) {
          W.inhale(seg(t, s.SYNC - 0.4, s.SYNC));
          W.tremor(dt, 0.15);
        }
        if (W.once("sync", t >= s.SYNC))
          W.impact(ARENA_C.x, ARENA_C.y, { element: "astral", force: 1.15, radius: 200, dmg: 60, hitstop: 0.16, lift: 0.7 });
        if (W.once("end", t >= 7)) W.settle();
      },
      19: (s, t, dt) => {
        if (W.once("tell", t > 0.01)) W.castSnap("astral", 0.5);
        if (t > 1.6 && t < s.FINAL) W.focus(ARENA_C.x, ARENA_C.y, 0.15 + 0.5 * seg(t, 1.6, s.FINAL));
        if (W.once("lock1", t >= 3)) {
          W.shake(0.08);
          W.punch(0.25);
        }
        if (W.once("lock2", t >= 4.6)) {
          W.shake(0.1);
          W.punch(0.3);
        }
        if (t > s.FINAL && t < s.FINAL + 0.85) {
          W.inhale(seg(t, s.FINAL, s.FINAL + 0.85));
          W.tremor(dt, 0.12);
          W.focus(ARENA_C.x, ARENA_C.y, 1);
          for (const e of W.alive()) applyStatus(e, "astral", 0.4);
        }
        const B = s.FINAL + 0.85;
        if (W.once("burst", t >= B)) W.impact(ARENA_C.x, ARENA_C.y, { element: "astral", force: 1.25, radius: 60, dmg: 30, hitstop: 0.16, frame: true });
        const burst = seg(t, B, s.FINAL + 1.9);
        for (let i = 0; i < 5; i++) {
          if (burst <= i * 0.07 || burst > 0.9) continue;
          const a = i / 5 * Math.PI * 2 + 0.4;
          const ex = ARENA_C.x + Math.cos(a) * 260, ey = ARENA_C.y + Math.sin(a) * 260 / 1.5;
          const hits = W.lineHit("str" + i, ARENA_C.x, ARENA_C.y, ex, ey, 9, { element: "astral", dmg: 55, force: 0.9, dirx: Math.cos(a), diry: Math.sin(a), lift: 0.4 });
          if (hits.length) W.freeze(0.05);
        }
        if (W.once("end", t >= 7.6)) W.settle();
      },
      20: (s, t, dt) => {
        if (W.once("tell", t > 0.35)) W.chroma = 0.9;
        if (W.once("open", t >= s.OPEN)) W.thump(ARENA_C.x, ARENA_C.y, 0.35, "astral", { hitstop: 0.05, wave: 0 });
        const pull = seg(t, 1.2, s.COLLIDE);
        if (t > s.OPEN && t < s.CLOSE) {
          W.focus(ARENA_C.x, ARENA_C.y, 0.15 + 0.6 * pull);
          W.tremor(dt, 0.03 + 0.12 * pull);
          for (const e of W.alive()) {
            const n = s.near(e.x, e.y - 6);
            if (n.d > 90) continue;
            const f = (1 - n.d / 90) * (40 + 140 * pull);
            const dx = n.px - e.x, dy = n.py - (e.y - 6), dl = Math.hypot(dx, dy) || 1;
            e.vx += dx / dl * f * dt;
            e.vy += dy / dl * f * dt;
            e.warp = Math.max(e.warp, (1 - n.d / 90) * pull);
            e.stagger = Math.max(e.stagger, 0.1);
            if (n.d < s.halfW(n.u, t) - 1) W.kill(e, "astral");
          }
        }
        if (t > s.COLLIDE - 0.4 && t < s.COLLIDE) W.inhale(seg(t, s.COLLIDE - 0.4, s.COLLIDE));
        if (W.once("collide", t >= s.COLLIDE)) {
          const mid = s.path[Math.floor(s.path.length / 2)];
          W.thump(mid.x, mid.y, 1.65, "astral", { hitstop: 0.22, frame: true });
          for (const e of W.alive()) {
            const n = s.near(e.x, e.y - 6);
            if (n.d > 80) continue;
            const dx = e.x - n.px, dy = e.y - 6 - n.py, dl = Math.hypot(dx, dy) || 1;
            W.hit(e, { element: "astral", dmg: 90 * (1 - n.d / 120), force: 1.1, dirx: dx / dl, diry: dy / dl, lift: 0.7 }, false);
          }
        }
        s.bands.forEach((b, i) => {
          if (i % 8 === 0 && W.once("stitch" + i, t >= s.CLOSE + 0.25 + b.close * 1.5)) W.shake(0.04);
        });
        if (W.once("last", t >= s.CLOSE + 2.75)) W.settle(0.7);
      }
    };
  }
});

// src/engine/lab.ts
var lab_exports = {};
__export(lab_exports, {
  DT: () => DT,
  Lab: () => Lab
});
var DT, SCHOOL_TRAIL, Lab;
var init_lab = __esm({
  "src/engine/lab.ts"() {
    "use strict";
    init_framebuffer();
    init_arena();
    init_math();
    init_world();
    init_enemies();
    init_choreo();
    DT = 1 / 60;
    SCHOOL_TRAIL = {
      PYRE: [0.35, 0.6],
      TIDE: [0.42, 0.66],
      TEMPEST: [0.6, 0.72],
      VERDANT: [0.3, 0.58],
      ASTRAL: [0.5, 0.74]
    };
    Lab = class {
      fb;
      def = null;
      spell = null;
      t = 0;
      acc = 0;
      speed = 1;
      showArena = true;
      showEnemies = true;
      advanced = true;
      constructor() {
        this.fb = new Framebuffer(VIEW_W, VIEW_H);
        buildFloor(this.fb);
      }
      rebuild() {
        W.reset();
        this.spell = this.def.make();
        this.t = 0;
        this.fb.resetTrail();
      }
      load(def, at = 0) {
        this.def = def;
        this.rebuild();
        this.acc = 0;
        if (at > 0) this.seek(at);
      }
      reset() {
        if (this.def) this.load(this.def, 0);
      }
      /** one fixed frame of the simulation */
      step() {
        if (!this.def || !this.spell) return;
        W.tick(DT);
        if (W.hitstop > 0) {
          W.hitstop -= DT;
          return;
        }
        const dt = DT * W.timeScale();
        this.t += dt;
        this.spell.update(dt, this.t);
        const ch = CHOREO[this.def.id];
        if (ch) ch(this.spell, this.t, dt);
        W.update(dt);
      }
      seek(target) {
        if (!this.def) return;
        const tt = clamp(target, 0, this.def.duration);
        if (tt < this.t) this.rebuild();
        let guard = 0;
        while (this.t < tt - 1e-6 && guard++ < 2e4) this.step();
        this.acc = 0;
      }
      advance(real) {
        if (!this.def || !this.spell) return;
        this.acc += Math.min(real, 0.25) * this.speed;
        let guard = 0;
        this.advanced = false;
        while (this.acc >= DT && guard++ < 8) {
          this.acc -= DT;
          if (this.t > this.def.duration) {
            this.rebuild();
            continue;
          }
          this.step();
          this.advanced = true;
        }
      }
      stepFrame(dir = 1) {
        if (!this.def) return;
        if (dir > 0) {
          this.step();
          this.advanced = true;
        } else this.seek(Math.max(0, this.t - DT));
      }
      render(ctx) {
        const { fb } = this;
        if (!this.def || !this.spell) return;
        fb.clear();
        const warp = this.spell.bgWarp ? this.spell.bgWarp(this.t) : null;
        fb.drawBackground(warp || void 0);
        if (W.inhaleAmt > 2e-3) fb.scaleAll(1 - W.inhaleAmt * 0.55);
        if (this.showArena) {
          drawDust(fb, this.t);
          const lit = this.spell.casterLight ? this.spell.casterLight(this.t) : 0.3;
          drawCaster(fb, this.t, this.def.accent, clamp(lit, 0, 2.5), W.casterKick);
        }
        fb.markBase();
        this.spell.render(fb, this.t);
        const fk = W.hitstop > 0 ? 0.05 : 0.14;
        fb.flash[0] *= fk;
        fb.flash[1] *= fk;
        fb.flash[2] *= fk;
        const [persist, decay] = this.def.trail ?? SCHOOL_TRAIL[this.def.school] ?? [0.4, 0.62];
        fb.applyTrail(persist, decay, this.advanced);
        if (this.showEnemies) {
          renderEnemies(fb, W);
          renderOverlay(fb, W);
        }
        const cam = W.camera();
        fb.cam.x = cam.x;
        fb.cam.y = cam.y;
        fb.cam.zoom = cam.zoom;
        fb.cam.rot = cam.rot;
        fb.waves = W.waves;
        fb.chroma = W.chroma;
        fb.impactFrames = W.impactFrames;
        fb.impactTint = W.impactTint;
        fb.present(ctx);
      }
    };
  }
});

// src/engine/particles.ts
function streakP(fb, p, c, k) {
  const dx = p.x - p.px, dy = p.y - p.py;
  const n = Math.max(1, Math.min(12, Math.ceil(Math.hypot(dx, dy))));
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    const f = (0.35 + 0.65 * u) * k;
    fb.add(p.px + dx * u, p.py + dy * u, c[0], c[1], c[2], f);
  }
}
var Pool;
var init_particles = __esm({
  "src/engine/particles.ts"() {
    "use strict";
    Pool = class {
      items = [];
      spawn(o) {
        let p = this.items.find((q) => q.dead);
        if (!p) {
          p = {
            x: 0,
            y: 0,
            vx: 0,
            vy: 0,
            life: 1,
            max: 1,
            size: 1,
            seed: 0,
            k: 1,
            a: 0,
            av: 0,
            dead: false,
            px: 0,
            py: 0,
            tag: 0
          };
          this.items.push(p);
        }
        Object.assign(p, {
          vx: 0,
          vy: 0,
          size: 1,
          k: 1,
          a: 0,
          av: 0,
          tag: 0,
          dead: false
        });
        Object.assign(p, o);
        p.max = p.life;
        p.px = p.x;
        p.py = p.y;
        return p;
      }
      get alive() {
        return this.items.filter((p) => !p.dead);
      }
      each(fn) {
        for (const p of this.items) if (!p.dead) fn(p);
      }
      count() {
        let n = 0;
        for (const p of this.items) if (!p.dead) n++;
        return n;
      }
      /** basic integrate + lifetime; systems usually do their own thing */
      step(dt, drag = 0, gx = 0, gy = 0) {
        for (const p of this.items) {
          if (p.dead) continue;
          p.px = p.x;
          p.py = p.y;
          p.vx += gx * dt;
          p.vy += gy * dt;
          if (drag) {
            const d = Math.exp(-drag * dt);
            p.vx *= d;
            p.vy *= d;
          }
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.a += p.av * dt;
          p.life -= dt;
          if (p.life <= 0) p.dead = true;
        }
      }
      clear() {
        for (const p of this.items) p.dead = true;
      }
    };
  }
});

// src/spells/common.ts
function fireCol2(h, steps = 9) {
  return R("fire", Math.floor(clamp(h) * steps) / steps);
}
function rampStep(name, h, steps = 8) {
  return R(name, Math.floor(clamp(h) * steps) / steps);
}
function flameBlob(fb, cx, cy, radius, t, seedOff, k, squash = 1, steps = 9) {
  const rr = radius * 1.35;
  field(fb, cx - rr, cy - rr / squash, cx + rr, cy + rr / squash, (x, y, o) => {
    const dx = x + 0.5 - cx, dy = (y + 0.5 - cy) * squash;
    const d = Math.hypot(dx, dy);
    if (d > rr) return;
    const a = Math.atan2(dy, dx);
    const n = fbm(Math.cos(a) * 2.4 + seedOff, Math.sin(a) * 2.4 - t * 1.7, 3);
    const surf = radius * (0.62 + n * 0.62);
    let h = 1 - d / surf;
    if (h <= 0) return;
    h *= k;
    const c = fireCol2(h, steps);
    o[0] = c[0];
    o[1] = c[1];
    o[2] = c[2];
  });
}
function growBranches(rng, x0, y0, a0, w0, opts) {
  const out = [];
  const queue = [
    { x: x0, y: y0, a: a0, w: w0, d: 0, delay: 0 }
  ];
  let guard = 0;
  while (queue.length && guard++ < 400) {
    const q = queue.shift();
    const pts = [{ x: q.x, y: q.y }];
    let x = q.x, y = q.y, a = q.a;
    const n = Math.max(3, Math.round(opts.steps * (1 - q.d * 0.18) * rng.range(0.6, 1.25)));
    for (let i = 0; i < n; i++) {
      a += rng.gauss(opts.wander) * 0.5;
      if (opts.bias) a += opts.bias(x, y, a, q.d) * 0.3;
      const s = opts.step * rng.range(0.7, 1.35);
      x += Math.cos(a) * s;
      y += Math.sin(a) * s;
      pts.push({ x, y });
      if (q.d < opts.maxDepth && rng.next() < opts.branchChance) {
        queue.push({
          x,
          y,
          a: a + rng.sign() * rng.range(0.4, 1.3),
          w: q.w * opts.widthFalloff,
          d: q.d + 1,
          delay: q.delay + i / n * (1 / opts.speed) * 0.9
        });
      }
    }
    out.push({
      pts,
      w: q.w,
      depth: q.d,
      grow: 0,
      speed: opts.speed * rng.range(0.8, 1.4),
      delay: q.delay,
      seed: rng.int(0, 9999)
    });
  }
  return out;
}
function updateBranches(bs, t) {
  for (const b of bs) b.grow = clamp((t - b.delay) * b.speed);
}
function drawBranch(fb, b, colFn, widthFn, blend = false) {
  const n = b.pts.length;
  const limit = b.grow * (n - 1);
  if (limit <= 0) return;
  for (let i = 0; i < Math.min(n - 1, Math.ceil(limit)); i++) {
    const p = b.pts[i], q = b.pts[i + 1];
    const f = clamp(limit - i);
    const u0 = i / (n - 1);
    const ex = p.x + (q.x - p.x) * f, ey = p.y + (q.y - p.y) * f;
    const dx = ex - p.x, dy = ey - p.y;
    const len = Math.max(1, Math.hypot(dx, dy));
    for (let s = 0; s <= len; s++) {
      const u = u0 + s / len / (n - 1) * 1;
      const cx = p.x + dx * s / len, cy = p.y + dy * s / len;
      const w = widthFn(u, b);
      let nx = -dy / len, ny = dx / len;
      const iw = Math.ceil(w);
      for (let kk = -iw; kk <= iw; kk++) {
        const e = Math.abs(kk) / (w || 1);
        if (e > 1) continue;
        const c = colFn(u, e, b);
        if (!c) continue;
        if (blend) fb.blend(cx + nx * kk, cy + ny * kk, c[0], c[1], c[2], 1);
        else fb.add(cx + nx * kk, cy + ny * kk, c[0], c[1], c[2], 1);
      }
    }
  }
}
function scarDecal(fb, bs, heat, t, tint = [1, 0.35, 0.08]) {
  for (const b of bs) {
    drawBranch(
      fb,
      b,
      (u, e) => {
        const flick = 0.75 + 0.25 * vnoise(u * 18 + b.seed, t * 3);
        const h = (1 - e) * heat * flick * (1 - u * 0.45);
        if (h <= 0.02) return null;
        const c = fireCol2(h * 0.95);
        return [c[0] * tint[0], c[1] * tint[1] * 1.6, c[2] * tint[2] * 2.2];
      },
      (u, bb) => Math.max(0.6, bb.w * (1 - u * 0.75))
    );
  }
}
function shard(fb, cx, cy, r, a, sides, seed, colFn, squash = 1) {
  const pts = [];
  for (let i = 0; i < sides; i++) {
    const ang = a + i / sides * TAU;
    const rr = r * (0.55 + hash2(seed, i) * 0.8);
    pts.push({ x: cx + Math.cos(ang) * rr, y: cy + Math.sin(ang) * rr / squash });
  }
  let minY = Infinity, maxY = -Infinity;
  for (const p of pts) {
    minY = Math.min(minY, p.y);
    maxY = Math.max(maxY, p.y);
  }
  for (let y = Math.max(0, Math.floor(minY)); y <= Math.min(fb.H - 1, Math.ceil(maxY)); y++) {
    const xs = [];
    const yc = y + 0.5;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i], q = pts[(i + 1) % pts.length];
      if (p.y === q.y) continue;
      if (yc >= p.y && yc < q.y || yc >= q.y && yc < p.y)
        xs.push(p.x + (yc - p.y) / (q.y - p.y) * (q.x - p.x));
    }
    xs.sort((m, n) => m - n);
    for (let k = 0; k + 1 < xs.length; k += 2) {
      const xa = Math.ceil(xs[k]), xb = Math.floor(xs[k + 1]);
      for (let x = xa; x <= xb; x++) {
        const d = Math.hypot(x - cx, (y - cy) * squash) / (r || 1);
        const edge = Math.min(x - xs[k], xs[k + 1] - x);
        const c = colFn(clamp(d), edge);
        if (c) fb.add(x, y, c[0], c[1], c[2], 1);
      }
    }
  }
}
function heatShimmer(fb, cx, cy, r, t, amp) {
  const x0 = Math.max(1, Math.floor(cx - r)), x1 = Math.min(fb.W - 2, Math.ceil(cx + r));
  const y0 = Math.max(1, Math.floor(cy - r)), y1 = Math.min(fb.H - 2, Math.ceil(cy + r));
  if (x1 <= x0 || y1 <= y0) return;
  const w = x1 - x0 + 1, h = y1 - y0 + 1;
  const tmp = new Float32Array(w * h * 3);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = ((y + y0) * fb.W + (x + x0)) * 3;
      const o = (y * w + x) * 3;
      tmp[o] = fb.buf[i];
      tmp[o + 1] = fb.buf[i + 1];
      tmp[o + 2] = fb.buf[i + 2];
    }
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const gx = x + x0, gy = y + y0;
      const d = Math.hypot(gx - cx, gy - cy) / r;
      if (d > 1) continue;
      const f = (1 - d) * amp;
      const dy = Math.round(
        (vnoise((gx + 0.5) * 0.18, (gy + 0.5) * 0.1 - t * 6) - 0.5) * 2 * f
      );
      const dx = Math.round((vnoise(gx * 0.12 + 40, gy * 0.14 - t * 4) - 0.5) * 1.4 * f);
      const sx = clamp(x + dx, 0, w - 1) | 0, sy = clamp(y + dy, 0, h - 1) | 0;
      const s = (sy * w + sx) * 3;
      const i = (gy * fb.W + gx) * 3;
      fb.buf[i] = tmp[s];
      fb.buf[i + 1] = tmp[s + 1];
      fb.buf[i + 2] = tmp[s + 2];
    }
}
var init_common = __esm({
  "src/spells/common.ts"() {
    "use strict";
    init_draw();
    init_math();
  }
});

// src/spells/pyre.ts
var C, CinderCrown, FurnaceWyrm, MeteorLoom, AshenGuillotine;
var init_pyre = __esm({
  "src/spells/pyre.ts"() {
    "use strict";
    init_particles();
    init_draw();
    init_math();
    init_arena();
    init_common();
    C = ARENA_C;
    CinderCrown = class {
      rng = new RNG(49181);
      frags = [];
      suns = [];
      petals = [];
      ash = new Pool();
      t = 0;
      constructor() {
        const n = 13;
        for (let i = 0; i < n; i++) {
          const a = i / n * TAU + this.rng.range(-0.08, 0.08);
          const sa = this.rng.angle();
          this.frags.push({
            a,
            r: 30 + this.rng.range(-4, 5),
            sp: this.rng.range(-1.5, 1.5) * (i % 3 === 0 ? 2.4 : 1),
            size: this.rng.range(1.6, 4.2),
            sx: C.x + Math.cos(sa) * this.rng.range(150, 260),
            sy: C.y + Math.sin(sa) * this.rng.range(110, 190),
            x: 0,
            y: 0,
            px: 0,
            py: 0,
            spike: this.rng.range(8, 26) * (i % 2 ? 1 : 0.62),
            w: this.rng.range(0.1, 0.26),
            tail: this.rng.next() < 0.45 ? 1 : 0,
            delay: this.rng.range(0, 0.55)
          });
        }
        for (let i = 0; i < 3; i++)
          this.suns.push({
            r: 9 + i * 5.5,
            sp: this.rng.range(1.4, 3.4) * this.rng.sign(),
            ph: this.rng.angle(),
            s: this.rng.range(1.4, 2.6)
          });
        for (let i = 0; i < 11; i++) {
          this.petals.push({
            a: i / 11 * TAU + this.rng.range(-0.22, 0.22),
            len: this.rng.range(46, 148),
            curve: this.rng.range(-1.5, 1.5),
            delay: this.rng.range(0, 0.42),
            sp: this.rng.range(0.7, 1.9),
            w: this.rng.range(7, 20),
            back: this.rng.next() < 0.28 ? 1 : 0
          });
        }
      }
      update(dt, t) {
        this.t = t;
        if (t > 3.95 && t < 5.6 && this.ash.count() < 260) {
          for (let i = 0; i < 7; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(20, 150);
            this.ash.spawn({
              x: C.x + Math.cos(a) * this.rng.range(0, 24),
              y: C.y + Math.sin(a) * this.rng.range(0, 18),
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp * 0.7 - 12,
              life: this.rng.range(0.7, 2.4),
              size: this.rng.range(0.6, 1.8),
              k: this.rng.range(0.5, 1),
              seed: this.rng.next() * 1e3
            });
          }
        }
        if (t > 1 && t < 3.3 && this.ash.count() < 150 && this.rng.next() < 0.55) {
          const a = this.rng.angle();
          this.ash.spawn({
            x: C.x + Math.cos(a) * 60,
            y: C.y + Math.sin(a) * 46,
            vx: -Math.cos(a) * 34,
            vy: -Math.sin(a) * 28,
            life: 1.4,
            size: 1,
            k: 0.6,
            seed: this.rng.next() * 1e3
          });
        }
        this.ash.each((p) => {
          p.vy -= 26 * dt;
          p.vx *= Math.exp(-1.1 * dt);
          p.vy *= Math.exp(-0.9 * dt);
        });
        this.ash.step(dt, 0);
        const gather = seg(t, 0, 1.55);
        for (const f of this.frags) {
          f.px = f.x;
          f.py = f.y;
          const g = easeOut(clamp((gather - f.delay * 0.3) / 0.9), 2.6);
          const ang = f.a + f.sp * t;
          const collapse = 1 - 0.92 * smoothstep(3, 3.8, t);
          const tx = C.x + Math.cos(ang) * f.r * collapse;
          const ty = C.y + Math.sin(ang) * f.r * collapse / 1.25;
          f.x = lerp(f.sx, tx, g);
          f.y = lerp(f.sy, ty, g);
        }
      }
      casterLight(t) {
        return 0.3 + 0.9 * smoothstep(3.9, 4.1, t) * (1 - seg(t, 4.1, 5.5)) + 0.3 * seg(t, 0, 3);
      }
      render(fb, t) {
        const build = seg(t, 1.1, 3);
        const inhale = seg(t, 3, 3.86);
        const blackout = smoothstep(3.78, 3.9, t) * (1 - smoothstep(3.93, 3.99, t));
        const burst = seg(t, 3.95, 5.4);
        const after = seg(t, 5.2, 6.4);
        for (const f of this.frags) {
          const d = Math.hypot(f.x - f.px, f.y - f.py);
          if (d > 0.5 && t < 3.9) {
            const c = fireCol2(0.55 + clamp(d / 14) * 0.45);
            streak(fb, f.px, f.py, f.x, f.y, f.size * 0.5, f.size * 0.9, c, 0.9);
          }
        }
        if (build > 0 && burst < 1) {
          const open = 1 - inhale * 0.55;
          const base = 26 * open;
          const bright = 1 - blackout * 0.98;
          const rMax = 60;
          const frags = this.frags;
          field(fb, C.x - rMax, C.y - rMax / 1.2, C.x + rMax, C.y + rMax / 1.2, (x, y, o) => {
            const dx = x + 0.5 - C.x, dy = (y + 0.5 - C.y) * 1.2;
            const d = Math.hypot(dx, dy);
            if (d > rMax) return;
            const a = Math.atan2(dy, dx);
            let surf = base;
            for (const f of frags) {
              const ang = f.a + f.sp * t;
              let da = Math.abs((a - ang + Math.PI * 3) % TAU - Math.PI);
              const g = Math.exp(-(da * da) / (f.w * f.w * 2));
              surf += f.spike * g * build * (1 - inhale * 0.72);
            }
            const flick = fbm(Math.cos(a) * 3 + 11, Math.sin(a) * 3 - t * 2.2, 3);
            surf *= 0.82 + flick * 0.34;
            const inner = base * 0.52 * (1 - inhale * 0.9);
            if (d > surf || d < inner) return;
            let h = Math.min((surf - d) / 9, (d - inner) / 5);
            h = clamp(h) * build;
            const rim = clamp(1 - Math.abs(d - surf) / 2.1);
            let heat = lerp(h * 0.85, 0.08, inhale * 0.85) * bright;
            heat += rim * (0.55 + inhale * 0.9);
            const c = fireCol2(clamp(heat));
            o[0] = c[0];
            o[1] = c[1];
            o[2] = c[2];
          });
          const spokeK = build * (1 - inhale * 0.3);
          for (let i = 0; i < this.frags.length; i++) {
            const f = this.frags[i];
            const ang = f.a + f.sp * t;
            const r1 = (base * 0.52 + f.spike * build / 2) * (1 - inhale * 0.6);
            const c = fireCol2(0.55 + 0.35 * Math.sin(t * 7 + i) * (1 - blackout));
            line(
              fb,
              C.x + Math.cos(ang) * base * 0.5,
              C.y + Math.sin(ang) * base * 0.5 / 1.2,
              C.x + Math.cos(ang) * (base + r1 * 0.6),
              C.y + Math.sin(ang) * (base + r1 * 0.6) / 1.2,
              c,
              spokeK * 0.75 * (1 - blackout)
            );
          }
          for (const s of this.suns) {
            const a = s.ph + s.sp * t;
            const rr = s.r * (1 - inhale * 0.8);
            const sx = C.x + Math.cos(a) * rr, sy = C.y + Math.sin(a) * rr / 1.2;
            glow(fb, sx, sy, s.s * 2.6 * (1 - blackout * 0.9), R("fire", 0.92), 1.1 * build);
            fb.add(sx, sy, 3, 2.6, 2, build * (1 - blackout * 0.8));
          }
          const coreR = lerp(3, 10, inhale) * (1 - blackout * 0.5);
          glow(fb, C.x, C.y, coreR * 1.5, R("fire", 0.9), 0.4 + inhale * 1.1);
          if (inhale > 0.2) {
            fieldMul(fb, C.x - 46, C.y - 40, C.x + 46, C.y + 40, (x, y) => {
              const d = Math.hypot(x - C.x, (y - C.y) * 1.2);
              return d < 30 ? lerp(1, 0.2, inhale * clamp(1 - d / 30)) : 1;
            });
          }
        }
        if (burst > 0 && burst < 1) {
          const e = burst;
          for (const p of this.petals) {
            const u = clamp((e - p.delay * 0.3) * p.sp);
            if (u <= 0) continue;
            const grow = easeOut(u, 4.5);
            const len = p.len * grow * (p.back ? 0.6 + 0.4 * Math.sin(u * 3) : 1);
            const pts = [];
            const steps = 12;
            const r0 = 14 + u * 26;
            for (let i = 0; i <= steps; i++) {
              const s = i / steps;
              const a = p.a + p.curve * s * s * 0.75 * (p.back ? -1.5 : 1);
              const rr = r0 + len * s;
              pts.push({ x: C.x + Math.cos(a) * rr, y: C.y + Math.sin(a) * rr / 1.22 });
            }
            const fade = 1 - clamp((u - 0.55) / 0.45);
            ribbon(
              fb,
              pts,
              (s) => p.w * (0.2 + Math.sin(Math.pow(s, 0.8) * Math.PI) * 0.95) * (1 - u * 0.3),
              (s, _i, edge) => {
                const n = fbm(s * 7 + p.a * 4, edge * 4 - t * 3.4, 3);
                let h = (1 - edge) * (1 - s * 0.5) * (0.35 + n * 0.75) * fade * 0.95;
                if (h < 0.06) return null;
                return fireCol2(clamp(h));
              }
            );
          }
          const fl = Math.pow(1 - clamp(burst * 9), 2);
          fb.flash[0] += 0.45 * fl;
          fb.flash[1] += 0.22 * fl;
          fb.flash[2] += 0.08 * fl;
          pulseRing(fb, C.x, C.y, 10 + easeOut(burst, 2) * 210, 5 * (1 - burst), R("fire", 0.62), 0.45 * (1 - burst) ** 2, 1.25);
          heatShimmer(fb, C.x, C.y, 70 + burst * 60, t, 3 * (1 - burst));
        }
        if (after > 0) {
          const k = (1 - after) * 0.9;
          for (const f of this.frags) {
            const ang = f.a + f.sp * 3.9;
            const rr = (26 + f.spike * 0.8) * (1 + after * 0.25);
            const x = C.x + Math.cos(ang) * rr, y = C.y + Math.sin(ang) * rr / 1.2;
            const flick = 0.5 + 0.5 * vnoise(f.a * 9, t * 5);
            glow(fb, x, y, 3.4, fireCol2(0.42 * flick), k * 1.2);
          }
          for (let i = 0; i < 40; i++) {
            const a = i / 40 * TAU;
            const rr = 26 * (1 + after * 0.25);
            const f = 0.5 + 0.5 * Math.sin(a * 7 + t * 2);
            fb.add(
              C.x + Math.cos(a) * rr,
              C.y + Math.sin(a) * rr / 1.2,
              0.6,
              0.18,
              0.05,
              k * f * 0.8
            );
          }
        }
        this.ash.each((p) => {
          const l = p.life / p.max;
          const c = fireCol2(l * 0.95 * p.k + 0.05);
          streakP(fb, p, c, l * 0.9);
          if (p.size > 1.3) fb.add(p.x, p.y, c[0], c[1], c[2], l);
        });
      }
    };
    FurnaceWyrm = class {
      rng = new RNG(31281);
      hist = [];
      head = { x: CASTER.x + 8, y: CASTER.y - 6, a: -1.2, v: 0 };
      waypoints = [];
      wi = 0;
      embers = new Pool();
      minis = [];
      impactT = -1;
      t = 0;
      SEGS = 72;
      constructor() {
        const tgt = ANCHORS[0];
        const r = this.rng;
        this.waypoints = [
          { x: CASTER.x + 30, y: CASTER.y - 30 },
          { x: 180, y: 56 },
          { x: 300, y: 48 },
          { x: 370, y: 120 },
          { x: 300, y: 180 },
          { x: 200, y: 180 },
          { x: 150, y: 120 },
          { x: 240, y: 78 },
          { x: 340, y: 150 },
          { x: 280, y: 196 },
          { x: tgt.x - 70, y: tgt.y + 40 },
          { x: tgt.x, y: tgt.y }
        ].map((p) => ({ x: p.x + r.range(-6, 6), y: p.y + r.range(-6, 6) }));
        for (let i = 0; i < 400; i++) this.hist.push({ x: this.head.x, y: this.head.y });
      }
      update(dt, t) {
        this.t = t;
        const emerge = seg(t, 0.35, 1);
        const strike = t > 4.55;
        if (t < 0.35) return;
        const speed = strike ? 520 : lerp(60, 340, emerge) * (1 + 0.35 * Math.sin(t * 3.3));
        let tgt = this.waypoints[Math.min(this.wi, this.waypoints.length - 1)];
        if (strike) tgt = ANCHORS[0];
        if (this.impactT > 0) return;
        const want = Math.atan2(tgt.y - this.head.y, tgt.x - this.head.x);
        let da = (want - this.head.a + Math.PI * 3) % TAU - Math.PI;
        if (strike) this.head.a = want;
        else this.head.a += clamp(da, -4.2 * dt, 4.2 * dt);
        const wob = Math.sin(t * 7.5) * (strike ? 0.05 : 0.55);
        const ax = Math.cos(this.head.a + wob) * speed;
        const ay = Math.sin(this.head.a + wob) * speed;
        this.head.x = clamp(this.head.x + ax * dt, 26, 392);
        this.head.y = clamp(this.head.y + ay * dt, 24, 212);
        if (Math.hypot(tgt.x - this.head.x, tgt.y - this.head.y) < 26 && !strike)
          this.wi = Math.min(this.wi + 1, this.waypoints.length - 1);
        const steps = Math.max(1, Math.round(dt / (1 / 120)));
        for (let i = 0; i < steps; i++) this.hist.unshift({ x: this.head.x, y: this.head.y });
        this.hist.length = 400;
        if (strike && this.impactT < 0 && Math.hypot(ANCHORS[0].x - this.head.x, ANCHORS[0].y - this.head.y) < 22) {
          this.impactT = t;
          this.head.x = ANCHORS[0].x;
          this.head.y = ANCHORS[0].y;
        }
        if (t > 0.9 && t < 5.2) {
          for (let i = 0; i < 3; i++) {
            const idx = this.rng.int(2, 120);
            const h = this.hist[idx];
            this.embers.spawn({
              x: h.x + this.rng.range(-3, 3),
              y: h.y + this.rng.range(-3, 3),
              vx: this.rng.range(-30, 30),
              vy: this.rng.range(-50, 10),
              life: this.rng.range(0.4, 1.3),
              size: this.rng.range(0.5, 1.6),
              seed: this.rng.next() * 999
            });
          }
          if (this.rng.next() < 0.06 && this.minis.length < 8) {
            const idx = this.rng.int(20, 180);
            const h = this.hist[idx];
            const a = this.rng.angle();
            const pts = [];
            for (let i = 0; i < 26; i++)
              pts.push({ x: h.x + Math.cos(a) * i * 1.2, y: h.y + Math.sin(a) * i * 1.2 });
            this.minis.push({ h: pts, life: 1.1, max: 1.1 });
          }
        }
        for (const m of this.minis) {
          m.life -= dt;
          const head = m.h[0];
          const a = Math.atan2(head.y - m.h[1].y, head.x - m.h[1].x) + Math.sin(t * 11 + m.max * 7) * 0.5;
          m.h.unshift({ x: head.x + Math.cos(a) * 2.4, y: head.y + Math.sin(a) * 2.4 });
          m.h.length = 26;
        }
        this.minis = this.minis.filter((m) => m.life > 0);
        this.embers.each((p) => {
          p.vy -= 40 * dt;
          p.vx *= Math.exp(-1.6 * dt);
        });
        this.embers.step(dt);
      }
      casterLight(t) {
        return 0.25 + 0.6 * seg(t, 0, 1) + (this.impactT > 0 ? 1.4 * (1 - seg(t, this.impactT, this.impactT + 0.5)) : 0);
      }
      render(fb, t) {
        const emerge = seg(t, 0, 1);
        const strike = t > 4.55;
        const imp = this.impactT > 0 ? seg(t, this.impactT, this.impactT + 1.6) : 0;
        if (t < 2.4) {
          const k = (1 - seg(t, 1.4, 2.6)) * easeOut(seg(t, 0, 0.35), 2);
          for (let i = -18; i <= 18; i++) {
            const n2 = vnoise(i * 0.3, 3.1);
            const h = (1 - Math.abs(i) / 19) * k * (0.5 + n2 * 0.8);
            const c = fireCol2(h);
            fb.add(CASTER.x + 10 + i, CASTER.y + 3 + Math.round(n2 * 2 - 1), c[0], c[1], c[2], 1);
          }
          glow(fb, CASTER.x + 10, CASTER.y + 3, 16 * k, R("fire", 0.6), 0.8 * k);
        }
        if (t < 0.35) return;
        const n = this.SEGS;
        const eaten = this.impactT > 0 ? easeOut(seg(t, this.impactT, this.impactT + 0.26), 2) : 0;
        const bodyLen = lerp(40, 235, easeOut(emerge, 2)) * (strike ? lerp(1, 0.3, easeOut(seg(t, 4.55, 5), 2)) : 1) * (1 - eaten);
        if (bodyLen < 2) return this.renderImpact(fb, t, imp);
        const pts = [];
        for (let i = 0; i < n; i++) {
          const u = i / (n - 1);
          const idx = Math.min(399, Math.floor(u * bodyLen));
          const h = this.hist[idx];
          pts.push({ x: h.x, y: h.y });
        }
        const widthAt = (u) => {
          const headBulge = Math.exp(-u * u * 170) * (strike ? 14 * easeOut(seg(t, 4.75, 5.1)) : 0);
          const taper = Math.pow(1 - u, 0.85);
          const bulge = 1 + 0.3 * Math.sin(u * 22 - t * 9);
          return (1.1 + 11.5 * taper * bulge) * (0.4 + 0.6 * emerge) + headBulge;
        };
        ribbon(
          fb,
          pts,
          (u) => widthAt(u) * 1.8,
          (u, _i, e) => {
            const f = (1 - e) * (1 - e) * 0.085 * (1 - u * 0.6);
            return [f * 1, f * 0.2, f * 0.04];
          }
        );
        ribbon(
          fb,
          pts,
          (u) => widthAt(u),
          (u, i, e) => {
            const nz = fbm(u * 26 + t * 2.2, e * 3 + i * 0.3, 3);
            let h = Math.pow(1 - e * e, 1.7) * (0.34 + nz * 0.42) * (1 - u * 0.5) + 0.07 * (1 - e);
            const scale = Math.sin(u * 150 - t * 16) > 0.8 ? 0.16 : 0;
            h += scale * (1 - e) * (1 - u);
            if (h < 0.05) return null;
            return fireCol2(clamp(h * (0.45 + 0.55 * emerge)));
          }
        );
        ribbon(
          fb,
          pts,
          (u) => Math.max(0.35, widthAt(u) * 0.16),
          (u, _i, e) => {
            const h = (1 - e) * (1 - u * 0.9) * (0.55 + 0.45 * vnoise(u * 30, t * 6));
            if (h < 0.12) return null;
            return R("fire", 0.74 + h * 0.26);
          }
        );
        const hd = pts[0];
        const a0 = Math.atan2(hd.y - pts[2].y, hd.x - pts[2].x);
        const mawOpen = strike ? easeOut(seg(t, 4.7, 5.05), 2) : 0.08 + 0.06 * Math.sin(t * 6);
        for (let j = 0; j < 7; j++) {
          const sp = (j / 6 - 0.5) * mawOpen * 2.6;
          const len = 9 + mawOpen * 26;
          const ex = hd.x + Math.cos(a0 + sp) * len, ey = hd.y + Math.sin(a0 + sp) * len;
          streak(fb, hd.x, hd.y, ex, ey, 3 * (1 - mawOpen * 0.3), 0.7, fireCol2(0.66), 0.8);
        }
        flameBlob(fb, hd.x, hd.y, 7 + mawOpen * 9, t, 3.7, 0.85);
        glow(fb, hd.x, hd.y, 16 + mawOpen * 22, R("fire", 0.55), 0.3);
        fb.add(hd.x + Math.cos(a0 + 1.3) * 4, hd.y + Math.sin(a0 + 1.3) * 4, 3, 3, 2.6, 1);
        fb.add(hd.x + Math.cos(a0 - 1.3) * 4, hd.y + Math.sin(a0 - 1.3) * 4, 3, 3, 2.6, 1);
        for (const m of this.minis) {
          const k = clamp(m.life / m.max);
          ribbon(
            fb,
            m.h,
            (u) => 1.6 * (1 - u) * k,
            (u, _i, e) => fireCol2((1 - e) * (1 - u) * k * 1.1)
          );
        }
        this.embers.each((p) => {
          const l = p.life / p.max;
          streakP(fb, p, fireCol2(l * 0.9), l * 0.8);
        });
        this.renderImpact(fb, t, imp);
      }
      renderImpact(fb, t, imp) {
        {
          const A = ANCHORS[0];
          if (imp <= 0) return;
          const e = imp;
          fb.flash[0] += 0.55 * Math.pow(1 - clamp(e * 6), 2);
          fb.flash[1] += 0.22 * Math.pow(1 - clamp(e * 6), 2);
          {
            const u = clamp(e * 1.6);
            if (u < 1) {
              pulseRing(fb, A.x, A.y, 8 + easeOut(u, 2) * 150, 18 * (1 - u) + 3, R("fire", 0.42), 0.22 * Math.pow(1 - u, 2.2), 1.4, 0.4, 1.7);
              pulseRing(fb, A.x, A.y, 4 + easeOut(u, 2) * 96, 7 * (1 - u) + 2, R("fire", 0.72), 0.3 * Math.pow(1 - u, 2.2), 1.4, 0.3, 4.3);
            }
          }
          for (let i = 0; i < 20; i++) {
            const a = hash2(i, 7) * TAU;
            const sp = 40 + hash2(i, 9) * 130;
            const u = clamp(e * (0.8 + hash2(i, 11) * 1.4));
            const rr = easeOut(u, 2) * sp;
            const k = Math.pow(1 - u, 1.6);
            streak(
              fb,
              A.x + Math.cos(a) * rr * 0.72,
              A.y + Math.sin(a) * rr * 0.72 / 1.5,
              A.x + Math.cos(a) * rr,
              A.y + Math.sin(a) * rr / 1.5,
              2.4 * k,
              0.5,
              fireCol2(0.3 + 0.5 * k),
              0.9
            );
          }
          flameBlob(fb, A.x, A.y, 36 * Math.pow(1 - e, 0.8), t, 9.1, 1.1 * Math.pow(1 - e, 1.6), 1.5);
          heatShimmer(fb, A.x, A.y, 70, t, 4 * Math.pow(1 - e, 2));
        }
      }
    };
    MeteorLoom = class {
      rng = new RNG(16109);
      ms = [];
      frags = new Pool();
      dust = new Pool();
      scars = [];
      t = 0;
      constructor() {
        const r = this.rng;
        const targets = [
          { x: 150, y: 150, t0: 0.5, dur: 1.5, s: 11, arc: 1 },
          { x: 300, y: 90, t0: 1.6, dur: 0.6, s: 8, arc: -1.4 },
          { x: 240, y: 180, t0: 2.2, dur: 0.9, s: 13, arc: 0.6 },
          { x: 330, y: 160, t0: 2.9, dur: 0.55, s: 7, arc: -0.7 },
          { x: 196, y: 82, t0: 3.3, dur: 0.7, s: 9, arc: 1.2 },
          { x: 268, y: 124, t0: 3.9, dur: 0.6, s: 16, arc: 0.2 }
        ];
        for (const T of targets) {
          const a = r.angle();
          this.ms.push({
            x: T.x + Math.cos(a) * 420,
            y: T.y - 300 - r.range(0, 80),
            tx: T.x,
            ty: T.y,
            t0: T.t0,
            dur: T.dur,
            size: T.s,
            seed: r.int(0, 9999),
            arc: T.arc,
            split: r.next() < 0.5 ? 1 : 0,
            hit: 0
          });
        }
      }
      update(dt, t) {
        this.t = t;
        for (const m of this.ms) {
          const u = seg(t, m.t0, m.t0 + m.dur);
          if (u >= 1 && !m.hit) {
            m.hit = 1;
            const rng = new RNG(m.seed);
            const bs = [];
            for (let i = 0; i < 5 + Math.floor(m.size / 3); i++)
              bs.push(
                ...growBranches(rng, m.tx, m.ty, rng.angle(), m.size * 0.22, {
                  steps: 7,
                  step: m.size * 0.55,
                  wander: 0.5,
                  branchChance: 0.14,
                  maxDepth: 2,
                  widthFalloff: 0.55,
                  speed: 2.2
                })
              );
            this.scars.push({ x: m.tx, y: m.ty, bs, t0: t });
            for (let i = 0; i < 44; i++) {
              const a = rng.angle();
              const sp = rng.range(30, 210) * (m.size / 10);
              this.dust.spawn({
                x: m.tx,
                y: m.ty,
                vx: Math.cos(a) * sp,
                vy: Math.sin(a) * sp * 0.55 - rng.range(0, 70),
                life: rng.range(0.6, 2.2),
                size: rng.range(0.6, 2.4),
                k: rng.next(),
                seed: rng.next() * 999
              });
            }
          }
          if (u > 0 && u < 1 && this.rng.next() < 0.4) {
            const p = this.pos(m, u);
            this.frags.spawn({
              x: p.x,
              y: p.y,
              vx: this.rng.range(-50, 50),
              vy: this.rng.range(40, 150),
              life: this.rng.range(0.4, 1.1),
              size: this.rng.range(0.7, 2),
              seed: this.rng.next() * 999
            });
          }
        }
        this.frags.each((p) => p.vy += 160 * dt);
        this.frags.step(dt);
        this.dust.each((p) => {
          p.vy -= 30 * dt;
          p.vx *= Math.exp(-1.4 * dt);
          p.vy *= Math.exp(-1.2 * dt);
        });
        this.dust.step(dt);
        for (const s of this.scars) updateBranches(s.bs, t - s.t0);
      }
      pos(m, u) {
        const e = u * u * (3 - 2 * u) * 0.25 + u * 0.75;
        const x = lerp(m.x, m.tx, e);
        const y = lerp(m.y, m.ty, e) + Math.sin(u * Math.PI) * m.arc * 30;
        return { x, y };
      }
      casterLight(t) {
        let k = 0.2;
        for (const s of this.scars) k += 0.5 * (1 - seg(t, s.t0, s.t0 + 0.6));
        return clamp(k, 0, 2);
      }
      render(fb, t) {
        for (const s of this.scars) {
          const age = t - s.t0;
          let heat = 0.95 * Math.exp(-age * 0.55);
          for (const o of this.scars)
            if (o !== s && o.t0 > s.t0) heat += 0.75 * Math.exp(-Math.abs(t - o.t0) * 2.4);
          scarDecal(fb, s.bs, clamp(heat, 0, 1.3), t);
          glow(fb, s.x, s.y, 13 * clamp(heat), R("fire", 0.32), 0.2 * clamp(heat));
          heatShimmer(fb, s.x, s.y, 34, t, 1.6 * clamp(heat));
        }
        for (const m of this.ms) {
          const u = seg(t, m.t0, m.t0 + m.dur);
          if (u <= 0 || u >= 1) continue;
          const p = this.pos(m, u);
          const sr = lerp(m.size * 2.6, m.size * 0.9, u);
          for (let y = -sr; y <= sr; y++)
            for (let x = -sr * 1.6; x <= sr * 1.6; x++) {
              const d = Math.hypot(x / (sr * 1.6), y / sr);
              if (d > 1) continue;
              fb.mul(m.tx + x, m.ty + y + 4, lerp(0.45, 1, d * d));
            }
          glow(fb, m.tx, m.ty, lerp(10, 44, u * u), R("fire", 0.45), 0.25 + u * u * 0.9);
          for (let i = 1; i < 16; i++) {
            const uu = Math.max(0, u - i * 0.012);
            const q = this.pos(m, uu);
            const k = (1 - i / 16) * 0.8;
            glow(fb, q.x, q.y, m.size * (0.9 - i * 0.04), fireCol2(0.75 - i * 0.035), k);
          }
          const sz = m.size;
          field(fb, p.x - sz * 1.6, p.y - sz * 1.6, p.x + sz * 1.6, p.y + sz * 1.6, (x, y, o) => {
            const dx = x - p.x, dy = y - p.y;
            const d = Math.hypot(dx, dy);
            if (d > sz * 1.6) return;
            const a = Math.atan2(dy, dx);
            const surf = sz * (0.6 + 0.45 * vnoise(Math.cos(a) * 2 + m.seed, Math.sin(a) * 2));
            if (d > surf) return;
            const crack = vnoise(x * 0.5 + m.seed, y * 0.5);
            const core = 1 - d / surf;
            let h = core * 0.5 + (crack > 0.62 ? core * 0.9 : 0) + 0.06;
            const c = fireCol2(clamp(h));
            o[0] = c[0];
            o[1] = c[1];
            o[2] = c[2];
          });
        }
        this.frags.each((p) => {
          const l = p.life / p.max;
          streakP(fb, p, fireCol2(0.45 + l * 0.5), l);
        });
        this.dust.each((p) => {
          const l = p.life / p.max;
          const c = fireCol2(l * l * 0.75 * (0.4 + p.k));
          fb.add(p.x, p.y, c[0] * 0.8, c[1] * 0.7, c[2] * 0.7, l * 0.85);
        });
        const sig = seg(t, 4.75, 6.4);
        if (sig > 0 && this.scars.length >= 5) {
          const pts = this.scars.map((s) => ({ x: s.x, y: s.y }));
          const order = [0, 3, 1, 4, 2, 5, 0];
          const k = Math.sin(clamp(sig * 1.4) * Math.PI) * 1.4;
          for (let i = 0; i < order.length - 1; i++) {
            const a = pts[order[i] % pts.length], b = pts[order[i + 1] % pts.length];
            const draw = clamp((sig * 5.2 - i) * 1.6);
            if (draw <= 0) continue;
            const ex = lerp(a.x, b.x, draw), ey = lerp(a.y, b.y, draw);
            streak(fb, a.x, a.y, ex, ey, 2, 2, R("fire", 0.5), k * 0.5);
            line(fb, a.x, a.y, ex, ey, R("fire", 0.88), k * 0.9);
          }
          if (sig > 0.45) {
            const f = Math.sin(clamp(seg(t, 5.4, 6)) * Math.PI);
            for (const s of this.scars) glow(fb, s.x, s.y, 9 + f * 12, R("fire", 0.72), f * 0.5);
            pulseRing(fb, C.x, C.y, 40 + f * 190, 26, R("fire", 0.3), f * 0.12, 1.5, 0.16, 2.7);
            fb.flash[0] += f * 0.1;
            fb.flash[1] += f * 0.035;
          }
        }
      }
    };
    AshenGuillotine = class {
      rng = new RNG(42465);
      embers = new Pool();
      sections = [];
      plates = [];
      veins = [];
      cutY = 132;
      cutA = -0.17;
      CUT_T = 3.52;
      constructor() {
        const r = this.rng;
        let x = 24;
        while (x < 404) {
          const w = r.range(18, 52);
          this.sections.push({
            x0: x,
            x1: Math.min(404, x + w),
            delay: r.range(0, 0.75),
            depth: r.range(0.5, 1),
            seed: r.int(0, 9999)
          });
          x += w;
        }
        for (let i = 0; i < 26; i++) {
          const px = r.range(30, 390);
          this.plates.push({
            x: px,
            y: this.cutY + (px - 208) * Math.tan(this.cutA) + r.range(-6, 6),
            vx: r.range(-20, 20),
            vy: r.sign() * r.range(18, 70),
            r: r.range(4, 13),
            a: r.angle(),
            av: r.range(-2, 2),
            seed: r.int(0, 9999)
          });
        }
        const vr = new RNG(991);
        for (let i = 0; i < 16; i++) {
          const px = vr.range(40, 380);
          const py = this.cutY + (px - 208) * Math.tan(this.cutA);
          this.veins.push(
            ...growBranches(vr, px, py, vr.sign() * (Math.PI / 2) + vr.range(-0.5, 0.5), 1.4, {
              steps: 6,
              step: 5,
              wander: 0.55,
              branchChance: 0.2,
              maxDepth: 2,
              widthFalloff: 0.6,
              speed: 1.1
            })
          );
        }
      }
      lineY(x) {
        return this.cutY + (x - 208) * Math.tan(this.cutA);
      }
      update(dt, t) {
        const post = t - this.CUT_T;
        if (post > 0) updateBranches(this.veins, post - 0.35);
        if (post > 0.1 && post < 2) {
          for (const s of this.sections) {
            if (post < 0.35 + s.delay) continue;
            if (this.rng.next() < 0.25) {
              const x = this.rng.range(s.x0, s.x1);
              this.embers.spawn({
                x,
                y: this.lineY(x),
                vx: this.rng.range(-18, 18),
                vy: -this.rng.range(30, 150) * s.depth,
                life: this.rng.range(0.6, 1.8),
                size: this.rng.range(0.6, 2),
                k: s.depth,
                seed: this.rng.next() * 999
              });
            }
          }
        }
        if (t < this.CUT_T && t > 0.25) {
          if (this.rng.next() < 0.7) {
            const a = this.rng.angle();
            const d = this.rng.range(30, 150);
            this.embers.spawn({
              x: 208 + Math.cos(a) * d,
              y: this.cutY + Math.sin(a) * d * 0.7,
              vx: 0,
              vy: 0,
              life: 2.2,
              size: 1,
              k: 0.4,
              tag: 1,
              seed: this.rng.next() * 999
            });
          }
        }
        this.embers.each((p) => {
          if (p.tag === 1) {
            const dx = 208 - p.x, dy = this.cutY - p.y;
            const d = Math.hypot(dx, dy) || 1;
            p.vx += dx / d * 26 * dt;
            p.vy += dy / d * 26 * dt;
            p.vx *= Math.exp(-0.9 * dt);
            p.vy *= Math.exp(-0.9 * dt);
          } else {
            p.vy += 24 * dt;
            p.vx *= Math.exp(-1.2 * dt);
          }
        });
        this.embers.step(dt);
        if (post > 0) {
          for (const pl of this.plates) {
            const k = clamp(post / 0.6);
            pl.x += pl.vx * dt * k;
            pl.y += pl.vy * dt * k * 0.5;
            pl.a += pl.av * dt * k;
            pl.vx *= Math.exp(-1.6 * dt);
            pl.vy *= Math.exp(-1.6 * dt);
          }
        }
      }
      casterLight(t) {
        return 0.1 + 0.3 * seg(t, 2.2, 3.4) + 1.3 * (1 - seg(t, this.CUT_T, this.CUT_T + 0.5));
      }
      render(fb, t) {
        const pre = seg(t, 0.2, 2.2);
        const mass = seg(t, 2.15, this.CUT_T);
        const post = t - this.CUT_T;
        if (t < this.CUT_T + 0.2) {
          const k = pre * 0.8;
          fieldMul(fb, 100, 20, 320, 230, (x, y) => {
            const d = Math.hypot((x - 208) / 110, (y - this.cutY) / 100);
            return lerp(1, lerp(0.25, 1, clamp(d)), k);
          });
        }
        if (t < this.CUT_T) {
          const h = lerp(14, 150, easeOut(pre, 2));
          const w = lerp(0.55, 2.2, mass);
          for (let y = -h / 2; y <= h / 2; y++) {
            const f = (1 - Math.abs(y) / (h / 2)) * (0.55 + pre * 0.9);
            const flick = 0.7 + 0.3 * vnoise(y * 0.3, t * 9);
            const c = R("fire", 0.88 + 0.12 * flick);
            for (let x = -w; x <= w; x++)
              fb.add(208 + x, this.cutY + y, c[0], c[1], c[2], f * (1 - Math.abs(x) / (w + 1)) * flick);
          }
          glow(fb, 208, this.cutY, 12 + pre * 26, R("fire", 0.72), 0.25 + pre * 0.4);
        }
        if (mass > 0 && t < this.CUT_T) {
          const m = easeOut(mass, 1.6);
          const halfLen = 190 * m;
          const halfW = lerp(1, 26, m);
          const cy = this.cutY - lerp(0, 0, 0);
          field(fb, 208 - halfLen - 8, cy - halfW - 10, 208 + halfLen + 8, cy + halfW + 10, (x, y, o) => {
            const dx = x - 208, dy = y - cy - dx * Math.tan(this.cutA);
            if (Math.abs(dx) > halfLen) return;
            const edge = Math.abs(dy) / halfW;
            if (edge > 1) return;
            const taper = 1 - Math.pow(Math.abs(dx) / halfLen, 2.4);
            const bandn = vnoise(dx * 0.06, dy * 0.3 + t * 1.4);
            const bandv = Math.abs(Math.sin(dy * 0.5 + bandn * 3.4 + dx * 0.012));
            const gap = vnoise(dx * 0.1 + 20, dy * 0.08 - t * 0.7) > 0.58 ? 0 : 1;
            let h = (1 - edge * edge) * taper * (0.35 + bandv * 0.55) * gap;
            if (!gap && Math.abs(dy) < halfW * 0.4) h = taper * 0.95 * (0.4 + 0.6 * bandn);
            h *= m * 1.15;
            if (h < 0.05) return;
            const c = fireCol2(clamp(h));
            o[0] = c[0];
            o[1] = c[1];
            o[2] = c[2];
          });
          for (let dx = -halfLen; dx <= halfLen; dx += 1) {
            const taper = 1 - Math.pow(Math.abs(dx) / halfLen, 2.4);
            const yy = cy + dx * Math.tan(this.cutA);
            const hw = halfW * taper + vnoise(dx * 0.2, t * 2) * 2;
            const c = R("fire", 0.95);
            fb.add(208 + dx, yy - hw, c[0], c[1], c[2], 0.7 * m);
            fb.add(208 + dx, yy + hw, c[0], c[1], c[2], 0.7 * m);
          }
          if (t > this.CUT_T - 0.18) {
            fb.exposure *= lerp(1, 0.45, seg(t, this.CUT_T - 0.18, this.CUT_T));
          }
        }
        if (post > 0 && post < 0.3) {
          const k = 1 - post / 0.3;
          for (let dx = -200; dx <= 200; dx++) {
            const yy = this.lineY(208 + dx);
            const taper = 1 - Math.pow(Math.abs(dx) / 200, 3);
            const w = (1 + 5 * k) * taper;
            for (let o = -w; o <= w; o += 0.5) {
              const f = Math.pow(1 - Math.abs(o) / (w + 0.5), 2) * k * taper;
              const c = R("fire", 0.8 + 0.2 * f);
              fb.add(208 + dx, yy + o, c[0], c[1], c[2], f * 0.6);
            }
            fb.add(208 + dx, yy, 3, 2.8, 2.4, k * taper);
          }
        }
        if (post > 0) {
          for (const s of this.sections) {
            const open = clamp((post - 0.12 - s.delay) * 1.5);
            if (open <= 0) continue;
            const decay = Math.exp(-Math.max(0, post - 1.2 - s.delay) * 0.7);
            const w = open * 9 * s.depth * decay + 1;
            for (let x = s.x0; x <= s.x1; x++) {
              const yy = this.lineY(x);
              const nz = vnoise(x * 0.14 + s.seed, t * 0.6);
              const ww = w * (0.6 + nz * 0.8);
              for (let dy = -ww; dy <= ww; dy++) {
                const e = Math.abs(dy) / ww;
                const strat = 1 - e;
                const deep = vnoise(x * 0.3 + s.seed, dy * 0.4 - t * 2.2);
                let h = strat * (0.55 + deep * 0.7) * decay * s.depth * 1.25;
                if (e > 0.88) h *= 0.25;
                const c = fireCol2(clamp(h));
                fb.add(x, yy + dy, c[0], c[1], c[2], 1);
              }
            }
            if (open > 0.4)
              glow(fb, (s.x0 + s.x1) / 2, this.lineY((s.x0 + s.x1) / 2), 16 * s.depth * decay, R("fire", 0.5), 0.5 * decay);
          }
          for (const b of this.veins)
            drawBranch(
              fb,
              b,
              (u, e) => {
                const decay = Math.exp(-Math.max(0, post - 1.6) * 0.8);
                const flick = 0.72 + 0.28 * vnoise(u * 20 + b.seed, post * 4);
                const h = Math.pow(1 - e, 1.4) * (1 - u * 0.75) * decay * 1.05 * flick;
                if (h < 0.04) return null;
                return fireCol2(h);
              },
              (u, bb) => Math.max(0.5, bb.w * (1 - u * 0.7))
            );
          for (const pl of this.plates) {
            const k = clamp(post / 0.5) * Math.exp(-Math.max(0, post - 1.4) * 0.9);
            if (k < 0.03) continue;
            field(fb, pl.x - pl.r, pl.y - pl.r, pl.x + pl.r, pl.y + pl.r, (x, y, o) => {
              const dx = x - pl.x, dy = y - pl.y;
              const d = Math.hypot(dx, dy);
              if (d > pl.r) return;
              const a = Math.atan2(dy, dx) + pl.a;
              const surf = pl.r * (0.55 + 0.42 * vnoise(Math.cos(a) * 2 + pl.seed, Math.sin(a) * 2));
              if (d > surf) return;
              const crust = vnoise(x * 0.5 + pl.seed, y * 0.5);
              const lip = clamp(1 - (surf - d) / 1.6) * (dy > 0 ? 1 : 0) * (crust > 0.45 ? 1 : 0);
              let h = 0.04 + lip * 0.3 + (crust > 0.68 ? 0.3 : 0) * (1 - d / surf);
              const c = fireCol2(h * k);
              o[0] = c[0] * 0.85;
              o[1] = c[1] * 0.8;
              o[2] = c[2] * 0.8;
            });
          }
          heatShimmer(fb, 208, this.cutY, 170, t, 3.4 * Math.exp(-post * 0.8));
          const sc = Math.exp(-Math.max(0, post - 2) * 0.45);
          for (let x = 24; x < 404; x++) {
            const yy = this.lineY(x);
            const nz = vnoise(x * 0.2, 5);
            const c = fireCol2(0.28 * sc * (0.5 + nz));
            fb.add(x, yy + Math.round(nz * 1.6 - 0.8), c[0], c[1], c[2], 0.9);
            fb.mul(x, yy + 2, lerp(0.5, 1, 1 - sc));
          }
        }
        this.embers.each((p) => {
          const l = p.life / p.max;
          const c = fireCol2(l * (0.4 + p.k * 0.7));
          streakP(fb, p, c, l * 0.9);
        });
      }
    };
  }
});

// src/spells/tide.ts
function sheet(fb, us, vs, pos, col, alpha = 1) {
  for (let i = 0; i <= us; i++) {
    const u = i / us;
    for (let j = 0; j <= vs; j++) {
      const v = j / vs * 2 - 1;
      const c = col(u, v);
      if (!c) continue;
      const p = pos(u, v);
      fb.add(p[0], p[1], c[0], c[1], c[2], alpha);
    }
  }
}
var C2, SQ, AbyssalBloom, RiptideCalligraphy, MirrorfrostBasilica, UndertowMaw;
var init_tide = __esm({
  "src/spells/tide.ts"() {
    "use strict";
    init_particles();
    init_draw();
    init_math();
    init_arena();
    init_common();
    C2 = ARENA_C;
    SQ = 1.5;
    AbyssalBloom = class {
      rng = new RNG(45312);
      petals = [];
      inner = [];
      bubbles = [];
      drops = new Pool();
      BURST = 5;
      constructor() {
        const r = this.rng;
        for (let i = 0; i < 7; i++)
          this.petals.push({
            a: i / 7 * TAU + r.range(-0.05, 0.05),
            len: r.range(58, 82),
            w: r.range(0.42, 0.62),
            curl: r.range(-0.5, 0.5),
            delay: r.range(0, 0.4),
            twist: r.range(-0.3, 0.3)
          });
        for (let i = 0; i < 7; i++)
          this.inner.push({
            a: i / 7 * TAU + Math.PI / 7,
            len: r.range(28, 44),
            w: r.range(0.3, 0.48),
            delay: r.range(0.3, 0.9)
          });
        for (let i = 0; i < 46; i++)
          this.bubbles.push({
            a: r.angle(),
            r: r.range(6, 52),
            sp: r.range(0.5, 2.2) * r.sign(),
            z: r.next(),
            s: r.range(0.5, 1.6)
          });
      }
      update(dt, t) {
        if (t > this.BURST && t < this.BURST + 0.5 && this.drops.count() < 420) {
          for (let i = 0; i < 26; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(60, 300);
            this.drops.spawn({
              x: C2.x + Math.cos(a) * this.rng.range(10, 60),
              y: C2.y + Math.sin(a) * this.rng.range(10, 60) / SQ,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp / SQ,
              life: this.rng.range(0.8, 2.3),
              size: this.rng.range(0.6, 2.2),
              k: this.rng.next(),
              seed: this.rng.next() * 999
            });
          }
        }
        this.drops.each((p) => {
          const age = 1 - p.life / p.max;
          if (age > 0.45) {
            const dx = C2.x - p.x, dy = C2.y - p.y;
            const d = Math.hypot(dx, dy) || 1;
            p.vx += dx / d * 170 * dt;
            p.vy += dy / d * 170 * dt;
          }
          p.vx *= Math.exp(-1.1 * dt);
          p.vy *= Math.exp(-1.1 * dt);
        });
        this.drops.step(dt);
      }
      casterLight(t) {
        return 0.2 + 0.4 * seg(t, 0, 3) + 1 * (1 - seg(t, this.BURST, this.BURST + 0.6));
      }
      render(fb, t) {
        const ring = seg(t, 0, 1);
        const grow = seg(t, 0.8, 3.6);
        const freeze = smoothstep(4.3, 4.6, t) * (1 - smoothstep(this.BURST, this.BURST + 0.05, t));
        const burst = seg(t, this.BURST, this.BURST + 1.9);
        const open = burst > 0 ? 1 + easeOut(burst, 2) * 0.9 : 1;
        const fade = 1 - clamp(burst * 1.5);
        if (fade > 0 || burst > 0) {
          const rr = lerp(10, 40, easeOut(ring, 2)) * (1 + burst * 2.2);
          const k = (0.8 - burst * 0.5) * (ring > 0 ? 1 : 0);
          if (k > 0)
            field(fb, C2.x - rr * 1.6, C2.y - rr * 1.6 / SQ, C2.x + rr * 1.6, C2.y + rr * 1.6 / SQ, (x, y, o) => {
              const dx = x + 0.5 - C2.x, dy = (y + 0.5 - C2.y) * SQ;
              const d = Math.hypot(dx, dy);
              if (d > rr * 1.5) return;
              const w = Math.sin(d * 0.55 - t * 3.4 + fbm(dx * 0.05, dy * 0.05 + t * 0.3, 3) * 4);
              const edge = clamp(1 - Math.abs(d - rr) / (rr * 0.55));
              const h = (0.28 + w * 0.3) * edge * k;
              if (h <= 0.02) return;
              const c = rampStep("water", clamp(h * 1.6), 7);
              o[0] = c[0];
              o[1] = c[1];
              o[2] = c[2];
            });
        }
        const drawPetal = (a0, len, wk, curl2, g, depthTint, twist) => {
          const L = len * g * open;
          if (L < 2) return;
          sheet(
            fb,
            Math.max(8, Math.ceil(L * 1.1)),
            Math.max(6, Math.ceil(L * wk * 1.3)),
            (u, v) => {
              const a = a0 + curl2 * u * u + Math.sin(t * 1.3 + u * 3 + a0) * 0.08 * twist;
              const rr = L * u;
              const wid = L * wk * Math.sin(Math.pow(u, 0.65) * Math.PI) * (1 - burst * 0.2);
              const rip = Math.sin(u * 7 - t * 4 + a0 * 3) * 2.2 * u + fbm(u * 5 + a0, t * 0.9, 2) * 3 * u;
              const px = C2.x + Math.cos(a) * rr - Math.sin(a) * (v * wid + rip * v * 0.3);
              const py = C2.y + (Math.sin(a) * rr + Math.cos(a) * (v * wid + rip * v * 0.3)) / SQ - u * u * 6 * g;
              return [px, py];
            },
            (u, v) => {
              const av = Math.abs(v);
              if (av > 1) return null;
              const flow = fbm(u * 6 - t * 1.6, v * 3 + a0 * 2, 3);
              let h = 0.26 + flow * 0.3;
              h += Math.pow(av, 3) * 0.55;
              h *= 1 - u * 0.25;
              h *= depthTint;
              h *= fade;
              if (freeze > 0) h += freeze * 0.18;
              if (h < 0.04) return null;
              const c = rampStep("water", clamp(h), 8);
              return [c[0] * 0.5, c[1] * 0.5, c[2] * 0.5];
            },
            1
          );
          if (fade > 0.2) {
            for (let i = 0; i < 5; i++) {
              const u = 0.55 + hash2(i, Math.floor(a0 * 97)) * 0.45;
              const ph = t * 2 + i;
              const a = a0 + curl2 * u * u;
              const wid = L * wk * Math.sin(Math.pow(u, 0.65) * Math.PI);
              const s = Math.sin(ph) > 0 ? 1 : -1;
              const px = C2.x + Math.cos(a) * L * u - Math.sin(a) * s * (wid + 2 + ph % 1 * 5);
              const py = C2.y + (Math.sin(a) * L * u + Math.cos(a) * s * (wid + 2 + ph % 1 * 5)) / SQ;
              fb.add(px, py, 1.1, 1.8, 2.2, 0.5 * fade * (1 - ph % 1));
            }
          }
        };
        for (const p of this.petals) {
          const g = easeOut(clamp((grow - p.delay * 0.25) / 0.8), 2);
          drawPetal(p.a, p.len, p.w, p.curl, g, 1, p.twist);
        }
        for (const p of this.inner) {
          const g = easeOut(clamp((grow - p.delay * 0.4) / 0.7), 2);
          drawPetal(p.a, p.len, p.w, -0.35, g, 1.35, 0.6);
        }
        if (fade > 0.1)
          for (const b of this.bubbles) {
            const a = b.a + b.sp * t * (0.4 + b.z);
            const rr = b.r * (0.4 + grow * 0.75) * open;
            const x = C2.x + Math.cos(a) * rr;
            const y = C2.y + Math.sin(a) * rr / SQ - b.z * 8 * grow;
            const k = (0.25 + b.z * 0.6) * fade;
            fb.add(x, y, 0.5, 1.1, 1.6, k);
            if (b.s > 1.2) fb.add(x, y - 1, 1.2, 1.9, 2.3, k * 0.6);
          }
        if (freeze > 0) {
          glow(fb, C2.x, C2.y, 34, [0.5, 1, 1.5], 0.5 * freeze);
          for (let i = 0; i < 90; i++) {
            const a = i / 90 * TAU;
            const rr = 64 + Math.sin(a * 7) * 4;
            fb.add(C2.x + Math.cos(a) * rr, C2.y + Math.sin(a) * rr / SQ, 1, 1.7, 2.1, 0.45 * freeze);
          }
        }
        if (burst > 0 && burst < 1) {
          const e = burst;
          pulseRing(fb, C2.x, C2.y, 10 + e * 210, 10 * (1 - e), [0.7, 1.5, 2], 1.2 * (1 - e), SQ);
          pulseRing(fb, C2.x, C2.y, 4 + e * 120, 5 * (1 - e), [1.4, 2, 2.4], 1 * (1 - e), SQ);
          fb.flash[2] += 0.26 * Math.pow(1 - clamp(e * 7), 2);
          fb.flash[1] += 0.16 * Math.pow(1 - clamp(e * 7), 2);
          for (let i = 0; i < 9; i++) {
            const a = i / 9 * TAU + 0.3;
            const L = easeOut(e, 2) * 160;
            const pts = [];
            for (let s = 0; s <= 8; s++) {
              const u = s / 8;
              const aa = a + Math.sin(u * 2.2 + i) * 0.35;
              pts.push({ x: C2.x + Math.cos(aa) * L * u, y: C2.y + Math.sin(aa) * L * u / SQ });
            }
            ribbon(
              fb,
              pts,
              (u) => 10 * Math.sin(Math.pow(u, 0.7) * Math.PI) * (1 - e * 0.5),
              (u, _i, edge) => {
                const h = (0.3 + Math.pow(edge, 3) * 0.7) * (1 - e) * (1 - u * 0.4);
                if (h < 0.05) return null;
                const c = rampStep("water", clamp(h * 1.3), 7);
                return [c[0] * 0.55, c[1] * 0.55, c[2] * 0.55];
              }
            );
          }
        }
        this.drops.each((p) => {
          const l = p.life / p.max;
          const c = rampStep("water", 0.45 + l * 0.5, 7);
          streakP(fb, p, [c[0] * 0.8, c[1] * 0.8, c[2] * 0.9], l * 0.8);
        });
      }
    };
    RiptideCalligraphy = class {
      rng = new RNG(31261);
      strokes = [];
      knots = [];
      spray = new Pool();
      WAVE = 5.1;
      constructor() {
        const S = (pts, t02, dur, w) => ({
          ctrl: pts.map((p) => ({ x: p[0], y: p[1] })),
          t0: t02,
          dur,
          w,
          seed: this.rng.int(0, 999)
        });
        this.strokes = [
          S([[CASTER.x + 12, CASTER.y - 10], [150, 110], [210, 74], [286, 72], [340, 104]], 0.35, 0.95, 5),
          S([[352, 60], [300, 108], [252, 150], [236, 196], [286, 206]], 1.25, 0.8, 4.2),
          S([[150, 186], [196, 150], [250, 120], [300, 150], [268, 190], [214, 178]], 2, 1, 3.6),
          S([[120, 60], [190, 96], [258, 130], [330, 176], [372, 200]], 2.95, 0.42, 5.4),
          S([[330, 46], [286, 96], [300, 150], [350, 148], [330, 96], [268, 60]], 3.4, 0.95, 3.2),
          S([[96, 150], [160, 200], [240, 212], [320, 190]], 4.2, 0.55, 4.6)
        ];
        for (let i = 0; i < this.strokes.length; i++)
          for (let j = i + 1; j < this.strokes.length; j++) {
            const A = this.sample(this.strokes[i], 40);
            const B = this.sample(this.strokes[j], 40);
            for (let a = 0; a < A.length; a += 2)
              for (let b = 0; b < B.length; b += 2) {
                if (Math.hypot(A[a].x - B[b].x, A[a].y - B[b].y) < 5) {
                  const t02 = Math.max(
                    this.strokes[i].t0 + a / A.length * this.strokes[i].dur,
                    this.strokes[j].t0 + b / B.length * this.strokes[j].dur
                  );
                  if (!this.knots.some((k) => Math.hypot(k.x - A[a].x, k.y - A[a].y) < 16))
                    this.knots.push({ x: A[a].x, y: A[a].y, t0: t02, a: this.rng.angle() });
                }
              }
          }
      }
      sample(s, n) {
        const out = [];
        for (let i = 0; i <= n; i++) out.push(catmull(s.ctrl, i / n));
        return out;
      }
      update(dt, t) {
        for (const s of this.strokes) {
          const u = seg(t, s.t0, s.t0 + s.dur);
          if (u > 0 && u < 1 && this.rng.next() < 0.75) {
            const p = catmull(s.ctrl, u);
            const q = catmull(s.ctrl, Math.max(0, u - 0.04));
            const a = Math.atan2(p.y - q.y, p.x - q.x) + this.rng.range(-1.2, 1.2);
            const sp = this.rng.range(20, 90);
            this.spray.spawn({
              x: p.x,
              y: p.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp * 0.6,
              life: this.rng.range(0.3, 0.9),
              size: 1,
              seed: this.rng.next() * 99
            });
          }
        }
        this.spray.each((p) => {
          p.vx *= Math.exp(-2.2 * dt);
          p.vy *= Math.exp(-2.2 * dt);
        });
        this.spray.step(dt);
      }
      casterLight(t) {
        return 0.3 + 0.3 * Math.sin(t * 5) + 1 * (1 - seg(t, this.WAVE, this.WAVE + 0.8));
      }
      render(fb, t) {
        const charge = seg(t, 4.75, this.WAVE);
        const waves = seg(t, this.WAVE, this.WAVE + 1.7);
        for (let si = 0; si < this.strokes.length; si++) {
          const s = this.strokes[si];
          const u = clamp(seg(t, s.t0, s.t0 + s.dur));
          if (u <= 0) continue;
          const n = 56;
          const pts = [];
          for (let i = 0; i <= n; i++) {
            const uu = i / n * u;
            const p = catmull(s.ctrl, uu);
            const lag = Math.sin(uu * 9 - t * 5 + si) * 1.6 * (1 - uu);
            pts.push({ x: p.x, y: p.y + lag });
          }
          const dissolve = waves > 0 ? 1 - clamp(waves * 1.6) : 1;
          const energy = charge > 0 ? charge : 0;
          ribbon(
            fb,
            pts,
            (uu) => s.w * (0.35 + Math.sin(Math.pow(uu, 0.8) * Math.PI) * 0.95) * (1 + energy * 0.4),
            (uu, _i, edge) => {
              const head = clamp((uu - (u - 0.07)) / 0.07);
              const flow = fbm(uu * 14 - t * 2.4 + s.seed, edge * 3, 3);
              let h = 0.24 + flow * 0.3;
              h += Math.pow(edge, 2.6) * 0.65;
              h += head * 0.5;
              if (energy > 0) {
                const pulse = Math.sin(uu * 18 - t * 26 + si * 2);
                h += Math.max(0, pulse) * energy * 0.7;
              }
              h *= dissolve;
              if (h < 0.05) return null;
              const c = rampStep("water", clamp(h), 8);
              return [c[0] * 0.55, c[1] * 0.55, c[2] * 0.6];
            }
          );
        }
        for (const k of this.knots) {
          const age = t - k.t0;
          if (age < 0) continue;
          const kk = clamp(age * 2) * (waves > 0 ? 1 - clamp(waves * 2) : 1);
          if (kk <= 0) continue;
          for (let i = 0; i < 3; i++) {
            const a = k.a + t * (1.6 + i * 0.7) + i / 3 * TAU;
            const rr = 2.5 + i * 1.6 + Math.sin(t * 3 + i) * 0.8;
            for (let s = 0; s < 14; s++) {
              const aa = a + s / 14 * 2.4;
              const r2 = rr * (1 - s / 26);
              const c = rampStep("water", 0.55 + 0.35 * (1 - s / 14), 7);
              fb.add(k.x + Math.cos(aa) * r2, k.y + Math.sin(aa) * r2 / 1.2, c[0] * 0.7, c[1] * 0.7, c[2] * 0.7, kk * 0.8);
            }
          }
          glow(fb, k.x, k.y, 5, [0.5, 1.1, 1.6], 0.4 * kk);
        }
        if (waves > 0) {
          for (let w = 0; w < 3; w++) {
            const u = clamp((waves - w * 0.14) * 1.5);
            if (u <= 0 || u >= 1) continue;
            const ang = -0.5 + w * 0.55;
            const dirx = Math.cos(ang), diry = Math.sin(ang) * 0.5;
            const travel = lerp(-60, 480, easeOut(u, 1.6));
            const ox = 20 + dirx * travel, oy = 60 + diry * travel + w * 40;
            const k = Math.sin(u * Math.PI) * 1.2;
            for (let i = -70; i <= 70; i++) {
              const curve = i * i / 300;
              const px = ox - curve * dirx * 1.4 - diry * i * 1.6;
              const py = oy - curve * diry + dirx * i * 1;
              const h = (1 - Math.abs(i) / 72) * k;
              for (let d = 0; d < 16; d++) {
                const f = (1 - d / 16) * h;
                const c = rampStep("water", clamp(0.25 + f * 0.8), 8);
                fb.add(px - dirx * d * 1.6, py - diry * d * 1.6, c[0] * 0.5 * f, c[1] * 0.5 * f, c[2] * 0.55 * f, 1);
              }
              fb.add(px, py, 1.3, 2, 2.4, h * 0.9);
            }
          }
          fb.flash[2] += 0.12 * Math.pow(1 - clamp(waves * 4), 2);
        }
        this.spray.each((p) => {
          const l = p.life / p.max;
          fb.add(p.x, p.y, 0.7 * l, 1.3 * l, 1.8 * l, l * 0.7);
        });
      }
    };
    MirrorfrostBasilica = class {
      rng = new RNG(61957);
      pieces = [];
      frost = [];
      cracks = [];
      glitter = new Pool();
      BREAK = 5.2;
      constructor() {
        const r = this.rng;
        const grow = (x, y, a, len, d, delay) => {
          this.frost.push({ x, y, a, len, delay, depth: d });
          if (d > 3) return;
          const ex = x + Math.cos(a) * len, ey = y + Math.sin(a) * len / SQ;
          const kids = d < 2 ? 3 : 2;
          for (let i = 0; i < kids; i++) {
            const na = a + (i - (kids - 1) / 2) * (Math.PI / 3) + r.range(-0.1, 0.1);
            grow(ex, ey, na, len * r.range(0.55, 0.78), d + 1, delay + len * 0.028);
          }
        };
        for (let i = 0; i < 6; i++) grow(C2.x, C2.y, i / 6 * TAU, 26, 0, 0);
        for (let tier = 0; tier < 4; tier++) {
          const count = [1, 6, 9, 12][tier];
          const rad = [0, 36, 74, 112][tier];
          for (let i = 0; i < count; i++) {
            const a = i / count * TAU + tier * 0.26;
            this.pieces.push({
              x: C2.x + Math.cos(a) * rad,
              y: C2.y + Math.sin(a) * rad / SQ,
              r: [30, 21, 17, 13][tier] * r.range(0.85, 1.15),
              sides: tier === 0 ? 6 : r.int(4, 6),
              a: a + r.range(-0.4, 0.4),
              seed: r.int(0, 9999),
              tier,
              delay: 1 + tier * 0.55 + i / count * 0.5 + r.range(0, 0.18),
              vx: Math.cos(a) * r.range(30, 110),
              vy: Math.sin(a) * r.range(30, 110) / SQ,
              av: r.range(-5, 5),
              broken: 0
            });
          }
        }
        for (let i = 0; i < 5; i++) {
          const a = i / 5 * TAU + 0.4;
          this.pieces.push({
            x: C2.x + Math.cos(a) * 88,
            y: C2.y + Math.sin(a) * 88 / SQ - 18,
            r: 13,
            sides: 4,
            a,
            seed: r.int(0, 9999),
            tier: 4,
            delay: 3 + i * 0.16,
            vx: Math.cos(a) * 60,
            vy: -r.range(40, 90),
            av: r.range(-4, 4),
            broken: 0
          });
        }
      }
      update(dt, t) {
        const post = t - this.BREAK;
        if (post > 0) {
          for (const p of this.pieces) {
            const d = Math.hypot(p.x - C2.x - 40, p.y - C2.y);
            const trig = d * 4e-3;
            if (post > trig) {
              if (p.broken === 0) {
                p.vx *= 2.2;
                p.vy *= 2.2;
              }
              p.broken = Math.min(1, p.broken + dt * 3.2);
              p.vx *= Math.exp(-1.8 * dt);
              p.vy *= Math.exp(-1.8 * dt);
              p.x += p.vx * dt;
              p.y += p.vy * dt;
              p.vy += 60 * dt;
              p.a += p.av * dt;
              if (p.broken < 0.2 && this.rng.next() < 0.6)
                for (let i = 0; i < 4; i++) {
                  const a = this.rng.angle();
                  const sp = this.rng.range(30, 140);
                  this.glitter.spawn({
                    x: p.x,
                    y: p.y,
                    vx: Math.cos(a) * sp,
                    vy: Math.sin(a) * sp * 0.6,
                    life: this.rng.range(0.4, 1.5),
                    size: 1,
                    seed: this.rng.next() * 99
                  });
                }
            }
          }
        }
        if (t > 4.2 && t < this.BREAK && this.cracks.length < 60 && this.rng.next() < 0.5) {
          const p = this.pieces[this.rng.int(0, this.pieces.length - 1)];
          this.cracks.push({ x: p.x, y: p.y, a: this.rng.angle(), len: this.rng.range(4, 14), t0: t });
        }
        this.glitter.each((p) => p.vy += 90 * dt);
        this.glitter.step(dt, 1.2);
      }
      casterLight(t) {
        return 0.25 + 0.4 * seg(t, 0, 3) + 1 * (1 - seg(t, this.BREAK, this.BREAK + 0.6));
      }
      render(fb, t) {
        const post = t - this.BREAK;
        for (const f of this.frost) {
          const u = clamp((t - 0.1 - f.delay) * 2.2);
          if (u <= 0) continue;
          const fade = post > 0 ? 1 - clamp(post * 0.5) : 1;
          const ex = f.x + Math.cos(f.a) * f.len * u, ey = f.y + Math.sin(f.a) * f.len * u / SQ;
          const c = rampStep("frost", 0.45 + (3 - f.depth) * 0.1, 7);
          line(fb, f.x, f.y, ex, ey, [c[0] * 0.7, c[1] * 0.7, c[2] * 0.8], 0.8 * fade);
          if (f.depth >= 2) {
            const c2 = rampStep("frost", 0.7, 7);
            fb.add(ex, ey, c2[0] * 0.6, c2[1] * 0.6, c2[2] * 0.6, 0.7 * fade);
          }
        }
        for (const p of this.pieces) {
          if (p.delay > t) continue;
          const g = clamp((t - p.delay) * 1.6);
          if (p.broken > 0.5) continue;
          for (let i = 1; i < 40; i++) {
            const k = (1 - i / 40) * 0.13 * g;
            const c = rampStep("frost", 0.45, 6);
            fb.add(p.x + i * 0.8, p.y + i * 1.4, c[0] * k, c[1] * k, c[2] * k, 1);
          }
        }
        for (const p of this.pieces) {
          if (p.delay > t) continue;
          const g = clamp(backOut((t - p.delay) * 1.5, 2.4));
          if (g <= 0) continue;
          const fade = 1 - clamp((p.broken - 0.55) / 0.45);
          if (fade <= 0) continue;
          const pulse = 0.5 + 0.5 * Math.sin(t * 3.4 - p.tier * 1.1 - Math.hypot(p.x - C2.x, p.y - C2.y) * 0.05);
          shard(
            fb,
            p.x,
            p.y - (p.tier === 4 ? 10 * g : 0),
            p.r * g,
            p.a,
            p.sides,
            p.seed,
            (d, edge) => {
              const facet = 0.1 + 0.36 * Math.pow(1 - d, 1.5) + 0.14 * Math.sin(d * 9 + p.a * 3);
              let h = facet + pulse * 0.14 * (1 - d);
              if (edge < 1.1 || d > 0.86) h = 0.88;
              h *= fade;
              if (t > 4) {
                const cr = vnoise(p.x * 0.4 + d * 9 + p.seed, p.y * 0.4 - d * 5);
                if (cr > 0.72 - clamp((t - 4) * 0.14)) h += 0.3 * clamp((t - 4) * 0.8) * fade;
              }
              const c = rampStep("frost", clamp(h), 7);
              return [c[0] * 0.45, c[1] * 0.45, c[2] * 0.5];
            },
            SQ
          );
        }
        for (let tier = 1; tier <= 3; tier++) {
          const tp = this.pieces.filter((p) => p.tier === tier);
          for (let i = 0; i < tp.length; i++) {
            const a = tp[i], b = tp[(i + 1) % tp.length];
            if (a.delay > t || b.delay > t) continue;
            const g = clamp(Math.min(t - a.delay, t - b.delay) * 1.1);
            const fade = (1 - clamp((Math.max(a.broken, b.broken) - 0.3) / 0.5)) * g;
            if (fade <= 0.02) continue;
            const n = Math.max(12, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) * 1.6));
            for (let s2 = 0; s2 <= n; s2++) {
              const u = s2 / n;
              const x = lerp(a.x, b.x, u);
              const y = lerp(a.y, b.y, u) - Math.sin(u * Math.PI) * (8 + tier * 3);
              const c = rampStep("frost", 0.5 + 0.3 * Math.sin(u * Math.PI), 6);
              fb.add(x, y, c[0] * 0.4, c[1] * 0.4, c[2] * 0.45, fade * 0.8);
              fb.add(x, y + 1, c[0] * 0.14, c[1] * 0.14, c[2] * 0.18, fade * 0.8);
            }
          }
        }
        if (t > 3.4 && post < 0.2) {
          const ph = t * 48 % 130;
          for (const p of this.pieces) {
            const d = Math.hypot(p.x - C2.x, (p.y - C2.y) * SQ);
            const f = Math.max(0, 1 - Math.abs(d - ph) / 18);
            if (f > 0 && p.broken < 0.3)
              shard(fb, p.x, p.y - (p.tier === 4 ? 10 : 0), p.r * 0.8, p.a, p.sides, p.seed, (dd) => {
                const k = f * 0.22 * (1 - dd);
                return [0.4 * k, 0.8 * k, 1.2 * k];
              }, SQ);
          }
        }
        for (const c of this.cracks) {
          const k = post > 0 ? 1 - clamp(post) : clamp((t - c.t0) * 3);
          if (k <= 0) continue;
          for (let i = 0; i < 4; i++) {
            const a = c.a + i * 1.3 + vnoise(c.x + i, c.y) * 0.8;
            line(fb, c.x, c.y, c.x + Math.cos(a) * c.len, c.y + Math.sin(a) * c.len / SQ, [1, 1.6, 2.1], 0.5 * k);
          }
        }
        if (post > 0 && post < 0.5) {
          const k = 1 - post / 0.5;
          fb.flash[0] += 0.2 * k * k;
          fb.flash[1] += 0.3 * k * k;
          fb.flash[2] += 0.42 * k * k;
          pulseRing(fb, C2.x + 40, C2.y, post * 260, 16, [0.8, 1.5, 2.2], k * 0.45, SQ, 0.12, 2.3);
        }
        this.glitter.each((p) => {
          const l = p.life / p.max;
          const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 22 + p.seed));
          fb.add(p.x, p.y, 0.9 * l * tw, 1.5 * l * tw, 2.1 * l * tw, l);
        });
      }
    };
    UndertowMaw = class {
      rng = new RNG(3307);
      foam = [];
      drops = new Pool();
      STOP = 4.6;
      SURGE = 4.95;
      constructor() {
        for (let i = 0; i < 160; i++)
          this.foam.push({
            a: this.rng.angle(),
            r: this.rng.range(8, 110),
            sp: this.rng.range(0.6, 2.4),
            s: this.rng.range(0.4, 1.6)
          });
      }
      update(dt, t) {
        if (t < this.STOP) {
          const pull = seg(t, 0.6, 4.3);
          for (const f of this.foam) {
            f.a += f.sp * (1.2 + 60 / (f.r + 14)) * dt * (0.4 + pull);
            f.r -= dt * (6 + 40 * pull) * (0.4 + f.s);
            if (f.r < 5) {
              f.r = this.rng.range(80, 130);
              f.a = this.rng.angle();
            }
          }
        }
        if (t > this.SURGE && t < this.SURGE + 0.4 && this.drops.count() < 500) {
          for (let i = 0; i < 34; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(120, 420);
            this.drops.spawn({
              x: C2.x,
              y: C2.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp / SQ,
              life: this.rng.range(0.6, 2),
              size: this.rng.range(0.6, 2.4),
              seed: this.rng.next() * 999
            });
          }
        }
        this.drops.each((p) => {
          p.vx *= Math.exp(-1.5 * dt);
          p.vy *= Math.exp(-1.5 * dt);
          p.vy += 30 * dt;
        });
        this.drops.step(dt);
      }
      casterLight(t) {
        return 0.2 + 0.3 * seg(t, 0, 4) + 1.2 * (1 - seg(t, this.SURGE, this.SURGE + 0.7));
      }
      render(fb, t) {
        const open = seg(t, 0.2, 3.4);
        const rage = seg(t, 2.4, this.STOP);
        const stop = smoothstep(this.STOP, this.STOP + 0.06, t) * (1 - smoothstep(this.SURGE - 0.12, this.SURGE, t));
        const crush = seg(t, this.STOP + 0.05, this.SURGE);
        const surge = seg(t, this.SURGE, this.SURGE + 1.9);
        const Rmax = lerp(16, 112, easeOut(open, 2)) * (1 - crush * 0.92);
        const spin = stop > 0 ? this.STOP : t;
        if (t < this.SURGE) {
          const asym = rage * 0.26;
          field(fb, C2.x - Rmax * 1.3, C2.y - Rmax * 1.3 / SQ, C2.x + Rmax * 1.3, C2.y + Rmax * 1.3 / SQ, (x, y, o) => {
            const dx = x + 0.5 - C2.x, dy = (y + 0.5 - C2.y) * SQ;
            let d = Math.hypot(dx, dy);
            const a = Math.atan2(dy, dx);
            const edgeR = Rmax * (1 + asym * Math.sin(a * 3 + spin * 1.3) + asym * 0.5 * Math.sin(a * 5 - spin * 0.7));
            if (d > edgeR) return;
            const rn = Math.max(0.04, d / edgeR);
            const depth = Math.log(rn + 0.03);
            const swirl = a + depth * 5 + spin * (1.2 + 2.6 * (1 - rn));
            const bandv = Math.sin(swirl * 2 + Math.log(rn) * 7 - spin * 3.2);
            const noise = fbm(Math.cos(swirl) * 3 * rn + 5, Math.sin(swirl) * 3 * rn - spin * 0.4, 3);
            let h = (0.3 + bandv * 0.34 + noise * 0.3) * Math.pow(rn, 0.55);
            h *= smoothstep(0.03, 0.3, rn);
            h *= 0.45 + open * 0.9;
            h *= 1 + rage * 0.5;
            if (h < 0.03) {
              o[0] = -0;
              return;
            }
            const c = rampStep("water", clamp(h), 9);
            o[0] = c[0] * 0.5;
            o[1] = c[1] * 0.5;
            o[2] = c[2] * 0.55;
          });
          for (let y = -Rmax / SQ; y <= Rmax / SQ; y++)
            for (let x = -Rmax; x <= Rmax; x++) {
              const d = Math.hypot(x, y * SQ) / (Rmax || 1);
              if (d > 0.45) continue;
              fb.mul(C2.x + x, C2.y + y, lerp(0.08, 1, clamp(d / 0.45)));
            }
          for (let i = 0; i < 7; i++) {
            const a0 = i / 7 * TAU + spin * 0.6;
            const pts = [];
            for (let s = 0; s <= 16; s++) {
              const u = s / 16;
              const rr = Rmax * (1 - u * 0.95);
              const aa = a0 + u * 3.6 * (1 + rage);
              pts.push({ x: C2.x + Math.cos(aa) * rr, y: C2.y + Math.sin(aa) * rr / SQ });
            }
            ribbon(
              fb,
              pts,
              (u) => (1 + 2.4 * (1 - u)) * (0.4 + open),
              (u, _i, e) => {
                const h = (1 - e * e) * (1 - u * 0.7) * (0.45 + rage * 0.5);
                if (h < 0.05) return null;
                const c = rampStep("water", clamp(h * 1.2), 7);
                return [c[0] * 0.5, c[1] * 0.5, c[2] * 0.55];
              }
            );
          }
          for (const f of this.foam) {
            if (f.r > Rmax) continue;
            const x = C2.x + Math.cos(f.a) * f.r;
            const y = C2.y + Math.sin(f.a) * f.r / SQ;
            const k = clamp(f.r / 40) * (0.3 + f.s * 0.5) * (0.4 + open);
            const px = C2.x + Math.cos(f.a - 0.16) * (f.r + 2);
            const py = C2.y + Math.sin(f.a - 0.16) * (f.r + 2) / SQ;
            streak(fb, px, py, x, y, 0.9 * f.s, 0.4, [0.8, 1.5, 2], k * 0.8);
          }
          for (let i = 0; i < 180; i++) {
            const a = i / 180 * TAU;
            const edgeR = Rmax * (1 + rage * 0.26 * Math.sin(a * 3 + spin * 1.3) + rage * 0.13 * Math.sin(a * 5 - spin * 0.7));
            fb.add(C2.x + Math.cos(a) * edgeR, C2.y + Math.sin(a) * edgeR / SQ, 0.7, 1.3, 1.8, 0.5 * open);
          }
        }
        if (stop > 0) {
          fb.exposure *= lerp(1, 1.25, stop);
          glow(fb, C2.x, C2.y, 10 + crush * 14, [0.6, 1.2, 1.8], 0.6 * stop);
        }
        if (crush > 0.4 && t < this.SURGE) {
          glow(fb, C2.x, C2.y, lerp(30, 4, crush), [1.2, 1.9, 2.4], crush * 1.6);
        }
        if (surge > 0) {
          const e = surge;
          fb.flash[2] += 0.5 * Math.pow(1 - clamp(e * 6), 2);
          fb.flash[1] += 0.33 * Math.pow(1 - clamp(e * 6), 2);
          fb.flash[0] += 0.14 * Math.pow(1 - clamp(e * 6), 2);
          for (let i = 0; i < 11; i++) {
            const a0 = i / 11 * TAU + 0.2;
            const L = easeOut(e, 1.8) * (150 + hash2(i, 3) * 90);
            sheet(
              fb,
              Math.ceil(L),
              14,
              (u, v) => {
                const a = a0 + u * 0.8 * (hash2(i, 5) - 0.5) * 2;
                const wid = 24 * Math.sin(Math.pow(u, 0.5) * Math.PI) * u;
                const rr = L * u;
                return [
                  C2.x + Math.cos(a) * rr - Math.sin(a) * v * wid,
                  C2.y + (Math.sin(a) * rr + Math.cos(a) * v * wid) / SQ
                ];
              },
              (u, v) => {
                const av = Math.abs(v);
                let h = (0.22 + Math.pow(av, 3) * 0.7) * (1 - u * 0.5) * (1 - e * 0.85);
                h *= 0.6 + fbm(u * 8 + i, v * 3 - t * 2, 2) * 0.9;
                if (h < 0.04) return null;
                const c = rampStep("water", clamp(h * 1.4), 8);
                return [c[0] * 0.45, c[1] * 0.45, c[2] * 0.5];
              }
            );
          }
          for (let i = 0; i < 3; i++) {
            const u = clamp(e * 1.6 - i * 0.12);
            pulseRing(fb, C2.x, C2.y, u * (260 - i * 40), 12 * (1 - u), [0.8, 1.6, 2.2], (1 - u) * 1.1, SQ);
          }
          const tun = 1 - clamp(e * 2.4);
          if (tun > 0)
            for (let i = 0; i < 4; i++) {
              const rr = 10 + i * 16 + e * 120;
              pulseRing(fb, C2.x, C2.y, rr, 3, [0.5, 1.1, 1.7], tun * 0.35 * (1 - i / 4), SQ, 0.3, i * 1.9);
            }
        }
        this.drops.each((p) => {
          const l = p.life / p.max;
          const c = rampStep("water", 0.4 + l * 0.55, 7);
          streakP(fb, p, [c[0] * 0.75, c[1] * 0.75, c[2] * 0.85], l * 0.85);
        });
      }
    };
  }
});

// src/spells/tempest.ts
function bolt(fb, x0, y0, x1, y1, t, seed, w, k, chaos = 0.32) {
  const frame = Math.floor(t * 28);
  const d = Math.hypot(x1 - x0, y1 - y0);
  const pts = boltPath(x0, y0, x1, y1, d * chaos, seed * 131 + frame * 7919, 5);
  boltDraw(fb, pts, w, VOLT(0.62), CORE, k);
  const r = new RNG(seed * 31 + frame);
  const n = Math.max(1, Math.floor(d / 40));
  for (let i = 0; i < n; i++) {
    const idx = r.int(3, pts.length - 3);
    const p = pts[idx];
    const a = r.angle();
    const len = d * r.range(0.07, 0.24);
    const sub = boltPath(p.x, p.y, p.x + Math.cos(a) * len, p.y + Math.sin(a) * len, len * 0.5, r.int(0, 9999), 3);
    boltDraw(fb, sub, w * 0.55, VOLT(0.5), VOLT(0.92), k * 0.6);
  }
  glow(fb, (x0 + x1) / 2, (y0 + y1) / 2, Math.min(16, d * 0.25), VOLT(0.45), 0.07 * k);
}
var C3, VOLT, CORE, ChainVerdict, Thunderloom, VoltCarousel, SkybreakerScript;
var init_tempest = __esm({
  "src/spells/tempest.ts"() {
    "use strict";
    init_particles();
    init_draw();
    init_math();
    init_arena();
    init_world();
    init_common();
    C3 = ARENA_C;
    VOLT = (h) => rampStep("volt", h, 8);
    CORE = [3.2, 3.4, 3.6];
    ChainVerdict = class {
      rng = new RNG(40010);
      nodes = [];
      events = [];
      sparks = new Pool();
      FINAL = 5;
      enemyOf = [-1, 4, 3, 1, 2, 5, 6, 0];
      constructor() {
        const r = this.rng;
        this.nodes = [{ x: CASTER.x + 14, y: CASTER.y - 8, charge: 0 }];
        for (let i = 1; i < this.enemyOf.length; i++) {
          const e = W.enemies[this.enemyOf[i]];
          this.nodes.push({ x: e ? e.x : C3.x, y: e ? e.y - e.spr.h * 0.55 : C3.y, charge: 0 });
        }
        const order = [0, 1, 2, 7, 3, 4, 5, 6, 7, 2];
        let tt = 1.35;
        for (let i = 0; i < order.length - 1; i++) {
          for (let f = 0; f < r.int(1, 2); f++) {
            this.events.push({
              a: order[i],
              b: r.int(0, this.nodes.length - 1),
              t0: tt,
              fail: true,
              seed: r.int(0, 9999)
            });
            tt += 0.07;
          }
          this.events.push({ a: order[i], b: order[i + 1], t0: tt, fail: false, seed: r.int(0, 9999) });
          tt += r.range(0.22, 0.42);
        }
      }
      update(dt, t) {
        for (let i = 1; i < this.nodes.length; i++) {
          const en = W.enemies[this.enemyOf[i]];
          if (!en) continue;
          this.nodes[i].x = en.x;
          this.nodes[i].y = en.y - en.z - en.spr.h * 0.55;
        }
        for (const e of this.events) {
          if (!e.fail && t > e.t0 && t < e.t0 + 0.1) {
            const n = this.nodes[e.b];
            for (let i = 0; i < 10; i++) {
              const a = this.rng.angle();
              const sp = this.rng.range(30, 150);
              this.sparks.spawn({
                x: n.x,
                y: n.y,
                vx: Math.cos(a) * sp,
                vy: Math.sin(a) * sp * 0.6,
                life: this.rng.range(0.15, 0.6),
                seed: this.rng.next() * 99
              });
            }
          }
        }
        if (t > this.FINAL && t < this.FINAL + 0.8 && this.rng.next() < 0.9) {
          const n = this.nodes[this.rng.int(0, this.nodes.length - 1)];
          for (let i = 0; i < 6; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(60, 260);
            this.sparks.spawn({
              x: n.x,
              y: n.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp * 0.6,
              life: this.rng.range(0.2, 0.9),
              seed: this.rng.next() * 99
            });
          }
        }
        this.sparks.each((p) => p.vy += 60 * dt);
        this.sparks.step(dt, 2.4);
      }
      casterLight(t) {
        let k = 0.2;
        for (const e of this.events) if (!e.fail) k += 0.5 * Math.exp(-Math.abs(t - e.t0) * 9);
        return clamp(k + 1.3 * Math.exp(-Math.abs(t - this.FINAL - 0.3) * 3), 0, 2.4);
      }
      render(fb, t) {
        const final = seg(t, this.FINAL, this.FINAL + 1);
        for (let i = 0; i < this.nodes.length; i++) {
          const n = this.nodes[i];
          const armed = this.events.some((e) => !e.fail && e.b === i && t > e.t0) || i === 0;
          const base = armed ? 0.8 : 0.35 * smoothstep(0.1, 1.2, t);
          const fr = Math.floor(t * 20) + i * 13;
          const r = new RNG(fr);
          for (let s = 0; s < 3; s++) {
            const a = r.angle();
            const len = r.range(3, 11) * base;
            const p = boltPath(n.x, n.y, n.x + Math.cos(a) * len, n.y + Math.sin(a) * len, len * 0.6, r.int(0, 999), 2);
            boltDraw(fb, p, 0.9, VOLT(0.45), VOLT(0.88), base * 0.8);
          }
          glow(fb, n.x, n.y, 4 + base * 5, VOLT(0.55), 0.2 + base * 0.3);
          fb.add(n.x, n.y, CORE[0], CORE[1], CORE[2], 0.5 * base);
        }
        for (const e of this.events) {
          if (e.fail || t < e.t0) continue;
          const age = t - e.t0;
          const A = this.nodes[e.a], B = this.nodes[e.b];
          const ghost = Math.max(0, 0.22 - age * 0.02) + (final > 0 ? 0 : 0);
          if (ghost > 0.01) {
            const pts = boltPath(A.x, A.y, B.x, B.y, Math.hypot(B.x - A.x, B.y - A.y) * 0.3, e.seed, 4);
            for (let i = 0; i < pts.length - 1; i++)
              line(fb, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, VOLT(0.42), ghost * (0.7 + 0.3 * Math.sin(t * 9 + i)));
          }
        }
        for (const e of this.events) {
          const age = t - e.t0;
          const A = this.nodes[e.a], B = this.nodes[e.b];
          if (e.fail) {
            if (age < 0 || age > 0.16) continue;
            const u = 1 - age / 0.16;
            const ex = lerp(A.x, B.x, 0.45 * u), ey = lerp(A.y, B.y, 0.45 * u);
            bolt(fb, A.x, A.y, ex, ey, t, e.seed, 0.9, u * 0.55, 0.45);
          } else {
            if (age < 0 || age > 0.26) continue;
            const k = Math.pow(1 - age / 0.26, 1.5);
            if (e.seed % 3 === 0) {
              const mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2;
              const nx = -(B.y - A.y) * 0.3, ny = (B.x - A.x) * 0.3;
              bolt(fb, A.x, A.y, mx + nx, my + ny, t, e.seed, 1.4, k, 0.2);
              bolt(fb, mx + nx, my + ny, B.x, B.y, t, e.seed + 1, 1.4, k, 0.2);
              bolt(fb, A.x, A.y, mx - nx, my - ny, t, e.seed + 2, 1.2, k * 0.8, 0.2);
              bolt(fb, mx - nx, my - ny, B.x, B.y, t, e.seed + 3, 1.2, k * 0.8, 0.2);
            } else {
              bolt(fb, A.x, A.y, B.x, B.y, t, e.seed, 1.6, k);
            }
            glow(fb, B.x, B.y, 14 * k, VOLT(0.7), k);
            fb.flash[2] += 0.05 * k;
          }
        }
        if (final > 0 && final < 1) {
          const succ = this.events.filter((e) => !e.fail);
          for (let i = 0; i < succ.length; i++) {
            const u = (final - i * 0.028) / 0.1;
            if (u < 0 || u > 1) continue;
            const k = Math.sin(u * Math.PI);
            const e = succ[i];
            bolt(fb, this.nodes[e.a].x, this.nodes[e.a].y, this.nodes[e.b].x, this.nodes[e.b].y, t, e.seed, 2.2, k * 1.4, 0.18);
          }
          const webK = Math.sin(clamp(final * 1.3) * Math.PI);
          fb.flash[2] += 0.3 * webK * webK;
          fb.flash[0] += 0.1 * webK * webK;
          for (const n of this.nodes) glow(fb, n.x, n.y, 8 + webK * 10, VOLT(0.7), webK * 0.55);
          if (final > 0.55) {
            const d = seg(t, this.FINAL + 0.55, this.FINAL + 1.6);
            for (const e of succ) {
              const A = this.nodes[e.a], B = this.nodes[e.b];
              const pts = boltPath(A.x, A.y, B.x, B.y, 20, e.seed, 4);
              for (let i = 0; i < pts.length - 1; i++)
                if (hash2(e.seed, i) > d)
                  line(fb, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, VOLT(0.55), (1 - d) * 0.5);
            }
          }
        }
        this.sparks.each((p) => {
          const l = p.life / p.max;
          const c = VOLT(0.5 + l * 0.5);
          fb.add(p.x, p.y, c[0], c[1], c[2], l);
          fb.add(p.px, p.py, c[0], c[1], c[2], l * 0.4);
        });
      }
    };
    Thunderloom = class {
      rng = new RNG(29719);
      T = { x: 272, y: 112 };
      threads = [];
      cores = [];
      fract = [];
      relight = [];
      STRIKE = 4.9;
      constructor() {
        const r = this.rng;
        for (let i = 0; i < 16; i++)
          this.threads.push({
            r: r.range(16, 62),
            tilt: r.angle(),
            squash: r.range(1.6, 5),
            sp: r.range(0.5, 2.6) * r.sign(),
            ph: r.angle(),
            w: r.range(0.6, 1.6)
          });
        for (let i = 0; i < 4; i++)
          this.cores.push({ r: r.range(10, 34), sp: r.range(1.2, 3) * r.sign(), ph: r.angle(), s: r.range(1, 2.4) });
        const br = new RNG(515);
        for (let i = 0; i < 14; i++)
          this.fract.push(
            ...growBranches(br, this.T.x, this.T.y, br.angle(), 1.5, {
              steps: 9,
              step: 9,
              wander: 0.42,
              branchChance: 0.2,
              maxDepth: 2,
              widthFalloff: 0.6,
              speed: 6
            })
          );
        for (let i = 0; i < 18; i++) {
          const a = r.angle(), d = r.range(20, 120);
          this.relight.push({
            x: this.T.x + Math.cos(a) * d,
            y: this.T.y + Math.sin(a) * d * 0.7,
            t0: this.STRIKE + r.range(0.35, 1.7),
            a: r.angle()
          });
        }
      }
      update(_dt, t) {
        if (t > this.STRIKE) updateBranches(this.fract, t - this.STRIKE);
      }
      casterLight(t) {
        return 0.15 + 0.4 * seg(t, 0, 4) + 1.6 * (1 - seg(t, this.STRIKE, this.STRIKE + 0.5));
      }
      render(fb, t) {
        const build = seg(t, 0.2, 3.4);
        const wind = seg(t, 3.2, 4.45);
        const rev = seg(t, 4.45, this.STRIKE);
        const post = t - this.STRIKE;
        const T = this.T;
        if (t < this.STRIKE) {
          const sh = build * (1 + wind * 0.3);
          fieldMul(fb, T.x - 110, T.y - 90, T.x + 110, T.y + 90, (x, y) => {
            const d = Math.hypot((x - T.x) / 100, (y - T.y) / 78);
            if (d > 1) return 1;
            return lerp(1, lerp(0.14, 1, d * d), sh);
          });
          const contract = 1 - rev * 0.93;
          const spin = t * (1 + wind * 3 + rev * 9);
          for (let i = 0; i < this.threads.length; i++) {
            const th = this.threads[i];
            const g = clamp((build - i * 0.03) * 1.4);
            if (g <= 0) continue;
            const rr = th.r * contract * g;
            const steps = 54;
            let px = 0, py = 0;
            for (let s = 0; s <= steps; s++) {
              const a = s / steps * TAU + th.ph + spin * th.sp * 0.3;
              const lx = Math.cos(a) * rr;
              const ly = Math.sin(a) * rr / th.squash;
              const x = T.x + lx * Math.cos(th.tilt) - ly * Math.sin(th.tilt);
              const y = T.y + lx * Math.sin(th.tilt) + ly * Math.cos(th.tilt);
              if (s > 0) {
                const flow = 0.5 + 0.5 * Math.sin(a * 4 - t * 12 + i);
                const c = VOLT(0.35 + flow * 0.35);
                line(fb, px, py, x, y, c, (0.26 + flow * 0.4) * g * (0.5 + wind * 0.8));
              }
              px = x;
              py = y;
            }
          }
          const fr = Math.floor(t * 24);
          const r = new RNG(fr * 7 + 3);
          const nJump = Math.floor(2 + build * 5 + wind * 7);
          for (let i = 0; i < nJump; i++) {
            const a1 = r.angle(), a2 = r.angle();
            const r1 = r.range(6, 62) * contract, r2 = r.range(6, 62) * contract;
            const x1 = T.x + Math.cos(a1) * r1, y1 = T.y + Math.sin(a1) * r1 / 1.7;
            const x2 = T.x + Math.cos(a2) * r2, y2 = T.y + Math.sin(a2) * r2 / 1.7;
            bolt(fb, x1, y1, x2, y2, t, i * 17 + fr, 0.8, (0.35 + wind * 0.6) * build, 0.4);
          }
          for (const co of this.cores) {
            const a = co.ph + co.sp * spin;
            const rr = co.r * contract * build;
            const x = T.x + Math.cos(a) * rr, y = T.y + Math.sin(a) * rr / 1.8;
            glow(fb, x, y, co.s * (3 + wind * 5), VOLT(0.75), (0.5 + wind) * build);
            fb.add(x, y, CORE[0], CORE[1], CORE[2], build);
          }
          if (rev > 0.3) glow(fb, T.x, T.y, lerp(26, 5, rev), [2, 2.4, 3.2], rev * 2.2);
        }
        if (post > -0.02) {
          const k = Math.max(0, 1 - post / 0.4);
          if (post < 0.28) {
            const w = lerp(5, 1.2, post / 0.28);
            for (let y = 0; y <= T.y; y++) {
              const n = vnoise(y * 0.2, Math.floor(t * 60) * 0.3);
              const xx = T.x + (n - 0.5) * 3 * (1 - y / T.y);
              for (let dx = -w * 2; dx <= w * 2; dx++) {
                const f = Math.max(0, 1 - Math.abs(dx) / (w * 2));
                const c = VOLT(0.5 + f * 0.5);
                fb.add(xx + dx, y, c[0], c[1], c[2], f * f * (1 - post / 0.4));
              }
              fb.add(xx, y, CORE[0], CORE[1], CORE[2], 1 - post / 0.3);
            }
            fb.flash[0] += 0.26 * k * k;
            fb.flash[1] += 0.3 * k * k;
            fb.flash[2] += 0.42 * k * k;
            fb.exposure *= 1 + k * 0.35;
          }
          for (const b of this.fract)
            drawBranch(
              fb,
              b,
              (u, e) => {
                const decay = Math.exp(-Math.max(0, post - 0.4) * 1.1);
                const h = (1 - e) * (1 - u * 0.78) * decay;
                if (h < 0.05) return null;
                return VOLT(clamp(h * 0.78));
              },
              (u, bb) => Math.max(0.5, bb.w * (1 - u * 0.6))
            );
          glow(fb, T.x, T.y, 50 * Math.exp(-post * 1.6), VOLT(0.65), 1.4 * Math.exp(-post * 1.6));
          pulseRing(fb, T.x, T.y, post * 320, 18 * Math.exp(-post * 2), VOLT(0.5), Math.max(0, 1 - post * 1.4) * 0.4, 1.6, 0.22, 3.1);
          const emi = Math.exp(-post * 2.2);
          if (emi > 0.05) {
            for (let y = 0; y < fb.H; y++) {
              const n = vnoise(y * 0.3, Math.floor(t * 40) * 0.7);
              if (n < 0.86 - emi * 0.25) continue;
              const sh = Math.round((n - 0.5) * 14 * emi);
              if (!sh) continue;
              const row = new Float32Array(fb.W * 3);
              for (let x = 0; x < fb.W; x++) {
                const s = clamp(x + sh, 0, fb.W - 1) | 0;
                row[x * 3] = fb.buf[(y * fb.W + s) * 3];
                row[x * 3 + 1] = fb.buf[(y * fb.W + s) * 3 + 1];
                row[x * 3 + 2] = fb.buf[(y * fb.W + s) * 3 + 2];
              }
              for (let x = 0; x < fb.W; x++) {
                fb.buf[(y * fb.W + x) * 3] = row[x * 3];
                fb.buf[(y * fb.W + x) * 3 + 1] = row[x * 3 + 1];
                fb.buf[(y * fb.W + x) * 3 + 2] = row[x * 3 + 2];
              }
            }
          }
          for (const rl of this.relight) {
            const age = t - rl.t0;
            if (age < 0 || age > 0.18) continue;
            const k2 = 1 - age / 0.18;
            bolt(fb, rl.x, rl.y, rl.x + Math.cos(rl.a) * 16, rl.y + Math.sin(rl.a) * 11, t, rl.t0 * 100, 0.8, k2 * 0.9, 0.5);
          }
        }
      }
    };
    VoltCarousel = class {
      rng = new RNG(49374);
      rings = [];
      frags = new Pool();
      SYNC = 5.3;
      constructor() {
        const r = this.rng;
        for (let i = 0; i < 6; i++)
          this.rings.push({
            r: 18 + i * 13 + r.range(-4, 4),
            squash: r.range(1.1, 2.6),
            tilt: r.angle(),
            sp: r.range(0.5, 2.2) * (i % 2 ? 1 : -1),
            ph: r.angle(),
            segs: r.int(3, 7),
            gap: r.range(0.25, 0.6),
            drift: r.range(-10, 10),
            jump: r.range(0, 6)
          });
      }
      segPos(ring, k, t, scale) {
        const a = ring.ph + ring.sp * t * (1 + 0.4 * Math.sin(t * 0.7 + ring.jump)) + k / ring.segs * TAU;
        const rr = (ring.r + Math.sin(t * 0.9 + ring.jump) * ring.drift) * scale;
        const lx = Math.cos(a) * rr, ly = Math.sin(a) * rr / ring.squash;
        return {
          x: C3.x + lx * Math.cos(ring.tilt) - ly * Math.sin(ring.tilt),
          y: C3.y + lx * Math.sin(ring.tilt) + ly * Math.cos(ring.tilt),
          a,
          rr
        };
      }
      update(dt, t) {
        if (t > this.SYNC + 0.35 && t < this.SYNC + 0.6) {
          for (const ring of this.rings)
            for (let k = 0; k < ring.segs; k++) {
              const p = this.segPos(ring, k, t, 1);
              const a = Math.atan2(p.y - C3.y, p.x - C3.x);
              this.frags.spawn({
                x: p.x,
                y: p.y,
                vx: Math.cos(a) * 70,
                vy: Math.sin(a) * 50,
                life: 1.6,
                a,
                av: this.rng.range(-6, 6),
                size: this.rng.range(2, 6),
                seed: this.rng.next() * 999
              });
            }
        }
        this.frags.each((p) => {
          p.vx *= Math.exp(-0.9 * dt);
          p.vy *= Math.exp(-0.9 * dt);
        });
        this.frags.step(dt);
      }
      casterLight(t) {
        return 0.2 + 0.5 * seg(t, 0, 4) + 1.4 * (1 - seg(t, this.SYNC, this.SYNC + 0.6));
      }
      render(fb, t) {
        const build = seg(t, 0.15, 1.8);
        const energy = seg(t, 1.5, this.SYNC);
        const sync = seg(t, this.SYNC, this.SYNC + 0.55);
        const after = seg(t, this.SYNC + 0.4, this.SYNC + 1.9);
        const scale = easeOut(build, 2) * (1 + sync * 0.1) * (after > 0 ? 1 + after * 0.4 : 1);
        const vis = 1 - clamp(after * 1.6);
        if (vis > 0) {
          for (let ri = 0; ri < this.rings.length; ri++) {
            const ring = this.rings[ri];
            const g = clamp((build - ri * 0.08) * 1.6);
            if (g <= 0) continue;
            for (let k = 0; k < ring.segs; k++) {
              const p = this.segPos(ring, k, t, scale);
              const span = (1 - ring.gap) / ring.segs * TAU;
              const steps = Math.max(5, Math.ceil(p.rr * span));
              let px = 0, py = 0;
              for (let s = 0; s <= steps; s++) {
                const aa = p.a + (s / steps - 0.5) * span;
                const lx = Math.cos(aa) * p.rr, ly = Math.sin(aa) * p.rr / ring.squash;
                const x = C3.x + lx * Math.cos(ring.tilt) - ly * Math.sin(ring.tilt);
                const y = C3.y + lx * Math.sin(ring.tilt) + ly * Math.cos(ring.tilt);
                if (s > 0) {
                  const c = VOLT(0.45 + 0.3 * Math.sin(s * 0.7 - t * 9 + ri) + energy * 0.2 + sync * 0.3);
                  const burn = 1 - sync * 0.6;
                  streak(fb, px, py, x, y, 1.4 + sync * 0.6, 1.4 + sync * 0.6, c, (0.4 + energy * 0.35) * g * vis * burn);
                  line(fb, px, py, x, y, CORE, 0.45 * g * vis * burn);
                }
                px = x;
                py = y;
              }
              glow(fb, p.x, p.y, 4 + sync * 3, VOLT(0.7), (0.3 + energy * 0.3) * g * vis);
            }
          }
          const all = [];
          for (let ri = 0; ri < this.rings.length; ri++) {
            if (clamp((build - ri * 0.08) * 1.6) <= 0) continue;
            for (let k = 0; k < this.rings[ri].segs; k++) {
              const p = this.segPos(this.rings[ri], k, t, scale);
              all.push({ x: p.x, y: p.y, ri });
            }
          }
          const thresh = sync > 0 ? 70 : 26 + energy * 24;
          let bi = 0;
          for (let i = 0; i < all.length; i++)
            for (let j = i + 1; j < all.length; j++) {
              if (all[i].ri === all[j].ri) continue;
              const d = Math.hypot(all[i].x - all[j].x, all[i].y - all[j].y);
              if (d > thresh) continue;
              const k = sync > 0 ? Math.sin(clamp(sync * 1.4) * Math.PI) * 0.8 : clamp(1 - d / thresh) * (0.4 + energy);
              bolt(fb, all[i].x, all[i].y, all[j].x, all[j].y, t, bi++ * 97, 1, k * vis, 0.22);
            }
          glow(fb, C3.x, C3.y, 6 + energy * 14 + sync * 26, VOLT(0.6), (0.3 + energy * 0.6 + sync * 0.7) * vis);
        }
        if (sync > 0) {
          const k = Math.sin(clamp(sync) * Math.PI);
          pulseRing(fb, C3.x, C3.y, sync * 280, 16 * (1 - sync), VOLT(0.6), (1 - sync) * 0.6, 1.3);
          for (let i = 0; i < 12; i++) {
            const a = i / 18 * TAU + sync;
            const L = easeOut(sync, 2) * 200;
            bolt(fb, C3.x, C3.y, C3.x + Math.cos(a) * L, C3.y + Math.sin(a) * L / 1.4, t, i * 31, 1.1, k * 0.7, 0.16);
          }
        }
        this.frags.each((p) => {
          const l = p.life / p.max;
          const a = p.a + p.av * (p.max - p.life);
          for (let s = -p.size; s <= p.size; s++) {
            const c = VOLT(0.35 + l * 0.35);
            fb.add(p.x + Math.cos(a) * s, p.y + Math.sin(a) * s / 1.5, c[0], c[1], c[2], l * 0.45);
          }
          if (Math.sin(t * 30 + p.seed) > 0.75) {
            const e = p.size;
            bolt(fb, p.x - Math.cos(a) * e, p.y - Math.sin(a) * e / 1.5, p.x + Math.cos(a) * e, p.y + Math.sin(a) * e / 1.5, t, p.seed, 0.6, l * 0.35, 0.6);
          }
        });
      }
    };
    SkybreakerScript = class {
      rng = new RNG(23314);
      N = [];
      E = [];
      packets = [];
      CIRCUIT = 4.3;
      RUPTURE = 6;
      constructor() {
        const r = this.rng;
        const push = (x, y) => this.N.push({ x, y }) - 1;
        const outer = [];
        const nOut = 9;
        for (let i = 0; i < nOut; i++) {
          const a = i / nOut * TAU + r.range(-0.12, 0.12);
          const rr = 72 + r.range(-12, 12);
          outer.push(push(C3.x + Math.cos(a) * rr, C3.y + Math.sin(a) * rr / 1.35));
        }
        const inner = [];
        const nIn = 5;
        for (let i = 0; i < nIn; i++) {
          const a = i / nIn * TAU + 0.5;
          const rr = 34 + r.range(-6, 6);
          inner.push(push(C3.x + Math.cos(a) * rr, C3.y + Math.sin(a) * rr / 1.35));
        }
        const ctr = push(C3.x, C3.y);
        let tt = 0.45;
        const edge = (a, b, instant) => {
          this.E.push({ a, b, t0: tt, instant, seed: r.int(0, 9999), blow: 0 });
          tt += instant ? r.range(0.08, 0.16) : r.range(0.17, 0.3);
        };
        for (let i = 0; i < nOut; i++) edge(outer[i], outer[(i + 3) % nOut], r.next() < 0.5);
        for (let i = 0; i < nOut; i += 2) edge(outer[i], inner[i % nIn], true);
        for (let i = 0; i < nIn; i++) edge(inner[i], inner[(i + 2) % nIn], false);
        for (let i = 0; i < nIn; i++) edge(inner[i], ctr, true);
        for (let k = 0; k < 3; k++) {
          const base = outer[k * 3];
          const a0 = Math.atan2(this.N[base].y - C3.y, this.N[base].x - C3.x);
          let prev = base;
          const sub = [];
          for (let i = 0; i < 4; i++) {
            const a = a0 + i / 4 * TAU * 0.6 - 0.3;
            const id = push(this.N[base].x + Math.cos(a) * 14, this.N[base].y + Math.sin(a) * 11);
            sub.push(id);
            edge(prev, id, true);
            prev = id;
          }
          edge(prev, base, true);
        }
        this.RUPTURE = Math.max(5.8, tt + 1.9);
        this.CIRCUIT = tt + 0.25;
      }
      update(dt, t) {
        if (t > this.CIRCUIT && t < this.RUPTURE) {
          if (this.packets.length < 26 && this.rng.next() < 0.5)
            this.packets.push({ e: this.rng.int(0, this.E.length - 1), u: 0, dir: 1, life: 2 });
          for (const p of this.packets) {
            p.u += dt * 2.2 * p.dir;
            p.life -= dt;
            if (p.u > 1 || p.u < 0) {
              const e = this.E[p.e];
              const node = p.u > 1 ? e.b : e.a;
              const cands = this.E.map((_, i) => i).filter((i) => this.E[i].a === node || this.E[i].b === node);
              if (cands.length) {
                const ni = cands[this.rng.int(0, cands.length - 1)];
                p.e = ni;
                p.dir = this.E[ni].a === node ? 1 : -1;
                p.u = this.E[ni].a === node ? 0 : 1;
              } else p.life = 0;
            }
          }
          this.packets = this.packets.filter((p) => p.life > 0);
        }
        if (t > this.RUPTURE - 1.2)
          for (let i = 0; i < this.E.length; i++) {
            const dt0 = this.RUPTURE - 1.2 + i / this.E.length * 1.2;
            if (t > dt0 && !this.E[i].blow) this.E[i].blow = t;
          }
      }
      casterLight(t) {
        return 0.2 + 0.4 * seg(t, 0, 3) + 1.5 * (1 - seg(t, this.RUPTURE, this.RUPTURE + 0.6));
      }
      render(fb, t) {
        const rupture = seg(t, this.RUPTURE, this.RUPTURE + 1.4);
        for (let i = 0; i < this.E.length; i++) {
          const e = this.E[i];
          const A = this.N[e.a], B = this.N[e.b];
          const age = t - e.t0;
          if (age < 0) continue;
          const u = e.instant ? age > 0 ? 1 : 0 : clamp(age * 2.6);
          if (u <= 0) continue;
          const ex = lerp(A.x, B.x, u), ey = lerp(A.y, B.y, u);
          let k = 1;
          if (e.blow) {
            const ba = t - e.blow;
            k = ba < 0.1 ? 1 + 1.2 * (1 - ba / 0.1) : Math.max(0, 1 - (ba - 0.1) * 1.6);
          }
          if (k <= 0) continue;
          const fresh = e.instant ? Math.max(0, 1 - age * 5) : Math.max(0, 1 - (age - 0.4) * 3);
          const flow = 0.5 + 0.5 * Math.sin(u * 20 - t * 14 + i);
          streak(fb, A.x, A.y, ex, ey, 1.2 + fresh * 1.2, 1.2 + fresh * 1.2, VOLT(0.4 + flow * 0.18), (0.35 + fresh * 0.6) * 0.7 * k);
          line(fb, A.x, A.y, ex, ey, VOLT(0.85 + 0.15 * flow), (0.65 + fresh * 0.5) * k);
          if (Math.floor(t * 24 + i) % 3 === 0) {
            const r = new RNG(Math.floor(t * 24) + i * 13);
            const uu = r.next();
            const mx = lerp(A.x, ex, uu), my = lerp(A.y, ey, uu);
            const a = r.angle();
            bolt(fb, mx, my, mx + Math.cos(a) * 6, my + Math.sin(a) * 5, t, i * 7, 0.6, 0.5 * k, 0.6);
          }
          if (!e.instant && u < 1) {
            const r = new RNG(Math.floor(t * 30) + i);
            for (let s = 0; s < 3; s++) {
              const a = r.angle();
              const l = r.range(4, 12);
              bolt(fb, ex, ey, ex + Math.cos(a) * l, ey + Math.sin(a) * l, t, s * 11 + i, 0.6, 0.6, 0.7);
            }
          }
          if (e.instant && fresh > 0) {
            bolt(fb, A.x, A.y, B.x, B.y, t, e.seed, 2, fresh * 1.2, 0.12);
          }
          if (e.blow && t - e.blow < 0.18) {
            const bk = 1 - (t - e.blow) / 0.18;
            glow(fb, (A.x + B.x) / 2, (A.y + B.y) / 2, 6 + bk * 8, VOLT(0.75), bk * 0.6);
            fb.flash[2] += 0.02 * bk;
          }
        }
        if (t < this.CIRCUIT) {
          const fr = Math.floor(t * 9);
          const r = new RNG(fr * 31);
          if (r.next() < 0.6) {
            const done = this.E.filter((e) => t > e.t0);
            const todo = this.E.filter((e) => t <= e.t0);
            if (done.length && todo.length) {
              const a = this.N[done[r.int(0, done.length - 1)].a];
              const b = this.N[todo[r.int(0, todo.length - 1)].b];
              const k = 1 - t * 9 % 1;
              bolt(fb, a.x, a.y, b.x, b.y, t, fr, 0.8, k * 0.5, 0.5);
            }
          }
        }
        for (const p of this.packets) {
          const e = this.E[p.e];
          const A = this.N[e.a], B = this.N[e.b];
          const x = lerp(A.x, B.x, clamp(p.u)), y = lerp(A.y, B.y, clamp(p.u));
          glow(fb, x, y, 4.5, VOLT(0.8), 0.9);
          fb.add(x, y, CORE[0], CORE[1], CORE[2], 1);
          const tx = lerp(A.x, B.x, clamp(p.u - 0.08 * p.dir)), ty = lerp(A.y, B.y, clamp(p.u - 0.08 * p.dir));
          streak(fb, tx, ty, x, y, 1.2, 0.4, VOLT(0.7), 0.7);
        }
        for (const n of this.N) {
          const near = this.E.some((e) => (this.N[e.a] === n || this.N[e.b] === n) && t > e.t0);
          if (!near) continue;
          fb.add(n.x, n.y, CORE[0], CORE[1], CORE[2], 0.6);
        }
        if (rupture > 0) {
          const k = Math.sin(clamp(rupture * 1.3) * Math.PI);
          pulseRing(fb, C3.x, C3.y, rupture * 300, 14 * (1 - rupture), VOLT(0.6), (1 - rupture) * 0.7, 1.35);
          for (let i = 0; i < 16; i++) {
            const a = i / 26 * TAU + rupture * 0.6;
            const L = easeOut(rupture, 2) * 230;
            bolt(fb, C3.x, C3.y, C3.x + Math.cos(a) * L, C3.y + Math.sin(a) * L / 1.35, t, i * 53, 1.2, k * 0.8, 0.2);
          }
        }
      }
    };
  }
});

// src/spells/verdant.ts
var C4, SQ2, GRN, BIO, Rootwake, SporeNebula, ThornOpera, Worldseed;
var init_verdant = __esm({
  "src/spells/verdant.ts"() {
    "use strict";
    init_particles();
    init_draw();
    init_math();
    init_arena();
    init_world();
    init_common();
    init_tide();
    C4 = ARENA_C;
    SQ2 = 1.45;
    GRN = (h) => rampStep("verdant", h, 8);
    BIO = (h) => rampStep("bio", h, 8);
    Rootwake = class {
      rng = new RNG(28673);
      roots = [];
      risers = [];
      flowers = [];
      petals = new Pool();
      SNAP = 5.4;
      constructor() {
        const r = this.rng;
        for (let i = 0; i < 6; i++) {
          const a = -0.9 + i / 5 * 2 + r.range(-0.2, 0.2);
          this.roots.push(
            ...growBranches(r, CASTER.x + 10, CASTER.y + 2, a, 2.6, {
              steps: 15,
              step: 9,
              wander: 0.3,
              branchChance: 0.15,
              maxDepth: 2,
              widthFalloff: 0.62,
              speed: 0.55,
              bias: (x, y) => {
                const want = Math.atan2(C4.y - y, C4.x - x);
                return Math.sin(want) * 0.2;
              }
            })
          );
        }
        const majors = this.roots.filter((b) => b.depth === 0).slice(0, 6);
        for (const b of majors) this.risers.push({ b, lift: r.range(16, 34), phase: r.angle(), seed: r.int(0, 999) });
        for (let i = 0; i < 16; i++) {
          const b = this.roots[r.int(0, this.roots.length - 1)];
          const p = b.pts[Math.min(b.pts.length - 1, r.int(2, b.pts.length - 1))];
          this.flowers.push({ x: p.x, y: p.y, t0: 2 + r.range(0, 2.6), r: r.range(2.5, 5), seed: r.int(0, 999) });
        }
      }
      update(dt, t) {
        const beat = t + 0.35 * Math.sin(t * 2.6) + 0.18 * Math.sin(t * 6.1);
        updateBranches(this.roots, beat);
        if (t > this.SNAP && t < this.SNAP + 0.5) {
          for (let i = 0; i < 12; i++) {
            const f = this.flowers[this.rng.int(0, this.flowers.length - 1)];
            const a = this.rng.angle();
            this.petals.spawn({
              x: f.x,
              y: f.y,
              vx: Math.cos(a) * this.rng.range(20, 90),
              vy: Math.sin(a) * this.rng.range(20, 70) - 30,
              life: this.rng.range(1.4, 3.2),
              a: this.rng.angle(),
              av: this.rng.range(-3, 3),
              size: this.rng.range(1.2, 2.6),
              seed: this.rng.next() * 999
            });
          }
        }
        this.petals.each((p) => {
          p.vx += Math.sin(t * 2 + p.seed) * 14 * dt;
          p.vy += 16 * dt;
          p.vx *= Math.exp(-0.8 * dt);
          p.vy *= Math.exp(-0.8 * dt);
        });
        this.petals.step(dt);
      }
      casterLight(t) {
        return 0.25 + 0.4 * seg(t, 0, 3) + 1 * (1 - seg(t, this.SNAP, this.SNAP + 0.8));
      }
      render(fb, t) {
        const snap = seg(t, this.SNAP, this.SNAP + 0.45);
        const wither = seg(t, this.SNAP + 0.7, 7.4);
        const tight = Math.sin(clamp(snap) * Math.PI) * 6;
        for (const b of this.roots) {
          const isRiser = this.risers.find((r) => r.b === b);
          const lift = isRiser ? isRiser.lift * smoothstep(2.2, 4, t) : 0;
          const bend = isRiser ? Math.sin(t * 1.4 + isRiser.phase) * 5 : 0;
          drawBranch(
            fb,
            b,
            (u, e) => {
              const vein = Math.exp(-Math.pow((e - 0) * 3.2, 2));
              const pulse = 0.5 + 0.5 * Math.sin(u * 14 - t * 5 + b.seed * 0.1);
              let h = 0.12 + vein * (0.25 + pulse * 0.42);
              h *= 1 - wither * 0.85;
              h *= 1 + snap * 0.5;
              const rim = e > 0.82 ? 0.1 : 0;
              const c = GRN(clamp(h + rim));
              return [c[0] * 0.55, c[1] * 0.55, c[2] * 0.55];
            },
            (u, bb) => Math.max(0.6, bb.w * (1 - u * 0.7) * (1 + lift * 0.012) * (1 - wither * 0.4)),
            false
          );
          if (lift > 1) {
            const n = b.pts.length;
            const lim = Math.floor(b.grow * (n - 1));
            for (let i = 1; i < lim; i++) {
              const p = b.pts[i];
              const li = lift * Math.sin(i / n * Math.PI);
              fb.mul(p.x + 2, p.y + 3, 0.75);
              const yy = p.y - li + bend * Math.sin(i / n * 3);
              const w = Math.max(1, b.w * (1 - i / n) * 1.3);
              for (let k = -w; k <= w; k++) {
                const e = Math.abs(k) / w;
                const h = (0.16 + (1 - e) * 0.4) * (1 - wither * 0.8);
                const c = GRN(h);
                fb.add(p.x, yy + k, c[0] * 0.7, c[1] * 0.7, c[2] * 0.7, 1);
              }
              if (i % 4 === 0) {
                const ta = Math.sin(i * 1.7 + b.seed) > 0 ? -1 : 1;
                const tl = 3 + Math.sin(i + t * 3) * 1 + snap * 3;
                const c = GRN(0.55);
                streak(fb, p.x, yy, p.x + ta * 1.5, yy + ta * tl, 1.1, 0.3, [c[0] * 0.8, c[1] * 0.8, c[2] * 0.8], 0.9);
              }
            }
          }
        }
        for (const f of this.flowers) {
          const u = clamp((t - f.t0) * 1.6);
          if (u <= 0) continue;
          const open = backOut(u, 2.6) * (1 - wither * 0.9);
          const rr = f.r * open * (1 + snap * 0.6);
          for (let k = 0; k < 6; k++) {
            const a = k / 6 * TAU + f.seed * 0.01 + t * 0.2;
            const px = f.x + Math.cos(a) * rr, py = f.y + Math.sin(a) * rr / SQ2;
            const c = rampStep("bloom", 0.55 + 0.3 * Math.sin(t * 3 + k), 7);
            streak(fb, f.x, f.y, px, py, 1.6, 0.8, [c[0] * 0.5, c[1] * 0.5, c[2] * 0.5], 0.9 * open);
          }
          glow(fb, f.x, f.y, 4 * open, [1.3, 1, 1.4], 0.5 * open);
          const pulseAge = (t - f.t0) % 1.6;
          if (pulseAge < 0.5) {
            const pr = pulseAge * 90;
            pulseRing(fb, f.x, f.y, pr, 5, [0.3, 0.9, 0.4], (1 - pulseAge / 0.5) * 0.18, SQ2);
          }
        }
        if (snap > 0) {
          const k = Math.sin(clamp(snap) * Math.PI);
          pulseRing(fb, CASTER.x + 10, CASTER.y, snap * 260, 14 * (1 - snap), GRN(0.7), k * 0.8, SQ2);
          fb.flash[1] += 0.14 * k * k;
          for (const b of this.roots) {
            if (b.depth > 1) continue;
            const p = b.pts[Math.floor(b.pts.length * 0.7)];
            if (!p) continue;
            const a = Math.atan2(p.y - CASTER.y, p.x - CASTER.x);
            const L = tight * 3;
            const c = GRN(0.8);
            streak(fb, p.x, p.y, p.x - Math.cos(a) * L, p.y - Math.sin(a) * L, 2 * k, 0.5, c, k);
          }
        }
        this.petals.each((p) => {
          const l = p.life / p.max;
          const a = p.a + p.av * (p.max - p.life);
          const c = rampStep("bloom", 0.4 + l * 0.4, 6);
          const w = p.size * Math.abs(Math.cos(a * 1.3));
          for (let k = -w; k <= w; k++)
            fb.add(p.x + Math.cos(a) * k, p.y + Math.sin(a) * k / 1.4, c[0] * 0.6, c[1] * 0.6, c[2] * 0.6, l * 0.9);
        });
        if (wither > 0.4) {
          for (const b of this.roots) {
            if (b.depth > 0) continue;
            const k = (wither - 0.4) * 0.2;
            for (let i = 0; i < b.pts.length; i += 3) {
              const p = b.pts[i];
              fb.add(p.x, p.y, 0.18, 0.3, 0.22, k);
            }
          }
        }
      }
    };
    SporeNebula = class {
      rng = new RNG(23008);
      spores = new Pool();
      colonies = [];
      released = new Pool();
      BLOOM = 5.6;
      constructor() {
        this.colonies.push(this.mkColony(C4.x, C4.y, 0));
      }
      mkColony(x, y, born) {
        const r = this.rng;
        const cells = [];
        const n = r.int(4, 9);
        for (let i = 0; i < n; i++) {
          const a = r.angle(), d = r.range(0, 7);
          cells.push({ dx: Math.cos(a) * d, dy: Math.sin(a) * d / SQ2, r: r.range(1, 2.8), ph: r.angle() });
        }
        return {
          x,
          y,
          r: r.range(5, 10),
          born,
          ph: r.angle(),
          sp: r.range(0.5, 1.6),
          hue: r.next(),
          cells,
          act: -1,
          links: []
        };
      }
      update(dt, t) {
        if (t < this.BLOOM && this.spores.count() < 90 && this.rng.next() < 0.6) {
          const c = this.colonies[this.rng.int(0, this.colonies.length - 1)];
          const a = this.rng.angle();
          this.spores.spawn({
            x: c.x + Math.cos(a) * c.r,
            y: c.y + Math.sin(a) * c.r / SQ2,
            vx: Math.cos(a) * 8,
            vy: Math.sin(a) * 6,
            life: 6,
            seed: this.rng.next() * 999,
            k: this.rng.next()
          });
        }
        const alive = this.spores.alive;
        for (const p of alive) {
          const [cx, cy] = curl(p.x * 0.02, p.y * 0.02, t * 0.1, 0.7);
          p.vx += cx * 70 * dt;
          p.vy += cy * 55 * dt;
          p.vx *= Math.exp(-0.7 * dt);
          p.vy *= Math.exp(-0.7 * dt);
        }
        this.spores.step(dt);
        if (t < this.BLOOM && this.colonies.length < 16) {
          for (let i = 0; i < alive.length; i++)
            for (let j = i + 1; j < alive.length; j++) {
              const a = alive[i], b = alive[j];
              if (a.dead || b.dead) continue;
              const d = Math.hypot(a.x - b.x, a.y - b.y);
              if (d < 4 && t > 0.8) {
                const x = (a.x + b.x) / 2, y = (a.y + b.y) / 2;
                if (this.colonies.some((c) => Math.hypot(c.x - x, c.y - y) < 22)) continue;
                if (x < 40 || x > 380 || y < 30 || y > 210) continue;
                const col = this.mkColony(x, y, t);
                const idx = this.colonies.map((c, k) => ({ k, d: Math.hypot(c.x - x, c.y - y) })).sort((p1, p2) => p1.d - p2.d).slice(0, 2);
                col.links = idx.map((o) => o.k);
                this.colonies.push(col);
                a.dead = true;
                b.dead = true;
              }
            }
        }
        if (t > 3.2 && t < this.BLOOM) {
          const period = 1.5;
          const phase = (t - 3.2) % period;
          if (phase < dt) this.colonies[0].act = t;
          for (const c of this.colonies) {
            if (c.act < 0) continue;
            for (const li of c.links) {
              const o = this.colonies[li];
              if (!o) continue;
              const delay = Math.hypot(c.x - o.x, c.y - o.y) * 4e-3;
              if (o.act < c.act && t > c.act + delay) o.act = c.act + delay;
            }
          }
        }
        if (t > this.BLOOM && t < this.BLOOM + 0.6 && this.released.count() < 620) {
          for (const c of this.colonies)
            for (let i = 0; i < 4; i++) {
              const a = this.rng.angle();
              const sp = this.rng.range(20, 130);
              this.released.spawn({
                x: c.x,
                y: c.y,
                vx: Math.cos(a) * sp,
                vy: Math.sin(a) * sp / SQ2,
                life: this.rng.range(1.2, 2.8),
                a,
                k: c.hue,
                seed: this.rng.next() * 999
              });
            }
        }
        this.released.each((p) => {
          const a = Math.atan2(p.y - C4.y, p.x - C4.x) + 1.5;
          const d = Math.hypot(p.x - C4.x, p.y - C4.y) + 1;
          p.vx += Math.cos(a) * (900 / d) * dt;
          p.vy += Math.sin(a) * (900 / d) * dt / SQ2;
          p.vx *= Math.exp(-0.9 * dt);
          p.vy *= Math.exp(-0.9 * dt);
        });
        this.released.step(dt);
      }
      casterLight(t) {
        return 0.15 + 0.3 * seg(t, 0, 4) + 0.9 * (1 - seg(t, this.BLOOM, this.BLOOM + 0.8));
      }
      render(fb, t) {
        const dissolve = seg(t, this.BLOOM + 0.3, 7.4);
        const vis = 1 - dissolve * 0.92;
        for (let i = 0; i < this.colonies.length; i++) {
          const c = this.colonies[i];
          for (const li of c.links) {
            const o = this.colonies[li];
            if (!o) continue;
            const grow = clamp((t - c.born) * 1.1);
            const n = 14;
            for (let s = 0; s <= n * grow; s++) {
              const u = s / n;
              const mx = lerp(c.x, o.x, u) + Math.sin(u * Math.PI) * Math.sin(t * 0.8 + i) * 5;
              const my = lerp(c.y, o.y, u) + Math.cos(u * Math.PI + i) * Math.sin(t * 0.6 + i) * 4;
              const pk = Math.max(0, Math.sin(u * 9 - t * 3 + i * 2));
              const h = 0.22 + pk * 0.4;
              const col = BIO(h);
              fb.add(mx, my, col[0] * 0.5 * vis, col[1] * 0.5 * vis, col[2] * 0.5 * vis, 1);
            }
          }
        }
        for (const c of this.colonies) {
          const g = clamp((t - c.born) * 0.9);
          if (g <= 0) continue;
          const breathe = 0.82 + 0.18 * Math.sin(t * c.sp * 1.7 + c.ph);
          const actK = c.act >= 0 ? Math.max(0, 1 - (t - c.act) * 1.6) : 0;
          for (const cell of c.cells) {
            const rr = cell.r * g * breathe * (1 + actK * 0.5) * (1 - dissolve);
            if (rr <= 0.3) continue;
            const px = c.x + cell.dx * g * breathe;
            const py = c.y + cell.dy * g * breathe;
            const lum = 0.35 + 0.3 * Math.sin(t * c.sp * 2.4 + cell.ph) + actK * 0.55;
            const col = c.hue < 0.33 ? BIO(lum) : c.hue < 0.72 ? GRN(lum) : rampStep("gold", lum, 7);
            field(fb, px - rr, py - rr, px + rr, py + rr, (x, y, o) => {
              const d = Math.hypot(x - px, (y - py) * 1.1) / rr;
              if (d > 1) return;
              const f = (1 - d * d) * 0.85;
              o[0] = col[0] * f * vis;
              o[1] = col[1] * f * vis;
              o[2] = col[2] * f * vis;
            });
          }
          glow(fb, c.x, c.y, c.r * 2.2 * g * (1 + actK), BIO(0.6), (0.14 + actK * 0.5) * vis);
        }
        this.spores.each((p) => {
          const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * 3 + p.seed));
          const col = BIO(0.45 + p.k * 0.4);
          fb.add(p.x, p.y, col[0] * 0.7 * tw, col[1] * 0.7 * tw, col[2] * 0.7 * tw, vis);
          this.spores.each((q) => {
            if (q === p) return;
            const d = Math.hypot(p.x - q.x, p.y - q.y);
            if (d < 16 && d > 0.5)
              line(fb, p.x, p.y, q.x, q.y, BIO(0.4), 0.1 * (1 - d / 16) * vis);
          });
        });
        if (t > this.BLOOM && t < this.BLOOM + 0.4) {
          const k = 1 - (t - this.BLOOM) / 0.4;
          fb.flash[1] += 0.1 * k * k;
          pulseRing(fb, C4.x, C4.y, (t - this.BLOOM) * 400, 16, BIO(0.6), k * 0.5, SQ2);
        }
        this.released.each((p) => {
          const l = p.life / p.max;
          const col = p.k < 0.4 ? BIO(0.4 + l * 0.5) : p.k < 0.75 ? GRN(0.4 + l * 0.5) : rampStep("gold", 0.4 + l * 0.4, 7);
          const tw = 0.5 + 0.5 * Math.sin(t * 8 + p.seed);
          fb.add(p.x, p.y, col[0] * 0.65, col[1] * 0.65, col[2] * 0.65, l * (0.5 + tw * 0.5));
        });
      }
    };
    ThornOpera = class {
      rng = new RNG(31489);
      tendrils = [];
      petals = new Pool();
      CURL = 4.9;
      OPEN = 5.6;
      constructor() {
        const r = new RNG(31489);
        this.rng = r;
        const N = 7;
        for (let i = 0; i < N; i++) {
          const a = -Math.PI * 0.9 + i / (N - 1) * Math.PI * 1.8;
          const base = { x: CASTER.x + 12 + Math.cos(a) * 6, y: CASTER.y - 2 + Math.sin(a) * 4 };
          const pts = [];
          const nseg = 22;
          for (let s = 0; s < nseg; s++) pts.push({ x: base.x, y: base.y, vx: 0, vy: 0 });
          const style = i % 3;
          const moves = [];
          let tt = 0.6 + i * 0.12;
          for (let m = 0; m < 7; m++) {
            const ang = r.angle();
            const d = r.range(60, 150);
            const prey = (m + i) % 2 === 0 && W.enemies.length ? W.enemies[(i * 3 + m) % W.enemies.length] : null;
            moves.push({
              t: tt,
              x: prey ? prey.hx + r.range(-6, 6) : C4.x + Math.cos(ang) * d * 0.8,
              y: prey ? prey.hy - 6 + r.range(-4, 4) : C4.y + Math.sin(ang) * d * 0.55,
              sp: style === 0 ? 1600 : style === 1 ? 700 : 1050
            });
            tt += style === 0 ? r.range(0.4, 0.6) : r.range(0.55, 0.85);
          }
          this.tendrils.push({ pts, base, seglen: 5.2, moves, seed: r.int(0, 999), style });
        }
      }
      target(td, t) {
        if (t > this.OPEN) {
          const u = seg(t, this.OPEN, this.OPEN + 0.9);
          const a = td.seed * 0.9 + u * 2.2 * (td.style === 1 ? -1 : 1);
          const d = 60 + easeOut(u, 2) * 150;
          return { x: C4.x + Math.cos(a) * d, y: C4.y + Math.sin(a) * d / SQ2, sp: 2600 };
        }
        if (t > this.CURL) {
          const u = seg(t, this.CURL, this.OPEN);
          const a = this.tendrils.indexOf(td) / this.tendrils.length * TAU + u * 3.4;
          const d = lerp(70, 16, easeOut(u, 2));
          return { x: C4.x + Math.cos(a) * d, y: C4.y + Math.sin(a) * d / SQ2 - 6, sp: 1100 };
        }
        let m = td.moves[0];
        for (const mv of td.moves) if (t >= mv.t) m = mv;
        const k = td.style === 2 ? Math.sin(t * 2.4 + td.seed) * 22 : 0;
        return { x: m.x + k, y: m.y + Math.cos(t * 2 + td.seed) * k * 0.5, sp: m.sp };
      }
      update(dt, t) {
        for (const td of this.tendrils) {
          const grow = clamp(t * 1.1);
          const tg = this.target(td, t);
          const head = td.pts[0];
          const dx = tg.x - head.x, dy = tg.y - head.y;
          const d = Math.hypot(dx, dy) || 1;
          let acc = tg.sp;
          if (td.style === 0) acc *= 0.6 + 0.8 * (Math.sin(t * 5 + td.seed) > 0.4 ? 2.4 : 0.2);
          head.vx += dx / d * acc * dt;
          head.vy += dy / d * acc * dt;
          head.vx *= Math.exp(-4.4 * dt);
          head.vy *= Math.exp(-4.4 * dt);
          head.x += head.vx * dt;
          head.y += head.vy * dt;
          const L = td.seglen * grow;
          for (let i = 1; i < td.pts.length; i++) {
            const p = td.pts[i], q = td.pts[i - 1];
            const ddx = p.x - q.x, ddy = p.y - q.y;
            const dd = Math.hypot(ddx, ddy) || 1;
            const tx = q.x + ddx / dd * L, ty = q.y + ddy / dd * L;
            const follow = 1 - Math.exp(-26 * dt);
            p.x += (tx - p.x) * follow;
            p.y += (ty - p.y) * follow;
          }
          const last = td.pts[td.pts.length - 1];
          last.x += (td.base.x - last.x) * 0.25;
          last.y += (td.base.y - last.y) * 0.25;
          const spd = Math.hypot(head.vx, head.vy);
          if (spd > 220 && this.rng.next() < 0.5) {
            const a = Math.atan2(head.vy, head.vx) + this.rng.range(-2, 2);
            this.petals.spawn({
              x: head.x,
              y: head.y,
              vx: Math.cos(a) * this.rng.range(20, 70),
              vy: Math.sin(a) * this.rng.range(20, 60),
              life: this.rng.range(1, 2.6),
              a: this.rng.angle(),
              av: this.rng.range(-4, 4),
              size: this.rng.range(1.2, 2.4),
              seed: this.rng.next() * 999
            });
          }
        }
        if (t > this.OPEN && t < this.OPEN + 0.5) {
          for (let i = 0; i < 16; i++) {
            const a = this.rng.angle();
            this.petals.spawn({
              x: C4.x + Math.cos(a) * 14,
              y: C4.y + Math.sin(a) * 14 / SQ2,
              vx: Math.cos(a) * this.rng.range(40, 170),
              vy: Math.sin(a) * this.rng.range(30, 120) - 20,
              life: this.rng.range(1.6, 3.4),
              a: this.rng.angle(),
              av: this.rng.range(-5, 5),
              size: this.rng.range(1.4, 3),
              seed: this.rng.next() * 999
            });
          }
        }
        this.petals.each((p) => {
          p.vx += Math.sin(t * 1.6 + p.seed) * 18 * dt;
          p.vy += 26 * dt;
          p.vx *= Math.exp(-1 * dt);
          p.vy *= Math.exp(-1 * dt);
        });
        this.petals.step(dt);
      }
      casterLight(t) {
        return 0.3 + 0.5 * seg(t, 0, 2) + 0.9 * (1 - seg(t, this.OPEN, this.OPEN + 0.6));
      }
      render(fb, t) {
        const open = seg(t, this.OPEN, this.OPEN + 0.35);
        const curl0 = seg(t, this.CURL, this.OPEN);
        if (curl0 > 0 && t < this.OPEN + 0.5) {
          const k = curl0 * (1 - seg(t, this.OPEN, this.OPEN + 0.4));
          glow(fb, C4.x, C4.y - 4, 10 + curl0 * 24, [0.8, 1.2, 0.5], 0.4 * k);
        }
        for (const td of this.tendrils) {
          const pts = td.pts.map((p) => ({ x: p.x, y: p.y }));
          for (let i = 0; i < pts.length; i += 2) fb.mul(pts[i].x + 2, pts[i].y + 4, 0.8);
          ribbon(
            fb,
            pts,
            (u) => Math.max(0.7, (1 - u * 0.55) * 2.9 * clamp(t * 1.3)),
            (u, _i, e) => {
              const pulse = 0.5 + 0.5 * Math.sin(u * 12 - t * 6 + td.seed);
              let h = 0.1 + (1 - e) * (0.26 + pulse * 0.3);
              if (e > 0.8) h = 0.07;
              h *= 1 + open * 0.8;
              const c = GRN(clamp(h));
              return [c[0] * 0.6, c[1] * 0.6, c[2] * 0.6];
            }
          );
          for (let i = 2; i < td.pts.length - 1; i += 2) {
            const p = td.pts[i], q = td.pts[i - 1];
            const a = Math.atan2(p.y - q.y, p.x - q.x);
            const side = i % 4 === 0 ? 1 : -1;
            const len = (2.6 + 2.2 * (1 - i / td.pts.length)) * (1 + open * 1.4);
            const na = a + side * 1.25;
            const c = GRN(0.52 + open * 0.3);
            streak(
              fb,
              p.x,
              p.y,
              p.x + Math.cos(na) * len,
              p.y + Math.sin(na) * len,
              1,
              0.25,
              [c[0] * 0.75, c[1] * 0.75, c[2] * 0.7],
              0.95
            );
          }
          const h0 = td.pts[0];
          glow(fb, h0.x, h0.y, 3.4, [0.6, 1.4, 0.6], 0.5);
        }
        if (open > 0) {
          const k = Math.sin(clamp(open) * Math.PI);
          pulseRing(fb, C4.x, C4.y, open * 230, 12 * (1 - open), GRN(0.7), k * 0.9, SQ2);
          fb.flash[1] += 0.12 * k * k;
        }
        this.petals.each((p) => {
          const l = p.life / p.max;
          const a = p.a + p.av * (p.max - p.life);
          const c = rampStep("bloom", 0.35 + l * 0.45, 6);
          const w = p.size * Math.abs(Math.cos(a * 1.1)) + 0.5;
          for (let k = -w; k <= w; k++)
            fb.add(p.x + Math.cos(a) * k, p.y + Math.sin(a) * k / 1.4, c[0] * 0.55, c[1] * 0.55, c[2] * 0.55, l * 0.9);
        });
      }
    };
    Worldseed = class {
      rng = new RNG(24301);
      layers = [];
      pollen = new Pool();
      CRACK = 2;
      BLOOM = 5.3;
      FOLD = 6.8;
      constructor() {
        const r = this.rng;
        const specs = [
          { count: 5, len: 26, w: 0.55, t0: 2.1, sp: 1.1, hue: 0.35, tremble: 2 },
          { count: 8, len: 46, w: 0.42, t0: 2.5, sp: 0.75, hue: 0.55, tremble: 1.2 },
          { count: 12, len: 74, w: 0.3, t0: 3, sp: 0.5, hue: 0.72, tremble: 0.6 },
          { count: 16, len: 104, w: 0.22, t0: 3.6, sp: 0.36, hue: 0.9, tremble: 0.3 }
        ];
        for (const s of specs) this.layers.push({ ...s, tilt: r.angle() });
      }
      update(dt, t) {
        if (t < this.CRACK && this.pollen.count() < 40 && this.rng.next() < 0.4) {
          const a = this.rng.angle();
          this.pollen.spawn({
            x: C4.x + Math.cos(a) * this.rng.range(8, 22),
            y: C4.y + Math.sin(a) * this.rng.range(6, 16) / SQ2,
            vx: this.rng.range(-5, 5),
            vy: this.rng.range(-8, 2),
            life: 3,
            k: 0,
            seed: this.rng.next() * 999
          });
        }
        if (t > this.BLOOM && t < this.BLOOM + 0.7 && this.pollen.count() < 520) {
          for (let i = 0; i < 24; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(30, 230);
            this.pollen.spawn({
              x: C4.x,
              y: C4.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp / SQ2,
              life: this.rng.range(1.2, 3),
              k: this.rng.next(),
              a: this.rng.angle(),
              av: this.rng.range(-4, 4),
              size: this.rng.range(0.8, 2.4),
              seed: this.rng.next() * 999
            });
          }
        }
        this.pollen.each((p) => {
          p.vx *= Math.exp(-1.1 * dt);
          p.vy *= Math.exp(-1.1 * dt);
          p.vy -= 8 * dt;
        });
        this.pollen.step(dt);
      }
      casterLight(t) {
        return 0.15 + 0.5 * seg(t, 2, 5) + 1.1 * (1 - seg(t, this.BLOOM, this.BLOOM + 0.9));
      }
      render(fb, t) {
        const crack = seg(t, this.CRACK, this.CRACK + 0.5);
        const fold = seg(t, this.FOLD, 8);
        const bloomK = seg(t, this.BLOOM, this.BLOOM + 0.5);
        const seedR = lerp(7, 10, Math.sin(t * 1.4) * 0.5 + 0.5) * (1 - crack * 0.35) * (1 - fold);
        if (seedR > 0.5) {
          const rot = t * 0.7;
          field(fb, C4.x - seedR * 1.4, C4.y - seedR * 1.4, C4.x + seedR * 1.4, C4.y + seedR * 1.4, (x, y, o) => {
            const dx = x - C4.x, dy = (y - C4.y) * 1.2;
            const d = Math.hypot(dx, dy);
            if (d > seedR) return;
            const a = Math.atan2(dy, dx) + rot;
            const veins = Math.abs(Math.sin(a * 3 + d * 0.5));
            let h = 0.22 + (1 - d / seedR) * 0.2 + veins * 0.35 * (1 - d / seedR);
            if (d > seedR - 1.2) h = 0.62;
            const c = rampStep("gold", clamp(h), 7);
            o[0] = c[0] * 0.55;
            o[1] = c[1] * 0.55;
            o[2] = c[2] * 0.55;
          });
          glow(fb, C4.x, C4.y, seedR * 2.4, [1, 0.85, 0.4], 0.3 + crack * 0.6);
          if (crack > 0) {
            for (let i = -seedR; i <= seedR; i++) {
              const k = 1 - Math.abs(i) / seedR;
              fb.add(C4.x + i * 0.3, C4.y + i, 2.4 * k * crack, 2.2 * k * crack, 1.6 * k * crack, 1);
            }
          }
        }
        for (let li = 0; li < this.layers.length; li++) {
          const L = this.layers[li];
          let u = easeOut(seg(t, L.t0, L.t0 + 1 / L.sp), 2);
          if (fold > 0) u *= 1 - easeOut(fold, 1.6);
          if (u <= 0.01) continue;
          const pulse = bloomK > 0 ? 1 + 0.18 * Math.sin(t * 7 - li * 1.2) * Math.max(0, 1 - (t - this.BLOOM) * 0.6) : 1;
          for (let i = 0; i < L.count; i++) {
            const a0 = L.tilt + i / L.count * TAU;
            const len = L.len * u * pulse;
            const tremble = Math.sin(t * (3 + L.tremble * 3) + i) * L.tremble * 0.02;
            sheet(
              fb,
              Math.max(6, Math.ceil(len * 1)),
              Math.max(4, Math.ceil(len * L.w * 0.9)),
              (uu, v) => {
                const a = a0 + tremble * uu + Math.sin(uu * 2.5) * 0.12;
                const rr = (5 + li * 5) * u + len * uu;
                const wid = len * L.w * Math.sin(Math.pow(uu, 0.6) * Math.PI);
                return [
                  C4.x + Math.cos(a) * rr - Math.sin(a) * v * wid,
                  C4.y + (Math.sin(a) * rr + Math.cos(a) * v * wid) / SQ2 - uu * uu * 10 * u
                ];
              },
              (uu, v) => {
                const av = Math.abs(v);
                if (av > 1) return null;
                const cell = fbm(uu * 7 + i * 2, av * 5 - t * 1.1, 3);
                const vein = Math.exp(-Math.pow(av * 4, 2)) * 0.3;
                let h = 0.16 + cell * 0.26 + vein;
                h += Math.pow(av, 4) * 0.5;
                const wave = Math.max(0, Math.sin(uu * 8 - t * 5 + li * 1.5));
                h += wave * 0.2 * (bloomK > 0 ? 1.6 : 0.6);
                h *= 1 - uu * 0.2;
                h *= smoothstep(0.02, 0.26, uu);
                if (h < 0.05) return null;
                const c = L.hue < 0.5 ? rampStep("bloom", clamp(h), 8) : li === 3 ? GRN(clamp(h)) : rampStep("bio", clamp(h), 8);
                return [c[0] * 0.42, c[1] * 0.42, c[2] * 0.42];
              }
            );
          }
        }
        const coreU = seg(t, 4, this.BLOOM);
        if (coreU > 0 && fold < 1) {
          const rr = (3 + coreU * 9) * (1 + bloomK * 1.4) * (1 - fold);
          glow(fb, C4.x, C4.y - 4, rr * 1.9, [1.3, 1.2, 0.7], 0.3 + bloomK * 0.55);
          for (let i = 0; i < 9; i++) {
            const a = i / 9 * TAU + t * 0.8;
            const c = rampStep("gold", 0.8, 6);
            streak(fb, C4.x, C4.y - 4, C4.x + Math.cos(a) * rr, C4.y - 4 + Math.sin(a) * rr / SQ2, 1.4, 0.4, c, 0.8);
          }
        }
        if (bloomK > 0 && bloomK < 1) {
          const k = Math.sin(bloomK * Math.PI);
          pulseRing(fb, C4.x, C4.y, bloomK * 120, 30 * (1 - bloomK) + 6, rampStep("bloom", 0.5, 6), k * 0.22, SQ2, 0.14, 1.3);
          fb.flash[0] += 0.1 * k * k;
          fb.flash[1] += 0.09 * k * k;
        }
        this.pollen.each((p) => {
          const l = p.life / p.max;
          const tw = 0.55 + 0.45 * Math.sin(t * 7 + p.seed);
          const c = p.k < 0.5 ? rampStep("gold", 0.5 + l * 0.4, 6) : rampStep("bloom", 0.5 + l * 0.4, 6);
          fb.add(p.x, p.y, c[0] * 0.6 * tw, c[1] * 0.6 * tw, c[2] * 0.6 * tw, l);
          if (p.size > 1.8) {
            const a = p.a + p.av * (p.max - p.life);
            fb.add(p.x + Math.cos(a) * 1.4, p.y + Math.sin(a), c[0] * 0.4, c[1] * 0.4, c[2] * 0.4, l * 0.7);
          }
        });
      }
    };
  }
});

// src/spells/astral.ts
var C5, AST, EventHorizon, Chronoshard, ConstellationEngine, RealityRipper;
var init_astral = __esm({
  "src/spells/astral.ts"() {
    "use strict";
    init_particles();
    init_draw();
    init_math();
    init_arena();
    init_common();
    C5 = ARENA_C;
    AST = (h) => rampStep("astral", h, 9);
    EventHorizon = class {
      rng = new RNG(58369);
      orbs = [];
      chunks = new Pool();
      COLLAPSE = 5.1;
      REBOUND = 5.55;
      constructor() {
        for (let i = 0; i < 70; i++)
          this.orbs.push({
            a: this.rng.angle(),
            r: this.rng.range(20, 120),
            sp: this.rng.range(0.4, 1.6) * (i % 5 === 0 ? -1 : 1),
            s: this.rng.range(0.4, 1.8),
            plane: this.rng.int(0, 2),
            ecc: this.rng.range(0.5, 1)
          });
      }
      rh(t) {
        const grow = seg(t, 0.4, 4.2);
        const col = seg(t, this.COLLAPSE, this.REBOUND);
        return lerp(2, 26, easeOut(grow, 2)) * (1 - easeInOut(col) * 0.98);
      }
      update(dt, t) {
        const rh = this.rh(t);
        for (const o of this.orbs) {
          const pull = 1 + rh * 2.2 / Math.max(6, o.r);
          o.a += o.sp * dt * pull * (t > this.COLLAPSE ? 4 : 1);
          o.r -= dt * (2 + 60 / Math.max(8, o.r)) * (t > this.COLLAPSE ? 9 : 1);
          if (o.r < rh + 1) {
            o.r = this.rng.range(90, 135);
            o.a = this.rng.angle();
          }
        }
        if (t > this.REBOUND && t < this.REBOUND + 0.25 && this.chunks.count() < 300) {
          for (let i = 0; i < 40; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(80, 420);
            this.chunks.spawn({
              x: C5.x,
              y: C5.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp / 1.5,
              life: this.rng.range(0.5, 1.6),
              size: this.rng.int(1, 4),
              seed: this.rng.int(0, 9999),
              k: this.rng.next()
            });
          }
        }
        this.chunks.each((p) => {
          p.vx *= Math.exp(-1.7 * dt);
          p.vy *= Math.exp(-1.7 * dt);
        });
        this.chunks.step(dt);
      }
      bgWarp(t) {
        const rh = this.rh(t);
        const k = seg(t, 0.2, 4);
        if (k <= 0 && t < this.REBOUND) return null;
        const reb = seg(t, this.REBOUND, this.REBOUND + 1.4);
        const str = (1 - reb) * (0.6 + k * 2.4);
        return (x, y) => {
          const dx = x - C5.x, dy = (y - C5.y) * 1.5;
          const r = Math.hypot(dx, dy);
          if (r < rh) return null;
          const a = Math.atan2(dy, dx);
          const lens = str * (rh * rh + 90) / (r + 4);
          const swirl = str * 26 / (r + 10);
          const sr = r + lens;
          const sa = a + swirl * 0.05;
          const bands = Math.round(sr / 2) * 2;
          const sx = C5.x + Math.cos(sa) * bands;
          const sy = C5.y + Math.sin(sa) * bands / 1.5;
          const mul = smoothstep(rh, rh * 1.9 + 6, r) * (1 + lens * 4e-3);
          return [sx, sy, mul];
        };
      }
      casterLight(t) {
        return 0.15 + 0.3 * seg(t, 0, 4) + 1 * (1 - seg(t, this.REBOUND, this.REBOUND + 0.6));
      }
      render(fb, t) {
        const rh = this.rh(t);
        const k = seg(t, 0.3, 4.2);
        const dark = smoothstep(this.COLLAPSE + 0.2, this.REBOUND, t) * (1 - smoothstep(this.REBOUND, this.REBOUND + 0.06, t));
        const reb = seg(t, this.REBOUND, this.REBOUND + 1.5);
        if (reb < 0.3) {
          const vis = 1 - reb * 3;
          for (let plane = 0; plane < 3; plane++) {
            const tilt = plane * 0.9 + t * 0.1;
            const sq = [1.5, 2.8, 1.15][plane];
            const dir = plane === 1 ? -1 : 1;
            for (let ri = 0; ri < 3; ri++) {
              const rr = (rh + 10 + ri * 9 + plane * 6) * (1 + 0.05 * Math.sin(t * 2 + ri));
              const steps = 120;
              for (let s = 0; s < steps; s++) {
                const a = s / steps * TAU + dir * t * (0.4 + ri * 0.12);
                const lx = Math.cos(a) * rr, ly = Math.sin(a) * rr / sq;
                const x = C5.x + lx * Math.cos(tilt) - ly * Math.sin(tilt);
                const y = C5.y + lx * Math.sin(tilt) + ly * Math.cos(tilt);
                const doppler = 0.35 + 0.45 * (0.5 + 0.5 * Math.cos(a + tilt));
                const nz = fbm(a * 3 + ri, t * 0.6 + plane, 2);
                const c = AST(clamp(doppler * (0.5 + nz) * k * 1.3));
                fb.add(x, y, c[0] * 0.55 * vis, c[1] * 0.55 * vis, c[2] * 0.6 * vis, 1);
              }
            }
          }
          for (const o of this.orbs) {
            if (o.r < rh) continue;
            const sq = [1.5, 2.8, 1.15][o.plane];
            const tilt = o.plane * 0.9 + t * 0.1;
            const pos = (aa, rr) => {
              const lx = Math.cos(aa) * rr, ly = Math.sin(aa) * rr / sq;
              return [C5.x + lx * Math.cos(tilt) - ly * Math.sin(tilt), C5.y + lx * Math.sin(tilt) + ly * Math.cos(tilt)];
            };
            const p1 = pos(o.a, o.r);
            const trail = 0.05 + rh * 1.4 / Math.max(10, o.r);
            const p0 = pos(o.a - trail, o.r + 1.5);
            const bright = clamp(0.3 + rh * 1.5 / Math.max(8, o.r)) * k;
            streak(fb, p0[0], p0[1], p1[0], p1[1], o.s, o.s * 0.4, AST(0.55 + bright * 0.4), bright * vis);
          }
          if (rh > 1)
            for (let s = 0; s < 200; s++) {
              const a = s / 200 * TAU;
              const rr = rh * 1.45 + Math.sin(a * 5 + t * 3) * 0.6;
              fb.add(C5.x + Math.cos(a) * rr, C5.y + Math.sin(a) * rr / 1.5, 1.8 * k, 1.5 * k, 2.6 * k, 0.8 * vis);
            }
        }
        if (dark > 0) fb.exposure *= 1 - dark * 0.96;
        if (reb > 0) {
          const e = reb;
          fb.flash[0] += 0.4 * Math.pow(1 - clamp(e * 7), 2);
          fb.flash[2] += 0.6 * Math.pow(1 - clamp(e * 7), 2);
          pulseRing(fb, C5.x, C5.y, 4 + easeOut(e, 2) * 300, 12 * (1 - e) + 2, AST(0.7), (1 - e) * 0.6, 1.5, 0.3, 1.1);
          pulseRing(fb, C5.x, C5.y, 2 + easeOut(e, 2) * 190, 7 * (1 - e), AST(0.92), (1 - e) * 1, 1.5);
          this.chunks.each((p) => {
            const l = p.life / p.max;
            const sx = Math.round(C5.x + (p.x - C5.x) * 0.35);
            const sy = Math.round(C5.y + (p.y - C5.y) * 0.35);
            for (let yy = 0; yy < p.size; yy++)
              for (let xx = 0; xx < p.size; xx++) {
                const i = (clamp(sy + yy, 0, fb.H - 1) * fb.W + clamp(sx + xx, 0, fb.W - 1)) * 3;
                const br = 2.5 + p.k * 3;
                fb.add(p.x + xx, p.y + yy, fb.bg[i] * br, fb.bg[i + 1] * br, fb.bg[i + 2] * br, l);
              }
            const c = AST(0.5 + l * 0.4);
            fb.add(p.x, p.y, c[0] * 0.4, c[1] * 0.4, c[2] * 0.4, l * 0.7);
          });
          const settle = seg(t, this.REBOUND + 0.8, this.REBOUND + 1.8);
          if (settle > 0 && settle < 1)
            for (let i = 0; i < 40; i++) {
              const a = i / 40 * TAU;
              const rr = (1 - settle) * 120;
              fb.add(C5.x + Math.cos(a) * rr, C5.y + Math.sin(a) * rr / 1.5, 0.6, 0.4, 1, (1 - settle) * 0.5);
            }
        }
      }
    };
    Chronoshard = class {
      rng = new RNG(50960);
      P0 = { x: CASTER.x + 12, y: CASTER.y - 8 };
      P1 = ANCHORS[1];
      crystals = [];
      freed = new Pool();
      FREEZE = 3.5;
      SYNC = 6;
      constructor() {
        const r = this.rng;
        for (let i = 0; i < 7; i++) {
          const a = i / 7 * TAU + r.range(-0.2, 0.2);
          const d = r.range(46, 86);
          this.crystals.push({
            x: C5.x + Math.cos(a) * d,
            y: C5.y + Math.sin(a) * d / 1.5,
            r: r.range(13, 22),
            a: r.angle(),
            av: r.range(-0.6, 0.6),
            seed: r.int(0, 9999),
            s: r.range(0.1, 0.95),
            born: 1.4 + i * 0.22,
            fire: 4.1 + i * 0.24,
            mode: i % 3,
            ox: 0,
            oy: 0
          });
        }
      }
      /** the attack itself, as a pure function of its own local time s */
      attack(fb, s, k, clip, ox = 0, oy = 0, scale = 1) {
        if (s < 0 || k <= 0) return;
        const put = (x, y, c, a) => {
          const px = C5.x + (x - C5.x) * scale + ox;
          const py = C5.y + (y - C5.y) * scale + oy;
          if (clip && !clip(px, py)) return;
          fb.add(px, py, c[0], c[1], c[2], a * k);
        };
        const u = clamp(s);
        const hx = lerp(this.P0.x, this.P1.x, easeOut(u, 1.6));
        const hy = lerp(this.P0.y, this.P1.y, easeOut(u, 1.6)) - Math.sin(u * Math.PI) * 18;
        if (u < 1) {
          for (let i = 0; i < 20; i++) {
            const uu = Math.max(0, u - i * 0.012);
            const x = lerp(this.P0.x, this.P1.x, easeOut(uu, 1.6));
            const y = lerp(this.P0.y, this.P1.y, easeOut(uu, 1.6)) - Math.sin(uu * Math.PI) * 18;
            const f = (1 - i / 20) * 1.1;
            const c2 = AST(0.45 + f * 0.45);
            for (let w = -2; w <= 2; w++) put(x, y + w, c2, f * (1 - Math.abs(w) / 3) * 0.8);
          }
          const c = AST(0.95);
          for (let dx = -2; dx <= 2; dx++)
            for (let dy = -2; dy <= 2; dy++)
              if (dx * dx + dy * dy <= 4) put(hx + dx, hy + dy, c, 1);
        }
        if (s > 1) {
          const e = clamp((s - 1) / 0.9);
          const rr = easeOut(e, 2) * 46;
          for (let i = 0; i < 90; i++) {
            const a = i / 90 * TAU;
            const r2 = rr * (0.9 + 0.12 * Math.sin(a * 6));
            put(this.P1.x + Math.cos(a) * r2, this.P1.y + Math.sin(a) * r2 / 1.5, AST(0.8), (1 - e) * 0.9);
          }
          for (let i = 0; i < 34; i++) {
            const a = hash2(i, 3) * TAU;
            const sp = 20 + hash2(i, 9) * 90;
            const d = easeOut(e, 2) * sp;
            put(this.P1.x + Math.cos(a) * d, this.P1.y + Math.sin(a) * d / 1.5, AST(0.6 + hash2(i, 5) * 0.4), (1 - e) * 0.9);
          }
        }
      }
      update(dt, t) {
        for (const c of this.crystals) {
          c.a += c.av * dt;
          const u = seg(t, c.born, this.SYNC);
          const a = Math.atan2(c.y - C5.y, c.x - C5.x) + u * 1.1;
          const d = Math.hypot(c.x - C5.x, (c.y - C5.y) * 1.5);
          c.ox = Math.cos(a) * d - (c.x - C5.x) + Math.sin(t * 1.3 + c.seed) * 5;
          c.oy = Math.sin(a) * d / 1.5 - (c.y - C5.y) + Math.cos(t * 1.1 + c.seed) * 4;
          if (c.mode === 2 && t > c.fire && t < c.fire + 0.1 && this.freed.count() < 300) {
            for (let i = 0; i < 24; i++) {
              const aa = this.rng.angle();
              const sp = this.rng.range(30, 160);
              this.freed.spawn({
                x: c.x + c.ox,
                y: c.y + c.oy,
                vx: Math.cos(aa) * sp,
                vy: Math.sin(aa) * sp / 1.5,
                life: this.rng.range(0.5, 1.6),
                seed: this.rng.next() * 999,
                k: this.rng.next()
              });
            }
          }
        }
        this.freed.each((p) => {
          p.vx *= Math.exp(-1.6 * dt);
          p.vy *= Math.exp(-1.6 * dt);
        });
        this.freed.step(dt);
      }
      casterLight(t) {
        return 0.25 + 0.4 * seg(t, 0, 2) + 1.1 * (1 - seg(t, this.SYNC, this.SYNC + 0.7));
      }
      render(fb, t) {
        const main = t * 0.55;
        const frozen = t > this.FREEZE;
        const sMain = frozen ? this.FREEZE * 0.55 : main;
        const sync = seg(t, this.SYNC, this.SYNC + 1.2);
        if (!frozen || sync > 0) {
          for (let i = -3; i <= 3; i++) {
            if (i === 0) continue;
            const s = sMain + i * 0.16;
            const k = (0.3 - Math.abs(i) * 0.06) * (i > 0 ? 0.8 : 1);
            this.attack(fb, s, k, null, i * 1.5, -Math.abs(i) * 1.2, 1);
          }
        }
        this.attack(fb, sMain, frozen ? 0.85 : 1, null);
        if (frozen && sync <= 0) {
          const j = Math.sin(t * 40) * 0.5;
          this.attack(fb, sMain, 0.25, null, j, -j);
        }
        for (const c of this.crystals) {
          const g = clamp((t - c.born) * 1.7);
          if (g <= 0) continue;
          const cx = c.x + c.ox, cy = c.y + c.oy;
          const rr = c.r * g * (sync > 0 ? 1 - sync : 1);
          if (rr < 1) continue;
          const clip = (x, y) => Math.hypot(x - cx, (y - cy) * 1.4) < rr * 0.92;
          let inner = c.s;
          const act = t - c.fire;
          if (act > 0) {
            if (c.mode === 0) inner = c.s + act * 0.9;
            else if (c.mode === 1) inner = c.s - act * 1.1;
          }
          this.attack(fb, inner, 0.85, clip, cx - C5.x - (this.P1.x - C5.x) * 0, cy - C5.y, 0.42);
          shard(
            fb,
            cx,
            cy,
            rr,
            c.a,
            6,
            c.seed,
            (d, edge) => {
              if (edge < 1.1) return AST(0.85);
              const facet = 0.1 + 0.16 * (1 - d) + 0.1 * Math.sin(d * 9 + c.a * 4);
              const live = act > 0 && act < 0.5 ? 0.3 * (1 - act / 0.5) : 0;
              const cc = AST(clamp(facet + live));
              return [cc[0] * 0.5, cc[1] * 0.5, cc[2] * 0.55];
            },
            1.4
          );
          if (act > 0 && act < 0.35) {
            const k = 1 - act / 0.35;
            glow(fb, cx, cy, rr * 1.6, AST(0.75), k * 0.9);
          }
          if (g > 0.6)
            for (let i = 0; i < 10; i++) {
              const u = i / 10;
              const x = lerp(cx, C5.x, u), y = lerp(cy, C5.y, u);
              if (hash2(Math.floor(x), Math.floor(y + t * 10)) > 0.75)
                fb.add(x, y, 0.4, 0.3, 0.8, 0.35 * g);
            }
        }
        for (const c of this.crystals) {
          const act = t - c.fire;
          if (act < 0 || act > 1.2) continue;
          const k = Math.max(0, 1 - act / 1.2);
          if (c.mode === 0) this.attack(fb, c.s + act * 0.9, k * 0.8, null);
          if (c.mode === 1) this.attack(fb, Math.max(0, c.s - act * 1.1), k * 0.7, null);
        }
        this.freed.each((p) => {
          const l = p.life / p.max;
          const back = Math.max(0, Math.sin(l * Math.PI * 2)) * 0.4;
          const x = lerp(p.x, p.px * 0.5 + p.x * 0.5, back);
          const c = AST(0.5 + l * 0.45);
          fb.add(x, p.y, c[0], c[1], c[2], l * 0.9);
        });
        if (sync > 0 && sync < 1) {
          const k = Math.sin(clamp(sync * 1.5) * Math.PI);
          fb.flash[2] += 0.35 * k * k;
          fb.flash[0] += 0.2 * k * k;
          for (let i = 0; i < 2; i++) {
            pulseRing(fb, C5.x, C5.y, easeOut(sync, 2) * (300 - i * 90), 7, AST(0.75 - i * 0.1), (1 - sync) * 0.55, 1.5, 0.3, i * 2.3);
          }
          this.attack(fb, 1 + sync * 0.8, (1 - sync) * 1.2, null);
        }
      }
    };
    ConstellationEngine = class {
      rng = new RNG(49239);
      stars = [];
      pulses = [];
      frags = new Pool();
      FINAL = 6.1;
      constructor() {
        const r = this.rng;
        for (let i = 0; i < 18; i++) {
          const x = r.range(70, 400), y = r.range(30, 210);
          this.stars.push({ x, y, bx: x, by: y, ph: r.angle(), s: r.range(0.6, 1.8), orb: r.range(0.4, 1.6) });
        }
      }
      /** the engine's node positions evolve through phases */
      pos(i, t) {
        const s = this.stars[i];
        const ph1 = smoothstep(1.6, 3, t);
        const ph2 = smoothstep(3, 4.6, t);
        const ph3 = smoothstep(4.6, this.FINAL, t);
        const fin = smoothstep(this.FINAL, this.FINAL + 0.6, t);
        const gc = i % 3;
        const cxs = [C5.x - 62, C5.x + 64, C5.x];
        const cys = [C5.y - 28, C5.y + 26, C5.y];
        const a1 = s.ph + t * s.orb * 0.7;
        const r1 = 32 + i % 5 * 7;
        const p1x = cxs[gc] + Math.cos(a1) * r1, p1y = cys[gc] + Math.sin(a1) * r1 / 1.5;
        const ring = i < 6 ? 0 : i < 12 ? 1 : 2;
        const idx = i < 6 ? i : i < 12 ? i - 6 : i - 12;
        const cnt = [6, 6, 6][ring];
        const a2 = idx / cnt * TAU + t * (0.4 - ring * 0.15) + ring * 0.5;
        const r2 = [34, 62, 92][ring];
        const p2x = C5.x + Math.cos(a2) * r2, p2y = C5.y + Math.sin(a2) * r2 / 1.5;
        const a3 = idx / cnt * TAU + ring * (Math.PI / 6);
        const r3 = [30, 58, 86][ring];
        const p3x = C5.x + Math.cos(a3) * r3, p3y = C5.y + Math.sin(a3) * r3 / 1.5;
        let x = lerp(s.bx, p1x, ph1);
        let y = lerp(s.by, p1y, ph1);
        x = lerp(x, p2x, ph2);
        y = lerp(y, p2y, ph2);
        x = lerp(x, p3x, ph3);
        y = lerp(y, p3y, ph3);
        x = lerp(x, C5.x, fin * 0.55);
        y = lerp(y, C5.y, fin * 0.55);
        return { x, y };
      }
      /** the "search" for a mathematical solution: candidate edge sets */
      edges(t) {
        const out = [];
        const n = this.stars.length;
        if (t < 1.4) {
          const fr = Math.floor(t * 5);
          const r = new RNG(fr * 131 + 7);
          for (let i = 0; i < 9; i++) {
            const a = r.int(0, n - 1), b = r.int(0, n - 1);
            if (a !== b) out.push([a, b, 0.35 * (1 - t * 5 % 1) * smoothstep(0.4, 1, t)]);
          }
          return out;
        }
        const lock = smoothstep(1.4, 2.4, t);
        if (t < 3) {
          for (let i = 0; i < n; i++) out.push([i, (i + 5) % n, lock * 0.7]);
          for (let i = 0; i < n; i += 2) out.push([i, (i + 9) % n, lock * 0.5]);
          return out;
        }
        for (let ring = 0; ring < 3; ring++)
          for (let k = 0; k < 6; k++) {
            const a = ring * 6 + k, b = ring * 6 + (k + (ring === 1 ? 2 : 1)) % 6;
            out.push([a, b, 0.85]);
          }
        for (let k = 0; k < 6; k++) {
          out.push([k, 6 + k, 0.6]);
          out.push([6 + k, 12 + (k + 3) % 6, 0.55]);
        }
        return out;
      }
      update(dt, t) {
        if (t > 3.2 && t < this.FINAL + 0.3 && this.pulses.length < 22 && this.rng.next() < 0.6) {
          const es = this.edges(t);
          const e = es[this.rng.int(0, es.length - 1)];
          this.pulses.push({ a: e[0], b: e[1], u: 0, sp: this.rng.range(0.8, 2.2), life: 2.5 });
        }
        for (const p of this.pulses) {
          p.u += p.sp * dt;
          p.life -= dt;
          if (p.u >= 1) {
            const es = this.edges(t).filter((e) => e[0] === p.b || e[1] === p.b);
            if (es.length && this.rng.next() < 0.8) {
              const e = es[this.rng.int(0, es.length - 1)];
              p.a = p.b;
              p.b = e[0] === p.a ? e[1] : e[0];
              p.u = 0;
            } else p.life = 0;
          }
        }
        this.pulses = this.pulses.filter((p) => p.life > 0);
        if (t > this.FINAL + 0.9 && t < this.FINAL + 1.2 && this.frags.count() < 200) {
          for (let i = 0; i < 30; i++) {
            const a = this.rng.angle();
            const sp = this.rng.range(20, 130);
            this.frags.spawn({
              x: C5.x,
              y: C5.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp / 1.5,
              life: this.rng.range(1, 2.4),
              seed: this.rng.next() * 999,
              size: this.rng.range(0.8, 2)
            });
          }
        }
        this.frags.each((p) => {
          p.vx *= Math.exp(-0.9 * dt);
          p.vy *= Math.exp(-0.9 * dt);
        });
        this.frags.step(dt);
      }
      casterLight(t) {
        return 0.15 + 0.35 * seg(t, 0, 5) + 1.2 * (1 - seg(t, this.FINAL + 0.5, this.FINAL + 1.3));
      }
      render(fb, t) {
        const fin = seg(t, this.FINAL, this.FINAL + 0.9);
        const burst = seg(t, this.FINAL + 0.85, this.FINAL + 1.9);
        const P = this.stars.map((_, i) => this.pos(i, t));
        for (const [a, b, k0] of this.edges(t)) {
          const A = P[a], B = P[b];
          if (!A || !B) continue;
          const k = k0 * (1 - burst);
          if (k <= 0.01) continue;
          const n = Math.max(4, Math.ceil(Math.hypot(B.x - A.x, B.y - A.y) / 2));
          for (let i = 0; i <= n; i++) {
            const u = i / n;
            const x = lerp(A.x, B.x, u), y = lerp(A.y, B.y, u);
            const sh = Math.sin(u * Math.PI) * 1.4;
            const c = AST(0.42 + 0.22 * Math.sin(u * 10 - t * 3));
            fb.add(x, y + sh * 0, c[0] * 0.5, c[1] * 0.5, c[2] * 0.55, k * 0.75);
          }
        }
        for (const p of this.pulses) {
          const A = P[p.a], B = P[p.b];
          if (!A || !B) continue;
          const x = lerp(A.x, B.x, clamp(p.u)), y = lerp(A.y, B.y, clamp(p.u));
          glow(fb, x, y, 4, AST(0.8), 0.8 * (1 - burst));
          fb.add(x, y, 2.6, 2.4, 3, 1 - burst);
        }
        for (let i = 0; i < P.length; i++) {
          const s = this.stars[i];
          const p = P[i];
          const tw = 0.6 + 0.4 * Math.sin(t * (1.4 + s.s) + s.ph);
          const k = (0.5 + tw * 0.6) * (1 - burst * 0.9) * (1 + fin * 1.2);
          glow(fb, p.x, p.y, 3 + s.s * 2.4 + fin * 4, AST(0.7), k * 0.8);
          fb.add(p.x, p.y, 2.4 * k, 2.2 * k, 3 * k, 1);
          const sp = (2 + s.s * 2) * (1 + fin * 2.2);
          for (let d = 1; d <= sp; d++) {
            const f = (1 - d / sp) * 0.5 * k;
            fb.add(p.x + d, p.y, 1.2 * f, 1.1 * f, 1.8 * f, 1);
            fb.add(p.x - d, p.y, 1.2 * f, 1.1 * f, 1.8 * f, 1);
            fb.add(p.x, p.y + d * 0.7, 1.2 * f, 1.1 * f, 1.8 * f, 1);
            fb.add(p.x, p.y - d * 0.7, 1.2 * f, 1.1 * f, 1.8 * f, 1);
          }
        }
        if (fin > 0) {
          const rr = fin * 16 * (1 - burst * 0.6);
          shard(fb, C5.x, C5.y, rr, t * 0.5, 8, 11, (d, edge) => {
            if (edge < 1) return [3, 2.8, 3.4];
            const h = 0.4 + (1 - d) * 0.6;
            const c = AST(clamp(h));
            return [c[0] * 0.8, c[1] * 0.8, c[2] * 0.9];
          }, 1.3);
          glow(fb, C5.x, C5.y, 20 + fin * 34, AST(0.85), fin * 1.6);
          for (let i = 0; i < 6; i++) {
            const a = i / 6 * TAU + t * 0.3;
            const L = fin * 60;
            streak(fb, C5.x, C5.y, C5.x + Math.cos(a) * L, C5.y + Math.sin(a) * L / 1.5, 2, 0.4, AST(0.9), fin);
          }
        }
        if (burst > 0) {
          const e = burst;
          for (let i = 0; i < 5; i++) {
            const u = clamp((e - i * 0.07) * 2.4);
            if (u <= 0 || u >= 1) continue;
            const a = i / 5 * TAU + 0.4;
            const L = easeOut(u, 2) * 260;
            const k = Math.sin(u * Math.PI);
            for (let s = 0; s < L; s += 1) {
              const sx = C5.x + Math.cos(a) * s, sy = C5.y + Math.sin(a) * s / 1.5;
              const f = (1 - s / L) * k;
              const c = AST(0.6 + f * 0.4);
              for (let w = -2; w <= 2; w++)
                fb.add(sx, sy + w, c[0] * 0.6, c[1] * 0.6, c[2] * 0.7, f * (1 - Math.abs(w) / 3));
            }
          }
          fb.flash[2] += 0.3 * Math.pow(1 - clamp(e * 5), 2);
          pulseRing(fb, C5.x, C5.y, e * 300, 12 * (1 - e), AST(0.7), (1 - e) * 1.1, 1.5);
        }
        this.frags.each((p) => {
          const l = p.life / p.max;
          const tw = 0.5 + 0.5 * Math.sin(t * 9 + p.seed);
          const c = AST(0.5 + l * 0.4);
          fb.add(p.x, p.y, c[0] * tw, c[1] * tw, c[2] * tw, l * 0.9);
        });
      }
    };
    RealityRipper = class {
      rng = new RNG(32420);
      path = [];
      bands = [];
      debris = new Pool();
      OPEN = 1;
      COLLIDE = 5.3;
      CLOSE = 6.1;
      constructor() {
        const r = this.rng;
        const n = 26;
        for (let i = 0; i <= n; i++) {
          const u = i / n;
          this.path.push({
            x: lerp(56, 380, u) + r.range(-5, 5),
            y: lerp(188, 52, u) + Math.sin(u * 5.3) * 22 + r.range(-7, 7)
          });
        }
        for (let i = 0; i < 64; i++)
          this.bands.push({ close: r.range(0, 1), drift: r.range(-1, 1), seed: r.int(0, 9999) });
      }
      /** signed distance-ish helper: nearest point on the tear spine */
      near(x, y) {
        let best = 1e9, bu = 0, bx = 0, by = 0;
        for (let i = 0; i < this.path.length - 1; i++) {
          const a = this.path[i], b = this.path[i + 1];
          const dx = b.x - a.x, dy = b.y - a.y;
          const l2 = dx * dx + dy * dy;
          let u = ((x - a.x) * dx + (y - a.y) * dy) / l2;
          u = clamp(u);
          const px = a.x + dx * u, py = a.y + dy * u;
          const d = Math.hypot(x - px, y - py);
          if (d < best) {
            best = d;
            bu = (i + u) / (this.path.length - 1);
            bx = px;
            by = py;
          }
        }
        return { d: best, u: bu, px: bx, py: by };
      }
      /** half-width of the opening at parameter u and time t */
      halfW(u, t) {
        const len = smoothstep(this.OPEN, 3, t);
        const within = clamp((len - Math.abs(u - 0.5) * 1.1) * 3);
        let w = within * lerp(0.6, 15, smoothstep(1.4, this.COLLIDE, t));
        if (t > this.COLLIDE) w *= 1 + 0.5 * Math.sin((t - this.COLLIDE) * 14) * Math.exp(-(t - this.COLLIDE) * 2);
        if (t > this.CLOSE) {
          const bi = Math.floor(u * this.bands.length) % this.bands.length;
          const b = this.bands[bi];
          const ct = this.CLOSE + 0.25 + b.close * 1.5;
          w *= 1 - clamp((t - ct) * (b.close > 0.9 ? 0.8 : 3.4));
          if (bi === 41) w *= 1 - clamp((t - this.CLOSE - 2.3) * 2.2);
        }
        const fr = Math.floor(t * 20);
        w += (hash2(Math.floor(u * 160), fr) - 0.5) * 3.2 * clamp(w * 0.4);
        return Math.max(0, w);
      }
      update(dt, t) {
        if (t > this.COLLIDE && t < this.COLLIDE + 0.4 && this.debris.count() < 320) {
          for (let i = 0; i < 24; i++) {
            const u = this.rng.next();
            const p = this.path[Math.floor(u * (this.path.length - 1))];
            const a = this.rng.angle();
            const sp = this.rng.range(60, 340);
            this.debris.spawn({
              x: p.x,
              y: p.y,
              vx: Math.cos(a) * sp,
              vy: Math.sin(a) * sp / 1.4,
              life: this.rng.range(0.5, 1.8),
              size: this.rng.int(1, 4),
              seed: this.rng.int(0, 9999),
              k: this.rng.next()
            });
          }
        }
        this.debris.each((p) => {
          p.vx *= Math.exp(-1.8 * dt);
          p.vy *= Math.exp(-1.8 * dt);
        });
        this.debris.step(dt);
      }
      bgWarp(t) {
        const pre = t < this.OPEN;
        const fr = Math.floor(t * 18);
        const pull = smoothstep(1.2, this.COLLIDE, t) * (t > this.CLOSE ? 1 - seg(t, this.CLOSE, this.CLOSE + 2.2) : 1);
        return (x, y) => {
          if (pre) {
            const n2 = this.near(x, y);
            if (n2.d < 1.2 && t > 0.35) {
              const off = Math.round((hash2(Math.floor(n2.u * 120), fr) - 0.5) * 5);
              return [x + off, y, 1];
            }
            return [x, y, 1];
          }
          const n = this.near(x, y);
          const hw = this.halfW(n.u, t);
          if (n.d < hw) return null;
          const band = Math.floor(y / 3);
          const bh = hash2(band, 77);
          const dirx = x < n.px ? -1 : 1;
          let s = pull * 46 * Math.exp(-(n.d - hw) / 34) | 0;
          if (bh > 0.78) s = Math.round(s * (1 + bh));
          let sx = x - dirx * s;
          let sy = y;
          if (bh > 0.93 && n.d - hw < 40 && pull > 0.4) {
            sx = n.px + (n.px - x) * 1.1;
            sy = y + Math.round((bh - 0.93) * 120);
          }
          const edgeGlow = 1 + 1.6 * Math.exp(-(n.d - hw) / 3);
          return [sx, sy, edgeGlow];
        };
      }
      casterLight(t) {
        return 0.1 + 0.4 * seg(t, 1, 4) + 1.2 * (1 - seg(t, this.COLLIDE, this.COLLIDE + 0.7));
      }
      render(fb, t) {
        const live = t > this.OPEN;
        const coll = seg(t, this.COLLIDE, this.COLLIDE + 1.2);
        if (live) {
          const parallax = t * 20;
          field(fb, 20, 20, fb.W - 20, fb.H - 20, (x, y, o) => {
            const n = this.near(x, y);
            const hw = this.halfW(n.u, t);
            if (n.d > hw) return;
            let r = 0.012, g = 4e-3, b = 0.03;
            for (let L = 2; L >= 0; L--) {
              const sp = 0.35 + L * 1.4;
              const sc = 0.1 - L * 0.028;
              const sx = (x + parallax * sp * 2.2) * sc;
              const sy = (y - parallax * sp * 0.7) * sc + L * 7;
              const cell = Math.floor(sx) * 31 + Math.floor(sy) * 7;
              const occ = hash2(Math.floor(sx), Math.floor(sy) + L * 13);
              if (occ < 0.52 - L * 0.1) continue;
              const fx = sx - Math.floor(sx), fy = sy - Math.floor(sy);
              const edge = Math.min(fx, 1 - fx, fy, 1 - fy);
              const face = 0.06 + 0.16 * hash2(cell, 3) + (L === 0 ? 0.1 : 0);
              let h = face;
              if (edge < 0.07) h = 0.52 + 0.3 * hash2(cell, 9);
              const c = AST(clamp(h * (1 + coll * 0.5)));
              const f = 0.46 - L * 0.1;
              r = c[0] * f;
              g = c[1] * f;
              b = c[2] * f;
              break;
            }
            if (hash2(Math.floor(x * 0.7 - parallax * 0.9), Math.floor(y * 0.7 + parallax * 0.3)) > 0.993) {
              r += 1.1;
              g += 0.7;
              b += 1.6;
            }
            const hz = Math.exp(-Math.pow((y - 118 + Math.sin(x * 0.04 + t) * 7) / 2.2, 2));
            r += hz * 0.4;
            g += hz * 0.18;
            b += hz * 0.75;
            const deep = clamp(1 - n.d / (hw + 1e-3));
            const shade = 0.25 + deep * 0.85;
            r *= shade;
            g *= shade;
            b *= shade;
            const fxp = (x * 2 + Math.floor(t * 12)) % fb.W;
            const fyp = (fb.H - y + 60) % fb.H;
            const i = (fyp * fb.W + fxp) * 3;
            r += fb.bg[i] * 1.6 * deep;
            g += fb.bg[i + 1] * 1.4 * deep;
            b += fb.bg[i + 2] * 2 * deep;
            o[0] = r;
            o[1] = g;
            o[2] = b;
          });
          const steps = 460;
          for (let i = 0; i <= steps; i++) {
            const u = i / steps;
            const fi = u * (this.path.length - 1);
            const k = Math.floor(fi), f = fi - k;
            const a = this.path[Math.min(k, this.path.length - 2)];
            const b2 = this.path[Math.min(k + 1, this.path.length - 1)];
            const px = lerp(a.x, b2.x, f), py = lerp(a.y, b2.y, f);
            let nx = -(b2.y - a.y), ny = b2.x - a.x;
            const l = Math.hypot(nx, ny) || 1;
            nx /= l;
            ny /= l;
            const hw = this.halfW(u, t);
            if (hw <= 0.05) continue;
            for (const side of [-1, 1]) {
              const ex = px + nx * hw * side, ey = py + ny * hw * side;
              const flick = 0.6 + 0.4 * hash2(i, Math.floor(t * 24));
              const c = AST(0.7 + 0.3 * flick);
              fb.add(ex, ey, c[0], c[1], c[2], 0.9 * flick);
              fb.add(ex + nx * side, ey + ny * side, c[0] * 0.4, c[1] * 0.4, c[2] * 0.5, 0.6);
              if (hash2(i, Math.floor(t * 12) + side) > 0.86) {
                const tl = 1 + hash2(i, 5) * 3;
                for (let s = 1; s <= tl; s++)
                  fb.add(ex + nx * side * s, ey + ny * side * s, c[0] * 0.5, c[1] * 0.5, c[2] * 0.6, 0.5);
              }
            }
          }
        } else {
          const n = Math.floor(t * 18);
          const r = new RNG(n);
          if (t > 0.3)
            for (let i = 0; i < 3; i++) {
              const u = r.next();
              const fi = u * (this.path.length - 1);
              const p = this.path[Math.floor(fi)];
              const c = AST(0.6);
              const w = r.int(1, 5);
              for (let k = 0; k < w; k++) fb.add(p.x + k, p.y, c[0] * 0.6, c[1] * 0.6, c[2] * 0.7, 0.5);
            }
        }
        if (coll > 0 && coll < 1) {
          const e = coll;
          fb.flash[0] += 0.4 * Math.pow(1 - clamp(e * 7), 2);
          fb.flash[2] += 0.5 * Math.pow(1 - clamp(e * 7), 2);
          const mid = this.path[Math.floor(this.path.length / 2)];
          pulseRing(fb, mid.x, mid.y, easeOut(e, 2) * 320, 14 * (1 - e), AST(0.7), (1 - e) * 1.2, 1.4);
          for (let i = 1; i <= 3; i++) {
            const k = (1 - e) * 0.3 / i;
            const ox = i * 9 * Math.sin(t * 7 + i), oy = i * -6;
            for (let s = 0; s < this.path.length - 1; s++)
              line(
                fb,
                this.path[s].x + ox,
                this.path[s].y + oy,
                this.path[s + 1].x + ox,
                this.path[s + 1].y + oy,
                AST(0.6),
                k
              );
          }
        }
        this.debris.each((p) => {
          const l = p.life / p.max;
          const sx = Math.round(p.px), sy = Math.round(p.py);
          for (let yy = 0; yy < p.size; yy++)
            for (let xx = 0; xx < p.size; xx++) {
              const i = (clamp(sy + yy, 0, fb.H - 1) * fb.W + clamp(sx + xx, 0, fb.W - 1)) * 3;
              const br = 2.2 + p.k * 3.4;
              fb.add(p.x + xx, p.y + yy, fb.bg[i] * br, fb.bg[i + 1] * br, fb.bg[i + 2] * br, l);
            }
          if (p.k > 0.6) {
            const c = AST(0.55 + l * 0.4);
            fb.add(p.x, p.y, c[0] * 0.5, c[1] * 0.5, c[2] * 0.6, l * 0.8);
          }
        });
        const st = seg(t, this.CLOSE, this.CLOSE + 2.6);
        if (st > 0 && st < 1) {
          for (let i = 0; i < 90; i++) {
            const b = this.bands[i % this.bands.length];
            const u = i * 37 % 100 / 100;
            const fi = u * (this.path.length - 1);
            const p = this.path[Math.floor(fi)];
            const ct = b.close;
            const k = clamp((st - ct * 0.6) * 3);
            if (k <= 0 || k >= 1) continue;
            const off = (1 - k) * 22 * b.drift;
            const c = AST(0.55);
            fb.add(p.x + off, p.y + off * 0.3, c[0] * 0.7, c[1] * 0.7, c[2] * 0.8, (1 - k) * 0.8);
          }
        }
      }
    };
  }
});

// src/spells/index.ts
var spells_exports = {};
__export(spells_exports, {
  SPELLS: () => SPELLS,
  byId: () => byId
});
var SPELLS, byId;
var init_spells = __esm({
  "src/spells/index.ts"() {
    "use strict";
    init_pyre();
    init_tide();
    init_tempest();
    init_verdant();
    init_astral();
    SPELLS = [
      {
        id: 1,
        name: "Cinder Crown",
        school: "PYRE",
        duration: 6.6,
        climax: 0.66,
        accent: [1.7, 0.55, 0.14],
        tagline: "Embers build a crown, swallow their own light, then unfold as shattered solar petals.",
        make: () => new CinderCrown()
      },
      {
        id: 2,
        name: "Furnace Wyrm",
        school: "PYRE",
        duration: 7,
        climax: 0.72,
        accent: [1.8, 0.6, 0.12],
        tagline: "A serpent of interlocking flame segments knots through the arena and feeds its whole length into one bite.",
        make: () => new FurnaceWyrm()
      },
      {
        id: 3,
        name: "Meteor Loom",
        school: "PYRE",
        duration: 7,
        climax: 0.84,
        accent: [1.6, 0.5, 0.1],
        tagline: "A choreographed bombardment whose impact scars turn out to be drawing one enormous sigil.",
        make: () => new MeteorLoom()
      },
      {
        id: 4,
        name: "Ashen Guillotine",
        school: "PYRE",
        duration: 7.2,
        climax: 0.56,
        accent: [1.9, 0.75, 0.25],
        tagline: "Absolute restraint, one impossibly fast cut, and an explosion that arrives late.",
        make: () => new AshenGuillotine()
      },
      {
        id: 5,
        name: "Abyssal Bloom",
        school: "TIDE",
        duration: 7,
        climax: 0.68,
        accent: [0.3, 0.85, 1.5],
        tagline: "Liquid membranes fold open like an ocean inventing a new form of life.",
        make: () => new AbyssalBloom()
      },
      {
        id: 6,
        name: "Riptide Calligraphy",
        school: "TIDE",
        duration: 7,
        climax: 0.78,
        accent: [0.35, 0.9, 1.6],
        tagline: "An invisible master writes with water, then the handwriting becomes cutting waves.",
        make: () => new RiptideCalligraphy()
      },
      {
        id: 7,
        name: "Mirrorfrost Basilica",
        school: "TIDE",
        duration: 7.6,
        climax: 0.62,
        accent: [0.6, 1.1, 1.8],
        tagline: "Frost assembles an impossible cathedral; a single point breaks and the chain reaction takes it all.",
        make: () => new MirrorfrostBasilica()
      },
      {
        id: 8,
        name: "Undertow Maw",
        school: "TIDE",
        duration: 7,
        climax: 0.73,
        accent: [0.25, 0.7, 1.4],
        tagline: "A vortex deeper than the screen, absolute stillness, then the weight of compressed water.",
        make: () => new UndertowMaw()
      },
      {
        id: 9,
        name: "Chain Verdict",
        school: "TEMPEST",
        duration: 6.8,
        climax: 0.82,
        accent: [0.7, 0.85, 2.1],
        tagline: "Electricity searches for valid paths, fails, reconnects, then every surviving channel fires at once.",
        make: () => new ChainVerdict()
      },
      {
        id: 10,
        name: "Thunderloom",
        school: "TEMPEST",
        duration: 7,
        climax: 0.735,
        accent: [0.75, 0.9, 2.2],
        tagline: "An elaborate woven storm collapses into one brutally concentrated spear.",
        make: () => new Thunderloom()
      },
      {
        id: 11,
        name: "Volt Carousel",
        school: "TEMPEST",
        duration: 7.2,
        climax: 0.79,
        accent: [0.8, 0.95, 2.3],
        tagline: "A forbidden electromagnetic engine reaching critical synchronisation.",
        make: () => new VoltCarousel()
      },
      {
        id: 12,
        name: "Skybreaker Script",
        school: "TEMPEST",
        duration: 7.4,
        climax: 0.8,
        accent: [0.85, 0.9, 2.4],
        tagline: "A glyph written in current behaves like a circuit \u2014 and its destruction is choreographed too.",
        make: () => new SkybreakerScript()
      },
      {
        id: 13,
        name: "Rootwake",
        school: "VERDANT",
        duration: 7.4,
        climax: 0.75,
        accent: [0.45, 1.4, 0.5],
        tagline: "A root network grows with biological rhythm, then answers as a single living entity.",
        make: () => new Rootwake()
      },
      {
        id: 14,
        name: "Spore Nebula",
        school: "VERDANT",
        duration: 7.4,
        climax: 0.79,
        accent: [0.3, 1.3, 1],
        tagline: "Colonies connect into a bioluminescent galaxy, then undergo a reproductive event.",
        make: () => new SporeNebula()
      },
      {
        id: 15,
        name: "Thorn Opera",
        school: "VERDANT",
        duration: 7.2,
        climax: 0.8,
        accent: [0.6, 1.3, 0.45],
        tagline: "Tendrils with individual personalities dance, knot, and open into one enormous thorned flower.",
        make: () => new ThornOpera()
      },
      {
        id: 16,
        name: "Worldseed",
        school: "VERDANT",
        duration: 8,
        climax: 0.72,
        accent: [0.8, 1.5, 0.7],
        tagline: "More geometry unfolds out of the seed than could ever have fit inside it.",
        make: () => new Worldseed()
      },
      {
        id: 17,
        name: "Event Horizon",
        school: "ASTRAL",
        duration: 7.4,
        climax: 0.79,
        accent: [0.85, 0.45, 1.7],
        tagline: "A region of the arena loses visual information, collapses, and rebounds with the floor inside it.",
        make: () => new EventHorizon()
      },
      {
        id: 18,
        name: "Chronoshard",
        school: "ASTRAL",
        duration: 7.4,
        climax: 0.8,
        accent: [0.75, 0.9, 1.8],
        tagline: "Time becomes a material: echoes ahead of the gesture, impacts before their projectiles.",
        make: () => new Chronoshard()
      },
      {
        id: 19,
        name: "Constellation Engine",
        school: "ASTRAL",
        duration: 8,
        climax: 0.82,
        accent: [0.9, 0.85, 1.9],
        tagline: "A vast celestial mechanism assembles itself out of almost nothing.",
        make: () => new ConstellationEngine()
      },
      {
        id: 20,
        name: "Reality Ripper",
        school: "ASTRAL",
        duration: 8.4,
        climax: 0.74,
        accent: [1, 0.45, 1.6],
        tagline: "A rendering artifact becomes a living wound in the world, and the stitching back is irregular.",
        make: () => new RealityRipper()
      }
    ];
    byId = (id) => SPELLS.find((s) => s.id === id);
  }
});

// scripts/capture.ts
import { deflateSync } from "node:zlib";
import { writeFileSync, mkdirSync } from "node:fs";
var ImageDataShim = class {
  width;
  height;
  data;
  constructor(w, h) {
    this.width = w;
    this.height = h;
    this.data = new Uint8ClampedArray(w * h * 4);
  }
};
globalThis.ImageData = ImageDataShim;
var { Lab: Lab2, DT: DT2 } = await Promise.resolve().then(() => (init_lab(), lab_exports));
var { SPELLS: SPELLS2 } = await Promise.resolve().then(() => (init_spells(), spells_exports));
function crc32(buf) {
  let c, crc = 4294967295;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 255;
    for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    crc = crc >>> 8 ^ c;
  }
  return (crc ^ 4294967295) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, "ascii"), Buffer.from(data)]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    Buffer.from(rgba.buffer, y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", new Uint8Array())
  ]);
}
function upscale(src, w, h, s) {
  const out = new Uint8ClampedArray(w * s * h * s * 4);
  for (let y = 0; y < h * s; y++)
    for (let x = 0; x < w * s; x++) {
      const si = ((y / s | 0) * w + (x / s | 0)) * 4;
      const di = (y * w * s + x) * 4;
      out[di] = src[si];
      out[di + 1] = src[si + 1];
      out[di + 2] = src[si + 2];
      out[di + 3] = 255;
    }
  return out;
}
var lab = new Lab2();
var fakeCtx = { putImageData() {
} };
mkdirSync("shots", { recursive: true });
mkdirSync("shots/timeline", { recursive: true });
var args = process.argv.slice(2);
var only = args.find((a) => /^\d+$/.test(a));
var strip = args.includes("--strip");
var seqI = args.indexOf("--seq");
var seq = seqI >= 0 ? { t0: parseFloat(args[seqI + 1]), stride: parseInt(args[seqI + 2] || "2") } : null;
var W2 = lab.fb.W;
var H = lab.fb.H;
var t0 = Date.now();
function grab() {
  lab.render(fakeCtx);
  return new Uint8ClampedArray(lab.fb.out.data);
}
function shotAt(target, settle = 5) {
  lab.seek(Math.max(0, target - settle * DT2));
  let f = null;
  for (let i = 0; i < settle; i++) {
    lab.step();
    lab.advanced = true;
    f = grab();
  }
  return f;
}
function sheetOf(frames, cols) {
  const rows = Math.ceil(frames.length / cols);
  const sw = W2 * cols, sh = H * rows;
  const sheet2 = new Uint8ClampedArray(sw * sh * 4);
  frames.forEach((f, i) => {
    const ox = i % cols * W2, oy = (i / cols | 0) * H;
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W2; x++) {
        const si = (y * W2 + x) * 4, di = ((y + oy) * sw + x + ox) * 4;
        sheet2[di] = f[si];
        sheet2[di + 1] = f[si + 1];
        sheet2[di + 2] = f[si + 2];
        sheet2[di + 3] = 255;
      }
  });
  return { sw, sh, sheet: sheet2 };
}
if (args.includes("--grid")) {
  const off = parseFloat(args[args.indexOf("--grid") + 1] || "0");
  const frames = SPELLS2.map((def) => {
    lab.load(def);
    return shotAt(def.climax * def.duration + off, 7);
  });
  const { sw, sh, sheet: sheet2 } = sheetOf(frames, 4);
  writeFileSync(`shots/timeline/grid${off ? "-" + off : ""}.png`, png(sw, sh, sheet2));
  console.log("grid done");
  process.exit(0);
}
for (const def of SPELLS2) {
  if (only && def.id !== parseInt(only)) continue;
  const name = `${String(def.id).padStart(2, "0")}-${def.name.toLowerCase().replace(/\s+/g, "-")}`;
  lab.load(def);
  if (seq) {
    lab.seek(seq.t0);
    const frames = [];
    const ts = [];
    for (let k = 0; k < 16; k++) {
      for (let i = 0; i < seq.stride; i++) {
        lab.step();
        lab.advanced = true;
        if (i < seq.stride - 1) grab();
      }
      frames.push(grab());
      ts.push(lab.t.toFixed(2));
    }
    const { sw, sh, sheet: sheet2 } = sheetOf(frames, 4);
    writeFileSync(`shots/timeline/${name}-seq.png`, png(sw, sh, sheet2));
    console.log(`\u2713 ${name} seq  (${ts.join(" ")})`);
    continue;
  }
  if (strip) {
    const times = [0.04, 0.2, 0.4, 0.55, def.climax, Math.min(0.97, def.climax + 0.1), 0.88, 0.99].map((f) => f * def.duration);
    const frames = times.map((tt) => shotAt(tt));
    const { sw, sh, sheet: sheet2 } = sheetOf(frames, 4);
    writeFileSync(`shots/timeline/${name}.png`, png(sw, sh, sheet2));
    console.log(`\u2713 ${name} strip`);
  } else {
    const f = shotAt(def.climax * def.duration, 7);
    writeFileSync(`shots/${name}.png`, png(W2 * 2, H * 2, upscale(f, W2, H, 2)));
    console.log(`\u2713 ${name}  (${lab.t.toFixed(2)}s)`);
  }
}
console.log(`done in ${((Date.now() - t0) / 1e3).toFixed(1)}s`);
