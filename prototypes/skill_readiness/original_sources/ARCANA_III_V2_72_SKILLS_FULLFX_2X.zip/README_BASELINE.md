# ARCANA // Ultimate VFX Laboratory

Twenty ultimate abilities across five relics — **PixiJS v8 (WebGL) + TypeScript + custom GLSL**, rendered at
480×270 and upscaled nearest-neighbour. Characters, enemies and the arena are placeholders; the VFX are the artwork.

## Run
```bash
npm install
npm run dev        # lab at http://localhost:5173   (/#20 opens skill 20, ?paused starts frozen)
npm run build      # -> dist/index.html
```
Lab: skill buttons, play/pause, restart, 0.25×/0.5×/1×, scrub bar, **FX 100/60/30 %** (particle density + bloom,
for weak GPUs), **Auto showcase (all 20)**. Keys: Space, R, ←/→.

## How the pixel look is produced
Everything is drawn into low-res buffers and quantised, so nothing reads as vector art:

- **`engine/pixtex.ts`** – 14 procedurally generated pixel sprites (spark, star, dithered glow, smoke, chunk, shard,
  streak, flame, bone, wing…). Every particle is a bitmap with hard edges and Bayer-quantised alpha, never a shape.
- **`engine/draw.ts`** – all vertices snap to the integer grid; circles are built from discrete pixels (`gring`
  places square pixels along the arc) instead of smooth strokes.
- **`engine/post.ts`** – one GLSL pass doing pixel-aligned refraction (shockwave / lens / time-slice), 3-ring bloom,
  chromatic aberration, grade, vignette, then **ordered-dither + colour-depth reduction**: smooth gradients become
  dithered pixel ramps (5.6 bits by default).
- **`Composer`** – three buffers: opaque world (floor, marks, darkness, actors, debris), additive light world
  (energy, sparks, sky), and a **feedback accumulator** where the light buffer is added over its own decayed,
  slightly zoomed previous frame. Fast motion therefore leaves living luminous trails; persistence is tunable per
  relic (`ctx.trailBase`, 0.52–0.68) and per frame (`ctx.post.trail`).

## How the motion is produced
- **`smoothDamp`** (speed-limited critically damped) drives the caster and every enemy. Scripted choreography sets a
  *target*; the body eases into it with continuous velocity, so dashes accelerate and decelerate instead of snapping.
  Caster: smoothTime 0.034 s, cap 3400 px/s. Enemies: 0.13 s, cap 780 px/s (weighty drag/lift/recoil).
- Caster extras: lean from lateral acceleration, run/idle bob, landing squash + dust, footprint-spaced afterimages,
  speed pixels. Enemy extras: idle breathing, blink, squash on landing and on hit, hit-lean, motion smear, shadow
  that shrinks with height, outline glow when trapped.
- **`ctx.shock` / `ctx.strike` / `ctx.blast`** are pixel-native: dithered expanding rings, radial pixel spokes,
  wavefront sparks, floor dust, debris chunks with tumble, scorch scars, distortion and screen shake. Density is
  scaled globally by `DENS = 2.1`.

## Structure
`engine/core.ts` (layers, particles, actors, timeline `at/each/seg/ent/scar`, lab runner) ·
`engine/fx.ts` (`pxBurst`, `pxJet`, `pxDust`, `pxRing`, `pxColumn`, scars) ·
`engine/util.ts` (deterministic RNG, curves, ramps) ·
`skills/{eclipse,dragonbone,fan,spindle,lantern}.ts` — each ultimate has its own bespoke system
(orbital rails, delayed-body wyrm, chain links, ink strokes, lace graphs, seam stitching, marionette tension,
loom mesh, spectral kings, cymatic interference field, reveal-ordered god-eater with a collapse transform).

## Validation (honest, measured from the running app)
Two scripts drive the real lab in headless Chromium (SwiftShader WebGL):
```bash
node scripts/analyze.mjs all 12      # per-frame + per-step metrics -> captures/analysis.json
node scripts/capture.mjs all 12      # 12-frame contact sheets     -> captures/skill-NN.png
node scripts/prof.mjs 1              # sim cost vs render cost
node scripts/smoke.mjs               # boots dist/index.html, plays, seeks, inits all 20
```
`analyze.mjs` measures lit coverage, blown-out coverage, unique quantised colours, trail afterglow, and the
per-step **acceleration** of the caster and every enemy (continuity = smoothness). Results for all 20 skills
(three batches, `errors: none` in every batch):

| # | max particles | lit | peak blown-out | colours | caster acc p99/max | enemy acc p99/max |
|---|---|---|---|---|---|---|
|01|2471|0.39|0.28|1555|5.0 / 12.8|1.7 / 10.2|
|02|1558|0.41|0.15|2327|7.0 / 15.3|1.4 / 2.8|
|03|4740|0.49|0.22|2633|3.3 / 27.8|0.5 / 3.7|
|04|2602|0.42|0.17|2416|1.6 / 56.0|1.6 / 11.7|
|05|2319|0.37|0.06|1342|6.7 / 15.3|1.8 / 12.9|
|06|2465|0.28|0.07|1042|2.8 / 15.3|1.6 / 12.3|
|07|1289|0.26|0.04|1845|5.5 / 12.8|1.8 / 10.7|
|08|1536|0.32|0.08|1227|4.8 / 15.3|1.3 / 4.9|
|09|6534|0.43|0.20|3718|5.5 / 15.3|1.6 / 10.5|
|10|1925|0.46|0.08|2148|0.0 / 5.2|0.3 / 2.1|
|11|2542|0.24|0.09|2951|7.0 / 10.6|2.3 / 4.5|
|12|3000|0.39|0.38|2596|2.3 / 15.3|1.3 / 10.9|
|13|2420|0.22|0.08|754|0.7 / 15.3|0.9 / 9.7|
|14|2668|0.31|0.06|1124|5.5 / 12.8|0.5 / 3.9|
|15|1942|0.37|0.17|988|4.1 / 12.8|1.2 / 12.1|
|16|1768|0.32|0.05|1476|3.6 / 28.6|0.6 / 4.2|
|17|3186|0.23|0.24|527|4.1 / 12.8|0.1 / 3.3|
|18|3249|0.33|0.34|1080|4.6 / 10.6|0.0 / 1.2|
|19|2075|0.38|0.20|935|3.4 / 15.3|1.0 / 8.9|
|20|3803|0.27|0.17|1614|2.8 / 18.1|0.4 / 6.9|

Reading it: particle load is 1.3k–6.5k per frame (was 0.1k–0.9k before the pixel upgrade); enemy acceleration stays
under ~1.9 px/frame² at p99 (previously pin-targets teleported them, spiking to tens); caster spikes at 27–56 are the
intentional blink/dash beats in skills 3, 4 and 16; blown-out coverage stays ≤0.08 for most skills, with single-frame
peaks of 0.28–0.38 at the deliberate "blinding" climaxes of 01, 12 and 18. Afterglow saturation returns to ~0, so the
trail buffer never leaves residue (skill 15's lingering 0.037 is its authored golden ground scar, life 5 s).

`tsc --noEmit` and `vite build` pass; all 20 skills ran start-to-finish with zero page/console errors.

Production smoke test (`scripts/smoke.mjs` on the built `dist/index.html`): 20 skills registered, boots, plays,
seeks backwards/forwards, and all 20 initialise and run to mid-skill with `failures: []`, `errors: none`.

## Known limits
- I could **not visually inspect frames in this session** (no image input available), so the numbers above are the
  evidence, not my eyes. Composition/colour choices inside individual skills are unreviewed; contact sheets are in
  `captures/` for a human pass.
- **Framerate is unverified on real hardware.** Under headless SwiftShader the lab plays at roughly 3 fps
  (`smoke.mjs`: 0.4–0.6 s of skill time per 1.2 s of wall clock) because every pixel is rasterised on the CPU across
  four passes. `scripts/prof.mjs` measured the CPU-side simulation at ~2.6 ms/step, so the bottleneck is software
  fill rate, not the effect code — but I have no GPU numbers. Use the **FX %** control if a machine struggles.
  WebGPU path untested.
- Placeholders stay placeholders: the caster is a 9×12 silhouette, enemies 10×12, both ready to be swapped for real
  sprite sheets in `engine/core.ts` (`CASTER_BMP`, `ENEMY_BMP`).
- If Chromium reports missing system libraries, export `LD_LIBRARY_PATH` to a directory containing them.
