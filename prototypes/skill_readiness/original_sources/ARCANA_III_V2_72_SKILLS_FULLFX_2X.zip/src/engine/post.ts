// Screen-space compositing for fantasy pixel art:
// - Pixel-locked refraction (shockwave, gravitational lens, temporal slice)
// - Clean thresholded pixel bloom (bright cores glow vibrantly without turning dark colors into muddy brown)
// - Subtle palette quantization that keeps dark stone surfaces clean (no noisy checkerboard across the floor)
// - Grid-locked afterglow (no zoom smear that turns curves into cobwebs)
import { Container, Filter, GlProgram, RenderTexture, Sprite, defaultFilterVert } from 'pixi.js';
import { H, W } from './util';

const FRAG = /* glsl */ `
in vec2 vTextureCoord;
out vec4 finalColor;
uniform sampler2D uTexture;
uniform float uTime;
uniform vec2 uRes;
uniform vec4 uShock[12];
uniform vec4 uLens[8];
uniform vec4 uSlice;
uniform vec4 uSliceB;
uniform float uAberr;
uniform float uBloom;
uniform vec4 uFlash;
uniform vec4 uGrade;
uniform float uVig;
uniform float uQuant;
uniform float uDither;

float bayer2(vec2 a){ a = floor(a); return fract(a.x * 0.5 + a.y * a.y * 0.75); }
float bayer4(vec2 a){ return bayer2(0.5 * a) * 0.25 + bayer2(a); }
float hash(float n){ return fract(sin(n * 127.1 + 3.7) * 43758.5453); }
vec3 tap(vec2 q){ return texture(uTexture, (floor(q) + 0.5) / uRes).rgb; }

void main(){
  vec2 p = floor(vTextureCoord * uRes) + 0.5;
  vec2 q = p;
  if (uSlice.x > 0.0) {
    vec2 dir = vec2(cos(uSlice.y), sin(uSlice.y));
    vec2 nrm = vec2(-dir.y, dir.x);
    float id = floor(dot(p, dir) / uSlice.z + uSlice.w);
    float h = hash(id) - 0.5;
    q += nrm * h * uSlice.x * 2.0 * step(0.4, hash(id + 7.0));
  }
  if (uSliceB.x > 0.0) {
    vec2 dir = vec2(cos(uSliceB.y), sin(uSliceB.y));
    vec2 nrm = vec2(-dir.y, dir.x);
    float id = floor(dot(p, dir) / uSliceB.z + uSliceB.w);
    float h = hash(id + 29.0) - 0.5;
    q += nrm * h * uSliceB.x * 2.0 * step(0.4, hash(id + 19.0));
  }
  for (int i = 0; i < 12; i++) {
    vec4 s = uShock[i];
    if (s.w == 0.0) continue;
    vec2 d = q - s.xy;
    float dist = length(vec2(d.x, d.y / 0.7));
    float x = (dist - s.z) / max(4.5, s.z * 0.09 + 2.5);
    float f = exp(-x * x);
    q += normalize(d + vec2(1e-4)) * f * s.w;
  }
  for (int i = 0; i < 8; i++) {
    vec4 l = uLens[i];
    if (l.w == 0.0) continue;
    vec2 d = q - l.xy;
    float f = smoothstep(l.z, 0.0, length(d));
    float a = l.w * f * f;
    float c = cos(a), s = sin(a);
    d = vec2(c * d.x - s * d.y, s * d.x + c * d.y);
    d *= 1.0 - 0.42 * f * clamp(l.w, -1.0, 1.0);
    q = l.xy + d;
  }
  vec3 col;
  if (uAberr > 0.0) {
    vec2 dd = normalize(q - uRes * 0.5 + vec2(1e-3)) * uAberr;
    col = vec3(tap(q + dd).r, tap(q).g, tap(q - dd).b);
  } else {
    col = tap(q);
  }
  if (uBloom > 0.0) {
    vec3 b = vec3(0.0);
    for (int i = 0; i < 8; i++) {
      float a = float(i) * 0.7853982;
      vec2 o = vec2(cos(a), sin(a));
      vec3 s1 = max(tap(q + o * 2.0) - 0.48, 0.0);
      vec3 s2 = max(tap(q + o * 4.0) - 0.56, 0.0);
      b += s1 + s2 * 0.65;
    }
    col += b * uBloom * 0.11;
  }
  // Fantasy color richness: slight contrast & saturation boost in mid/high tones, never muddy brown
  float luma = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(vec3(luma), col, 1.18);
  col = mix(col, col * uGrade.rgb, uGrade.a);
  col = mix(col, uFlash.rgb, uFlash.a);
  vec2 vv = (p / uRes - 0.5) * vec2(1.22, 1.45);
  col *= 1.0 - uVig * smoothstep(0.4, 1.05, length(vv));

  // Clean pixel-art quantization: only dither bright/mid energy gradients, keep dark stone floor 100% clean
  float lv = max(16.0, pow(2.0, uQuant) - 1.0);
  float dMask = smoothstep(0.16, 0.45, luma) * uDither * 0.35;
  float b = (bayer4(p) - 0.5) * dMask;
  col = clamp(floor(col * lv + 0.5 + b) / lv, 0.0, 1.0);
  finalColor = vec4(col, 1.0);
}`;

export interface PostState {
  shocks: number[][];
  lens: number[][];
  slice: [number, number, number, number];
  sliceB?: [number, number, number, number];
  aberr: number;
  bloom: number;
  flash: [number, number, number, number];
  grade: [number, number, number, number];
  vig: number;
  quant: number;
  dither: number;
  trail: number;
  trailZoom: number;
  trailSpin: number;
}
export const newPost = (): PostState => ({
  shocks: [], lens: [], slice: [0, 0, 8, 0], aberr: 0, bloom: 1, flash: [1, 1, 1, 0], grade: [1, 1, 1, 0], vig: 0.28,
  quant: 6.0, dither: 0.5, trail: 0.22, trailZoom: 1.0, trailSpin: 0,
});

export class PostFx extends Filter {
  constructor() {
    const glProgram = GlProgram.from({ vertex: defaultFilterVert, fragment: FRAG, name: 'arcana-post' });
    super({
      glProgram,
      resources: {
        fx: {
          uTime: { value: 0, type: 'f32' },
          uRes: { value: new Float32Array([W, H]), type: 'vec2<f32>' },
          uShock: { value: new Float32Array(48), type: 'vec4<f32>', size: 12 },
          uLens: { value: new Float32Array(32), type: 'vec4<f32>', size: 8 },
          uSlice: { value: new Float32Array(4), type: 'vec4<f32>' },
          uSliceB: { value: new Float32Array(4), type: 'vec4<f32>' },
          uAberr: { value: 0, type: 'f32' },
          uBloom: { value: 1, type: 'f32' },
          uFlash: { value: new Float32Array(4), type: 'vec4<f32>' },
          uGrade: { value: new Float32Array(4), type: 'vec4<f32>' },
          uVig: { value: 0.28, type: 'f32' },
          uQuant: { value: 6.0, type: 'f32' },
          uDither: { value: 0.5, type: 'f32' },
        },
      },
      resolution: 1,
    });
  }
  apply_state(s: PostState, t: number) {
    const grp: any = (this as any).resources.fx;
    const u = grp.uniforms;
    u.uTime = t;
    const sh: Float32Array = u.uShock;
    sh.fill(0);
    s.shocks.slice().sort((a, b) => Math.abs(b[3]) - Math.abs(a[3])).slice(0, 12).forEach((v, i) => sh.set(v, i * 4));
    const ln: Float32Array = u.uLens;
    ln.fill(0);
    s.lens.slice(0, 8).forEach((v, i) => ln.set(v, i * 4));
    (u.uSlice as Float32Array).set(s.slice);
    (u.uSliceB as Float32Array).set(s.sliceB ?? [0, 0, 8, 0]);
    u.uAberr = s.aberr;
    u.uBloom = s.bloom;
    (u.uFlash as Float32Array).set(s.flash);
    (u.uGrade as Float32Array).set(s.grade);
    u.uVig = s.vig;
    u.uQuant = s.quant;
    u.uDither = s.dither;
    grp.update?.();
  }
}

export class Composer {
  rtO = RenderTexture.create({ width: W, height: H, resolution: 1 });
  rtL = RenderTexture.create({ width: W, height: H, resolution: 1 });
  acc: [RenderTexture, RenderTexture] = [
    RenderTexture.create({ width: W, height: H, resolution: 1 }),
    RenderTexture.create({ width: W, height: H, resolution: 1 }),
  ];
  private cur = 0;
  private comp = new Container();
  private decay = new Sprite();
  private lit = new Sprite();
  root = new Container();
  private spO = new Sprite();
  private spL = new Sprite();
  constructor() {
    this.rtO.source.scaleMode = 'nearest';
    this.rtL.source.scaleMode = 'nearest';
    this.acc[0].source.scaleMode = 'nearest';
    this.acc[1].source.scaleMode = 'nearest';
    this.decay.anchor.set(0.5);
    this.decay.position.set(W / 2, H / 2);
    this.lit.blendMode = 'add';
    this.comp.addChild(this.decay, this.lit);
    this.spL.blendMode = 'add';
    this.root.addChild(this.spO, this.spL);
  }
  reset(renderer: any) {
    this.cur = 0;
    this.decay.alpha = 0;
    this.lit.alpha = 0;
    renderer.render({ container: this.comp, target: this.acc[0], clear: true });
    renderer.render({ container: this.comp, target: this.acc[1], clear: true });
    this.lit.alpha = 1;
  }
  draw(renderer: any, worldO: Container, worldL: Container, s: PostState, _t: number) {
    renderer.render({ container: worldO, target: this.rtO, clear: true });
    renderer.render({ container: worldL, target: this.rtL, clear: true });
    const prev = this.acc[this.cur], next = this.acc[this.cur ^ 1];
    this.decay.texture = prev;
    this.decay.alpha = Math.min(0.28, s.trail * 0.42);
    this.decay.scale.set(1.0);
    this.decay.rotation = 0;
    this.lit.texture = this.rtL;
    renderer.render({ container: this.comp, target: next, clear: true });
    this.cur ^= 1;
    this.spO.texture = this.rtO;
    this.spL.texture = next;
  }
}
