// Procedural 16-bit Fantasy Pixel-Art Sprite & Construct Generator.
// Every texture here is rasterized on an integer pixel grid with multi-stop hue-shifted palettes,
// Bayer ordered dithering, and crisp pixel outlines — replacing raw vector/math shapes with true pixel art.
import { Container, Graphics, Sprite, Texture } from 'pixi.js';
import { TAU, clamp, hash1, hash2, lerp, mix, pack, rgb, vnoise } from './util';
import { bay, dq } from './pixtex';
import { hiRamp, shadeRamp } from './draw';

function makeTex(w: number, h: number, draw: (px: (x: number, y: number, col: number, a?: number) => void) => void): Texture {
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext('2d')!;
  const img = ctx.createImageData(w, h);
  const d = img.data;
  const setPx = (x: number, y: number, col: number, a = 1) => {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || x >= w || y < 0 || y >= h || a <= 0) return;
    const i = (y * w + x) * 4;
    const r = (col >> 16) & 255, g = (col >> 8) & 255, b = col & 255;
    const prevA = d[i + 3] / 255;
    const outA = a + prevA * (1 - a);
    if (outA <= 0) return;
    d[i] = Math.round((r * a + d[i] * prevA * (1 - a)) / outA);
    d[i + 1] = Math.round((g * a + d[i + 1] * prevA * (1 - a)) / outA);
    d[i + 2] = Math.round((b * a + d[i + 2] * prevA * (1 - a)) / outA);
    d[i + 3] = Math.round(clamp(outA, 0, 1) * 255);
  };
  draw(setPx);
  ctx.putImageData(img, 0, 0);
  const tex = Texture.from(cv);
  tex.source.scaleMode = 'nearest';
  return tex;
}

function bresenhamLine(
  px: (x: number, y: number, col: number, a?: number) => void,
  x0: number, y0: number, x1: number, y1: number, col: number, a = 1,
) {
  x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
  const dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  const dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  for (let k = 0; k < 300; k++) {
    px(x0, y0, col, a);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

export type StampKey =
  | 'seal_solar'
  | 'seal_astral'
  | 'seal_abyss'
  | 'seal_imperial'
  | 'corona_ring'
  | 'crescent_wave'
  | 'vortex_swirl'
  | 'star_flare'
  | 'crater_fissure'
  | 'dragon_head'
  | 'leviathan_skull'
  | 'hollow_king'
  | 'choir_wraith'
  | 'godeater_skull'
  | 'godeater_wing'
  | 'godeater_eye'
  | 'butterfly_open'
  | 'butterfly_half'
  | 'gothic_arch'
  | 'crystal_mirror'
  | 'needle_lance';

const CACHE: Partial<Record<StampKey, Texture>> = {};

function buildSeal(points: number, innerStar: number, runeDensity: number): Texture {
  const S = 128, C = 63.5;
  return makeTex(S, S, (px) => {
    // Soft stepped pixel aura under the rings
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const r = Math.hypot(x - C, y - C);
      const ringD = Math.min(Math.abs(r - 56), Math.abs(r - 45), Math.abs(r - 22));
      if (ringD < 3.5) {
        const a = dq((1 - ringD / 3.5) * 0.45, x, y, 4);
        if (a > 0) px(x, y, 0x9999ff, a);
      }
    }
    // Crisp Bresenham-style concentric rings
    for (const rad of [58, 55, 45, 43, 22]) {
      const steps = Math.round(rad * 7);
      const bright = rad === 55 || rad === 45 || rad === 22;
      for (let i = 0; i < steps; i++) {
        const a = (i / steps) * TAU;
        px(C + Math.cos(a) * rad, C + Math.sin(a) * rad, bright ? 0xffffff : 0xb8b8ff, bright ? 0.95 : 0.65);
      }
    }
    // Runic teeth between r=46 and r=54
    const ticks = points * runeDensity;
    for (let i = 0; i < ticks; i++) {
      const a = (i / ticks) * TAU;
      const r0 = 47, r1 = i % 2 === 0 ? 53 : 50;
      bresenhamLine(px, C + Math.cos(a) * r0, C + Math.sin(a) * r0, C + Math.cos(a) * r1, C + Math.sin(a) * r1, i % 2 === 0 ? 0xffffff : 0xc8c8ff, 0.9);
    }
    // Sacred star polygon
    const verts: [number, number][] = [];
    for (let i = 0; i < points; i++) {
      const a = (i / points) * TAU - Math.PI / 2;
      verts.push([C + Math.cos(a) * 44, C + Math.sin(a) * 44]);
    }
    for (let i = 0; i < points; i++) {
      const A = verts[i], B = verts[(i + innerStar) % points];
      bresenhamLine(px, A[0], A[1], B[0], B[1], 0xd8d8ff, 0.85);
      const B2 = verts[(i + 1) % points];
      bresenhamLine(px, A[0], A[1], B2[0], B2[1], 0xa0a0ff, 0.6);
      // Cardinal gem at each vertex
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        if (Math.abs(dx) + Math.abs(dy) <= 2) px(A[0] + dx, A[1] + dy, dx === 0 && dy === 0 ? 0xffffff : 0xd8d8ff, 1);
      }
    }
  });
}

function buildCoronaRing(): Texture {
  const S = 128, C = 63.5, R0 = 26;
  return makeTex(S, S, (px) => {
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const dx = x - C, dy = y - C;
      const r = Math.hypot(dx, dy);
      if (r < R0 - 1) continue;
      const a = Math.atan2(dy, dx);
      // Domain-warped pixel flame turbulence (curling tongues, not straight spikes!)
      const n1 = vnoise(Math.cos(a) * 3.5 + r * 0.08, Math.sin(a) * 3.5 + r * 0.08);
      const n2 = vnoise(Math.cos(a * 2 + n1 * 2) * 4.2, Math.sin(a * 2 - n1 * 2) * 4.2 + r * 0.12);
      const reach = R0 + 10 + 28 * (n1 * 0.6 + n2 * 0.4);
      if (r > reach) continue;
      const u = clamp(1 - (r - R0) / (reach - R0), 0, 1);
      const q = dq(Math.pow(u, 0.85), x, y, 5);
      if (q <= 0) continue;
      const col = q > 0.82 ? 0xffffff : q > 0.6 ? 0xffe066 : q > 0.38 ? 0xff6a24 : 0xa81648;
      px(x, y, col, clamp(q * 1.15, 0, 1));
    }
  });
}

function buildCrescentWave(): Texture {
  const S = 96, C = 47.5;
  return makeTex(S, S, (px) => {
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const dx = x - C, dy = y - C;
      const r = Math.hypot(dx, dy);
      const a = Math.atan2(dy, dx);
      if (Math.abs(a) > 1.35) continue;
      const u = 1 - Math.abs(a) / 1.35; // 1 at center of arc, 0 at tips
      const rOuter = 42;
      const thick = 18 * Math.pow(u, 0.75);
      const jag = (hash2(Math.floor(a * 18), Math.floor(r * 0.5)) - 0.5) * 4 * (1 - u * 0.4);
      const rInner = rOuter - thick + jag;
      if (r > rOuter + 1 || r < rInner) continue;
      const v = clamp((r - rInner) / Math.max(1, rOuter - rInner), 0, 1); // 1 at leading outer edge, 0 at trailing inner edge
      const q = dq(v * Math.pow(u, 0.35), x, y, 5);
      if (q <= 0) continue;
      const col = v > 0.82 ? 0xffffff : v > 0.52 ? 0xfff0b8 : 0xb8b8ff;
      px(x, y, col, clamp(q * 1.1, 0, 1));
    }
  });
}

function buildVortexSwirl(): Texture {
  const S = 128, C = 63.5;
  return makeTex(S, S, (px) => {
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const dx = x - C, dy = y - C;
      const r = Math.hypot(dx, dy);
      if (r < 6 || r > 60) continue;
      const a = Math.atan2(dy, dx);
      const spiral = Math.sin(a * 4 - Math.log(r) * 7.5 + vnoise(x * 0.08, y * 0.08) * 1.6);
      const env = Math.sin(((r - 6) / 54) * Math.PI);
      const val = clamp((spiral * 0.5 + 0.5) * env, 0, 1);
      if (val < 0.32) continue;
      const q = dq((val - 0.32) / 0.68, x, y, 4);
      if (q <= 0) continue;
      const col = q > 0.8 ? 0xffffff : q > 0.5 ? 0xffb8d0 : 0xc84878;
      px(x, y, col, q * 0.9);
    }
  });
}

function buildStarFlare(): Texture {
  const S = 64, C = 31.5;
  return makeTex(S, S, (px) => {
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const dx = Math.abs(x - C), dy = Math.abs(y - C);
      const r = Math.hypot(dx, dy);
      const cross = Math.max(0, 1 - dy / 2.2) * Math.max(0, 1 - dx / 29) + Math.max(0, 1 - dx / 2.2) * Math.max(0, 1 - dy / 29);
      const diag = Math.max(0, 1 - Math.abs(dx - dy) / 1.8) * Math.max(0, 1 - r / 18) * 0.7;
      const core = Math.max(0, 1 - r / 9);
      const v = clamp(Math.max(cross, diag, core * core), 0, 1);
      const q = dq(v, x, y, 5);
      if (q > 0) px(x, y, q > 0.75 ? 0xffffff : 0xd8e8ff, q);
    }
  });
}

function buildDragonHead(): Texture {
  // 40x32 pixel-art skeletal dragon skull with horns, glowing eye socket, and fangs
  const rows = [
    '....oooo................................',
    '..oobbbbooo.............................',
    '.obbbbbbbbbooo..........................',
    '..ooobbbbbbbbbooo.......................',
    '.....ooobbbbbbbbbooo....................',
    '........oobwwwwbbbbbooo.................',
    '.......oobwwwwwwwwbbbbbbooo.............',
    '......oobbbbbwwwwwwbbbbbbbbooo..........',
    '.....oobbbbbbbbbwwwwbbbbbbbbbbooo.......',
    '....oobbbbbbbbbbbbbbbbbbbbbbbbbbboo.....',
    '....obbbbbbbbooooobbbbbbbbbbbbbwwwwbo...',
    '....obbbbbbboeeeeeobbbbbbbbbbbwwwwwwbo..',
    '....obbbbbbboewwwweobbbbbbbbbbbbbbbbbbo.',
    '....obbbbbbbboeeeeobbbbbbbbbbbbbbbbbbbo.',
    '.....oobbbbbbbboooobbbbbbbbbbbbbbbbbbo..',
    '.......ooobbbbbbbbbbbbbbbbbbbbbbbbbbo...',
    '.........oooobbbbbbbbbbooobwobwobwbo....',
    '............ooooobbbbbbo..owo.owo.oo....',
    '......oooo......oooooooo................',
    '....oobbbbooo...........................',
    '...obbbbbbbbboo.........................',
    '....oobbbbbbbbbooo......................',
    '......oobbbbbbbbbbbooo..................',
    '........oobbbbbbbbbbbboooo..............',
    '..........oobbbbbbowobwobwoo............',
    '............ooooo..oo.oo.oo.............',
  ];
  const pal: Record<string, number> = { o: 0x100b1a, b: 0xd8ccb4, w: 0xfbf6ea, e: 0xff385c };
  return makeTex(40, 26, (px) => {
    for (let y = 0; y < rows.length; y++) for (let x = 0; x < rows[y].length; x++) {
      const ch = rows[y][x];
      if (ch !== '.') px(x, y, pal[ch], 1);
    }
  });
}

function buildHollowKing(): Texture {
  // 24x32 pixel-art crowned spectral knight wraith with halberd & tattered cloak
  const rows = [
    '.......o..o..o..o.......',
    '.......gggggggggg.......',
    '......ogwwwwwwwwgo......',
    '......obbbbbbbbbbo......',
    '.....oobbeebbeebboo.....',
    '.....obbbbbbbbbbbbo.....',
    '......ooobbbbbbooo......',
    '...ooooobwwwwwwbooooo...',
    '..obbbbbwwwwwwwwbbbbbo..',
    '.obbbbbbwwwwwwwwbbbbbbo.',
    '.obbb.obbbbbbbbbbo.bbbo.',
    '.obb..obbbwwwwbbbo..bbo.',
    '..o...obbbwwwwbbbo...o..',
    '......obbbbbbbbbbo......',
    '.....oobbbbbbbbbboo.....',
    '....obbbbbbbbbbbbbbo....',
    '....obbbbbbbbbbbbbbo....',
    '...oobbbbbbbbbbbbbboo...',
    '...obbbbbbbbbbbbbbbbo...',
    '..oobbbbbbbbbbbbbbbboo..',
    '..obbbboobbbbbboobbbbo..',
    '.oobbb..obbbbbbo..bbboo.',
    '.obbo...obboobbo...obbo.',
    '..oo....obo..obo....oo..',
    '........oo....oo........',
  ];
  const pal: Record<string, number> = { o: 0x0b1628, g: 0xffd85a, w: 0xf0fbff, b: 0x6ad8ff, e: 0xffffff };
  return makeTex(24, 25, (px) => {
    for (let y = 0; y < rows.length; y++) for (let x = 0; x < rows[y].length; x++) {
      const ch = rows[y][x];
      if (ch !== '.') px(x, y, pal[ch], ch === 'b' && y > 15 ? 0.78 : 1);
    }
  });
}

function buildChoirWraith(): Texture {
  // 20x26 veiled abyssal choir siren with halo and flowing spirit robes
  const rows = [
    '.....oooooooooo.....',
    '...ooggggggggggoo...',
    '..ogggooooooooogggo.',
    '..ogoo..oooo..ooggo.',
    '.....oobwwwwbbo.....',
    '....obwwwwwwwwbo....',
    '....obwweeeewbbo....',
    '....obwwwwwwwwbo....',
    '.....oobwwwwbbo.....',
    '....oobbbbbbbbboo...',
    '...obbbbbwwwwbbbbo..',
    '..obbbbbwwwwwwbbbbo.',
    '..obbbbbwwwwwwbbbbo.',
    '..obbbbbbwwwwbbbbbo.',
    '...obbbbbbbbbbbbbo..',
    '...oobbbbbbbbbbboo..',
    '....obbbbbbbbbbbo...',
    '....obbbboobbbbbo...',
    '...oobbb..oobbbboo..',
    '...obbo....o..obbo..',
    '....oo.........oo...',
  ];
  const pal: Record<string, number> = { o: 0x09182b, g: 0x9ef8ff, w: 0xe8fbff, b: 0x4ec8f0, e: 0x09182b };
  return makeTex(20, 21, (px) => {
    for (let y = 0; y < rows.length; y++) for (let x = 0; x < rows[y].length; x++) {
      const ch = rows[y][x];
      if (ch !== '.') px(x, y, pal[ch], ch === 'b' && y > 13 ? 0.75 : 1);
    }
  });
}

function buildGodEaterSkull(): Texture {
  // 80x72 monumental pixel-art Eldritch Abyssal Crown-Skull
  const W = 80, H = 72, CX = 39.5;
  return makeTex(W, H, (px) => {
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const dx = Math.abs(x - CX), dy = y - 34;
      // 7-spire abyssal crown at top
      const crownY = 18 - Math.cos((dx / 34) * Math.PI * 3.5) * 11 + (dx * dx) * 0.012;
      const inCrown = y >= crownY && y < 24 && dx < 32 - (24 - y) * 0.3;
      // Cranium & zygomatic arches
      const craniumR = Math.hypot(dx * 0.92, (y - 31) * 1.1);
      const cheek = y > 30 && y < 48 && dx > 14 && dx < 31 - Math.abs(y - 38) * 0.8;
      // Jaws & fangs
      const jaw = y >= 45 && y < 65 && dx < 22 - (y - 45) * 0.65;
      const fangGap = y >= 50 && ((Math.floor(dx) % 5 === 0) || (y > 54 && Math.abs(y - 54) < 3));
      const inBody = inCrown || craniumR < 25 || cheek || (jaw && !fangGap);
      if (!inBody) continue;

      // Eye sockets & third-eye brow sigil
      const eyeD = Math.hypot(dx - 11, (y - 35) * 1.25);
      const thirdEye = dx < 3.5 && Math.abs(y - 24) < 5.5 - dx;
      const nasal = dx < 3.2 && y > 39 && y < 47 && (dx + (47 - y) * 0.3 < 3.5);

      if (thirdEye) {
        px(x, y, dx < 1.2 && Math.abs(y - 24) < 2 ? 0xffffff : 0xffd85a, 1);
      } else if (eyeD < 6.2) {
        // Starfield void socket with glowing iris
        if (eyeD < 2.2) px(x, y, 0xffffff, 1);
        else if (eyeD < 3.6) px(x, y, 0x5ae8ff, 1);
        else px(x, y, 0x070512, 0.96);
      } else if (nasal) {
        px(x, y, 0x070512, 0.95);
      } else {
        // Shaded pixel bone with dark obsidian outline
        const edge = craniumR > 22.8 || dx > 28 || y < crownY + 2 || (jaw && dx > 19 - (y - 45) * 0.6);
        const hi = y < 28 && craniumR < 19 && ((x + y) % 2 === 0);
        const mid = craniumR < 21 && y < 44;
        const col = edge ? 0x141028 : hi ? 0xf4f8ff : mid ? 0xbfe2ff : 0x6d8eb8;
        px(x, y, col, 0.96);
      }
      void dy;
    }
  });
}

function buildGodEaterEye(): Texture {
  const W = 24, H = 16, CX = 11.5, CY = 7.5;
  return makeTex(W, H, (px) => {
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const dx = Math.abs(x - CX), dy = Math.abs(y - CY);
      const almond = (dx / 11) + (dy / (5.5 * (1 - Math.pow(dx / 11.5, 1.6) + 0.05)));
      if (almond > 1.05) continue;
      if (almond > 0.85) px(x, y, 0xffffff, 1);
      else if (dx < 1.3 && dy < 4.2) px(x, y, 0x080414, 1);
      else if (Math.hypot(dx, dy) < 4.2) px(x, y, 0xffd85a, 1);
      else px(x, y, 0x4ad8ff, 0.9);
    }
  });
}

function buildButterfly(open: boolean): Texture {
  const rows = open
    ? [
        '.oo.......oo.',
        'obbbo...obbbo',
        'obwwbo.obwwbo',
        'obwwwbobwwwbo',
        '.obwwwcwwwbo.',
        '..obbbwbbbo..',
        '..obbwwwbbo..',
        '.obwwbobwwbo.',
        '.obbo...obbo.',
        '..o.......o..',
      ]
    : [
        '....oo.oo....',
        '...obbbbbb...',
        '...obwwwbo...',
        '....obwbo....',
        '....obwbo....',
        '...obwwwbo...',
        '...obboobbo..',
        '....o....o...',
      ];
  const pal: Record<string, number> = { o: 0x1c1032, b: 0xd8c8ff, w: 0xffffff, c: 0xffe88a };
  return makeTex(rows[0].length, rows.length, (px) => {
    for (let y = 0; y < rows.length; y++) for (let x = 0; x < rows[y].length; x++) {
      const ch = rows[y][x];
      if (ch !== '.') px(x, y, pal[ch], 1);
    }
  });
}

function buildImperialSeal(): Texture {
  const S = 36;
  return makeTex(S, S, (px) => {
    for (let y = 2; y < S - 2; y++) for (let x = 2; x < S - 2; x++) {
      const border = x < 5 || x >= S - 5 || y < 5 || y >= S - 5;
      // Seal-script symmetrical glyph inside
      const gx = Math.abs(x - 17.5), gy = Math.abs(y - 17.5);
      const glyph =
        (gx < 1.5 && y > 7 && y < S - 7) ||
        (gy < 1.5 && x > 7 && x < S - 7) ||
        (Math.abs(gy - 6) < 1.2 && gx > 3 && gx < 10) ||
        (Math.abs(gx - 8) < 1.2 && gy > 3 && gy < 10);
      if (border || glyph) {
        const wear = hash2(x, y) > 0.12;
        if (wear) px(x, y, glyph ? 0xffe8a8 : 0xff3855, 0.92);
      } else {
        px(x, y, 0x38081e, 0.45);
      }
    }
  });
}

export function getStampTex(k: StampKey): Texture {
  let t = CACHE[k];
  if (t) return t;
  switch (k) {
    case 'seal_solar': t = buildSeal(6, 2, 4); break;
    case 'seal_astral': t = buildSeal(8, 3, 3); break;
    case 'seal_abyss': t = buildSeal(12, 5, 2); break;
    case 'seal_imperial': t = buildImperialSeal(); break;
    case 'corona_ring': t = buildCoronaRing(); break;
    case 'crescent_wave': t = buildCrescentWave(); break;
    case 'vortex_swirl': t = buildVortexSwirl(); break;
    case 'star_flare': t = buildStarFlare(); break;
    case 'dragon_head': t = buildDragonHead(); break;
    case 'hollow_king': t = buildHollowKing(); break;
    case 'choir_wraith': t = buildChoirWraith(); break;
    case 'godeater_skull': t = buildGodEaterSkull(); break;
    case 'godeater_eye': t = buildGodEaterEye(); break;
    case 'butterfly_open': t = buildButterfly(true); break;
    case 'butterfly_half': t = buildButterfly(false); break;
    default: t = buildStarFlare(); break;
  }
  CACHE[k] = t;
  return t;
}

export interface StampOpt {
  sx?: number;
  sy?: number;
  rot?: number;
  tint?: number;
  alpha?: number;
  ys?: number;
  add?: boolean;
}

/**
 * Pooled Sprite Stamp attached to a Graphics layer so any draw/skill code can stamp
 * crisp nearest-neighbor pixel-art textures with plane-foreshortening (`ys`).
 */
export class StampPool {
  c = new Container();
  private items: { wrap: Container; sp: Sprite }[] = [];
  private used = 0;
  constructor(public additive: boolean) {}
  reset() {
    for (let i = 0; i < this.used; i++) this.items[i].wrap.visible = false;
    this.used = 0;
  }
  put(key: StampKey, x: number, y: number, o: StampOpt = {}) {
    if (this.used >= 600) return;
    let it = this.items[this.used++];
    if (!it) {
      const wrap = new Container();
      const sp = new Sprite();
      sp.anchor.set(0.5);
      wrap.addChild(sp);
      this.c.addChild(wrap);
      it = { wrap, sp };
      this.items.push(it);
    }
    const { wrap, sp } = it;
    wrap.visible = true;
    wrap.position.set(Math.round(x), Math.round(y));
    wrap.scale.set(1, o.ys ?? 1);
    sp.texture = getStampTex(key);
    sp.blendMode = (o.add ?? this.additive) ? 'add' : 'normal';
    sp.scale.set(o.sx ?? 1, o.sy ?? o.sx ?? 1);
    sp.rotation = o.rot ?? 0;
    sp.tint = o.tint ?? 0xffffff;
    sp.alpha = clamp(o.alpha ?? 1, 0, 1);
  }
}

export function stampOn(g: Graphics, key: StampKey, x: number, y: number, o: StampOpt = {}) {
  const pool: StampPool | undefined = (g as any).__pool;
  if (pool) pool.put(key, x, y, o);
}
export { hiRamp, shadeRamp, mix, rgb, pack, lerp };
