// Core runtime: layered Pixi scene, texture-based pixel particles, actors, timeline and the lab runner.
// Motion is velocity-continuous (spring-smoothed), energy is accumulated over frames for living trails.
import { Application, Container, Graphics, Rectangle, Sprite, Texture } from 'pixi.js';
import { Composer, PostFx, PostState, newPost } from './post';
import { TEX, TexKey, TEXS, bay, dq } from './pixtex';
import { StampPool } from './sprites';
import { disc, gring, line, poly, px, rotRect } from './draw';
import {
  CX, H, P, TAU, W, YS, clamp, ease, hash1, lerp, mix, rand, reseed, rr,
} from './util';

export interface Skill {
  id: number;
  name: string;
  relic: string;
  sub: string;
  dur: number;
  phases: [number, string][];
  setup: (c: Ctx) => void;
  kind?: 'original' | 'minor' | 'major' | 'fusion';
  fusion?: { primary: Skill; secondary: Skill; offset: number; nexus: number; color: number };
}

// ---------------------------------------------------------------- particles
export interface Part {
  x: number; y: number; z: number; vx: number; vy: number; vz: number; ax: number; ay: number; gz: number;
  drag: number; bounce: number; life: number; age: number; size: number; size1: number; c0: number; c1: number;
  alpha: number; streak: number; hold: number; tex: TexKey; rot: number; spin: number; fl: number; qs: number;
}
export type Layer = 'low' | 'deb' | 'add' | 'sky';
const TEXKEYS: TexKey[] = ['dot', 'spark', 'star', 'glow', 'glowL', 'smoke', 'chunk', 'shard', 'streak', 'flame', 'bone', 'wing', 'ring', 'eye'];

class PLayer {
  c = new Container();
  ps: Record<string, Part[]> = {};
  spr: Record<string, Sprite[]> = {};
  constructor(public additive: boolean) { for (const k of TEXKEYS) { this.ps[k] = []; this.spr[k] = []; } }
  get(k: TexKey, i: number) {
    let s = this.spr[k][i];
    if (!s) {
      s = new Sprite(TEX(k));
      s.anchor.set(0.5);
      s.blendMode = this.additive ? 'add' : 'normal';
      this.spr[k][i] = s;
      this.c.addChild(s);
    }
    return s;
  }
  add(p: Part) { if (this.ps[p.tex].length < 9000) this.ps[p.tex].push(p); }
  update(dt: number) {
    for (const k of TEXKEYS) {
      const ps = this.ps[k];
      for (let i = ps.length - 1; i >= 0; i--) {
        const p = ps[i];
        p.age += dt;
        if (p.age >= p.life) { ps[i] = ps[ps.length - 1]; ps.pop(); continue; }
        if (p.age < p.hold) continue;
        const d = Math.exp(-p.drag * dt);
        p.vx = (p.vx + p.ax * dt) * d;
        p.vy = (p.vy + p.ay * dt) * d;
        p.vz -= p.gz * dt;
        p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
        p.rot += p.spin * dt;
        if (p.z < 0 && p.gz !== 0) {
          p.z = 0;
          if (p.vz < 0) { p.vz = -p.vz * p.bounce; p.vx *= 0.72; p.vy *= 0.72; if (p.bounce <= 0.02) p.vz = 0; }
        }
      }
    }
  }
  render() {
    for (const k of TEXKEYS) {
      const ps = this.ps[k], sp = this.spr[k];
      for (let i = 0; i < ps.length; i++) {
        const p = ps[i];
        const u = p.age / p.life;
        const s = this.get(k, i);
        s.visible = true;
        s.x = Math.round(p.x); s.y = Math.round(p.y - p.z);
        s.tint = p.c0 === p.c1 ? p.c0 : mix(p.c0, p.c1, u);
        // dithered fade: alpha quantised in Bayer order instead of a smooth ramp
        const a = p.alpha * clamp((1 - u) * (p.fl > 0 ? 2.2 : 4)) * (p.fl > 0 ? 0.55 + 0.45 * Math.sin(p.age * 34 + p.fl * 9) : 1);
        s.alpha = dq(clamp(a), s.x, s.y, p.qs);
        const sz = Math.max(1, lerp(p.size, p.size1, u));
        let sx = sz, sy = sz;
        if (p.streak > 0) {
          const spd = Math.hypot(p.vx, p.vy);
          s.rotation = Math.atan2(p.vy, p.vx);
          sx = sz + Math.min(30, spd * p.streak);
        } else s.rotation = p.rot;
        s.width = Math.max(1, Math.round(sx));
        s.height = Math.max(1, Math.round(sy));
      }
      for (let i = ps.length; i < sp.length; i++) sp[i].visible = false;
    }
  }
  clear() { for (const k of TEXKEYS) this.ps[k].length = 0; }
  count() { let n = 0; for (const k of TEXKEYS) n += this.ps[k].length; return n; }
}

export interface BurstOpt {
  ang?: [number, number]; spd?: [number, number]; life?: [number, number]; size?: [number, number]; size1?: number;
  cols?: number[]; c1?: number; drag?: number; gz?: number; vz?: [number, number]; z?: number; streak?: number;
  ax?: number; ay?: number; ys?: number; bounce?: number; alpha?: number; hold?: number; tex?: TexKey;
  spin?: number; fl?: number; ring?: boolean;
}

// ---------------------------------------------------------------- actors
const ENEMY_BMP = [
  '.oo........oo.',
  'obbo..oo..obbo',
  '.obbobbbbobbo.',
  '..obbbbbbbbo..',
  '..obebbbbebbo.',
  '..obbbbbbbbo..',
  '...oobllboo...',
  '.oobbbllbbbbo.',
  'obbbbbllbbbbbo',
  'obbbllllllllbo',
  'obbbllbbbbllbo',
  '.oobbbbbbbboo.',
  '..obbbbbbbbo..',
  '..obbo..obbo..',
  '..obbo..obbo..',
  '..ooo....ooo..',
];
const CASTER_BMP = [
  '....oooooo....',
  '...occcccco...',
  '..occhhhhcco..',
  '..ochweewhco..',
  '...ooohhooo...',
  '..ooccccccbo..',
  '.occcbbbbbbco.',
  'occcbbbbbbbbco',
  'occ.obbbbbbo.o',
  'oc..obbbbbbo..',
  'o...occcccco..',
  '....obbbbbbo..',
  '...oobbbbbboo.',
  '...obbo..obbo.',
  '...occo..occo.',
  '...ooo....ooo.',
];
const ENEMY_BODY = [0x6e5b9e, 0x488496, 0x9c5568];

function drawBmp(
  g: Graphics, bmp: string[], pal: Record<string, number>, ox: number, oy: number, rot: number, flip: number,
  mod: ((c: number, ch: string) => number) | null, alpha = 1, sx = 1, sy = 1,
) {
  const w = bmp[0].length, h = bmp.length;
  const groups = new Map<number, number[]>();
  const rotated = Math.abs(rot) > 0.03;
  const cr = Math.cos(rot), sr = Math.sin(rot);
  const hw = (w * sx) / 2, hh = (h * sy) / 2;
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) {
      const ch = bmp[j][i];
      if (ch === '.') continue;
      let col = pal[ch];
      if (mod) col = mod(col, ch);
      const lx = ((i - w / 2 + 0.5) * sx) * flip, ly = (j - h / 2 + 0.5) * sy;
      let x: number, y: number;
      if (rotated) { x = ox + lx * cr - ly * sr; y = oy - hh + lx * sr + ly * cr; } else { x = ox + lx; y = oy - hh + ly; }
      let arr = groups.get(col);
      if (!arr) groups.set(col, (arr = []));
      arr.push(Math.round(x), Math.round(y));
    }
  }
  const cw = Math.max(1, Math.ceil(sx * (rotated ? 1.3 : 1))), chh = Math.max(1, Math.ceil(sy * (rotated ? 1.3 : 1)));
  groups.forEach((arr, col) => {
    for (let k = 0; k < arr.length; k += 2) g.rect(arr[k] - (cw >> 1), arr[k + 1] - (chh >> 1), cw, chh);
    g.fill({ color: col, alpha });
  });
}

/** critically-damped, speed-limited smoothing => velocity stays continuous even across scripted teleports */
function smoothDamp(cur: number, target: number, v: number[], idx: number, smoothTime: number, dt: number, maxSpeed: number) {
  const st = Math.max(0.0001, smoothTime);
  const om = 2 / st;
  const x = om * dt;
  const exp = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
  let change = cur - target;
  const origTo = target;
  const maxChange = maxSpeed * st;
  change = clamp(change, -maxChange, maxChange);
  target = cur - change;
  const temp = (v[idx] + om * change) * dt;
  v[idx] = (v[idx] - om * temp) * exp;
  let out = target + change + temp * exp;
  if (origTo - cur > 0 === out > origTo) { out = origTo; v[idx] = (out - origTo) / dt; }
  return out;
}
const DAMP_C = 0.034, DAMP_C_MAX = 3400;
const DAMP_E = 0.13, DAMP_E_MAX = 780;

export class Enemy {
  x = 0; y = 0; z = 0; vx = 0; vy = 0; vz = 0; rot = 0; vrot = 0; lean = 0;
  tx = 0; ty = 0; tz = 0; trot = 0; dv = [0, 0, 0];
  flash = 0; shakeAmt = 0; tint: number | null = null; tintAmt = 0; alpha = 1; outline = 0; outlineCol = 0x9fe8ff;
  pinned = false; px = 0; py = 0; pz = 0; prot = 0; hx = 0; hy = 0; kind = 0; flip = 1; grav = 1; dead = false;
  sq = 0; blink = 0; air = 0;
  constructor(public id: number) {}
  /** set a motion target: the body eases into it (no teleport snapping) */
  pin(x: number, y: number, z = 0, rot = 0) { this.pinned = true; this.px = x; this.py = y; this.pz = z; this.prot = rot; }
  knock(vx: number, vy: number, vz = 0, spin = 0) {
    this.vx = vx; this.vy = vy; this.vz = vz; this.vrot = spin; this.flash = 1; this.sq = 1; this.shakeAmt = 1; this.pinned = false;
  }
  reset() {
    this.x = this.tx = this.hx; this.y = this.ty = this.hy; this.z = this.tz = 0;
    this.vx = this.vy = this.vz = 0; this.rot = this.vrot = 0; this.lean = 0; this.pinned = false;
    this.flash = 0; this.tint = null; this.tintAmt = 0; this.alpha = 1; this.outline = 0; this.shakeAmt = 0;
    this.grav = 1; this.sq = 0; this.air = 0; this.pz = 0; this.prot = 0; this.dv[0] = this.dv[1] = this.dv[2] = 0;
  }
  physics(dt: number, t: number) {
    // eased toward the pin target with a speed limit => continuous velocity, natural accel/decel
    if (this.pinned) {
      this.tx = this.px; this.ty = this.py; this.tz = this.pz; this.trot = this.prot;
      const ox = this.x, oy = this.y, oz = this.z;
      this.x = smoothDamp(this.x, this.tx, this.dv, 0, DAMP_E, dt, DAMP_E_MAX);
      this.y = smoothDamp(this.y, this.ty, this.dv, 1, DAMP_E, dt, DAMP_E_MAX);
      this.z = smoothDamp(this.z, this.tz, this.dv, 2, DAMP_E, dt, DAMP_E_MAX);
      this.vx = (this.x - ox) / dt; this.vy = (this.y - oy) / dt; this.vz = (this.z - oz) / dt;
      this.rot += (this.trot - this.rot) * (1 - Math.exp(-11 * dt));
      this.vrot *= Math.exp(-6 * dt);
      this.pinned = false;
    } else {
      this.x += this.vx * dt; this.y += this.vy * dt; this.z += this.vz * dt;
      if (this.z > 0 || this.vz > 0) { this.vz -= 430 * dt * this.grav; this.air = 1; }
      if (this.z <= 0) {
        this.z = 0;
        if (this.vz < -60) {
          this.sq = Math.min(1, -this.vz / 260);
          this.vz = -this.vz * 0.3; this.vx *= 0.78; this.vy *= 0.78; this.air = 0;
        } else { this.vz = 0; this.air = 0; }
        const f = Math.exp(-3.4 * dt);
        this.vx *= f; this.vy *= f; this.vrot *= Math.exp(-4.5 * dt);
        if (Math.abs(this.vx) + Math.abs(this.vy) < 26) this.rot = lerp(this.rot, Math.round(this.rot / TAU) * TAU, 1 - Math.exp(-7 * dt));
      }
      this.rot += this.vrot * dt;
    }
    this.x = clamp(this.x, -44, W + 44);
    this.y = clamp(this.y, 26, H + 44);
    const ka = 1 - Math.exp(-9 * dt);
    this.lean += (clamp(-this.vx * 0.0016, -0.4, 0.4) - this.lean) * ka;
    this.flash = Math.max(0, this.flash - dt * 3.4);
    this.shakeAmt = Math.max(0, this.shakeAmt - dt * 2.2);
    this.sq = Math.max(0, this.sq - dt * 5.5);
    this.blink = hash1(this.id * 3.7 + Math.floor(t * 0.7)) > 0.86 ? 1 : 0;
    if (Math.abs(this.vx) > 14) this.flip = this.vx > 0 ? 1 : -1;
  }
}

class Caster {
  x = 60; y = 190; z = 0; tx = 60; ty = 190; tz = 0;
  px = 60; py = 190; vx = 0; vy = 0; ax = 0; flip = 1; visible = true; alpha = 1; trail = 0xffd35a;
  glow = 0; ghostT = 0; rot = 0; lean = 0; bob = 0; sq = 0; step = 0; speed = 0; dv = [0, 0, 0];
  ghosts: { x: number; y: number; z: number; flip: number; age: number; life: number; col: number }[] = [];
}

const CPAL = (c: number) => ({ o: 0x100c1c, h: 0x241d38, w: 0xffffff, e: c, b: 0xe6ecff, c });
const EPAL = (b: number) => ({ o: 0x120d1d, b, l: mix(b, 0xd8e2ff, 0.38), e: 0xff385c });

// ---------------------------------------------------------------- context
interface Ent { t0: number; life: number; fn: (age: number, u: number, dt: number) => void }
interface Scar { t0: number; life: number; fn: (g: Layers, a: number, age: number) => void }
export interface Layers { mark: Graphics; glow: Graphics; act: Graphics; front: Graphics; dark: Graphics; add: Graphics; sky: Graphics }

/** default particle-density multiplier (user-adjustable via Lab.setQuality) */
export const DENS = 2.1;

export class Ctx {
  t = 0; dtl = 1 / 60;
  L: Layers;
  post: PostState = newPost();
  trailBase = 0.62;
  quantBase = 5.6;
  /** live quality knobs: particle density and bloom strength */
  dens = DENS;
  bloomScale = 1;
  enemies: Enemy[] = [];
  caster = new Caster();
  relic = 'halo';
  relicCol = 0xffd35a;
  dark = 0; sil = 0;
  camShake = 0; shakeX = 0; shakeY = 0;
  slowS = 1; slowT = 0;
  worldO = new Container();
  worldL = new Container();
  advanced = false;
  private pl: Record<Layer, PLayer> = { low: new PLayer(true), deb: new PLayer(false), add: new PLayer(true), sky: new PLayer(true) };
  private cues: { t: number; fn: () => void; done: boolean }[] = [];
  private handlers: ((t: number, dt: number) => void)[] = [];
  private segs: { t0: number; t1: number; fn: (u: number) => number[]; e: (t: number) => number }[] = [];
  private hides: [number, number][] = [];
  private ents: Ent[] = [];
  private scars: Scar[] = [];
  private pools: StampPool[] = [];
  private floor = new Graphics();

  constructor() {
    const mk = (add: boolean) => {
      const g = new Graphics();
      const pool = new StampPool(add);
      (g as any).__pool = pool;
      this.pools.push(pool);
      return g;
    };
    this.L = {
      mark: mk(false), glow: mk(true), act: mk(false), front: mk(false), dark: mk(false), add: mk(true), sky: mk(true),
    };
    this.L.glow.blendMode = 'add';
    this.L.add.blendMode = 'add';
    this.L.sky.blendMode = 'add';
    const P = (g: Graphics) => (g as any).__pool.c as Container;
    // opaque pass: floor, marks, darkness, ground light, actors, front occluders, debris
    this.worldO.addChild(
      this.floor,
      this.L.mark, P(this.L.mark),
      this.L.dark,
      this.L.glow, P(this.L.glow),
      this.pl.low.c,
      this.L.act, P(this.L.act),
      this.L.front, P(this.L.front),
      this.pl.deb.c,
    );
    // additive light pass
    this.worldL.addChild(
      this.L.add, P(this.L.add),
      this.pl.add.c,
      this.L.sky, P(this.L.sky),
      this.pl.sky.c,
    );
    this.buildFloor();
  }

  setBackgroundVisible(value: boolean) { this.floor.visible = value; }

  private buildFloor() {
    const g = this.floor;
    // Deep obsidian-indigo sanctum base (rich dark fantasy tone, never flat grey graph paper)
    // 2×-wide world under the 0.5× camera. This is EXTRA background, not a
    // lower-quality or downsampled substitute for the original arena.
    g.rect(-W / 2, -H / 2, W * 2, H * 2).fill(0x13111f);
    // Staggered ancient stone slabs with subtle bevel highlights and broken seams
    const th = 22, tw = 32;
    for (let row = -7; row < 20; row++) {
      const y = row * th;
      const off = (row & 1) ? 16 : 0;
      for (let col = -9; col < 27; col++) {
        const x = col * tw + off;
        const h = hash1(col * 17.3 + row * 11.1);
        const base = mix(0x171526, 0x211e34, h);
        g.rect(x + 1, y + 1, tw - 1, th - 1).fill(base);
        // Subtle top-left stone bevel & bottom shadow
        g.rect(x + 2, y + 1, tw - 4, 1).fill({ color: 0x2b2742, alpha: 0.55 });
        g.rect(x + 1, y + th - 1, tw - 1, 1).fill({ color: 0x0d0b16, alpha: 0.75 });
        if (h > 0.78) {
          g.rect(x + 6, y + 7, 4, 1).fill(0x2d2946);
          g.rect(x + 7, y + 8, 2, 1).fill(0x100e1b);
        } else if (h < 0.16) {
          g.rect(x + 18, y + 11, 3, 2).fill(0x0f0d19);
        }
      }
    }
    // Ornate carved sanctum astrolabe inlay at arena center (continuous stone rings & compass star, no dotted brown beads)
    const cy = 160;
    disc(g, CX, cy, 114, 0x161326, 0.9, YS);
    gring(g, CX, cy, 112, 0x2d2846, 2, 0.85, 0, TAU, YS);
    gring(g, CX, cy, 104, 0x231f38, 1, 0.8, 0, TAU, YS);
    gring(g, CX, cy, 64, 0x292542, 1, 0.8, 0, TAU, YS);
    gring(g, CX, cy, 28, 0x2d2846, 1, 0.85, 0, TAU, YS);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      const r0 = 28, r1 = i % 2 === 0 ? 112 : 64;
      line(
        g,
        [[CX + Math.cos(a) * r0, cy + Math.sin(a) * r0 * YS], [CX + Math.cos(a) * r1, cy + Math.sin(a) * r1 * YS]],
        1, 0x25213a, 0.75,
      );
      const rx = Math.round(CX + Math.cos(a) * 84), ry = Math.round(cy + Math.sin(a) * 84 * YS);
      g.rect(rx - 1, ry - 1, 3, 3).fill(0x2f2a4a);
    }
    // Gothic sanctum upper colonnade & parapet
    g.rect(0, 0, W, 46).fill(0x0b0a14);
    g.rect(0, 42, W, 5).fill(0x1b182c);
    g.rect(0, 42, W, 1).fill(0x322d4e);
    g.rect(0, 47, W, 3).fill({ color: 0x07060d, alpha: 0.85 });
    for (let i = 0; i < 9; i++) {
      const px0 = i * 56 + 14;
      // Stone pillar & gothic arch shadow
      g.rect(px0, 10, 14, 34).fill(0x181528);
      g.rect(px0 + 1, 10, 12, 2).fill(0x312c4d);
      g.rect(px0 + 3, 14, 8, 28).fill(0x110f1e);
      g.rect(px0 + 5, 18, 4, 2).fill(0x3b355c);
    }
  }

  // ---- timeline API
  at(t: number, fn: () => void) { this.cues.push({ t, fn, done: false }); }
  each(fn: (t: number, dt: number) => void) { this.handlers.push(fn); }
  seg(t0: number, t1: number, fn: (u: number) => number[], e: (t: number) => number = ease.io) { this.segs.push({ t0, t1, fn, e }); }
  hide(t0: number, t1: number) { this.hides.push([t0, t1]); }
  ent(life: number, fn: (age: number, u: number, dt: number) => void) { this.ents.push({ t0: this.t, life, fn }); }
  scar(life: number, fn: (g: Layers, a: number, age: number) => void) { this.scars.push({ t0: this.t, life, fn }); }
  slow(scale: number, dur: number) { this.slowS = scale; this.slowT = dur; }
  shake(a: number) { this.camShake = Math.max(this.camShake, a); }
  darken(a: number) { this.dark = Math.max(this.dark, a); }
  silhouette(a: number) { this.sil = Math.max(this.sil, a); }
  flash(col: number, a: number) {
    const f = this.post.flash;
    if (a > f[3]) { f[0] = ((col >> 16) & 255) / 255; f[1] = ((col >> 8) & 255) / 255; f[2] = (col & 255) / 255; f[3] = clamp(a) * 0.82; }
  }
  distort(x: number, y: number, r: number, amp: number) { this.post.shocks.push([x, y, r, amp]); }
  lens(x: number, y: number, r: number, k: number) { this.post.lens.push([x, y, r, k]); }

  // ---- particles
  emit(layer: Layer, o: Partial<Part>) {
    const size = o.size ?? 1;
    const tex: TexKey = o.tex ?? (o.streak && o.streak > 0 ? 'streak' : size >= 2.6 ? 'chunk' : size >= 1.5 ? 'spark' : 'dot');
    const hard = tex === 'chunk' || tex === 'bone' || tex === 'shard';
    const base: Part = {
      x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, ax: 0, ay: 0, gz: 0, drag: 0, bounce: 0.3, life: 1, age: 0,
      size: 1, size1: 1, c0: 0xffffff, c1: 0xffffff, alpha: 1, streak: 0, hold: 0, tex,
      rot: rr(0, TAU), spin: hard ? rr(-9, 9) : 0, fl: 0, qs: hard ? 0 : 4,
    };
    this.pl[layer].add(Object.assign(base, o, { size, tex }));
  }
  burst(layer: Layer, x: number, y: number, n: number, o: BurstOpt = {}) {
    const ang = o.ang ?? [0, TAU], spd = o.spd ?? [20, 80], life = o.life ?? [0.4, 0.9], size = o.size ?? [1, 2];
    const cols = o.cols ?? [0xffffff];
    const count = Math.round(n * this.dens);
    for (let i = 0; i < count; i++) {
      const ring = o.ring ? (i / count) * (ang[1] - ang[0]) + ang[0] : rr(ang[0], ang[1]);
      const s = o.ring ? lerp(spd[0], spd[1], (i % 5) / 4) : rr(spd[0], spd[1]);
      const sp = (o as any).spread ? rr(0, (o as any).spread) : 0;
      const sa = rand() * TAU;
      this.emit(layer, {
        x: x + Math.cos(sa) * sp, y: y + Math.sin(sa) * sp * YS, z: o.z ?? 0,
        vx: Math.cos(ring) * s, vy: Math.sin(ring) * s * (o.ys ?? 1), vz: o.vz ? rr(o.vz[0], o.vz[1]) : 0,
        ax: o.ax ?? 0, ay: o.ay ?? 0, gz: o.gz ?? 0, drag: o.drag ?? 0, bounce: o.bounce ?? 0.3,
        life: rr(life[0], life[1]), size: rr(size[0], size[1]), size1: o.size1 ?? 1,
        c0: cols[Math.floor(rand() * cols.length)], c1: o.c1 ?? cols[Math.floor(rand() * cols.length)],
        streak: o.streak ?? 0, alpha: o.alpha ?? 1, hold: o.hold ?? 0, tex: o.tex ?? ('dot' as TexKey),
        spin: o.spin ? rr(-o.spin, o.spin) : 0, fl: o.fl ?? 0,
      });
    }
  }
  /** single textured pixel sprite (flashes, stars, glows) */
  sprite(layer: Layer, tex: TexKey, x: number, y: number, size: number, life: number, col: number, o: Partial<Part> = {}) {
    this.emit(layer, { tex, x, y, size, size1: o.size1 ?? size, life, c0: col, c1: o.c1 ?? col, alpha: o.alpha ?? 1, qs: 5, ...o });
  }
  count() { let n = 0; for (const k of Object.keys(this.pl) as Layer[]) n += this.pl[k].count(); return n; }

  // ---- enemies
  layout(pts: P[]) {
    while (this.enemies.length < pts.length) this.enemies.push(new Enemy(this.enemies.length));
    this.enemies.length = pts.length;
    pts.forEach((p, i) => { const e = this.enemies[i]; e.hx = p[0]; e.hy = p[1]; e.kind = i % 3; e.reset(); });
  }
  blast(x: number, y: number, r: number, power: number, lift = 90, spin = 8) {
    for (const e of this.enemies) {
      const d = Math.hypot(e.x - x, (e.y - y) / YS);
      if (d < r) {
        const a = Math.atan2(e.y - y, e.x - x), k = 1 - (d / r) * 0.5;
        e.knock(Math.cos(a) * power * k, Math.sin(a) * power * k * YS, lift * k, (rand() - 0.5) * spin);
      }
    }
    // violent ground reaction: dust ring, sparks, scorch
    this.burst('low', x, y, 26, { spd: [30, 150], life: [0.5, 1.3], cols: [0x6a6474, 0x4a4658, 0x8a8498], size: [1, 3], drag: 2.4, ys: YS, tex: 'smoke' });
    this.burst('add', x, y, 18, { spd: [60, 260], life: [0.25, 0.6], cols: [0xffffff], size: [1, 2], drag: 3, ys: YS, tex: 'spark', streak: 0.02 });
  }
  /** readable per-target hit: pixel flash, sparks, squash, impulse */
  strike(e: Enemy, ang: number, power: number, lift = 60, col = 0xffffff, spin = 8) {
    e.knock(Math.cos(ang) * power, Math.sin(ang) * power * YS, lift, (rand() - 0.5) * spin);
    const x = Math.round(e.x), y = Math.round(e.y - 6 - e.z);
    this.sprite('add', 'star', x, y, 22, 0.16, 0xffffff, { size1: 8, c1: col, rot: ang });
    this.sprite('add', 'glow', x, y, 30, 0.22, col, { size1: 12 });
    // quantised radial pixel burst (a ring of pixels, not random scatter)
    const n = 14;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + ang * 0.2, s = 120 + (i % 3) * 70;
      this.emit('add', { tex: i % 3 ? 'spark' : 'dot', x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.85, life: 0.24 + (i % 4) * 0.06, size: i % 3 ? 5 : 2, c0: 0xffffff, c1: col, drag: 5, streak: 0.02 });
    }
    this.burst('deb', x, y + 6, 7, { spd: [30, 130], vz: [40, 180], gz: 400, life: [0.6, 1.4], size: [1, 3], cols: [0x4a3a44, col, 0xd8d0e0], tex: 'chunk', spin: 9, bounce: 0.4 });
    this.burst('low', x, y + 8, 8, { spd: [20, 90], life: [0.4, 1], cols: [0x6a6474, 0x3a3648], size: [2, 4], drag: 3, ys: YS, tex: 'smoke' });
    this.shake(2.4);
  }
  /** expanding pixel shockwave: dithered rings, radial spokes, dense sparks, ground dust, distortion */
  shock(x: number, y: number, o: { r: number; life: number; col: number; w?: number; amp?: number; push?: number; lift?: number; ys?: number; col2?: number }) {
    const hit = new Set<Enemy>();
    const ys = o.ys ?? YS;
    const w = o.w ?? 4;
    this.ent(o.life, (_a, u, dt) => {
      const r = o.r * ease.outExpo(u);
      const f = 1 - u;
      const L = this.L;
      // Connected pixel shockwave rings with crescent energy teeth
      gring(L.mark, x, y, r * 0.96, 0x080612, w + 2, 0.25 * f, 0, TAU, ys);
      gring(L.glow, x, y, r, o.col, w + 1, 0.65 * f, 0, TAU, ys);
      gring(L.add, x, y, r, o.col2 ?? 0xffffff, Math.max(1, w - 1), 0.95 * f, 0, TAU, ys);
      gring(L.add, x, y, r * 0.84, o.col, 1, 0.45 * f * f, 0, TAU, ys);
      if (o.amp) this.distort(x, y, r, o.amp * f);
      // dense sparks riding the wavefront + dust kicked off the floor
      const n = Math.round(clamp(o.r * 0.12, 4, 20) * this.dens * dt * 60 * 0.35);
      for (let i = 0; i < n; i++) {
        const a = rr(0, TAU);
        this.emit('add', { tex: rand() < 0.4 ? 'streak' : 'spark', x: x + Math.cos(a) * r, y: y + Math.sin(a) * r * ys, vx: Math.cos(a) * rr(20, 120), vy: Math.sin(a) * rr(20, 120) * ys, vz: rr(0, 60), gz: 120, life: rr(0.25, 0.7), size: rand() < 0.4 ? 5 : 5, c0: 0xffffff, c1: o.col, drag: 2.4, streak: 0.03 });
      }
      if (ys === YS) for (let i = 0; i < Math.round(n * 0.7); i++) {
        const a = rr(0, TAU);
        this.emit('low', { tex: 'smoke', x: x + Math.cos(a) * r * 0.98, y: y + Math.sin(a) * r * ys, vx: Math.cos(a) * rr(10, 50), vy: Math.sin(a) * rr(6, 30) * ys, vz: rr(6, 34), gz: 30, life: rr(0.6, 1.5), size: rr(3, 7), size1: rr(8, 14), c0: 0x8a8498, c1: 0x2a2838, drag: 2, alpha: 0.55 });
      }
      if (o.push) for (const e of this.enemies) {
        if (hit.has(e)) continue;
        if (Math.hypot(e.x - x, (e.y - y) / ys) < r) { hit.add(e); this.strike(e, Math.atan2(e.y - y, e.x - x), o.push, o.lift ?? 70, o.col); }
      }
    });
  }

  silhouetteAt(g: Graphics, x: number, y: number, col: number, alpha = 1, flip = 1, rot = 0) {
    drawBmp(g, CASTER_BMP, { o: col, h: col, w: 0xffffff, e: col, b: col, c: col }, Math.round(x), Math.round(y + 6), rot, flip, null, alpha);
  }

  reset(skill: Skill) {
    reseed(skill.id * 977 + 13);
    this.t = 0; this.cues = []; this.handlers = []; this.segs = []; this.hides = []; this.ents = []; this.scars = [];
    for (const k of Object.keys(this.pl) as Layer[]) this.pl[k].clear();
    // prevent a previous fusion's scene from appearing before its secondary time offset
    for (const g of Object.values(this.L)) g.clear();
    for (const pool of this.pools) pool.reset();
    this.post = newPost();
    this.worldO.position.set(0, 0); this.worldL.position.set(0, 0);
    this.dark = this.sil = 0; this.camShake = 0; this.slowS = 1; this.slowT = 0; this.advanced = false;
    const c = this.caster;
    c.x = c.px = c.tx = 50; c.y = c.py = c.ty = 200; c.z = c.tz = 0; c.dv[0] = c.dv[1] = c.dv[2] = 0; c.ghosts = []; c.visible = true; c.alpha = 1;
    c.glow = 0; c.rot = 0; c.lean = 0; c.flip = 1; c.sq = 0; c.speed = 0;
    this.relic = skill.relic;
    this.trailBase = ({ halo: 0.64, chain: 0.58, fan: 0.52, spindle: 0.6, lantern: 0.68 } as Record<string, number>)[skill.relic] ?? 0.6;
    this.layout([[150, 120], [330, 110], [250, 190], [110, 190], [380, 190]]);
    c.trail = ({ halo: 0xffd35a, chain: 0xff3a4a, fan: 0x6af0ff, spindle: 0xc9a8ff, lantern: 0x7ad8ff } as Record<string, number>)[skill.relic] ?? 0xffffff;
    this.relicCol = c.trail;
    skill.setup(this);
    this.cues.sort((a, b) => a.t - b.t);
  }

  step(rawDt: number) {
    let dt = rawDt;
    if (this.slowT > 0) { dt *= this.slowS; this.slowT -= rawDt; }
    this.dtl = dt;
    this.t += dt;
    this.advanced = true;
    const t = this.t, L = this.L, c = this.caster;
    (Object.values(L) as Graphics[]).forEach((g) => g.clear());
    for (const p of this.pools) p.reset();
    this.post = newPost();
    this.post.trail = this.trailBase;
    this.post.quant = this.quantBase;
    this.post.bloom = this.bloomScale;
    this.dark = 0; this.sil = 0;
    for (const cue of this.cues) if (!cue.done && cue.t <= t) { cue.done = true; cue.fn(); }
    for (const h of this.handlers) h(t, dt);

    // ---- caster choreography: targets from segments, then spring-smoothed => continuous velocity
    for (const s of this.segs) {
      if (t >= s.t0) {
        const u = clamp((t - s.t0) / (s.t1 - s.t0));
        const r = s.fn(s.e(u));
        c.tx = r[0]; c.ty = r[1]; c.tz = r[2] ?? 0;
      }
    }
    const wasAir = c.z > 0.5;
    c.px = c.x; c.py = c.y;
    c.x = smoothDamp(c.x, c.tx, c.dv, 0, DAMP_C, dt, DAMP_C_MAX);
    c.y = smoothDamp(c.y, c.ty, c.dv, 1, DAMP_C, dt, DAMP_C_MAX);
    c.z = smoothDamp(c.z, c.tz, c.dv, 2, DAMP_C * 1.6, dt, DAMP_C_MAX);
    if (wasAir && c.z <= 0.5 && c.tz <= 0.5) {
      c.sq = 1;
      this.burst('low', c.x, c.y + 2, 12, { spd: [30, 130], life: [0.3, 0.8], cols: [0x7a7488, 0x4a4658], size: [2, 5], drag: 3, ys: YS, tex: 'smoke' });
      this.shake(1.6);
    }
    c.visible = !this.hides.some(([a, b]) => t >= a && t < b);
    const ivx = (c.x - c.px) / Math.max(dt, 1e-4), ivy = (c.y - c.py) / Math.max(dt, 1e-4);
    const ksm = 1 - Math.exp(-14 * dt);
    c.vx += (ivx - c.vx) * ksm; c.vy += (ivy - c.vy) * ksm;
    c.ax += ((ivx - c.vx) / Math.max(dt, 1e-4) - c.ax) * (1 - Math.exp(-8 * dt));
    c.speed = Math.hypot(c.vx, c.vy);
    if (Math.abs(c.vx) > 26) c.flip = c.vx > 0 ? 1 : -1;
    c.lean += (clamp(-c.ax * 0.00035 - c.vx * 0.00035, -0.34, 0.34) - c.lean) * ksm;
    c.bob = c.z > 0.5 ? 0 : Math.sin(t * (c.speed > 60 ? 17 : 3.4)) * (c.speed > 60 ? 1.1 : 0.5);
    c.sq = Math.max(0, c.sq - dt * 6);
    // afterimages + speed pixels
    c.ghostT -= dt;
    if (c.visible && c.speed > 120 && c.ghostT <= 0) {
      c.ghostT = clamp(26 / c.speed, 0.012, 0.05);
      c.ghosts.push({ x: c.x, y: c.y, z: c.z, flip: c.flip, age: 0, life: 0.34 + Math.min(0.3, c.speed / 2600), col: c.trail });
      const a = Math.atan2(c.vy, c.vx);
      this.emit('add', { tex: 'streak', x: c.x - Math.cos(a) * 5, y: c.y - 6 - c.z - Math.sin(a) * 5, vx: -Math.cos(a) * 30, vy: -Math.sin(a) * 30, life: 0.22, size: 7, c0: 0xffffff, c1: c.trail, drag: 3, rot: a });
    }
    c.step -= dt * (c.speed / 60);
    if (c.visible && c.z <= 0.5 && c.speed > 45 && c.step <= 0) {
      c.step = 1;
      this.emit('low', { tex: 'smoke', x: c.x - c.flip * 3, y: c.y + 2, vx: -c.vx * 0.12 + rr(-12, 12), vy: rr(-8, 4), vz: rr(4, 20), gz: 40, life: rr(0.3, 0.7), size: rr(2, 4), size1: rr(5, 8), c0: 0x8a8498, c1: 0x2a2838, drag: 3, alpha: 0.5 });
    }

    // ---- scripted entities and persistent scars
    for (let i = this.ents.length - 1; i >= 0; i--) {
      const e = this.ents[i], age = t - e.t0;
      if (age > e.life) { this.ents.splice(i, 1); continue; }
      e.fn(age, age / e.life, dt);
    }
    for (let i = this.scars.length - 1; i >= 0; i--) {
      const s = this.scars[i], age = t - s.t0;
      if (age > s.life) { this.scars.splice(i, 1); continue; }
      s.fn(L, clamp((s.life - age) / (s.life * 0.4)), age);
    }
    for (const e of this.enemies) e.physics(dt, t);
    for (const k of Object.keys(this.pl) as Layer[]) this.pl[k].update(dt);
    this.drawActors(dt);
    if (this.dark > 0) L.dark.rect(-W / 2, -H / 2, W * 2, H * 2).fill({ color: 0x02020a, alpha: clamp(this.dark) });
    for (const k of Object.keys(this.pl) as Layer[]) this.pl[k].render();
    this.camShake *= Math.exp(-7.5 * dt);
    if (this.camShake < 0.15) this.camShake = 0;
    this.shakeX = Math.round(rr(-1, 1) * this.camShake);
    this.shakeY = Math.round(rr(-1, 1) * this.camShake);
    this.worldO.position.set(this.shakeX, this.shakeY);
    this.worldL.position.set(this.shakeX, this.shakeY);
  }

  private drawActors(dt: number) {
    const g = this.L.act, c = this.caster, sil = this.sil;
    // additive afterimages
    for (let i = c.ghosts.length - 1; i >= 0; i--) {
      const gh = c.ghosts[i];
      gh.age += dt;
      if (gh.age > gh.life) { c.ghosts.splice(i, 1); continue; }
      const u = gh.age / gh.life;
      this.silhouetteAt(this.L.glow, gh.x, gh.y - gh.z, gh.col, 0.6 * (1 - u) * (1 - u), gh.flip);
      if (u < 0.5) this.silhouetteAt(this.L.add, gh.x, gh.y - gh.z, 0xffffff, 0.25 * (1 - u * 2), gh.flip);
    }
    type A = { y: number; draw: () => void };
    const list: A[] = [];
    for (const e of this.enemies) {
      if (e.dead) continue;
      const sh = 6 - Math.min(4, e.z * 0.05);
      g.ellipse(Math.round(e.x), Math.round(e.y + 1), Math.max(1.5, sh), Math.max(0.8, sh * 0.4)).fill({ color: 0x000000, alpha: 0.45 * e.alpha * clamp(1 - e.z / 220, 0.2, 1) });
      if (e.z > 14) gring(this.L.glow, Math.round(e.x), Math.round(e.y + 1), 5, 0x9fe8ff, 1, 0.3 * e.alpha, 0, TAU, YS);
      list.push({
        y: e.y, draw: () => {
          const shk = e.shakeAmt > 0 ? Math.round(rr(-1, 1) * e.shakeAmt * 2.2) : 0;
          const pal = EPAL(ENEMY_BODY[e.kind % 3]);
          const bob = Math.round(Math.sin(this.t * 2.6 + e.id * 1.7) * 1 + (e.air > 0 ? 0 : 0));
          const sqx = 1 + e.sq * 0.28, sqy = 1 - e.sq * 0.3;
          const mod = (col: number, ch: string) => {
            let o = col;
            if (ch === 'e' && e.blink > 0) o = pal.b;
            if (e.tint !== null && e.tintAmt > 0) o = mix(o, e.tint, e.tintAmt);
            if (sil > 0) o = mix(o, 0x050509, sil);
            if (e.flash > 0) o = mix(o, 0xffffff, clamp(e.flash * 1.5));
            return o;
          };
          const X = Math.round(e.x) + shk, Y = Math.round(e.y - e.z + 6) + bob;
          if (e.outline > 0) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as [number, number][])
            drawBmp(g, ENEMY_BMP, { o: e.outlineCol, b: e.outlineCol, l: e.outlineCol, e: e.outlineCol }, X + dx, Y + dy, e.rot + e.lean * 0.4, e.flip, null, e.outline * e.alpha, sqx, sqy);
          drawBmp(g, ENEMY_BMP, pal, X, Y, e.rot + e.lean * 0.4, e.flip, mod, e.alpha, sqx, sqy);
          // motion smear pixels when flung
          if (Math.hypot(e.vx, e.vy) > 150 && rand() < 0.7) this.emit('add', { tex: 'dot', x: X + rr(-3, 3), y: Y + rr(-4, 4), life: 0.18, size: 1, c0: 0xffffff, c1: 0x9fe8ff, alpha: 0.5 });
        },
      });
    }
    if (c.visible && c.alpha > 0) {
      g.ellipse(Math.round(c.x), Math.round(c.y + 1), Math.max(1.5, 6 - Math.min(4, c.z * 0.04)), 2.4).fill({ color: 0x000000, alpha: 0.5 * c.alpha });
      list.push({
        y: c.y + 0.5, draw: () => {
          const pal = CPAL(c.trail);
          const mod = (col: number) => (sil > 0 ? mix(col, 0x050509, sil * 0.7) : c.glow > 0 ? mix(col, 0xffffff, c.glow) : col);
          const sqx = 1 + c.sq * 0.24, sqy = 1 - c.sq * 0.26;
          drawBmp(g, CASTER_BMP, pal, Math.round(c.x), Math.round(c.y - c.z + 6 + c.bob), c.lean + c.rot, c.flip, mod, c.alpha, sqx, sqy);
          this.drawRelic(g, Math.round(c.x + c.flip * 8), Math.round(c.y - c.z - 6 + Math.sin(this.t * 4) * 1.2 + c.bob), c.alpha);
          if (c.glow > 0) this.L.add.ellipse(Math.round(c.x), Math.round(c.y - c.z - 2), 12, 16).fill({ color: 0xffffff, alpha: 0.25 * c.glow });
        },
      });
    }
    list.sort((a, b) => a.y - b.y);
    for (const a of list) a.draw();
    void TEXS; void poly; void rotRect;
  }

  private drawRelic(g: Graphics, x: number, y: number, a: number) {
    const col = this.relicCol, t = this.t;
    switch (this.relic) {
      case 'halo': gring(g, x, y, 4, col, 1, a, 0, TAU, 1, 0); g.rect(x - 1, y - 1, 2, 2).fill({ color: 0xffffff, alpha: a }); break;
      case 'chain': for (let i = 0; i < 4; i++) g.rect(x + (i % 2) * 2 - 2, y - 4 + i * 2, 2, 2).fill({ color: i % 2 ? 0xe8dcc0 : col, alpha: a }); break;
      case 'fan': { poly(g, [[x, y + 4], [x - 5, y - 3], [x - 2, y - 5], [x + 2, y - 5], [x + 5, y - 3]], 0xf2f6ff, a); g.rect(x - 1, y - 4, 2, 2).fill({ color: col, alpha: a }); break; }
      case 'spindle': { poly(g, [[x, y - 6], [x + 2, y], [x, y + 6], [x - 2, y]], 0xe6e0ff, a); g.rect(x, y - 7, 1, 1).fill({ color: col, alpha: a }); break; }
      default: g.rect(x - 2, y - 1, 4, 5).fill({ color: 0x2a3340, alpha: a }); g.rect(x - 1, y, 2, 2).fill({ color: mix(0x7ad8ff, 0xffffff, 0.5 + Math.sin(t * 9) * 0.3), alpha: a }); g.rect(x - 1, y - 3, 2, 2).fill({ color: col, alpha: a * 0.7 });
    }
  }
}
const CY_ = () => 150;

// ---------------------------------------------------------------- lab runner
export class Lab {
  app!: Application;
  ctx = new Ctx();
  private auxCtx = new Ctx();
  private combinedO = new Container();
  private combinedL = new Container();
  /** camera 1× original or 0.5×: the same original effects, no density reduction */
  cameraZoom = 0.5;
  skill: Skill | null = null;
  skills: Skill[] = [];
  playing = true;
  ended = false;
  speed = 1;
  showcase = false;
  qual = 1;
  onChange: () => void = () => {};
  private acc = 0;
  private post = new PostFx();
  private comp = new Composer();
  private holdT = 0;
  get displayTime() { return this.ctx.t; }
  get liveParticles() { return this.ctx.count() + (this.skill?.fusion ? this.auxCtx.count() : 0); }
  constructor() {
    this.combinedO.addChild(this.ctx.worldO, this.auxCtx.worldO);
    this.combinedL.addChild(this.ctx.worldL, this.auxCtx.worldL);
    this.auxCtx.setBackgroundVisible(false);
    this.auxCtx.L.act.visible = false; // one caster, two full visual systems
    this.auxCtx.worldO.visible = this.auxCtx.worldL.visible = false;
    this.applyCamera();
  }
  setCameraZoom(z: number) {
    this.cameraZoom = z;
    this.applyCamera();
    this.comp.reset(this.app.renderer);
    this.ctx.advanced = true;
    this.draw();
  }
  private applyCamera() {
    const z = this.cameraZoom;
    for (const scene of [this.combinedO, this.combinedL]) {
      scene.scale.set(z);
      scene.position.set(CX * (1 - z), (H / 2) * (1 - z));
    }
  }
  private screenPost(): PostState {
    const main = this.ctx.post;
    const extra = this.skill?.fusion && this.ctx.t >= this.skill.fusion.offset ? this.auxCtx.post : null;
    const z = this.cameraZoom;
    const project = (v: number[]) => [CX + (v[0] - CX) * z, H / 2 + (v[1] - H / 2) * z, v[2] * z, v[3] * z];
    const sh = [...main.shocks, ...(extra?.shocks ?? [])];
    const ln = [...main.lens, ...(extra?.lens ?? [])];
    const flash = extra && extra.flash[3] > main.flash[3] ? extra.flash : main.flash;
    return { ...main, shocks: sh.map(project), lens: ln.map(v => { const p = project(v); p[3] = v[3]; return p; }), flash,
      sliceB: extra?.slice,
      bloom: Math.max(main.bloom, extra?.bloom ?? 0),
      trail: Math.max(main.trail, extra?.trail ?? 0),
      aberr: Math.max(main.aberr, extra?.aberr ?? 0),
      quant: Math.max(main.quant, extra?.quant ?? 0),
    };
  }

  async init(host: HTMLElement) {
    this.app = new Application();
    await this.app.init({
      width: W, height: H, background: 0x0b0a10, antialias: false, resolution: 1, autoDensity: false,
      preference: 'webgl', preserveDrawingBuffer: true,
    });
    host.appendChild(this.app.canvas);
    this.comp.root.filterArea = new Rectangle(0, 0, W, H);
    this.comp.root.filters = [this.post];
    this.app.stage.addChild(this.comp.root);
    this.comp.reset(this.app.renderer);
    this.app.ticker.add((tk) => this.frame(tk.deltaMS / 1000));
  }
  destroy() { try { this.app.destroy(true, { children: true, texture: true }); } catch { /* noop */ } }
  load(s: Skill, autoplay = true) {
    this.skill = s;
    this.ctx.reset(s.fusion?.primary ?? s);
    this.auxCtx.worldO.visible = this.auxCtx.worldL.visible = !!s.fusion;
    if (s.fusion) {
      this.auxCtx.reset(s.fusion.secondary);
      this.auxCtx.setBackgroundVisible(false);
      this.auxCtx.L.act.visible = false;
    }
    this.ended = false; this.playing = autoplay; this.acc = 0; this.holdT = 0;
    this.comp.reset(this.app.renderer);
    this.ctx.step(1 / 60);
    this.draw();
    this.onChange();
  }
  restart() { if (this.skill) this.load(this.skill, true); }
  /** Preserved legacy API, but intentionally fixed at FULL strength in this remix laboratory. */
  setQuality(_q: number) {
    this.qual = 1;
    for (const c of [this.ctx, this.auxCtx]) { c.dens = DENS; c.bloomScale = 1; c.quantBase = 5.6; }
  }
  toggle() { if (this.ended) return this.restart(); this.playing = !this.playing; this.onChange(); }
  seek(t: number) {
    if (!this.skill) return;
    const s = this.skill;
    this.ctx.reset(s.fusion?.primary ?? s);
    if (s.fusion) {
      this.auxCtx.reset(s.fusion.secondary);
      this.auxCtx.setBackgroundVisible(false);
      this.auxCtx.L.act.visible = false;
    }
    this.ended = false;
    this.comp.reset(this.app.renderer);
    this.simStep(1 / 60);
    this.runTo(t);
    this.draw();
  }
  advance(t: number) { this.runTo(t); this.draw(); }
  /** step to a time; only the last ~0.8s is composited (trail buffer needs recent history) */
  private runTo(t: number) {
    while (this.ctx.t < t) {
      this.simStep(1 / 60);
      if (this.ctx.t > t - 0.8) this.compDraw();
    }
  }
  private simStep(dt: number) {
    this.ctx.step(dt);
    const fuse = this.skill?.fusion;
    if (fuse && this.ctx.t >= fuse.offset) {
      this.auxCtx.step(dt);
      // A third, interacting effect originates at the intersection of the two
      // original phenomena. The source effects themselves remain unmodified.
      if (this.ctx.t >= fuse.nexus && this.ctx.t - dt < fuse.nexus) {
        const x = CX, y = 158;
        this.ctx.shock(x, y, { r: 190, life: 1.15, col: fuse.color, w: 4, amp: 7, push: 170, lift: 70 });
        this.ctx.burst('add', x, y, 100, { spd: [60, 280], life: [0.4, 1.4], size: [2, 6], size1: 1,
          cols: [fuse.color, this.auxCtx.relicCol, this.ctx.relicCol, 0xffffff], tex: 'shard', streak: 0.028 });
        this.ctx.flash(fuse.color, 0.32);
        this.ctx.shake(4);
      }
    }
  }
  private compDraw() {
    const s = this.screenPost();
    this.post.apply_state(s, this.ctx.t);
    this.comp.draw(this.app.renderer, this.combinedO, this.combinedL, s, this.ctx.t);
  }
  draw() {
    const s = this.screenPost();
    this.post.apply_state(s, this.ctx.t);
    if (this.ctx.advanced) { this.comp.draw(this.app.renderer, this.combinedO, this.combinedL, s, this.ctx.t); this.ctx.advanced = false; }
    this.app.render();
  }
  next(d: number) {
    if (!this.skills.length || !this.skill) return;
    const i = (this.skills.findIndex((s) => s.id === this.skill!.id) + d + this.skills.length) % this.skills.length;
    this.load(this.skills[i], true);
  }
  private frame(dt: number) {
    if (!this.skill) return;
    if (this.playing && !this.ended) {
      this.acc += Math.min(dt, 0.1) * this.speed;
      let n = 0;
      while (this.acc >= 1 / 60 && n < 6) {
        this.simStep(1 / 60);
        this.acc -= 1 / 60; n++;
        if (this.displayTime >= this.skill.dur) { this.ended = true; this.playing = false; this.holdT = 0; this.onChange(); break; }
      }
      if (n) this.draw();
    } else if (this.ended && this.showcase) {
      this.holdT += dt;
      if (this.holdT > 1.4) this.next(1);
    } else if (this.ctx.advanced) this.draw();
  }
}
export { Texture, bay };
