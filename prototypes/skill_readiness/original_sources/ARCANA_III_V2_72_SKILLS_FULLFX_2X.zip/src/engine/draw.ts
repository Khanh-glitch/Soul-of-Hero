// Fantasy Pixel-Art Geometry & Magical Construct Primitives.
// Every primitive uses hue-shifted pixel color ramps (never muddy alpha-brown) and connected pixel-grid geometry
// (never gappy beaded circles or flat vector hoses).
import type { Graphics } from 'pixi.js';
import { P, TAU, YS, clamp, hash1, lerp, mix, pack, rgb } from './util';
import { stampOn } from './sprites';

const R = Math.round;

/**
 * Hue-shifting shadow: in real fantasy pixel art, warm colors (gold, orange, red) shift toward
 * deep crimson/magenta/violet in their dark steps — NEVER toward muddy olive/brown!
 * Cold colors (cyan, green, blue) shift toward deep royal indigo/navy.
 */
export function shadeRamp(col: number, k: number): number {
  k = clamp(k, 0, 1);
  const [r, g, b] = rgb(col);
  // Warm colors shift toward deep magenta-violet (0x3a0c38); cool colors shift toward deep indigo (0x121842)
  const warm = r > b + 20 ? 1 : 0;
  const shadow = warm ? [58, 10, 52] : [18, 22, 68];
  const mid = warm ? [Math.min(255, r * 0.9 + 30), g * 0.42, Math.min(255, b * 0.7 + 55)] : [r * 0.45, g * 0.72, Math.min(255, b * 0.95 + 35)];
  if (k < 0.5) {
    const t = k * 2;
    return pack(lerp(shadow[0], mid[0], t), lerp(shadow[1], mid[1], t), lerp(shadow[2], mid[2], t));
  }
  const t = (k - 0.5) * 2;
  return pack(lerp(mid[0], r, t), lerp(mid[1], g, t), lerp(mid[2], b, t));
}

/** Hue-shifting highlight toward incandescent gold-white or cyan-white */
export function hiRamp(col: number, k: number): number {
  k = clamp(k, 0, 1);
  const [r, g, b] = rgb(col);
  const warm = r >= b;
  const hi = warm ? [255, 248, 215] : [225, 250, 255];
  return pack(lerp(r, hi[0], k), lerp(g, hi[1], k), lerp(b, hi[2], k));
}

/**
 * Multi-stepped fantasy pixel ribbon.
 * - Avoids flat vector tubes and avoids muddy brown ground-tape scars.
 * - For dark ground scars (`color < 0x222228`), renders tapered, chipped stone fissure segments instead of a black hose.
 * - For luminous ribbons, renders a hue-shifted outer aura + vivid body + bright inner core spine.
 */
export function ribbon(g: Graphics, pts: P[], w: number | ((i: number, n: number) => number), color: number, alpha = 1) {
  const n = pts.length;
  if (n < 2 || alpha <= 0.01) return;
  const [cr, cg, cb] = rgb(color);
  const isDarkMark = cr + cg + cb < 95;

  if (isDarkMark) {
    // Instead of a continuous black rubber hose on the floor, draw broken obsidian fissure stones that taper at both ends
    const step = Math.max(2, Math.floor(n / 18));
    for (let i = 0; i < n - 1; i += step) {
      const p0 = pts[i], p1 = pts[Math.min(n - 1, i + step)];
      const u = i / Math.max(1, n - 1);
      const endTaper = Math.sin(u * Math.PI);
      if (endTaper < 0.18) continue;
      const rawW = typeof w === 'number' ? w : w(i, n);
      const hw = Math.max(1, rawW * 0.36 * endTaper);
      const dx = p1[0] - p0[0], dy = p1[1] - p0[1], l = Math.hypot(dx, dy) || 1;
      const nx = -dy / l, ny = dx / l;
      const j0 = (hash1(i * 3.7 + p0[0]) - 0.5) * 2.2;
      const j1 = (hash1(i * 5.3 + p1[1]) - 0.5) * 2.2;
      g.poly([
        R(p0[0] + nx * (hw + j0)), R(p0[1] + ny * (hw + j0)),
        R(p1[0] + nx * (hw * 0.8 + j1)), R(p1[1] + ny * (hw * 0.8 + j1)),
        R(p1[0] - nx * (hw * 0.8 - j1)), R(p1[1] - ny * (hw * 0.8 - j1)),
        R(p0[0] - nx * (hw - j0)), R(p0[1] - ny * (hw - j0)),
      ]).fill({ color: 0x0c0a18, alpha: Math.min(0.65, alpha * 0.75) });
    }
    return;
  }

  // Build left/right pixel-snapped rails with subtle organic serration on wide ribbons
  const buildPoly = (scale: number, serrate: number): number[] => {
    const L: number[] = [], Rt: number[] = [];
    for (let i = 0; i < n; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
      let dx = b[0] - a[0], dy = b[1] - a[1];
      const l = Math.hypot(dx, dy) || 1;
      dx /= l; dy /= l;
      const baseW = typeof w === 'number' ? w : w(i, n);
      const jag = serrate > 0 && baseW >= 5 ? (hash1(i * 7.13) - 0.35) * serrate * Math.min(4, baseW * 0.25) : 0;
      const hw = Math.max(0.5, (baseW * scale + jag) * 0.5);
      L.push(R(pts[i][0] - dy * hw), R(pts[i][1] + dx * hw));
      Rt.push(R(pts[i][0] + dy * hw), R(pts[i][1] - dx * hw));
    }
    const flat: number[] = [];
    for (let i = 0; i < n; i++) flat.push(L[i * 2], L[i * 2 + 1]);
    for (let i = n - 1; i >= 0; i--) flat.push(Rt[i * 2], Rt[i * 2 + 1]);
    return flat;
  };

  const sampleW = typeof w === 'number' ? w : w(n >> 1, n);
  const deepCol = shadeRamp(color, 0.38);
  const midCol = shadeRamp(color, 0.78);
  const brightCol = hiRamp(color, 0.55);

  if (sampleW >= 6) {
    // 3-step fantasy pixel ramp: deep hue-shifted aura -> vivid body -> bright inner spine
    g.poly(buildPoly(1.12, 1.0)).fill({ color: deepCol, alpha: clamp(alpha * 0.55, 0, 0.85) });
    g.poly(buildPoly(0.76, 0.4)).fill({ color: midCol, alpha: clamp(alpha * 0.88, 0, 0.96) });
    g.poly(buildPoly(0.32, 0.0)).fill({ color: brightCol, alpha: clamp(alpha * 0.95, 0, 1) });
  } else {
    g.poly(buildPoly(1.0, 0.0)).fill({ color: midCol, alpha: clamp(alpha * 0.88, 0, 0.96) });
    if (sampleW >= 2.5) {
      g.poly(buildPoly(0.42, 0.0)).fill({ color: brightCol, alpha: clamp(alpha * 0.92, 0, 1) });
    }
  }
}

export function line(g: Graphics, pts: P[], w: number, color: number, alpha = 1) {
  if (pts.length < 2 || alpha <= 0.01) return;
  const [cr, cg, cb] = rgb(color);
  const isDark = cr + cg + cb < 95;
  const rw = Math.max(1, R(w));
  if (!isDark && rw >= 2) {
    // Hue-shifted outer pixel step so lines never look like raw CAD vectors
    const outer = shadeRamp(color, 0.42);
    g.moveTo(R(pts[0][0]), R(pts[0][1]));
    for (let i = 1; i < pts.length; i++) g.lineTo(R(pts[i][0]), R(pts[i][1]));
    g.stroke({ width: rw + 2, color: outer, alpha: alpha * 0.45, cap: 'butt', join: 'miter' });
  }
  const mainCol = isDark ? 0x0e0b1a : shadeRamp(color, 0.88);
  g.moveTo(R(pts[0][0]), R(pts[0][1]));
  for (let i = 1; i < pts.length; i++) g.lineTo(R(pts[i][0]), R(pts[i][1]));
  g.stroke({ width: rw, color: mainCol, alpha: isDark ? Math.min(0.6, alpha) : alpha, cap: 'butt', join: 'miter' });
}

export function seg(g: Graphics, x0: number, y0: number, x1: number, y1: number, w: number, color: number, alpha = 1) {
  line(g, [[x0, y0], [x1, y1]], w, color, alpha);
}

/** Pixel-snapped disc with a stepped outer aura rim when r >= 4 */
export function disc(g: Graphics, x: number, y: number, r: number, color: number, alpha = 1, ys = 1) {
  if (r <= 0 || alpha <= 0.01) return;
  x = R(x); y = R(y);
  if (r <= 1.5) {
    const s = r > 0.85 ? 2 : 1;
    g.rect(x - (s >> 1), y - (s >> 1), s, s).fill({ color, alpha });
    return;
  }
  const n = clamp(Math.round(r * 2.5), 10, 32);
  const f: number[] = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU;
    f.push(R(x + Math.cos(a) * r), R(y + Math.sin(a) * r * ys));
  }
  g.poly(f).fill({ color, alpha });
}

export function px(g: Graphics, x: number, y: number, s: number, color: number, alpha = 1) {
  g.rect(R(x - s / 2), R(y - s / 2), Math.max(1, R(s)), Math.max(1, R(s))).fill({ color, alpha });
}

/** Hue-shifted stepped pixel light pool (replaces muddy single-color alpha circles) */
export function ditherDisc(g: Graphics, x: number, y: number, r: number, color: number, alpha = 1, ys = 1, lv = 4) {
  if (r <= 1 || alpha <= 0.01) return;
  for (let i = 0; i < lv; i++) {
    const u = i / Math.max(1, lv - 1); // 0 = outer, 1 = inner
    const rad = r * (1 - u * 0.68);
    const stepCol = u < 0.7 ? shadeRamp(color, 0.35 + u * 0.85) : hiRamp(color, (u - 0.7) * 1.8);
    disc(g, x, y, rad, stepCol, alpha * (0.14 + u * 0.22), ys);
  }
}

/**
 * Connected pixel-art ring/arc (replaces the old gappy beaded `gring`).
 * Draws a continuous pixel-snapped polyline with a hue-shifted aura step and arcane cardinal nodes on full rings.
 */
export function gring(
  g: Graphics, cx: number, cy: number, r: number, color: number, w = 1, alpha = 1,
  a0 = 0, a1 = TAU, ys = YS, rot = 0,
) {
  if (r < 0.8 || alpha <= 0.01) return;
  const span = Math.abs(a1 - a0);
  const arcLen = span * r * Math.max(ys, 0.5);
  const n = clamp(Math.round(arcLen / 2.2), 12, 120);
  const cr = Math.cos(rot), sr = Math.sin(rot);
  const pts: P[] = [];
  for (let i = 0; i <= n; i++) {
    const a = lerp(a0, a1, i / n);
    const x = Math.cos(a) * r, y = Math.sin(a) * r * ys;
    pts.push([R(cx + x * cr - y * sr), R(cy + x * sr + y * cr)]);
  }
  const rw = Math.max(1, R(w));
  const [rc, gc, bc] = rgb(color);
  const isDark = rc + gc + bc < 95;
  if (isDark) {
    line(g, pts, rw, 0x0c0a18, Math.min(0.55, alpha));
    return;
  }
  const deep = shadeRamp(color, 0.38);
  const main = shadeRamp(color, 0.88);
  const hi = hiRamp(color, 0.6);
  if (rw >= 2) {
    g.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
    g.stroke({ width: rw + 2, color: deep, alpha: alpha * 0.45, cap: 'butt', join: 'round' });
  }
  g.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
  g.stroke({ width: rw, color: main, alpha: clamp(alpha * 0.92, 0, 1), cap: 'butt', join: 'round' });
  if (rw >= 3) {
    g.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
    g.stroke({ width: 1, color: hi, alpha: clamp(alpha, 0, 1), cap: 'butt', join: 'round' });
  }
}

/** Ornate fantasy pixel-art magic seal using hand-rasterized 128x128 pixel seal textures */
export function magicSeal(
  g: Graphics, cx: number, cy: number, r: number, color: number, rot = 0, alpha = 1, ys = YS, points = 6,
) {
  if (r < 4 || alpha <= 0.02) return;
  const key = points >= 10 ? 'seal_abyss' : points >= 7 ? 'seal_astral' : 'seal_solar';
  const sc = r / 56;
  stampOn(g, key, cx, cy, { sx: sc, sy: sc, rot, tint: shadeRamp(color, 0.92), alpha: alpha * 0.95, ys, add: true });
  if (r >= 24) {
    stampOn(g, key, cx, cy, { sx: sc * 0.58, sy: sc * 0.58, rot: -rot * 1.2, tint: hiRamp(color, 0.55), alpha: alpha * 0.7, ys, add: true });
  }
}

/** Jagged pixel-art lightning / arcane bolt between two points */
export function pixelBolt(
  g: Graphics, p0: P, p1: P, color: number, amp = 10, w = 2, alpha = 1, seed = 1, branch = true,
) {
  if (alpha <= 0.02) return;
  const dx = p1[0] - p0[0], dy = p1[1] - p0[1];
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len, ny = dx / len;
  const steps = clamp(Math.round(len / 9), 4, 22);
  const pts: P[] = [p0];
  for (let i = 1; i < steps; i++) {
    const u = i / steps;
    const env = Math.sin(u * Math.PI);
    const j = (hash1(seed * 13.7 + i * 4.3) - 0.5) * 2 * amp * env;
    pts.push([R(lerp(p0[0], p1[0], u) + nx * j), R(lerp(p0[1], p1[1], u) + ny * j)]);
  }
  pts.push(p1);
  line(g, pts, w + 2, shadeRamp(color, 0.45), alpha * 0.55);
  line(g, pts, w, color, alpha * 0.95);
  line(g, pts, 1, hiRamp(color, 0.8), alpha);
  if (branch && steps >= 6) {
    const bi = Math.floor(steps * 0.45);
    const bp = pts[bi];
    const ba = Math.atan2(dy, dx) + (hash1(seed * 9.1) > 0.5 ? 0.65 : -0.65);
    const bl = len * 0.32;
    pixelBolt(g, bp, [bp[0] + Math.cos(ba) * bl, bp[1] + Math.sin(ba) * bl], color, amp * 0.5, 1, alpha * 0.75, seed + 19, false);
  }
}

export function ringPts(cx: number, cy: number, r: number, a0 = 0, a1 = TAU, n = 40, ys = YS, rot = 0): P[] {
  const pts: P[] = [];
  const cr = Math.cos(rot), sr = Math.sin(rot);
  for (let i = 0; i <= n; i++) {
    const a = lerp(a0, a1, i / n);
    const x = Math.cos(a) * r, y = Math.sin(a) * r * ys;
    pts.push([R(cx + x * cr - y * sr), R(cy + x * sr + y * cr)]);
  }
  return pts;
}

export function sector(
  g: Graphics, cx: number, cy: number, r0: number, r1: number, a0: number, a1: number,
  color: number, alpha = 1, ys = YS, rot = 0,
) {
  const n = clamp(Math.round(Math.abs(a1 - a0) * Math.max(r0, r1) / 4), 4, 90);
  const flat: number[] = [];
  const cr = Math.cos(rot), sr = Math.sin(rot);
  const add = (a: number, r: number) => {
    const x = Math.cos(a) * r, y = Math.sin(a) * r * ys;
    flat.push(R(cx + x * cr - y * sr), R(cy + x * sr + y * cr));
  };
  for (let i = 0; i <= n; i++) add(lerp(a0, a1, i / n), r1);
  for (let i = n; i >= 0; i--) add(lerp(a0, a1, i / n), r0);
  g.poly(flat).fill({ color: shadeRamp(color, 0.88), alpha });
}

/** Fantasy crescent slash wave with stepped outer aura, jagged edge teeth, and bright inner spine */
export function arcBlade(
  g: Graphics, cx: number, cy: number, r: number, a0: number, a1: number, thick: number,
  color: number, alpha = 1, ys = YS, rot = 0,
) {
  if (r < 2 || alpha <= 0.01) return;
  const n = clamp(Math.round(Math.abs(a1 - a0) * r / 3.5), 8, 72);
  const cr = Math.cos(rot), sr = Math.sin(rot);
  const build = (radScale: number, thScale: number, jag: number) => {
    const flat: number[] = [];
    const add = (a: number, rad: number) => {
      const x = Math.cos(a) * rad, y = Math.sin(a) * rad * ys;
      flat.push(R(cx + x * cr - y * sr), R(cy + x * sr + y * cr));
    };
    for (let i = 0; i <= n; i++) {
      const u = i / n;
      const tooth = jag > 0 ? Math.sin(u * Math.PI) * (i % 2 === 0 ? jag : -jag * 0.4) : 0;
      add(lerp(a0, a1, u), r * radScale + tooth);
    }
    for (let i = n; i >= 0; i--) {
      const u = i / n;
      add(lerp(a0, a1, u), r * radScale * (1 - thick * thScale * Math.sin(u * Math.PI)));
    }
    return flat;
  };
  g.poly(build(1.04, 1.18, 2.5)).fill({ color: shadeRamp(color, 0.4), alpha: alpha * 0.65 });
  g.poly(build(1.0, 0.9, 1.0)).fill({ color: shadeRamp(color, 0.88), alpha: alpha * 0.95 });
  g.poly(build(0.98, 0.38, 0)).fill({ color: hiRamp(color, 0.75), alpha });
}

export function poly(g: Graphics, pts: P[], color: number, alpha = 1) {
  if (pts.length < 3 || alpha <= 0.01) return;
  const f: number[] = [];
  for (const p of pts) f.push(R(p[0]), R(p[1]));
  g.poly(f).fill({ color, alpha });
}

export function star(g: Graphics, x: number, y: number, r: number, n: number, inner: number, rot: number, color: number, alpha = 1, ys = 1) {
  if (r <= 0.5 || alpha <= 0.01) return;
  const f: number[] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = rot + (i / (n * 2)) * TAU;
    const rad = i % 2 === 0 ? r : r * inner;
    f.push(R(x + Math.cos(a) * rad), R(y + Math.sin(a) * rad * ys));
  }
  g.poly(f).fill({ color, alpha });
}

export function ngon(g: Graphics, x: number, y: number, r: number, n: number, rot: number, color: number, alpha = 1, ys = 1) {
  if (r <= 0.5 || alpha <= 0.01) return;
  const f: number[] = [];
  for (let i = 0; i < n; i++) {
    const a = rot + (i / n) * TAU;
    f.push(R(x + Math.cos(a) * r), R(y + Math.sin(a) * r * ys));
  }
  g.poly(f).fill({ color, alpha });
}

export function diamond(g: Graphics, x: number, y: number, len: number, wid: number, rot: number, color: number, alpha = 1) {
  const c = Math.cos(rot), s = Math.sin(rot);
  const pts: P[] = [[len, 0], [0, wid], [-len, 0], [0, -wid]];
  g.poly(pts.flatMap(([a, b]) => [R(x + a * c - b * s), R(y + a * s + b * c)])).fill({ color, alpha });
}

export function shard(g: Graphics, x: number, y: number, len: number, wid: number, rot: number, color: number, alpha = 1) {
  const c = Math.cos(rot), s = Math.sin(rot);
  const pts: P[] = [[len, 0], [-len * 0.25, wid], [-len * 0.65, 0], [-len * 0.25, -wid]];
  g.poly(pts.flatMap(([a, b]) => [R(x + a * c - b * s), R(y + a * s + b * c)])).fill({ color, alpha });
  // Crisp specular facet edge
  if (len >= 4) {
    const p0: P = [R(x + len * c), R(y + len * s)];
    const p1: P = [R(x - len * 0.25 * c - wid * s), R(y - len * 0.25 * s + wid * c)];
    g.moveTo(p0[0], p0[1]).lineTo(p1[0], p1[1]).stroke({ width: 1, color: hiRamp(color, 0.7), alpha });
  }
}

export function rotRect(g: Graphics, x: number, y: number, w: number, h: number, rot: number, color: number, alpha = 1) {
  const c = Math.cos(rot), s = Math.sin(rot);
  const pts: P[] = [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]];
  g.poly(pts.flatMap(([a, b]) => [R(x + a * c - b * s), R(y + a * s + b * c)])).fill({ color, alpha });
}

/** Fantasy arcane rune glyph with outer diamond/circle frame and bright stroke */
export function glyph(g: Graphics, x: number, y: number, size: number, seed: number, color: number, alpha = 1, rot = 0, w = 1) {
  if (alpha <= 0.02) return;
  const c = Math.cos(rot), s = Math.sin(rot);
  const pt = (i: number): P => {
    const gx = (i % 3) - 1, gy = Math.floor(i / 3) - 1;
    const a = gx * size, b = gy * size;
    return [R(x + a * c - b * s), R(y + a * s + b * c)];
  };
  const rw = Math.max(1, R(w));
  const deep = shadeRamp(color, 0.4);
  const hi = hiRamp(color, 0.6);
  // Subtle rune frame
  if (size >= 3) diamond(g, x, y, size * 1.45, size * 1.45, rot + Math.PI / 4, deep, alpha * 0.45);
  const n = 3 + Math.floor(hash1(seed) * 3);
  for (let k = 0; k < n; k++) {
    const a = Math.floor(hash1(seed * 7.1 + k) * 9), b = Math.floor(hash1(seed * 3.3 + k * 5) * 9);
    if (a === b) continue;
    const A = pt(a), B = pt(b);
    g.moveTo(A[0], A[1]).lineTo(B[0], B[1]);
  }
  g.stroke({ width: rw, color: hi, alpha });
  px(g, x, y, Math.max(1, rw), 0xffffff, alpha * 0.9);
}

/** Heavy fantasy bone/iron chain with dark outline, metallic links, and glowing runic rivets */
export function chainLine(g: Graphics, pts: P[], linkLen: number, color: number, w = 1, hi = 0xffffff) {
  if (pts.length < 2) return;
  const step = Math.max(4, linkLen);
  let acc = 0, k = 0;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i];
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const l = Math.hypot(dx, dy);
    if (l < 1e-3) continue;
    const ux = dx / l, uy = dy / l;
    let d = step - acc;
    while (d <= l) {
      const x = R(a[0] + ux * d), y = R(a[1] + uy * d);
      const hl = step * 0.58;
      const nx = -uy * (w * 1.15 + 0.8), ny = ux * (w * 1.15 + 0.8);
      // Dark iron/obsidian under-shadow
      g.poly([
        R(x - ux * hl + nx), R(y - uy * hl + ny),
        R(x + ux * hl + nx), R(y + uy * hl + ny),
        R(x + ux * hl - nx), R(y + uy * hl - ny),
        R(x - ux * hl - nx), R(y - uy * hl - ny),
      ]).fill({ color: 0x120d1a, alpha: 0.9 });
      if (k % 2 === 0) {
        g.poly([
          R(x - ux * hl + nx * 0.8), R(y - uy * hl + ny * 0.8),
          R(x + ux * hl + nx * 0.8), R(y + uy * hl + ny * 0.8),
          R(x + ux * hl - nx * 0.8), R(y + uy * hl - ny * 0.8),
          R(x - ux * hl - nx * 0.8), R(y - uy * hl - ny * 0.8),
        ]).stroke({ width: 1, color: mix(color, hi, 0.25), alpha: 1 });
      } else {
        g.rect(x - 1, y - 1, 3, 3).fill({ color: hi, alpha: 0.95 });
      }
      k++;
      d += step;
    }
    acc = l - (d - step);
  }
}

export function ring3(cx: number, cy: number, r: number, tiltX: number, tiltZ: number, spin: number, n = 64): { p: P; z: number }[] {
  const out: { p: P; z: number }[] = [];
  const cxr = Math.cos(tiltX), sxr = Math.sin(tiltX), czr = Math.cos(tiltZ), szr = Math.sin(tiltZ);
  for (let i = 0; i <= n; i++) {
    const a = spin + (i / n) * TAU;
    const x = Math.cos(a) * r, y = Math.sin(a) * r;
    const y1 = y * cxr, z1 = y * sxr;
    const x2 = x * czr - y1 * szr, y2 = x * szr + y1 * czr;
    out.push({ p: [R(cx + x2), R(cy + y2 * 0.78 - z1 * 0.3)], z: z1 });
  }
  return out;
}
export const fade = (a: number) => clamp(a, 0, 1);
