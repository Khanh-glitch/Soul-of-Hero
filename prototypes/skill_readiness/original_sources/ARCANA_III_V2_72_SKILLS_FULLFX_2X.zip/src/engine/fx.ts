// Shared fantasy pixel-art effect constructs: craters, tapered fissures, arcane ring scars,
// stepped light pillars, diamond-tapered blade flashes, and dense pixel bursts.
import type { Graphics } from 'pixi.js';
import { Ctx } from './core';
import {
  diamond, disc, ditherDisc, glyph, gring, hiRamp, line, magicSeal, pixelBolt, poly, px, rotRect, shadeRamp, shard, star,
} from './draw';
import { P, TAU, YS, clamp, ease, hash1, lerp, mix, rand, rr } from './util';

const R = Math.round;

/** Stepped hue-shifted light pool */
export function halo(g: Graphics, x: number, y: number, r: number, col: number, a: number, ys = 1) {
  ditherDisc(g, x, y, r, col, a, ys, 5);
}

/**
 * Fantasy pixel-art pillar of light/flame:
 * - Glowing ground seal at the base
 * - 3-step hue-shifted vertical column (deep aura -> vivid body with rising pixel tongues -> white core)
 */
export function pillar(g: Graphics, x: number, y: number, h: number, w: number, col: number, a: number) {
  if (w <= 0.4 || h <= 2 || a <= 0.02) return;
  x = R(x); y = R(y); h = R(h);
  const deep = shadeRamp(col, 0.42);
  const mid = shadeRamp(col, 0.88);
  const hi = hiRamp(col, 0.78);
  // Base ground flare
  disc(g, x, y, w * 2.4, deep, a * 0.45, YS);
  disc(g, x, y, w * 1.4, mid, a * 0.75, YS);
  disc(g, x, y, w * 0.7, 0xffffff, a * 0.9, YS);

  // Outer aura shaft
  const wOut = Math.max(2, R(w * 1.35));
  const wMid = Math.max(1, R(w * 0.82));
  const wCore = Math.max(1, R(w * 0.36));
  g.poly([x - wOut, y, x - R(wOut * 0.55), y - h, x + R(wOut * 0.55), y - h, x + wOut, y]).fill({ color: deep, alpha: a * 0.48 });
  g.poly([x - wMid, y, x - R(wMid * 0.5), y - h, x + R(wMid * 0.5), y - h, x + wMid, y]).fill({ color: mid, alpha: a * 0.85 });
  g.rect(x - (wCore >> 1), y - h, wCore, h).fill({ color: hi, alpha: a });

  // Stepped pixel energy tongues climbing the edges
  const step = Math.max(6, R(h / 14));
  for (let py = 4; py < h - 4; py += step) {
    const u = py / h;
    const hw = lerp(wMid, wMid * 0.5, u);
    const side = ((py / step) & 1) ? 1 : -1;
    const tongueH = Math.min(10, step);
    g.rect(R(x + side * (hw + 1)), y - py - tongueH, Math.max(1, R(w * 0.22)), tongueH).fill({ color: mid, alpha: a * 0.75 * (1 - u * 0.5) });
  }
}

/**
 * Fantasy shattered crater & tapered magma/arcane fissures (replaces the old thin squiggly lines with white dots).
 */
export function crackScar(c: Ctx, x: number, y: number, n: number, len: number, life: number, col: number, ys = YS) {
  interface Branch { pts: P[]; w0: number }
  const branches: Branch[] = [];
  const stones: { x: number; y: number; w: number; h: number }[] = [];

  for (let i = 0; i < n; i++) {
    let a = (i / n) * TAU + rr(-0.22, 0.22);
    let px0 = x, py0 = y;
    const pts: P[] = [[R(px0), R(py0)]];
    const steps = 4 + Math.floor(rand() * 3);
    const totalLen = len * rr(0.65, 1.15);
    for (let k = 1; k <= steps; k++) {
      a += (k % 2 ? 1 : -1) * rr(0.14, 0.36);
      const l = (totalLen / steps) * rr(0.8, 1.2);
      px0 += Math.cos(a) * l;
      py0 += Math.sin(a) * l * ys;
      pts.push([R(px0), R(py0)]);
      // Short fork crack
      if (k === 2 && rand() < 0.65) {
        const fa = a + (rand() < 0.5 ? 0.65 : -0.65);
        const fl = totalLen * 0.34;
        branches.push({
          pts: [[R(px0), R(py0)], [R(px0 + Math.cos(fa) * fl * 0.55), R(py0 + Math.sin(fa) * fl * 0.55 * ys)], [R(px0 + Math.cos(fa + 0.2) * fl), R(py0 + Math.sin(fa + 0.2) * fl * ys)]],
          w0: 2.2,
        });
      }
    }
    branches.push({ pts, w0: rr(3.5, 5.2) });
    // Upturned stone rubble chunks near the crater rim
    const ra = (i / n) * TAU + rr(-0.3, 0.3), rd = totalLen * rr(0.25, 0.72);
    stones.push({
      x: R(x + Math.cos(ra) * rd),
      y: R(y + Math.sin(ra) * rd * ys),
      w: Math.round(rr(3, 5)),
      h: Math.round(rr(2, 3)),
    });
  }

  // Helper to build a tapered polygon for a crack branch (wide at root, 0.5px sharp at tip)
  const buildTaper = (pts: P[], w0: number, scale: number): number[] => {
    const L: number[] = [], Rt: number[] = [];
    const m = pts.length;
    for (let i = 0; i < m; i++) {
      const u = i / Math.max(1, m - 1);
      const hw = Math.max(0.4, w0 * scale * Math.pow(1 - u, 1.35) * 0.5);
      const pA = pts[Math.max(0, i - 1)], pB = pts[Math.min(m - 1, i + 1)];
      let dx = pB[0] - pA[0], dy = pB[1] - pA[1];
      const l = Math.hypot(dx, dy) || 1;
      dx /= l; dy /= l;
      L.push(R(pts[i][0] - dy * hw), R(pts[i][1] + dx * hw));
      Rt.push(R(pts[i][0] + dy * hw), R(pts[i][1] - dx * hw));
    }
    const flat: number[] = [];
    for (let i = 0; i < m; i++) flat.push(L[i * 2], L[i * 2 + 1]);
    for (let i = m - 1; i >= 0; i--) flat.push(Rt[i * 2], Rt[i * 2 + 1]);
    return flat;
  };

  const deepCol = shadeRamp(col, 0.45);
  const midCol = shadeRamp(col, 0.88);
  const hiCol = hiRamp(col, 0.65);

  c.scar(life, (g, a, age) => {
    const heat = clamp(1 - age / (life * 0.75), 0, 1);
    const pulse = 0.75 + 0.25 * Math.sin(age * 7 + x * 0.1);
    // Central scorched impact pit
    disc(g.mark, x, y, Math.min(22, len * 0.24), 0x0b0916, 0.65 * a, ys);
    if (heat > 0.05) {
      disc(g.glow, x, y, Math.min(14, len * 0.16), deepCol, 0.5 * a * heat, ys);
      disc(g.glow, x, y, Math.min(7, len * 0.08), hiCol, 0.7 * a * heat * pulse, ys);
    }
    for (const b of branches) {
      g.mark.poly(buildTaper(b.pts, b.w0 + 2, 1.0)).fill({ color: 0x0b0916, alpha: 0.72 * a });
      if (heat > 0.04) {
        g.glow.poly(buildTaper(b.pts, b.w0, 0.85)).fill({ color: mix(deepCol, midCol, heat), alpha: 0.78 * a * heat * pulse });
        if (b.w0 > 3 && heat > 0.25) {
          g.glow.poly(buildTaper(b.pts.slice(0, Math.max(2, b.pts.length - 1)), b.w0, 0.38)).fill({ color: hiCol, alpha: 0.85 * a * heat });
        }
      }
    }
    // Chipped stone blocks around the fissure (dark base + lit upper rim)
    for (const s of stones) {
      g.mark.rect(s.x, s.y, s.w, s.h).fill({ color: 0x0b0916, alpha: 0.8 * a });
      g.mark.rect(s.x, s.y - 1, s.w, 1).fill({ color: 0x35334a, alpha: 0.75 * a });
    }
  });
}

/**
 * Ornate arcane seal scar & broken stone ring (replaces the old beaded brown circle).
 */
export function ringScar(c: Ctx, x: number, y: number, r: number, life: number, col: number, w = 2, ys = YS, a0 = 0, a1 = TAU) {
  const deepCol = shadeRamp(col, 0.45);
  const midCol = shadeRamp(col, 0.88);
  const hiCol = hiRamp(col, 0.6);
  // Pre-generate 6 broken arc segments so the scar looks like a battle-damaged arcane glyph ring
  const segs: [number, number][] = [];
  const total = a1 - a0;
  const count = total >= TAU - 0.1 ? 8 : 3;
  for (let i = 0; i < count; i++) {
    const s0 = a0 + (i / count) * total + 0.04;
    const s1 = a0 + ((i + 0.78) / count) * total;
    segs.push([s0, s1]);
  }
  c.scar(life, (g, a, age) => {
    const heat = clamp(1 - age / (life * 0.8), 0, 1);
    const fl = 0.72 + 0.28 * Math.sin(age * 6 + r);
    for (let i = 0; i < segs.length; i++) {
      const [s0, s1] = segs[i];
      gring(g.mark, x, y, r, 0x0b0916, w + 2, 0.55 * a, s0, s1, ys);
      if (heat > 0.04) {
        gring(g.glow, x, y, r, mix(deepCol, midCol, heat), Math.max(1, w), 0.65 * a * heat * fl, s0, s1, ys);
      }
      // Cardinal rune nodes on the ring
      if (total >= TAU - 0.1 && i % 2 === 0 && heat > 0.1) {
        const rx = R(x + Math.cos(s0) * r), ry = R(y + Math.sin(s0) * r * ys);
        diamond(g.glow, rx, ry, 3, 2, s0, hiCol, 0.7 * a * heat);
      }
    }
  });
}

export function debris(c: Ctx, x: number, y: number, n: number, cols: number[], spd = 90, z = 4) {
  c.burst('deb', x, y, n, { spd: [spd * 0.2, spd], vz: [90, 280], gz: 400, life: [1.1, 2.4], size: [2, 4], cols, bounce: 0.42, drag: 0.6, z, ys: YS, tex: 'chunk' });
  c.burst('low', x, y, n * 0.5, { spd: [spd * 0.15, spd * 0.55], vz: [10, 65], gz: 60, life: [0.6, 1.5], size: [3, 7], cols: [0x58526e, 0x36324a], bounce: 0, drag: 2.4, z, ys: YS, tex: 'smoke', alpha: 0.45 });
}

/** Diamond-tapered cross slash flash (replaces uniform perpendicular sticks) */
export function slashX(c: Ctx, x: number, y: number, col: number, len = 22, life = 0.3, rot = 0.6) {
  const deep = shadeRamp(col, 0.45);
  const mid = shadeRamp(col, 0.9);
  const hi = hiRamp(col, 0.8);
  c.ent(life, (_a, u) => {
    const l = len * (0.35 + 0.85 * ease.outExpo(u));
    const f = 1 - u;
    const w = Math.max(1.2, 4.5 * f);
    for (const r of [rot, rot + Math.PI / 2]) {
      diamond(c.L.add, x, y, l * 1.1, w * 1.45, r, deep, 0.6 * f);
      diamond(c.L.add, x, y, l, w * 0.9, r, mid, 0.95 * f);
      diamond(c.L.add, x, y, l * 0.82, Math.max(1, w * 0.4), r, hi, f);
    }
    disc(c.L.add, x, y, 4 * f + 1, 0xffffff, f);
  });
}

/** Diamond-tapered directional blade flash with crescent shock and sparks */
export function slashLine(c: Ctx, x: number, y: number, ang: number, len: number, col: number, life = 0.25) {
  const deep = shadeRamp(col, 0.45);
  const mid = shadeRamp(col, 0.9);
  const hi = hiRamp(col, 0.8);
  c.ent(life, (_a, u) => {
    const l = len * ease.outExpo(u);
    const f = 1 - u;
    const cx = x + Math.cos(ang) * l * 0.25, cy = y + Math.sin(ang) * l * 0.25;
    const w = Math.max(1.2, 5.2 * f);
    diamond(c.L.add, cx, cy, l * 0.85, w * 1.4, ang, deep, 0.65 * f);
    diamond(c.L.add, cx, cy, l * 0.78, w * 0.85, ang, mid, 0.95 * f);
    diamond(c.L.add, cx, cy, l * 0.65, Math.max(1, w * 0.38), ang, hi, f);
    for (let i = 0; i < 3; i++) {
      const k = (i - 1) * 0.5;
      const px2 = cx + Math.cos(ang) * l * k, py2 = cy + Math.sin(ang) * l * k;
      c.emit('add', { tex: 'spark', x: px2, y: py2, vx: Math.cos(ang) * rr(30, 110) + rr(-25, 25), vy: Math.sin(ang) * rr(30, 110) + rr(-25, 25), life: rr(0.14, 0.32), size: 4, c0: 0xffffff, c1: mid, drag: 4 });
    }
  });
}

/** Fractured shockwave ring built from crescent blade arcs and shards */
export function fracRing(g: Graphics, x: number, y: number, r: number, col: number, a: number, seed: number, w = 3, ys = YS, pieces = 9) {
  if (r < 2 || a <= 0.02) return;
  const hi = hiRamp(col, 0.7);
  for (let i = 0; i < pieces; i++) {
    const h = hash1(seed * 12.9 + i * 78.2);
    const a0 = (i / pieces) * TAU + h * 0.18;
    const span = (TAU / pieces) * (0.48 + h * 0.32);
    const rr2 = r + (h - 0.5) * 7;
    gring(g, x, y, rr2, col, w, a, a0, a0 + span, ys);
    gring(g, x, y, rr2, hi, Math.max(1, w - 2), a * 0.9, a0 + 0.04, a0 + span - 0.04, ys);
    const midA = a0 + span * 0.5;
    shard(g, x + Math.cos(midA) * (rr2 + 3), y + Math.sin(midA) * (rr2 + 3) * ys, 4, 1.5, midA, hi, a * 0.85);
  }
}

export function sparkle(g: Graphics, x: number, y: number, r: number, col: number, a = 1, rot = 0) {
  if (r <= 0.4 || a <= 0.02) return;
  if (r >= 4.5) {
    const sc = (r * 2.2) / 64;
    const pool = (g as any).__pool;
    if (pool) {
      pool.put('star_flare', x, y, { sx: sc, sy: sc, rot, tint: hiRamp(col, 0.45), alpha: a, add: true });
      return;
    }
  }
  star(g, x, y, r * 1.15, 4, 0.22, rot, shadeRamp(col, 0.75), a * 0.75);
  star(g, x, y, r, 4, 0.16, rot, hiRamp(col, 0.55), a);
  px(g, x, y, Math.max(1, r * 0.35), 0xffffff, a);
}

export function groundLight(c: Ctx, x: number, y: number, r: number, col: number, a: number) {
  halo(c.L.glow, x, y, r, col, a, YS);
}
export function flatPoly(g: Graphics, pts: P[], col: number, a = 1) {
  poly(g, pts, col, a);
}

export function pxBurst(c: Ctx, x: number, y: number, power: number, cols: number[], o: { ys?: number; z?: number; smoke?: number } = {}) {
  const ys = o.ys ?? 1, z = o.z ?? 0;
  const n = Math.round(clamp(power * 0.55, 10, 56));
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + rr(-0.05, 0.05), s = power * rr(1.3, 3.2);
    const col = cols[i % cols.length];
    c.emit('add', { tex: i % 4 === 0 ? 'streak' : 'spark', x, y, z, vx: Math.cos(a) * s, vy: Math.sin(a) * s * ys, vz: o.ys ? rr(0, 40) : 0, gz: o.ys ? 120 : 0, life: rr(0.2, 0.58), size: i % 4 === 0 ? 6 : 5, c0: 0xffffff, c1: shadeRamp(col, 0.88), drag: 3.4, streak: i % 4 === 0 ? 0.03 : 0 });
  }
  c.burst('add', x, y, Math.round(power * 0.45), { spd: [power * 0.6, power * 2.8], life: [0.28, 0.85], cols, size: [1, 2], drag: 2.2, ys, z, tex: 'dot', alpha: 0.95 });
  if (o.smoke !== 0) c.burst('low', x, y + (o.ys ? 2 : 0), Math.round(power * 0.2), { spd: [power * 0.2, power * 0.9], life: [0.45, 1.2], cols: [0x58526e, 0x38334c, 0x242036], size: [3, 7], drag: 2.6, ys: o.ys ?? YS, z, tex: 'smoke', alpha: 0.45 });
  c.sprite('add', 'glowL', x, y - z, power * 2.4, 0.22, cols[0], { size1: power * 0.6, c1: 0xffffff });
}

export function pxJet(c: Ctx, x: number, y: number, ang: number, spread: number, power: number, col: number, n = 6, tex: 'spark' | 'flame' | 'dot' = 'spark') {
  for (let i = 0; i < n; i++) {
    const a = ang + rr(-spread, spread), s = power * rr(0.5, 1.3);
    c.emit('add', { tex, x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rr(0.25, 0.68), size: tex === 'flame' ? rr(5, 9) : rr(3, 6), c0: 0xffffff, c1: shadeRamp(col, 0.88), drag: 2.4, streak: tex === 'spark' ? 0.02 : 0 });
  }
}

export function pxDust(c: Ctx, x: number, y: number, n: number, ang: number, power: number) {
  for (let i = 0; i < n; i++) {
    const a = ang + rr(-0.9, 0.9), s = power * rr(0.3, 1);
    c.emit('low', { tex: 'smoke', x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.5, vz: rr(4, 30), gz: 40, life: rr(0.45, 1.2), size: rr(3, 6), size1: rr(8, 14), c0: 0x625c78, c1: 0x262238, drag: 2.2, alpha: 0.48 });
  }
}

export function pxRing(c: Ctx, x: number, y: number, r0: number, r1: number, life: number, col: number, o: { ys?: number; n?: number; size?: number; col2?: number } = {}) {
  const ys = o.ys ?? YS, n = o.n ?? 36, size = o.size ?? 3;
  c.ent(life, (_a, u) => {
    const r = lerp(r0, r1, ease.outExpo(u)), f = 1 - u;
    gring(c.L.add, x, y, r, col, 2, f * 0.85, 0, TAU, ys);
    for (let i = 0; i < n; i += 2) {
      const a = (i / n) * TAU + u * 0.6;
      const px2 = x + Math.cos(a) * r, py = y + Math.sin(a) * r * ys;
      const s = size * (0.5 + f);
      c.sprite('add', i % 4 === 0 ? 'dot' : 'spark', px2, py, s * 1.3, 0.1, i % 4 === 0 ? 0xffffff : o.col2 ?? col);
    }
  });
}

export function pxColumn(c: Ctx, x: number, y: number, h: number, life: number, col: number, w = 8) {
  c.ent(life, (age, u) => {
    const g = ease.outExpo(Math.min(1, age * 4)), f = 1 - sstep(0.5, 1, u);
    pillar(c.L.add, x, y, h * g, w * f + 2, col, f);
    for (let i = 0; i < 5; i++) c.emit('add', { tex: i % 2 ? 'flame' : 'spark', x: x + rr(-w, w) * 0.6, y: y - rr(0, h * g), vx: rr(-14, 14), vy: rr(-90, -20), life: rr(0.28, 0.8), size: rr(4, 8), c0: 0xffffff, c1: shadeRamp(col, 0.88), drag: 1.6 });
  });
}
function sstep(a: number, b: number, x: number) { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); }
export { rotRect, magicSeal, pixelBolt, shadeRamp, hiRamp };
