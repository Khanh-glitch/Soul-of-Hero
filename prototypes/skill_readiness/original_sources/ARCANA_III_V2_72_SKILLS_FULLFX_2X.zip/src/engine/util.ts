// Math, colour, easing, deterministic RNG and curve helpers shared by all VFX systems.
export const W = 480;
export const H = 270;
export const CX = 240;
export const CY = 150;
/** vertical squash used for ground-plane circles (top-down 3/4 view) */
export const YS = 0.7;
export const TAU = Math.PI * 2;
export type P = [number, number];

export const clamp = (v: number, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const sstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
/** normalised progress of t within [a,b] */
export const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const dist = (a: number, b: number, c: number, d: number) => Math.hypot(c - a, d - b);
export const lerpP = (a: P, b: P, t: number): P => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];

export const ease = {
  lin: (t: number) => t,
  in: (t: number) => t * t,
  in3: (t: number) => t * t * t,
  out: (t: number) => 1 - (1 - t) * (1 - t),
  out3: (t: number) => 1 - Math.pow(1 - t, 3),
  io: (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
  io3: (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  outExpo: (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
  inExpo: (t: number) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10)),
  outBack: (t: number) => 1 + 2.70158 * Math.pow(t - 1, 3) + 1.70158 * Math.pow(t - 1, 2),
  sin: (t: number) => Math.sin(t * Math.PI),
};

// ---------- deterministic RNG (re-seeded per playback so replays are identical) ----------
let seed = 1;
export function reseed(s = 1) {
  seed = s >>> 0 || 1;
}
export function rand(): number {
  seed = (seed + 0x6d2b79f5) >>> 0;
  let t = seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
export const rr = (a: number, b: number) => a + (b - a) * rand();
export const ri = (a: number, b: number) => Math.floor(rr(a, b + 1));
export const pick = <T,>(arr: T[]): T => arr[Math.floor(rand() * arr.length)];
export const sign = () => (rand() < 0.5 ? -1 : 1);
export function hash1(n: number) {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}
export function hash2(x: number, y: number) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
export function vnoise(x: number, y: number) {
  const xi = Math.floor(x),
    yi = Math.floor(y);
  const xf = x - xi,
    yf = y - yi;
  const u = xf * xf * (3 - 2 * xf),
    v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(hash2(xi, yi), hash2(xi + 1, yi), u), lerp(hash2(xi, yi + 1), hash2(xi + 1, yi + 1), u), v);
}
export function fbm(x: number, y: number) {
  return vnoise(x, y) * 0.55 + vnoise(x * 2.1 + 5.2, y * 2.1 + 1.3) * 0.3 + vnoise(x * 4.3 + 9, y * 4.3 + 3) * 0.15;
}
/** curl-ish flow vector from noise */
export function flow(x: number, y: number, t: number): P {
  const a = fbm(x * 0.012 + t * 0.1, y * 0.012) * TAU * 2;
  return [Math.cos(a), Math.sin(a)];
}

// ---------- colour ----------
export const rgb = (c: number): [number, number, number] => [(c >> 16) & 255, (c >> 8) & 255, c & 255];
export const pack = (r: number, g: number, b: number) =>
  ((clamp(r, 0, 255) | 0) << 16) | ((clamp(g, 0, 255) | 0) << 8) | (clamp(b, 0, 255) | 0);
export function mix(a: number, b: number, t: number) {
  t = clamp(t);
  const A = rgb(a),
    B = rgb(b);
  return pack(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t);
}
export function shade(c: number, k: number) {
  const A = rgb(c);
  return pack(A[0] * k, A[1] * k, A[2] * k);
}
/** multi-stop colour ramp, t in 0..1 */
export function ramp(cols: number[], t: number) {
  t = clamp(t) * (cols.length - 1);
  const i = Math.min(cols.length - 2, Math.floor(t));
  return mix(cols[i], cols[i + 1], t - i);
}
export function hsl(h: number, s: number, l: number) {
  h = ((h % 1) + 1) % 1;
  const f = (n: number) => {
    const k = (n + h * 12) % 12;
    const a = s * Math.min(l, 1 - l);
    return l - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1)));
  };
  return pack(f(0) * 255, f(8) * 255, f(4) * 255);
}
export const SPECTRUM = [0xff3a4a, 0xff9a2a, 0xffe24a, 0x4ae86a, 0x3ad8ff, 0x4a6aff, 0xb04aff];

// ---------- curves ----------
export function bez(p0: P, p1: P, p2: P, p3: P, t: number): P {
  const u = 1 - t;
  const a = u * u * u,
    b = 3 * u * u * t,
    c = 3 * u * t * t,
    d = t * t * t;
  return [a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]];
}
export function bez2(p0: P, p1: P, p2: P, t: number): P {
  const u = 1 - t;
  return [u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]];
}
/** Catmull-Rom through points; u in 0..1 */
export function spline(pts: P[], u: number): P {
  const n = pts.length - 1;
  const f = clamp(u) * n;
  const i = Math.min(n - 1, Math.floor(f));
  const t = f - i;
  const p0 = pts[Math.max(0, i - 1)],
    p1 = pts[i],
    p2 = pts[i + 1],
    p3 = pts[Math.min(n, i + 2)];
  const t2 = t * t,
    t3 = t2 * t;
  const k = (a: number, b: number, c: number, d: number) =>
    0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
  return [k(p0[0], p1[0], p2[0], p3[0]), k(p0[1], p1[1], p2[1], p3[1])];
}
export function sample(fn: (u: number) => P, n: number, a = 0, b = 1): P[] {
  const out: P[] = [];
  for (let i = 0; i <= n; i++) out.push(fn(lerp(a, b, i / n)));
  return out;
}
export function polyLen(pts: P[]) {
  let l = 0;
  for (let i = 1; i < pts.length; i++) l += dist(pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1]);
  return l;
}
/** point + tangent at fraction u along a polyline */
export function along(pts: P[], u: number): { p: P; a: number } {
  const n = pts.length - 1;
  const f = clamp(u) * n;
  const i = Math.min(n - 1, Math.floor(f));
  const t = f - i;
  const a = pts[i],
    b = pts[i + 1];
  return { p: [lerp(a[0], b[0], t), lerp(a[1], b[1], t)], a: Math.atan2(b[1] - a[1], b[0] - a[0]) };
}
export function segIntersect(a: P, b: P, c: P, d: P): P | null {
  const r: P = [b[0] - a[0], b[1] - a[1]],
    s: P = [d[0] - c[0], d[1] - c[1]];
  const den = r[0] * s[1] - r[1] * s[0];
  if (Math.abs(den) < 1e-6) return null;
  const t = ((c[0] - a[0]) * s[1] - (c[1] - a[1]) * s[0]) / den;
  const u = ((c[0] - a[0]) * r[1] - (c[1] - a[1]) * r[0]) / den;
  if (t < 0 || t > 1 || u < 0 || u > 1) return null;
  return [a[0] + t * r[0], a[1] + t * r[1]];
}
