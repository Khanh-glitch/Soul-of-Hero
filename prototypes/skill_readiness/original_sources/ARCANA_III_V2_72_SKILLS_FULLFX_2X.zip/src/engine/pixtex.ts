// Procedural pixel-art sprite textures: every particle is a hand-quantised bitmap, not a vector shape.
// All textures are white + alpha so runtime tint drives the palette.
import { Texture } from 'pixi.js';

const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
export const bay = (x: number, y: number) => BAYER[((y & 3) << 2) | (x & 3)] / 16;
/** ordered-dither quantisation to `lv` alpha levels */
export const dq = (a: number, x: number, y: number, lv = 4) => {
  if (a <= 0) return 0;
  if (a >= 1) return 1;
  return Math.min(lv, Math.floor(a * lv + bay(x, y) * 0.999)) / lv;
};

function makeWH(w: number, h: number, fn: (x: number, y: number, s: number) => number): Texture {
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const g = cv.getContext('2d')!;
  const img = g.createImageData(w, h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const a = Math.max(0, Math.min(1, fn(x, y, w)));
      const i = (y * w + x) * 4;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
      img.data[i + 3] = Math.round(a * 255);
    }
  g.putImageData(img, 0, 0);
  const t = Texture.from(cv);
  t.source.scaleMode = 'nearest';
  return t;
}
function make(size: number, fn: (x: number, y: number, s: number) => number): Texture { return makeWH(size, size, fn); }
const rad = (x: number, y: number, s: number) => {
  const h = (s - 1) / 2;
  return Math.hypot(x - h, y - h) / (h + 0.5);
};

export type TexKey = 'dot' | 'spark' | 'star' | 'glow' | 'glowL' | 'smoke' | 'chunk' | 'shard' | 'streak' | 'flame' | 'bone' | 'wing' | 'ring' | 'eye';

export const TEXS: Record<TexKey, Texture> = {
  dot: make(1, () => 1),
  spark: make(5, (x, y) => {
    const d = Math.max(Math.abs(x - 2), Math.abs(y - 2));
    return d === 0 ? 1 : d === 1 ? (x === 2 || y === 2 ? 0.95 : 0.45) : x === 2 || y === 2 ? 0.4 : 0;
  }),
  star: make(11, (x, y) => {
    const h = 5, dx = Math.abs(x - h), dy = Math.abs(y - h);
    const arm = Math.max(0, 1 - (dx + dy * 3.2) / 5.5) * (dy < 2 ? 1 : 0) + Math.max(0, 1 - (dy + dx * 3.2) / 5.5) * (dx < 2 ? 1 : 0);
    const core = Math.max(0, 1 - Math.hypot(dx, dy) / 2.6);
    const a = Math.max(arm * 0.85, core);
    return dq(a, x, y, 5);
  }),
  glow: make(17, (x, y) => {
    const r = rad(x, y, 17);
    const a = Math.max(0, 1 - r);
    return dq(a * a * 0.95, x, y, 4);
  }),
  glowL: make(33, (x, y) => {
    const r = rad(x, y, 33);
    const a = Math.max(0, 1 - r);
    return dq(Math.pow(a, 1.7) * 0.9, x, y, 4);
  }),
  smoke: make(13, (x, y) => {
    const r = rad(x, y, 13);
    const n = (Math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1;
    const a = Math.max(0, 1 - r * 1.15) * (0.45 + Math.abs(n) * 0.6);
    return dq(a, x, y, 3);
  }),
  chunk: make(5, (x, y) => {
    const m = [
      '.###.',
      '#####',
      '#####',
      '.###.',
      '..#..',
    ];
    return m[y][x] === '#' ? 1 : 0;
  }),
  shard: make(7, (x, y) => {
    const top = Math.floor((x / 6) * 3);
    return y >= top && y <= top + 1 && x > 0 && x < 6 ? (y === top ? 1 : 0.6) : 0;
  }),
  streak: make(13, (x, y) => {
    const a = Math.pow(x / 12, 0.7) * (y === 1 ? 1 : y === 0 || y === 2 ? 0.35 : 0);
    return dq(a, x, y, 4);
  }),
  flame: make(7, (x, y) => {
    const h = 3;
    const w = Math.max(0, 1 - Math.abs(y - 5) / 4) * (1 - Math.abs(x - h) / (3.2 - y * 0.18));
    return dq(Math.max(0, w), x, y, 4);
  }),
  bone: makeWH(7, 5, (x, y) => {
    const m = [
      '#.....#',
      '##...##',
      '.#####.',
      '##...##',
      '#.....#',
    ];
    return m[y][x] === '#' ? 1 : 0;
  }),
  wing: makeWH(5, 4, (x, y) => {
    const m = [
      '.#.#.',
      '#####',
      '.###.',
      '..#..',
    ];
    return m[y][x] === '#' ? 1 : 0;
  }),
  ring: make(9, (x, y) => {
    const r = rad(x, y, 9) * 2;
    const a = Math.max(0, 1 - Math.abs(r - 1.35) * 2.4);
    return dq(a, x, y, 3);
  }),
  eye: make(5, (x, y) => {
    const r = rad(x, y, 5);
    return r < 0.5 ? 1 : dq(Math.max(0, 1 - (r - 0.5) * 2.2), x, y, 3);
  }),
};
export const TEX = (k: TexKey) => TEXS[k] ?? TEXS.dot;
