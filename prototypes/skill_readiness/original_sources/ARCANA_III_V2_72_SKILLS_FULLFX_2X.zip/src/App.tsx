import { useEffect, useRef, useState } from 'react';
import { Lab } from './engine/core';
import { RELICS, SKILLS, REMIX_COUNTS } from './skills';

interface Info { id: number; t: number; dur: number; playing: boolean; ended: boolean; showcase: boolean; speed: number; phase: string; qual: number; zoom: number; particles: number }

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const labRef = useRef<Lab | null>(null);
  const [info, setInfo] = useState<Info>({ id: 0, t: 0, dur: 1, playing: false, ended: false, showcase: false, speed: 1, phase: '', qual: 1, zoom: 0.5, particles: 0 });
  const [filter, setFilter] = useState<'all' | 'original' | 'minor' | 'major' | 'fusion'>('all');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let dead = false;
    const lab = new Lab();
    lab.skills = SKILLS;
    lab.init(host.current!).then(() => {
      if (dead) { lab.destroy(); return; }
      labRef.current = lab;
      (window as any).__lab = lab;
      const hashId = parseInt(location.hash.replace('#', ''));
      lab.load(SKILLS.find((s) => s.id === hashId) ?? SKILLS[0], !location.search.includes('paused'));
      setReady(true);
    });
    const iv = setInterval(() => {
      const l = labRef.current;
      if (!l || !l.skill) return;
      let phase = '';
      for (const [pt, name] of l.skill.phases) if (l.displayTime >= pt) phase = name;
      setInfo({ id: l.skill.id, t: l.displayTime, dur: l.skill.dur, playing: l.playing, ended: l.ended, showcase: l.showcase, speed: l.speed, phase, qual: l.qual, zoom: l.cameraZoom, particles: l.liveParticles });
    }, 80);
    const key = (e: KeyboardEvent) => {
      const l = labRef.current;
      if (!l) return;
      if (e.code === 'Space') { e.preventDefault(); l.toggle(); }
      if (e.code === 'KeyR') l.restart();
      if (e.code === 'KeyZ') l.setCameraZoom(l.cameraZoom === 0.5 ? 1 : 0.5);
      if (e.code === 'ArrowRight') l.next(1);
      if (e.code === 'ArrowLeft') l.next(-1);
    };
    window.addEventListener('keydown', key);
    return () => { dead = true; clearInterval(iv); window.removeEventListener('keydown', key); labRef.current?.destroy(); };
  }, []);

  const lab = () => labRef.current!;
  const cur = SKILLS.find((s) => s.id === info.id);
  const relic = RELICS.find((r) => r.id === cur?.relic);
  const btn = 'px-3 py-1.5 text-xs tracking-widest uppercase border border-white/15 bg-white/5 hover:bg-white/15 transition rounded-sm';
  const kinds = [
    ['all', 'All 72', REMIX_COUNTS.total], ['original', '20 Original Ultimates', REMIX_COUNTS.original],
    ['minor', '20 Standalone / Small', REMIX_COUNTS.minor], ['major', '20 Standalone / Grand', REMIX_COUNTS.major],
    ['fusion', '12 Fusion Skills (301 preserved)', REMIX_COUNTS.fusion],
  ] as const;
  const visible = SKILLS.filter(s => filter === 'all' || (s.kind ?? 'original') === filter);

  return (
    <div className="min-h-screen bg-[#07060b] text-slate-200 flex flex-col items-center select-none" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>
      <header className="w-full max-w-[1280px] px-4 pt-3 pb-2 flex items-baseline justify-between">
        <h1 className="text-sm tracking-[0.4em] text-amber-200/90">ARCANA <span className="text-white/40">// 20 ORIGINAL · 40 NEW STANDALONE · 12 FUSIONS · V2</span></h1>
        <span className="text-[10px] text-white/35 hidden sm:block">SPACE play/pause · R replay · Z zoom · ←/→ skill</span>
      </header>

      <div className="w-full max-w-[1280px] px-4">
        <div className="relative w-full overflow-hidden border border-white/10 bg-black" style={{ aspectRatio: '16 / 9' }}>
          <div ref={host} className="absolute inset-0 [&>canvas]:w-full [&>canvas]:h-full [&>canvas]:block" style={{ imageRendering: 'pixelated' }} />
          <style>{`canvas{image-rendering:pixelated;image-rendering:crisp-edges}`}</style>
          {!ready && <div className="absolute inset-0 grid place-items-center text-xs tracking-widest text-white/50">igniting renderer…</div>}
          {cur && (
            <div className="absolute left-3 top-2 pointer-events-none">
              <div className="text-[10px] tracking-[0.3em]" style={{ color: relic?.color }}>{relic?.name.toUpperCase()} · {(cur.kind ?? 'original').toUpperCase()} · {String(cur.id).padStart(3, '0')}</div>
              <div className="text-lg sm:text-2xl font-bold text-white drop-shadow-[0_2px_0_rgba(0,0,0,0.9)]">{cur.name}</div>
              <div className="text-[10px] sm:text-xs text-white/60 max-w-md">{cur.sub}</div>
            </div>
          )}
          <div className="absolute right-3 bottom-2 text-[10px] sm:text-xs tracking-widest text-white/70 pointer-events-none text-right drop-shadow-[0_1px_0_rgba(0,0,0,0.9)]">
            {info.showcase && <div className="text-amber-200">AUTO SHOWCASE</div>}
            {info.phase.toUpperCase()}<div>CAMERA {info.zoom === 0.5 ? '2× FAR' : 'ORIGINAL'} · FX FULL · {info.particles.toLocaleString()} PARTICLES</div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 py-2">
          <button className={btn} onClick={() => lab().next(-1)}>◀</button>
          <button className={btn} onClick={() => lab().toggle()}>{info.ended ? '↻ Replay' : info.playing ? '❚❚ Pause' : '▶ Play'}</button>
          <button className={btn} onClick={() => lab().restart()}>↻ Restart</button>
          <button className={btn} onClick={() => lab().next(1)}>▶</button>
          {[0.25, 0.5, 1].map((s) => (
            <button key={s} className={btn + (info.speed === s ? ' !bg-amber-300/25 !border-amber-200/60' : '')} onClick={() => { lab().speed = s; }}>{s}×</button>
          ))}
          <button
            className={btn + (info.zoom === 0.5 ? ' !bg-cyan-300/20 !border-cyan-200/60' : '')}
            title="Camera only: 2× farther, unchanged world VFX simulation and full density"
            onClick={() => lab().setCameraZoom(info.zoom === 0.5 ? 1 : 0.5)}
          >
            Camera {info.zoom === 0.5 ? '2× FAR' : '1× ORIGINAL'}
          </button>
          <span className="text-[10px] text-emerald-200/70" title="No quality-reduction control in this lab">FX 100% LOCKED</span>
          <button
            className={btn + (info.showcase ? ' !bg-amber-300/25 !border-amber-200/60' : '')}
            onClick={() => { const l = lab(); l.showcase = !l.showcase; if (l.showcase) { l.load(SKILLS[0], true); } }}
          >
            {info.showcase ? '■ Stop showcase' : '✦ Auto showcase (all 72 entries)'}
          </button>
          <input
            type="range" min={0} max={1000} value={Math.round((info.t / info.dur) * 1000)}
            onChange={(e) => { const l = lab(); l.playing = false; l.seek((+e.target.value / 1000) * info.dur); }}
            className="flex-1 min-w-[160px] accent-amber-300"
          />
          <span className="text-[11px] text-white/50 w-24 text-right">{info.t.toFixed(1)} / {info.dur.toFixed(1)}s</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 pt-2 pb-3">
          {kinds.map(([kind, label, count]) => (
            <button key={kind} className={btn + (filter === kind ? ' !bg-amber-300/25 !border-amber-200/60' : '')}
              onClick={() => setFilter(kind)}>{label} <span className="opacity-40">({count})</span></button>
          ))}
          <span className="ml-auto text-[10px] text-white/35">Showcase always plays ALL 72, regardless of filter.</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2 pb-6">
          {RELICS.map((r) => (
            <div key={r.id} className="border border-white/10 bg-white/[0.03] p-2">
              <div className="text-[11px] font-bold tracking-widest" style={{ color: r.color }}>{r.name.toUpperCase()}</div>
              <div className="text-[9px] text-white/40 mb-1.5 leading-3">{r.tag}</div>
              {visible.filter((s) => s.relic === r.id).map((s) => (
                <button
                  key={s.id}
                  onClick={() => { const l = lab(); l.showcase = false; l.load(s, true); }}
                  className={'block w-full text-left text-[11px] px-2 py-1 mb-1 border transition ' + (info.id === s.id ? 'bg-white/15 border-white/40 text-white' : 'border-transparent hover:bg-white/10 text-white/70')}
                >
                  <span className="text-white/35 mr-1.5">{String(s.id).padStart(3, '0')}</span>{s.name}
                  {filter === 'all' && <span className="text-[9px] text-white/35 ml-1">· {s.kind ?? 'original'}</span>}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
