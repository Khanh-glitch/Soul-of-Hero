// ECLIPSE HALO — Floating celestial blades, orbital mechanics, eclipses, and the destruction of light.
// Remade with true fantasy pixel-art constructs: stepped hue-shifted solar coronas, ornate astrolabe seals,
// tapered crescent blade-waves, and shattered magma craters (zero Spirograph black-brown hoses).
import { Ctx, Skill } from '../engine/core';
import {
  CX, H, P, TAU, W, YS, bez, clamp, dist, ease, lerp, mix, prog, rand, ramp, rr, sample, segIntersect, sstep, vnoise,
} from '../engine/util';
import {
  arcBlade, diamond, disc, glyph, gring, hiRamp, line, magicSeal, ngon, pixelBolt, poly, ribbon, rotRect, sector, shadeRamp, shard, star,
} from '../engine/draw';
import { crackScar, debris, fracRing, halo, pillar, ringScar, slashLine, slashX, sparkle } from '../engine/fx';
import { stampOn } from '../engine/sprites';

const GOLD = 0xffd84a, ORG = 0xff5a1f, CRIM = 0xa81448, BLUE = 0x4ad8ff, VIO = 0x9b5aff, WH = 0xffffff, RED = 0xff385c;
const wrapPi = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));

// ============================================================ 01 BLACK SUN CORONATION
function s01(c: Ctx) {
  const G: P = [CX, 174], SC: P = [CX, 102];
  const base = [0, 1, 2, 3, 4, 5].map((i) => (i / 6) * TAU + 0.4);
  c.layout(base.map((a) => [G[0] + Math.cos(a) * 100, G[1] + Math.sin(a) * 100 * YS]));
  c.seg(0, 0.9, (u) => [lerp(36, G[0], u), lerp(222, G[1], u) - Math.sin(u * Math.PI) * 10], ease.outExpo);
  c.seg(4.55, 5.0, (u) => [G[0], G[1], 136 * u], ease.out);
  c.seg(5.0, 6.0, (u) => [lerp(G[0], G[0] + 42, u), G[1] + 8, 136 * (1 - u * u)], ease.lin);
  c.caster.trail = GOLD;

  const rot = [0, 0, 0, 0, 0];
  const shards = Array.from({ length: 28 }, () => ({
    a: rr(0, TAU), r: rr(0, 28), sa: rr(0, TAU), ta: rr(1.4, 3.7), sz: rr(5, 10), rt: rr(0, TAU),
  }));

  // 6 staggered solar crescent blades tearing outward — with short tapered comet wakes (NOT persistent black hoses!)
  const blades = Array.from({ length: 6 }, (_, j) => {
    const dir = j % 2 ? -1 : 1, a0 = (j / 6) * TAU + 0.3, t0 = 5.0 + j * 0.12;
    const path = (u: number): P => {
      const r = 10 + 270 * ease.out(u), a = a0 + dir * 1.35 * u;
      return [G[0] + Math.cos(a) * r, G[1] + Math.sin(a) * r * YS];
    };
    return { dir, a0, t0, life: 1.45, hit: new Set<number>(), path };
  });

  c.each((t, dt) => {
    const L = c.L;
    const m = ease.io(prog(t, 2.3, 3.8));
    const collapse = ease.in3(prog(t, 4.55, 4.92));
    const eclipse = ease.io(prog(t, 1.2, 4.2));
    const afterK = t > 5 ? 1 - prog(t, 5.2, 9.4) : 1;

    c.darken(t < 4.95 ? 0.88 * eclipse : 0.55 * (1 - prog(t, 5.0, 8.8)));
    c.silhouette(t < 5.0 ? eclipse : 1 - prog(t, 5.0, 5.4));

    // Tightening enemy ring + ornate solar prison seal on the sanctum floor
    if (t > 0.85 && t < 5.0) {
      const rf = lerp(100, 48, ease.io(prog(t, 0.9, 4.3)));
      magicSeal(L.glow, G[0], G[1], rf + 8, ORG, t * 0.4, 0.7 * eclipse, YS, 6);
      magicSeal(L.glow, G[0], G[1], rf * 0.55, GOLD, -t * 0.6, 0.55 * eclipse, YS, 6);
      c.enemies.forEach((e, i) => {
        const a = base[i] + 0.38 * (t - 0.9);
        const ex = G[0] + Math.cos(a) * rf, ey = G[1] + Math.sin(a) * rf * YS;
        e.pin(ex, ey, 6 * eclipse * (0.6 + 0.4 * Math.sin(t * 3 + i)), 0);
        e.shakeAmt = t > 3.5 ? 0.45 : 0;
        // Solar tether from ground seal to each trapped target
        if (eclipse > 0.3) line(L.add, [[G[0] + Math.cos(a) * (rf * 0.55), G[1] + Math.sin(a) * (rf * 0.55) * YS], [ex, ey]], 1, GOLD, 0.45 * eclipse);
      });
    }
    halo(L.glow, G[0], G[1] + 4, 128, ORG, 0.52 * eclipse * (t < 4.95 ? 1 : 0), YS);

    // Dark solar fragments converging into the Black Sun
    const assemble = ease.out(prog(t, 1.0, 3.7));
    const R0 = 35 * assemble;
    for (const s of shards) {
      const p = prog(t, s.ta - 1.2, s.ta);
      if (p <= 0 || p >= 1) continue;
      const q = ease.in(p);
      const d = lerp(185, s.r, q), a = s.sa + (s.a - s.sa) * q * 0.6;
      const x = SC[0] + Math.cos(a) * d, y = SC[1] + Math.sin(a) * d;
      shard(L.add, x, y, s.sz, s.sz * 0.42, a + Math.PI, GOLD, 0.85 * p);
      shard(L.front, x, y, s.sz * 0.75, s.sz * 0.3, a + Math.PI, 0x0b0714, 0.95);
    }

    // THE BLACK SUN: cellular pixel-art corona texture + occulted void disc + diamond-ring eclipse
    const sunShrink = t > 4.95 ? 1 - ease.out(prog(t, 4.95, 6.8)) : 1;
    const R_sun = R0 * sunShrink;
    if (R_sun > 1.5) {
      const cor = sstep(1.3, 3.2, t) * sunShrink;
      const surge = t > 4.2 && t < 5.2 ? 1 + 0.45 * sstep(4.2, 4.95, t) : 1;
      const sc = (R_sun / 26) * surge;
      halo(L.add, SC[0], SC[1], (R_sun + 32) * surge, CRIM, 0.45 * cor, 1);
      // Two counter-rotating pixel-art cellular fire corona textures (no spiky sea-urchin triangles!)
      stampOn(L.add, 'corona_ring', SC[0], SC[1], { sx: sc * 1.15, sy: sc * 1.15, rot: t * 0.45, tint: ORG, alpha: 0.85 * cor, add: true });
      stampOn(L.add, 'corona_ring', SC[0], SC[1], { sx: sc * 0.96, sy: sc * 0.96, rot: -t * 0.65, tint: GOLD, alpha: 0.95 * cor, add: true });
      if (t < 4.95) {
        stampOn(L.add, 'seal_solar', SC[0], SC[1], { sx: sc * 0.85, sy: sc * 0.85, rot: t * 0.3, tint: GOLD, alpha: 0.5 * cor, add: true });
      }
      // Occulting Black Sun void core + crisp diamond-ring rim
      disc(L.front, SC[0], SC[1], R_sun, 0x05030a);
      gring(L.add, SC[0], SC[1], R_sun + 1.5, GOLD, 2, cor, 0, TAU, 1);
      gring(L.add, SC[0], SC[1], R_sun + 0.5, WH, 1, cor, 0, TAU, 1);
      sparkle(L.add, SC[0] + R_sun, SC[1] - 2, 10 * cor * surge, WH, cor, t);
      sparkle(L.add, SC[0] - R_sun, SC[1] + 2, 8 * cor * surge, GOLD, cor, -t);
    }
    void afterK;

    // Orbiting incandescent ring-blades (ground -> rising around Black Sun -> collapsing inward)
    if (t > 0.4 && t < 4.95) {
      const cc: P = t < 0.9 ? [c.caster.x, c.caster.y] : G;
      const ctr: P = [lerp(cc[0], SC[0], m), lerp(cc[1], SC[1], m)];
      const ys = lerp(YS, 0.85, m);
      const frz = 1 - sstep(3.9, 4.5, t);
      for (let i = 0; i < 5; i++) {
        const gr = lerp(14, 54 + i * 13, ease.out3(prog(t, 0.4 + 0.06 * i, 1.9)));
        const r = lerp(gr, 44 + i * 12, m) * (1 - collapse);
        if (r < 2) continue;
        rot[i] += dt * (i % 2 ? -1 : 1) * (1.0 + 0.55 * i) * frz;
        const n = 3 + (i % 3), step = TAU / n;
        for (let k = 0; k < n; k++) {
          const a0 = rot[i] + k * step, a1 = a0 + step * 0.58;
          arcBlade(L.add, ctr[0], ctr[1], r, a0, a1, 0.16, i % 2 ? GOLD : ORG, 0.92, ys);
          const ga = a1 + step * 0.2;
          glyph(L.add, ctr[0] + Math.cos(ga) * r, ctr[1] + Math.sin(ga) * r * ys, 2.5, i * 10 + k, GOLD, 0.85, ga);
        }
      }
    }

    // Erupting curved solar blades with short tapered fire wakes (clean, dramatic, zero black-brown hoses)
    for (const b of blades) {
      const u = (t - b.t0) / b.life;
      if (u < 0 || u > 1.0) continue;
      const uu = clamp(u);
      const r = 10 + 270 * ease.out(uu), ang = b.a0 + b.dir * 1.35 * uu;
      const span = lerp(0.55, 1.05, ease.out(uu)), fadeOut = 1 - sstep(0.68, 1.0, u);
      const hp = b.path(uu);
      // Short tapered comet wake (only 18% of path length, fading cleanly)
      const tr = sample((s) => b.path(clamp(uu - 0.18 * s)), 12);
      ribbon(L.add, tr, (i, n) => 12 * (1 - i / n), ORG, 0.75 * fadeOut);
      arcBlade(L.add, G[0], G[1], r, ang - span * 0.48, ang + span * 0.48, 0.34, GOLD, fadeOut, YS);
      sparkle(L.add, hp[0], hp[1], 7 * fadeOut, WH, fadeOut, t * 4);
      if (u < 0.45 && rand() < 0.5) {
        pixelBolt(L.add, SC, hp, GOLD, 10, 1, 0.65 * fadeOut, t * 20 + b.a0, false);
      }
      if (rand() < 0.85) {
        c.emit('add', { tex: 'flame', x: hp[0], y: hp[1], vx: rr(-35, 35), vy: rr(-50, -5), life: rr(0.25, 0.65), size: rr(4, 7), c0: WH, c1: ORG, ay: -20 });
      }
      c.enemies.forEach((e, i) => {
        if (b.hit.has(i)) return;
        const dx = e.x - G[0], dy = (e.y - G[1]) / YS, er = Math.hypot(dx, dy), ea = Math.atan2(dy, dx);
        if (Math.abs(er - r) < 18 && Math.abs(wrapPi(ea - ang)) < span / 2 + 0.12) {
          b.hit.add(i);
          c.strike(e, Math.atan2(e.y - G[1], e.x - G[0]) + b.dir * 0.35, 235, 155, GOLD, 12);
          slashX(c, e.x, e.y - 8, GOLD, 24, 0.32, ang);
          debris(c, e.x, e.y, 8, [0x2e2238, ORG, GOLD], 110);
        }
      });
    }

    if (t > 4.95 && t < 5.55) {
      const k = 1 - prog(t, 4.95, 5.55);
      pillar(L.add, SC[0], G[1], G[1] + 20, 16 * k + 3, GOLD, k);
    }
  });

  c.at(4.95, () => {
    c.flash(WH, 1);
    c.shake(12);
    c.slow(0.35, 0.25);
    c.shock(G[0], G[1], { r: 175, life: 1.0, col: GOLD, w: 5, amp: 6 });
    c.shock(G[0], G[1], { r: 290, life: 1.4, col: ORG, w: 4, amp: 4 });
    c.burst('add', SC[0], SC[1], 110, { spd: [60, 320], life: [0.45, 1.2], cols: [GOLD, WH, ORG], streak: 0.03, drag: 1.6 });
    for (let i = 0; i < 36; i++) {
      c.emit('deb', { x: rr(40, W - 40), y: rr(75, 235), z: rr(70, 175), vx: rr(-25, 25), vy: rr(-8, 8), gz: 240, life: rr(1.3, 2.3), size: rr(2, 4), c0: [0x2e2238, ORG, GOLD][i % 3], c1: 0x1a1224, bounce: 0.35 });
    }
  });
  c.at(5.2, () => {
    // Clean fantasy aftermath: shattered magma crater + broken solar seal rings (no Spirograph loop hoses!)
    crackScar(c, G[0], G[1], 8, 68, 5.5, ORG);
    ringScar(c, G[0], G[1], 56, 5.5, GOLD, 2);
    ringScar(c, G[0], G[1], 106, 5.5, ORG, 2);
  });
}

// ============================================================ 02 ORBITBREAKER WALTZ
function s02(c: Ctx) {
  const C: P = [CX, 162], A = 108, B = 46;
  const phis = [0, Math.PI / 3, (Math.PI * 2) / 3];
  const cols = [GOLD, BLUE, VIO];
  const lem = (th: number, k: number): P => {
    const x = A * Math.sin(th), y = B * Math.sin(2 * th);
    const ph = phis[k];
    return [C[0] + x * Math.cos(ph) - y * Math.sin(ph), C[1] + (x * Math.sin(ph) + y * Math.cos(ph)) * 0.8];
  };
  const tips: P[] = [];
  for (let k = 0; k < 3; k++) tips.push(lem(Math.PI / 2, k), lem(Math.PI * 1.5, k));
  c.layout(tips);
  const T0 = [0.45, 2.25, 4.05], T1 = [2.25, 4.05, 5.85];
  c.seg(0, 0.45, (u) => [lerp(36, C[0], u), lerp(215, C[1], u)], ease.out);
  for (let k = 0; k < 3; k++) c.seg(T0[k], T1[k], (u) => lem(u * TAU, k), ease.io3);
  const rails = [0, 1, 2].map((k) => sample((u) => lem(u * TAU, k), 96));

  // Constellation intersection nodes
  const nodes: { x: number; y: number; seen: boolean; pulse: number }[] = [];
  for (let a = 0; a < 3; a++) for (let b = a + 1; b < 3; b++)
    for (let i = 0; i < 96; i++) for (let j = 0; j < 96; j++) {
      const p = segIntersect(rails[a][i], rails[a][i + 1], rails[b][j], rails[b][j + 1]);
      if (p && !nodes.some((n) => dist(n.x, n.y, p[0], p[1]) < 9)) nodes.push({ x: p[0], y: p[1], seen: false, pulse: -9 });
    }
  const held = new Array(6).fill(false), struck = new Array(6).fill(false), tipHit = new Array(6).fill(false);
  const REV: [number, number][] = [[2, 6.0], [1, 6.5], [0, 7.0]];
  const prevTh = [TAU, TAU, TAU];

  c.each((t) => {
    const L = c.L;
    const fadeR = 1 - prog(t, 8.0, 8.75);
    const prog_k = [0, 1, 2].map((k) => ease.io3(prog(t, T0[k], T1[k])));

    // Subtle astrolabe sanctum seal at the waltz center
    if (t > 0.4 && fadeR > 0) {
      magicSeal(L.glow, C[0], C[1], 34, BLUE, t * 0.4, 0.45 * fadeR, YS, 6);
    }

    // Instead of drawing 3 full static figure-8 tubes (which look like a Spirograph),
    // draw a dynamic tapered comet-ribbon on the active sweep + crisp constellation star-nodes along established paths!
    for (let k = 0; k < 3; k++) {
      const p = prog_k[k];
      if (p <= 0 || fadeR <= 0) continue;
      const maxIdx = Math.floor(p * 96);
      // Constellation star-chain along the traced path
      for (let idx = 0; idx <= maxIdx; idx += 6) {
        const q = rails[k][idx];
        const nextQ = rails[k][Math.min(maxIdx, idx + 6)];
        line(L.glow, [q, nextQ], 1, cols[k], 0.38 * fadeR);
        if (idx % 12 === 0) {
          sparkle(L.add, q[0], q[1], 3.2 + Math.sin(t * 5 + idx) * 1.2, cols[k], 0.85 * fadeR, t + idx);
        } else {
          diamond(L.add, q[0], q[1], 2, 1.2, t * 2 + idx, hiRamp(cols[k], 0.5), 0.7 * fadeR);
        }
      }
      // Active sweeping blade-ribbon (tapered trailing 30% of the curve)
      if (p < 1.0) {
        const i0 = Math.max(0, Math.floor((p - 0.28) * 96));
        const sub = rails[k].slice(i0, maxIdx + 1);
        ribbon(L.add, sub, (i, n) => 11 * (i / Math.max(1, n - 1)), cols[k], 0.9 * fadeR);
      }
    }

    // Orbiting ring-blades with delayed acceleration
    let activeK = -1;
    for (let k = 0; k < 3; k++) if (t >= T0[k] && t < T1[k]) activeK = k;
    const bladeAt = (x: number, y: number, col: number, ph: number, r = 8) => {
      gring(L.add, x, y, r, col, 2, 0.95, 0, TAU, 1);
      for (let s = 0; s < 3; s++) {
        const a = ph + (s / 3) * TAU;
        shard(L.add, x + Math.cos(a) * (r + 2), y + Math.sin(a) * (r + 2), 4.5, 1.8, a + 1.57, WH, 0.95);
      }
    };
    if (activeK >= 0 && t < 5.85) {
      for (let b = 1; b <= 3; b++) {
        const pr = clamp(prog_k[activeK] - b * 0.045 * (0.5 + prog_k[activeK]));
        const q = lem(pr * TAU, activeK);
        bladeAt(q[0], q[1], cols[activeK], t * 7 + b, 9 - b);
      }
    } else if (t < 6.0 || t > 8.0) {
      for (let b = 0; b < 3; b++) {
        const a = t * 3.2 + (b / 3) * TAU;
        bladeAt(c.caster.x + Math.cos(a) * 16, c.caster.y - 6 + Math.sin(a) * 12, cols[b], t * 4 + b, 6);
      }
    }

    // Forward hits: lobe tips get struck and suspended in astral rings
    for (let k = 0; k < 3; k++) for (let s = 0; s < 2; s++) {
      const i = k * 2 + s;
      if (!tipHit[i] && t >= T0[k] && dist(c.caster.x, c.caster.y, tips[i][0], tips[i][1]) < 18) {
        tipHit[i] = true; held[i] = true;
        const e = c.enemies[i];
        e.flash = 1;
        slashX(c, e.x, e.y - 6, cols[k], 22, 0.35, t);
        c.burst('add', e.x, e.y - 6, 14, { spd: [30, 120], life: [0.3, 0.6], cols: [cols[k], WH], drag: 2 });
        c.shock(e.x, e.y, { r: 32, life: 0.4, col: cols[k], w: 2 });
      }
      if (held[i] && !struck[i]) {
        c.enemies[i].pin(tips[i][0], tips[i][1], 12 + 3 * Math.sin(t * 3 + i), 0.15 * Math.sin(t * 2 + i));
        gring(L.add, tips[i][0], tips[i][1] - 12, 10, cols[k], 1, 0.7 * fadeR, 0, TAU, YS, t * 2);
      }
    }

    // Astrolabe nodes at orbital crossings
    for (const n of nodes) {
      if (!n.seen && t < 6 && dist(c.caster.x, c.caster.y, n.x, n.y) < 12) {
        n.seen = true; n.pulse = t;
        c.burst('add', n.x, n.y, 10, { spd: [20, 90], life: [0.3, 0.6], cols: [WH, GOLD, BLUE], drag: 2 });
      }
      if (!n.seen || fadeR <= 0) continue;
      const pu = Math.exp(-(t - n.pulse) * 4);
      gring(L.add, n.x, n.y, 6 + 6 * pu, BLUE, 1, 0.7 * fadeR, 0, TAU, YS, t);
      sparkle(L.add, n.x, n.y, 4 + 6 * pu, WH, fadeR, t * 0.6);
    }

    // THE REVERSAL — blazing astral comets race backward along every path
    for (const [k, s0] of REV) {
      if (t < s0) continue;
      const u = ease.in(prog(t, s0, 8.0));
      const th = TAU * (1 - u);
      if (t > 8.05) continue;
      const q = lem(th, k);
      const tr = sample((s) => lem(Math.min(TAU, th + s * 0.75 * (0.3 + u)), k), 16);
      ribbon(L.add, tr, (i, n) => 12 * (1 - i / n), cols[k], 0.92);
      bladeAt(q[0], q[1], cols[k], -t * 10, 10);
      sparkle(L.add, q[0], q[1], 9, WH, 1, t * 3);
      for (const [tth, si] of [[Math.PI * 1.5, 1], [Math.PI * 0.5, 0]] as [number, number][]) {
        const i = k * 2 + si;
        if (!struck[i] && prevTh[k] > tth && th <= tth) {
          struck[i] = true;
          const e = c.enemies[i];
          c.strike(e, Math.atan2(e.y - C[1], e.x - C[0]) + 0.3, 180, 135, cols[k], 12);
          slashX(c, e.x, e.y - 6, cols[k], 28, 0.4, t * 2);
          c.shock(e.x, e.y, { r: 48, life: 0.5, col: cols[k], w: 3, amp: 2 });
          c.slow(0.5, 0.06);
        }
      }
      prevTh[k] = th;
    }
    if (t > 6.0 && t < 8.0) {
      const k = prog(t, 6.0, 8.0);
      magicSeal(L.add, C[0], C[1], 18 + 34 * k, GOLD, t * 3, 0.85 * k, YS, 6);
      c.post.aberr = 1.4 * k;
    }
    if (t > 8.0 && t < 8.5) c.post.aberr = 2.5 * (1 - prog(t, 8.0, 8.5));
  });

  c.at(8.0, () => {
    c.flash(WH, 1);
    c.shake(14);
    c.slow(0.3, 0.3);
    c.blast(C[0], C[1], 260, 240, 120);
    const cl = [GOLD, BLUE, VIO];
    [140, 205, 270].forEach((r, i) => {
      c.ent(1.25 + i * 0.2, (_a, u) => {
        const rr2 = r * ease.out3(u);
        fracRing(c.L.add, C[0], C[1], rr2, cl[i], 1 - u, i + 3, 4 * (1 - u) + 1);
        c.distort(C[0], C[1], rr2, 6 * (1 - u));
      });
    });
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + 0.2;
      slashLine(c, C[0], C[1], a, 95, cl[i % 3], 0.42);
    }
    c.ent(0.95, (_a, u) => {
      const k = ease.outExpo(u), f = 1 - u;
      magicSeal(c.L.add, C[0], C[1], 115 * k, GOLD, u * 1.2, f, YS, 8);
      sparkle(c.L.add, C[0], C[1], 36 * f, WH, f, u * 2);
    });
    c.burst('add', C[0], C[1], 140, { spd: [40, 310], life: [0.55, 1.4], cols: [GOLD, BLUE, VIO, WH], streak: 0.03, drag: 1.4 });
    crackScar(c, C[0], C[1], 7, 56, 4.5, BLUE);
    [44, 88].forEach((r, i) => ringScar(c, C[0], C[1], r, 4.5, cols[i], 2));
  });
}

// ============================================================ 03 SEVENFOLD DAWNFALL
function s03(c: Ctx) {
  const GC: P = [CX, 168];
  const T: P[] = [];
  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * TAU - Math.PI / 2 + 0.52;
    T.push([GC[0] + Math.cos(a) * 118, GC[1] + Math.sin(a) * 66]);
  }
  T.push([GC[0], GC[1]]);
  c.layout(T);
  const COLS = [GOLD, 0x8cfbff, VIO, 0x3ad8d0, RED, 0x4aff8a, WH];
  const COL2 = [ORG, 0x3a8cff, 0x4a1a9a, 0x1a6a9a, 0xff8a4a, 0x1a9a5a, GOLD];
  const LAND = [4.6, 5.3, 5.95, 6.55, 7.1, 7.6, 8.8];
  const FLY = [1.35, 1.35, 1.35, 1.3, 1.3, 1.3, 2.4];
  const APP = [1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.3];
  const HOV: P[] = Array.from({ length: 7 }, (_, k) => [52 + k * 62, 30 + (k % 2) * 14]);
  const CP: [P, P][] = [
    [[-70, 90], [60, -90]], [[90, 40], [-90, -60]], [[-160, 40], [160, -40]], [[60, 110], [-30, -100]],
    [[-100, 20], [140, -120]], [[120, 70], [-120, -60]], [[0, 60], [0, -160]],
  ].map(([a, b]) => [a as P, b as P]);

  const bodyPos = (k: number, t: number): P => {
    const u = (t - (LAND[k] - FLY[k])) / FLY[k];
    const h = HOV[k];
    if (u <= 0) {
      const a = t * (1.2 + k * 0.3) + k;
      return [h[0] + Math.cos(a) * 9, h[1] + Math.sin(a * (k % 2 ? 1 : -1)) * 6];
    }
    const e = k === 6 ? ease.in(clamp(u)) * 0.6 + clamp(u) * 0.4 : ease.in(clamp(u)) * 0.7 + clamp(u) * 0.3;
    const tp: P = [T[k][0], T[k][1] - 6];
    return bez(h, [h[0] + CP[k][0][0], h[1] + CP[k][0][1]], [tp[0] + CP[k][1][0], tp[1] + CP[k][1][1]], tp, e);
  };

  const stops: P[] = [
    ...T.slice(0, 6).map((p): P => {
      const a = Math.atan2(p[1] - GC[1], p[0] - GC[0]);
      return [p[0] + Math.cos(a) * 26, p[1] + Math.sin(a) * 18];
    }),
    [GC[0] - 28, GC[1] + 30],
  ];
  let prev: P = [50, 205];
  const MT = [0.7, 1.15, 1.6, 2.05, 2.5, 2.95, 3.4];
  stops.forEach((p, i) => {
    const from = prev;
    c.seg(MT[i] - 0.34, MT[i], (u) => [lerp(from[0], p[0], u), lerp(from[1], p[1], u) - Math.sin(u * Math.PI) * 14], ease.outExpo);
    prev = p;
  });
  c.seg(3.6, 4.5, (u) => [lerp(prev[0], CX, u), lerp(prev[1], 238, u), Math.sin(u * Math.PI) * 38], ease.io);
  const markerOn = new Array(7).fill(false);
  MT.forEach((mt, k) => c.at(mt, () => {
    markerOn[k] = true;
    c.burst('add', T[k][0], T[k][1], 16, { spd: [20, 80], life: [0.3, 0.7], cols: [COLS[k], WH], ys: YS, drag: 2 });
  }));
  c.at(0.25, () => {
    for (let i = 0; i < 6; i++) c.ent(0.9, (_a, u) => {
      const e = ease.in(u);
      gring(c.L.add, c.caster.x + (i - 2.5) * 6, c.caster.y - 8 - e * 260, 6 + i, i % 2 ? GOLD : WH, 2, 1 - u * 0.5, 0, TAU, 0.5);
    });
  });

  const hist: P[][] = [[], [], [], [], [], [], []];
  const SPEC = [0xff3a4a, 0xff9a2a, 0xffe24a, 0x4ae86a, 0x3ad8ff, 0x5a6aff, 0xc04aff];

  c.each((t) => {
    const L = c.L;
    for (let k = 0; k < 7; k++) {
      const land = LAND[k], u = (t - (land - FLY[k])) / FLY[k];
      const col = COLS[k], col2 = COL2[k];
      // Ornate astrolabe ground target seal + countdown ring
      if (markerOn[k] && t < land + 0.08) {
        const cd = clamp(1 - (land - t) / (land - MT[k]));
        magicSeal(L.glow, T[k][0], T[k][1], k === 6 ? 28 : 22, col, t * 0.8 * (k % 2 ? 1 : -1), 0.85, YS, k === 6 ? 7 : 6);
        gring(L.add, T[k][0], T[k][1], (k === 6 ? 32 : 25) * (1 - cd * 0.65), WH, 2, 0.9, 0, TAU, YS);
      }
      if (t < APP[k] || t >= land) continue;
      const vis = clamp((t - APP[k]) * 3);
      const bp = bodyPos(k, t);
      if (u > 0) {
        const sr = lerp(3, 20, ease.in(clamp(u)));
        disc(L.mark, bp[0], T[k][1], sr, 0x06040e, 0.55 * ease.in(clamp(u)), 0.45);
      }
      const h = hist[k];
      h.push(bp);
      const maxTail = k === 2 ? 32 : k === 6 ? 22 : 15;
      if (h.length > maxTail) h.shift();
      const w0 = k === 2 ? 13 : k === 6 ? 10 : 7;
      if (h.length > 2) {
        const tr = h.slice().reverse();
        ribbon(L.add, tr, (i, n) => w0 * (1 - i / n), col, 0.9);
      }
      // 7 distinct fantasy pixel-art celestial bodies
      const x = bp[0], y = bp[1];
      if (k === 0) {
        halo(L.add, x, y, 14, ORG, 0.65);
        star(L.add, x, y, 9, 6, 0.42, t * 3, GOLD, 1);
        disc(L.add, x, y, 4, WH);
      } else if (k === 1) {
        diamond(L.add, x, y, 10, 4, t * 2, col, 0.95);
        diamond(L.add, x, y, 10, 4, t * 2 + Math.PI / 2, 0xdffbff, 0.95);
        disc(L.add, x, y, 3, WH);
      } else if (k === 2) {
        halo(L.add, x, y, 15, VIO, 0.65);
        disc(L.front, x, y, 5, 0x070312);
        gring(L.add, x, y, 6, WH, 2, 1, 0, TAU, 1);
      } else if (k === 3) {
        disc(L.add, x, y, 4.5, col);
        gring(L.add, x, y, 10, 0xdffef8, 2, 0.95, 0, TAU, 0.35, 0.45);
        sparkle(L.add, x, y, 7, WH, 1, t * 2);
      } else if (k === 4) {
        for (let s = 0; s < 2; s++) {
          const a = t * 7 + s * Math.PI;
          star(L.add, x + Math.cos(a) * 6, y + Math.sin(a) * 6, 6, 4, 0.3, a, s ? WH : RED, 1);
        }
        halo(L.add, x, y, 13, RED, 0.5);
      } else if (k === 5) {
        star(L.add, x, y, 10, 5, 0.38, t * 3, col);
        star(L.add, x, y, 5, 5, 0.38, -t * 3, WH);
      } else {
        halo(L.add, x, y, 24, GOLD, 0.55);
        star(L.add, x, y, 15, 7, 0.38, t * 1.6, GOLD);
        star(L.add, x, y, 10, 7, 0.42, -t * 1.2, WH);
        disc(L.add, x, y, 4, WH);
      }
      if (vis < 1) gring(L.add, x, y, 18 * (1 - vis), WH, 2, vis, 0, TAU, 1);
      void col2;
    }
  });

  LAND.forEach((lt, k) => c.at(lt, () => {
    const [x, y] = T[k], col = COLS[k];
    const e = c.enemies[k];
    c.shake(4 + k * 2.0);
    c.flash(col, 0.25 + k * 0.08);
    c.ent(1.25 + k * 0.2, (_a, u) => pillar(c.L.add, x, y, 220, lerp(10, 2, u) + 2, col, (1 - u) * 0.92));
    c.shock(x, y, { r: 52 + k * 10, life: 0.65, col, w: 4, amp: 3 + k });
    switch (k) {
      case 0:
        c.burst('deb', x, y, 32, { spd: [30, 130], vz: [110, 260], gz: 380, life: [0.8, 1.5], size: [2, 3], cols: [GOLD, ORG, WH], bounce: 0.2, ys: YS });
        ringScar(c, x, y, 22, 5.5, ORG, 2);
        c.strike(e, -Math.PI / 2 + 0.4, 40, 200, GOLD, 10);
        break;
      case 1:
        c.ent(0.95, (_a, u) => {
          for (let i = 0; i < 8; i++) {
            const a = (i / 8) * TAU + 0.3, l = (14 + (i % 2) * 14) * ease.outBack(Math.min(1, u * 3));
            shard(c.L.add, x + Math.cos(a) * l * 0.75, y + Math.sin(a) * l * 0.45 - l * 0.35, l * 0.55, 3, a - 0.5, i % 2 ? 0xdffbff : col, 1 - Math.max(0, u - 0.65) * 3);
          }
        });
        ringScar(c, x, y, 24, 5.5, col, 2);
        c.strike(e, 0, 150, 160, col, 14);
        break;
      case 2:
        c.ent(1.0, (_a, u) => {
          gring(c.L.add, x, y, 42 * (1 - u), VIO, 3, 1, 0, TAU, YS);
          disc(c.L.front, x, y, 13 * Math.sin(u * Math.PI), 0x07030f, 1, YS);
          c.lens(x, y - 10, 58, 1.4 * Math.sin(u * Math.PI));
        });
        ringScar(c, x, y, 22, 5.5, VIO, 2);
        c.strike(e, Math.PI * 0.8, 60, 220, VIO, 16);
        break;
      case 3:
        for (let i = 0; i < 3; i++) c.shock(x, y, { r: 36 + i * 24, life: 0.55 + i * 0.18, col: 0x3ad8d0, col2: 0xdffef8, w: 3 });
        ringScar(c, x, y, 26, 5.5, 0x3ad8d0, 2);
        c.strike(e, 0.4, 200, 90, 0x3ad8d0, 12);
        break;
      case 4:
        slashX(c, x, y - 8, RED, 34, 0.45, 0.4);
        ringScar(c, x, y, 24, 5.5, RED, 2);
        c.strike(e, 2.2, 180, 120, RED, 20);
        break;
      case 5:
        slashX(c, x, y - 8, col, 38, 0.45, 0);
        ringScar(c, x, y, 24, 5.5, col, 2);
        c.strike(e, -Math.PI / 2, 30, 260, col, 6);
        break;
      default: {
        c.slow(0.25, 0.4);
        c.shake(18);
        c.flash(WH, 1);
        c.blast(x, y, 300, 220, 160);
        const R = 132;
        const vert = (i: number): P => {
          const a = -Math.PI / 2 + (i / 7) * TAU;
          return [x + Math.cos(a) * R, y + Math.sin(a) * R * 0.62];
        };
        c.ent(2.5, (_a, u) => {
          const k = ease.outExpo(Math.min(1, u * 3)), f = 1 - sstep(0.55, 1, u);
          magicSeal(c.L.add, x, y, R * k, GOLD, u * 0.5, 0.85 * f, 0.62, 7);
          for (let i = 0; i < 7; i++) {
            const A = vert(i);
            pillar(c.L.add, A[0], A[1], 230 * k, 6 * (1 - u * 0.5) + 2, SPEC[i], f * 0.9);
            if (u < 0.55) pixelBolt(c.L.add, [x, y], A, SPEC[i], 8, 2, f * 0.85, i * 13 + Math.floor(u * 20), false);
          }
          pillar(c.L.add, x, y, 280, 16 * (1 - u) + 3, GOLD, f);
        });
        for (let i = 0; i < 4; i++) c.shock(x, y, { r: 115 + i * 85, life: 0.95 + i * 0.22, col: SPEC[i * 2], w: 5, amp: 6, push: i === 0 ? 150 : 0 });
        c.burst('add', x, y, 180, { spd: [60, 330], life: [0.65, 1.6], cols: SPEC, streak: 0.03, drag: 1.4, ys: YS, vz: [0, 120], gz: 100 });
        debris(c, x, y, 36, [WH, GOLD, 0x4a4268], 250);
        crackScar(c, x, y, 9, 95, 6, GOLD);
        ringScar(c, x, y, R, 6, GOLD, 2, 0.62);
      }
    }
  }));
}

// ============================================================ 04 MERIDIAN COLLAPSE
function s04(c: Ctx) {
  const C0: P = [CX, 140], R = 110, GC: P = [CX, 168];
  c.layout([[205, 160], [278, 152], [240, 192], [190, 205], [296, 196], [240, 138]]);
  const cols = [GOLD, BLUE, VIO, 0xff6a9a];
  const T0 = [[0.55, 0.0], [0.55, 1.05], [0.55, 2.1], [0.0, 0.0]];
  const T1 = [[1.3, 0.4], [1.3, 1.45], [1.3, 2.5], [0.12, 0.0]];
  const APP = [0.5, 1.4, 2.3, 3.2];
  const A = [-Math.PI / 2, 0, Math.PI / 2, Math.PI];

  const rp = (_k: number, a: number, tx: number, tz: number, hs: number, r = R): { p: P; z: number } => {
    const x = Math.cos(a) * r, y = Math.sin(a) * r;
    const y1 = y * Math.cos(tx), z1 = y * Math.sin(tx);
    const x2 = x * Math.cos(tz) - y1 * Math.sin(tz), y2 = x * Math.sin(tz) + y1 * Math.cos(tz);
    return { p: [C0[0] + x2, C0[1] + y2 * 0.78 - z1 * 0.3 * hs], z: z1 };
  };
  const tilt = (k: number, t: number): [number, number, number] => {
    const grow = ease.io(prog(t, 2.8, 5.2));
    const rearr = ease.io(prog(t, 5.7, 6.5));
    const coll = ease.io3(prog(t, 6.5, 7.5));
    let tx = lerp(T0[k][0], T1[k][0], grow), tz = lerp(T0[k][1], T1[k][1], grow);
    tx += rearr * (0.25 + 0.15 * k) * (k % 2 ? -1 : 1);
    tz += rearr * 0.6;
    tx = lerp(tx, Math.PI / 2, coll); tz = lerp(tz % Math.PI, 0, coll);
    return [tx, tz, 1 - coll];
  };

  const POS: P[] = [0, 1, 2, 3].map((k) => rp(k, A[k], T0[k][0], T0[k][1], 1).p);
  POS.forEach((p, k) => c.seg(APP[k], APP[k] + 0.01, () => [p[0], p[1] + 18]));
  [0, 1, 2].forEach((k) => c.hide(APP[k] + 0.55, APP[k + 1]));
  c.hide(4.2, 5.3);
  c.seg(5.3, 5.31, () => [CX, 152]);
  c.seg(5.75, 6.05, (u) => [lerp(CX, 420, u), lerp(152, 118, u)], ease.outExpo);

  APP.forEach((a, k) => c.at(a, () => {
    c.burst('add', POS[k][0], POS[k][1], 36, { spd: [20, 165], life: [0.3, 0.85], cols: [cols[k], WH], streak: 0.03, drag: 2.5 });
    c.ent(0.5, (_a, u) => {
      pillar(c.L.add, POS[k][0], POS[k][1] + 18, 175, 8 * (1 - u) + 1, cols[k], 1 - u);
      magicSeal(c.L.add, POS[k][0], POS[k][1] + 18, 38 * u, cols[k], u * 2, 1 - u, YS, 4);
      c.distort(POS[k][0], POS[k][1], 40 * u + 4, 4 * (1 - u));
    });
    c.flash(cols[k], 0.2);
  }));

  const spin = [0, 0, 0, 0];
  const slabs = Array.from({ length: 16 }, () => {
    const a = rr(0, TAU), d = rr(30, 115);
    return { x: CX + Math.cos(a) * d, y: 165 + Math.sin(a) * d * 0.6, ph: rr(0, TAU), w: rr(10, 20), h: rr(6, 11), r: rr(-0.4, 0.4), vx: 0, vy: 0, vr: 0, fly: false, ox: 0, oy: 0, ot: 0 };
  });
  const pieces: { x: number; y: number; vx: number; vy: number; r: number; vr: number; col: number; l: number }[] = [];
  const stars = Array.from({ length: 4 }, () => Array.from({ length: 4 }, () => ({ o: rr(0, 1), s: rr(0.04, 0.1) })));

  c.each((t, dt) => {
    const L = c.L;
    const collapseP = ease.io3(prog(t, 6.5, 7.5));
    const fadeAll = t > 7.75 ? 1 - prog(t, 8.0, 9.0) : 1;
    for (let k = 0; k < 4; k++) spin[k] += dt * (0.25 + k * 0.1 + 1.6 * prog(t, 5.3, 6.4) * (1 - collapseP * 0.8)) * (k % 2 ? -1 : 1);

    if (t > 3.2 && t < 7.8) {
      const s = sstep(3.2, 5.2, t) * (1 - collapseP * 0.6);
      c.lens(C0[0], C0[1], R * 1.05, 0.5 * s * Math.sin(t * 1.3));
      c.post.slice = [3.0 * s, 0.4 + t * 0.05, 14, t * 0.3];
      c.post.aberr = 1.1 * s;
    }

    // Floating displaced sanctum floor slabs
    for (const s of slabs) {
      const appear = sstep(3.0, 4.6, t) * fadeAll;
      if (appear <= 0 && !s.fly) continue;
      if (t >= 7.75 && !s.fly) {
        s.fly = true;
        const a = Math.atan2(s.y - GC[1], s.x - GC[0]);
        s.vx = Math.cos(a) * rr(90, 220); s.vy = Math.sin(a) * rr(50, 130); s.vr = rr(-6, 6);
        s.ox = s.x; s.oy = s.y; s.ot = t;
      }
      let x = s.x, y = s.y - 8 * Math.sin(t * 1.4 + s.ph) * appear - 10 * appear, rot = s.r + 0.2 * Math.sin(t + s.ph);
      let al = appear;
      if (s.fly) {
        const q = t - s.ot;
        x = s.ox + s.vx * q; y = s.oy + s.vy * q - Math.max(0, 80 * q - 160 * q * q); rot = s.r + s.vr * q;
        al = 1 - prog(q, 0.9, 1.8);
        if (al <= 0) continue;
      }
      const cs = Math.cos(rot), sn = Math.sin(rot);
      const pts: P[] = [[-s.w / 2, -s.h / 2], [s.w / 2, -s.h / 2], [s.w / 2, s.h / 2], [-s.w / 2, s.h / 2]].map(([a, b]) => [x + a * cs - b * sn, y + a * sn + b * cs] as P);
      poly(L.front, pts.map((p) => [p[0], p[1] + 3] as P), 0x0f0c1c, al * 0.95);
      poly(L.front, pts, 0x28243e, al);
      line(L.add, [...pts, pts[0]], 1, mix(GOLD, BLUE, 0.5 + 0.5 * Math.sin(t + s.ph)), 0.65 * al);
    }

    // Four interlocking celestial armillary rings
    for (let k = 0; k < 4; k++) {
      if (t < APP[k]) continue;
      const [tx, tz, hs] = tilt(k, t);
      const age = t - APP[k];
      const span = lerp(0.55, TAU, ease.io(prog(age, 0.5, 2.0 + (3 - k) * 0.5)));
      const n = 96;
      const pts: { p: P; z: number }[] = [];
      const a0 = A[k] + spin[k] - span / 2;
      const full = span >= TAU - 0.01;
      for (let i = 0; i <= n; i++) {
        const a = full ? A[k] + spin[k] + (i / n) * TAU : a0 + (i / n) * span;
        pts.push(rp(k, a, tx, tz, hs));
      }
      const ps = pts.map((q) => q.p);
      const taper = (i: number, nn: number) => (full ? 1 : Math.sin((i / nn) * Math.PI) + 0.1);
      const wbase = lerp(11, 4, collapseP) * fadeAll;
      ribbon(L.add, ps, (i, nn) => wbase * taper(i, nn) * (0.75 + 0.25 * (pts[i].z / R)), cols[k], 0.9 * fadeAll);
      stars[k].forEach((s, i) => {
        const idx = Math.floor(((((s.o + t * s.s) % 1) + 1) % 1) * (ps.length - 1));
        sparkle(L.add, ps[idx][0], ps[idx][1], 4 + (i === 0 ? 2 : 0), WH, fadeAll, t * 2 + i);
      });
    }

    // Collapse to a razor-sharp white-gold dimensional horizon
    if (t > 7.0 && t < 8.0) {
      const k = sstep(7.0, 7.6, t);
      const len = R * 1.15 * (1 + (t > 7.65 ? 0.4 * prog(t, 7.65, 8) : 0));
      diamond(L.add, C0[0], C0[1], len, 7 * k, 0, GOLD, 0.55 * k);
      diamond(L.add, C0[0], C0[1], len, 2.5 * k, 0, WH, k);
      sparkle(L.add, C0[0], C0[1], 24 * k, WH, k, t * 2);
      c.darken(0.6 * k);
    }

    if (t > 3.5 && t < 7.75) {
      const pull = ease.io(prog(t, 6.2, 7.5));
      c.enemies.forEach((e, i) => {
        const ox = (i % 3 - 1) * 14, oy = (Math.floor(i / 3) - 0.5) * 12;
        e.pin(lerp(e.hx, CX + ox, pull), lerp(e.hy, C0[1] + 14 + oy, pull), 6 * sstep(3.5, 5, t) * (1 - pull) + 14 * pull, 0.1 * Math.sin(t * 3 + i) * pull);
        e.shakeAmt = pull * 0.6;
      });
    }

    for (const p of pieces) {
      p.l += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.99; p.vy *= 0.99; p.r += p.vr * dt;
      const a = 1 - prog(p.l, 0.8, 1.9);
      if (a > 0) {
        rotRect(L.add, p.x, p.y, 12, 3, p.r, p.col, a);
        rotRect(L.add, p.x, p.y, 7, 1, p.r, WH, a);
      }
    }

    if (t > 5.4 && t < 7.0) {
      const rings = [0, 1, 2, 3].map((k) => {
        const [tx, tz, hs] = tilt(k, t);
        return Array.from({ length: 36 }, (_, i) => rp(k, spin[k] + (i / 36) * TAU, tx, tz, hs).p);
      });
      for (let a = 0; a < 4; a++) for (let b = a + 1; b < 4; b++) {
        let cnt = 0;
        for (let i = 0; i < 36 && cnt < 2; i++) for (let j = 0; j < 36 && cnt < 2; j++) {
          const q = segIntersect(rings[a][i], rings[a][(i + 1) % 36], rings[b][j], rings[b][(j + 1) % 36]);
          if (q) { cnt++; sparkle(L.add, q[0], q[1], 6 + 2 * Math.sin(t * 20 + a + b), WH, 1, t); }
        }
      }
    }
  });

  c.at(7.75, () => {
    c.flash(WH, 1);
    c.shake(16);
    c.slow(0.3, 0.3);
    c.blast(CX, 160, 300, 300, 150, 12);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - 160, e.x - CX), 280, 150, WH, 12));
    for (let i = 0; i < 16; i++) {
      const a = rr(0, TAU);
      pieces.push({ x: CX + Math.cos(a) * rr(20, 100), y: C0[1] + Math.sin(a) * rr(10, 60), vx: Math.cos(a) * rr(80, 260), vy: Math.sin(a) * rr(50, 150), r: rr(0, TAU), vr: rr(-8, 8), col: cols[i % 4], l: 0 });
    }
    // Tapered diamond cross-rupture with crackling astral lightning
    c.ent(1.45, (_a, u) => {
      const wH = 38 * Math.sin(Math.min(1, u * 1.6) * Math.PI * 0.5) * (1 - u) + 2;
      const lenH = 250 * ease.outExpo(Math.min(1, u * 2));
      const lenV = 165 * ease.outExpo(Math.min(1, u * 2));
      const f = 1 - u;
      diamond(c.L.add, CX, C0[1], lenH, wH * 1.25, 0, BLUE, 0.55 * f);
      diamond(c.L.add, CX, C0[1], lenH * 0.92, wH * 0.72, 0, GOLD, 0.9 * f);
      diamond(c.L.add, CX, C0[1], lenH * 0.82, Math.max(1.5, wH * 0.28), 0, WH, f);
      diamond(c.L.add, CX, C0[1], lenV, wH * 0.8, Math.PI / 2, BLUE, 0.55 * f);
      diamond(c.L.add, CX, C0[1], lenV * 0.9, wH * 0.45, Math.PI / 2, GOLD, 0.9 * f);
      diamond(c.L.add, CX, C0[1], lenV * 0.8, Math.max(1.5, wH * 0.2), Math.PI / 2, WH, f);
      if (u < 0.65) {
        pixelBolt(c.L.add, [CX - lenH * 0.8, C0[1]], [CX + lenH * 0.8, C0[1]], BLUE, 14 * f, 2, f, u * 30, true);
        pixelBolt(c.L.add, [CX, C0[1] - lenV * 0.75], [CX, C0[1] + lenV * 0.75], GOLD, 12 * f, 2, f, u * 30 + 7, false);
      }
      c.post.slice = [5 * f, 0.0, 12, u * 5];
      c.distort(CX, C0[1], 40 + 250 * u, 6 * f);
    });
    [60, 130, 210].forEach((r, i) => c.shock(CX, C0[1] + 20, { r, life: 0.95 + i * 0.28, col: cols[i], w: 5, amp: 5 }));
    c.burst('add', CX, C0[1], 170, { spd: [60, 340], life: [0.65, 1.7], cols: [GOLD, BLUE, VIO, WH], streak: 0.03, drag: 1.3 });
    debris(c, CX, C0[1], 36, [WH, 0x4a4268, GOLD], 250);
    crackScar(c, CX, GC[1], 8, 95, 5, GOLD);
    ringScar(c, CX, GC[1], 72, 5, BLUE, 2);
  });
}

export const ECLIPSE: Skill[] = [
  { id: 1, relic: 'halo', name: 'Black Sun Coronation', sub: 'a constructed eclipse becomes a solar catastrophe', dur: 10, phases: [[0, 'Dash & orbit'], [1.2, 'Black sun assembles'], [4.2, 'Silence'], [4.95, 'Corona release'], [6.5, 'Aftermath']], setup: s01 },
  { id: 2, relic: 'halo', name: 'Orbitbreaker Waltz', sub: 'three figure-eight orbits, then the whole system runs backward', dur: 10.5, phases: [[0, 'Figure-eight dashes'], [5.9, 'Stop at the crossing'], [6.1, 'Orbit reversal'], [8.0, 'Stellar collision']], setup: s02 },
  { id: 3, relic: 'halo', name: 'Sevenfold Dawnfall', sub: 'seven distinct celestial bodies, seven distinct arrivals', dur: 12, phases: [[0, 'Launch & mark'], [3.6, 'Descent'], [4.6, 'Impacts 1–6'], [8.8, 'Seventh star'], [10, 'Aftermath']], setup: s03 },
  { id: 4, relic: 'halo', name: 'Meridian Collapse', sub: 'a broken astronomical machine folds to a horizon, then ruptures', dur: 11.5, phases: [[0.5, 'Four teleports'], [2.8, 'Interlocking rings'], [5.3, 'Tilt'], [6.5, 'Collapse to horizon'], [7.75, 'Cross rupture']], setup: s04 },
];
