import type { Skill } from '../engine/core';
import { ECLIPSE } from './eclipse';
import { DRAGONBONE } from './dragonbone';
import { FAN } from './fan';
import { SPINDLE } from './spindle';
import { LANTERN } from './lantern';

export const RELICS = [
  { id: 'halo', name: 'Eclipse Halo', tag: 'cosmic geometry → catastrophe', color: '#ffd35a' },
  { id: 'chain', name: 'Dragonbone Chain', tag: 'living restraint → monstrous destruction', color: '#ff4a5a' },
  { id: 'fan', name: 'Prismatic War Fan', tag: 'beauty & fluidity → overwhelming force', color: '#6af0ff' },
  { id: 'spindle', name: 'Fate Spindle', tag: 'connected structures rewrite space & time', color: '#c9a8ff' },
  { id: 'lantern', name: 'Soul Lantern', tag: 'living darkness → spectral apocalypse', color: '#7ad8ff' },
];
import { fusionSkills, type RemixSkill } from './remixes';
import { independentSkills } from './v2-independent';
export { REMIX_COUNTS } from './remixes';
export const ORIGINAL_SKILLS: Skill[] = [...ECLIPSE, ...DRAGONBONE, ...FAN, ...SPINDLE, ...LANTERN];
export const SKILLS: RemixSkill[] = [
  ...ORIGINAL_SKILLS.map(s => ({ ...s, kind: 'original' as const })),
  ...independentSkills(),
  ...fusionSkills(ORIGINAL_SKILLS),
];
