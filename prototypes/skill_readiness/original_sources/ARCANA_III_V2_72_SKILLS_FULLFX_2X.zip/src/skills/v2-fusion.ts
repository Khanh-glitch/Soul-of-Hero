/** ARCANA V2 cross-system syntheses: neither parent ultimate is simply run in parallel.
 * Each fusion computes one joint physical/geometric process with observable coupling.
 * #301 remains in remixes.ts as the accepted legacy implementation, untouched.
 */
import { Ctx, type Skill } from '../engine/core';
import { type P, TAU, YS, clamp, ease, lerp, prog, rr, sample } from '../engine/util';
import { arcBlade, chainLine, diamond, disc, glyph, gring, line, magicSeal, ngon, ribbon, shard, star } from '../engine/draw';
import { crackScar, debris, halo, ringScar, slashLine, sparkle } from '../engine/fx';
const center:P=[241,151];
const polar=(p:P,r:number,a:number,ys=YS):P=>[p[0]+Math.cos(a)*r,p[1]+Math.sin(a)*r*ys];
const track=(fn:(u:number)=>P,n=30):P[]=>sample(fn,n);
const P=(t:number,a:number,b:number)=>prog(t,a,b);
const F=(t:number,end:number)=>1-prog(t,end-1.3,end);
const PALETTE=[0xff567a,0xffac42,0xffeb90,0x65e8bd,0x72ceff,0xb7a0ff,0xff9dde];
const INFOS = [
 {name:'Reflected Orbit',pair:'Orbitbreaker × Glass Monsoon',why:'Blade paths reflect off actual oriented glass planes; reversed travel shatters them',col:0xffd779,hi:0xe1faff,dur:9.0},
 {name:'Ink-Blood Wyrm',pair:'Wyrm Uncoiled × Imperial Inkstorm',why:'Connected calligraphy becomes the live parametric spine of an articulated dragon',col:0xff699a,hi:0xffe3aa,dur:9.2},
 {name:'Meteor Sutures',pair:'Sevenfold Dawnfall × Starlace Execution',why:'Taut needle connections capture and redirect falling meteors between graph vertices',col:0xffc173,hi:0xd5faff,dur:9.4},
 {name:'Time Meridian',pair:'Meridian Collapse × Seam Between Seconds',why:'Ring crossings store prior cuts and reactivate them in reverse chronological order',col:0xd5baff,hi:0xf0f7ff,dur:9.2},
 {name:'Resonant Undertow',pair:'Hell-Tide Harpoon × Drowned Choir',why:'Vortex curl continuously bends propagating waves into compressed spiral fronts',col:0x8ad8ff,hi:0xff8fe4,dur:9.5},
 {name:'Prism Loom',pair:'Seven-Color Tempest × Loom of the Last Horizon',why:'Seven guided streams enter connected fabric cells; each row redirects and recolors the flow',col:0x7febf5,hi:0xffe3ae,dur:9.7},
 {name:'Soulwing Ascension',pair:'Butterfly Cataclysm × Funeral Fireworks',why:'Each ghostfire seed becomes a new luminous butterfly that flies to a flower target',col:0xffb0e2,hi:0x9bffff,dur:8.7},
 {name:'Spectral Puppetry',pair:'Marionette Eclipse × Procession of Hollow Kings',why:'Live tension lines steer ghost soldiers into two coordinated flanking armies',col:0xb6afff,hi:0xe5ffff,dur:9.1},
 {name:'Abyssal Ribgate',pair:"Leviathan's Last Heartbeat × God-Eater's Wake",why:'Individual ribs are actual portal-frame segments; the heartbeat directly controls its aperture',col:0x88dcff,hi:0xff789f,dur:9.5},
 {name:'Chromatic Lockdown',pair:'Cathedral of Shackles × Seven-Color Tempest',why:'Cage edges are conducting rails that transmit refracted current toward enclosed targets',col:0xffa2b9,hi:0xa7f9ff,dur:9.4},
 {name:'Singularity Harpoon',pair:'Sevenfold Dawnfall × Hell-Tide Harpoon',why:'A central tether changes meteor trajectories via orbiting gravity and releases a joint drill',col:0xffb76e,hi:0xceabff,dur:9.4},
] as const;
function collision(c:Ctx,k:number,col:number,hi:number,major=false){
 const e=c.enemies[k%c.enemies.length];if(!e)return;
 const a=Math.atan2(e.y-center[1],e.x-center[0]);
 c.strike(e,a,major?205:127,major?115:68,col,major?13:7);
 c.burst('add',e.x,e.y-7,major?60:29,{spd:[60,major?245:156],life:[0.35,1.3],size:[2,7],size1:0.5,cols:[col,hi,0xffffff],tex:'shard',streak:0.028});
 if(major)crackScar(c,e.x,e.y,6,54,2.7,col);else ringScar(c,e.x,e.y,26,1.7,col,2.5);
}
function install(c:Ctx,i:number){
 const info=INFOS[i],x=center[0],y=center[1],last=info.dur;
 c.layout([[x-92,y-34],[x+84,y-26],[x-58,y+42],[x+76,y+45],[x+4,y-72]]);
 c.caster.x=c.caster.tx=70;c.caster.y=c.caster.ty=213;c.caster.trail=info.col;
 // Character moves through the resulting phenomenon; no new character/weapon assets.
 if([0,1,2,3,5,7].includes(i)) {
   c.seg(0,2.6,u=>[lerp(70,x-36,u),lerp(213,y+34,u)]);
   c.seg(3.4,6.6,u=>[x-44+110*u,y+20-56*Math.sin(u*Math.PI)]);
 } else c.seg(0,5.9,u=>[lerp(70,x-15,u),lerp(213,y+28,u),[8,10].includes(i)?Math.sin(u*Math.PI)*38:0]);
 c.at(0.10,()=>c.burst('add',70,200,25,{spd:[16,105],life:[0.3,0.9],cols:[info.col,info.hi],tex:'spark',size:[2,5]}));
 // Contact ordering comes from the coupled phenomena, not from parent 'nexus' overlay.
 const contacts=([0,2,5,7,9].includes(i)?[4.45,5.25,6.15,6.77]:[4.95,5.95,6.85]);
 contacts.forEach((t,j)=>c.at(t,()=>{collision(c,(i+j)%c.enemies.length,info.col,info.hi,j===contacts.length-1);if(i===4||i===10)c.shock(x,y,{r:90+j*22,life:0.85,col:info.col,w:2,amp:2.0,push:75});}));
 c.at(6.95,()=>{
   c.flash(info.hi,0.71);c.shake(7.1);
   if([0,3,4,7,8,10].includes(i))c.shock(x,y,{r:172,life:1.2,col:info.col,col2:info.hi,w:4,amp:5.0,push:190,lift:90});
   else c.burst('add',x,y,90,{spd:[40,255],life:[0.6,1.7],cols:[info.col,info.hi,0xffffff],tex:i===6?'wing':'shard',size:[2,9],streak:0.025});
 });
 c.at(last-1.05,()=>{debris(c,x,y,32,[info.col,info.hi,0x342e4a],150);crackScar(c,x,y,8,83,3.0,info.col);});
 // Geometry depends on shared source variables: positions and phases of phenomenon A actually control B.
 c.each((t,dt)=>{
  const L=c.L,a=clamp(t*3)*F(t,last),build=ease.out(P(t,0.3,2.4)),couple=ease.io(P(t,2.15,4.7)),release=ease.out(P(t,5.0,7.2)),r=44+build*63;
  if(a<=0)return;
  switch(i){
   case 0: { // REFLECTIONS: actual specular normals derived from adjacent blade segments.
     const pts:P[]=[[x-102,y+38],[x-51,y-46],[x+56,y-49],[x+84,y+32],[x-4,y+68]];
     for(let j=1;j<pts.length-1;j++){
       const incoming:P=[pts[j][0]-pts[j-1][0],pts[j][1]-pts[j-1][1]];
       const outgoing:P=[pts[j+1][0]-pts[j][0],pts[j+1][1]-pts[j][1]];
       const l0=Math.hypot(...incoming)||1,l1=Math.hypot(...outgoing)||1;
       const nx=incoming[0]/l0-outgoing[0]/l1,ny=incoming[1]/l0-outgoing[1]/l1;
       const normal=Math.atan2(ny,nx),tangent=normal+Math.PI/2;
       const p=pts[j];diamond(L.front,...p,32,8,tangent,info.col,a*0.92);
       diamond(L.add,...p,24,3,tangent,info.hi,a);
       sparkle(L.add,...p,6,info.hi,a*(j<couple*5?1:0.12));
     }
     const head=clamp(P(t,0.6,5.5)*4);
     for(let j=1;j<=Math.ceil(head);j++){
       const k=clamp(head-(j-1)),from=pts[j-1],to=pts[j];
       const end:P=[lerp(from[0],to[0],k),lerp(from[1],to[1],k)];
       ribbon(L.glow,[from,end],7,j%2?info.col:info.hi,a);
       diamond(L.add,...end,18,6,t+j,info.hi,a);
     }
     if(t>5.25)for(let j=4;j>=1;j--)line(L.add,[pts[j],pts[j-1]],3,info.hi,a*release);
     break;}
   case 1: { // INK SPINE: drawn stroke is literally used as the dragon skeleton's path.
     const ink=(v:number):P=>[x-110+220*v,y+Math.sin(v*TAU*1.4)*52+Math.sin(v*TAU*3+t*0.4)*7];
     const extent=P(t,0.3,3.5),inkPts=sample(ink,42,0,Math.max(0.001,extent));
     ribbon(L.front,inkPts,k=>16*(1-k/42)+3,0x0b0716,a);ribbon(L.add,inkPts,7,info.col,a*0.9);
     const snakePos=P(t,2.2,6.5),body=sample(v=>ink(clamp(snakePos-v*0.36)),38);
     chainLine(L.front,body,8,info.col,4,info.hi);ribbon(L.glow,body,7,info.hi,a*0.43);
     const head=body[0];diamond(L.add,...head,28,9,Math.atan2(body[0][1]-body[1][1],body[0][0]-body[1][0]),info.hi,a);
     for(const knot of [0.22,0.51,0.79]){const p=ink(knot);arcBlade(L.add,...p,17,0.3+t,1.3+t,0.3,info.col,a*couple);}
     break;}
   case 2: { // METEOR SUTURES: each segment is a real connected-vertex route, not falling stars over a drawn lattice.
     const nodes:P[]=[[x-97,y-45],[x+10,y-85],[x+99,y-38],[x+58,y+49],[x-45,y+56],[x-97,y-45]];
     for(let j=0;j<nodes.length-1;j++){const active=P(t,0.4+j*0.3,3.3+j*0.14);line(L.add,[nodes[j],nodes[j+1]],3,info.col,a*active);diamond(L.front,...nodes[j],14,4,j+t,info.hi,a*active);}
     for(let m=0;m<5;m++){const start=m*0.7+1.3,u=P(t,start,start+3.1),seg=Math.min(4,Math.floor(u*5)),within=u*5-seg;
       const p0=nodes[seg],p1=nodes[seg+1],pos:P=[lerp(p0[0],p1[0],within),lerp(p0[1],p1[1],within)];
       star(L.add,...pos,12,5,0.35,t+m,info.hi,a);const wake:P[]=[pos,[pos[0]-(p1[0]-p0[0])*0.18,pos[1]-(p1[1]-p0[1])*0.18]];ribbon(L.glow,wake,8,info.col,a*couple);}
     break;}
   case 3: { // TEMPORAL SEAMS: crossings of rotating ring paths are where frozen cut-history is stored.
     for(let j=0;j<2;j++){const rot=t*0.3+j*Math.PI/2;gring(L.glow,x,y,r,info.col,4,a,0,TAU,j?0.55:0.85,rot);}
     const stamps:P[]=[[x-65,y],[x,y-41],[x+69,y],[x,y+41]];
     stamps.forEach((p,j)=>{const appear=P(t,1+j*0.45,3+j*0.42),retrace=P(t,6.15-j*0.25,7.0-j*0.17);if(appear>0){shard(L.front,...p,19,7,t+j,info.hi,a*(1-retrace));line(L.add,[p,[p[0]+(j%2?40:-40),p[1]+(j%2?20:-20)]],3,j%2?info.col:info.hi,a*Math.max(appear*0.4,retrace));}});
     break;}
   case 4: { // THE VORTEX DEFORMS WAVE FRONTS via angular displacement proportional to inward radius.
     const curl=1.7+couple*2.9;
     for(let j=0;j<7;j++){const travel=P(t,0.4+j*0.39,6.25),radius=18+travel*r*1.25;const pp=sample(u=>{const ang=u*TAU+curl*(1-radius/(r*1.4))+j*0.29+t*0.1;return [x+Math.cos(ang)*radius,y+Math.sin(ang)*radius*YS] as P;},64);
       ribbon(L.glow,pp,3+j%3,j%2?info.col:info.hi,a*(1-travel*0.5));}
     for(let k=0;k<9;k++){const p=polar(center,r*(1-release*0.7),t*2+k*TAU/9);line(L.add,[p,center],1,info.hi,a*couple*0.4);}disc(L.dark,x,y,16+couple*20,0x03051a,a);break;}
   case 5: { // FIBER CELLS: actual rows/columns define guided photons; bending fabric moves both flow and light.
     const rows=10,columns=10,span=116,h=65;for(let j=0;j<=rows;j++){const v=j/rows,yy=y-h+2*h*v,bend=Math.sin(t*1.3+j*0.33)*14*couple;line(L.front,[[x-span,yy],[x,yy+bend],[x+span,yy]],2,PALETTE[j%7],a*0.8);}
     for(let j=0;j<=columns;j++){const u=j/columns,xx=x-span+2*span*u;line(L.glow,[[xx,y-h],[xx+Math.sin(t+j)*8*couple,y],[xx,y+h]],1,info.hi,a*0.45);}
     for(let j=0;j<7;j++){const u=(t*0.37+j/7)%1,row=Math.floor(u*rows),v=u*rows-row,pos:P=[x-span+((j+1)/8)*2*span,y-h+row/rows*2*h];
       const end:P=[pos[0]+Math.sin(t+j)*v*15,pos[1]+v*2*h/rows];ribbon(L.add,[pos,end],8,PALETTE[j],a);sparkle(L.add,...end,6,PALETTE[j],a);}
     if(t>5.0)for(let j=0;j<7;j++)arcBlade(L.add,x,y,100,j*0.23+release,j*0.23+release+1.4,0.08,PALETTE[j],a*release);break;}
   case 6: { // soul cores EMBEDDED in a moving butterfly swarm: same entity changes both wing & particle state
     for(let j=0;j<52;j++){const u=P(t,0.2+j*0.02,6.9),ang=j*2.39996+t*(0.25+(j%4)*0.04),dist=(16+Math.sqrt(j/52)*r)* (1-release*0.45);const p=polar(center,dist,ang),charge=Math.pow(Math.max(0,Math.sin(t*2+j*0.48)),4),wing=2+charge*5;
       diamond(L.add,p[0]-wing,p[1],2.5*wing,wing,ang+0.4,info.col,a);diamond(L.add,p[0]+wing,p[1],2.5*wing,wing,ang-0.4,info.hi,a);if(j%5===0)star(L.add,...p,6+charge*7,5,0.4,ang,PALETTE[j%7],a*u);
     }break;}
   case 7: { // puppet strings REPOSITION spectral soldiers; line tension and soldier path share coordinates.
     const groups=2;for(let army=0;army<groups;army++){const anchor:P=[x+(army?-85:85),y-85];diamond(L.add,...anchor,18,4,t,info.hi,a);
      for(let j=0;j<7;j++){const u=P(t,0.55+j*0.25,6.6),side=army?-1:1;const p:P=[x+side*(103-110*u),y+side*(52-25*u)+(j-3)*8];
        line(L.glow,[anchor,[p[0]+side*12,p[1]-22],[p[0],p[1]-6]],2,info.col,a*(0.35+couple*0.65));diamond(L.front,p[0],p[1]-5,21,8,0,info.col,a*0.7);disc(L.add,p[0],p[1]-12,4,info.hi,a);}
     }break;}
   case 8: { // the skeletal RIBS ITSELF are the gates; their heartbeats change aperture geometry
     const beat=Math.pow(Math.max(0,Math.sin(t*TAU*0.72)),5),radius=17+build*30+beat*14-couple*release*19;
     for(let j=0;j<12;j++){const a0=j*TAU/12,ring=polar(center,radius,a0);const p0=polar(center,radius+19*Math.sin(t+j),a0);ribbon(L.front,[ring,p0],8,info.col,a);diamond(L.add,...ring,13,5,a0+Math.PI/2,info.hi,a);}
     gring(L.add,x,y,radius+3,info.col,4,a);halo(L.glow,x,y,radius*1.8,info.col,0.42*a);disc(L.dark,x,y,radius-6,0x030314,a);for(let j=0;j<6;j++){const p=polar(center,radius+32,t*1.5+j*TAU/6);ribbon(L.glow,[p,polar(center,radius-7,t*1.5+j*TAU/6+0.5)],5,info.hi,a);}
     break;}
   case 9: { // a CAGE EDGE is a coloured conductor; pulse moves along its actual path and changes when vertices fold
     const n=5,pts=Array.from({length:n},(_,j)=>polar(center,r*(0.7-release*0.48),j*TAU/n+Math.PI/5+t*0.1));
     for(let j=0;j<n;j++){const next=pts[(j+1)%n];chainLine(L.front,[pts[j],next],10,info.col,2,info.hi);const u=(t*0.65+j/n)%1;const pos:P=[lerp(pts[j][0],next[0],u),lerp(pts[j][1],next[1],u)];ribbon(L.glow,[pts[j],pos],5,PALETTE[j%7],a*couple);star(L.add,...pos,8,5,0.38,t,PALETTE[j%7],a);if(release>0)ribbon(L.add,[pos,center],3,PALETTE[j%7],a*release);}
     break;}
   case 10: { // anchored HARPOON well curves EVERY falling meteor, then reversed torque ejects a drill
     const torque=(1-release)*2.6-release*3.9;
     chainLine(L.front,[[x-110,y+58],[x-65,y+30],center],10,info.col,3,info.hi);
     for(let j=0;j<6;j++){const start=j*0.48+0.6,u=P(t,start,6.6),ang=j*TAU/6+torque*u*2.8,dist=r*(1-u*0.89),p=polar(center,dist,ang);const tail=sample(v=>polar(center,r*(1-(u-v*0.16)*0.89),j*TAU/6+torque*(u-v*0.16)*2.8),14);
       ribbon(L.glow,tail,5,info.col,a);shard(L.add,...p,15,6,ang+Math.PI/2,info.hi,a);}
     if(release>0){const spiral=sample(v=>polar(center,r*release*v,torque*2.8+v*TAU*2.5),40);ribbon(L.add,spiral,10*release,info.hi,a);}
     disc(L.dark,x,y,18+build*15,0x0c0814,a);gring(L.add,x,y,20+build*17,info.hi,2,a);
     break;}
  }
  if(t>1.1 && t<last-1.1 && rr(0,1)<0.8) {
    const ang=rr(0,TAU),dist=rr(20,r*1.4);
    c.emit('add',{tex:i===6?'wing':i===8?'bone':'spark',x:x+Math.cos(ang)*dist,y:y+Math.sin(ang)*dist*YS,z:rr(0,20),vx:rr(-66,66),vy:rr(-53,53),life:rr(0.35,1.3),size:rr(2,7),size1:1,c0:info.col,c1:info.hi,drag:1.5});
  }
  if(t>3&&t<7)c.darken(0.10+couple*0.14);
  void dt;
 });
}
export function v2FusionSkills():Skill[]{return INFOS.map((info,i)=>({id:i+302,name:info.name,relic:['halo','chain','halo','halo','chain','fan','fan','spindle','chain','chain','halo'][i],kind:'fusion',sub:`V2 coupled mechanisms · ${info.why}`,dur:info.dur,phases:[[0,'Initiation'],[2.15,'Mechanisms couple'],[4.7,'Transformation'],[6.5,'Linked impacts'],[info.dur-1.1,'Release / residue']],setup:(c:Ctx)=>install(c,i)}));}
