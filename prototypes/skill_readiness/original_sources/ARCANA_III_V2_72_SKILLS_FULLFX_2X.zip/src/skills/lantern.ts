// SOUL LANTERN — impossible living darkness unfolding into spectral apocalypse.
import { Ctx, Skill } from '../engine/core';
import {
  CX, H, P, TAU, W, YS, bez2, clamp, dist, ease, hash1, hash2, lerp, mix, prog, rand, ramp, rr, sample, sstep, vnoise,
} from '../engine/util';
import { arcBlade, diamond, disc, glyph, gring, hiRamp, line, magicSeal, ngon, pixelBolt, poly, ribbon, ringPts, rotRect, sector, shadeRamp, shard, star } from '../engine/draw';
import { crackScar, debris, halo, pillar, ringScar, slashLine, slashX, sparkle } from '../engine/fx';
import { stampOn } from '../engine/sprites';

const GH = 0xbfe9ff, CYA = 0x4fd8ff, DEEP = 0x0a3a5a, GOLD = 0xffd27a, WH = 0xffffff, VIO = 0x7a5aff;
const GF = [0x9fe8ff, 0x4fd8ff, 0xe8fbff];

// A Hollow King: pixel-art crowned wraith monarch sprite + layered ghostly afterimages + war-banner + pale soulfire
function king(c: Ctx, x: number, y: number, s: number, t: number, a: number, dir: number, stretch: number, seed: number, col = GH) {
  if (a <= 0.02) return;
  const L = c.L;
  const P_ = (px: number, py: number): P => [x + px * s * dir, y + py * s];
  const bob = Math.sin(t * 2.5 + seed) * 1.5;
  // Trailing ghostly echo + main pixel-art Hollow King wraith sprite
  stampOn(L.add, 'hollow_king', x - dir * (6 + stretch * 14), y - 18 * s + bob, { sx: s * 1.3 * dir, sy: s * 1.3, tint: CYA, alpha: a * 0.38, add: true });
  stampOn(L.front, 'hollow_king', x, y - 18 * s + bob, { sx: s * 1.35 * dir, sy: s * 1.35, tint: col, alpha: a * 0.88, add: false });
  stampOn(L.add, 'hollow_king', x, y - 18 * s + bob, { sx: s * 1.35 * dir, sy: s * 1.35, tint: WH, alpha: a * 0.45, add: true });
  // War-banner on halberd pole
  const pole0 = P_(10, 0), pole1 = P_(10, -48);
  line(L.add, [pole0, pole1], 1, WH, a * 0.8);
  const flag: P[] = [];
  for (let k = 0; k <= 7; k++) flag.push([pole1[0] - dir * k * 3.8 * s * (1 + stretch), pole1[1] + 2 * s + Math.sin(t * 6 - k * 0.8 + seed) * 2.5 * s + k * 0.5 * s]);
  ribbon(L.add, flag, (i, n) => 9 * s * (1 - (i / n) * 0.65), col, a * 0.7);
  if (rand() < 0.35) c.emit('add', { tex: 'flame', x: x + rr(-5, 5), y: y - 28 * s, vx: rr(-8, 8), vy: rr(-35, -10), life: rr(0.4, 0.9), size: 4, c0: WH, c1: CYA });
}

// ============================================================ 17 PROCESSION OF HOLLOW KINGS
function s17(c: Ctx) {
  const EC: P = [372, 168];
  c.layout([[322, 128], [356, 200], [402, 126], [424, 196], [310, 212]]);
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  c.seg(0, 4.2, (u) => [lerp(36, 190, u), 186 + Math.sin(u * 9) * 1.5], ease.lin);
  c.seg(4.4, 5.1, (u) => [lerp(190, 408, u), lerp(186, 164, u)], ease.outExpo);
  c.seg(5.1, 14, () => [408, 164]);
  c.caster.trail = CYA;
  const K = 15;
  const ks = Array.from({ length: K }, (_, j) => ({ rank: Math.floor(j / 5), lat: (j % 5) - 2, ta: 0.7 + j * 0.2, seed: j * 1.7, ex: 0, hist: [] as P[], hit: new Set<number>() }));
  const base = (k: (typeof ks)[number], xf: number): P => [xf - 34 - k.rank * 38 - Math.abs(k.lat) * 10, 186 + k.lat * 28 * (1 + k.rank * 0.12)];
  const foot: { x: number; y: number; t: number }[] = [];
  const souls: { x: number; y: number; vx: number; vy: number; l: number; ph: number }[] = [];
  c.each((t, dt) => {
    const L = c.L;
    const xf = c.caster.x;
    const surge = ease.out(prog(t, 4.4, 5.6));
    const stop = t > 6.0;
    c.darken(0.5 * sstep(0.6, 3, t) * (t < 8.3 ? 1 : 1 - prog(t, 8.3, 10)));
    if (t < 6.1 && Math.floor(t * 3.2) !== Math.floor((t - dt) * 3.2) && t < 4.2) foot.push({ x: c.caster.x, y: c.caster.y + (foot.length % 2 ? 2 : -2), t });
    ks.forEach((k, j) => {
      if (t < k.ta) return;
      let [x, y] = base(k, xf);
      const rise = ease.out(prog(t, k.ta, k.ta + 1.0));
      // ground shadow the king emerges from
      L.mark.ellipse(x, y + 2, 24 * rise, 8 * rise).fill({ color: 0x000000, alpha: 0.55 * rise });
      gring(L.glow, x, y + 2, 22 * rise, CYA, 1, 0.35 * (1 - rise * 0.5), 0, TAU, YS);
      let alpha = rise * (0.9 - k.rank * 0.18), stretch = 0;
      if (t >= 4.4 && t < 6.6) {
        // the surge: front ranks become bright streaks, rear ranks lag and remain partly visible
        const lag = 1 - k.rank * 0.2;
        const d = 250 * ease.outExpo(prog(t, 4.4 + k.rank * 0.09, 5.4 + k.rank * 0.12)) * lag;
        x += d;
        stretch = clamp(1 - Math.abs(prog(t, 4.4, 5.6) - 0.5) * 2, 0, 1) * (1 - k.rank * 0.25) * 1.2 + 0.0;
        const e = ease.outExpo(prog(t, 4.4, 5.4));
        void e;
      }
      if (t >= 5.4 && t < 6.2) x += 250 * (1 - k.rank * 0.2);
      const converge = ease.io(prog(t, 6.5, 8.1));
      let tx = x, ty = y;
      if (t >= 6.2) {
        // curve around the remaining enemies and converge from several directions
        const st: P = [clamp(base(k, xf)[0] + 250 * (1 - k.rank * 0.2), 40, 450), y];
        const ang = Math.atan2(st[1] - EC[1], st[0] - EC[0]) + (j % 2 ? 1 : -1) * 1.7 * (1 - converge);
        const rad = lerp(dist(st[0], st[1], EC[0], EC[1]) + 30, 6, ease.in(converge));
        tx = EC[0] + Math.cos(ang) * rad * 1.1; ty = EC[1] + Math.sin(ang) * rad * 0.65;
        x = tx; y = ty;
      }
      // enemies struck by passing front ranks
      if (t >= 4.4 && t < 6.1) c.enemies.forEach((e, i) => {
        if (!k.hit.has(i) && Math.abs(e.x - x) < 14 && Math.abs(e.y - y) < 24 && k.rank < 3) {
          k.hit.add(i);
          if (c.enemies[i].flash < 0.5) { c.strike(e, Math.atan2(e.y - y, 1) * 0.6 + (j % 2 ? -0.5 : 0.5), 120, 70, CYA, 9); c.burst('add', e.x, e.y - 10, 16, { spd: [20, 100], life: [0.5, 1], cols: GF, ay: -40, drag: 2 }); c.ent(0.4, (_a, u) => { for (let q = 0; q < 5; q++) { const a = q * 1.26 + j; line(c.L.add, [[e.x, e.y - 10], [e.x + Math.cos(a) * 24 * ease.out(u), e.y - 10 + Math.sin(a) * 24 * ease.out(u)]], 2, WH, 1 - u); } }); }
        }
      });
      k.hist.push([x, y - 24]);
      if (k.hist.length > 22) k.hist.shift();
      const m = clamp(converge * 1.4 - 0.2);
      if (t >= 6.3 && k.hist.length > 2) {
        const hs = k.hist.slice().reverse();
        ribbon(L.add, hs, (i, n) => (4 + 16 * m) * (1 - i / n), CYA, 0.45 * m);
        ribbon(L.add, hs, (i, n) => (1 + 6 * m) * (1 - i / n), WH, 0.8 * m);
      }
      if (t < 8.0 || t >= 8.0) king(c, x, y, 1.9 - k.rank * 0.15, t, alpha * (1 - m) * (t > 8 ? 0 : 1), t >= 6.2 ? (EC[0] > x ? 1 : -1) : 1, stretch, k.seed);
      if (stretch > 0.3) { ribbon(L.add, [[x - 60 * stretch, y - 22], [x, y - 22]], (i, n) => 10 * (i / n), CYA, 0.5 * alpha); line(L.add, [[x - 80 * stretch, y - 22], [x, y - 22]], 2, WH, 0.8 * alpha); }
    });
    // enemies: dragged into the converging ring
    if (t > 6.6 && t < 8.1) { const k = ease.io(prog(t, 6.6, 8.0)); c.enemies.forEach((e, i) => { e.pin(lerp(e.x, EC[0] + Math.cos(i * 1.26 + t * 2) * 22, k * 0.22), lerp(e.y, EC[1] + 8 + Math.sin(i * 1.26 + t * 2) * 12, k * 0.22), 6 + 18 * k, 0.2 * Math.sin(t * 9 + i)); e.shakeAmt = 0.6 * k; e.outline = 0.7; }); }
    // crown-shaped eruption of blue-white flame
    if (t >= 8.1 && t < 10.2) {
      const u = prog(t, 8.1, 10.2), grow = ease.outExpo(Math.min(1, u * 4)), f = 1 - sstep(0.4, 1, u);
      const R = 46 * grow;
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * TAU, bx = EC[0] + Math.cos(a) * R, by = EC[1] + 6 + Math.sin(a) * R * YS;
        const hgt = (i % 2 ? 78 : 118) * grow * (0.85 + 0.15 * Math.sin(t * 12 + i * 2)), w = 9 * f + 2;
        const tip: P = [bx + Math.sin(t * 9 + i) * 4, by - hgt];
        poly(L.add, [[bx - w, by], [bx - w * 0.3, by - hgt * 0.6], tip, [bx + w * 0.3, by - hgt * 0.55], [bx + w, by]], CYA, 0.75 * f);
        poly(L.add, [[bx - w * 0.5, by], [bx, by - hgt * 0.75], [bx + w * 0.5, by]], GH, 0.9 * f);
        poly(L.add, [[bx - w * 0.2, by], [bx, by - hgt * 0.45], [bx + w * 0.2, by]], WH, f);
        c.emit('add', { x: tip[0], y: tip[1], vx: rr(-12, 12), vy: rr(-40, -10), life: rr(0.5, 1.2), size: 1, c0: WH, c1: CYA });
      }
      gring(L.add, EC[0], EC[1] + 6, R, WH, 3, f, 0, TAU, YS); gring(L.add, EC[0], EC[1] + 6, R + 4, CYA, 3, 0.6 * f, 0, TAU, YS);
      halo(L.add, EC[0], EC[1] - 20, 90 * grow, GH, 0.35 * f, 0.9);
    }
    for (const s of souls) { s.l += dt; s.x += s.vx * dt + Math.sin(s.l * 2 + s.ph) * 6 * dt; s.y += s.vy * dt; s.vy *= 0.995; const a = 1 - prog(s.l, 2.5, 4.5); if (a > 0) { disc(L.add, s.x, s.y, 1.6, WH, a); halo(L.add, s.x, s.y, 5, CYA, 0.4 * a, 1); } }
    // footprints and fallen banners
    c.each(() => {});
  });
  c.at(8.1, () => {
    c.flash(WH, 1); c.shake(14); c.slow(0.35, 0.3);
    c.blast(EC[0], EC[1], 260, 280, 170);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - EC[1] + rr(-10, 10), e.x - EC[0] + rr(-10, 10)), 270, 170, CYA, 12));
    [70, 150, 260].forEach((r, i) => c.shock(EC[0], EC[1] + 6, { r, life: 0.9 + i * 0.25, col: CYA, col2: WH, w: 5, amp: 5 }));
    for (let i = 0; i < 90; i++) souls.push({ x: EC[0] + rr(-60, 60), y: EC[1] + rr(-40, 20), vx: rr(-40, 40), vy: rr(-70, -15), l: 0, ph: rr(0, TAU) });
    for (let i = 0; i < 140; i++) { const a = rr(0, TAU), s = rr(40, 260); c.emit('add', { x: EC[0], y: EC[1], z: rr(0, 20), vx: Math.cos(a) * s, vy: Math.sin(a) * s * YS, vz: rr(40, 200), gz: 120, life: rr(0.8, 1.9), size: 1, c0: GF[i % 3], c1: DEEP, drag: 1.2 }); }
    ringScar(c, EC[0], EC[1], 50, 6, CYA, 2);
    crackScar(c, EC[0], EC[1], 8, 90, 6, CYA);
    c.scar(6, (g, a, age) => {
      for (let i = 0; i < foot.length; i++) { const f = foot[i]; if (i % 1 === 0) { g.mark.ellipse(f.x, f.y + 3, 3, 1.6).fill({ color: 0x0a2a3a, alpha: 0.5 * a }); g.glow.ellipse(f.x, f.y + 3, 2, 1).fill({ color: CYA, alpha: 0.5 * a * (0.6 + 0.4 * Math.sin(age * 3 + i)) }); } }
      for (let b = 0; b < 6; b++) { const x = 90 + b * 55, y = 190 + (b % 3) * 14 - 20; line(g.glow, [[x, y], [x + 28, y - 3]], 1, GH, 0.5 * a); poly(g.glow, [[x + 28, y - 3], [x + 40, y - 8], [x + 36, y + 3]], CYA, 0.3 * a); }
    });
  });
}

// ============================================================ 18 FUNERAL FIREWORKS
function s18(c: Ctx) {
  c.layout([[196, 152], [268, 196], [338, 132], [392, 190], [226, 226]]);
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  const route: P[] = [[34, 200], [120, 150], [200, 215], [290, 140], [370, 205], [440, 160]];
  const SW = [0.8, 1.7, 2.6, 3.5, 4.4];
  c.seg(0.2, 5.6, (u) => { const f = u * 5, i = Math.min(4, Math.floor(f)), t = f - i; return [lerp(route[i][0], route[i + 1][0], t), lerp(route[i][1], route[i + 1][1], ease.io(t)) + Math.sin(t * Math.PI * 2) * 12]; }, ease.lin);
  c.seg(5.6, 6.1, () => [440, 160]);
  c.seg(6.1, 6.7, () => [440, 160, 12 * 1]);
  c.seg(6.7, 14, () => [440, 160, 16]);
  c.caster.trail = CYA;
  const FC: P[] = [[84, 62], [170, 42], [250, 72], [330, 44], [410, 66]];
  // formation layouts (point sets in sky)
  const layouts: P[][] = [
    Array.from({ length: 28 }, (_, i) => { const a = i * 2.4, r = 6 + i * 1.4; return [FC[0][0] + Math.cos(a) * r, FC[0][1] + Math.sin(a) * r * 0.85] as P; }),
    Array.from({ length: 30 }, (_, i) => { const arm = i % 6, k = Math.floor(i / 6) + 1; const a = (arm / 6) * TAU - Math.PI / 2; return [FC[1][0] + Math.cos(a) * k * 7, FC[1][1] + Math.sin(a) * k * 7] as P; }),
    Array.from({ length: 26 }, (_, i) => { const u = i / 25; return [FC[2][0] - 40 + u * 80, FC[2][1] + Math.sin(u * 7) * 18 + (i % 2 ? 4 : -4)] as P; }),
    (() => { const pts: P[] = []; const rec = (x: number, y: number, a: number, l: number, d: number) => { if (d === 0) return; const nx = x + Math.cos(a) * l, ny = y + Math.sin(a) * l; for (let k = 0; k < 3; k++) pts.push([lerp(x, nx, (k + 1) / 3), lerp(y, ny, (k + 1) / 3)]); rec(nx, ny, a - 0.5, l * 0.7, d - 1); rec(nx, ny, a + 0.5, l * 0.7, d - 1); }; rec(FC[3][0], FC[3][1] + 38, -Math.PI / 2, 16, 4); return pts.slice(0, 32); })(),
    Array.from({ length: 30 }, (_, i) => { const a = (i / 30) * TAU, r = i % 2 ? 36 : 18; return [FC[4][0] + Math.cos(a) * r, FC[4][1] + Math.sin(a) * r * 0.9] as P; }),
  ];
  type Soul = { f: number; i: number; t0: number; from: P; ctrl: P; to: P; fl: number; hist: P[]; arrived: boolean };
  const souls: Soul[] = [];
  layouts.forEach((lay, f) => lay.forEach((to, i) => souls.push({ f, i, t0: SW[f] + i * 0.022, from: [0, 0], ctrl: [0, 0], to, fl: 1.4, hist: [], arrived: false })));
  const BL = [4.0, 4.6, 5.2, 5.8, 6.4].map((x) => x + 2.6);
  const bloomAt = (f: number) => 6.8 + f * 0.4;
  const frags: { x: number; y: number; from: P; to: P; ctrl: P; t0: number; dur: number; f: number; tgt: number; hist: P[]; done: boolean }[] = [];
  const marks: P[] = [[130, 215], [200, 118], [300, 232], [350, 100], [270, 150]];
  const tgtPos = (f: number): P => (f < 5 ? [home[f][0], home[f][1]] : marks[f - 5]);
  void BL;
  c.each((t, dt) => {
    const L = c.L;
    c.darken(0.3 * sstep(0.5, 3, t));
    // ascending souls leave long trails; launch point follows the swinging lantern
    for (const s of souls) {
      if (t < s.t0) continue;
      if (s.from[0] === 0) {
        s.from = [c.caster.x + rr(-5, 5), c.caster.y - 10];
        const side = s.f % 2 ? 1 : -1;
        s.ctrl = [s.from[0] + side * (40 + (s.i % 7) * 8), s.from[1] - 70 - (s.i % 5) * 12];
      }
      const u = clamp((t - s.t0) / s.fl);
      const e = ease.out(u);
      let p = bez2(s.from, s.ctrl, s.to, e);
      if (s.f === 0) { const a = u * 7 + s.i * 0.3; p = [p[0] + Math.cos(a) * 8 * (1 - u), p[1] + Math.sin(a) * 8 * (1 - u)]; } // spirals
      if (s.f === 3) p = [p[0] + Math.sin(u * 10 + s.i) * 4 * (1 - u), p[1]];
      s.hist.push(p); if (s.hist.length > (u < 1 ? 16 : 3)) s.hist.shift();
      s.arrived = u >= 1;
      const hover = u >= 1 && t < bloomAt(s.f) ? [Math.sin(t * 2 + s.i) * 1.2, Math.cos(t * 1.6 + s.i) * 1.2] : [0, 0];
      const px = p[0] + hover[0], py = p[1] + hover[1];
      if (t < bloomAt(s.f)) {
        if (s.hist.length > 2) { ribbon(L.sky, s.hist.slice().reverse(), (i, n) => 3 * (1 - i / n), GF[s.i % 3], 0.5); }
        disc(L.sky, px, py, 1.6, WH, 1); halo(L.sky, px, py, 5, CYA, 0.35, 1);
        // outline enemies in passing light
        c.enemies.forEach((e2) => { if (u < 1 && dist(p[0], p[1], e2.x, e2.y - 10) < 38) { e2.outline = 0.9; e2.outlineCol = GH; } });
      }
    }
    c.enemies.forEach((e) => { if (e.outline > 0) e.outline = Math.max(0, e.outline - dt * 1.5); });
    // dark under each ascending formation; constellation links
    for (let f = 0; f < 5; f++) {
      const g = prog(t, SW[f] + 0.3, SW[f] + 1.6) * (1 - prog(t, bloomAt(f), bloomAt(f) + 0.6));
      if (g > 0) { L.mark.ellipse(FC[f][0], 170, 50 * g, 22 * g).fill({ color: 0, alpha: 0.4 * g }); gring(L.glow, FC[f][0], 170, 50 * g, CYA, 1, 0.3 * g, 0, TAU, 0.45); }
      if (f === 1 || f === 2 || f === 3) {
        const lay = layouts[f];
        const arr = souls.filter((s) => s.f === f);
        if (t < bloomAt(f) && arr.every((s) => s.arrived)) for (let i = 0; i < lay.length - 1; i += (f === 3 ? 1 : f === 1 ? 6 : 1)) { if (f === 1 && i + 6 >= lay.length) break; const j = f === 1 ? i + 6 : i + 1; line(L.sky, [lay[i], lay[j]], 1, GH, 0.3); }
      }
    }
    // the bloom
    for (let f = 0; f < 5; f++) {
      const u = prog(t, bloomAt(f), bloomAt(f) + 1.4);
      if (u <= 0 || u >= 1) continue;
      const k = ease.outExpo(Math.min(1, u * 2.2)), a = 1 - sstep(0.5, 1, u), [x, y] = FC[f];
      halo(L.sky, x, y, 50 * k, GH, 0.25 * a, 1);
      if (f === 0) for (let p = 0; p < 9; p++) { const ang = (p / 9) * TAU + u * 1.2, R = 52 * k; const pts = sample((s) => { const w = Math.sin(s * Math.PI) * 11 * k; return [x + Math.cos(ang) * R * s + Math.cos(ang + 1.57) * w, y + Math.sin(ang) * R * s * 0.85 + Math.sin(ang + 1.57) * w * 0.85] as P; }, 12); line(L.sky, [...pts, [x, y]], 2, p % 2 ? CYA : WH, a); poly(L.sky, pts, CYA, 0.15 * a); }
      if (f === 1) { for (let p = 0; p < 6; p++) { const ang = (p / 6) * TAU - Math.PI / 2, R = 50 * k; line(L.sky, [[x, y], [x + Math.cos(ang) * R, y + Math.sin(ang) * R]], 3, GH, a); for (let q = 1; q < 5; q++) { const d = (q / 5) * R, nx = Math.cos(ang + 1.57), ny = Math.sin(ang + 1.57); line(L.sky, [[x + Math.cos(ang) * d - nx * 5, y + Math.sin(ang) * d - ny * 5], [x + Math.cos(ang) * d + nx * 5, y + Math.sin(ang) * d + ny * 5]], 1, WH, a); } } disc(L.sky, x, y, 9 * k, WH, a * 0.9); disc(L.front, x - 3, y - 1, 1.6, 0x04101c, a); disc(L.front, x + 3, y - 1, 1.6, 0x04101c, a); L.sky.rect(x - 2, y + 3, 4, 1).fill({ color: 0x04101c, alpha: a }); }
      if (f === 2) for (let p = 0; p < 5; p++) { const pts = sample((s) => { const ang = p * 1.256 + s * 3.2 + u * 2, r = s * 56 * k; return [x + Math.cos(ang) * r, y + Math.sin(ang) * r * 0.85] as P; }, 22); ribbon(L.sky, pts, (i, n) => 7 * Math.sin((i / n) * Math.PI) + 1, 0xff9a4a, 0.5 * a); ribbon(L.sky, pts, (i, n) => 3 * Math.sin((i / n) * Math.PI), GOLD, 0.8 * a); line(L.sky, pts, 1, WH, a); }
      if (f === 3) { const rec = (px: number, py: number, ang: number, l: number, d: number, g: number) => { if (d === 0 || g <= 0) return; const gg = Math.min(1, g), nx = px + Math.cos(ang) * l * gg, ny = py + Math.sin(ang) * l * gg; line(L.sky, [[px, py], [nx, ny]], d * 0.7 + 0.5, d > 2 ? WH : GH, a); disc(L.sky, nx, ny, 1.4, WH, a); rec(nx, ny, ang - 0.5, l * 0.72, d - 1, g * 1.6 - 0.5); rec(nx, ny, ang + 0.5, l * 0.72, d - 1, g * 1.6 - 0.5); }; rec(x, y + 30, -Math.PI / 2, 24, 5, k * 1.1); }
      if (f === 4) for (let p = 0; p < 36; p++) { const ang = (p / 36) * TAU, r0 = 10, r1 = 18 + 44 * k * (0.7 + 0.3 * hash1(p)); const sag = 14 * u * u; line(L.sky, [[x + Math.cos(ang) * r0, y + Math.sin(ang) * r0 * 0.85], [x + Math.cos(ang) * r1, y + Math.sin(ang) * r1 * 0.85 + sag]], 1.5, p % 3 ? GOLD : WH, a); sparkle(L.sky, x + Math.cos(ang) * r1, y + Math.sin(ang) * r1 * 0.85 + sag, 3, p % 2 ? CYA : WH, a, p); }
    }
    // fragments descend toward a visible enemy or ground marker
    for (const fr of frags) {
      if (t < fr.t0 || fr.done) continue;
      const u = clamp((t - fr.t0) / fr.dur), e = ease.in(u);
      const p = bez2(fr.from, fr.ctrl, fr.to, e);
      fr.hist.push(p); if (fr.hist.length > 10) fr.hist.shift();
      if (fr.hist.length > 2) ribbon(L.sky, fr.hist.slice().reverse(), (i, n) => 3 * (1 - i / n), fr.f % 2 ? CYA : GOLD, 0.7);
      disc(L.sky, p[0], p[1], 1.8, WH, 1);
      if (rand() < 0.5) c.emit('add', { x: p[0], y: p[1], vx: rr(-10, 10), vy: rr(5, 25), life: 0.5, size: 1, c0: fr.f % 2 ? GH : GOLD, c1: DEEP });
      if (u >= 1) { fr.done = true; impact(fr.f, fr.to); }
    }
    // ground markers waiting for the rain
    for (let f = 0; f < 5; f++) { const g = prog(t, bloomAt(f), bloomAt(f) + 0.5) * (1 - prog(t, bloomAt(f) + 2.6, bloomAt(f) + 3.2)); if (g > 0) { gring(L.glow, marks[f][0], marks[f][1], 14 * g, GOLD, 1, 0.8 * g, 0, TAU, YS, t); gring(L.glow, marks[f][0], marks[f][1], 8 * g, CYA, 1, 0.8 * g, 0, TAU, YS, -t); } }
    // souls returning to the lantern
    const ret = prog(t, 10.4, 12.2);
    if (ret > 0) for (const s of souls) { if (s.hist.length === 0) continue; const k = ease.in(clamp(ret * 1.3 - (s.i % 10) * 0.03)); const last = s.hist[s.hist.length - 1]; const p: P = bez2(last, [last[0] + (s.f - 2) * 30, last[1] + 80], [c.caster.x, c.caster.y - 14], k); if (k < 1 && s.i % 2 === 0) { disc(L.sky, p[0], p[1], 1.4, WH, 1 - k * 0.5); halo(L.sky, p[0], p[1], 4, CYA, 0.3, 1); } }
    c.enemies.forEach((e, i) => { if (t > 6.9 && t < 9.5) e.pin(home[i][0], home[i][1], 0, 0); });
  });
  function impact(f: number, p: P) {
    const [x, y] = p, col = f % 2 ? CYA : GOLD;
    c.burst('add', x, y, 6, { spd: [20, 100], life: [0.3, 0.8], cols: [col, WH], ys: YS, vz: [20, 90], gz: 300, drag: 1.5 });
    c.enemies.forEach((e, i) => {
      if (dist(e.x, e.y, x, y) < 14) {
        c.strike(e, rr(-1, 1) + (i % 2 ? Math.PI : 0), 70, 90, col, 8);
        c.ent(0.5, (_a, u) => { gring(c.L.add, x, y, 6 + 30 * ease.out(u), col, 2, 1 - u, 0, TAU, YS); if (f % 5 === 2) pillar(c.L.add, x, y, 70 * (1 - u), 6 * (1 - u) + 1, col, 1 - u); });
      }
    });
  }
  SW.forEach((s) => c.at(s, () => {
    c.ent(0.4, (_a, u) => { const a = u * 3.4 - 0.2; arcBlade(c.L.add, c.caster.x, c.caster.y - 8, 22, a - 0.8, a + 0.8, 0.5, CYA, 1 - u, 0.8); });
    c.burst('add', c.caster.x, c.caster.y - 10, 18, { spd: [20, 110], life: [0.4, 0.9], cols: GF, ay: -30, drag: 2 });
  }));
  c.at(6.1, () => { c.flash(GH, 0.4); c.shock(440, 164, { r: 70, life: 0.7, col: CYA, w: 3, amp: 3 }); });
  for (let f = 0; f < 5; f++) c.at(bloomAt(f), () => {
    c.flash(f % 2 ? CYA : GOLD, 0.25); c.shake(3);
    c.shock(FC[f][0], 120, { r: 80, life: 0.8, col: f % 2 ? CYA : GOLD, w: 3, amp: 3, ys: 1 });
    const tg = [f, (f + 1) % 5 + 5 > 9 ? 5 : ((f + 2) % 5) + 5];
    for (let i = 0; i < 14; i++) {
      const target = i % 2 ? tgtPos(5 + (f % 5)) : tgtPos(f);
      const a = rr(0, TAU), start: P = [FC[f][0] + Math.cos(a) * rr(10, 40), FC[f][1] + Math.sin(a) * rr(10, 30)];
      frags.push({ x: 0, y: 0, from: start, to: [target[0] + rr(-6, 6), target[1] + rr(-3, 3) - 4], ctrl: [start[0] + (target[0] - start[0]) * 0.3 + rr(-50, 50), start[1] - 20 + rr(-10, 10)], t0: c.t + 1.0 + i * 0.07, dur: rr(0.9, 1.2), f, tgt: 0, hist: [], done: false });
    }
    void tg;
  });
  c.at(10.1, () => {
    c.flash(0xe8f6ff, 1); c.shake(10); c.slow(0.4, 0.2);
    [90, 190, 300].forEach((r, i) => c.shock(CX, 170, { r, life: 1.2 + i * 0.25, col: i % 2 ? GOLD : CYA, w: 5, amp: 4 }));
    c.ent(1.8, (_a, u) => { halo(c.L.add, CX, 150, 300, 0x4a9aff, 0.18 * (1 - u), 0.7); halo(c.L.add, CX, 150, 180, GOLD, 0.16 * (1 - u), 0.7); });
    c.burst('add', CX, 150, 120, { spd: [60, 300], life: [0.8, 1.8], cols: [GOLD, CYA, WH], drag: 1.3, ys: YS });
    c.enemies.forEach((e) => { e.flash = 1; });
  });
}

// ============================================================ 19 THE DROWNED CHOIR
function s19(c: Ctx) {
  const C: P = [CX, 172];
  c.layout([[300, 150], [340, 190], [190, 200], [150, 160], [250, 118], [330, 120]]);
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  c.seg(0, 2.2, (u) => [lerp(34, CX, u), lerp(214, 176, u)], ease.out);
  c.seg(2.2, 7.0, () => [CX, 176]);
  c.seg(7.0, 7.6, () => [CX, 176, 18 * 1], ease.out);
  c.seg(7.6, 8.4, () => [CX, 176, 18]);
  c.seg(8.5, 9.0, () => [CX, 176, 0], ease.in);
  c.caster.trail = CYA;
  const choirs = [
    { R: 46, n: 6, w: 0.36, t0: 1.6, k: 0.22, om: 3.1, per: 1.8 },
    { R: 90, n: 9, w: -0.27, t0: 2.5, k: 0.17, om: 2.5, per: 2.4 },
    { R: 134, n: 12, w: 0.2, t0: 3.5, k: 0.13, om: 2.0, per: 3.1 },
  ];
  const sync = ease.io(prog(7.0, 7.0, 7.6));
  void sync;
  const ghostPos = (ch: (typeof choirs)[number], i: number, t: number): P => {
    const s = ease.io(prog(t, 7.0, 7.7)), fold = ease.io3(prog(t, 7.7, 8.5));
    let ang = (i / ch.n) * TAU + ch.w * (t - ch.t0) * (1 - s);
    if (s > 0) ang = lerp(ang, (i / ch.n) * TAU + 0.0, s * 0.0 + s * 0.0) ;
    const R = ch.R * (1 - fold * 0.92);
    return [C[0] + Math.cos(ang) * R, C[1] + Math.sin(ang) * R * 0.62];
  };
  const field = (x: number, y: number, t: number): number => {
    let sum = 0;
    const rel = prog(t, 8.5, 12.4);
    if (t < 8.5) {
      choirs.forEach((ch) => {
        const amp = ease.out(prog(t, ch.t0 + 0.6, ch.t0 + 2.0));
        if (amp <= 0) return;
        let s = 0;
        for (let i = 0; i < ch.n; i++) { const g = ghostPos(ch, i, t); const d = Math.hypot(x - g[0], (y - g[1]) / 0.62); s += Math.sin(ch.k * d * 3.2 - ch.om * t) / (1 + d * 0.012); }
        sum += (s / Math.sqrt(ch.n)) * amp;
      });
      return sum / 1.8;
    }
    const d = Math.hypot(x - C[0], (y - C[1]) / 0.62);
    return (Math.sin(0.16 * d - 6 * (t - 8.5)) * Math.exp(-d * 0.004) * (1 - rel) * (1 - ease.out(prog(d, 0, 520)) * (prog(t, 8.5, 9.2) < 1 ? 0 : 0)));
  };
  const ghost = (g: Ctx['L']['add'], x: number, y: number, s: number, t: number, _type: number, a: number, col: number, stretchLen = 0, ang = 0) => {
    if (a <= 0.02) return;
    const bob = Math.sin(t * 2.2 + x * 0.1) * 1.8;
    y += bob;
    if (stretchLen > 0) {
      line(g, [[x, y], [x + Math.cos(ang) * stretchLen, y + Math.sin(ang) * stretchLen * 0.62]], 3, col, a * 0.7);
      line(g, [[x, y], [x + Math.cos(ang) * stretchLen, y + Math.sin(ang) * stretchLen * 0.62]], 1, WH, a);
      return;
    }
    // Veiled pixel-art Choir Wraith sprite + glowing halo & water-spirit ribbons (no circle-head snowmen!)
    stampOn(g, 'choir_wraith', x, y - 9 * s, { sx: s * 1.15, sy: s * 1.15, tint: col, alpha: a * 0.92, add: true });
    for (const sd of [-1, 1]) {
      const rb: P[] = [];
      for (let k = 0; k <= 6; k++) rb.push([x + sd * (4 + k * 2.4) * s, y - 8 * s + Math.sin(t * 3.2 + k * 0.7 + sd) * 2.5 * s + k * 1.2 * s]);
      line(g, rb, 1, col, a * 0.55);
    }
  };
  const fil: { x: number; y: number; ang: number; l: number }[] = [];
  c.each((t, dt) => {
    const L = c.L;
    c.darken(0.35 * sstep(0.5, 3, t) * (t < 8.5 ? 1 : 1 - prog(t, 8.5, 11)));
    c.post.grade = [0.7, 1.05, 1.2, 0.22 * sstep(1, 4, t)];
    // ripples from the lantern
    [0.4, 1.0, 1.6].forEach((r0) => { const u = prog(t, r0, r0 + 1.6); if (u > 0 && u < 1) { gring(L.glow, c.caster.x, c.caster.y, 150 * ease.out(u), CYA, 2, 0.8 * (1 - u), 0, TAU, YS); c.distort(c.caster.x, c.caster.y, 150 * ease.out(u), 2 * (1 - u)); } });
    // Cymatic resonance mandala & interference crescents (replaces the old 5px dot-matrix grid)
    if (t > 1.8 && t < 8.6) {
      const aRes = sstep(1.8, 3.4, t) * (1 - sstep(8.2, 8.6, t));
      magicSeal(L.glow, C[0], C[1], 138, DEEP, t * 0.18, 0.45 * aRes, 0.62, 12);
      magicSeal(L.glow, C[0], C[1], 90, CYA, -t * 0.27, 0.55 * aRes, 0.62, 9);
      magicSeal(L.glow, C[0], C[1], 46, GH, t * 0.36, 0.65 * aRes, 0.62, 6);
      // Standing-wave interference crescents where choir ripples cross
      for (let m = 0; m < 12; m++) {
        const ang = (m / 12) * TAU + Math.sin(t * 1.4 + m) * 0.35;
        const rad = 52 + ((m * 23 + t * 38) % 92);
        const span = 0.28 + 0.14 * Math.sin(t * 3 + m);
        arcBlade(L.add, C[0], C[1], rad, ang - span, ang + span, 0.28, m % 2 ? CYA : GH, 0.55 * aRes * (1 - (rad - 52) / 95), 0.62);
      }
    }
    // ghosts rise in concentric choirs
    const items: { y: number; draw: () => void }[] = [];
    choirs.forEach((ch, ci) => {
      for (let i = 0; i < ch.n; i++) {
        const rise = ease.out(prog(t, ch.t0 + i * 0.1, ch.t0 + i * 0.1 + 0.9));
        if (rise <= 0) continue;
        const g = ghostPos(ch, i, t);
        const rel = t > 8.5 ? 1 - prog(t, 8.5, 9.2) : 1;
        if (rel <= 0) continue;
        const pulse = 1 + 0.15 * Math.exp(-((t * 1 % ch.per) / ch.per) * 5);
        items.push({ y: g[1], draw: () => {
          L.mark.ellipse(g[0], g[1] + 2, 9, 3).fill({ color: 0, alpha: 0.35 * rise });
          gring(L.glow, g[0], g[1] + 2, 8 + 6 * (t % 1), CYA, 1, 0.4 * (1 - (t % 1)) * rise, 0, TAU, YS);
          ghost(L.add, g[0], g[1] - 8 * (1 - rise) + 2, (0.9 + ci * 0.12) * pulse * rise, t + i, (i + ci) % 3, rise * rel * (c.t > 8.5 ? 1 : 1), [GH, CYA, 0x9fb8ff][ci]);
          if (t > 8.5) ghost(L.add, g[0], g[1], 1, t, 0, (1 - rel) * 0.0, GH);
        } });
      }
    });
    items.sort((a, b) => a.y - b.y).forEach((it) => it.draw());
    // pressure waves per choir, and bright crescents
    choirs.forEach((ch, ci) => {
      if (t < ch.t0 + 0.8 || t > 8.4) return;
      const ph = ((t / ch.per) % 1);
      const r1 = ch.R + ph * 80, r2 = Math.max(2, ch.R - ph * 50);
      gring(L.add, C[0], C[1], r1, [GH, CYA, 0xa0b8ff][ci], 2, 0.6 * (1 - ph), 0, TAU, 0.62);
      gring(L.add, C[0], C[1], r2, [GH, CYA, 0xa0b8ff][ci], 1, 0.4 * (1 - ph), 0, TAU, 0.62);
      c.distort(C[0], C[1], r1, 1.6 * (1 - ph));
    });
    // enemies are pushed, suspended and made to vibrate by the standing waves
    c.enemies.forEach((e, i) => {
      if (t > 2.5 && t < 8.4) {
        const I = field(home[i][0], home[i][1], t), I2 = field(home[i][0] + 3, home[i][1], t);
        const lift = Math.max(0, I) * 22 * sstep(2.5, 4, t);
        e.pin(home[i][0] + (I2 - I) * 40 * sstep(2.5, 4, t), home[i][1], lift, 0.15 * I);
        e.shakeAmt = Math.min(1, Math.abs(I) * 1.4) * 0.8 * sstep(2.5, 4, t);
      }
    });
    // Synchronisation: harmonic abyssal mandalas & erupting choir water-spouts (replaces the 11-ring bullseye)
    if (t > 7.0 && t < 9.0) {
      const s = ease.io(prog(t, 7.0, 7.7)), fold = ease.io3(prog(t, 7.7, 8.5)), rel = prog(t, 8.5, 9.0);
      const vis = s * (1 - rel);
      const rScale = 1 - fold * 0.85;
      magicSeal(L.add, C[0], C[1], 145 * rScale, CYA, t * 0.8, 0.85 * vis, 0.62, 12);
      magicSeal(L.add, C[0], C[1], 92 * rScale, GH, -t * 1.1, 0.9 * vis, 0.62, 8);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU + t * 0.6;
        const px0 = C[0] + Math.cos(a) * 88 * rScale, py0 = C[1] + Math.sin(a) * 88 * 0.62 * rScale;
        pillar(L.add, px0, py0, 120 * vis, 5 * vis + 1, i % 2 ? CYA : GH, 0.75 * vis);
      }
      pillar(L.add, C[0], C[1], 170 * fold, 12 * fold + 2, WH, 0.9 * fold * (1 - rel));
      halo(L.add, C[0], C[1], 45 + 65 * fold, CYA, 0.55 * fold * (1 - rel), 0.62);
    }
    // the colossal resonant wave
    if (t >= 8.5 && t < 11.5) {
      const u = prog(t, 8.5, 11.5), r = 360 * ease.out3(u), f = 1 - u;
      for (let k = 0; k < 4; k++) { const pts: P[] = []; for (let i = 0; i <= 80; i++) { const a = (i / 80) * TAU, w = 1 + 0.05 * Math.sin(a * 5 - u * 9 + k); pts.push([C[0] + Math.cos(a) * (r - k * 16) * w, C[1] + Math.sin(a) * (r - k * 16) * w * 0.62]); } line(L.add, pts, 6 - k * 1.2, [WH, GH, CYA, 0x4a8aff][k], 0.85 * f * (1 - k * 0.15)); }
      c.distort(C[0], C[1], r, 7 * f);
      for (const f2 of fil) { const a = Math.max(0, 1 - f2.l * 0.5); f2.l += dt; const d1 = 30 + f2.l * 150, d0 = d1 - 40 - f2.l * 40; line(L.add, [[C[0] + Math.cos(f2.ang) * d0, C[1] + Math.sin(f2.ang) * d0 * 0.62 - f2.l * 10], [C[0] + Math.cos(f2.ang) * d1, C[1] + Math.sin(f2.ang) * d1 * 0.62 - f2.l * 10]], 1.5, GH, a * 0.8); }
    }
    // a lingering ocean viewed from another dimension
    if (t > 9.0) { const al = 1 - prog(t, 9.0, 12.3); for (let k = 0; k < 8; k++) { const R = ((t * 38 + k * 46) % 360); gring(L.glow, C[0], C[1], R, CYA, 1, 0.3 * al * (1 - R / 360), 0, TAU, 0.62); } }
  });
  c.at(7.0, () => { c.flash(WH, 0.45); c.shake(5); c.shock(CX, 176, { r: 200, life: 1.2, col: GH, w: 4, amp: 3 }); });
  c.at(7.7, () => { c.shake(4); c.burst('add', CX, 172, 60, { spd: [20, 160], life: [0.5, 1.2], cols: [GH, CYA, WH], ys: YS, drag: 2 }); });
  c.at(8.5, () => {
    c.flash(WH, 1); c.shake(16); c.slow(0.3, 0.3);
    c.blast(C[0], C[1], 360, 330, 160, 14);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - C[1], e.x - C[0]), 320, 140, CYA, 14));
    [100, 220].forEach((r, i) => c.shock(C[0], C[1], { r, life: 1.2 + i * 0.5, col: i ? GH : CYA, w: 5, amp: 5 }));
    for (let i = 0; i < 70; i++) fil.push({ x: 0, y: 0, ang: (i / 70) * TAU + rr(-0.05, 0.05), l: rr(-0.1, 0) });
    c.burst('add', C[0], C[1], 160, { spd: [60, 340], life: [0.8, 1.9], cols: [GH, CYA, WH], drag: 1.2, ys: YS, streak: 0.02 });
    for (let k = 0; k < 5; k++) ringScar(c, C[0], C[1], 40 + k * 40, 6, CYA, 1);
  });
}

// ============================================================ 20 GOD-EATER'S WAKE
type Prim = { k: 'rib' | 'poly' | 'disc' | 'eye' | 'ring' | 'tear' | 'star'; pts?: P[]; w?: number; col: number; a: number; x?: number; y?: number; r?: number; edge?: number };
function s20(c: Ctx) {
  const Q: P = [CX, 152], EC: P = [322, 190];
  c.layout([[296, 176], [340, 206], [372, 170], [332, 150], [300, 210]]);
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  c.seg(0, 3.3, (u) => [lerp(34, 170, u), lerp(210, 196, u)], ease.io);
  c.seg(7.0, 7.55, (u) => { const p = bez2([170, 196], [240, 70], [404, 72], u); return [p[0], p[1]]; }, ease.io);
  c.seg(7.55, 8.3, (u) => [lerp(404, 360, u), lerp(72, 226, u)], ease.io);
  c.seg(9.4, 10.0, (u) => [lerp(360, CX, u), lerp(226, 176, u)], ease.io);
  c.seg(10.0, 10.65, (u) => [CX, 176, 120 * ease.out(u)], ease.lin);
  c.hide(10.7, 12.35);
  c.seg(12.35, 12.95, (u) => [lerp(CX, 52, u), lerp(150, 216, u) - Math.sin(u * Math.PI) * 30], ease.outExpo);
  c.seg(12.95, 20, () => [52, 216]);
  c.caster.trail = GH;
  const limbs = [
    { b: [Q[0] - 22, Q[1] - 6] as P, a: -2.6, s: 1 }, { b: [Q[0] + 22, Q[1] - 6] as P, a: -0.55, s: -1 },
    { b: [Q[0] - 26, Q[1] + 8] as P, a: 2.6, s: -1 }, { b: [Q[0] + 26, Q[1] + 8] as P, a: 0.5, s: 1 },
  ];
  const stars = Array.from({ length: 34 }, (_, i) => { const a = rr(0, TAU), r = Math.sqrt(rand()); return { p: [Q[0] + Math.cos(a) * r * 80, 90 + Math.sin(a) * r * 70] as P, t: 8.4 + rand() * 1.5, ph: rr(0, TAU), head: i < 12 }; });
  const chunks = Array.from({ length: 46 }, (_, i) => ({ r0: rr(50, 260), a0: rr(0, TAU), s: rr(3, 9), t0: 3.6 + i * 0.045, sp: rr(0.8, 1.6) }));
  const tears = Array.from({ length: 6 }, (_, i) => { const a: P = [Q[0] + rr(-90, 90), rr(40, 150)]; const pts: P[] = [a]; for (let k = 0; k < 6; k++) pts.push([pts[k][0] + rr(-10, 10) + (i % 2 ? 6 : -6), pts[k][1] + rr(6, 16)]); return { pts, t0: 8.3 + i * 0.22, ph: rr(0, TAU) }; });
  const colK = (t: number) => ease.in(prog(t, 10.7, 11.55));
  const build = (t: number): Prim[] => {
    const out: Prim[] = [];
    const sway = Math.sin(t * 1.3), un = sstep(8.3, 9.8, t);
    // ribcage
    const tips: { l: P; r: P }[] = [];
    for (let i = 0; i < 7; i++) {
      const g = ease.out(prog(t, 4.0 + i * 0.3, 5.1 + i * 0.3));
      const yH = 142 - i * 14 + sway * 1.2, W_ = 30 + 62 * Math.sin(((i + 0.8) / 7.6) * Math.PI);
      for (const sd of [-1, 1]) {
        const pts = sample((u) => bez2([Q[0] + sd * 8, yH + 2], [Q[0] + sd * W_ * 1.1, yH - 22 + sway * 2], [Q[0] + sd * 10, yH + 26], u), 12);
        const sub = pts.slice(0, Math.max(2, Math.ceil(g * pts.length)));
        if (g > 0.02) out.push({ k: 'rib', pts: sub, w: 5 - i * 0.2, col: mix(0xbfe9ff, 0xffa060, un * (0.3 + 0.3 * Math.sin(t * 6 + i))), a: 0.9, edge: 1 });
      }
      tips.push({ l: [Q[0] - W_ * 0.62, yH - 12], r: [Q[0] + W_ * 0.62, yH - 12] });
    }
    // cosmic membranes between rib tips
    const mem = ease.out(prog(t, 5.0, 7.0));
    if (mem > 0.02) for (let i = 0; i < 6; i++) {
      const w = (k: number) => Math.sin(t * 2 + i + k) * 4;
      out.push({ k: 'poly', pts: [[tips[i].l[0] + w(0), tips[i].l[1]], [tips[i + 1].l[0] + w(1), tips[i + 1].l[1]], [tips[i + 1].r[0] + w(2), tips[i + 1].r[1]], [tips[i].r[0] + w(3), tips[i].r[1]]], col: [0x2a1a6a, 0x1a3a8a, 0x4a1a7a][i % 3], a: 0.38 * mem });
    }
    // spine
    out.push({ k: 'rib', pts: sample((u) => [Q[0] + Math.sin(u * 5 + t) * 1.5, lerp(Q[1], 86, u)] as P, 10), w: 4, col: 0xdfeeff, a: 0.8 * mem, edge: 0 });
    // limbs: continuous curling, then coiling around the formation
    const lm = ease.out(prog(t, 5.5, 8.0)), mc = ease.io(prog(t, 7.4, 9.0));
    limbs.forEach((l, li) => {
      const n = 44, free: P[] = [], coil: P[] = [];
      let x = l.b[0], y = l.b[1], a = l.a;
      for (let i = 0; i <= n; i++) {
        free.push([x, y]);
        a += l.s * (0.02 + 0.1 * (i / n)) + Math.sin(t * 1.5 + i * 0.25 + li) * 0.02;
        x += Math.cos(a) * 6.2; y += Math.sin(a) * 6.2 * 0.85;
      }
      for (let i = 0; i <= n; i++) {
        const u = i / n;
        if (u < 0.35) { const e = u / 0.35; const entry: P = [EC[0] + Math.cos(li * 1.6) * 70, EC[1] + Math.sin(li * 1.6) * 44]; coil.push(bez2(l.b, [(l.b[0] + entry[0]) / 2, Math.min(l.b[1], entry[1]) - 60], entry, e)); }
        else { const ang = li * 1.6 + ((u - 0.35) / 0.65) * TAU * 1.3 * (l.s > 0 ? 1 : -1) + t * 0.3 * (l.s > 0 ? 1 : -1), r = 70 * (1 - 0.35 * u); coil.push([EC[0] + Math.cos(ang) * r, EC[1] + Math.sin(ang) * r * 0.62]); }
      }
      const pts = free.map((p, i) => [lerp(p[0], coil[i][0], mc), lerp(p[1], coil[i][1], mc)] as P);
      const sub = pts.slice(0, Math.max(2, Math.ceil(lm * pts.length)));
      if (lm > 0.02) out.push({ k: 'rib', pts: sub, w: 13 * (0.5 + 0.5 * lm), col: mix(0x1a1470, 0x5a2a90, un), a: 0.8, edge: 2 });
    });
    // Head: monumental pixel-art Eldritch Abyssal Crown-Skull (replaces clip-art circle + triangles)
    const hd = ease.out(prog(t, 6.3, 8.3));
    if (hd > 0.02) {
      const hx = Q[0], hy = 56 + sway * 2 - (1 - hd) * 20;
      out.push({ k: 'disc', x: hx, y: hy, r: 40 * hd, col: GH, a: hd });
    }
    // eyes
    const eyeP: P[] = [[Q[0] - 16, 44], [Q[0] + 16, 44], [Q[0], 32], [Q[0] - 28, 58], [Q[0] + 28, 58], [Q[0] - 52, 104], [Q[0] + 52, 104], [Q[0] - 40, 130], [Q[0] + 40, 130], [Q[0] - 70, 86], [Q[0] + 70, 86], [Q[0], 110]];
    eyeP.forEach((p, i) => { const k = prog(t, 6.0 + i * 0.16, 6.6 + i * 0.16); if (k > 0) out.push({ k: 'eye', x: p[0], y: p[1] + sway, r: (i < 5 ? 7 : 5) * k, col: i % 3 ? GH : GOLD, a: 1, edge: Math.max(0.1, Math.abs(Math.sin(t * 0.9 + i * 1.7)) * 1.4 > 1 ? 0.1 : 1) }); });
    // spatial tears between moving sections
    tears.forEach((tr) => { const k = prog(t, tr.t0, tr.t0 + 0.4); if (k > 0) out.push({ k: 'tear', pts: tr.pts.map((p) => [p[0] + Math.sin(t * 6 + tr.ph) * 1.5, p[1]] as P), col: WH, a: k * (0.7 + 0.3 * Math.sin(t * 20 + tr.ph)) }); });
    // stars ignite
    stars.forEach((s) => { if (t > s.t) out.push({ k: 'star', x: s.p[0], y: s.p[1], r: (2 + 3 * Math.abs(Math.sin(t * 5 + s.ph))) * Math.min(1, (t - s.t) * 3), col: s.head ? WH : GOLD, a: 1 }); });
    return out;
  };
  const render = (prims: Prim[], tf: (p: P) => P, wScale: number, g: { add: Ctx['L']['add']; front: Ctx['L']['add'] }, shadow: boolean, t: number) => {
    for (const p of prims) {
      const pts = p.pts?.map(tf);
      const al = shadow ? p.a * 0.6 * shadowA : p.a;
      switch (p.k) {
        case 'rib': {
          if (shadow) {
            ribbon(g.front, pts!, (i, n) => Math.max(1, (p.w ?? 4) * wScale * (1 - (p.edge === 2 ? (i / n) * 0.85 : 0.0))), 0x1d1636, al * 0.55);
            break;
          }
          ribbon(g.add, pts!, (i, n) => Math.max(1, (p.w ?? 4) * wScale * (p.edge === 2 ? 1 - (i / n) * 0.85 : 1) * 1.35), p.col, 0.88 * al);
          // Articulated pixel bone-vertebrae / scythe spines along limbs so they look like skeletal eldritch appendages
          if (p.edge === 2) {
            for (let i = 2; i < pts!.length - 2; i += 4) {
              const q = pts![i], qn = pts![i + 1];
              const a = Math.atan2(qn[1] - q[1], qn[0] - q[0]);
              const sc = (1 - i / pts!.length) * wScale;
              shard(g.add, q[0], q[1], 7 * sc + 2, 2.5 * sc + 1, a + Math.PI / 2, GH, 0.85 * al);
            }
          }
          line(g.add, pts!, 1, p.edge === 2 ? WH : hiRamp(p.col, 0.7), 0.95 * al);
          break;
        }
        case 'poly': if (shadow) poly(g.front, pts!, 0x000000, al); else { poly(g.add, pts!, p.col, p.a * 0.42); line(g.add, [...pts!, pts![0]], 1, mix(p.col, WH, 0.5), 0.35 * p.a); } break;
        case 'disc': {
          const q = tf([p.x!, p.y!]);
          const sc = (p.r! / 34) * wScale;
          if (!shadow) {
            stampOn(g.add, 'seal_abyss', q[0], q[1] - 4, { sx: sc * 1.15, sy: sc * 1.15, rot: t * 0.35, tint: VIO, alpha: 0.75 * al, add: true });
            stampOn(g.add, 'corona_ring', q[0], q[1], { sx: sc * 0.95, sy: sc * 0.95, rot: -t * 0.5, tint: CYA, alpha: 0.7 * al, add: true });
            stampOn(g.front, 'godeater_skull', q[0], q[1], { sx: sc * 1.15, sy: sc * 1.15, rot: Math.sin(t * 1.5) * 0.05, tint: 0xffffff, alpha: al, add: false });
            stampOn(g.add, 'godeater_skull', q[0], q[1], { sx: sc * 1.15, sy: sc * 1.15, rot: Math.sin(t * 1.5) * 0.05, tint: CYA, alpha: 0.45 * al, add: true });
          } else {
            stampOn(g.front, 'godeater_skull', q[0], q[1], { sx: sc * 1.2, sy: sc * 1.2, rot: 0, tint: 0x283868, alpha: al * 0.65, add: true });
          }
          break;
        }
        case 'ring': if (!shadow) { const q = tf([p.x!, p.y!]); gring(g.add, q[0], q[1], p.r! * wScale, p.col, 2, p.a, 0, TAU, 1); } break;
        case 'eye': if (!shadow) {
          const q = tf([p.x!, p.y!]), r = p.r! * wScale, o = p.edge!;
          const sc = (r / 6.5);
          stampOn(g.add, 'godeater_eye', q[0], q[1], { sx: sc, sy: sc * o, rot: 0, tint: p.col, alpha: 0.95 * al, add: true });
        } break;
        case 'tear': if (!shadow) { line(g.front, pts!, 4, 0x000000, 0.9 * al); line(g.add, pts!, 1.5, p.col, al); line(g.add, pts!.map((q) => [q[0] + 3, q[1]] as P), 1, CYA, 0.5 * al); } break;
        case 'star': if (!shadow) { const q = tf([p.x!, p.y!]); sparkle(g.add, q[0], q[1], p.r! * 2.4 * wScale, p.col, 1, t); } break;
      }
    }
  };
  let shadowA = 1;
  const ribbonTrail: P[] = [];
  const frozen: Prim[] = [];
  let frozenDone = false;
  void frozen; void frozenDone;
  c.each((t, dt) => {
    const L = c.L;
    const k = colK(t);
    // spreading shadow far larger than warrior or lantern
    const sr = ease.out(prog(t, 0.3, 3.4));
    if (sr > 0 && t < 11.6) { const pts: P[] = []; for (let i = 0; i < 60; i++) { const a = (i / 60) * TAU, r = (14 + 250 * sr) * (1 + 0.1 * Math.sin(a * 5 + t * 0.8) + 0.05 * Math.sin(a * 11 - t)); pts.push([CX + Math.cos(a) * r, 170 + Math.sin(a) * r * 0.58]); } L.mark.poly(pts.flat()).fill({ color: 0x000000, alpha: 0.5 * sr * (1 - k) }); }
    c.darken(t < 11.5 ? 0.55 * sstep(0.5, 3.4, t) + 0.3 * k : t < 12.2 ? 0.97 : 0.6 * (1 - prog(t, 12.2, 14.5)));
    // Lantern opens into an abyssal vortex portal
    const open = ease.outBack(prog(t, 3.3, 4.6)) * (1 - sstep(10.7, 11.2, t));
    if (t > 3.0 && open > 0) {
      const rx = 42 * open, ry = 20 * open;
      const vSc = (rx / 46);
      stampOn(L.glow, 'vortex_swirl', Q[0], Q[1], { sx: vSc * 1.35, sy: vSc * 1.35, rot: -t * 1.4, tint: VIO, alpha: 0.85 * open, ys: 0.52, add: true });
      stampOn(L.add, 'vortex_swirl', Q[0], Q[1], { sx: vSc * 0.95, sy: vSc * 0.95, rot: -t * 2.1, tint: CYA, alpha: 0.9 * open, ys: 0.52, add: true });
      magicSeal(L.add, Q[0], Q[1], rx * 1.45, CYA, t * 0.5, 0.7 * open, 0.52, 8);
      L.front.ellipse(Q[0], Q[1], rx * 0.78, ry * 0.78).fill({ color: 0x03020a, alpha: 1 });
      gring(L.add, Q[0], Q[1], rx * 0.8, GH, 2, open, 0, TAU, ry / rx);
      for (let a = 0; a < 3; a++) { const pts = sample((s) => { const an = a * 2.1 + s * 6 - t * 3, r = (1 - s) * rx * 1.9 + 4; return [Q[0] + Math.cos(an) * r, Q[1] + Math.sin(an) * r * 0.45] as P; }, 24); line(L.add, pts, 1, GH, 0.5 * open); }
      c.lens(Q[0], Q[1], 170, 1.1 * open * (1 + 0.3 * Math.sin(t * 3)));
      c.post.slice = [t > 8.3 && t < 11 ? 2.5 * un(t) : 0, 1.0, 10, t];
    }
    // floor fragments, particles and light dragged into curved trajectories
    for (const ch of chunks) {
      const u = prog(t, ch.t0, ch.t0 + 3.2 / ch.sp);
      if (u <= 0 || u >= 1) continue;
      const e = ease.in(u), r = ch.r0 * (1 - e), a = ch.a0 + e * 5 * ch.sp + u * 2;
      const x = Q[0] + Math.cos(a) * r, y = Q[1] + 12 + Math.sin(a) * r * 0.55;
      const s = ch.s * (1 - e * 0.7), cs = Math.cos(a * 2), sn = Math.sin(a * 2);
      L.front.poly([[-s, -s * 0.6], [s, -s * 0.6], [s, s * 0.6], [-s, s * 0.6]].flatMap(([px, py]) => [x + px * cs - py * sn, y + px * sn + py * cs])).fill({ color: 0x2b2b3d, alpha: 1 });
      line(L.add, [[x, y], [Q[0] + Math.cos(a - 0.3) * r * 0.9, Q[1] + 12 + Math.sin(a - 0.3) * r * 0.9 * 0.55]], 1, CYA, 0.4 * e);
    }
    if (t > 3.5 && t < 10.5) { for (let i = 0; i < 2; i++) { const a = rr(0, TAU), r = rr(60, 250); c.emit('add', { x: Q[0] + Math.cos(a) * r, y: Q[1] + Math.sin(a) * r * 0.55, vx: -Math.sin(a) * 90, vy: Math.cos(a) * 50, ax: -Math.cos(a) * 160, ay: -Math.sin(a) * 90, life: rr(0.8, 1.4), size: 1, c0: GH, c1: VIO, drag: 0.4 }); } }
    // enemies pulled, then coiled, then dragged to the collapse
    c.enemies.forEach((e, i) => {
      if (t > 3.6 && t < 7.4) { const a = Math.atan2(Q[1] - e.y, Q[0] - e.x); e.vx += Math.cos(a) * 18 * dt * 5; e.vy += Math.sin(a) * 18 * dt * 5; e.shakeAmt = 0.3; }
      if (t >= 7.4 && t < 10.7) { const m = ease.io(prog(t, 7.4, 9.0)); e.pin(lerp(e.x, EC[0] + Math.cos(i * 1.26) * 18, 0.04 + m * 0.0), lerp(e.y, EC[1] + Math.sin(i * 1.26) * 12, 0.04), 10 * m * (0.6 + 0.4 * Math.sin(t * 3 + i)), 0.15 * Math.sin(t * 5 + i)); e.shakeAmt = 0.5; e.outline = 0.6; e.outlineCol = GH; }
      if (t >= 10.7 && t < 12.2) { const m = ease.in(prog(t, 10.7, 11.9)); e.pin(lerp(e.x, Q[0] + (i - 2) * 4, m * 0.25), lerp(e.y, Q[1] + 10, m * 0.25), 20 * m, t * 6); e.shakeAmt = 0.8; e.outline = 0.9; if (rand() < 0.5) c.emit('add', { x: e.x + rr(-4, 4), y: e.y - 8, vx: rr(-10, 10), vy: rr(-60, -20), life: rr(0.4, 0.9), size: 1, c0: GF[i % 3], c1: DEEP }); }
    });
    // the entity
    if (t > 4.0 && t < 11.7) {
      const prims = build(t);
      const tf = (p: P): P => {
        if (k <= 0) return p;
        const dx = p[0] - Q[0], dy = p[1] - Q[1], r = Math.hypot(dx, dy), ang = k * 5 * Math.exp(-r / 200), cs = Math.cos(ang), sn = Math.sin(ang), s = Math.pow(1 - k, 1.4);
        return [Q[0] + (dx * cs - dy * sn) * s, Q[1] + (dx * sn + dy * cs) * s];
      };
      const wS = k > 0 ? 1 - k * 0.7 : 1;
      render(prims, tf, wS, L, false, t);
      // unstable: spectral flame travels along the anatomy
      if (t > 8.3 && t < 10.7) for (const p of prims) if (p.k === 'rib' && rand() < 0.35) { const q = p.pts![Math.floor(rand() * p.pts!.length)]; c.emit('add', { x: q[0], y: q[1], vx: rr(-10, 10), vy: rr(-50, -15), life: rr(0.4, 1.1), size: rr(1, 2), c0: [GH, CYA, 0xffa060][Math.floor(rand() * 3)], c1: VIO }); }
      // collapse: stretched ribbons of spirit fire, dark matter, broken geometry and skeletal fragments
      if (k > 0 && k < 1) for (const p of prims) {
        if (p.k !== 'rib' || !p.pts) continue;
        for (let i = 0; i < p.pts.length; i += 3) {
          const a = tf(p.pts[i]);
          const tf2 = (q: P): P => { const kk = Math.max(0, k - 0.14), dx = q[0] - Q[0], dy = q[1] - Q[1], r = Math.hypot(dx, dy), ang = kk * 5 * Math.exp(-r / 200), cs = Math.cos(ang), sn = Math.sin(ang), s = Math.pow(1 - kk, 1.4); return [Q[0] + (dx * cs - dy * sn) * s, Q[1] + (dx * sn + dy * cs) * s]; };
          const b = tf2(p.pts[i]);
          const mode = i % 4;
          line(L.add, [a, b], 3 * (1 - k) + 1, mode === 0 ? GH : mode === 1 ? 0xffa060 : mode === 2 ? VIO : WH, 0.9);
          if (mode === 3) shard(L.add, a[0], a[1], 4, 1.5, Math.atan2(a[1] - b[1], a[0] - b[0]), 0xdfeeff, 0.9);
        }
      }
    }
    if (k > 0 && k < 1.0) { c.lens(Q[0], Q[1], 200, -1.3 * k); halo(L.add, Q[0], Q[1], 12 + 30 * k, WH, 0.8 * k, 0.8); disc(L.add, Q[0], Q[1], 2 + 3 * k, WH, 1); c.shake(2 * k); c.silhouette(k); }
    // near-total darkness
    if (t >= 11.55 && t < 12.2) { c.silhouette(1); c.lens(Q[0], Q[1], 120, -1.5); const p = 0.5 + 0.5 * Math.sin(t * 40); disc(L.add, Q[0], Q[1], 1.4 + p, WH, 1); halo(L.add, Q[0], Q[1], 6 + p * 4, CYA, 0.5, 1); }
    // warrior streak ribbon (through the body, and out of the blast)
    const streaking = (t > 7.0 && t < 7.7) || (t > 12.35 && t < 13.1) || (t > 9.9 && t < 10.7);
    if (streaking) { ribbonTrail.push([c.caster.x, c.caster.y - 8 - c.caster.z]); if (ribbonTrail.length > 22) ribbonTrail.shift(); } else if (ribbonTrail.length) ribbonTrail.shift();
    if (ribbonTrail.length > 2) { const rt = ribbonTrail.slice().reverse(); ribbon(L.add, rt, (i, n) => 4 * (1 - i / n), WH, 1); ribbon(L.add, rt, (i, n) => 10 * (1 - i / n), CYA, 0.5); }
    if (t > 7.0 && t < 7.6) c.caster.glow = 1; else if (t > 10.0 && t < 10.7) c.caster.glow = 1; else c.caster.glow = 0;
    // closing the lantern
    if (t > 10.3 && t < 10.75) { const u = prog(t, 10.3, 10.75); halo(L.add, c.caster.x, c.caster.y - c.caster.z - 8, 10 + 40 * u, WH, 0.8 * u, 1); }
    // Spectral abyssal echo of the vanished entity lingers briefly in the sky
    if (t > 12.5) {
      const f = (1 - prog(t, 13.2, 15.8)) * sstep(12.5, 13.1, t);
      if (f > 0) {
        shadowA = f * 0.45;
        const frz = build(8.8);
        render(frz, (p) => [Q[0] + (p[0] - Q[0]) * 1.15, 148 + (p[1] - 100) * 0.85], 1.1, { add: L.add, front: L.glow }, true, t);
      }
    }
    function un(tt: number) { return sstep(8.3, 9.8, tt); }
  });
  // keep the lingering shadow alpha under control with a scar that overlays fade
  c.at(12.2, () => {
    c.flash(WH, 1); c.shake(24); c.slow(0.25, 0.4);
    c.blast(Q[0], Q[1] + 10, 380, 380, 190, 14);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - Q[1] + rr(-10, 10), e.x - Q[0] + rr(-10, 10)), 360, 190, GH, 14));
    [60, 140, 240, 340].forEach((r, i) => c.shock(Q[0], Q[1] + 14, { r, life: 1.1 + i * 0.35, col: [WH, GH, CYA, VIO][i], col2: WH, w: 6, amp: 7 }));
    c.ent(3.2, (a, u) => { c.post.slice = [4 * (1 - u), 0.5 + u, 12, a * 6]; c.lens(Q[0], Q[1], 220 * (1 - u * 0.5), 0.8 * (1 - u) * Math.sin(a * 6)); });
    // towering spectral fire
    for (let i = 0; i < 11; i++) {
      const a = (i / 11) * TAU + 0.3, d = 50 + (i % 3) * 36, bx = Q[0] + Math.cos(a) * d * 1.3, by = Q[1] + 14 + Math.sin(a) * d * 0.62, hh = 150 + (i % 4) * 36;
      c.ent(2.6 + (i % 3) * 0.3, (age, u) => {
        const g = ease.outExpo(Math.min(1, age * 3)), f = 1 - sstep(0.4, 1, u), w = 10 * f + 2;
        const tip: P = [bx + Math.sin(age * 8 + i) * 6, by - hh * g * (0.85 + 0.15 * Math.sin(age * 14 + i))];
        poly(c.L.add, [[bx - w, by], [bx - w * 0.3, by - (by - tip[1]) * 0.6], tip, [bx + w * 0.3, by - (by - tip[1]) * 0.55], [bx + w, by]], i % 3 ? CYA : VIO, 0.7 * f);
        poly(c.L.add, [[bx - w * 0.5, by], [bx, by - (by - tip[1]) * 0.78], [bx + w * 0.5, by]], GH, 0.85 * f);
        poly(c.L.add, [[bx - w * 0.2, by], [bx, by - (by - tip[1]) * 0.45], [bx + w * 0.2, by]], WH, f);
        if (rand() < 0.5) c.emit('add', { x: tip[0], y: tip[1], vx: rr(-15, 15), vy: rr(-50, -10), life: rr(0.5, 1.3), size: 1, c0: WH, c1: CYA });
      });
    }
    // fractured stars + fragments of the creature's body
    for (let i = 0; i < 30; i++) {
      const a = rr(0, TAU), sp = rr(80, 320), life = rr(1.4, 2.6);
      let x = Q[0], y = Q[1], vx = Math.cos(a) * sp, vy = Math.sin(a) * sp * 0.65 - 60, r = rr(0, TAU);
      c.ent(life, (age, u, d) => { x += vx * d; y += vy * d; vy += 80 * d; vx *= 0.99; r += d * 4; sparkle(c.L.add, x, y, (6 + (i % 4) * 3) * (1 - u), i % 2 ? WH : GOLD, 1 - u, r); });
    }
    for (let i = 0; i < 12; i++) {
      const a = rr(0, TAU), sp = rr(60, 230), ang0 = rr(0, TAU), life = rr(2, 3.2), len = rr(14, 30);
      let x = Q[0] + Math.cos(a) * 20, y = Q[1] - 20, vx = Math.cos(a) * sp, vy = -rr(60, 180), r = ang0, vr = rr(-5, 5);
      c.ent(life, (age, u, d) => { x += vx * d; y += vy * d; vy += 260 * d; vx *= 0.99; r += vr * d; if (y > 200 + (i % 4) * 14) { y = 200 + (i % 4) * 14; vy = 0; vx *= 0.8; vr *= 0.8; } rotRect(c.L.front, x, y, len, 4, r, 0xcfe0f0, 1 - sstep(0.7, 1, u)); rotRect(c.L.add, x, y, len, 1.5, r, GH, 0.8 * (1 - u)); });
    }
    for (let i = 0; i < 160; i++) { const a = rr(0, TAU), s = rr(60, 380); c.emit(i % 3 ? 'add' : 'deb', { x: Q[0], y: Q[1] + 6, z: rr(0, 30), vx: Math.cos(a) * s, vy: Math.sin(a) * s * YS, vz: rr(40, 300), gz: 220, life: rr(0.8, 2.4), size: i % 3 ? rr(1, 2) : rr(2, 4), c0: i % 3 ? [WH, GH, CYA][i % 3] : 0xcfe0f0, c1: DEEP, drag: 0.8 }); }
    ringScar(c, Q[0], Q[1] + 14, 70, 7, CYA, 3); ringScar(c, Q[0], Q[1] + 14, 150, 7, VIO, 2); ringScar(c, Q[0], Q[1] + 14, 250, 7, GH, 1);
    crackScar(c, Q[0], Q[1] + 14, 14, 160, 7, CYA);
  });
  c.at(3.3, () => { c.flash(GH, 0.3); c.shake(5); });
  c.at(7.0, () => { c.flash(WH, 0.35); });
  c.at(10.7, () => { c.flash(WH, 0.9); c.shake(8); });
}

export const LANTERN: Skill[] = [
  { id: 17, relic: 'lantern', name: 'Procession of Hollow Kings', sub: 'a spectral army rises, surges, curves and crowns itself in flame', dur: 12, phases: [[0, 'Slow walk'], [0.7, 'Kings emerge'], [4.4, 'Army surges'], [6.5, 'Curve & converge'], [8.1, 'Crown eruption']], setup: s17 },
  { id: 18, relic: 'lantern', name: 'Funeral Fireworks', sub: 'souls climb as reverse meteors, bloom, then fall as ghostfire rain', dur: 12.8, phases: [[0.2, 'Running swings'], [0.8, 'Souls ascend'], [6.8, 'Five blooms'], [7.8, 'Ghostfire rain'], [10.1, 'Final radiance'], [10.4, 'Souls return']], setup: s18 },
  { id: 19, relic: 'lantern', name: 'The Drowned Choir', sub: 'three choirs sing interference; they synchronise, fold, then release one wave', dur: 12.8, phases: [[0.4, 'Ripples'], [1.6, 'Choirs rise'], [2.5, 'Interference'], [7.0, 'Synchronise'], [7.7, 'Fold inward'], [8.5, 'Resonant wave']], setup: s19 },
  { id: 20, relic: 'lantern', name: "God-Eater's Wake", sub: 'a portal in a hand-sized lantern; the entity emerges, then collapses to a point and detonates', dur: 16.5, phases: [[0, 'Shadow spreads'], [3.3, 'Portal opens'], [4.0, 'Entity emerges'], [7.0, 'Streak through it'], [8.3, 'Unstable'], [10.7, 'Lantern closes'], [11.55, 'Near darkness'], [12.2, 'Cosmic eruption'], [13.5, 'Shadow remains']], setup: s20 },
];
