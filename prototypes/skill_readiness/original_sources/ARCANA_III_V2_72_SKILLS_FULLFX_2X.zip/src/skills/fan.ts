// PRISMATIC WAR FAN — beauty, colour and fluidity becoming overwhelming force.
import { Ctx, Skill } from '../engine/core';
import {
  CX, H, P, SPECTRUM as SP, TAU, W, YS, bez, clamp, dist, ease, hsl, lerp, mix, prog, rand, rr, sample, segIntersect, spline, sstep,
} from '../engine/util';
import { arcBlade, diamond, disc, glyph, gring, hiRamp, line, magicSeal, ngon, pixelBolt, poly, ribbon, rotRect, shadeRamp, shard, star } from '../engine/draw';
import { crackScar, debris, halo, pillar, ringScar, slashX, sparkle } from '../engine/fx';
import { stampOn } from '../engine/sprites';

const WH = 0xffffff;
const partial = (pts: P[], f: number) => pts.slice(0, Math.max(2, Math.min(pts.length, Math.ceil(f * pts.length) + 1)));

function geo(g: Ctx['L']['add'], i: number, x: number, y: number, s: number, rot: number, a: number) {
  const col = SP[i % 7];
  switch (i % 7) {
    case 0: poly(g, [[x + Math.cos(rot) * s, y + Math.sin(rot) * s], [x + Math.cos(rot + 2.1) * s, y + Math.sin(rot + 2.1) * s], [x + Math.cos(rot + 4.2) * s, y + Math.sin(rot + 4.2) * s]], col, a); break;
    case 1: disc(g, x, y, s * 0.8, col, a); break;
    case 2: diamond(g, x, y, s * 1.3, s * 0.6, rot, col, a); break;
    case 3: rotRect(g, x, y, s * 1.4, s * 1.4, rot, col, a); break;
    case 4: star(g, x, y, s * 1.4, 4, 0.25, rot, col, a); break;
    case 5: ngon(g, x, y, s, 6, rot, col, a); break;
    default: line(g, [[x - Math.cos(rot) * s * 1.6, y - Math.sin(rot) * s * 1.6], [x + Math.cos(rot) * s * 1.6, y + Math.sin(rot) * s * 1.6]], 1.5, col, a);
  }
}

// ============================================================ 09 SEVEN-COLOR TEMPEST
function s09(c: Ctx) {
  const C: P = [CX, 186];
  const S1 = (u: number): P => bez([44, 205], [150, 80], [310, 262], [440, 118], u);
  const S2 = (u: number): P => bez([440, 118], [350, 40], [140, 36], [44, 128], u);
  const S3 = (u: number): P => { const a = Math.PI + TAU * 1.2 * u, r = 200 * (1 - u); return [CX + Math.cos(a) * r * 1.1, 170 + Math.sin(a) * r * 0.55]; };
  c.seg(0.3, 1.4, S1, ease.io); c.seg(1.5, 2.6, S2, ease.io); c.seg(2.8, 3.95, S3, ease.io);
  c.seg(5.3, 5.45, (u) => [lerp(CX, 112, u), lerp(170, 226, u)], ease.out);
  c.seg(5.55, 5.9, (u) => [lerp(112, 372, u), lerp(226, 92, u) - Math.sin(u * Math.PI) * 14], ease.outExpo);
  c.seg(5.9, 8, () => [372, 92]);
  c.caster.trail = 0x6af0ff;
  const dirs = SP.map((_, i) => -Math.PI / 2 + (i / 7) * TAU);
  c.layout(dirs.map((a) => [CX + Math.cos(a) * 100, 172 + Math.sin(a) * 62]));
  const PP = (s: number): P => (s < 0.5 ? S1(s * 2) : S2((s - 0.5) * 2));
  const PPn = (s: number): P => { const a = PP(Math.max(0, s - 0.01)), b = PP(Math.min(1, s + 0.01)); const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1; return [-dy / l, dx / l]; };
  const spiralPt = (i: number, s: number, t: number): P => {
    const a = (i / 7) * TAU + s * 5.5 - t * 2.2, r = 8 + 120 * Math.pow(s, 0.9);
    return [C[0] + Math.cos(a) * r, C[1] + Math.sin(a) * r * 0.45 - s * 98];
  };
  const feathers = Array.from({ length: 56 }, (_, i) => ({ i: i % 7, s: rr(0.1, 1), o: rr(-8, 8), sp: rr(0.05, 0.15) }));
  const glit = Array.from({ length: 90 }, () => ({ s: rr(0, 1), o: rr(-1, 1), ph: rr(0, TAU) }));
  const cur = dirs.map((a, i) => ({ a, t0: 5.8 + i * 0.19 }));
  const hit = new Array(7).fill(false);
  const arcs: { r: number; a0: number; a1: number; i: number; ph: number }[] = [];
  for (let i = 0; i < 7; i++) for (let k = 0; k < 4; k++) { const a0 = Math.PI * (1.1 + k * 0.2 + rr(0, 0.05)); arcs.push({ r: 118 + i * 7, a0, a1: a0 + 0.16 + rr(0, 0.05), i, ph: rr(0, TAU) }); }
  c.each((t, dt) => {
    const L = c.L;
    const m = ease.io(prog(t, 3.2, 5.0));
    const g1 = ease.out(prog(t, 0.3, 1.4)), g2 = ease.out(prog(t, 1.5, 2.6));
    const split = sstep(1.7, 2.7, t);
    const vis = t < 5.9 ? 1 : 1 - sstep(5.9, 6.5, t);
    const visS = Math.min(1, 0.5 * g1 + 0.5 * g2);
    // sheets: white wind ribbon -> seven refracted colour sheets -> prismatic hurricane
    if (vis > 0) {
      const N = 46;
      for (let i = 0; i < 7; i++) {
        const pts: P[] = [];
        const n = Math.max(2, Math.floor(N * (t < 2.6 ? visS : 1)));
        for (let k = 0; k <= n; k++) {
          const s = (k / N);
          const q = PP(Math.min(1, s)), nr = PPn(Math.min(1, s));
          const off = (i - 3) * 6.5 * split;
          const sheet: P = [q[0] + nr[0] * off, q[1] + nr[1] * off];
          const sp = spiralPt(i, Math.min(1, s), t);
          pts.push([lerp(sheet[0], sp[0], m), lerp(sheet[1], sp[1], m)]);
        }
        const w = lerp(lerp(26, 9, split), 9, m) * (t < 1.4 ? 1 : 1);
        const col = mix(0xcfeaff, SP[i], split);
        ribbon(L.add, pts, (k, nn) => w * (0.35 + 0.65 * Math.sin((k / nn) * Math.PI * 0.9 + 0.15)) , col, (0.28 + 0.2 * split) * vis);
        line(L.add, pts, 1, mix(col, WH, 0.5), 0.75 * vis);
      }
      // glittering fragments riding the wind
      for (const gl of glit) {
        const s = Math.min(visS, gl.s) ;
        if (s <= 0.01 && t < 3) continue;
        const q = PP(gl.s), nr = PPn(gl.s);
        const sp = spiralPt(Math.floor(gl.ph * 7 / TAU) % 7, gl.s, t);
        const base: P = [q[0] + nr[0] * gl.o * 14, q[1] + nr[1] * gl.o * 14];
        const x = lerp(base[0], sp[0], m), y = lerp(base[1], sp[1], m);
        if (t < 2.6 && gl.s > visS) continue;
        if (Math.sin(t * 8 + gl.ph) > 0.2) sparkle(L.add, x, y, 2.2, WH, 0.9 * vis, t);
      }
      // crystalline feathers and luminous arcs once the storm turns
      if (m > 0.05) {
        for (const f of feathers) {
          const s = (f.s + t * f.sp) % 1, q = spiralPt(f.i, s, t), q2 = spiralPt(f.i, Math.min(1, s + 0.02), t);
          const a = Math.atan2(q2[1] - q[1], q2[0] - q[0]);
          shard(L.add, q[0] + f.o * 0.3, q[1], 6 + s * 5, 1.8, a, SP[f.i], m * vis);
        }
        for (let k = 0; k < 6; k++) {
          const s = (k + 1) / 7, y = C[1] - s * 98, r = 8 + 120 * Math.pow(s, 0.9);
          gring(L.add, C[0], y, r, WH, 1, 0.5 * m * vis, t * 2 + k, t * 2 + k + 2.2, 0.45);
        }
        halo(L.add, C[0], C[1] - 20, 40, WH, 0.35 * m * vis, 0.5);
        disc(L.add, C[0], C[1] - 8, 6 * m, WH, vis, 0.6);
        c.lens(C[0], C[1] - 40, 130, 0.5 * m * vis * Math.sin(t * 2));
        c.post.aberr = 1.8 * m * vis;
      }
    }
    // enemies are carried by the storm
    if (t > 3.4 && t < 5.8) {
      const k = ease.io(prog(t, 3.4, 4.6));
      c.enemies.forEach((e, i) => {
        const a = dirs[i] + (t - 3.4) * 1.9 * k, r = lerp(100, 72, k);
        e.pin(C[0] + Math.cos(a) * r, 172 + Math.sin(a) * r * 0.6, 30 * k * (0.7 + 0.3 * Math.sin(t * 3 + i)), a * 1.5);
      });
    }
    if (t > 3.0 && t < 5.9) c.darken(0.25 * m);
    // seven currents
    cur.forEach((cu, i) => {
      const e = c.enemies[i];
      const ext = ease.outExpo(prog(t, cu.t0, cu.t0 + 0.4));
      const ret = ease.in3(prog(t, 7.2 + i * 0.03, 7.85));
      if (ext <= 0 || ret >= 1) return;
      const tgt: P = [CX + Math.cos(cu.a) * 100, 172 + Math.sin(cu.a) * 62];
      const nrm: P = [-Math.sin(cu.a), Math.cos(cu.a)];
      const pts = sample((u) => {
        const s = u * ext * (1 - ret), bulge = Math.sin(u * Math.PI) * 26 * (i % 2 ? 1 : -1);
        return [C[0] + (tgt[0] - C[0]) * s + nrm[0] * bulge * (1 - ret) + nrm[0] * Math.sin(u * 14 - t * 16) * 3, 172 + (tgt[1] - 172) * s + nrm[1] * bulge * (1 - ret) * 0.6] as P;
      }, 30);
      ribbon(L.add, pts, (k, n) => 16 * Math.sin((k / n) * Math.PI * 0.8 + 0.2) * (1 - ret) + 2, SP[i], 0.92);
      line(L.add, pts, 2, WH, 0.95);
      for (let k = 1; k < 12; k++) { const q = pts[Math.floor(((k / 12 + t * 1.3) % 1) * (pts.length - 1))]; geo(L.add, i, q[0], q[1] - 2, 3.2, t * 5 + k, 0.95); }
      if (!hit[i] && ext > 0.9) {
        hit[i] = true;
        c.strike(e, cu.a + 0.2, 230, 190, SP[i], 14);
        c.shock(e.x, e.y, { r: 40, life: 0.5, col: SP[i], w: 3, amp: 3 });
        c.burst('add', e.x, e.y - 8, 20, { spd: [40, 160], life: [0.4, 0.9], cols: [SP[i], WH], drag: 2 });
        c.shake(4); c.slow(0.55, 0.05);
      }
    });
    // shattered rainbow above the fractured terrain
    if (t > 8.0) {
      const f = 1 - prog(t, 9.4, 11.4);
      if (f > 0) for (const a of arcs) {
        const yo = Math.sin(t * 1.3 + a.ph) * 2 - prog(t, 8.0, 9.6) * 10;
        gring(L.add, CX, 268 + yo, a.r * 1.5, SP[a.i], 3, 0.8 * f * sstep(8, 8.4, t), a.a0, a.a1, 0.55);
        gring(L.add, CX, 268 + yo, a.r * 1.5, WH, 1, 0.6 * f * sstep(8, 8.4, t), a.a0 + 0.02, a.a1 - 0.02, 0.55);
      }
    }
    void dt;
  });
  c.at(5.75, () => { c.flash(WH, 0.7); c.shake(6); c.shock(CX, 172, { r: 120, life: 0.7, col: 0x6af0ff, w: 4, amp: 4 }); c.slow(0.5, 0.1); });
  c.at(7.9, () => {
    c.flash(WH, 1); c.shake(15); c.slow(0.3, 0.3);
    c.blast(CX, 172, 300, 220, 140);
    for (let i = 0; i < 7; i++) c.shock(CX, 172, { r: 100 + i * 40, life: 0.9 + i * 0.1, col: SP[i], w: 4, amp: 5 });
    c.ent(1.2, (_a, u) => {
      for (let i = 0; i < 7; i++) {
        const a = dirs[i] + u * 0.5, l = 120 * ease.outExpo(u);
        poly(c.L.add, [[CX + Math.cos(a - 0.08) * 8, 172 + Math.sin(a - 0.08) * 8 * 0.7], [CX + Math.cos(a) * l, 172 + Math.sin(a) * l * 0.7], [CX + Math.cos(a + 0.08) * 8, 172 + Math.sin(a + 0.08) * 8 * 0.7]], SP[i], 1 - u);
      }
      halo(c.L.add, CX, 172, 60 * (1 - u * 0.5), WH, 1 - u, 0.7);
    });
    for (let i = 0; i < 160; i++) { const a = rr(0, TAU), s = rr(60, 330); c.emit('add', { x: CX, y: 172, z: rr(0, 20), vx: Math.cos(a) * s, vy: Math.sin(a) * s * YS, vz: rr(0, 120), gz: 100, life: rr(0.7, 1.6), size: rr(1, 3), c0: SP[i % 7], c1: WH, streak: 0.03, drag: 1.3 }); }
    // light-reflecting fractured terrain
    const tris = Array.from({ length: 22 }, (_, i) => { const a = rr(0, TAU), d = rr(15, 190); const x = CX + Math.cos(a) * d, y = 172 + Math.sin(a) * d * 0.6; const s = rr(10, 26), r0 = rr(0, TAU); return { pts: [0, 1, 2].map((k) => [x + Math.cos(r0 + k * 2.1) * s, y + Math.sin(r0 + k * 2.1) * s * 0.6] as P), i, ph: rr(0, TAU) }; });
    c.scar(6, (g, a, age) => tris.forEach((tr) => { poly(g.mark, tr.pts, 0x0c0c14, 0.5 * a); line(g.glow, [...tr.pts, tr.pts[0]], 1, SP[tr.i % 7], 0.7 * a * (0.5 + 0.5 * Math.sin(age * 4 + tr.ph))); poly(g.glow, tr.pts, SP[tr.i % 7], 0.12 * a); }));
    crackScar(c, CX, 172, 12, 130, 6, 0x9ae8ff);
  });
}

// ============================================================ 10 GLASS MONSOON
function s10(c: Ctx) {
  c.layout([[330, 150], [375, 190], [400, 125], [305, 205], [360, 235], [420, 175]]);
  c.seg(0, 1.6, (u) => [lerp(170, 66, u), lerp(180, 205, u)], ease.out);
  c.seg(1.6, 6.5, (u) => [66, 205 + Math.sin(u * 20) * 0.4]);
  c.caster.trail = 0x9ae8ff;
  const panels = Array.from({ length: 5 }, (_, i) => ({ x: 208 + (i % 2) * 14, y: 100 + i * 28, t0: 0.9 + i * 0.22, tilt: rr(-0.2, 0.2), off: rr(-8, 8) }));
  type Plate = { x: number; y: number; ph: number; t0: number; sz: number; hue: number; col: number; row: number };
  const plates: Plate[] = [];
  for (let r = 0; r < 5; r++) for (let q = 0; q < 9; q++) { const x = 34 + q * 52 + (r % 2) * 26, y = 18 + r * 24; plates.push({ x, y, ph: rr(0, TAU), t0: 2.4 + (Math.abs(x - 215) / 260 + r * 0.05) * 2.4, sz: rr(15, 22), hue: rr(0, 1), col: q, row: r }); }
  type Sh = { x: number; y: number; x1: number; y1: number; t0: number; dur: number; sz: number; rot: number; lvl: number; hue: number; ph: number; state: number; lt: number };
  const shards: Sh[] = [];
  const FALL0 = 6.7;
  plates.forEach((p, pi) => { for (let k = 0; k < 3; k++) { const a = (k / 3) * TAU + rr(0, 1); const tx = clamp(p.x + rr(-60, 60), 20, W - 20), ty = rr(120, 245); shards.push({ x: p.x + Math.cos(a) * 6, y: p.y + Math.sin(a) * 4, x1: tx, y1: ty, t0: FALL0 + rand() * 1.4 + (pi % 3) * 0.1, dur: 0.75 + rand() * 0.25, sz: p.sz * 0.62, rot: a, lvl: 0, hue: p.hue, ph: rr(0, TAU), state: 0, lt: 0 }); } });
  const landed: Sh[] = [];
  const glass = c.enemies.map(() => 0);
  const pulseT = 9.1;
  const tri = (g: Ctx['L']['add'], x: number, y: number, s: number, rot: number, sq: number, col: number, a: number) => {
    const pts: P[] = [0, 1, 2].map((k) => { const ang = rot + k * 2.1; return [x + Math.cos(ang) * s, y + Math.sin(ang) * s * sq] as P; });
    poly(g, pts, col, a);
    line(g, [...pts, pts[0]], 1, mix(col, WH, 0.6), a);
  };
  c.each((t, dt) => {
    const L = c.L;
    // mirror panels
    panels.forEach((p, i) => {
      const g = ease.outBack(prog(t, p.t0, p.t0 + 0.7));
      if (g <= 0 || t > 5.4) return;
      const h = 56 * g, fade = 1 - sstep(4.6, 5.4, t);
      const x = p.x + Math.sin(t * 1.2 + i) * 2, y = p.y;
      const sk = p.tilt * 6;
      const pts: P[] = [[x - 12 + sk, y + 14], [x + 12 + sk, y + 14], [x + 12 - sk, y + 14 - h], [x - 12 - sk, y + 14 - h]];
      poly(L.front, pts, 0x7acaff, 0.22 * fade);
      poly(L.front, [pts[0], pts[1], [pts[1][0], pts[1][1] - 6], [pts[0][0], pts[0][1] - 6]], 0xffffff, 0.12 * fade);
      line(L.add, [...pts, pts[0]], 1.5, 0xbff0ff, 0.9 * fade);
      line(L.add, [[x - 7 + sk, y + 10], [x + 3 - sk, y + 14 - h + 6]], 2, WH, 0.5 * fade);
      // reflections: offset / contradictory positions
      c.enemies.forEach((e, k) => {
        if (g < 0.8 || (k + i) % 2) return;
        const rx = x + (e.x - 320) * 0.08 + p.off * ((k + Math.floor(t * 0.8)) % 2 ? 1 : -1) * 0.6, ry = y + 14 - h * 0.5 + (e.y - 170) * 0.12;
        if (Math.abs(rx - x) < 10) c.silhouetteAt(L.add, rx, ry + 6, 0xaaddff, 0.5 * fade, -1);
      });
      if (g > 0.9 && rand() < 0.2) c.emit('add', { x: x + rr(-10, 10), y: y + rr(-h + 14, 14), life: 0.6, size: 1, c0: WH, c1: 0x7acaff, vy: -10 });
    });
    // canopy of crystalline plates; synchronised tilting refracts light into shifting beams
    const fracture = ease.io(prog(t, 5.0, 6.4));
    if (t < FALL0) plates.forEach((p) => {
      const g = ease.out(prog(t, p.t0, p.t0 + 0.7));
      if (g <= 0) return;
      const tilt = Math.sin(t * 1.3 - (p.x + p.y) * 0.015) * 1.1;
      const sq = Math.max(0.15, Math.abs(Math.cos(tilt)));
      const col = hsl(p.hue + tilt * 0.35 + t * 0.03, 0.8, 0.62);
      const x = p.x, y = p.y + Math.sin(t + p.ph) * 2;
      if (fracture < 0.01) {
        const s = p.sz * 0.5 * g;
        const pts: P[] = [[x - s, y], [x - s * 0.5, y - s * sq], [x + s * 0.5, y - s * sq], [x + s, y], [x + s * 0.5, y + s * sq], [x - s * 0.5, y + s * sq]];
        poly(L.add, pts, col, 0.45);
        line(L.add, [...pts, pts[0]], 1, mix(col, WH, 0.6), 0.9);
        if (p.col % 2 === p.row % 2 && Math.abs(Math.sin(tilt)) > 0.55) line(L.add, [[x, y], [x + Math.sin(tilt) * 90, 170 + p.col * 6]], 1, col, 0.22 * g);
      }
    });
    // fracture: plates split into thousands of angular shards suspended above the arena
    if (t >= 5.0 && t < FALL0 + 0.1) {
      const f = fracture;
      shards.forEach((s, i) => {
        if (t >= s.t0) return;
        const p = plates[Math.floor(i / 3)];
        const a = s.rot + t * 0.4 * (i % 2 ? 1 : -1);
        const x = s.x + Math.cos(a) * 9 * f + Math.sin(t * 1.5 + s.ph) * 1.5, y = s.y + Math.sin(a) * 6 * f + Math.cos(t + s.ph) * 2;
        tri(L.add, x, y, s.sz * (0.55 + 0.1 * Math.sin(t * 3 + s.ph)), a + t * 0.8, 0.6 + 0.4 * Math.abs(Math.sin(t + s.ph)), hsl(s.hue + t * 0.05, 0.75, 0.62), 0.55 + 0.35 * f);
        if (rand() < 0.01) sparkle(L.add, x, y, 4, WH, 1, t);
        void p;
      });
      halo(L.add, CX, 70, 190, 0x9ae8ff, 0.1 * f, 0.4);
    }
    // choreographed descent
    for (const s of shards) {
      if (s.state === 2) continue;
      if (t < s.t0) continue;
      const u = (t - s.t0) / s.dur;
      if (s.state === 0) s.state = 1;
      if (u >= 1) {
        s.state = 2; s.lt = t; landed.push(s);
        impact(s);
        continue;
      }
      const e = ease.in(u);
      const x = lerp(s.x, s.x1, e), y = lerp(s.y, s.y1, e);
      const col = hsl(s.hue, 0.7, 0.7);
      const len = s.sz * (s.lvl ? 0.8 : 1.2);
      // pointing down while falling
      poly(L.add, [[x, y + len], [x - len * 0.28, y - len * 0.2], [x + len * 0.28, y - len * 0.2]], col, 0.95);
      line(L.add, [[x, y + len], [x, y - len * 1.8 * e]], 1.5, mix(col, WH, 0.5), 0.55);
      line(L.add, [[x, y - len * 0.2], [x, y - len * 0.2 - 28 * e]], 1, WH, 0.3);
    }
    // landed glass
    const pulseK = prog(t, pulseT, pulseT + 0.6), dis = prog(t, pulseT + 0.6, pulseT + 2.0);
    for (const s of landed) {
      if (s.lvl > 1) continue;
      const al = (1 - dis) * clamp((t - s.lt + 0.01) * 6 + 1) * 0.85;
      if (al <= 0) continue;
      const w = Math.sin(pulseK * Math.PI);
      tri(L.glow, s.x1, s.y1, 3 + s.sz * 0.25, s.rot, 0.5, mix(hsl(s.hue, 0.6, 0.7), WH, w), al);
    }
    // enemies progressively glassed; reaction to contact
    c.enemies.forEach((e, i) => { e.tint = 0xaee8ff; e.tintAmt = clamp(glass[i] * 0.2); });
    // pulse of white light reflecting through the whole shower
    if (t > pulseT && t < pulseT + 1.6) {
      const k = prog(t, pulseT, pulseT + 1.6), f = Math.sin(Math.min(1, k * 1.4) * Math.PI);
      for (let r = 1; r <= 6; r++) {
        const rad = r * 52 * (0.5 + k), pts = ringPts6(CX, 170, rad, t * 0.3 * (r % 2 ? 1 : -1));
        line(L.add, pts, 1.5, hsl(r / 6 + t * 0.2, 0.7, 0.8), 0.6 * f);
      }
      for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU + t * 0.3; line(L.add, [[CX, 170], [CX + Math.cos(a) * 340 * k, 170 + Math.sin(a) * 200 * k]], 1, WH, 0.35 * f); }
      c.post.aberr = 2 * f; c.post.grade = [1.1, 1.2, 1.3, 0.2 * f];
      if (rand() < 0.8) sparkle(L.sky, rr(0, W), rr(40, 250), rr(2, 6), WH, 1, rand() * 3);
    }
    void dt;
  });
  function ringPts6(cx: number, cy: number, r: number, rot: number): P[] { const o: P[] = []; for (let i = 0; i <= 6; i++) { const a = rot + (i / 6) * TAU; o.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.65]); } return o; }
  function impact(s: Sh) {
    const col = hsl(s.hue, 0.7, 0.75);
    if (s.lvl === 0) {
      // large shards split on contact into smaller, faster cascading layers
      for (let k = 0; k < 2; k++) { const a = rr(0, TAU); const ch: Sh = { x: s.x1, y: s.y1 - 14, x1: clamp(s.x1 + Math.cos(a) * rr(10, 30), 10, W - 10), y1: clamp(s.y1 + Math.sin(a) * 14, 100, 255), t0: c.t + 0.04 + k * 0.1, dur: 0.28, sz: s.sz * 0.5, rot: a, lvl: 1, hue: s.hue + 0.05 * k, ph: rr(0, TAU), state: 0, lt: 0 }; shards.push(ch); }
      c.burst('add', s.x1, s.y1, 8, { spd: [20, 90], life: [0.2, 0.6], cols: [col, WH], ys: YS, drag: 2, vz: [10, 70], gz: 300 });
      c.ent(0.25, (_a, u) => { for (let i = 0; i < 6; i++) { const a = i * 1.05 + s.rot; line(c.L.add, [[s.x1 + Math.cos(a) * 3, s.y1 + Math.sin(a) * 2], [s.x1 + Math.cos(a) * (6 + 14 * u), s.y1 + Math.sin(a) * (4 + 8 * u)]], 1.5, col, 1 - u); } });
    } else {
      c.burst('add', s.x1, s.y1, 4, { spd: [10, 60], life: [0.2, 0.5], cols: [col, WH], ys: YS, drag: 2 });
      c.emit('deb', { x: s.x1, y: s.y1, z: 2, vx: rr(-20, 20), vy: rr(-8, 8), vz: rr(30, 90), gz: 300, life: 1.2, size: 1, c0: col, c1: 0x445566, bounce: 0.3 });
    }
    // contact with a target: glass-burst silhouette
    c.enemies.forEach((e, i) => {
      if (dist(e.x, e.y, s.x1, s.y1) < 16 && s.lvl === 0) {
        glass[i]++;
        c.strike(e, Math.atan2(e.y - s.y1, e.x - s.x1) + rr(-0.5, 0.5), 80, 70, col, 8);
        c.ent(0.45, (_a, u) => { for (let k = 0; k < 10; k++) { const a = (k / 10) * TAU + i; const l = (6 + 26 * ease.out(u)) * (0.6 + (k % 3) * 0.3); shard(c.L.add, e.x + Math.cos(a) * l, e.y - 8 + Math.sin(a) * l, 5 * (1 - u) + 1, 1.5 * (1 - u) + 0.5, a, k % 2 ? WH : col, 1 - u); } disc(c.L.add, e.x, e.y - 8, 10 * (1 - u), WH, 1 - u); });
        c.shake(2);
      }
    });
  }
  c.at(6.55, () => { c.flash(WH, 0.5); c.shake(3); c.shock(78, 205, { r: 70, life: 0.5, col: 0x9ae8ff, w: 3, amp: 3 }); });
  c.at(pulseT, () => {
    c.flash(WH, 0.8); c.shake(6);
    c.shock(CX, 170, { r: 320, life: 1.4, col: 0xbff0ff, w: 5, amp: 4 });
    c.blast(CX, 170, 260, 130, 100);
    c.enemies.forEach((e) => { e.flash = 1; });
    c.burst('add', CX, 140, 120, { spd: [40, 280], life: [0.6, 1.6], cols: [WH, 0x9ae8ff, 0xffd0ff, 0xd0ffe8], drag: 1.5, ys: YS });
    c.scar(4, (g, a, age) => { for (const s of landed) if (s.lvl === 0) { line(g.glow, [[s.x1 - 4, s.y1 + 1], [s.x1 + 4, s.y1 - 1]], 1, WH, 0.5 * a * (0.5 + 0.5 * Math.sin(age * 8 + s.ph))); } });
  });
}

// ============================================================ 11 IMPERIAL INKSTORM
function s11(c: Ctx) {
  // Four iconic calligraphic brush strokes forming a grand Imperial Seal + Enso circle (never tangled hoses)
  const strokes: P[][] = [
    sample((u) => bez([95, 122], [190, 96], [290, 132], [388, 108], u), 80),
    sample((u) => bez([366, 82], [275, 145], [195, 188], [108, 222], u), 80),
    sample((u) => spline([[240, 66], [244, 118], [240, 172], [236, 218], [212, 232], [192, 210]], u), 80),
    sample((u) => {
      const a = -2.3 + u * 5.65, r = 1 - 0.06 * u;
      return [CX + Math.cos(a) * 142 * r, 156 + Math.sin(a) * 86 * r] as P;
    }, 96),
  ];
  const ST = [0.5, 2.1, 3.7, 5.2], SD = 1.4;
  const ints: { p: P; a: number; b: number; ia: number; ib: number }[] = [];
  for (let a = 0; a < 4; a++) for (let b = a + 1; b < 4; b++) {
    for (let i = 0; i < strokes[a].length - 1; i++) for (let j = 0; j < strokes[b].length - 1; j++) {
      const p = segIntersect(strokes[a][i], strokes[a][i + 1], strokes[b][j], strokes[b][j + 1]);
      if (p && !ints.some((q) => dist(q.p[0], q.p[1], p[0], p[1]) < 12)) ints.push({ p, a, b, ia: i / (strokes[a].length - 1), ib: j / (strokes[b].length - 1) });
    }
  }
  const useInts = ints.slice(0, 6);
  const fixed: P[] = [[150, 130], [330, 150], [250, 195], [200, 90], [310, 100]];
  const epos: P[] = useInts.map((i) => i.p);
  while (epos.length < 5) epos.push(fixed[epos.length]);
  c.layout(epos.slice(0, 6).map((p) => [clamp(p[0], 40, 440), clamp(p[1], 80, 230)] as P));
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  // caster paints with his body
  strokes.forEach((s, k) => c.seg(ST[k], ST[k] + SD, (u) => { const q = s[Math.min(s.length - 1, Math.floor(u * (s.length - 1)))]; return [q[0], q[1] + 4]; }, ease.io));
  c.seg(7.6, 8.5, (u) => { const s = strokes[2]; const q = s[Math.min(s.length - 1, Math.floor((1 - u) * (s.length - 1)))]; return [q[0], q[1] + 4, Math.sin(u * Math.PI) * 14]; }, ease.io);
  c.seg(8.5, 8.8, (u) => { const s = strokes[2][0]; return [lerp(strokes[2][0][0], 70, u), lerp(s[1], 205, u)]; });
  c.seg(8.8, 14, () => [70, 205]);
  c.caster.trail = 0xffd35a;
  const INK = 0x0e081a, INK2 = 0x3b1d6e, GOLD = 0xffd84a, RED = 0xff3255;
  // Crisp tapered sumi-e brush profile (14..18px at the belly, razor-sharp at entry and exit)
  const wAt = (s: number, k: number) =>
    (k === 3 ? 13 : 16) * Math.pow(Math.sin(Math.PI * clamp(s, 0.02, 0.98)), 0.72) * (0.85 + 0.25 * Math.sin(s * 9 + k));
  const chars: { x: number; y: number; vx: number; vy: number; r: number; vr: number; l: number; seed: number }[] = [];
  const PULSE = [7.8, 8.3, 8.8, 9.3];
  const WAVE0 = 10.0;
  const struck = c.enemies.map(() => false);
  const lift = (t: number, k: number) => (k === 0 || k === 2 ? ease.io(prog(t, 6.6 + k * 0.2, 7.6 + k * 0.2)) : 0);

  const drawInk = (L: Ctx['L'], k: number, g: number, t: number, wm: number, a: number, headOnly: [number, number] | null) => {
    if (a <= 0.02) return;
    const full = strokes[k];
    const i0 = headOnly ? Math.floor(headOnly[0] * (full.length - 1)) : 0;
    const i1 = headOnly ? Math.ceil(headOnly[1] * (full.length - 1)) : Math.ceil(g * (full.length - 1));
    const pts0 = full.slice(Math.max(0, i0), Math.min(full.length, i1 + 1));
    if (pts0.length < 2) return;
    const lf = lift(t, k);
    const pts = pts0.map((p, i) => {
      const s = (i0 + i) / (full.length - 1);
      return [p[0], p[1] - lf * 18 * Math.sin(Math.PI * s) * (0.6 + 0.4 * Math.sin(t * 2.5 + s * 5))] as P;
    });
    const W_ = (i: number) => wAt((i0 + i) / (full.length - 1), k) * wm;

    // Multi-bristle sumi-e brushwork: vermilion & imperial-gold aura bristles + deep obsidian ink core + dry-brush streaks
    ribbon(L.add, pts, (i) => W_(i) * 1.15, k % 2 === 0 ? RED : GOLD, 0.65 * a);
    ribbon(L.front, pts, (i) => W_(i) * 0.72, INK, 0.92 * a);
    // Dry-brush gold & vermilion hair-fibers inside the stroke
    for (const bristle of [-0.24, 0.22]) {
      const bPts = pts.map((p, i) => {
        const q = pts[Math.min(pts.length - 1, i + 1)], r = pts[Math.max(0, i - 1)];
        const dx = q[0] - r[0], dy = q[1] - r[1], l = Math.hypot(dx, dy) || 1;
        return [p[0] - (dy / l) * W_(i) * bristle, p[1] + (dx / l) * W_(i) * bristle] as P;
      });
      line(L.add, bPts, 1, bristle < 0 ? GOLD : RED, 0.78 * a);
    }
    if (lf > 0.1) {
      const sheet = pts.map((p, i) => [p[0] + Math.sin(i * 0.25 + t * 2) * 3 * lf, p[1] - 12 * lf * Math.sin((i / pts.length) * Math.PI)] as P);
      ribbon(L.add, sheet, (i) => W_(i) * 0.65 * lf, GOLD, 0.75 * lf * a);
    }
  };
  c.each((t, dt) => {
    const L = c.L;
    c.darken(0.3 * sstep(0.3, 2, t));
    // strokes built progressively along the actual brush path
    for (let k = 0; k < 4; k++) {
      const g = prog(t, ST[k], ST[k] + SD);
      if (g <= 0) continue;
      const head = ease.io(g);
      const waveActive = t > WAVE0;
      if (!waveActive) drawInk(L, k, head, t, 1, 1, null);
      else drawInk(L, k, 1, t, 0.65, (1 - prog(t, WAVE0, WAVE0 + 1.4)) * 0.55, null);
      if (g < 1) {
        const q = strokes[k][Math.min(strokes[k].length - 1, Math.floor(head * (strokes[k].length - 1)))];
        for (let i = 0; i < 3; i++) c.emit(i ? 'add' : 'deb', { x: q[0], y: q[1], z: rr(0, 10), vx: rr(-70, 70), vy: rr(-70, 40), vz: rr(20, 120), gz: 280, life: rr(0.4, 1.1), size: rr(1, 3), c0: i ? GOLD : INK2, c1: INK, bounce: 0.1 });
        halo(L.add, q[0], q[1], 8, GOLD, 0.4);
      }
    }
    // Vermilion Imperial Seal Stamps (朱印) & golden arcane rings where brush strokes cross
    useInts.forEach((it, i) => {
      const born = Math.max(ST[it.a] + SD * it.ia, ST[it.b] + SD * it.ib) + 0.15;
      if (t < born || t > WAVE0 + 1.5) return;
      const g = ease.outBack(prog(t, born, born + 0.55));
      const fadeOut = 1 - sstep(WAVE0 + 0.8, WAVE0 + 1.5, t);
      stampOn(L.add, 'seal_imperial', it.p[0], it.p[1], { sx: 0.65 * g, sy: 0.65 * g, rot: 0, tint: RED, alpha: 0.9 * fadeOut, ys: YS, add: true });
      gring(L.add, it.p[0], it.p[1], 15 * g, GOLD, 1, 0.75 * fadeOut, 0, TAU, YS, t * (i % 2 ? 1 : -1));
    });
    // energy racing through the connected strokes, in order
    PULSE.forEach((pt, k) => {
      const s = prog(t, pt, pt + 0.6);
      if (s <= 0 || s >= 1 || t > WAVE0) return;
      const i0 = Math.max(0, Math.floor((s - 0.12) * (strokes[k].length - 1))), i1 = Math.floor(s * (strokes[k].length - 1));
      const seg = strokes[k].slice(i0, i1 + 1);
      if (seg.length > 1) { ribbon(L.add, seg, 7, GOLD, 0.8); line(L.add, seg, 2.5, WH, 1); halo(L.add, seg[seg.length - 1][0], seg[seg.length - 1][1], 14, WH, 0.7); }
      useInts.forEach((it) => { if ((it.a === k && Math.abs(it.ia - s) < 0.04) || (it.b === k && Math.abs(it.ib - s) < 0.04)) { halo(L.add, it.p[0], it.p[1], 22, WH, 0.7); sparkle(L.add, it.p[0], it.p[1], 8, WH, 1, t * 3); } });
    });
    // enemies hang in the ink: bound at intersections until the waves arrive
    c.enemies.forEach((e, i) => { if (t > 6.4 && t < WAVE0 + 0.25 && !struck[i]) { e.pin(home[i][0], home[i][1], 5 + 3 * Math.sin(t * 3 + i), 0.1 * Math.sin(t * 2 + i)); e.tint = INK2; e.tintAmt = 0.35 * sstep(6.4, 8, t); } });
    // Cutting waves of vermilion fire, gold leaf, and obsidian ink surging along the brush paths
    if (t > WAVE0) {
      for (let k = 0; k < 4; k++) {
        const t0 = WAVE0 + k * 0.12, s = ease.in(prog(t, t0, t0 + 1.25)) * 0.75 + prog(t, t0, t0 + 1.25) * 0.25;
        const tail = Math.max(0, s - 0.32);
        const f = 1 - sstep(t0 + 1.2, t0 + 2.2, t);
        if (f <= 0) continue;
        const i0 = Math.floor(tail * (strokes[k].length - 1)), i1 = Math.floor(s * (strokes[k].length - 1));
        const sub = strokes[k].slice(i0, i1 + 1);
        if (sub.length < 2) continue;
        ribbon(L.add, sub, (i, n) => (8 + 18 * Math.sin((i / n) * Math.PI)) * f, k % 2 === 0 ? RED : GOLD, 0.92 * f);
        ribbon(L.front, sub, (i, n) => (4 + 8 * Math.sin((i / n) * Math.PI)) * f, INK, 0.85 * f);
        line(L.add, sub, 2, WH, 0.95 * f);
        const hd = sub[sub.length - 1], pv = sub[Math.max(0, sub.length - 3)];
        const ang = Math.atan2(hd[1] - pv[1], hd[0] - pv[0]);
        stampOn(L.add, 'crescent_wave', hd[0], hd[1], { sx: 0.55 * f, sy: 0.55 * f, rot: ang, tint: GOLD, alpha: 0.95 * f, add: true });
        shard(L.add, hd[0], hd[1], 18 * f, 6 * f, ang, WH, 0.95 * f);
        if (s < 0.98 && f > 0.4) for (let i = 0; i < 4; i++) c.emit(i < 2 ? 'deb' : 'add', { x: hd[0], y: hd[1], z: rr(0, 12), vx: Math.cos(ang) * rr(30, 200) + rr(-60, 60), vy: Math.sin(ang) * rr(30, 200) + rr(-60, 60), vz: rr(20, 140), gz: 300, life: rr(0.5, 1.4), size: rr(1, 3), c0: i < 2 ? INK2 : [GOLD, RED][i % 2], c1: INK, bounce: 0.2 });
        if (rand() < 0.15 && s < 0.98) chars.push({ x: hd[0], y: hd[1], vx: Math.cos(ang) * rr(30, 120) + rr(-50, 50), vy: Math.sin(ang) * rr(30, 120) + rr(-80, 0), r: rr(-0.5, 0.5), vr: rr(-3, 3), l: 0, seed: rand() * 100 });
        c.enemies.forEach((e, i) => {
          if (!struck[i] && dist(e.x, e.y - 6, hd[0], hd[1]) < 24) { struck[i] = true; e.tintAmt = 0; c.strike(e, ang, 270, 110, GOLD, 14); slashX(c, e.x, e.y - 6, RED, 26, 0.35, ang); c.slow(0.5, 0.05); c.shake(5); }
        });
        c.distort(hd[0], hd[1], 22, 3 * f);
      }
    }
    // detached characters keep travelling after the structure collapses
    for (let i = chars.length - 1; i >= 0; i--) {
      const ch = chars[i]; ch.l += dt; ch.x += ch.vx * dt; ch.y += ch.vy * dt; ch.vy += 120 * dt; ch.vx *= 0.99; ch.r += ch.vr * dt;
      const a = 1 - prog(ch.l, 1.2, 2.4);
      if (a <= 0) { chars.splice(i, 1); continue; }
      glyph(L.add, ch.x, ch.y, 5, ch.seed, GOLD, a, ch.r, 2.5);
      glyph(L.front, ch.x, ch.y, 5, ch.seed, INK, a, ch.r, 4);
    }
    void dt;
  });
  c.at(WAVE0, () => {
    c.flash(0xfff0b0, 0.8); c.shake(10); c.slow(0.4, 0.2);
    // Imperial vermilion seal stamps & shattered ink-stone fissures at the calligraphy intersections
    useInts.forEach((it) => {
      ringScar(c, it.p[0], it.p[1], 26, 6, GOLD, 2);
      crackScar(c, it.p[0], it.p[1], 6, 48, 6, RED);
    });
  });
  c.at(WAVE0 + 1.4, () => {
    useInts.forEach((it) => {
      c.shock(it.p[0], it.p[1], { r: 64, life: 0.8, col: RED, col2: GOLD, w: 3, amp: 3 });
      c.burst('deb', it.p[0], it.p[1], 24, { spd: [30, 160], vz: [60, 200], gz: 300, life: [0.8, 1.8], cols: [INK2, GOLD, RED], bounce: 0.2, ys: YS });
    });
  });
}

// ============================================================ 12 BUTTERFLY CATACLYSM
const bfx = (th: number): P => { const r = Math.exp(Math.cos(th)) - 2 * Math.cos(4 * th) + Math.pow(Math.sin((2 * th - Math.PI) / 24), 5); return [Math.sin(th) * r, -Math.cos(th) * r]; };
function s12(c: Ctx) {
  const N = 620, C: P = [CX, 150];
  c.layout([[150, 140], [330, 140], [190, 200], [290, 200], [240, 110], [240, 230]]);
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  c.seg(0, 0.45, () => [200, 180]);
  c.seg(1.3, 1.31, () => [130, 205]); c.seg(2.2, 2.21, () => [360, 120]); c.seg(3.1, 3.11, () => [185, 110]);
  c.seg(8.0, 8.05, () => [CX, 170]);
  c.seg(8.1, 8.45, (u) => [lerp(CX, CX + 70, u), lerp(170, 190, u)], ease.outExpo);
  c.hide(0.45, 1.3); c.hide(1.7, 2.2); c.hide(2.6, 3.1); c.hide(3.5, 8.0);
  c.caster.trail = 0x9ae8ff;
  type B = { x: number; y: number; vx: number; vy: number; ph: number; hue: number; sp: number; sz: number; u: number; v: number; kind: number; wave: number; shard: boolean; life: number; keep: boolean };
  const bs: B[] = Array.from({ length: N }, (_, i) => ({ x: 200, y: 180, vx: 0, vy: 0, ph: rr(0, TAU), hue: (i * 0.618) % 1, sp: rr(9, 15), sz: rr(0.8, 1.3), u: rr(0, 1), v: rr(0, 1), kind: i % 4, wave: i % 3, shard: false, life: 1, keep: i % 20 === 0 }));
  const wingPts = Array.from({ length: N }, () => { const th = rr(0, 12 * Math.PI), p = bfx(th), k = Math.pow(rand(), 0.6); return [p[0] * k, p[1] * k] as P; });
  const cathPts: P[] = Array.from({ length: N }, (_, i) => {
    const kind = i % 6;
    if (kind < 3) { const col = [-78, -40, 40, 78][i % 4], y = rr(0, 1); return [CX + col + rr(-3, 3), 235 - y * 125] as P; }
    if (kind < 5) { const side = i % 2 ? 1 : -1, a = rr(0, Math.PI / 2); return [CX + side * (40 - Math.cos(a) * 40) + side * 0, 110 - Math.sin(a) * 30 + (side > 0 ? 0 : 0)] as P; }
    const a = rr(0, TAU), r = rr(8, 30) * (i % 2 ? 1 : 0.0 + 1); return [CX + Math.cos(a) * r, 80 + Math.sin(a) * r] as P;
  });
  const tgt = (b: B, i: number, t: number): P => {
    if (t < 3.2) { const s = i % 4, u = (b.u + t * 0.12) % 1, a = s * (TAU / 4) + u * 9 + t * 0.7, r = 20 + u * 150; return [C[0] + Math.cos(a) * r * 1.1, C[1] + Math.sin(a) * r * 0.6 - 10]; }
    if (t < 4.7) { const a = b.u * TAU * 2 + t * 0.6, rose = Math.cos(2.5 * a) , r = 18 + 70 * Math.abs(rose) * (0.4 + 0.6 * b.v); return [C[0] + Math.cos(a) * r * 1.3, C[1] - 10 + Math.sin(a) * r * 0.9]; }
    if (t < 6.5) return cathPts[i];
    const close = t > 8.2 ? 1 - ease.out(prog(t, 8.2, 8.75)) : 1;
    const sc = 27, w = wingPts[i];
    const flap = 1 + 0.12 * Math.sin(t * 3);
    // wings stay readable when they close: no collapse to a single blown-out point
    return [C[0] + w[0] * sc * (0.2 + 0.8 * close) * flap, 118 + w[1] * sc * (0.2 + 0.8 * close) * 0.82];
  };
  const hits: boolean[][] = c.enemies.map(() => [false, false, false]);
  c.each((t, dt) => {
    const L = c.L;
    const alive = Math.floor(N * ease.out(prog(t, 0.5, 3.0)));
    const cloudAt = (t < 1.3 ? [200, 180] : t < 2.2 ? [130, 205] : t < 3.1 ? [360, 120] : [185, 110]) as P;
    // spinning fan
    if (t < 0.5) { const k = t / 0.45; for (let i = 0; i < 5; i++) { const a = k * TAU * 1.2 + i * 1.1; line(L.add, [[200, 174], [200 + Math.cos(a) * 20, 174 + Math.sin(a) * 14]], 2, SP[i], 0.9); } }
    const burstMode = t >= 8.8;
    let white = 0;
    if (t > 8.2 && t < 8.8) white = sstep(8.2, 8.75, t);
    for (let i = 0; i < alive; i++) {
      const b = bs[i];
      if (b.life <= 0) continue;
      if (!b.shard) {
        if (!burstMode) {
          const T = tgt(b, i, t);
          const spawn = t < 3.2 ? Math.min(1, (t - 0.5) / 1.0) : 1;
          const k = (t < 3.2 ? 3.2 : 6) * spawn + (t > 8.0 ? 4 : 0);
          b.vx += (T[0] - b.x) * k * dt; b.vy += (T[1] - b.y) * k * dt;
          b.vx += Math.cos(b.ph + t * 2.1) * 30 * dt; b.vy += Math.sin(b.ph * 1.3 + t * 1.7) * 30 * dt;
          const d = Math.exp(-(t < 3.2 ? 2.2 : 4.2) * dt); b.vx *= d; b.vy *= d;
          if (b.x === 200 && b.y === 180 && t < 3.5) { b.x = cloudAt[0] + rr(-8, 8); b.y = cloudAt[1] + rr(-8, 8); b.vx = rr(-60, 60); b.vy = rr(-60, 60); }
        } else {
          b.shard = !b.keep;
          if (b.shard) {
            const a = Math.atan2(b.y - C[1], b.x - C[0]) + (b.wave - 1) * 0.35, s = rr(240, 400) * (1 + b.wave * 0.15);
            const delay = 0; void delay;
            b.vx = Math.cos(a) * s; b.vy = Math.sin(a) * s * 0.7;
          }
        }
        b.x += b.vx * dt; b.y += b.vy * dt;
        const flap = Math.abs(Math.sin(t * b.sp + b.ph));
        const col = b.kind === 0 ? hsl(b.hue, 0.85, 0.62) : b.kind === 1 ? mix(hsl(b.hue, 0.7, 0.55), 0xffffff, 0.35) : b.kind === 2 ? hsl(b.hue + 0.5, 0.9, 0.6) : mix(0xffd0f0, hsl(b.hue, 0.8, 0.6), 0.6);
        const fc = white > 0 ? mix(col, 0xffffff, white * 0.72) : col;
        const x = Math.floor(b.x), y = Math.floor(b.y);
        if (i < 110) {
          // Hero swallowtail butterflies use the crisp 2-frame pixel-art butterfly sprites
          stampOn(L.add, flap > 0.45 ? 'butterfly_open' : 'butterfly_half', x, y, { sx: 0.65 * b.sz, sy: 0.65 * b.sz, rot: Math.atan2(b.vy, b.vx) + Math.PI / 2, tint: fc, alpha: 0.95, add: true });
        } else {
          const wv = Math.round((1 + 2.4 * flap) * b.sz);
          L.add.rect(x - wv, y - 1, wv, 2).fill({ color: fc, alpha: 0.92 }).rect(x + 1, y - 1, wv, 2).fill({ color: fc, alpha: 0.92 }).rect(x, y - 1, 1, 3).fill({ color: 0xffffff, alpha: 0.9 });
        }
      } else {
        b.x += b.vx * dt; b.y += b.vy * dt; b.vx *= Math.exp(-0.9 * dt); b.vy *= Math.exp(-0.9 * dt);
        b.life -= dt * 0.56;
        const a = Math.atan2(b.vy, b.vx), col = hsl(b.hue + t * 0.1, 0.8, 0.72);
        shard(L.add, b.x, b.y, 4 + 3 * b.life, 1.3, a, col, clamp(b.life * 1.6));
        if (b.life < 0.22 && b.keep === false && b.kind === 0) b.life = 0;
      }
    }
    // revert intact butterflies that survive
    if (burstMode && t > 10.6) bs.forEach((b) => { if (b.keep) { b.vx += Math.cos(b.ph + t) * 20 * dt; b.vy += Math.sin(b.ph + t) * 14 * dt - 6 * dt; b.vx *= 0.97; b.vy *= 0.97; } });
    // temporary structures also glow
    if (t > 3.2 && t < 8.8) {
      const f = sstep(3.2, 4.0, t) * (1 - white);
      if (t > 4.7 && t < 8.2) { gring(L.glow, CX, 100, 30 + 3 * Math.sin(t * 2), 0xffd0f0, 1, 0.25 * f, 0, TAU, 1); }
      if (t > 6.5) halo(L.glow, CX, 118, 80, 0xd0a0ff, 0.12 * f, 0.6);
    }
    if (white > 0) { halo(L.add, C[0], 120, 22 + 30 * white, 0xffffff, 0.5 * white, 0.9); disc(L.add, C[0], 120, 5 + 9 * white, 0xffffff, 0.85 * white, 0.9); c.darken(0.5 * white); c.lens(C[0], 120, 100, -0.8 * white); }
    // enemies are carried by the swarm
    c.enemies.forEach((e, i) => { if (t > 3.0 && t < 8.8) { const k = sstep(3.0, 5.0, t) * (1 - sstep(8.2, 8.8, t)); e.pin(home[i][0] + Math.sin(t + i) * 5 * k, home[i][1] + Math.cos(t * 0.8 + i) * 3 * k, 14 * k * (0.7 + 0.3 * Math.sin(t * 2 + i)), 0.2 * Math.sin(t + i) * k); } });
    // wing-shaped impact bursts engulfing enemies as each wave passes
    c.enemies.forEach((e, i) => {
      for (let w = 0; w < 3; w++) {
        const arrive = 8.8 + w * 0.05 + (dist(e.hx, e.hy, C[0], C[1]) / (300 + w * 50)) + w * 0.18;
        if (!hits[i][w] && t >= arrive) { hits[i][w] = true; wingBurst(e.hx, e.hy - 8, w, i); if (w === 0) c.strike(e, Math.atan2(e.hy - C[1], e.hx - C[0]), 240, 150, SP[i % 7], 12); }
      }
    });
    void dt;
  });
  function wingBurst(x: number, y: number, w: number, i: number) {
    const cols = [[0xff5aa0, 0xffd35a], [0x3ad8ff, 0xb04aff], [0x4ae86a, 0xffffff]][w];
    // Ornate fantasy pixel-art Swallowtail Wing-Crest burst (4 crescent wing blades + stained-glass facets)
    c.ent(0.85, (_a, u) => {
      const r = (10 + 38 * ease.outExpo(u)) * (1 + w * 0.16);
      const f = 1 - u;
      for (const sd of [-1, 1]) {
        const aUpper = sd > 0 ? -0.45 : Math.PI + 0.45;
        const aLower = sd > 0 ? 0.55 : Math.PI - 0.55;
        arcBlade(c.L.add, x, y, r, aUpper - 0.55, aUpper + 0.55, 0.45, cols[0], f, 0.85);
        arcBlade(c.L.add, x, y, r * 0.72, aLower - 0.45, aLower + 0.45, 0.4, cols[1], f, 0.85);
        shard(c.L.add, x + sd * r * 0.85, y - r * 0.35, 8 * f + 2, 3 * f + 1, sd > 0 ? -0.35 : Math.PI + 0.35, WH, f);
      }
      sparkle(c.L.add, x, y, 12 * f, WH, f, u * 3);
      halo(c.L.add, x, y, 18 * f, cols[1], f);
    });
    c.burst('add', x, y, 18, { spd: [40, 180], life: [0.4, 1.0], cols: [cols[0], cols[1], 0xffffff], drag: 2, streak: 0.02 });
    c.shake(3);
    void i;
  }
  c.at(1.3, () => { c.burst('add', 130, 205, 20, { spd: [20, 100], life: [0.3, 0.7], cols: SP }); c.shock(130, 205, { r: 40, life: 0.5, col: 0x9ae8ff, w: 2, amp: 2 }); });
  c.at(2.2, () => { c.burst('add', 360, 120, 20, { spd: [20, 100], life: [0.3, 0.7], cols: SP }); c.shock(360, 120, { r: 40, life: 0.5, col: 0xff9ae8, w: 2, amp: 2 }); });
  c.at(3.1, () => { c.burst('add', 185, 110, 20, { spd: [20, 100], life: [0.3, 0.7], cols: SP }); });
  c.at(8.05, () => { c.burst('add', CX, 170, 60, { spd: [20, 160], life: [0.4, 1.0], cols: SP, drag: 2 }); c.shock(CX, 170, { r: 60, life: 0.6, col: WH, w: 3, amp: 3 }); });
  c.at(8.8, () => {
    c.flash(WH, 1); c.shake(14); c.slow(0.3, 0.3);
    c.shock(CX, 140, { r: 330, life: 1.3, col: 0xff9ae8, w: 5, amp: 6 });
    c.shock(CX, 140, { r: 200, life: 1.0, col: 0x9ae8ff, w: 4, amp: 4 });
    c.burst('add', CX, 118, 130, { spd: [60, 340], life: [0.7, 1.7], cols: SP, streak: 0.03, drag: 1.4 });
    const tris = Array.from({ length: 26 }, (_, i) => { const a = rr(0, TAU), d = rr(15, 200); const x = CX + Math.cos(a) * d, y = 160 + Math.sin(a) * d * 0.6; const s = rr(8, 22), r0 = rr(0, TAU); return { pts: [0, 1, 2].map((k) => [x + Math.cos(r0 + k * 2.1) * s, y + Math.sin(r0 + k * 2.1) * s * 0.6] as P), i, ph: rr(0, TAU) }; });
    c.scar(6, (g, a, age) => tris.forEach((tr) => { poly(g.glow, tr.pts, SP[tr.i % 7], 0.14 * a); line(g.glow, [...tr.pts, tr.pts[0]], 1, SP[tr.i % 7], 0.75 * a * (0.5 + 0.5 * Math.sin(age * 3 + tr.ph))); }));
    crackScar(c, CX, 160, 12, 120, 5, 0xffd0f0);
  });
}

export const FAN: Skill[] = [
  { id: 9, relic: 'fan', name: 'Seven-Color Tempest', sub: 'wind → spectral sheets → prismatic hurricane → seven currents', dur: 12, phases: [[0.3, 'Sweep 1: wind ribbon'], [1.5, 'Sweep 2: refraction'], [2.8, 'Sweep 3: hurricane'], [5.55, 'Diagonal dash'], [5.8, 'Seven currents'], [7.9, 'Crystal detonation']], setup: s09 },
  { id: 10, relic: 'fan', name: 'Glass Monsoon', sub: 'mirrors become a canopy, fracture, then rain choreographed glass', dur: 12, phases: [[0.9, 'Mirror panels'], [2.4, 'Crystal canopy'], [5.0, 'Fracture'], [6.6, 'Fan closes'], [6.7, 'Glass rain'], [9.1, 'White pulse']], setup: s10 },
  { id: 11, relic: 'fan', name: 'Imperial Inkstorm', sub: 'four brush strokes become a living sigil, then cutting waves of ink', dur: 14, phases: [[0.5, 'Four strokes'], [6.4, 'Calligraphy lifts'], [7.6, 'Through the sigil'], [7.8, 'Energy runs the strokes'], [10, 'Ink waves']], setup: s11 },
  { id: 12, relic: 'fan', name: 'Butterfly Cataclysm', sub: 'a swarm builds wings, a flower, a cathedral — then closes and detonates', dur: 13, phases: [[0.5, 'Fragment cloud'], [3.2, 'Flower'], [4.7, 'Cathedral'], [6.5, 'Giant wings'], [8.2, 'Wings close'], [8.8, 'Prismatic waves']], setup: s12 },
];
