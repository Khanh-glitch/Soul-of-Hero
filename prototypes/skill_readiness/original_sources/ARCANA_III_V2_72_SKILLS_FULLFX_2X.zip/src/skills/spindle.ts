// FATE SPINDLE — intricate connected structures rewriting space and time.
import { Ctx, Skill } from '../engine/core';
import {
  CX, H, P, TAU, W, YS, bez2, clamp, dist, ease, hash2, hsl, lerp, mix, prog, rand, rr, sample, segIntersect, sstep,
} from '../engine/util';
import { arcBlade, diamond, disc, glyph, gring, line, magicSeal, ngon, poly, ribbon, ringPts, rotRect, shard, star } from '../engine/draw';
import { crackScar, debris, halo, pillar, ringScar, slashLine, slashX, sparkle } from '../engine/fx';
import { stampOn } from '../engine/sprites';

const SIL = 0xdfe6ff, ROSE = 0xffc8d8, VIO = 0xb48aff, CY = 0x8ae8ff, GOLD = 0xffd35a, WH = 0xffffff;

function thread(c: Ctx, a: P, b: P, g: number, col: number, w = 1, glow = 0.38) {
  const q: P = [lerp(a[0], b[0], g), lerp(a[1], b[1], g)];
  line(c.L.glow, [a, q], w + 2, VIO, glow);
  line(c.L.add, [a, q], w, col, 0.95);
}
function needle(g: Ctx['L']['front'], x: number, y: number, h: number, col: number, a = 1) {
  x = Math.round(x); y = Math.round(y);
  // Ornate astral sewing-lance with filigree crossguard and glowing eye
  poly(g, [[x, y - h - 4], [x + 2.5, y - h * 0.68], [x + 1, y], [x - 1, y], [x - 2.5, y - h * 0.68]], col, a);
  diamond(g, x, y - h * 0.68, 6, 2, 0, WH, a);
  g.rect(x, Math.round(y - h + 1), 1, 4).fill({ color: 0x1e1038, alpha: a });
}

// ============================================================ 13 STARLACE EXECUTION
function s13(c: Ctx) {
  const C: P = [CX, 160];
  const E: P[] = [[240, 134], [207, 186], [273, 186]];
  c.layout(E);
  const seq = [0, 3, 6, 1, 4, 7, 2, 5, 0];
  const V = (rx: number, ry: number, off: number, k: number): P => { const a = (k * TAU) / 8 - Math.PI / 2 + off; return [C[0] + Math.cos(a) * rx, C[1] + Math.sin(a) * ry]; };
  const outer = seq.map((k) => V(125, 82, TAU / 16, k)), inner = seq.map((k) => V(68, 44, 0, k));
  type Edge = { a: P; b: P; t0: number; t1: number; col: number };
  const edges: Edge[] = [];
  let prev: P = [34, 214];
  c.seg(0, 0.45, (u) => [lerp(34, outer[0][0], u), lerp(214, outer[0][1], u)], ease.outExpo);
  prev = outer[0];
  const plant: { p: P; t: number }[] = [{ p: outer[0], t: 0.45 }];
  for (let j = 1; j < 9; j++) { const t1 = 0.45 + j * 0.28, a = outer[j - 1], b = outer[j]; c.seg(t1 - 0.28, t1, (u) => [lerp(a[0], b[0], u), lerp(a[1], b[1], u)], ease.outExpo); edges.push({ a, b, t0: t1 - 0.28, t1, col: SIL }); if (j < 8) plant.push({ p: b, t: t1 }); prev = b; }
  const tI = 0.45 + 8 * 0.28 + 0.4;
  c.seg(tI - 0.4, tI, (u) => [lerp(prev[0], inner[0][0], u), lerp(prev[1], inner[0][1], u), Math.sin(u * Math.PI) * 18], ease.io);
  plant.push({ p: inner[0], t: tI });
  for (let j = 1; j < 9; j++) { const t1 = tI + j * 0.24, a = inner[j - 1], b = inner[j]; c.seg(t1 - 0.24, t1, (u) => [lerp(a[0], b[0], u), lerp(a[1], b[1], u)], ease.outExpo); edges.push({ a, b, t0: t1 - 0.24, t1, col: ROSE }); if (j < 8) plant.push({ p: b, t: t1 }); }
  const tEnd = tI + 8 * 0.24;
  const pullDir: P = (() => { const dx = inner[8][0] - C[0], dy = inner[8][1] - C[1], l = Math.hypot(dx, dy); return [dx / l, dy / l]; })();
  c.seg(tEnd + 0.05, tEnd + 0.4, (u) => [inner[8][0] + pullDir[0] * 56 * u, inner[8][1] + pullDir[1] * 36 * u], ease.out);
  c.seg(tEnd + 0.4, 14, () => [inner[8][0] + pullDir[0] * 56, inner[8][1] + pullDir[1] * 36]);
  c.caster.trail = VIO;
  // knots at every crossing of two threads
  const knots: { p: P; e: number; fr: number; ang: number; fired: boolean; ign: number }[] = [];
  for (let k = 0; k < edges.length; k++) for (let l = k + 1; l < edges.length; l++) {
    const p = segIntersect(edges[k].a, edges[k].b, edges[l].a, edges[l].b);
    if (p && !knots.some((q) => dist(q.p[0], q.p[1], p[0], p[1]) < 4)) knots.push({ p, e: l, fr: dist(edges[l].a[0], edges[l].a[1], p[0], p[1]) / dist(edges[l].a[0], edges[l].a[1], edges[l].b[0], edges[l].b[1]), ang: Math.atan2(p[1] - C[1], (p[0] - C[0]) * 0.7), fired: false, ign: 0 });
  }
  knots.sort((a, b) => a.ang - b.ang);
  knots.forEach((k, i) => (k.ign = 6.3 + i * Math.min(0.08, 3.4 / knots.length)));
  const tauT0 = 5.3, tauT1 = 6.2;
  const fil: { x: number; y: number; vx: number; vy: number; r: number; vr: number; len: number; l: number; col: number }[] = [];
  const pulses: { k: number; t0: number }[] = [];
  c.each((t, dt) => {
    const L = c.L;
    const tk = ease.io(prog(t, tauT0, tauT1));
    const sc = lerp(1, 0.4, tk);
    const T = (p: P): P => [C[0] + (p[0] - C[0]) * sc, C[1] + (p[1] - C[1]) * sc];
    const fadeT = 1 - sstep(9.2, 9.9, t);
    c.darken(0.35 * sstep(1, 4, t) * (t < 10.4 ? 1 : 0));
    // grown threads, in the order they were pulled
    if (fadeT > 0 && t < 10.4) {
      edges.forEach((e, i) => {
        const g = ease.outExpo(clamp((t - e.t0) / (e.t1 - e.t0)));
        if (g <= 0) return;
        const taut = tk > 0 ? tk : 0;
        thread(c, T(e.a), T(e.b), g, mix(e.col, WH, taut * 0.5), 1 + taut, 0.2 + 0.35 * taut);
        // energy pulses along established lines
        if (g >= 1 && t > 3.6 && t < 6.3) { const f = (t * 0.8 + i * 0.37) % 1, a = T(e.a), b = T(e.b); disc(L.add, lerp(a[0], b[0], f), lerp(a[1], b[1], f), 1.6, WH, 0.9); }
      });
      for (const k of knots) {
        const e = edges[k.e], g = ease.outExpo(clamp((t - e.t0) / (e.t1 - e.t0)));
        if (g < k.fr) continue;
        const q = T(k.p), ig = t > k.ign ? Math.exp(-(t - k.ign) * 5) : 0;
        diamond(L.front, q[0], q[1], 2.5, 2.5, Math.PI / 4, 0x1a1030, 1);
        diamond(L.add, q[0], q[1], 2 + 3 * ig, 2 + 3 * ig, Math.PI / 4, ig > 0.05 ? WH : mix(SIL, VIO, 0.4), 0.95);
        if (ig > 0.1) halo(L.add, q[0], q[1], 8 + 16 * ig, WH, 0.6 * ig, 1);
      }
      for (const p of plant) {
        if (t < p.t) continue;
        const q = T(p.p), a = Math.exp(-(t - p.t) * 3);
        needle(L.front, q[0], q[1], 14, SIL, 1);
        gring(L.glow, q[0], q[1], 5 + 12 * a, VIO, 1, 0.8 * a + 0.2, 0, TAU, YS);
        halo(L.glow, q[0], q[1], 14, VIO, 0.25, YS);
      }
    }
    // spindle thread: needle drags a thread behind, tension at the end
    if (t < tEnd + 0.05) { const cp: P = [c.caster.x, c.caster.y - 8]; sparkle(L.add, cp[0], cp[1], 5, WH, 1, t * 4); }
    if (t > tEnd && t < 6.4) {
      const cp: P = [c.caster.x, c.caster.y - 8], a = T(inner[8]);
      line(L.front, [a, cp], 3, 0x0a0814); line(L.front, [a, cp], 2, WH);
      line(L.add, [a, cp.map((v, i) => v + Math.sin(t * 80) * (i ? 0 : 0) )  as P], 4, VIO, 0.5);
      c.post.aberr = 1.5 * tk;
    }
    // enemies are held in the lace; hits arrive with the ignition cascade
    c.enemies.forEach((e, i) => { if (t > 1.5 && t < 10.4) { const k = sstep(1.5, 5.5, t); e.pin(E[i][0] + Math.sin(t * 30 + i) * 0.6 * sstep(6.3, 8, t), E[i][1], 18 * k * (1 + 0.1 * Math.sin(t * 4 + i)), 0.1 * Math.sin(t * 3 + i) * k); e.shakeAmt = sstep(6.3, 9, t) * 0.5; e.outline = 0.5 * k; e.outlineCol = VIO; } });
    // knots ignite in sequence, each pulse ends as a slash or crystal impact on a target
    for (const k of knots) if (!k.fired && t >= k.ign) {
      k.fired = true;
      const idx = knots.indexOf(k), e = c.enemies[idx % 3];
      pulses.push({ k: idx, t0: t });
      const from = T(k.p);
      c.shock(from[0], from[1], { r: 22, life: 0.35, col: WH, w: 2, amp: 1.5 });
      c.at(t + 0.22, () => {
        const kind = idx % 3, ex = e.x, ey = e.y - 10 - e.z;
        e.flash = 1; c.shake(2.5);
        if (kind === 0) slashLine(c, ex - 18, ey - 12 + (idx % 5) * 3, 0.5 + (idx % 4) * 0.4, 40, SIL, 0.25);
        else if (kind === 1) { for (let q = 0; q < 6; q++) c.emit('add', { x: ex, y: ey, vx: Math.cos(q * 1.05) * rr(50, 120), vy: Math.sin(q * 1.05) * rr(50, 120), life: 0.5, size: 2, c0: WH, c1: CY, streak: 0.04, drag: 3 }); c.ent(0.3, (_a, u) => star(c.L.add, ex, ey, 14 * (1 - u) + 3, 4, 0.2, u * 2, CY, 1 - u)); }
        else slashX(c, ex, ey, ROSE, 18, 0.28, idx);
      });
    }
    for (let i = pulses.length - 1; i >= 0; i--) {
      const p = pulses[i], u = (t - p.t0) / 0.22;
      if (u > 1) { pulses.splice(i, 1); continue; }
      const kk = knots[p.k], from = T(kk.p), e = c.enemies[p.k % 3];
      const x = lerp(from[0], e.x, ease.in(u)), y = lerp(from[1], e.y - 10, ease.in(u));
      line(L.add, [[lerp(from[0], x, 0.2), lerp(from[1], y, 0.2)], [x, y]], 3, WH, 0.9);
      halo(L.add, x, y, 8, VIO, 0.7, 1);
    }
    // the stellar seal
    const sk = ease.outBack(prog(t, 9.3, 10.3));
    if (sk > 0 && t < 10.45) {
      const R = 112 * sk, f = 1 - sstep(10.2, 10.45, t);
      for (const [r, w, col] of [[1, 3, VIO], [0.78, 2, SIL], [0.45, 2, ROSE]] as [number, number, number][]) { gring(L.add, C[0], C[1], R * r, col, w, f, 0, TAU, YS); gring(L.glow, C[0], C[1], R * r, col, w + 3, 0.3 * f, 0, TAU, YS); }
      for (let i = 0; i < 8; i++) { const A = V(R * 0.78, R * 0.78 * YS, t * 0.4, i), B = V(R * 0.78, R * 0.78 * YS, t * 0.4, (i + 3) % 8); line(L.add, [[A[0], A[1] + (C[1] - 160)], [B[0], B[1]]], 2, WH, 0.8 * f); }
      for (let i = 0; i < 24; i++) { const a = (i / 24) * TAU - t * 0.3, rr2 = R * 0.9; glyph(L.add, C[0] + Math.cos(a) * rr2, C[1] + Math.sin(a) * rr2 * YS, 3, i * 7, SIL, 0.9 * f, a); }
      halo(L.add, C[0], C[1], R * 0.5, WH, 0.35 * f, YS);
      pillar(L.add, C[0], C[1], 150 * sk, 4 + 6 * Math.sin(t * 10) * 0, VIO, 0.7 * f);
      c.lens(C[0], C[1], R, 0.5 * f);
    }
    for (let i = fil.length - 1; i >= 0; i--) {
      const f = fil[i]; f.l += dt; f.x += f.vx * dt; f.y += f.vy * dt; f.vx *= 0.985; f.vy *= 0.985; f.vy += 40 * dt; f.r += f.vr * dt;
      const a = 1 - prog(f.l, 0.8, 2.4);
      if (a <= 0) { fil.splice(i, 1); continue; }
      line(L.add, [[f.x - Math.cos(f.r) * f.len, f.y - Math.sin(f.r) * f.len], [f.x + Math.cos(f.r) * f.len, f.y + Math.sin(f.r) * f.len]], 1, f.col, a);
    }
    void dt;
  });
  c.at(10.4, () => {
    c.flash(WH, 1); c.shake(14); c.slow(0.3, 0.3);
    c.blast(C[0], C[1], 300, 270, 140);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - C[1] + rr(-6, 6), e.x - C[0] + rr(-6, 6)), 260, 160, VIO, 12));
    for (let i = 0; i < 170; i++) { const a = rr(0, TAU), r = rr(0, 110); fil.push({ x: C[0] + Math.cos(a) * r, y: C[1] + Math.sin(a) * r * YS, vx: Math.cos(a) * rr(40, 260), vy: Math.sin(a) * rr(30, 180) - 20, r: rr(0, TAU), vr: rr(-6, 6), len: rr(3, 12), l: 0, col: [SIL, ROSE, VIO, WH][i % 4] }); }
    [70, 150, 240].forEach((r, i) => c.shock(C[0], C[1], { r, life: 0.9 + i * 0.25, col: i === 1 ? ROSE : VIO, w: 4, amp: 5 }));
    c.burst('add', C[0], C[1], 100, { spd: [50, 300], life: [0.6, 1.6], cols: [SIL, VIO, WH], streak: 0.03, drag: 1.4, ys: YS });
    for (let i = 0; i < 8; i++) slashLine(c, C[0], C[1], (i / 8) * TAU + 0.2, 110, i % 2 ? VIO : ROSE, 0.45);
    c.ent(1.0, (_a, u) => {
      const k = ease.outExpo(u), f = 1 - u;
      magicSeal(c.L.add, C[0], C[1], 130 * k, VIO, u * 1.2, f, YS, 8);
      sparkle(c.L.add, C[0], C[1], 42 * f, WH, f, u * 2);
    });
    ringScar(c, C[0], C[1], 110, 4.5, VIO, 2);
    ringScar(c, C[0], C[1], 52, 4.5, ROSE, 2);
    crackScar(c, C[0], C[1], 8, 75, 4.5, VIO);
  });
}

// ============================================================ 14 THE SEAM BETWEEN SECONDS
function s14(c: Ctx) {
  const path = (u: number): P => [34 + u * 412, 168 + Math.sin(u * TAU * 1.25 + 0.4) * 54];
  const eu = [0.2, 0.38, 0.55, 0.72, 0.88];
  c.layout(eu.map((u, i) => { const p = path(u); return [p[0], p[1] + (i % 2 ? 18 : -18)] as P; }));
  const au = [0.1, 0.23, 0.36, 0.5, 0.63, 0.76, 0.9];
  const A: P[] = au.map(path);
  const tA = au.map((u) => { for (let t = 0.5; t < 2.3; t += 0.004) if (ease.io((t - 0.5) / 1.8) >= u) return t; return 2.3; });
  c.seg(0.5, 2.3, path, ease.io);
  c.hide(2.35, 5.5);
  c.seg(5.5, 5.51, () => [446, 168]);
  c.seg(5.95, 6.35, (u) => [lerp(446, 420, u), 168 + u * 6], ease.out);
  c.caster.trail = CY;
  const near = A.map((a) => { let bi = 0, bd = 1e9; c.enemies.forEach((e, i) => { const d = dist(e.hx, e.hy, a[0], a[1]); if (d < bd) { bd = d; bi = i; } }); return bi; });
  const ACT = A.map((_, i) => 6.8 + i * 0.34);
  const seamT = (i: number) => 2.5 + i * 0.45;
  const zoneR = Array.from({ length: 40 }, () => ({ o: [rr(40, 230), rr(80, 250)] as P, a: rr(0, TAU), f: rr(0, 1), l: rr(25, 70) }));
  const zoneF = Array.from({ length: 36 }, () => ({ o: [rr(250, 450), rr(70, 250)] as P, ph: rr(0, TAU), s: rr(1.5, 3.5) }));
  const hist = c.enemies.map(() => [] as P[]);
  let histT = 0;
  c.each((t, dt) => {
    const L = c.L;
    const contract = ease.in(prog(t, 6.2, 6.75));
    const pre = t < 9.5 ? 1 : 0;
    c.darken(0.35 * sstep(1, 3, t) * (t < 9.6 ? 1 : 0));
    // suspended temporal copies of the dash
    A.forEach((p, i) => {
      if (t < tA[i]) return;
      const born = Math.exp(-(t - tA[i]) * 4);
      const act = ACT[i], gone = t > act + 0.3;
      if (gone) return;
      const col = i % 2 ? 0xc9a8ff : CY;
      const jit = (Math.floor(t * 12 + i) % 7 === 0) ? 1 : 0;
      for (let e = 2; e >= 0; e--) c.silhouetteAt(L.add, p[0] - e * 7 + jit, p[1], mix(col, WH, e === 0 ? 0.2 : 0), (0.85 - e * 0.28) * (t > act - 0.1 ? 1 - prog(t, act - 0.1, act + 0.3) : 1), 1, 0.12 * Math.sin(i));
      if (born > 0.1) halo(L.add, p[0], p[1] - 6, 18 * born, WH, 0.5 * born, 1);
      gring(L.glow, p[0], p[1] + 2, 8, col, 1, 0.5, 0, TAU, YS);
    });
    // seams: layered slabs of time, stitched together by travelling needles
    if (pre) for (let i = 0; i < 6; i++) {
      const a = A[i], b = A[i + 1], g = ease.io(prog(t, seamT(i), seamT(i) + 0.55));
      if (g <= 0) continue;
      const q: P = [lerp(a[0], b[0], g), lerp(a[1], b[1], g)];
      const colS = [CY, VIO, ROSE, SIL][i % 4];
      const sh = 1 - contract * 0.85;
      poly(L.add, [[a[0], a[1] - 36 * sh], [q[0], q[1] - 36 * sh], [q[0], q[1] + 20 * sh], [a[0], a[1] + 20 * sh]], colS, 0.12 + 0.05 * Math.sin(t * 2 + i));
      line(L.add, [[a[0], a[1] - 36 * sh], [q[0], q[1] - 36 * sh]], 1, colS, 0.5);
      line(L.add, [[a[0], a[1] + 20 * sh], [q[0], q[1] + 20 * sh]], 1, colS, 0.5);
      const n = 14, zig: P[] = [];
      for (let k = 0; k <= n; k++) {
        const u = (k / n) * g;
        const base: P = [lerp(a[0], b[0], u), lerp(a[1], b[1], u) - 8];
        zig.push([base[0], base[1] + (k % 2 ? -10 : 10) * (1 - contract) * Math.min(1, g * 2)]);
      }
      line(L.glow, zig, 3, colS, 0.55);
      line(L.add, zig, 1, WH, 0.95);
      for (let k = 0; k < n; k += 2) { const u = k / n * g; const s0: P = [lerp(a[0], b[0], u), lerp(a[1], b[1], u) - 8]; line(L.add, [[s0[0], s0[1] - 12], [s0[0], s0[1] + 12]], 1, WH, 0.35); }
      // the needle that is stitching
      if (g < 1) { const tail = sample((u) => [lerp(a[0], q[0], u), lerp(a[1], q[1], u) - 8] as P, 8); ribbon(L.add, tail, (k, nn) => 3 * (k / nn), WH, 0.8); diamond(L.add, q[0], q[1] - 8, 7, 1.6, Math.atan2(b[1] - a[1], b[0] - a[0]), WH, 1); halo(L.add, q[0], q[1] - 8, 10, colS, 0.7, 1); }
    }
    // particles reversing in one zone, frozen in another
    if (t > 2.6 && pre) {
      const k = sstep(2.6, 3.6, t);
      for (const z of zoneR) { const f = (t * 0.7 + z.f) % 1, d = 60 * Math.pow(1 - f, 1.6); const x = z.o[0] + Math.cos(z.a) * d, y = z.o[1] + Math.sin(z.a) * d * 0.6; line(L.add, [[x, y], [x + Math.cos(z.a) * z.l * 0.2 * (1 - f), y + Math.sin(z.a) * z.l * 0.12 * (1 - f)]], 1, CY, 0.8 * k * (0.3 + f)); }
      for (const z of zoneF) { const s = 1.2 + Math.sin(t * z.s + z.ph) * 0.3; diamond(L.add, z.o[0], z.o[1], 2 * s, 1 * s, 0.7, mix(SIL, ROSE, 0.4), 0.7 * k); }
      c.post.slice = [2.2 * k * (1 - contract), 1.15, 11, t * 0.5];
    }
    // the ordered cascade: each copy re-enacts its strike
    A.forEach((p, i) => {
      const u = (t - ACT[i]) / 0.3;
      if (u < 0 || u > 1.6) return;
      const e = c.enemies[near[i]];
      const tx = e.x - 8, ty = e.y;
      const k = ease.outExpo(clamp(u));
      const x = lerp(p[0], tx, k), y = lerp(p[1], ty, k);
      const col = i % 2 ? 0xc9a8ff : CY;
      if (u < 1) {
        for (let q = 1; q < 5; q++) c.silhouetteAt(L.add, lerp(p[0], tx, ease.outExpo(clamp(u - q * 0.06))), lerp(p[1], ty, ease.outExpo(clamp(u - q * 0.06))), col, 0.5 - q * 0.1, 1);
        c.silhouetteAt(L.add, x, y, WH, 1, 1);
      }
      if (!(p as any)._d && u >= 1) {
        (p as any)._d = true;
        const last = i === 6, ang = Math.atan2(e.y - p[1], e.x - p[0]);
        c.strike(e, ang + (i % 2 ? 0.3 : -0.3), last ? 280 : 90, last ? 160 : 60, col, 10);
        const ex = e.x, ey = e.y - 8;
        switch (i % 7) {
          case 0: slashLine(c, ex - 20, ey - 16, 0.7, 50, WH, 0.3); break;
          case 1: slashX(c, ex, ey, CY, 24, 0.35, 0.5); break;
          case 2: slashLine(c, ex - 50, ey, 0, 110, ROSE, 0.3); break;
          case 3: c.ent(0.35, (_a, q) => arcBlade(c.L.add, ex, ey, 26 * ease.out(q) + 6, -1.2, 1.2, 0.5, VIO, 1 - q, 1, ang)); break;
          case 4: for (let s = 0; s < 3; s++) slashLine(c, ex - 18, ey - 14 + s * 8, 0.5, 42, SIL, 0.25 + s * 0.03); break;
          case 5: c.ent(0.4, (_a, q) => { gring(c.L.add, ex, ey, 30 * ease.out(q), WH, 2, 1 - q, 0, TAU, 0.8); gring(c.L.add, ex, ey, 18 * ease.out(q), VIO, 2, 1 - q, 0, TAU, 0.8); }); break;
          default: c.ent(0.5, (_a, q) => pillar(c.L.add, ex, e.y, 160, 10 * (1 - q) + 2, VIO, 1 - q));
        }
        c.shock(ex, e.y, { r: 36, life: 0.4, col, w: 3, amp: 3 });
        c.slow(0.55, 0.05);
      }
    });
    // briefly several moments at once: enemy echoes and time-slice geometry
    histT += dt;
    if (histT > 0.07) { histT = 0; c.enemies.forEach((e, i) => { hist[i].push([e.x, e.y - e.z]); if (hist[i].length > 8) hist[i].shift(); }); }
    if (t > 6.8 && t < 9.5) {
      c.enemies.forEach((e, i) => { const h = hist[i]; for (let k = 2; k < h.length; k += 2) c.silhouetteAt(L.add, h[h.length - 1 - k][0], h[h.length - 1 - k][1], k % 4 ? CY : VIO, 0.35 - k * 0.03, 1); });
      for (let k = 0; k < 5; k++) { const x = ((t * 90 + k * 110) % (W + 120)) - 60; poly(L.add, [[x, 40], [x + 38, 40], [x + 8, H], [x - 30, H]], [CY, VIO, ROSE][k % 3], 0.05); }
      c.post.slice = [3 * Math.sin(prog(t, 6.8, 9.5) * Math.PI), 1.15, 9, t * 3];
    }
    // final needle snaps the seams shut
    if (t > 9.0 && t < 9.5) { const k = ease.in(prog(t, 9.0, 9.5)); for (let i = 0; i < 6; i++) { const m: P = [(A[i][0] + A[i + 1][0]) / 2, (A[i][1] + A[i + 1][1]) / 2 - 8]; const p: P = [lerp(m[0], 240, k), lerp(m[1], 160, k)]; diamond(L.add, p[0], p[1], 8, 1.8, Math.atan2(160 - m[1], 240 - m[0]), WH, 1); line(L.add, [m, p], 1, WH, 0.8); } }
    // caster pulling the last thread
    if (t > 5.5 && t < 9.6) { const cp: P = [c.caster.x, c.caster.y - 8]; line(L.front, [cp, [A[6][0], A[6][1] - 8]], 2, WH, 1); line(L.add, [cp, [A[6][0], A[6][1] - 8]], 4, VIO, 0.4 + 0.3 * contract); }
  });
  c.at(5.5, () => { c.burst('add', 446, 168, 30, { spd: [20, 120], life: [0.4, 0.9], cols: [CY, WH, VIO] }); c.shock(446, 170, { r: 50, life: 0.5, col: CY, w: 3, amp: 3 }); });
  c.at(6.25, () => { c.flash(VIO, 0.35); c.shake(4); });
  c.at(9.5, () => {
    c.flash(WH, 1); c.shake(12); c.slow(0.35, 0.25);
    [80, 170, 300].forEach((r, i) => c.shock(240, 165, { r, life: 1.0 + i * 0.3, col: i === 1 ? VIO : SIL, w: 5, amp: 5 }));
    c.ent(1.0, (_a, u) => { const w = 300 * ease.outExpo(u); poly(c.L.add, [[240 - w, 0], [240 + w * 0.3, 0], [240 + w, H], [240 - w * 0.3, H]], VIO, 0.35 * (1 - u)); });
    A.forEach((p) => c.burst('add', p[0], p[1] - 6, 22, { spd: [20, 150], life: [0.5, 1.2], cols: [CY, VIO, WH, ROSE], drag: 1.6 }));
    c.scar(5, (g, a) => { for (let i = 0; i < 6; i++) { const n = 16; for (let k = 0; k < n; k += 2) { const u0 = k / n, u1 = (k + 1) / n; line(g.glow, [[lerp(A[i][0], A[i + 1][0], u0), lerp(A[i][1], A[i + 1][1], u0) + 6], [lerp(A[i][0], A[i + 1][0], u1), lerp(A[i][1], A[i + 1][1], u1) + 6]], 1, SIL, 0.6 * a); } } });
  });
}

// ============================================================ 15 MARIONETTE ECLIPSE
function s15(c: Ctx) {
  const C: P = [CX, 176];
  c.layout([[240, 150], [186, 204], [296, 204]]);
  const home = c.enemies.map((e) => [e.hx, e.hy] as P);
  const orbit = (u: number): P => { const a = Math.PI + u * TAU * 1.15; return [C[0] + Math.cos(a) * 100, C[1] + Math.sin(a) * 62]; };
  c.seg(0, 0.5, (u) => [lerp(34, orbit(0)[0], u), lerp(214, orbit(0)[1], u)], ease.out);
  c.seg(0.5, 4.2, orbit, ease.io);
  c.seg(6.0, 6.8, (u) => [lerp(orbit(1)[0], CX, u), lerp(orbit(1)[1], 168, u), Math.sin(u * Math.PI) * 78 + 12 * u], ease.io);
  c.seg(6.8, 7.1, (u) => [CX, 168, 90 * (1 - ease.in(u)) * 0.6]);
  c.seg(7.1, 12.6, () => [CX, 168, 0]);
  c.caster.trail = GOLD;
  const BAR = (t: number): { n: P[]; ang: number } => {
    const ang = t * 0.5, ca = Math.cos(ang), sa = Math.sin(ang);
    const hw = 74, ctr: P = [CX, 70];
    const n: P[] = [[ctr[0] + ca * hw, ctr[1] + sa * 11], [ctr[0] - ca * hw, ctr[1] - sa * 11], [ctr[0] - sa * hw * 0.8, ctr[1] + ca * 10], [ctr[0] + sa * hw * 0.8, ctr[1] - ca * 10], ctr];
    return { n, ang };
  };
  // each enemy: head + two hands => 3 strings; node assignment by bar end
  const assign = [[0, 4, 1], [2, 1, 4], [3, 4, 0]];
  const ten = (t: number, i: number, j: number) => ease.io(prog(t, 3.6 + i * 0.7 + j * 0.2, 4.3 + i * 0.7 + j * 0.2));
  const lift = (t: number, i: number) => ease.outBack(prog(t, 7.1 + i * 0.22, 7.7 + i * 0.22));
  const hand = (t: number, cur: number): void => {
    const L = c.L;
    const base: P = [CX, 36 + 4 * Math.sin(t)];
    const op = 1 - ease.io(cur);
    const alpha = sstep(2.4, 4.0, t) * (1 - sstep(9.1, 9.5, t));
    if (alpha <= 0) return;
    // negative space: bright corona behind, hand drawn as the dark silhouette in front
    halo(L.add, base[0], base[1] + 30, 130, 0xffd8a0, 0.28 * alpha, 0.6);
    const fingers: P[][] = [];
    for (let f = 0; f < 5; f++) {
      const spread = (f - 2) * 0.33 * (0.4 + 0.6 * op) + Math.PI / 2 * 0 ;
      let a = Math.PI / 2 + spread, x = base[0] + (f - 2) * 11, y = base[1] + 22;
      const pts: P[] = [[x, y]];
      const lens = [20, 24, 22, 17, 14][f === 0 || f === 4 ? 3 : f === 2 ? 1 : 2] * 1;
      for (let s = 0; s < 3; s++) { a -= (f === 0 ? -1 : 1) * 0 + (cur * 1.0) * (s + 1) * 0.35 * Math.sign(2 - f || 1); x += Math.cos(a) * lens; y += Math.sin(a) * lens * 0.9; pts.push([x, y]); }
      fingers.push(pts);
    }
    poly(L.front, [[base[0] - 34, base[1] - 4], [base[0] + 34, base[1] - 4], [base[0] + 30, base[1] + 24], [base[0] - 30, base[1] + 24]], 0x030208, 0.97 * alpha);
    for (const f of fingers) { ribbon(L.front, f, (i, n) => 9 - i * 1.6 + 1, 0x030208, 0.97 * alpha); line(L.add, f, 1, 0xffd8a0, 0.55 * alpha); }
    // thumb
    ribbon(L.front, [[base[0] - 32, base[1] + 6], [base[0] - 46 + cur * 18, base[1] + 24], [base[0] - 44 + cur * 26, base[1] + 40 - cur * 6]], (i) => 9 - i * 2, 0x030208, 0.97 * alpha);
  };
  const frags: { pts: P[]; x: number; y: number; vx: number; vy: number; r: number; vr: number; l: number }[] = [];
  c.each((t, dt) => {
    const L = c.L;
    const bar = BAR(t);
    const build = sstep(1.0, 3.0, t);
    const dark = sstep(2.0, 5, t) * 0.4 + 0.2 * sstep(7.1, 8, t);
    c.darken(t < 9.4 ? dark : 0.3 * (1 - prog(t, 9.4, 11)));
    // launched threads from the circling spindle to anchor points above each target
    for (let i = 0; i < 3; i++) {
      const g = ease.out(prog(t, 0.7 + i * 0.75, 1.5 + i * 0.75));
      if (g <= 0) continue;
      const hubs = [4, 3, 2][i];
      void hubs;
      const anc: P = [home[i][0], home[i][1] - 96];
      const src: P = t < 4.2 ? [c.caster.x, c.caster.y - 8] : home[i];
      line(L.front, [src, [lerp(src[0], anc[0], g), lerp(src[1], anc[1], g) - Math.sin(g * Math.PI) * 14]], 1, SIL, 1 - sstep(2.8, 3.6, t));
      if (g < 1) sparkle(L.add, lerp(src[0], anc[0], g), lerp(src[1], anc[1], g) - Math.sin(g * Math.PI) * 14, 4, WH, 1, t * 5);
    }
    // apparatus: crossbeams + golden nodes
    if (build > 0) {
      const [a, b, c2, d, ctr] = bar.n;
      for (const [p, q] of [[a, b], [c2, d]]) { line(L.front, [p, q], 4, 0x20180a, build); line(L.front, [p, q], 2, 0xb08a3a, build); line(L.add, [p, q], 1, GOLD, 0.7 * build); }
      for (const nd of bar.n) { disc(L.front, nd[0], nd[1], 4, 0x20180a, build); disc(L.add, nd[0], nd[1], 3, GOLD, build); disc(L.add, nd[0] - 1, nd[1] - 1, 1.2, WH, build); halo(L.add, nd[0], nd[1], 9, GOLD, 0.3 * build, 1); }
      // suspension rods up to the shadow-hand
      line(L.front, [ctr, [CX, 40]], 1, 0xb08a3a, build);
      void c2; void d;
    }
    // strings: curved bundles, with tension and travelling knots
    for (let i = 0; i < 3; i++) {
      const e = c.enemies[i];
      const lf = lift(t, i);
      const ez = e.z;
      const attach: P[] = [[e.x, e.y - 15 - ez], [e.x - 6, e.y - 8 - ez], [e.x + 6, e.y - 8 - ez]];
      for (let j = 0; j < 3; j++) {
        const nd = bar.n[assign[i][j]];
        const tn = ten(t, i, j);
        const col = t > 8.2 ? mix(GOLD, WH, 0.8) : mix(0xcfb070, WH, tn * 0.6);
        const g = ease.out(prog(t, 1.9 + i * 0.3 + j * 0.15, 2.8 + i * 0.3 + j * 0.15));
        if (g <= 0) continue;
        const sag = 22 * (1 - tn) * (1 - lf) * (t > 8.2 ? 0.3 : 1);
        const mid: P = [(nd[0] + attach[j][0]) / 2 + Math.sin(t * 2 + i + j) * 3 * (1 - tn), (nd[1] + attach[j][1]) / 2 + sag];
        const pts = sample((u) => bez2(nd, mid, attach[j], u), 14);
        const sub = pts.slice(0, Math.max(2, Math.ceil(g * pts.length)));
        line(L.front, sub, 2, 0x0a0814, 0.7);
        line(L.front, sub, 1, col, 1);
        line(L.add, sub, 2, GOLD, 0.15 + 0.4 * tn + (t > 8.2 ? 0.4 : 0));
        // knots slide along the strings and change the structure's shape
        const kf = ((t * 0.35 + i * 0.3 + j * 0.2) % 1);
        const kp = pts[Math.floor(kf * (pts.length - 1))];
        disc(L.add, kp[0], kp[1], 1.8, GOLD, g); disc(L.front, kp[0], kp[1], 1.2, WH, g);
      }
      // tension pulls and turns the target
      if (t > 3.6 && t < 7.1) {
        let dx = 0, dy = 0, rot = 0;
        for (let j = 0; j < 3; j++) { const tn = ten(t, i, j), nd = bar.n[assign[i][j]]; dx += (nd[0] - e.hx) * 0.03 * tn; rot += (j === 1 ? -1 : j === 2 ? 1 : 0) * 0.25 * tn; dy -= 2 * tn; }
        e.pin(home[i][0] + dx, home[i][1] + dy, 5 * ten(t, i, 0) + 3 * ten(t, i, 1), rot);
      }
      if (t >= 7.1 && t < 9.0 + i * 0.3) e.pin(home[i][0] + Math.sin(t * 9 + i) * 0.8 * lf, home[i][1], 14 + 46 * lf + Math.sin(t * 4 + i) * 2, 0.35 * Math.sin(t * 2 + i));
      void ez;
    }
    // shadow-hand and the eclipse behind the suspended targets
    const cur = ease.io(prog(t, 7.5, 8.3)) * 1;
    hand(t, cur);
    const ecl = ease.out(prog(t, 7.1, 7.9)) * (1 - sstep(9.1, 9.3, t));
    if (ecl > 0) {
      const R = 48 * ecl, ex = CX, ey = 128;
      const sc = R / 26;
      stampOn(L.add, 'corona_ring', ex, ey, { sx: sc * 1.15, sy: sc * 1.15, rot: t * 0.4, tint: GOLD, alpha: 0.85 * ecl, add: true });
      stampOn(L.add, 'corona_ring', ex, ey, { sx: sc * 0.95, sy: sc * 0.95, rot: -t * 0.6, tint: ROSE, alpha: 0.75 * ecl, add: true });
      disc(L.front, ex, ey, R, 0x04020a, 0.98);
      gring(L.add, ex, ey, R + 1, GOLD, 2, ecl, 0, TAU, 1);
    }
    // strings collapse into filaments; each target gets its own pulse
    for (let i = 0; i < 3; i++) {
      const tp = 8.4 + i * 0.25, u = prog(t, tp, tp + 0.35);
      if (u > 0 && u < 1) {
        const e = c.enemies[i], nd = bar.n[assign[i][0]];
        const x = lerp(nd[0], e.x, ease.in(u)), y = lerp(nd[1], e.y - 15 - e.z, ease.in(u));
        halo(L.add, x, y, 12, WH, 0.9, 1); line(L.add, [[lerp(nd[0], x, 0.1), lerp(nd[1], y, 0.1)], [x, y]], 3, WH, 1);
      }
    }
    // shattered shadow
    for (let i = frags.length - 1; i >= 0; i--) {
      const f = frags[i]; f.l += dt; f.x += f.vx * dt; f.y += f.vy * dt; f.vy += 150 * dt; f.r += f.vr * dt;
      const a = 1 - prog(f.l, 1.0, 2.4);
      if (a <= 0) { frags.splice(i, 1); continue; }
      const cs = Math.cos(f.r), sn = Math.sin(f.r);
      const pts = f.pts.map((p) => [f.x + p[0] * cs - p[1] * sn, f.y + p[0] * sn + p[1] * cs] as P);
      poly(L.front, pts, 0x030208, a); line(L.add, [...pts, pts[0]], 1, GOLD, 0.6 * a);
    }
    void dt;
  });
  [0, 1, 2].forEach((i) => c.at(8.75 + i * 0.25, () => {
    const e = c.enemies[i];
    c.strike(e, Math.atan2(e.y - 168, e.x - CX) + 0.2, 300, 180, WH, 14);
    c.shock(e.x, e.y, { r: 50, life: 0.6, col: GOLD, w: 3, amp: 3 });
    slashX(c, e.x, e.y - 14, WH, 28, 0.4, i);
  }));
  c.at(7.1, () => { c.shake(8); c.flash(GOLD, 0.35); c.shock(CX, 170, { r: 90, life: 0.8, col: GOLD, w: 4, amp: 4 }); });
  c.at(9.15, () => {
    c.flash(WH, 1); c.shake(14); c.slow(0.35, 0.3);
    for (let i = 0; i < 40; i++) { const a = rr(0, TAU), r = rr(0, 60), s = rr(0, TAU), l = rr(6, 18); frags.push({ pts: [[0, -l], [l * 0.8, l * 0.5], [-l * 0.6, l * 0.7]], x: CX + Math.cos(a) * r, y: 128 + Math.sin(a) * r * 0.8, vx: Math.cos(a) * rr(60, 220), vy: Math.sin(a) * rr(40, 160) - 60, r: s, vr: rr(-6, 6), l: 0 }); }
    for (let i = 0; i < 260; i++) c.emit('add', { x: rr(20, W - 20), y: rr(-10, 90), vx: rr(-8, 8), vy: rr(30, 120), ay: 40, life: rr(1.4, 3.2), size: 1, c0: i % 3 ? GOLD : WH, c1: 0x7a4a20, streak: 0.45, hold: rr(0, 0.5) });
    c.burst('add', CX, 128, 110, { spd: [60, 300], life: [0.6, 1.5], cols: [GOLD, WH, 0xffe9b0], streak: 0.03, drag: 1.4 });
    c.shock(CX, 170, { r: 220, life: 1.2, col: GOLD, w: 5, amp: 5 });
    ringScar(c, CX, 170, 60, 5, GOLD, 2); crackScar(c, CX, 170, 8, 90, 5, GOLD);
  });
}

// ============================================================ 16 LOOM OF THE LAST HORIZON
function s16(c: Ctx) {
  const TL: P = [92, 60], TR: P = [388, 60], BR: P = [418, 230], BL: P = [62, 230];
  const NC = 34, NR = 20, hzY = 142;
  c.layout([[150, 150], [320, 140], [240, 190], [190, 100], [350, 200]]);
  const homeE = c.enemies.map((e) => [e.hx, e.hy] as P);
  const corners: P[] = [TL, TR, BR, BL];
  const out: P[] = [[TL[0] - 20, TL[1] - 6], [TR[0] + 20, TR[1] - 6], [BR[0] + 22, BR[1] + 6], [BL[0] - 22, BL[1] + 6]];
  const planted = [0.55, 1.1, 1.65, 2.2];
  let prev: P = [30, 150];
  out.forEach((p, i) => { const f = prev; c.seg(planted[i] - 0.4, planted[i], (u) => [lerp(f[0], p[0], u), lerp(f[1], p[1], u) + 4 - Math.sin(u * Math.PI) * 10], ease.outExpo); prev = p; });
  c.seg(2.6, 2.95, (u) => [lerp(prev[0], out[0][0], u), lerp(prev[1], out[0][1], u)], ease.outExpo);
  // moves through the tapestry while it folds forward
  c.seg(6.4, 8.2, (u) => [lerp(out[0][0], CX + 30, ease.io(u)) + Math.sin(u * 8) * 16, lerp(out[0][1], 170, u) + Math.sin(u * 6) * 14, Math.sin(u * Math.PI) * 18], ease.lin);
  c.seg(8.2, 8.9, (u) => [lerp(CX + 30, out[0][0] + 4, ease.io(u)), lerp(170, out[0][1] + 4, ease.io(u))], ease.lin);
  c.seg(8.9, 9.2, () => [out[0][0] + 4, out[0][1] + 4]);
  c.seg(9.9, 10.5, (u) => [lerp(out[0][0], 120, u), lerp(out[0][1], 215, u)], ease.io);
  c.caster.trail = GOLD;
  const warp = (u: number, v: number): P => {
    const top: P = [lerp(TL[0], TR[0], u), lerp(TL[1], TR[1], u)], bot: P = [lerp(BL[0], BR[0], u), lerp(BL[1], BR[1], u)];
    return [lerp(top[0], bot[0], v), lerp(top[1], bot[1], v)];
  };
  const scene = (u: number, v: number, t: number): number => {
    const hz = 0.6 + 0.02 * Math.sin(u * 5);
    const star = hash2(Math.floor(u * 80), Math.floor(v * 40));
    if (v < hz) {
      const mt = hz - (0.1 + 0.07 * Math.sin(u * 9 + t * 0.15) + 0.05 * Math.sin(u * 23 + 1) + 0.06 * Math.max(0, Math.sin(u * 4 + t * 0.1 + 2)));
      if (v > mt) return mix(0x2a2040, 0x70507a, (v - mt) / (hz - mt + 0.001));
      const pd = Math.hypot((u - 0.72) * 2.2, v - 0.26);
      if (pd < 0.09) return mix(0xffd9a0, 0xb06a60, pd / 0.09);
      if (Math.abs(pd - 0.14) < 0.012 && Math.abs(v - 0.26 - (u - 0.72) * 0.15) < 0.04) return 0xd8c0a0;
      const isl = Math.hypot((u - 0.25 - 0.02 * Math.sin(t * 0.3)) * 3, (v - 0.3) * 6);
      if (isl < 0.5 && v > 0.3 - isl * 0.1) return 0x5a6a9a;
      if (star > 0.965) return star > 0.99 ? 0xffffff : 0xb0c8ff;
      return mix(0x0a0a28, 0x6a3a7a, Math.pow(v / hz, 2.2));
    }
    const g = (v - hz) / (1 - hz);
    return mix(0xd09a50, 0x1a1020, Math.min(1, g * 1.6)) ;
  };
  const NF = c.enemies.length;
  void NF;
  const struck = c.enemies.map(() => false);
  const sw = (t: number) => ease.io3(prog(t, 9.3, 11.9)) * 2.2;
  const loose: { x: number; y: number; vx: number; vy: number; l: number; col: number; len: number }[] = [];
  const unrav = (u: number, v: number) => 9.3 + ((u + v) / 2) * 2.7;
  c.each((t, dt) => {
    const L = c.L;
    c.darken(0.4 * sstep(1.5, 4, t));
    const weaveStart = 2.7, growW = prog(t, 2.5, 3.6);
    const comp = ease.io3(prog(t, 11.9, 12.5));
    const horizonLine = t > 12.35 && t < 13.05;
    // needle constructs at the corners
    corners.forEach((p, i) => {
      if (t < planted[i] - 0.05) return;
      const k = ease.outBack(prog(t, planted[i] - 0.05, planted[i] + 0.5));
      const o = out[i], h = 66 * k;
      poly(L.front, [[o[0], o[1] - h], [o[0] + 4, o[1] - h * 0.7], [o[0] + 1.5, o[1]], [o[0] - 1.5, o[1]], [o[0] - 4, o[1] - h * 0.7]], 0xcfd6ff, 1);
      L.front.rect(o[0] - 1, o[1] - h + 6, 2, 8).fill(0x1a1030);
      gring(L.glow, o[0], o[1], 10 + 10 * Math.exp(-(t - planted[i]) * 3), GOLD, 1, 0.8, 0, TAU, YS);
      halo(L.add, o[0], o[1] - h * 0.6, 14, GOLD, 0.25, 1);
      if (t < 2.6) line(L.add, [[o[0], o[1] - h + 8], [i ? out[i - 1][0] : o[0], i ? out[i - 1][1] - 66 + 8 : o[1] - h + 8]], 1, GOLD, 0.3 * (1 - prog(t, planted[i], planted[i] + 0.7)));
    });
    if (t > 2.4 && t < 2.62) { const tg = t - 2.4; line(L.add, [[out[0][0], out[0][1] - 58], [out[0][0] + tg * 1000, out[0][1] - 58]], 1, GOLD, 0.8); }
    // ---- the tapestry as a displaced mesh
    const fold = (u: number, v: number): { p: P; sh: number; under: boolean; a: number } => {
      let [x, y] = warp(u, v);
      let sh = 0, under = false, a = 1;
      const foldPos = ease.io(prog(t, 6.4, 8.2));
      if (t > 6.4 && t < 9.3) {
        const d = (u - (0.1 + 0.8 * foldPos)) / 0.16;
        const ridge = Math.exp(-d * d);
        y -= 34 * ridge * (0.7 + 0.3 * Math.sin(v * 9 + t * 2));
        x += 10 * ridge * Math.sign(d || 1);
        sh = (d > 0 ? -1 : 1) * ridge * 0.7; under = ridge > 0.55 && d < 0;
      }
      if (t >= 9.3) {
        const tau = unrav(u, v), loosen = clamp((t - tau) / 0.9);
        a = 1 - loosen;
        const wf = (u + v) / 2 * (2.7 / 2.2) - sw(t) / 2.2 * 1.0;
        void wf;
        // cloth whipping ahead of the unravel front
        const front = (t - 9.3) / 2.7, here = (u + v) / 2, dd = (here - front) / 0.14;
        const whip = Math.exp(-dd * dd) * (loosen < 1 ? 1 : 0);
        y += whip * (40 * Math.sin(u * 12 - t * 18)) + loosen * (Math.sin(v * 20 + t * 14) * 12 + 20 * loosen);
        x += whip * 18 * Math.sin(v * 9 + t * 11) + loosen * 30 * (u - 0.3);
        sh += whip * 0.8;
      }
      if (comp > 0) { y = lerp(y, hzY + (v - 0.5) * 1, comp); x = lerp(x, x, comp); a *= 1 - sstep(0.55, 1, comp); }
      return { p: [x, y], sh, under, a };
    };
    const reveal = (v: number) => ease.out(prog(t, 3.0 + v * 3.3, 3.6 + v * 3.3));
    if (growW > 0 && t < 12.9) {
      // warp threads first
      if (t < 3.8) for (let cI = 0; cI <= NC; cI += 2) { const u = cI / NC; const a = warp(u, 0), b = warp(u, growW); line(L.front, [a, b], 1, SIL, 0.9); }
      // shuttles lay weft row by row
      const rowsDone = clamp((t - weaveStart) / 3.6) * NR;
      const grid: { p: P; sh: number; under: boolean; a: number }[][] = [];
      for (let r = 0; r <= NR; r++) { grid[r] = []; for (let cI = 0; cI <= NC; cI++) grid[r][cI] = fold(cI / NC, r / NR); }
      for (let r = 0; r < NR; r++) {
        const rowT = clamp(rowsDone - r);
        if (rowT <= 0) continue;
        const dirR = r % 2 ? -1 : 1;
        const cMax = Math.floor(rowT * NC);
        for (let cI = 0; cI < NC; cI++) {
          const cc = dirR > 0 ? cI : NC - 1 - cI;
          if (cI > cMax) continue;
          const u = (cc + 0.5) / NC, v = (r + 0.5) / NR;
          const g = grid[r][cc], g2 = grid[r][cc + 1], g3 = grid[r + 1][cc + 1], g4 = grid[r + 1][cc];
          if (g.a <= 0.02) continue;
          const base = scene(u, v, t);
          const over = (cc + r) % 2 === 0;
          let col = mix(base, over ? 0xffe6a8 : 0x403048, over ? 0.18 : 0.22);
          col = mix(col, 0x000000, clamp(-g.sh * 0.5));
          if (g.sh > 0) col = mix(col, 0xffffff, g.sh * 0.3);
          if (g.under) col = mix(col, 0x7a60c0, 0.5);
          const rv = reveal(v);
          col = mix(0x1a1424, col, rv);
          poly(L.front, [g.p, g2.p, g3.p, g4.p], col, 0.93 * g.a);
          if (over && rv > 0.2) L.front.rect(Math.floor(g.p[0]), Math.floor(g.p[1]), 1, 1).fill({ color: GOLD, alpha: 0.5 * g.a });
        }
        // shuttle
        if (rowT < 1) { const cc = dirR > 0 ? rowT * NC : (1 - rowT) * NC; const sp = fold(cc / NC, (r + 0.5) / NR).p; diamond(L.add, sp[0], sp[1], 7, 2, 0, WH, 1); halo(L.add, sp[0], sp[1], 10, GOLD, 0.7, 1); line(L.add, [sp, warp(dirR > 0 ? 0 : 1, (r + 0.5) / NR)], 1, GOLD, 0.7); }
      }
      // tears along the unravel front
      if (t > 9.3 && t < 12.2) {
        const front = (t - 9.3) / 2.7 * 2 * 1.0;
        for (let k = 0; k < 14; k++) {
          const cI = Math.floor(rand() * NC), rI = Math.round((front - cI / NC) * NR) ;
          if (rI < 0 || rI > NR) continue;
          const a = grid[rI][cI].p, b = grid[Math.min(NR, rI + 1)][Math.min(NC, cI + 2)].p;
          line(L.add, [a, [(a[0] + b[0]) / 2 + rr(-6, 6), (a[1] + b[1]) / 2 + rr(-6, 6)], b], 1, k % 2 ? WH : GOLD, 0.95);
        }
        c.post.slice = [2.5, 0.8, 12, t * 4];
      }
      void grid;
    }
    // fold-forward reveals: shading of ridge handled above; vertical thread accents
    if (t > 6.4 && t < 9.3) { const fp = ease.io(prog(t, 6.4, 8.2)); const x = lerp(TL[0], TR[0], 0.1 + 0.8 * fp); line(L.add, [[x, 70], [x + 20, 224]], 1, mix(GOLD, WH, 0.5), 0.35); c.lens(x, 150, 70, 0.4); }
    // enemies silhouetted against the geometry; whipped by passing cloth
    if (t > 3.5 && t < 11.9) c.silhouette(0.85 * sstep(3.5, 6, t) * (1 - sstep(11, 11.9, t)));
    c.enemies.forEach((e, i) => {
      if (t > 3.5 && t < 9.3) e.pin(homeE[i][0], homeE[i][1], 0, 0);
      if (t >= 9.3 && !struck[i]) {
        const u = clamp((e.x - 62) / 356, 0, 1), v = clamp((e.y - 60) / 170, 0, 1);
        const front = (t - 9.3) / 2.7;
        if (Math.abs((u + v) / 2 - front) < 0.07) { struck[i] = true; c.strike(e, Math.atan2(e.y - 60, e.x - 92) + 0.3, 250, 150, GOLD, 12); slashLine(c, e.x - 30, e.y - 20, 0.6, 70, WH, 0.35); }
        else e.pin(homeE[i][0], homeE[i][1], 0, 0);
      }
    });
    // falling golden threads from unravelled cells
    if (t > 9.4 && t < 12.4) for (let k = 0; k < 6; k++) { const u = rand(), v = rand(); if (t > unrav(u, v)) { const p = warp(u, v); c.emit('add', { x: p[0], y: p[1], vx: rr(-30, 30), vy: rr(10, 80), ay: 60, life: rr(0.6, 1.4), size: 1, c0: rand() < 0.5 ? GOLD : WH, c1: 0x7a4a20, streak: 0.3 }); } }
    // the razor-thin horizon
    if (horizonLine) {
      const k = sstep(12.35, 12.55, t) * (1 - sstep(12.85, 13.05, t));
      L.add.rect(60, hzY - 1, 360, 2).fill({ color: WH, alpha: k });
      L.add.rect(60, hzY - 4, 360, 8).fill({ color: GOLD, alpha: 0.35 * k });
      halo(L.add, CX, hzY, 80, GOLD, 0.35 * k, 0.12);
      c.post.aberr = 2.5 * k;
    } else if (t > 11.9 && t < 12.35) c.darken(0.5 * comp);
    for (let i = loose.length - 1; i >= 0; i--) { const q = loose[i]; q.l += dt; }
    void dt;
  });
  planted.forEach((pt, i) => c.at(pt, () => { c.shock(out[i][0], out[i][1], { r: 44, life: 0.5, col: GOLD, w: 3, amp: 3 }); c.shake(3); c.burst('add', out[i][0], out[i][1] - 10, 14, { spd: [20, 100], life: [0.3, 0.7], cols: [GOLD, WH], ys: YS }); }));
  c.at(9.2, () => { slashLine(c, out[0][0] - 10, out[0][1] - 40, 0.5, 100, WH, 0.4); c.flash(GOLD, 0.5); c.shake(6); c.burst('add', out[0][0], out[0][1] - 40, 40, { spd: [30, 200], life: [0.4, 1], cols: [GOLD, WH], streak: 0.03 }); });
  c.at(12.9, () => {
    c.flash(WH, 1); c.shake(15); c.slow(0.3, 0.3);
    c.blast(CX, hzY + 20, 320, 280, 150);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - hzY + rr(-10, 10), e.x - CX + rr(-20, 20)), 270, 160, GOLD, 14));
    c.shock(CX, hzY + 20, { r: 300, life: 1.2, col: GOLD, w: 5, amp: 6, ys: 0.4 });
    c.shock(CX, hzY + 20, { r: 160, life: 0.9, col: WH, w: 4, amp: 4 });
    for (let i = 0; i < 260; i++) { const a = rr(0, TAU), s = rr(60, 360); c.emit('add', { x: rr(70, 410), y: hzY + rr(-2, 2), vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.7, life: rr(0.7, 2), size: 1, c0: i % 3 ? GOLD : WH, c1: 0x7a4a20, streak: 0.06, drag: 1.2 }); }
    c.ent(1.4, (_a, u) => { for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU, d = 20 + 180 * ease.out(u) * (0.5 + (i % 3) * 0.3); sparkle(c.L.add, CX + Math.cos(a) * d, hzY + Math.sin(a) * d * 0.6, 8 * (1 - u) + 2, i % 2 ? GOLD : WH, 1 - u, a + u * 3); } });
    for (let i = 0; i < 40; i++) c.emit('deb', { x: rr(80, 400), y: hzY, z: 0, vx: rr(-120, 120), vy: rr(-40, 40), vz: rr(100, 320), gz: 360, life: rr(1, 2.2), size: rr(1, 3), c0: [0x5a6a9a, GOLD, 0x403048][i % 3], c1: 0x201830, bounce: 0.4 });
    ringScar(c, CX, 185, 88, 5, GOLD, 2);
    crackScar(c, CX, 185, 9, 115, 5, GOLD);
  });
}

export const SPINDLE: Skill[] = [
  { id: 13, relic: 'spindle', name: 'Starlace Execution', sub: 'two needle passes weave a star lace; knots ignite in order', dur: 12.5, phases: [[0.45, 'Outer star'], [3.1, 'Inner star'], [5.3, 'Pull taut'], [6.3, 'Knots ignite'], [9.3, 'Stellar seal'], [10.4, 'Shatter']], setup: s13 },
  { id: 14, relic: 'spindle', name: 'The Seam Between Seconds', sub: 'afterimages are stitched together, then replay as a strike cascade', dur: 11.5, phases: [[0.5, 'Dash leaves copies'], [2.5, 'Stitching time'], [5.5, 'Final thread'], [6.8, 'Cascade'], [9.5, 'Seams snap shut']], setup: s14 },
  { id: 15, relic: 'spindle', name: 'Marionette Eclipse', sub: 'tension rig, shadow-hand, lifted targets, collapse into threads of light', dur: 12.5, phases: [[0.5, 'Circle & thread'], [2.0, 'Apparatus'], [3.6, 'Strings tighten'], [7.1, 'Suspension & eclipse'], [8.4, 'Pulses'], [9.15, 'Shatter']], setup: s15 },
  { id: 16, relic: 'spindle', name: 'Loom of the Last Horizon', sub: 'needles, weaving, folding, unravelling, collapse into one horizon', dur: 14.5, phases: [[0.5, 'Four needles'], [2.6, 'Weaving'], [6.4, 'Folding'], [9.2, 'Sever & unravel'], [12.0, 'Horizon'], [12.9, 'Rupture']], setup: s16 },
];
