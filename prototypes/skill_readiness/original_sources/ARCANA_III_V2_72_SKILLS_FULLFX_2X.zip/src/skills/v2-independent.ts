/** ARCANA V2 — forty SELF-CONTAINED abilities, not clips from an ultimate.
 * Twenty pairs of different behaviors; minor = one resolved mechanism,
 * major = transformation/composition of that mechanism (not 3 more identical hits).
 * No parent setup(), no timeline seek, no parent pre-roll.
 */
import type { Skill } from '../engine/core';
import { Ctx } from '../engine/core';
import { TAU, YS, type P, clamp, ease, lerp, prog, rr, sample } from '../engine/util';
import { arcBlade, chainLine, diamond, disc, glyph, gring, line, magicSeal, ngon, ribbon, shard, star } from '../engine/draw';
import { crackScar, debris, halo, ringScar, slashLine, sparkle } from '../engine/fx';

type Mode = 'minor' | 'major';
type Spec = { small:string; large:string; family:string; tiny:string; grand:string; col:number; hi:number; duration:[number,number] };
const SPECS: Spec[] = [
 {small:'Solar Sickle',large:'Penumbra Siege',family:'halo',tiny:'curved split blades',grand:'three light-draining eclipses converge',col:0xffb849,hi:0xfff5af,duration:[4.2,7.9]},
 {small:'Comet Rebound',large:'Retrograde Collision',family:'halo',tiny:'tangent deflection',grand:'opposed figure-eights reverse through crossings',col:0xf8da76,hi:0x9be9ff,duration:[4.4,8.3]},
 {small:'Star Nail',large:'Skyfall Relay',family:'halo',tiny:'single piercing meteor',grand:'impact platforms redirect falling bodies',col:0xffac67,hi:0xffffff,duration:[4.6,8.0]},
 {small:'Horizon Shear',large:'Orthogonal Collapse',family:'halo',tiny:'displaced spatial strip',grand:'two orthogonal rings shear and fold terrain',col:0xeacb89,hi:0xc6ebff,duration:[4.3,8.1]},
 {small:'Vertebra Lash',large:'Hydra Coil',family:'chain',tiny:'segmented tightening vertebra',grand:'three independently hunting serpent heads',col:0xff5a6f,hi:0xffe3b6,duration:[4.6,8.4]},
 {small:'Serrated Manacle',large:'Cage-Shift',family:'chain',tiny:'paired V-lock chains',grand:'polyhedral prison refolds against targets',col:0xeaa6a0,hi:0xff6379,duration:[4.0,8.0]},
 {small:'Dragline',large:'Undertow Engine',family:'chain',tiny:'off-axis drag into a launch rail',grand:'opposing coupled vortices exchange pressure',col:0x886de8,hi:0xff6b8c,duration:[4.3,8.5]},
 {small:'Rib Hook',large:'Cardiac Breaker',family:'chain',tiny:'closing pairs of ribs',grand:'heartbeat travels through three skeletal chambers',col:0x6bd3ec,hi:0xff6c88,duration:[4.5,8.2]},
 {small:'Chromatic Split',large:'Chromatic Maelstrom',family:'fan',tiny:'one ray splits into three delayed cuts',grand:'seven differently-behaving fluid light lanes',col:0x56ebf9,hi:0xffb5e8,duration:[4.0,8.5]},
 {small:'False-Face Shatter',large:'Kaleidoscope Guillotine',family:'fan',tiny:'reflected decoy and deflected glass strike',grand:'beam reflections turn mirrors into guillotine blades',col:0xc9f7ff,hi:0xf6afff,duration:[4.2,8.5]},
 {small:'Ink Fang',large:'Script Execution',family:'fan',tiny:'ink stroke grows into predatory jaw',grand:'three connected strokes become successive ink blades',col:0xff8bca,hi:0xffe8a0,duration:[4.7,9.0]},
 {small:'Scissorwing',large:'Murmuration Cathedral',family:'fan',tiny:'two luminous wings scissor a target',grand:'swarm assembles architecture then giant severing wings',col:0xfba9ff,hi:0x8bffed,duration:[4.1,8.3]},
 {small:'Needle Gate',large:'Fate Crossfire',family:'spindle',tiny:'gate carries a pulse to a target',grand:'reconnecting needle graph routes combined pulses',col:0xc6a3ff,hi:0xffebfb,duration:[4.0,8.8]},
 {small:'Backstitch',large:'Temporal Avalanche',family:'spindle',tiny:'rewound strike follows an old dash',grand:'three frozen events reactivate in reverse order',col:0xa8aaff,hi:0xeaf5ff,duration:[4.5,8.4]},
 {small:'Predator Thread',large:'String Orchestra',family:'spindle',tiny:'angled pull bends into a blade',grand:'three different tension systems drive triangle convergence',col:0xe8a8fc,hi:0xffe68d,duration:[4.2,8.2]},
 {small:'Aegis Unfurl',large:'Loom Guillotine',family:'spindle',tiny:'woven shield dimples then rebounds',grand:'fabric rows rise as sequential slicing folds',col:0xc2aeff,hi:0xffebbb,duration:[4.6,8.9]},
 {small:'Phantom Passage',large:'Wraith Cavalcade',family:'lantern',tiny:'three ghosts follow and strike along a track',grand:'two spectral armies converge on the group',col:0x92dfff,hi:0xe9faff,duration:[4.0,8.5]},
 {small:'Soul Comet',large:'Mortuary Bloomfield',family:'lantern',tiny:'one arcing soul blossoms upon collision',grand:'impact seeds ignite a branching field of flowers',col:0x78dfff,hi:0xffd0fa,duration:[4.1,8.4]},
 {small:'Resonance Fang',large:'Antiphonal Destruction',family:'lantern',tiny:'wave rebounds after enemy collision',grand:'two interference fields make a moving damage seam',col:0x93e5f0,hi:0xd2e4ff,duration:[4.6,8.7]},
 {small:'Void Bite',large:'Abyss Fold',family:'lantern',tiny:'collapsing aperture bites the world',grand:'paired portals ingest and expel the same energy stream',col:0x94aeff,hi:0xdbb9ff,duration:[4.3,8.8]},
];
const O:P=[242,150];
const rad=(x:number,y:number,r:number,a:number,ys=YS):P=>[x+Math.cos(a)*r,y+Math.sin(a)*r*ys];
const curve=(f:(u:number)=>P,n=26,u=1):P[]=>sample(f,n,0,Math.max(0.001,u));
const path=(a:P,b:P,n=13):P[]=>curve(u=>[lerp(a[0],b[0],u),lerp(a[1],b[1],u)],n);
const pulse=(t:number,a:number,b:number,tail=0.9)=>clamp((t-a)/Math.max(0.01,b-a))*clamp((b+tail-t)/tail);
const fade=(t:number,start:number,end:number)=>1-prog(t,start,end);
function bloom(c:Ctx,x:number,y:number,col:number,hi:number,large:boolean,shape:'star'|'shard'|'wing'|'bone'='shard'){
 c.flash(hi,large?0.66:0.43);c.shake(large?5.7:3.2);
 c.burst('add',x,y,large?52:25,{spd:[55,large?235:130],life:[0.45,1.35],size:[2,large?8:5],size1:0.8,cols:[col,hi,0xffffff],tex:shape,streak:0.025});
 c.burst('low',x,y,large?17:8,{spd:[22,105],life:[0.65,1.45],cols:[0x564b62,0x81768b],tex:'smoke',size:[2,6],drag:1.9});
 c.distort(x,y,large?72:37,large?4.0:2.1);
}
function hit(c:Ctx,x:number,y:number,col:number,hi:number,k=0,large=false){
 const e=c.enemies[k%c.enemies.length]; if(!e) return;
 const angle=Math.atan2(e.y-y,e.x-x);
 c.strike(e,angle,large?200:112,large?112:60,col,large?10:5);
 bloom(c,e.x,e.y-6,col,hi,large);
}
/** A hit is an EVENT on the visible phenomenon's path, not a free-floating burst.
 * The contact wake has the physical vocabulary of the originating relic.
 */
function contactWake(c:Ctx, index:number, start:P, e:{x:number;y:number}, col:number, hi:number, big:boolean){
 const target:P=[e.x,e.y-7],angle=Math.atan2(target[1]-start[1],target[0]-start[0]);
 const len=Math.hypot(target[0]-start[0],target[1]-start[1]);
 c.ent(big?0.72:0.46,(_age,u)=>{
   const a=(1-u)*0.95; const end:P=[lerp(start[0],target[0],ease.out(u)),lerp(start[1],target[1],ease.out(u))];
   switch(Math.floor(index/4)){
    case 0: { // celestial edge carried by the blade's real swept line
      ribbon(c.L.add,[start,end],big?10:6,col,a);
      arcBlade(c.L.glow,target[0],target[1],big?39:24,angle-1.2+u,angle+0.15+u,0.17,hi,a);
      break;
    }
    case 1: { // serpentine link advances through the target
      const p0:P=[lerp(start[0],end[0],0.5),lerp(start[1],end[1],0.5)+Math.sin(u*Math.PI)*17];
      chainLine(c.L.front,[start,p0,end],big?8:10,col,big?4:3,hi);
      break;
    }
    case 2: { // coloured sheet or ink ripple travels along the cut
      const pts=curve(v=>[lerp(start[0],end[0],v),lerp(start[1],end[1],v)+Math.sin(v*Math.PI*2+u*3)*9*v],18);
      ribbon(c.L.glow,pts,big?10:6,col,a);
      shard(c.L.add,...end,big?18:12,6,angle,hi,a);
      break;
    }
    case 3: { // nerve packet is conducted through a taut thread
      line(c.L.glow,[start,end],big?3:2,col,a);
      diamond(c.L.add,...end,big?16:10,4,angle+u,hi,a);
      break;
    }
    case 4: { // ghostfire follows a distinct rushing spirit silhouette
      const ghost:P=[lerp(start[0],end[0],0.76),lerp(start[1],end[1],0.76)];
      ribbon(c.L.glow,[start,ghost,end],big?12:8,col,a*0.7);
      diamond(c.L.front,...end,big?23:16,9,angle,hi,a*0.75);
      break;
    }
   }
   if(len>30)sparkle(c.L.add,...end,big?9:6,hi,a);
 });
}
function setup(c:Ctx,index:number,mode:Mode){
 const s=SPECS[index], big=mode==='major', dur=s.duration[big?1:0];
 const begin=big?1.45:1.15, convert=big?3.05:2.1, climax=big?5.6:2.7, out=dur-1.1;
 const x=O[0], y=O[1], R=big?125:72, q=big?5:3;
 c.layout(big?[[x-78,y-25],[x+81,y-23],[x+10,y+55],[x-55,y+48],[x+61,y+44]]:[[x-35,y+7],[x+46,y-3],[x+9,y+43]]);
 c.caster.x=c.caster.tx=93;c.caster.y=c.caster.ty=199;c.caster.trail=s.col;
 // Actual caster travel with world-space mark paths. Actor artwork remains untouched.
 if ([1,4,6,10,12,13,16].includes(index)) {
   c.seg(0,convert,u=>[lerp(92,x-45,u),199-35*Math.sin(Math.PI*u)]);
   c.seg(convert,climax+0.2,u=>[lerp(x-45,x+50,u),y+33-50*Math.sin(Math.PI*u)]);
 } else if ([2,3,7,17,19].includes(index)) {
   c.seg(0,climax,u=>[lerp(88,x-16,u),lerp(198,y+24,u),Math.sin(u*Math.PI)*32]);
 } else c.seg(0,climax,u=>[lerp(94,x-35+50*u,u),lerp(196,y+34,u)-14*Math.sin(Math.PI*u)]);
 c.at(0.12,()=>c.burst('add',93,192,20,{spd:[25,100],life:[0.38,0.85],cols:[s.col,s.hi],tex:'spark',size:[2,4]}));
 const target=(k:number)=>c.enemies[k%c.enemies.length];
 // Contact is scheduled from the geometry's narrative — different schemes per skill.
 const contacts= big
  ? ([2,7,17,18].includes(index)?[convert+0.2,convert+1.05,climax,climax+0.5]:[10,12,13,14,15,19].includes(index)?[convert+0.45,climax-0.85,climax,climax+0.46]:[climax-0.7,climax,climax+0.6])
  : ([1,4,13,16,18].includes(index)?[climax-0.26,climax]:[climax]);
 contacts.forEach((time,k)=>c.at(time,()=>{
   const e=target((index+k)%c.enemies.length);if(!e)return;
   if([5,6,7,14,19].includes(index) && time<climax) e.pin(x+(k-1)*18,y+(k%2)*9,10+(k%3)*8);
   contactWake(c,index,[x,y],e,s.col,s.hi,big);
   hit(c,x,y,s.col,s.hi,(index+k)%c.enemies.length,big&&k===contacts.length-1);
   if ([2,3,7,15,17,19].includes(index)) crackScar(c,e.x,e.y,4,big?40:21,2.4,s.col);
   else if ([0,1,8,11,18].includes(index))ringScar(c,e.x,e.y,big?44:25,1.65,s.col,3);
   else slashLine(c,e.x,e.y-5,0.4+k*0.8,big?57:31,s.hi,0.45);
 }));
 if(big) c.at(climax+0.95,()=>{
   if([0,2,3,7,8,11,17,18,19].includes(index))c.shock(x,y,{r:142,life:1.1,col:s.col,col2:s.hi,w:3,amp:3.7,push:170,lift:70});
   else c.burst('add',x,y,68,{spd:[35,235],life:[0.45,1.4],cols:[s.col,s.hi,0xffffff],tex:index===10?'flame':'shard',size:[2,7],streak:0.032});
   c.flash(s.hi,0.55);c.shake(5);
 });
 c.at(dur-1.1,()=>{
   if([2,3,5,7,15,17,19].includes(index))crackScar(c,x,y,big?8:4,big?88:40,3.1,s.col);
   else ringScar(c,x,y,big?104:52,2.8,s.col,big?3:2);
   debris(c,x,y,big?25:11,[s.col,s.hi,0x4c425a],big?125:75);
 });
 // Distinct evolving VFX systems, fully simulated from t=0; large and small are NOT the same animation scaled up.
 c.each((t,dt)=>{
   const L=c.L, construct=ease.out(prog(t,0.15,begin)), growth=ease.io(prog(t,begin,convert));
   const surge=ease.out(prog(t,convert,climax)), decay=fade(t,out,dur);
   const a=clamp(t*3.5)*decay, phase=surge, A=t*0.75, outer=R*(0.28+construct*0.26+growth*0.46);
   if(a<=0.001)return;
   switch(index){
    case 0: { // minor two mirrored cutting sickles; major three overlapping absorption wells with a shared collapsing corona
      if(!big){for(let j=0;j<2;j++){const aa=A*(j?-1:1)+j*Math.PI;arcBlade(L.add,x,y,outer,aa,aa+Math.PI*0.85,0.2,j?s.hi:s.col,a,YS);const pp=rad(x,y,outer,aa+phase*2.2);shard(L.front,...pp,20,6,aa+0.7,s.hi,a);}}
      else {for(let j=0;j<3;j++){const p=rad(x,y,64,j*TAU/3),r=22+growth*24-phase*18;halo(L.glow,...p,r+20,s.col,a*0.48);disc(L.dark,...p,r,0x05030c,0.96*a);gring(L.add,...p,r+4,s.hi,3,a);for(let k=0;k<3;k++)arcBlade(L.add,...p,r+13,k*TAU/3+t*(j%2?1:-1),k*TAU/3+0.8+t*(j%2?1:-1),0.16,s.col,a);}}
      break;}
    case 1: { // comet's tangent change; opposite figure eights re-trace previous coordinates, striking at crossovers
      for(let j=0;j<(big?2:1);j++){const path0=curve(v=>[x+Math.sin(v*TAU*1.25)*outer,y+Math.sin(v*TAU*2+j*1.3)*outer*0.58],48,big?1:0.73);ribbon(L.glow,path0,big?6:4,j?s.hi:s.col,0.75*a);const u=prog(t,0.4,climax),index0=Math.floor((big&&t>climax?1-u:u)*47);const pt=path0[Math.max(0,Math.min(47,index0))];diamond(L.add,...pt,big?24:15,5,A*4,s.hi,a);if(big)for(const mark of [0.18,0.5,0.81]){const p=path0[Math.round(mark*47)];sparkle(L.add,...p,5,s.hi,a*0.85);}}break;}
    case 2: { // impact relay: platform centers are physical waypoints, not random repeated falling meteors
      const nodes=big?[[x-80,y-35],[x+40,y-50],[x+60,y+27],[x-20,y+22]] as P[]:[[x,y]] as P[];
      nodes.forEach((p,j)=>{const u=prog(t,0.25+j*(big?0.63:0),climax+j*0.16),start:[number,number]=[p[0]-43,p[1]-130],cur:[number,number]=[lerp(start[0],p[0],ease.in3(u)),lerp(start[1],p[1],ease.in3(u))];ribbon(L.add,path(start,cur,12),v=>7*(v/12)+1,s.col,a);star(L.add,...cur,big?12:9,6,0.4,A,s.hi,a);if(big&&j<nodes.length-1){gring(L.glow,...p,16,s.col,2,a*growth);line(L.add,[p,nodes[j+1]],2,s.hi,a*growth*0.75);}});break;}
    case 3: { // independent spatial strip / orthogonal collapsing bands
      const rot=big?[0,Math.PI/2]:[0];for(let j=0;j<rot.length;j++){const theta=rot[j]+(big?A*0.19:0),span=outer*2;const p0: P=[x-Math.cos(theta)*span,y-Math.sin(theta)*span],p1:P=[x+Math.cos(theta)*span,y+Math.sin(theta)*span];ribbon(L.glow,[p0,p1],big?12:8,j?s.hi:s.col,a*0.82);line(L.add,[p0,p1],2,0xffffff,a);if(big){for(let m=-2;m<=2;m++){const shift=12*m*(1-phase);line(L.front,[[p0[0]+shift*Math.sin(theta),p0[1]-shift*Math.cos(theta)],[p1[0]+shift*Math.sin(theta),p1[1]-shift*Math.cos(theta)]],1,s.hi,0.25*a);}}}c.distort(x,y,outer*0.55,big?2.7:1.5);break;}
    case 4: { // vertebral arc closes; major = three separate heads, each has an articulated continuous spine
      for(let j=0;j<(big?3:1);j++){const angle=j*TAU/3;const spine=curve(v=>[x+(v-0.48)*outer*1.55*Math.cos(angle)+Math.sin(v*TAU*1.65+A*3+j)*17,y+(v-0.48)*outer*0.91*Math.sin(angle)+Math.cos(v*TAU*1.6+A*2+j)*13],36);chainLine(L.front,spine,9,s.col,big?4:3,s.hi);const head=spine[Math.min(35,Math.round(prog(t,0.35,climax)*35))];diamond(L.add,...head,18,7,angle+A,s.hi,a);if(big)ribbon(L.glow,spine,7,s.col,a*0.45);}break;}
    case 5: { // V clamp vs 5-sided shifting cage, with vertices really changing positions
      const n=big?5:2;const vertices=Array.from({length:n},(_,j)=>rad(x,y,outer*(1-phase*0.7),j*TAU/n+A*(big?0.6:0.18)+0.2));for(let j=0;j<n;j++){const p=vertices[j],q=big?vertices[(j+1)%n]:O;chainLine(L.front,[p,q],8,s.col,3,s.hi);glyph(L.add,...p,9,j,s.hi,a,A);}if(big){for(let j=0;j<n;j++){line(L.glow,[vertices[j],rad(x,y,outer*0.22,j*TAU/n)],2,s.hi,a*0.6);}}break;}
    case 6: { // off-axis tether winds into release line; major TWO different clockwise/counterclockwise rotating fields
      const wells=big?[[x-63,y],[x+63,y]] as P[]:[[x+8,y]] as P[];wells.forEach((w,j)=>{for(let k=0;k<(big?5:3);k++){const points=curve(v=>rad(w[0],w[1],outer*0.8*(1-v*0.82),k*TAU/5+v*TAU*1.5*(j? -1:1)+t*2*(j?-1:1)),31);ribbon(L.add,points,big?5:3,k%2?s.hi:s.col,a*0.88);}disc(L.dark,...w,13+growth*13,0x08051b,a);gring(L.add,...w,16+growth*14,s.hi,2,a);});if(big)ribbon(L.glow,curve(v=>[lerp(x-63,x+63,v),y+Math.sin(v*TAU*1.5+t*3)*12],26),7,s.col,a);break;}
    case 7: { // ribs are paired jaws; 3 heartbeat-activated spine chambers in major
      for(let j=0;j<(big?3:1);j++){const p=rad(x,y,big?67:5,j*TAU/3),r=(big?39:55)*(1-phase*0.58);for(let k=0;k<7;k++){const u=k/6,a0=-1.15+u*1.95,ang=a0+Math.sin(t*4-j)*0.06;arcBlade(L.add,p[0],p[1],r,ang,ang+0.34,0.25,k%2?s.hi:s.col,a,YS);}const beat=Math.pow(Math.max(0,Math.sin(t*TAU*1.15-j*0.65)),7);halo(L.glow,...p,18+beat*26,j%2?s.hi:s.col,a*(0.25+beat*0.6));}break;}
    case 8: { // 3 independently delayed rays; major seven guided flow channels with different velocities / turn angles
      const n=big?7:3,palette=[0xff5577,0xffa941,0xffff8d,0x63f6c4,0x59d5ff,0xaf95ff,0xff9fe8];for(let j=0;j<n;j++){const aa=-1.7+(j-(n-1)/2)*(big?0.21:0.36),delay=j*0.11,vis=prog(t,0.2+delay,convert+0.2);const pts=curve(v=>[x+v*outer*Math.cos(aa+v*(big?0.8:0.3)),y+v*outer*Math.sin(aa+v*(big?0.8:0.3))*0.9+Math.sin(v*TAU*1.3+A+j)*v*9],27,vis);ribbon(L.glow,pts,k=>2+Math.sin(k/27*Math.PI)*(big?11:6),palette[big?j:j*2],a*0.84);}break;}
    case 9: { // decoy mirror & reflection / cascade of glass plane mirrors + bouncing beam
      const n=big?8:3;const pts=Array.from({length:n},(_,j)=>rad(x,y,outer*(0.55+(j%3)*0.2),TAU*j/n+0.12));for(let j=0;j<n;j++){const p=pts[j];diamond(L.front,...p,big?30:19,big?10:6,A*0.22+j,s.col,0.78*a);diamond(L.add,...p,big?22:15,3,A*0.22+j,s.hi,a);if(j>0&&big)ribbon(L.glow,[pts[j-1],p],5,j%2?s.col:s.hi,a*(0.25+phase*0.7));}if(big)for(let j=0;j<n;j++)if(phase>0.5)arcBlade(L.add,...pts[j],17,A+j*0.4,A+j*0.4+1.1,0.13,s.hi,a*phase);break;}
    case 10: { // ink stroke physically draws, bends into closing jaw / major three connected streams activate in sequence
      const n=big?3:1;for(let j=0;j<n;j++){const q=prog(t,0.25+j*0.45,convert+0.3+j*0.1),a0=j*1.7+0.4,pts=curve(v=>[x+Math.cos(v*2.65+a0)*outer*(0.15+0.85*v),y+Math.sin(v*2.65+a0)*outer*(0.16+0.84*v)*0.7+Math.sin(v*TAU*2+t+j)*6],34,q);ribbon(L.front,pts,k=>2+(1-k/34)*(big?22:16),0x0d0820,a);ribbon(L.add,pts,k=>2+(1-k/34)*(big?10:6),j%2?s.hi:s.col,a*0.82);if(big&&q>=0.93){const end=pts[pts.length-1];arcBlade(L.add,...end,26,phase*2+j,phase*2+j+Math.PI*0.7,0.2,s.hi,a);}}break;}
    case 11: { // scissor = two convergent wing bodies; major swarm forms ribbed architecture then two colossal blades
      const n=big?54:14;for(let j=0;j<n;j++){const ang=j*2.39996+A*(big?0.56:0.9),distance=outer*(0.2+0.76*Math.sqrt((j+1)/n))*(1-phase*0.6),p=rad(x,y,distance,ang),wing=2+Math.abs(Math.sin(t*10+j))*4;diamond(L.add,p[0]-wing,p[1],wing*2.2,wing,ang+0.5,s.col,a*0.87);diamond(L.add,p[0]+wing,p[1],wing*2.2,wing,ang-0.5,s.hi,a*0.87);}if(big)for(let j=0;j<6;j++){const p=rad(x,y,outer*0.85,j*TAU/6);line(L.add,[p,[x,y-35]],2,s.hi,a*growth); }else for(let j of [-1,1])arcBlade(L.glow,x,y,outer*(1-phase*0.82),A+j,Math.PI*0.9+A+j,0.26,j<0?s.col:s.hi,a);break;}
    case 12: { // small one gated impulse; major star graph with actual travelling packets and rerouted edges
      const n=big?6:2,pts=Array.from({length:n},(_,j)=>rad(x,y,outer,j*TAU/n+0.35));for(let j=0;j<n;j++){const next=big?pts[(j+(growth>0.6?2:1))%n]:[x,y] as P;line(L.glow,[pts[j],next],big?3:2,s.col,a*(0.3+growth*0.7));diamond(L.front,...pts[j],13,4,A+j,s.hi,a);const u=(t*0.4+j/n)%1,packet:[number,number]=[lerp(pts[j][0],next[0],u),lerp(pts[j][1],next[1],u)];star(L.add,...packet,6,4,0.35,A,s.hi,a);}break;}
    case 13: { // rewind a real dash; major 3 moments with staggered reverse release
      const n=big?3:1;for(let j=0;j<n;j++){const delay=j*(big?0.6:0),points=curve(v=>[lerp(x-outer,x+outer,v),y+Math.sin(v*TAU*(j+1)+j)*outer*0.29],22);ribbon(L.glow,points,big?5:3,j%2?s.col:s.hi,a*0.6);const u=prog(t,0.5+delay,climax-delay*0.4),px=points[Math.min(21,Math.floor((t>convert?1-u:u)*21))];diamond(L.add,...px,big?24:18,6,A+j,s.col,a);for(const k of [0.28,0.58,0.84]){const f=points[Math.floor(k*21)];shard(L.front,...f,14,7,j,s.hi,a*0.62);}}break;}
    case 14: { // one tension line deflects target; major 3 independent tension anchors converge into force triangle
      const n=big?3:1,anchor=rad(x,y,outer,-Math.PI/2);for(let j=0;j<n;j++){const p=rad(x,y,outer,j*TAU/n-1.4),target=c.enemies[j%c.enemies.length];if(!target)continue;const ctrl:P=[lerp(p[0],target.x,0.5)+Math.sin(t*1.4+j)*24,lerp(p[1],target.y,0.5)-19];ribbon(L.glow,[p,ctrl,[target.x,target.y-10]],big?4:3,j%2?s.hi:s.col,a);diamond(L.add,...p,14,6,t+j,s.hi,a);if(big)line(L.add,[p,anchor],1,s.col,a*growth);}if(big)ngon(L.add,x,y,outer*0.35,3,A,s.hi,a);break;}
    case 15: { // small shield deflect/rebound; big weave rows elevate into slicing folded waves
      const rows=big?13:7,w=outer*1.2,h=outer*0.58;for(let j=0;j<rows;j++){const v=j/(rows-1),y0=y-h+2*h*v,lift=big?Math.sin(Math.PI*prog(t,begin+v*0.8,climax+v*0.2))*34:Math.sin(Math.PI*phase)*-15;const pp:[number,number][]=[[x-w,y0],[x,y0+lift],[x+w,y0]];ribbon(L.front,pp,big?4:2,j%3?s.col:s.hi,a*0.74);if(big&&v<surge){const slash:[number,number][]=[[x-w,y0-lift],[x+w,y0-lift]];ribbon(L.add,slash,3,s.hi,a*phase);}}for(let j=0;j<(big?11:6);j++){const u=j/(big?10:5);line(L.glow,[[x-w+2*w*u,y-h],[x-w+2*w*u,y+h]],1,s.col,a*growth*0.55);}break;}
    case 16: { // ghosts inherit and diverge from the warrior's actual path; two converging armies if major
      const n=big?16:3;for(let j=0;j<n;j++){const army=big?j%2:0,del=j*0.13,u=prog(t,0.5+del,climax),px=lerp(x-outer*1.6,x+outer*(big?0.7:0.6),ease.out(u)),py=y+(army?-1:1)*(big?42:16)+Math.sin(j*1.1)*7;disc(L.glow,px,py-12,big?12:8,s.col,0.3*a);diamond(L.front,px,py-6,big?21:16,7,0,s.col,a*0.65);gring(L.add,px,py-12,5,s.hi,1,a,0,TAU,1);}if(big)ribbon(L.glow,[[x-outer,y-60],[x,y],[x+outer,y+60]],9,s.hi,a*phase);break;}
    case 17: { // arcing soul seed; major bloom ignition spreads through graph of connected flowers
      const n=big?9:1;for(let j=0;j<n;j++){const a0=j*2.39996,rr0=big?outer*Math.sqrt((j+1)/n):0,p=rad(x,y,rr0,a0),delay=big?j*0.34:0,u=prog(t,0.3+delay,convert+delay*0.6),r=big?18:32,rad0=r*prog(t,convert+delay*0.25,climax+0.55);const spr:P=[p[0]+Math.sin(A+j)*9,p[1]-42*(1-u)];star(L.add,...spr,7,5,0.4,A,s.hi,a);for(let k=0;k<6;k++)arcBlade(L.add,...p,Math.max(2,rad0),k*TAU/6,k*TAU/6+0.53,0.2,(k+j)%2?s.hi:s.col,a);if(big&&j>0){const from=rad(x,y,outer*Math.sqrt(j/n),(j-1)*2.39996);line(L.glow,[from,p],1,s.col,a*growth);}}break;}
    case 18: { // minor true outward wave reflects from target; major TWO sources and moving constructive crossing zone
      const n=big?2:1;for(let j=0;j<n;j++){const p=big?rad(x,y,78,j*Math.PI):O,offset=big?j*0.45:0;for(let k=0;k<(big?3:2);k++){const start=0.45+offset+k*1.6,u=prog(t,start,start+2.6),rr0=outer*1.25*u;gring(L.glow,...p,rr0,(j+k)%2?s.col:s.hi,big?3:2,a*(1-u*0.8));if(!big&&k===1){gring(L.add,...p,outer*(1-u),s.hi,2,a*(1-u));}}}if(big)for(let j=0;j<8;j++){const pos:[number,number]=[x+(j-3.5)*14,y+Math.sin(t*2+j)*6];sparkle(L.add,...pos,3,s.hi,0.9*a*growth);}break;}
    case 19: { // small folding black bite; large coupled portals share ONE continuous travelling material stream
      const portals=big?[[x-85,y],[x+85,y]] as P[]:[[x,y]] as P[];portals.forEach((p,j)=>{const r=(big?34:44)*(0.5+growth*0.6)*(1-phase*0.68);halo(L.glow,...p,r*1.8,s.col,a*0.55);disc(L.dark,...p,r,0x040311,a);gring(L.add,...p,r+3,s.hi,3,a);for(let k=0;k<6;k++){const ang=k*TAU/6+A*2*(j? -1:1);arcBlade(L.add,...p,r+12,ang,ang+0.72,0.22,s.col,a);}});if(big){const p0=portals[0],p1=portals[1];const transfer=curve(v=>[lerp(p0[0],p1[0],v),y+Math.sin(v*TAU*2-t*3)*25],34);ribbon(L.glow,transfer,8,s.col,a);const u=(t*0.44)%1,particle=transfer[Math.min(33,Math.round(u*33))];star(L.add,...particle,9,6,0.45,t,s.hi,a);}break;}
   }
   // Moment-specific live secondary emissions; density stays at 2.1, no global throttling.
   if(t>0.35 && t<out && (index%3===0||big) && rr(0,1)<0.72){const ang=rr(0,TAU),r=rr(10,outer);c.emit('add',{tex:index===11?'wing':index===7?'bone':index===9?'shard':'spark',x:x+Math.cos(ang)*r,y:y+Math.sin(ang)*r*YS,vx:rr(-70,70),vy:rr(-50,50),z:rr(0,18),life:rr(0.4,1.2),size:rr(2,big?8:5),size1:1,c0:s.col,c1:s.hi,drag:1.7});}
   if(big&&t>convert&&t<climax)c.darken(0.08+0.18*growth);
   void dt;
 });
}
export function independentSkills():Skill[]{
 const result:Skill[]=[];
 for(let i=0;i<SPECS.length;i++){const s=SPECS[i];for(const mode of ['minor','major'] as const){const big=mode==='major',dur=s.duration[big?1:0];result.push({
   id:(big?201:101)+i,name:big?s.large:s.small,relic:s.family,kind:mode,
   sub:big?s.grand:s.tiny,dur,
   phases:[[0,'Opening'],[big?1.45:1.15,'Construct'],[big?3.05:2.1,'Transform'],[big?5.6:2.7,'Impact'],[dur-1.1,'Residue / release']],
   setup:(c:Ctx)=>setup(c,i,mode),
 });}}
 return result;
}
export const INDEPENDENT_COUNTS={small:20,large:20} as const;
