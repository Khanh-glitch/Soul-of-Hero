/** Fusion routing: #301 stays byte-equivalent at the invocation/parameters level.
 * 302–312 use purpose-built coupled geometry / VFX in v2-fusion.ts.
 * Do not call these visually signed-off until renderer captures are inspected.
 */
import type { Skill } from '../engine/core';
import { v2FusionSkills } from './v2-fusion';
export type RemixKind = 'original' | 'minor' | 'major' | 'fusion';
export type RemixSkill = Skill & { kind?: RemixKind };
const PAIRS: [string, number, number, number, number, number][] = [
  ['Corona of Shackled Kings', 1, 6, 0.3, 6.9, 0xffaa55],
];
export function fusionSkills(originals: Skill[]): RemixSkill[] {
  const src = new Map(originals.map(s => [s.id, s]));
  const legacy: RemixSkill[] = PAIRS.map(([name, ai, bi, offset, nexus, color], i) => {
    const a = src.get(ai)!, b = src.get(bi)!;
    const dur = Math.max(a.dur, offset + b.dur) + 0.5;
    return {
      id: 301 + i, name, relic: a.relic, kind: 'fusion' as const,
      sub: `${a.name} × ${b.name} · two full-strength, overlapping procedural VFX systems`,
      dur, phases: [[0, `First system: ${a.name}`], [offset, `Second system: ${b.name}`], [nexus, 'Fusion nexus']] as [number,string][],
      setup: a.setup, fusion: { primary: a, secondary: b, offset, nexus, color },
    };
  });
  return [...legacy, ...v2FusionSkills()];
}

export const REMIX_COUNTS = { original: 20, minor: 20, major: 20, fusion: 12, total: 72 } as const;
