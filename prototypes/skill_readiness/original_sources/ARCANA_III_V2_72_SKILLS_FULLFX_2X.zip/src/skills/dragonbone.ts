// DRAGONBONE CHAIN — living restraint becoming monstrous destruction.
import { Ctx, Skill } from '../engine/core';
import {
  CX, H, P, TAU, W, YS, bez, bez2, clamp, dist, ease, lerp, mix, prog, rand, ramp, rr, sample, sstep,
} from '../engine/util';
import { chainLine, diamond, disc, glyph, gring, hiRamp, line, magicSeal, ngon, pixelBolt, poly, ribbon, ringPts, rotRect, shadeRamp, shard, star } from '../engine/draw';
import { crackScar, debris, halo, pillar, ringScar, slashLine, slashX, sparkle } from '../engine/fx';
import { stampOn } from '../engine/sprites';

const BONE = 0xe8dcc0, BONE_D = 0x8a7a64, CRIM = 0xff3a4a, DRED = 0x8a1228, TEAL = 0x2aa8ff, FIRE = 0xff7a1a, GOLD = 0xffcc44, WH = 0xffffff;
const partial = (pts: P[], f: number) => pts.slice(0, Math.max(2, Math.min(pts.length, Math.ceil(f * pts.length) + 1)));

// ---------- the wyrm: a continuous creature built from a head that leaves a delayed body behind it ----------
function drawWyrm(c: Ctx, pts: P[], vis: number, t: number, jaw: number, heat: number) {
  const L = c.L, n = pts.length;
  if (n < 3) return;
  const nr: P[] = pts.map((p, i) => {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)];
    const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1;
    return [-dy / l, dx / l];
  });
  const wid = (i: number) => (i < 5 ? 6 + i * 1.6 : 14 * Math.pow(1 - (i - 5) / (n - 4), 0.75) + 1.5);
  // flowing membranes between rib pairs
  const left: number[] = [], right: number[] = [];
  for (let i = 0; i < n; i++) {
    const w = wid(i) * (1 + 0.25 * Math.sin(t * 5 - i * 0.5));
    left.push(pts[i][0] + nr[i][0] * w, pts[i][1] + nr[i][1] * w);
    right.push(pts[i][0] - nr[i][0] * w, pts[i][1] - nr[i][1] * w);
  }
  const flat = [...left];
  for (let i = n - 1; i >= 0; i--) flat.push(right[i * 2], right[i * 2 + 1]);
  L.add.poly(flat).fill({ color: mix(DRED, TEAL, heat * 0.3), alpha: 0.28 * vis });
  // inner cursed glow along the spine
  ribbon(L.add, pts, (i) => wid(i) * 0.9, mix(0x2a0a40, FIRE, heat), 0.35 * vis);
  // ribs
  for (let i = 3; i < n - 2; i += 2) {
    const w = wid(i) * 1.25, p = pts[i], q = nr[i];
    const tx = pts[i - 1][0] - pts[i + 1][0], ty = pts[i - 1][1] - pts[i + 1][1], tl = Math.hypot(tx, ty) || 1;
    const bx = (tx / tl) * 3, by = (ty / tl) * 3;
    for (const s of [1, -1]) line(L.add, [p, [p[0] + q[0] * s * w * 0.6 + bx, p[1] + q[1] * s * w * 0.6 + by], [p[0] + q[0] * s * w + bx * 2, p[1] + q[1] * s * w + by * 2]], 1, BONE, 0.85 * vis);
  }
  // spine core + vertebrae
  ribbon(L.front, pts, (i) => Math.max(2, wid(i) * 0.28), BONE_D, vis);
  for (let i = 0; i < n; i += 1) {
    const a = Math.atan2(pts[Math.max(0, i - 1)][1] - pts[Math.min(n - 1, i + 1)][1], pts[Math.max(0, i - 1)][0] - pts[Math.min(n - 1, i + 1)][0]);
    rotRect(L.front, pts[i][0], pts[i][1], 3.2, Math.max(2, wid(i) * 0.5), a + Math.PI / 2, i % 2 ? BONE : mix(BONE, WH, 0.4), vis);
    if (i % 3 === 0) rotRect(L.add, pts[i][0], pts[i][1], 1.5, 1.5, 0, mix(CRIM, WH, heat), vis * 0.9);
  }
  // Pixel-art skeletal Dragon Head sprite oriented along the Wyrm's heading
  const h0 = pts[0], h1 = pts[2];
  const ha = Math.atan2(h0[1] - h1[1], h0[0] - h1[0]);
  const flipY = Math.cos(ha) < 0 ? -1 : 1;
  stampOn(L.front, 'dragon_head', h0[0], h0[1], { sx: 1.05, sy: 1.05 * flipY, rot: ha, tint: mix(BONE, WH, heat * 0.4), alpha: vis, add: false });
  stampOn(L.add, 'dragon_head', h0[0], h0[1], { sx: 1.05, sy: 1.05 * flipY, rot: ha, tint: mix(CRIM, FIRE, heat), alpha: 0.45 * vis, add: true });
  if (jaw > 0.25) {
    const mx = h0[0] + Math.cos(ha) * 14, my = h0[1] + Math.sin(ha) * 14;
    halo(L.add, mx, my, 12 + jaw * 18, FIRE, 0.7 * jaw, 1);
    sparkle(L.add, mx, my, 8 * jaw, WH, jaw, t * 4);
  }
}

// ============================================================ 05 WYRM UNCOILED
function s05(c: Ctx) {
  const C: P = [CX, 168];
  const A: P = [44, 214];
  const T0: P = [C[0] + 140 * Math.cos(-0.3), C[1] + 84 * Math.sin(-0.3)];
  c.layout([T0, [215, 150], [270, 195], [180, 205], [300, 140], [235, 120]]);
  const cx0 = Math.atan2(0, 1);
  void cx0;
  const spiral = (t: number): P => {
    const s = Math.max(0, t - 1.2);
    const th = -0.3 + 2.15 * s + 0.1 * s * s;
    const rx = lerp(140, 26, ease.io(prog(t, 3.3, 5.5)));
    const x = C[0] + Math.cos(th) * rx, y = C[1] + Math.sin(th) * rx * 0.6 + Math.sin(th * 2) * 8 * (rx / 140);
    return [x, y - 26 * Math.sin(s * 1.1) * Math.min(1, s) * (1 - prog(t, 4.5, 5.6))];
  };
  const head = (t: number): P => {
    if (t < 0) t = 0;
    if (t < 1.2) { const u = ease.out(t / 1.2); return bez(A, [150, 100], [260, 90], T0, u); }
    const p = spiral(t);
    const dv = ease.io3(prog(t, 5.9, 6.7));
    return [lerp(p[0], C[0], dv), lerp(p[1], C[1] + 8, dv)];
  };
  const DEL = 0.05;
  const NV = (t: number) => Math.floor(lerp(7, 66, ease.io(prog(t, 1.0, 3.6))));
  const body = (t: number): P[] => {
    const n = NV(t), out: P[] = [];
    for (let i = 0; i < n; i++) out.push(head(t - i * DEL));
    // transform into a rising helix of cursed fire on the final plunge
    const hq = ease.io(prog(t, 6.1, 6.9));
    if (hq > 0) for (let i = 0; i < n; i++) {
      const ph = i * 0.55 + t * 11, r = 34 * (1 - (i / n) * 0.55) * (0.5 + 0.5 * hq);
      const hx = C[0] + Math.cos(ph) * r, hy = C[1] + 10 - i * 3.1 * hq + Math.sin(ph) * r * 0.38;
      out[i] = [lerp(out[i][0], hx, hq), lerp(out[i][1], hy, hq)];
    }
    return out;
  };
  // caster: lash -> carried by the chain -> rides the neck -> emerges from the coil on a streak
  c.seg(0.3, 1.2, (u) => bez(A, [150, 100], [260, 90], T0, u), ease.out);
  c.seg(1.2, 5.45, (u) => { const tt = 1.2 + u * 4.25; const p = head(tt - 0.3); return [p[0], p[1] + 4, 12]; }, ease.lin);
  c.seg(5.5, 5.95, (u) => [lerp(C[0], 420, u), lerp(C[1], 205, u) - Math.sin(u * Math.PI) * 10, 0], ease.outExpo);
  c.caster.trail = CRIM;
  const streak: P[] = [];
  const hitT = new Map<number, number>();
  let coilStart: P[] = [];
  c.at(4.2, () => { coilStart = c.enemies.map((e) => [e.x, e.y]); });
  c.at(1.2, () => {
    c.enemies[0].flash = 1;
    c.shake(4);
    c.shock(T0[0], T0[1], { r: 50, life: 0.5, col: CRIM, w: 3, amp: 3 });
  });
  c.each((t, dt) => {
    const L = c.L;
    const vis = sstep(1.1, 3.2, t) * (t > 6.95 ? 0 : 1);
    const b = body(t);
    // the lash and the chain-before-wyrm
    if (t < 1.4) {
      const cp: P = [c.caster.x, c.caster.y - 6], hp = head(t);
      const wave = sample((u) => [lerp(cp[0], hp[0], u), lerp(cp[1], hp[1], u) + Math.sin(u * 9 - t * 40) * 6 * (1 - u) * Math.sin(u * Math.PI)] as P, 24);
      chainLine(L.front, wave, 4, BONE_D, 1.2, BONE);
    }
    if (t >= 1.0 && t < 3.6) chainLine(L.front, b, 4, BONE_D, 1.2, mix(BONE, WH, 0.3));
    if (t > 1.0 && t < 7.0) {
      const jaw = t < 6 ? 0.1 + 0.1 * Math.sin(t * 4) : ease.out(prog(t, 5.9, 6.5));
      const heat = sstep(5.6, 6.8, t);
      drawWyrm(c, b, vis, t, jaw, heat);
      // cursed fire licking the body
      if (t > 5.8) for (let k = 0; k < 4; k++) { const i = Math.floor(rand() * b.length); c.emit('add', { x: b[i][0] + rr(-4, 4), y: b[i][1], vx: rr(-20, 20), vy: rr(-80, -20), life: rr(0.3, 0.8), size: rr(1, 3), c0: pickF(), c1: DRED }); }
    }
    // spiral storm of dust, stone and embers
    if (t > 1.6 && t < 6.0) {
      const h = head(t - 0.1);
      for (let k = 0; k < 3; k++) {
        const a = rr(0, TAU), rad = rr(6, 40);
        const dx = C[0] - h[0], dy = C[1] - h[1], dl = Math.hypot(dx, dy) || 1;
        c.emit(k === 0 ? 'deb' : 'add', { x: h[0] + Math.cos(a) * rad, y: h[1] + Math.sin(a) * rad * YS, z: rr(0, 18), vx: -dy / dl * 110 + rr(-20, 20), vy: dx / dl * 80 + rr(-20, 20), vz: rr(10, 60), gz: 30, ax: dx * 0.5, ay: dy * 0.5, life: rr(0.8, 1.7), size: k === 0 ? rr(1, 3) : 1, c0: k === 0 ? [0x6a5f58, 0x8a7a6a, BONE_D][Math.floor(rand() * 3)] : FIRE, c1: k === 0 ? 0x2a2420 : DRED, drag: 0.6 });
      }
      L.mark.ellipse(h[0], h[1] + 18, 30, 8).fill({ color: 0, alpha: 0.25 * vis });
    }
    // enemies: struck as the body sweeps over them, then compressed into the coil
    const h = head(t);
    c.enemies.forEach((e, i) => {
      if (t >= 1.2 && t < 4.2 && i === 0) { const p = head(t - 0.12); e.pin(p[0], p[1] + 6, 8 + 6 * Math.sin(t * 6), t * 3); return; }
      if (t > 1.4 && t < 4.2 && i > 0 && !e.pinned) {
        for (let k = 0; k < Math.min(b.length, 30); k += 3) if (dist(e.x, e.y, b[k][0], b[k][1] + 6) < 14 && t - (hitT.get(i) ?? -9) > 1.2) {
          hitT.set(i, t);
          const nx = b[Math.min(b.length - 1, k + 2)][0] - b[k][0], ny = b[Math.min(b.length - 1, k + 2)][1] - b[k][1];
          c.strike(e, Math.atan2(nx, -ny) + (i % 2 ? 0 : Math.PI), 130, 70, CRIM, 9);
          break;
        }
      }
      if (t >= 4.2 && t < 5.95) {
        const k = ease.io(prog(t, 4.2, 5.2));
        const ox = (i % 3 - 1) * 7, oy = (Math.floor(i / 2) - 1) * 6;
        e.pin(lerp(coilStart[i]?.[0] ?? e.x, C[0] + ox, k), lerp(coilStart[i]?.[1] ?? e.y, C[1] + 6 + oy, k), 8 * k * Math.sin(k * 3 + i) + 4 * k, 0.2 * k * Math.sin(t * 10 + i));
        e.shakeAmt = 0.5 * k;
      }
    });
    void h;
    // streak
    if (t > 5.5 && t < 6.6) {
      streak.push([c.caster.x, c.caster.y - 6]);
      if (streak.length > 18) streak.shift();
    }
    if (streak.length > 2 && t < 6.7) { const sr = streak.slice().reverse(); ribbon(L.add, sr, (i, n) => 7 * (1 - i / n), CRIM, 0.8); ribbon(L.add, sr, (i, n) => 2.5 * (1 - i / n), WH, 1); }
    // coil pressure
    if (t > 4.6 && t < 5.9) { const k = prog(t, 4.6, 5.9); c.lens(C[0], C[1], 50, 0.8 * k); c.distort(C[0], C[1], 30 + 10 * Math.sin(t * 12), 2 * k); halo(L.glow, C[0], C[1], 30, CRIM, 0.35 * k, YS); }
    if (t > 6.2 && t < 7.0) { const k = prog(t, 6.2, 7.0); pillar(L.add, C[0], C[1] + 10, 150 * k, 6 + 10 * k, FIRE, 0.5); c.darken(0.5 * k); c.post.aberr = 2 * k; }
  });
  c.at(6.95, () => {
    c.flash(WH, 1); c.shake(14); c.slow(0.3, 0.3);
    c.blast(C[0], C[1], 300, 300, 200);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - C[1] - rr(-10, 10), e.x - C[0] + rr(-10, 10)), 260, 180, FIRE, 14));
    [50, 110, 190].forEach((r, i) => c.shock(C[0], C[1], { r, life: 0.9 + i * 0.25, col: [FIRE, CRIM, GOLD][i], w: 5, amp: 6 }));
    c.burst('add', C[0], C[1] - 20, 160, { spd: [50, 330], life: [0.6, 1.5], cols: [FIRE, CRIM, GOLD, WH], streak: 0.03, drag: 1.4 });
    for (let i = 0; i < 40; i++) c.emit('deb', { x: C[0] + rr(-20, 20), y: C[1] + rr(-10, 10), z: rr(10, 100), vx: rr(-230, 230), vy: rr(-120, 120), vz: rr(100, 320), gz: 380, life: rr(1.2, 2.4), size: rr(2, 4), c0: BONE, c1: BONE_D, bounce: 0.4 });
    ringScar(c, C[0], C[1], 60, 6, FIRE, 3); ringScar(c, C[0], C[1], 120, 6, CRIM, 2);
    crackScar(c, C[0], C[1], 10, 100, 6, FIRE);
    c.ent(1.2, (_a, u) => pillar(c.L.add, C[0], C[1], 260, lerp(30, 4, u), mix(FIRE, WH, 0.4), 1 - u));
  });
}
const pickF = () => [FIRE, CRIM, GOLD, 0xb04aff][Math.floor(rand() * 4)];

// ============================================================ 06 CATHEDRAL OF SHACKLES
function s06(c: Ctx) {
  const A: P[] = [[135, 112], [345, 112], [378, 226], [102, 226]];
  const CEN: P = [CX, 170];
  const BOSS: P = [CX, 78];
  const PH = 96;
  c.layout([[205, 160], [280, 152], [248, 196], [168, 200], [318, 198]]);
  const AT = [0.45, 0.9, 1.35, 1.8];
  let prev: P = [40, 210];
  const order = [0, 1, 2, 3];
  order.forEach((k, i) => { const f = prev; c.seg(AT[i] - 0.3, AT[i], (u) => [lerp(f[0], A[k][0], u), lerp(f[1], A[k][1] + 10, u)], ease.outExpo); prev = [A[k][0], A[k][1] + 10]; });
  c.seg(2.2, 2.55, (u) => [lerp(prev[0], A[0][0], u), lerp(prev[1], A[0][1] + 10, u)], ease.outExpo);
  c.seg(2.8, 3.15, (u) => [lerp(A[0][0], A[2][0], u), lerp(A[0][1] + 10, A[2][1] + 10, u)], ease.outExpo);
  c.seg(5.9, 6.6, (u) => [lerp(A[2][0], CX, u), lerp(A[2][1] + 10, CEN[1], u), Math.sin(u * Math.PI) * 60], ease.io);
  c.seg(6.6, 8.4, () => [CX, CEN[1], 0]);
  const tethers: [number, number, number][] = [[0, 1, 0.9], [1, 2, 1.35], [2, 3, 1.8], [3, 0, 2.3], [0, 2, 3.0], [1, 3, 3.3]];
  tethers.forEach(([a, b, tt]) => c.at(tt - 0.01, () => {
    c.shock(A[b][0], A[b][1], { r: 36, life: 0.45, col: GOLD, w: 3, amp: 2 });
    c.burst('add', A[b][0], A[b][1], 18, { spd: [20, 100], life: [0.3, 0.7], cols: [GOLD, BONE, WH], ys: YS, drag: 2 });
    c.shake(3);
  }));
  const sealT = [3.6, 3.8, 4.0, 4.2, 4.5, 4.7, 4.9, 5.1, 5.4];
  const igniteT = [7.0, 7.12, 7.24, 7.36, 7.5, 7.62, 7.74, 7.86, 8.0];
  let startPos: P[] = [];
  c.at(2.8, () => { startPos = c.enemies.map((e) => [e.x, e.y]); });
  const archCurve = (i: number, side: number, f1: number, f2: number): P[] => {
    const a = A[i], b = A[(i + 1) % 4];
    const mid: P = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const apex: P = [lerp(mid[0], CX, f1 * 0.7), lerp(mid[1] - 132, BOSS[1] + 30, f1)];
    const base = side ? b : a;
    const foot: P = [lerp(base[0], CX, f1 * 0.55), lerp(base[1] - 72, CEN[1] - 30, f1 * 0.7)];
    const ctrl: P = [lerp(foot[0], apex[0], 0.12), lerp(foot[1], apex[1], 0.78 - f2 * 0.5)];
    return sample((u) => bez2(foot, ctrl, apex, u), 16);
  };
  const ribCurve = (i: number, f1: number, f2: number): P[] => {
    const top: P = [lerp(A[i][0], CX, f1 * 0.55), lerp(A[i][1] - PH, BOSS[1] + 40, f1 * 0.7)];
    const mid: P = [(top[0] + CX) / 2, (top[1] + BOSS[1]) / 2];
    const ctrl: P = [mid[0], mid[1] + 34 * (1 - f2)];
    return sample((u) => bez2(top, ctrl, BOSS, u), 16);
  };
  const knot = (p: P, k: number): P => {
    if (k <= 0) return p;
    const dx = p[0] - CX, dy = p[1] - 130, r = Math.hypot(dx, dy), a = k * 4.5 * Math.exp(-r / 150);
    const s = 1 - 0.9 * k * k;
    const cs = Math.cos(a), sn = Math.sin(a);
    return [CX + (dx * cs - dy * sn) * s, 130 + (dx * sn + dy * cs) * s];
  };
  const sealPos = (f1: number, f2: number): P[] => {
    const out: P[] = [];
    for (let i = 0; i < 4; i++) out.push([lerp(A[i][0], CX, f1 * 0.55), lerp(A[i][1] - PH, BOSS[1] + 40, f1 * 0.7)]);
    for (let i = 0; i < 4; i++) out.push(archCurve(i, 0, f1, f2)[16]);
    out.push(BOSS);
    return out;
  };
  const shatter: { x: number; y: number }[] = [];
  void shatter;
  c.each((t, dt) => {
    const L = c.L;
    const f1 = ease.io(prog(t, 6.2, 6.95)), f2 = ease.io(prog(t, 6.9, 7.5)), kn = ease.io3(prog(t, 8.0, 8.75));
    if (t > 8.8) return drawAfter();
    const dim = 0.0;
    void dim;
    // darkness gathers inside the prison
    c.darken(0.45 * sstep(1.5, 4.5, t));
    const T = (p: P) => knot(p, kn);
    const TP = (ps: P[]) => ps.map(T);
    // ground tethers (persistent, increasingly complex)
    tethers.forEach(([a, b, tt]) => {
      if (t < tt - 0.3) return;
      const g = clamp((t - (tt - 0.3)) / 0.3);
      const pa = A[a], pb = A[b];
      const q: P = [lerp(pa[0], pb[0], g), lerp(pa[1], pb[1], g)];
      const pts = sample((u) => [lerp(pa[0], q[0], u), lerp(pa[1], q[1], u)] as P, 12);
      chainLine(L.front, TP(pts), 5, BONE_D, 1.1, mix(GOLD, BONE, 0.4));
      line(L.glow, TP(pts), 3, GOLD, 0.25);
    });
    // anchors
    A.forEach((p, i) => {
      if (t < AT[i]) return;
      const q = T([p[0], p[1]]);
      diamond(L.front, q[0], q[1] + 2, 4, 7, Math.PI / 2, BONE, 1);
      gring(L.glow, q[0], q[1], 14, GOLD, 1, 0.6, 0, TAU, YS, t);
      halo(L.glow, q[0], q[1], 22, GOLD, 0.3, YS);
    });
    // pillars -> arches -> ribs -> seals
    for (let i = 0; i < 4; i++) {
      const g = ease.out(prog(t, AT[i] + 0.1, AT[i] + 1.1));
      if (g <= 0) continue;
      const top: P = [lerp(A[i][0], CX, f1 * 0.55), lerp(A[i][1] - PH, BOSS[1] + 40, f1 * 0.7)];
      const bot: P = A[i];
      for (const off of [-1.5, 1.5]) {
        const pts = sample((u) => [lerp(bot[0], top[0], u) + Math.sin(u * 14 + t * 2 + i) * off, lerp(bot[1], top[1], u)] as P, 14);
        chainLine(L.front, TP(partial(pts, g)), 4, BONE_D, 1, BONE);
      }
    }
    for (let i = 0; i < 4; i++) for (let side = 0; side < 2; side++) {
      const g = ease.io(prog(t, AT[(i + 1) % 4] + 0.7 + side * 0.25, AT[(i + 1) % 4] + 1.9 + side * 0.25));
      if (g <= 0) continue;
      const cv = archCurve(i, side, f1, f2);
      const pts = partial(cv, g);
      chainLine(L.front, TP(pts), 4, mix(BONE_D, GOLD, 0.2), 1.2, BONE);
      line(L.glow, TP(pts), 4, DRED, 0.28);
    }
    for (let i = 0; i < 4; i++) {
      const g = ease.io(prog(t, 3.0 + i * 0.25, 4.3 + i * 0.25));
      if (g <= 0) continue;
      const cv = ribCurve(i, f1, f2);
      chainLine(L.front, TP(partial(cv, g)), 4, BONE_D, 1.1, mix(BONE, GOLD, 0.4));
    }
    // vertically hanging chains with hooks
    if (t > 3.4) {
      const sp = sealPos(f1, f2);
      for (let i = 4; i < 9; i++) {
        const g = ease.out(prog(t, 3.4 + (i - 4) * 0.2, 4.4 + (i - 4) * 0.2));
        const s = sp[i], len = (i === 8 ? 78 : 50) * g * (1 - f2 * 0.4);
        const pts = sample((u) => [s[0] + Math.sin(u * 5 + t * 2 + i) * 1.5, s[1] + u * len] as P, 8);
        chainLine(L.front, TP(pts), 4, BONE_D, 1, BONE);
        const e = T([s[0], s[1] + len]);
        if (g > 0.8) line(L.front, [e, [e[0] + 3, e[1] + 4], [e[0] - 1, e[1] + 6]], 1.5, BONE);
      }
    }
    // locking seals
    const sp = sealPos(f1, f2);
    sp.forEach((s, i) => {
      if (t < sealT[i]) return;
      const age = t - sealT[i], ig = t > igniteT[i] ? clamp((t - igniteT[i]) * 3) : 0, q = T(s);
      const a = 1 - (kn > 0 ? kn * 0.5 : 0);
      ngon(L.add, q[0], q[1], 6 + 4 * Math.exp(-age * 5) + ig * 3, 6, t * 0.8, mix(GOLD, WH, ig), 0.9 * a);
      ngon(L.front, q[0], q[1], 4, 6, t * 0.8, 0x1a1218);
      glyph(L.add, q[0], q[1], 2, i * 5, mix(GOLD, WH, ig), 1, t);
      if (ig > 0 || age < 0.3) halo(L.add, q[0], q[1], 16 + 14 * (1 - Math.abs(ig * 2 - 1)), mix(GOLD, WH, 0.5), 0.7, 1);
    });
    // enemies are drawn to restraint points, each bound by a chain
    c.enemies.forEach((e, i) => {
      if (t < 2.8 || t > 8.0) return;
      const k = ease.io(prog(t, 2.8, 5.8));
      const an = A[i % 4], tg: P = i === 4 ? [CX, 168] : [lerp(an[0], CX, 0.4), lerp(an[1], 170, 0.4)];
      const sh = startPos[i] ?? [e.x, e.y];
      const rise = i === 4 ? 24 * k : 0;
      const kk = ease.io(prog(t, 7.0, 8.0)); // restraint pulled inward during contraction
      const px = lerp(lerp(sh[0], tg[0], k), CX, kk * 0.8), py = lerp(lerp(sh[1], tg[1], k), 166, kk * 0.8);
      e.pin(px, py, rise + kk * 10, 0.12 * Math.sin(t * 8 + i) * k);
      e.shakeAmt = 0.4 * k;
      const src: P = i === 4 ? BOSS : an;
      const pts = sample((u) => [lerp(src[0], px, u), lerp(src[1], py - 6 - rise, u) + Math.sin(u * 3) * 0] as P, 10);
      chainLine(L.front, TP(pts), 4, BONE_D, 1, mix(BONE, CRIM, 0.3 * k));
    });
    // main chain from the leaping warrior
    if (t > 5.9 && t < 8.4) {
      const cp: P = [c.caster.x, c.caster.y - 8 - c.caster.z];
      const tau = ease.io(prog(t, 6.2, 6.8));
      const pts = sample((u) => [lerp(cp[0], BOSS[0], u), lerp(cp[1], BOSS[1], u) + Math.sin(u * Math.PI) * 30 * (1 - tau)] as P, 18);
      chainLine(L.front, pts, 4, GOLD, 1.3, WH);
      line(L.add, pts, 2, GOLD, 0.4);
    }
    // contraction feedback
    if (t > 6.2 && t < 8.1) { c.shake(1.5 * f1); c.lens(CX, 130, 140, -0.3 * f2); }
    if (t > 7.0 && t < 8.1) igniteT.forEach((it, i) => { if (Math.abs(t - it) < dt * 0.6) { const s = T(sp[i]); c.shock(s[0], s[1], { r: 40, life: 0.5, col: GOLD, w: 3, amp: 3 }); c.burst('add', s[0], s[1], 14, { spd: [30, 130], life: [0.3, 0.7], cols: [GOLD, WH], drag: 2 }); } });
    // knot
    if (kn > 0) { halo(L.add, CX, 130, 20 + 40 * kn, GOLD, 0.6 * kn, 1); sparkle(L.add, CX, 130, 14 * kn, WH, 1, t * 3); c.post.aberr = 2 * kn; }
    // ground sigil appears under the prison
    if (t > 4.0 && t < 8.8) { gring(L.glow, CX, CEN[1], 100 * (1 - kn), GOLD, 1, 0.35, 0, TAU, YS, t * 0.2); glyph(L.glow, CX, CEN[1], 14 * (1 - kn), 77, GOLD, 0.35, t * 0.3, 1); }

    function drawAfter() {
      c.post.vig = 0.5;
    }
  });
  c.at(8.8, () => {
    c.flash(WH, 1); c.shake(15); c.slow(0.3, 0.3);
    c.blast(CX, 168, 320, 300, 160);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - 168, e.x - CX), 280, 150, GOLD, 12));
    [60, 130, 220].forEach((r, i) => c.shock(CX, 168, { r, life: 1.0 + i * 0.3, col: i === 1 ? GOLD : 0x2a1830, col2: i === 1 ? WH : GOLD, w: 6, amp: 6 }));
    for (let i = 0; i < 90; i++) { const a = rr(0, TAU), s = rr(70, 360); c.emit('deb', { x: CX, y: 130, z: rr(0, 40), vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.6, vz: rr(80, 280), gz: 340, life: rr(1, 2.3), size: rr(1, 3), c0: [GOLD, BONE, 0x2a1830][i % 3], c1: 0x201018, bounce: 0.45, drag: 0.5 }); }
    c.burst('add', CX, 130, 140, { spd: [60, 340], life: [0.6, 1.4], cols: [GOLD, WH, 0xaa6a20], streak: 0.03, drag: 1.4 });
    ringScar(c, CX, 168, 44, 5.5, GOLD, 2);
    ringScar(c, CX, 168, 96, 5.5, GOLD, 2);
    crackScar(c, CX, 168, 9, 95, 5.5, GOLD);
  });
}

// ============================================================ 07 HELL-TIDE HARPOON
function s07(c: Ctx) {
  const V: P = [250, 152];
  const T0: P = [335, 108];
  c.layout([T0, [170, 120], [190, 190], [320, 195], [290, 125], [225, 160]]);
  const HOME = c.enemies.map((e) => [e.hx, e.hy] as P);
  const a0 = Math.PI + 0.25;
  const spiralPos = (u: number): P => {
    const e = ease.io(u), a = a0 + 2.1 * TAU * e, r = lerp(150, 34, ease.in(e) * 0.5 + e * 0.5);
    return [V[0] + Math.cos(a) * r, V[1] + Math.sin(a) * r * YS];
  };
  c.seg(0, 0.9, (u) => [lerp(44, spiralPos(0)[0], u), lerp(214, spiralPos(0)[1], u)], ease.outExpo);
  c.seg(0.9, 5.0, (u) => spiralPos(u), ease.lin);
  const FAR: P = [40, 214];
  c.seg(5.0, 5.35, (u) => { const s = spiralPos(1); return [lerp(s[0], FAR[0], u), lerp(s[1], FAR[1], u)]; }, ease.outExpo);
  c.caster.trail = CRIM;
  let sq = 0, blastP = -1;
  const dirD: P = (() => { const dx = FAR[0] - V[0], dy = FAR[1] - V[1], l = Math.hypot(dx, dy); return [dx / l, dy / l]; })();
  const tf = (p: P): P => {
    if (sq <= 0) return p;
    const dx = p[0] - V[0], dy = p[1] - V[1];
    const a = dx * dirD[0] + dy * dirD[1], b = -dx * dirD[1] + dy * dirD[0];
    const a2 = a * (1 - 0.3 * sq) , b2 = b * Math.pow(1 - sq, 1.5);
    return [V[0] + a2 * dirD[0] - b2 * dirD[1], V[1] + a2 * dirD[1] + b2 * dirD[0]];
  };
  const hooks = Array.from({ length: 7 }, (_, j) => ({ a: (j / 7) * TAU + 0.3, t0: 1.8 + j * 0.28 }));
  const enAng = c.enemies.map((_, i) => Math.atan2(HOME[i][1] - V[1], (HOME[i][0] - V[0]) / 1) );
  const enR = c.enemies.map((_, i) => Math.hypot(HOME[i][0] - V[0], (HOME[i][1] - V[1]) / YS));
  const blastDir: P = [-dirD[0], -dirD[1]];
  void blastP;
  c.at(0.15, () => {
    c.ent(0.7, (_a, u) => {
      const s: P = [c.caster.x, c.caster.y - 8], q: P = [lerp(s[0], T0[0], ease.out(u)), lerp(s[1], T0[1] - 6, ease.out(u)) - Math.sin(u * Math.PI) * 30];
      const pts = sample((k) => [lerp(s[0], q[0], k), lerp(s[1], q[1], k) + Math.sin(k * 8) * 4 * (1 - k)] as P, 18);
      chainLine(c.L.front, pts, 4, BONE_D, 1.2, BONE);
      poly(c.L.front, [[q[0] + 6, q[1]], [q[0] - 3, q[1] - 3], [q[0] - 3, q[1] + 3]], WH);
    });
  });
  c.at(0.85, () => { c.strike(c.enemies[0], 0.2, 20, 40, CRIM, 4); c.shock(T0[0], T0[1], { r: 44, life: 0.5, col: CRIM, w: 3, amp: 3 }); });
  c.each((t, dt) => {
    const L = c.L;
    sq = ease.in(prog(t, 5.3, 6.1));
    const grow = ease.out3(prog(t, 0.9, 3.0)), Rw = 150 * grow * (1 - sstep(6.0, 6.5, t));
    const vis = 1 - sstep(6.0, 6.5, t);
    c.darken(0.35 * grow * vis);
    const spin = t * 1.6 + t * t * 0.08;
    if (Rw > 3) {
      // Abyssal whirlpool basin with pixel-art vortex swirl textures & bone-chain currents (no peppermint pinwheel!)
      for (let k = 0; k < 4; k++) {
        const r = Rw * (1 - k * 0.2);
        L.mark.poly(ringPts(V[0], V[1], r, 0, TAU, 36).map(tf).flat()).fill({ color: mix(0x1e071e, 0x06030d, k / 3), alpha: 0.6 * vis });
      }
      const vScale = (Rw / 58) * (1 - sq * 0.75);
      if (vScale > 0.08) {
        stampOn(L.glow, 'vortex_swirl', V[0], V[1], { sx: vScale * 1.05, sy: vScale * 1.05, rot: -spin * 0.85, tint: CRIM, alpha: 0.85 * vis, ys: YS * (1 - sq * 0.5), add: true });
        stampOn(L.add, 'vortex_swirl', V[0], V[1], { sx: vScale * 0.72, sy: vScale * 0.72, rot: -spin * 1.35 + 1.1, tint: FIRE, alpha: 0.9 * vis, ys: YS * (1 - sq * 0.5), add: true });
        magicSeal(L.glow, V[0], V[1], Rw * 0.92 * (1 - sq * 0.6), CRIM, -spin * 0.35, 0.6 * vis, YS, 8);
      }
      for (let arm = 0; arm < 2; arm++) {
        const pts = sample((s) => {
          const r = 12 + s * (Rw - 12), a = arm * Math.PI + Math.log(r / 12 + 1) * 2.1 - spin;
          return tf([V[0] + Math.cos(a) * r, V[1] + Math.sin(a) * r * YS]);
        }, 22);
        chainLine(L.front, pts, 6, BONE_D, 1.1, mix(BONE, CRIM, 0.35));
      }
      // broken sigil rings
      [0.45, 0.8].forEach((f, k) => {
        const r = Rw * f, dirn = k ? 1 : -1;
        for (let s = 0; s < 8; s++) {
          const a = s * (TAU / 8) + spin * 0.7 * dirn;
          if (s % 3 !== 2) L.add.poly(ringPts(V[0], V[1], r, a, a + 0.45, 8).map(tf).flat()).stroke({ width: 2, color: k ? CRIM : FIRE, alpha: 0.85 * vis });
          const gp = tf([V[0] + Math.cos(a + 0.6) * r, V[1] + Math.sin(a + 0.6) * r * YS]);
          glyph(L.add, gp[0], gp[1], 2.5, s * 3 + k * 11, FIRE, 0.9 * vis, a);
        }
      });
      // chains erupting from the walls and curling inward
      for (const h of hooks) {
        const g = ease.out(prog(t, h.t0, h.t0 + 1.0));
        if (g <= 0) continue;
        const a = h.a - spin * 0.3;
        const st: P = [V[0] + Math.cos(a) * Rw * 0.95, V[1] + Math.sin(a) * Rw * 0.95 * YS];
        const en: P = [V[0] + Math.cos(a + 1.2) * Rw * 0.3, V[1] + Math.sin(a + 1.2) * Rw * 0.3 * YS];
        const pts = sample((u) => { const p = bez2(st, [V[0] + Math.cos(a + 0.5) * Rw * 0.6, V[1] - 60], en, u); return tf([p[0], p[1] - Math.sin(u * Math.PI) * 24]); }, 14);
        chainLine(L.front, partial(pts, g), 4, BONE_D, 1.1, mix(BONE, CRIM, 0.3));
        const hd = partial(pts, g); const q = hd[hd.length - 1];
        poly(L.front, [[q[0] + 3, q[1]], [q[0] - 2, q[1] - 2], [q[0] - 2, q[1] + 2]], CRIM);
      }
      // debris ripped into orbit
      if (t < 5.4) for (let k = 0; k < 3; k++) { const a = rr(0, TAU), r = rr(20, Rw), vt = 80 + 120 * (1 - r / Rw); c.emit(k ? 'add' : 'deb', { x: V[0] + Math.cos(a) * r, y: V[1] + Math.sin(a) * r * YS, z: rr(0, 12), vx: -Math.sin(a) * vt, vy: Math.cos(a) * vt * YS, ax: (V[0] - (V[0] + Math.cos(a) * r)) * 0.9, ay: (V[1] - (V[1] + Math.sin(a) * r * YS)) * 0.9, vz: rr(0, 40), gz: 20, life: rr(0.6, 1.3), size: k ? 1 : rr(1, 3), c0: k ? CRIM : 0x4a3a40, c1: 0x200810 }); }
      c.lens(V[0], V[1], Rw * 1.1, 0.9 * grow * vis);
    }
    // the long chain traced as a spiral, plus the target's tether
    if (t > 0.9 && t < 5.4) {
      const u = prog(t, 0.9, 5.0), cs = spiralPos(u), r = Math.hypot(cs[0] - V[0], (cs[1] - V[1]) / YS), a = Math.atan2((cs[1] - V[1]) / YS, cs[0] - V[0]);
      const tp = [c.enemies[0].x, c.enemies[0].y - 6] as P;
      const pts: P[] = [tp, ...sample((s) => { const ang = a - TAU * 1.1 * (1 - s) * (0.4 + r / 150), rr2 = r * s; return [V[0] + Math.cos(ang) * rr2, V[1] + Math.sin(ang) * rr2 * YS - 4] as P; }, 40)];
      chainLine(L.front, pts, 4, BONE_D, 1.3, BONE);
      line(L.add, pts, 2, CRIM, 0.3);
    }
    // enemies dragged into faster and faster orbits
    c.enemies.forEach((e, i) => {
      if (t < 1.5 || t > 5.4) return;
      const k = ease.io(prog(t, 1.6, 5.2)), s = t - 1.5;
      if (i === 0) { const kk = ease.in(prog(t, 1.0, 5.2)); e.pin(lerp(T0[0], V[0] + 6, kk) + Math.cos(s * 3) * 10 * (1 - kk), lerp(T0[1], V[1], kk) + Math.sin(s * 3) * 6 * (1 - kk), 10 * (1 - kk), s * 2); return; }
      const ang = enAng[i] + (0.9 * s + 0.35 * s * s) * (i % 2 ? 1 : 1), r = lerp(enR[i], 16 + i * 4, k);
      e.pin(V[0] + Math.cos(ang) * r, V[1] + Math.sin(ang) * r * YS, 4 + 6 * Math.sin(s * 4 + i), ang);
    });
    // tension + needle's-eye collapse
    if (t > 5.0 && t < 6.5) {
      const cp: P = [c.caster.x, c.caster.y - 6];
      const tight = ease.out(prog(t, 5.0, 5.4));
      const pts = sample((u) => [lerp(V[0], cp[0], u), lerp(V[1], cp[1], u) + Math.sin(u * 40 - t * 90) * 3 * (1 - tight * 0.7)] as P, 26);
      chainLine(L.front, pts, 4, GOLD, 1.3, WH);
      line(L.add, pts, 3, CRIM, 0.5);
      line(L.add, pts, 1, WH, 0.9);
      if (t > 5.4) halo(L.add, V[0], V[1], 20 * sq, WH, 0.8, 0.6);
      c.post.aberr = 2.5 * sq;
    }
    // The Hell-Tide directional blast: high-velocity piercing crimson railgun + cascading crescent shockwaves + dragon head vanguard!
    if (t >= 6.05 && t < 8.4) {
      const bt = t - 6.05;
      const head = 420 * ease.outExpo(clamp(bt / 0.85));
      const f = 1 - sstep(1.1, 2.25, bt);
      const bAng = Math.atan2(blastDir[1], blastDir[0]);
      const pEnd: P = [V[0] + blastDir[0] * head, V[1] + blastDir[1] * head];
      // Piercing diamond-tapered crimson-gold energy lance (straight, devastating, zero toothpaste wiggle!)
      const midP: P = [(V[0] + pEnd[0]) * 0.5, (V[1] + pEnd[1]) * 0.5];
      diamond(L.add, midP[0], midP[1], head * 0.55, 22 * f, bAng, CRIM, 0.7 * f);
      diamond(L.add, midP[0], midP[1], head * 0.52, 11 * f, bAng, FIRE, 0.92 * f);
      diamond(L.add, midP[0], midP[1], head * 0.48, 4 * f, bAng, WH, f);
      chainLine(L.front, sample((u) => [lerp(V[0], pEnd[0], u), lerp(V[1], pEnd[1], u)] as P, 24), 6, BONE, 1.3, GOLD);
      // Cascading pixel crescent shockwaves & dragon-skull vanguard along the blast axis
      for (let w = 1; w <= 5; w++) {
        const s = (w / 5) * head;
        const wx = V[0] + blastDir[0] * s, wy = V[1] + blastDir[1] * s;
        const sc = (0.45 + 0.12 * w) * f;
        stampOn(L.add, 'crescent_wave', wx, wy, { sx: sc, sy: sc, rot: bAng, tint: w % 2 ? CRIM : FIRE, alpha: 0.9 * f, add: true });
      }
      stampOn(L.front, 'dragon_head', pEnd[0], pEnd[1], { sx: 1.35, sy: 1.35 * (blastDir[0] < 0 ? -1 : 1), rot: bAng, tint: BONE, alpha: f, add: false });
      if (bt < 1.1) pixelBolt(L.add, V, pEnd, GOLD, 14 * f, 2, 0.9 * f, Math.floor(bt * 30), true);
      if (f > 0.1) for (let k = 0; k < 5; k++) {
        const u = rand();
        const qx = lerp(V[0], pEnd[0], u), qy = lerp(V[1], pEnd[1], u);
        c.emit(k < 2 ? 'deb' : 'add', { x: qx, y: qy, z: rr(0, 20), vx: blastDir[0] * rr(40, 200) + rr(-40, 40), vy: blastDir[1] * rr(40, 200) * YS + rr(-40, 40), vz: rr(0, 120), gz: 280, life: rr(0.5, 1.4), size: rr(1, 3), c0: k < 2 ? BONE_D : CRIM, c1: 0x200810, bounce: 0.3 });
      }
      c.enemies.forEach((e, i) => {
        if (e.dead) return;
        const dx = e.x - V[0], dy = e.y - V[1], al = dx * blastDir[0] + dy * blastDir[1] * 0 + dy * blastDir[1] * 1;
        void al;
        const proj = (dx * blastDir[0] + dy * blastDir[1]) ;
        const perp = Math.abs(-dx * blastDir[1] + dy * blastDir[0]);
        if (!(e as any)._h && proj > 0 && proj < head && perp < 34) {
          (e as any)._h = true;
          c.strike(e, Math.atan2(blastDir[1], blastDir[0]), i === 0 ? 420 : 300, i === 0 ? 120 : 160, CRIM, 16);
        }
      });
      c.distort(V[0] + blastDir[0] * head * 0.5, V[1] + blastDir[1] * head * 0.4, head * 0.5, 4 * f);
    }
    void dt;
  });
  c.at(5.4, () => { c.enemies.forEach((e) => ((e as any)._h = false)); });
  c.at(6.05, () => {
    c.flash(CRIM, 0.9); c.shake(14); c.slow(0.35, 0.25);
    c.shock(V[0], V[1], { r: 120, life: 0.9, col: CRIM, w: 5, amp: 5 });
    c.burst('add', V[0], V[1], 140, { spd: [60, 340], life: [0.6, 1.4], cols: [CRIM, WH, FIRE], streak: 0.03, drag: 1.4 });
    // Shattered abyssal crater + broken runic rings (no black-brown spiral hoses)
    crackScar(c, V[0], V[1], 8, 85, 5.5, CRIM);
    ringScar(c, V[0], V[1], 52, 5.5, FIRE, 2);
    ringScar(c, V[0], V[1], 112, 5.5, CRIM, 2);
    for (let i = 0; i < 36; i++) {
      const a = rr(0, TAU), r = rr(10, 120);
      c.emit('deb', { x: V[0] + Math.cos(a) * r, y: V[1] + Math.sin(a) * r * YS, z: rr(10, 60), vx: rr(-25, 25), vy: rr(-10, 10), vz: rr(0, 40), gz: 22, life: rr(2.0, 3.4), size: rr(1, 2), c0: CRIM, c1: 0x2a0820, bounce: 0.1, drag: 0.5 });
    }
  });
}

// ============================================================ 08 LEVIATHAN'S LAST HEARTBEAT
function s08(c: Ctx) {
  const Hc: P = [CX, 160];
  c.layout([[170, 130], [310, 128], [330, 190], [160, 196], [245, 220]]);
  c.seg(0, 6.0, (u) => [lerp(36, 196, u), lerp(205, 196, u) - Math.sin(u * 10) * 1.2], ease.io);
  c.seg(6.8, 7.4, (u) => [196, 196, 16 * ease.out(u)], ease.out);
  c.seg(7.8, 8.4, () => [196, 196, 0]);
  const S = (u: number): P => { const phi = lerp(3.5, 3.5 + 5.0, u); return [Hc[0] + Math.cos(phi) * 128 * (1 - 0.15 * u), Hc[1] - 6 + Math.sin(phi) * 76 * (1 - 0.15 * u)]; };
  const spine = sample(S, 70);
  const sections: [number, number, number][] = [[0, 0.3, 1.8], [0.3, 0.66, 3.0], [0.66, 1, 4.2]];
  const ribs = Array.from({ length: 7 }, (_, i) => ({ u: 0.38 + i * 0.075, t0: 2.5 + i * 0.35 }));
  const organs = [{ p: [Hc[0], Hc[1] - 4] as P, r: 11, t0: 4.5 }, { p: [Hc[0] - 24, Hc[1] - 12] as P, r: 7, t0: 4.9 }, { p: [Hc[0] + 24, Hc[1] - 10] as P, r: 7, t0: 5.2 }, { p: [Hc[0] + 4, Hc[1] + 18] as P, r: 6, t0: 5.4 }];
  const anchors: P[] = [S(0.02), ...ribs.filter((_, i) => i % 3 === 0).map((r) => S(r.u)), S(0.5), S(0.85)];
  const anchorT = [2.2, 2.8, 3.5, 4.3, 3.3, 4.6];
  const pulseT = [3.4, 4.5, 5.6, 6.5];
  const heartBeats = [3.4, 3.65, 4.5, 4.75, 5.6, 5.85, 6.5, 6.75];
  let coreStart = 0;
  void coreStart;
  const contract = (t: number) => 1 - ease.in3(prog(t, 7.3, 7.9));
  const P_ = (p: P, k: number): P => [Hc[0] + (p[0] - Hc[0]) * k, Hc[1] + (p[1] - Hc[1]) * k];
  const leftRibs = [2, 3, 4];
  c.each((t, dt) => {
    const L = c.L;
    const k = contract(t);
    const full = sstep(6.7, 7.0, t) * (1 - sstep(7.3, 7.35, t));
    const gone = t > 7.9;
    // vast shadow moving under the arena
    const sh = sstep(0.4, 2.2, t) * (gone ? 0 : 1);
    if (sh > 0) {
      const pts = spine.map((p, i) => P_([p[0] + Math.sin(t * 0.8 + i * 0.2) * 5, p[1] + 14 + Math.cos(t * 0.6 + i * 0.15) * 3], k));
      ribbon(L.mark, pts, (i) => 30 * Math.sin((i / 70) * 3.1) + 6, 0x000000, 0.4 * sh);
      L.mark.ellipse(Hc[0], Hc[1] + 14, 70 * k, 38 * k).fill({ color: 0, alpha: 0.3 * sh });
    }
    // chain descends into the ground
    const cp: P = [c.caster.x + 4, c.caster.y - 9 - c.caster.z];
    if (t < 6.8) {
      const dg = ease.out(prog(t, 0.2, 1.4));
      const g1: P = [c.caster.x + 22, c.caster.y + 2];
      const pts = sample((u) => [lerp(cp[0], g1[0], u), lerp(cp[1], g1[1], u) + Math.sin(u * Math.PI) * -6 * (1 - dg)] as P, 12);
      chainLine(L.front, partial(pts, dg), 4, BONE_D, 1.1, BONE);
      if (dg > 0.9) gring(L.glow, g1[0], g1[1], 6 + 2 * Math.sin(t * 5), TEAL, 1, 0.7, 0, TAU, YS);
    } else if (t < 7.9) {
      const pts = sample((u) => [lerp(cp[0], cp[0] + 6, u), lerp(cp[1], cp[1] - 30 * (t > 7.2 ? 1 : 0.4), u)] as P, 6);
      chainLine(L.front, pts, 4, GOLD, 1.2, WH);
    }
    // remains of the creature (spine sections, ribs, skull, organs)
    const bright = full;
    for (const [a, b, t0] of sections) {
      const g = ease.out3(prog(t, t0, t0 + 1.4));
      if (g <= 0 || gone) continue;
      const n = 22;
      const pts: P[] = [];
      for (let i = 0; i <= n; i++) pts.push(P_(S(lerp(a, b, i / n)), k));
      const sub = partial(pts, g);
      // bumpy coil with emergence from the ground
      const lift = (i: number) => -(1 - g) * 6 - Math.sin(i * 0.9 + t * 1.2) * 1.5;
      const pp = sub.map((p, i) => [p[0], p[1] + lift(i)] as P);
      ribbon(L.glow, pp, 10, mix(0x0a1a2a, TEAL, bright * 0.5), 0.55);
      ribbon(L.front, pp, 6, BONE_D, 1);
      for (let i = 0; i < pp.length; i++) {
        const q = pp[i], nx = pp[Math.min(pp.length - 1, i + 1)], pv = pp[Math.max(0, i - 1)];
        const an = Math.atan2(nx[1] - pv[1], nx[0] - pv[0]);
        rotRect(L.front, q[0], q[1], 4, 9, an + Math.PI / 2, i % 2 ? BONE : mix(BONE, WH, 0.3 + bright * 0.5), 1);
        line(L.front, [q, [q[0] + Math.cos(an - 1.57) * 8, q[1] + Math.sin(an - 1.57) * 8 - 3]], 1, BONE, 1);
        if (i % 3 === 0) disc(L.add, q[0], q[1], 1.4, mix(TEAL, WH, bright), 0.8);
      }
    }
    for (const r of ribs) {
      const g = ease.out3(prog(t, r.t0, r.t0 + 1.2));
      if (g <= 0 || gone) continue;
      const base = P_(S(r.u), k), tip = P_([Hc[0] + (S(r.u)[0] - Hc[0]) * 0.18, Hc[1] + (S(r.u)[1] - Hc[1]) * 0.18 - 10], k);
      const ctrl: P = [base[0] + (tip[0] - base[0]) * 0.1, base[1] - 74 * k];
      const pts = partial(sample((u) => bez2(base, ctrl, tip, u), 18), g);
      ribbon(L.glow, pts, (i, n) => 9 * (1 - i / n * 0.7), mix(0x10202a, TEAL, bright * 0.6), 0.5);
      ribbon(L.front, pts, (i, n) => 6 * (1 - i / n * 0.8) + 1, BONE, 1);
      ribbon(L.front, pts, (i, n) => 2 * (1 - i / n * 0.8), mix(BONE, WH, 0.3 + bright * 0.6), 1);
    }
    const sk = ease.out3(prog(t, 2.0, 3.4));
    if (sk > 0 && !gone) {
      const p = P_(S(0.0), k), ar = Math.atan2(S(0.02)[1] - S(0)[1], S(0.02)[0] - S(0)[0]) + Math.PI;
      const sc = 1.45 * k * sk;
      stampOn(L.front, 'dragon_head', p[0], p[1] - (1 - sk) * 10, { sx: sc, sy: sc * (Math.cos(ar) < 0 ? -1 : 1), rot: ar, tint: BONE, alpha: 1, add: false });
      stampOn(L.add, 'dragon_head', p[0], p[1] - (1 - sk) * 10, { sx: sc, sy: sc * (Math.cos(ar) < 0 ? -1 : 1), rot: ar, tint: TEAL, alpha: 0.45 + bright * 0.4, add: true });
    }
    // organs: the (invisible) heart finally revealed
    for (let i = 0; i < organs.length; i++) {
      const o = organs[i], g = ease.out(prog(t, o.t0, o.t0 + 0.8));
      if (g <= 0 || gone) continue;
      let beat = 0;
      for (const b of heartBeats) if (t > b) beat = Math.max(beat, Math.exp(-(t - b) * 7));
      const q = P_(o.p, k), r = o.r * g * (1 + 0.4 * beat * (i === 0 ? 1 : 0.5));
      halo(L.add, q[0], q[1], r * 2.4, i === 0 ? CRIM : TEAL, 0.6, 1);
      disc(L.add, q[0], q[1], r, i === 0 ? CRIM : mix(TEAL, WH, 0.3), 1);
      disc(L.add, q[0], q[1], r * 0.45, WH, 0.9);
    }
    // nervous system: chains from every part to the heart, carrying pulses
    if (t > 2.2 && !gone) anchors.forEach((a, i) => {
      const g = ease.out(prog(t, anchorT[i], anchorT[i] + 0.9));
      if (g <= 0) return;
      const A2 = P_(a, k), hh = P_(Hc, k);
      const ctrl: P = [(A2[0] + hh[0]) / 2, (A2[1] + hh[1]) / 2 + 24 * k];
      const pts = sample((u) => bez2(hh, ctrl, A2, u), 20);
      chainLine(L.front, partial(pts, g), 4, 0x4a5a6a, 1, 0x9ab8d0);
      for (const pt of pulseT) {
        const s = prog(t, pt, pt + 0.55 + i * 0.03);
        if (s > 0 && s < 1) { const q = pts[Math.floor((1 - s) * (pts.length - 1))]; halo(L.add, q[0], q[1], 9, CRIM, 0.7, 1); disc(L.add, q[0], q[1], 2.2, WH, 1); }
        const s2 = prog(t, pt + 0.6, pt + 1.1);
        if (s2 > 0 && s2 < 1) { const q = pts[Math.floor(s2 * (pts.length - 1))]; halo(L.add, q[0], q[1], 8, TEAL, 0.7, 1); disc(L.add, q[0], q[1], 1.8, WH, 1); }
      }
    });
    // final-form instant
    if (full > 0) { c.darken(0.3 * full); halo(L.add, Hc[0], Hc[1], 120, TEAL, 0.25 * full, YS); c.post.grade = [0.7, 1.0, 1.3, 0.35 * full]; }
    // contraction: all remains drawn into the heart, becoming an abyssal core
    if (t > 7.3 && t < 8.7) {
      const q = ease.in(prog(t, 7.6, 8.4));
      const r = 6 + 16 * q;
      disc(L.front, Hc[0], Hc[1], r, 0x010104, 1);
      gring(L.add, Hc[0], Hc[1], r + 1, WH, 2, 1, 0, TAU, 1);
      gring(L.add, Hc[0], Hc[1], r + 4, TEAL, 2, 0.6, 0, TAU, 1);
      c.lens(Hc[0], Hc[1], 120, -1.2 * q);
      c.darken(0.55 * q);
      c.silhouette(0.6 * q);
      if (t < 8.4) c.burst('add', Hc[0] + rr(-60, 60), Hc[1] + rr(-40, 40), 1, { spd: [0, 1], life: [0.2, 0.4], cols: [TEAL] });
    }
    // enemies: tugged to the heart by each pulse; pinned into the core as it closes
    c.enemies.forEach((e, i) => {
      if (t > 7.5 && t < 8.6) { const q = ease.in(prog(t, 7.5, 8.4)); e.pin(lerp(e.x, Hc[0] + (i - 2) * 6, q * 0.15), lerp(e.y, Hc[1] + 10, q * 0.15), 6 * q + 3 * Math.sin(t * 20 + i), 0.2 * Math.sin(t * 15 + i)); e.shakeAmt = 0.7; }
    });
    void dt;
  });
  pulseT.forEach((pt) => c.at(pt + 0.55, () => {
    c.enemies.forEach((e) => { const a = Math.atan2(Hc[1] - e.y, Hc[0] - e.x); const d = dist(e.x, e.y, Hc[0], Hc[1]); if (d > 30) { e.vx += Math.cos(a) * 95; e.vy += Math.sin(a) * 95 * YS; e.vz = 40; e.flash = 0.6; } });
    c.shock(Hc[0], Hc[1], { r: 70, life: 0.7, col: CRIM, w: 3, amp: 3 });
    c.shake(2.5);
  }));
  c.at(7.25, () => { c.flash(TEAL, 0.5); c.shake(4); });
  c.at(7.9, () => { c.slow(0.5, 0.15); c.burst('add', Hc[0], Hc[1], 40, { spd: [10, 120], life: [0.3, 0.8], cols: [TEAL, WH], drag: 2 }); });
  c.at(8.7, () => {
    c.flash(WH, 1); c.shake(18); c.slow(0.3, 0.35);
    c.blast(Hc[0], Hc[1], 340, 330, 170, 12);
    c.enemies.forEach((e) => c.strike(e, Math.atan2(e.y - Hc[1] + rr(-8, 8), e.x - Hc[0] + rr(-8, 8)), 300, 170, TEAL, 14));
    // fluid-like wobbling shockwave
    c.ent(1.8, (_a, u) => {
      const r = 300 * ease.out3(u), f = 1 - u;
      const pts: P[] = [];
      for (let i = 0; i <= 80; i++) { const a = (i / 80) * TAU; const w = 1 + 0.07 * Math.sin(a * 7 + u * 12) + 0.04 * Math.sin(a * 13 - u * 20); pts.push([Hc[0] + Math.cos(a) * r * w, Hc[1] + Math.sin(a) * r * w * YS]); }
      line(c.L.add, pts, 8 * f + 2, 0x0a2a4a, 0.5 * f);
      line(c.L.add, pts, 4 * f + 1, TEAL, 0.9 * f);
      line(c.L.add, pts, 1.5, WH, f);
      c.distort(Hc[0], Hc[1], r, 7 * f);
    });
    [60, 160].forEach((r, i) => c.shock(Hc[0], Hc[1], { r, life: 1.0 + i * 0.4, col: i ? CRIM : TEAL, w: 5, amp: 4 }));
    // curling black water arms + droplets + bone shards
    c.ent(2.0, (_a, u) => {
      for (let arm = 0; arm < 5; arm++) {
        const pts = sample((s) => { const r = 300 * ease.out3(u) * s, a = (arm / 5) * TAU + s * 2.4 * (arm % 2 ? 1 : -1) + u * 1.5; return [Hc[0] + Math.cos(a) * r, Hc[1] + Math.sin(a) * r * YS - Math.sin(s * Math.PI) * 18] as P; }, 24);
        ribbon(c.L.add, pts, (i, n) => 9 * Math.sin((i / n) * Math.PI) * (1 - u) + 1, 0x061a30, 0.7 * (1 - u));
        line(c.L.add, pts, 1, TEAL, 0.7 * (1 - u));
      }
    });
    for (let i = 0; i < 120; i++) { const a = rr(0, TAU), s = rr(40, 360); c.emit(i % 3 ? 'add' : 'deb', { x: Hc[0], y: Hc[1], z: rr(0, 30), vx: Math.cos(a) * s, vy: Math.sin(a) * s * YS, vz: rr(60, 300), gz: 330, life: rr(0.8, 2.2), size: i % 3 ? rr(1, 2) : rr(2, 4), c0: i % 3 ? TEAL : BONE, c1: i % 3 ? 0x1a4a7a : BONE_D, bounce: 0.4, drag: 0.6 }); }
    ringScar(c, Hc[0], Hc[1], 70, 6, TEAL, 2); ringScar(c, Hc[0], Hc[1], 150, 6, TEAL, 2);
    crackScar(c, Hc[0], Hc[1], 12, 110, 6, TEAL);
    // a few enormous ribs remain, suspended, then sink
    leftRibs.forEach((ri, j) => {
      const r = ribs[ri], base = S(r.u);
      c.ent(3.3, (_a, u) => {
        const g = ease.out(Math.min(1, u * 4)), sink = sstep(0.55, 1, u), al = 1 - sink;
        const b: P = [base[0], base[1] + sink * 14], tip: P = [lerp(b[0], Hc[0], 0.8), b[1] - 10 - 30 * j * 0.0];
        const ctrl: P = [b[0] + (tip[0] - b[0]) * 0.1, b[1] - 74];
        const pts = partial(sample((q) => bez2(b, ctrl, tip, q), 18), g);
        ribbon(c.L.front, pts, (i, n) => 6 * (1 - i / n * 0.8) + 1, mix(BONE, 0x2a3a4a, sink), al);
        ribbon(c.L.add, pts, (i, n) => 3 * (1 - i / n * 0.8), TEAL, 0.4 * al);
      });
    });
  });
}

export const DRAGONBONE: Skill[] = [
  { id: 5, relic: 'chain', name: 'Wyrm Uncoiled', sub: 'a chain lengthens into one continuous spectral dragon', dur: 9.5, phases: [[0, 'Lash & carry'], [1.2, 'Chain becomes wyrm'], [4.2, 'Coil'], [5.5, 'Warrior streaks out'], [6.1, 'Plunge helix'], [6.95, 'Detonation']], setup: s05 },
  { id: 6, relic: 'chain', name: 'Cathedral of Shackles', sub: 'anchors, chains, arches, seals — a gothic prison that contracts to a knot', dur: 12, phases: [[0.4, 'Four anchors'], [3.0, 'Cathedral builds'], [5.9, 'Leap & pull taut'], [6.2, 'Staged contraction'], [8.0, 'Knot'], [8.8, 'Burst']], setup: s06 },
  { id: 7, relic: 'chain', name: 'Hell-Tide Harpoon', sub: 'a spiral whirlpool pulled through a needle\u2019s eye', dur: 10, phases: [[0, 'Harpoon'], [0.9, 'Spiral whirlpool'], [5.0, 'Dash & tension'], [5.4, 'Collapse to a line'], [6.05, 'Serpentine blast']], setup: s07 },
  { id: 8, relic: 'chain', name: "Leviathan's Last Heartbeat", sub: 'scattered bones reveal one colossal creature, then it implodes', dur: 13, phases: [[0, 'Chain sinks'], [1.8, 'Fragments emerge'], [3.4, 'Pulses'], [7.3, 'Contraction'], [8.7, 'Heartbeat'], [10, 'Remains sink']], setup: s08 },
];
