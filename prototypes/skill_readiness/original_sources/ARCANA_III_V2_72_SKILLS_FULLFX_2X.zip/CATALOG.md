# ARCANA III — V2 implementation catalog

This catalog is derived from actual code registrations, not a proposed-only design board.

**Status:** 20 original ultimates untouched; 40 newly authored independent V2 skills; #301 preserved unchanged; 11 newly implemented causal-fusion candidates. 72 selectable entries total. **No rendered WebGL acceptance has been performed in this environment.**

## Independent V2 techniques

| Family | Small ID & name — mechanism | Grand ID & name — transformed mechanism |
|---|---|---|
| Eclipse Halo | **101 Solar Sickle** — curved split blades | **201 Penumbra Siege** — three light-draining eclipses converge |
| Eclipse Halo | **102 Comet Rebound** — tangent deflection | **202 Retrograde Collision** — opposed figure-eights reverse through crossings |
| Eclipse Halo | **103 Star Nail** — single piercing meteor | **203 Skyfall Relay** — impact platforms redirect falling bodies |
| Eclipse Halo | **104 Horizon Shear** — displaced spatial strip | **204 Orthogonal Collapse** — two orthogonal rings shear and fold terrain |
| Dragonbone Chain | **105 Vertebra Lash** — segmented tightening vertebra | **205 Hydra Coil** — three independently hunting serpent heads |
| Dragonbone Chain | **106 Serrated Manacle** — paired V-lock chains | **206 Cage-Shift** — polyhedral prison refolds against targets |
| Dragonbone Chain | **107 Dragline** — off-axis drag into a launch rail | **207 Undertow Engine** — opposing coupled vortices exchange pressure |
| Dragonbone Chain | **108 Rib Hook** — closing pairs of ribs | **208 Cardiac Breaker** — heartbeat travels through three skeletal chambers |
| Prismatic War Fan | **109 Chromatic Split** — one ray splits into three delayed cuts | **209 Chromatic Maelstrom** — seven differently-behaving fluid light lanes |
| Prismatic War Fan | **110 False-Face Shatter** — reflected decoy and deflected glass strike | **210 Kaleidoscope Guillotine** — beam reflections turn mirrors into guillotine blades |
| Prismatic War Fan | **111 Ink Fang** — ink stroke grows into predatory jaw | **211 Script Execution** — three connected strokes become successive ink blades |
| Prismatic War Fan | **112 Scissorwing** — two luminous wings scissor a target | **212 Murmuration Cathedral** — swarm assembles architecture then giant severing wings |
| Fate Spindle | **113 Needle Gate** — gate carries a pulse to a target | **213 Fate Crossfire** — reconnecting needle graph routes combined pulses |
| Fate Spindle | **114 Backstitch** — rewound strike follows an old dash | **214 Temporal Avalanche** — three frozen events reactivate in reverse order |
| Fate Spindle | **115 Predator Thread** — angled pull bends into a blade | **215 String Orchestra** — three different tension systems drive triangle convergence |
| Fate Spindle | **116 Aegis Unfurl** — woven shield dimples then rebounds | **216 Loom Guillotine** — fabric rows rise as sequential slicing folds |
| Soul Lantern | **117 Phantom Passage** — three ghosts follow and strike along a track | **217 Wraith Cavalcade** — two spectral armies converge on the group |
| Soul Lantern | **118 Soul Comet** — one arcing soul blossoms upon collision | **218 Mortuary Bloomfield** — impact seeds ignite a branching field of flowers |
| Soul Lantern | **119 Resonance Fang** — wave rebounds after enemy collision | **219 Antiphonal Destruction** — two interference fields make a moving damage seam |
| Soul Lantern | **120 Void Bite** — collapsing aperture bites the world | **220 Abyss Fold** — paired portals ingest and expel the same energy stream |

## Fusion V2

#301 **Corona of Shackled Kings**: existing accepted implementation and parameters preserved, original dual-runtime technique.

| ID | Fusion | Coupled mechanisms |
|---:|---|---|
| 302 | **Reflected Orbit** | Blade paths reflect off actual oriented glass planes; reversed travel shatters them |
| 303 | **Ink-Blood Wyrm** | Connected calligraphy becomes the live parametric spine of an articulated dragon |
| 304 | **Meteor Sutures** | Taut needle connections capture and redirect falling meteors between graph vertices |
| 305 | **Time Meridian** | Ring crossings store prior cuts and reactivate them in reverse chronological order |
| 306 | **Resonant Undertow** | Vortex curl continuously bends propagating waves into compressed spiral fronts |
| 307 | **Prism Loom** | Seven guided streams enter connected fabric cells; each row redirects and recolors the flow |
| 308 | **Soulwing Ascension** | Each ghostfire seed becomes a new luminous butterfly that flies to a flower target |
| 309 | **Spectral Puppetry** | Live tension lines steer ghost soldiers into two coordinated flanking armies |
| 310 | **Abyssal Ribgate** | Individual ribs are actual portal-frame segments; the heartbeat directly controls its aperture |
| 311 | **Chromatic Lockdown** | Cage edges are conducting rails that transmit refracted current toward enclosed targets |
| 312 | **Singularity Harpoon** | A central tether changes meteor trajectories via orbiting gravity and releases a joint drill |

## Verification and limitations

- `node scripts/check-v2.mjs` exercises all 51 new routines from time zero through closing, verifies registered contact events, dynamic geometry calls, opening cue, and camera/density invariants. It does not execute GPU shaders or prove artistry.
- `npx tsc --noEmit` performs full source type checking after dependencies are installed. The local inspection found no diagnostics in new V2 files; external React/Pixi types could not be resolved without dependency installation.
- Camera is fixed to default 0.5x zoom (2x distant), user may switch to original 1x. `DENS` remains 2.1, bloom and shader original.
- The 20 ultimate source files and original renderer/runtime core are byte-for-byte unchanged relative to the supplied corrected ZIP.
- #301 original pairing, secondary timing, nexus, and color are unchanged.
- The 11 other fusions no longer instantiate original ultimates simultaneously or rely on nexus shock alone: each has a dedicated implementation of a joint mechanism. These remain candidates pending visual review.
- The standalone V2 geometry is newly authored to embody source phenomena; it is **not** a literal extraction of every original ultra-complex shader/path routine.
