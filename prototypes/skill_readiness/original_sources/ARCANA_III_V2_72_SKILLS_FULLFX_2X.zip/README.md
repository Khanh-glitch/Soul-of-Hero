# ARCANA III — V2 Full FX Lab (Candidate)

**72 selectable entries:** 20 original ultimate skills (unchanged); 20 independent small V2 skills; 20 independent grand V2 skills; original accepted fusion **#301**; 11 newly coded V2 causal-fusion candidates (**#302–312**).

This is a **source implementation candidate**, not a visually signed-off release. The running WebGL composition, FPS and artistic acceptability need checking in a real browser.

## Run

```bash
npm ci
npm run dev
```

Open the Vite local URL. Default camera zoom is 0.5 (2x farther); press `Z` to compare with 1x original. `R` resets; arrow keys change skills; space pauses; use skill filters or autoplay to inspect all 72. Scrub to a moment via the timeline.

## What changed in V2

- `src/skills/v2-independent.ts` replaces the old time-sliced / shared-template derivatives with **40 distinct, complete skills**. Each has its own setup, moving procedural geometry, staged impacts, enemy reaction, and close. Minor and grand vary in **mechanism**, not only particle count or extra repeat hits.
- `src/skills/v2-fusion.ts` implements 11 *coupled* behaviors: reflection geometry routes orbit blades (#302); ink paths define dragon spines (#303); graph vertices redirect meteors (#304); seam crossings control temporal release (#305); a vortex bends resonance fields (#306); fabric cells route light (#307); soul cores guide butterflies (#308); strings steer phantoms (#309); ribs act as portal gates (#310); cage edges conduct light (#311); tether gravity redirects meteors (#312).
- `src/skills/remixes.ts` continues to invoke the existing **#301 Corona of Shackled Kings** with exactly the original two ultimate setups, offset 0.3, nexus 6.9 and color 0xffaa55. Other fusions use new combined mechanisms, not a full concurrent playback of two originals.
- 20 original ultimate scripts, existing scene renderer, particle density and post-FX are byte-identical to the supplied corrected baseline.

## Validation already possible here

```bash
node scripts/check-v2.mjs
```

Checks 51 V2 entries end-to-end **as timeline/geometry calls**, with contact, release, and finite path checks. See `V2_TEST_RESULTS.json`.

**Verification limit:** `npm ci` could not complete (an unavailable npm tarball in offline cache and a network timeout), so Vite build, PixiJS/WebGL visual captures and FPS are **NOT verified**. Do not infer polished visuals from passing this check. Please compare all phases of difficult skills visually before promoting them to production. No effect intensity/particle quality scaling was intentionally added.

For per-skill design/implementation mapping see `CATALOG.md`; for the original proposal see `ARCANA_V2_DESIGN_BOARD.md`.
