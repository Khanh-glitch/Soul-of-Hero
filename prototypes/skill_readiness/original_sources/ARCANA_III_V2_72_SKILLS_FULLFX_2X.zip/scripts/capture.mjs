// Runtime evidence: drives the REAL running lab in headless Chromium (WebGL) and saves frames / contact sheets.
// usage: node scripts/capture.mjs <ids|all> [framesPerSkill=8] [outDir=captures]
import { chromium } from 'playwright';
import { createServer } from 'vite';
import fs from 'fs';

const arg = process.argv[2] ?? 'all';
const N = parseInt(process.argv[3] ?? '8');
const out = process.argv[4] ?? 'captures';
fs.mkdirSync(out, { recursive: true });
const server = await createServer({ server: { port: 5199 }, logLevel: 'error' });
await server.listen();
const browser = await chromium.launch({ env: { ...process.env, ...(process.env.EXTRA_LD ? { LD_LIBRARY_PATH: process.env.EXTRA_LD } : {}) }, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 1000, height: 700 } });
const errs = [];
page.on('pageerror', (e) => errs.push(String(e)));
page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
await page.goto('http://localhost:5199/?paused');
await page.waitForFunction(() => window.__lab && window.__lab.skill, null, { timeout: 60000 });
const ids = arg === 'all' ? await page.evaluate(() => window.__lab.skills.map(s => s.id)) : arg.split(',').map(Number);
const summary = [];
for (const id of ids) {
  const res = await page.evaluate(
    async ({ id, N }) => {
      const lab = window.__lab;
      const s = lab.skills.find((k) => k.id === id);
      lab.showcase = false;
      lab.load(s, false);
      const W = 480, H = 270, cols = 4, rows = Math.ceil(N / cols);
      const sheet = document.createElement('canvas');
      sheet.width = W * cols; sheet.height = H * rows;
      const g = sheet.getContext('2d');
      g.imageSmoothingEnabled = false;
      let maxP = 0, nonBlack = [];
      const t0 = performance.now();
      for (let i = 0; i < N; i++) {
        const t = ((i + 1) / N) * s.dur * 0.999;
        lab.advance(t);
        const cv = lab.app.canvas;
        g.drawImage(cv, (i % cols) * W, Math.floor(i / cols) * H);
        g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect((i % cols) * W, Math.floor(i / cols) * H, 78, 13);
        g.fillStyle = '#fff'; g.font = '11px monospace'; g.fillText('t=' + t.toFixed(2), (i % cols) * W + 4, Math.floor(i / cols) * H + 10);
        maxP = Math.max(maxP, lab.liveParticles);
      }
      return { url: sheet.toDataURL('image/png'), maxP, ms: Math.round(performance.now() - t0) };
    },
    { id, N },
  );
  fs.writeFileSync(`${out}/skill-${String(id).padStart(3, '0')}.png`, Buffer.from(res.url.split(',')[1], 'base64'));
  summary.push({ id, maxParticles: res.maxP, simMs: res.ms });
  console.log('captured', id, JSON.stringify({ maxParticles: res.maxP, simMs: res.ms }));
}
fs.writeFileSync(`${out}/summary.json`, JSON.stringify({ errors: errs, summary }, null, 2));
console.log('page errors:', errs.length ? errs.join('\n') : 'none');
await browser.close();
await server.close();
