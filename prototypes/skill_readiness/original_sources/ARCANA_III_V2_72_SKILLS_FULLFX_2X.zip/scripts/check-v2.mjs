/** No renderer used in this test: timeline and geometry call smoke, not visual acceptance. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
const native = createRequire(import.meta.url);
const ts = native('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js');
let primitives=0, badGeometry=0;
const checkPts=(arg)=> {if(!Array.isArray(arg))return;if(arg.some(p=>!Array.isArray(p)||p.length<2||!Number.isFinite(p[0])||!Number.isFinite(p[1])))badGeometry++;};
const draw=new Proxy({}, {get:(_,key)=> (...args)=>{
 primitives++;
 if(['ribbon','line','chainLine'].includes(String(key)))checkPts(args[1]);
 }});
const fx=new Proxy({}, {get:()=>()=>{primitives++;}});
const utilSrc=fs.readFileSync(new URL('../src/engine/util.ts',import.meta.url),'utf8');
function transpile(code,name){const out=ts.transpileModule(code,{fileName:name,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2020,module:ts.ModuleKind.CommonJS}});const es=out.diagnostics?.filter(d=>d.category===ts.DiagnosticCategory.Error)??[];assert.equal(es.length,0,`${name}: ${es.map(e=>ts.flattenDiagnosticMessageText(e.messageText,' ')).join('; ')}`);return out.outputText;}
function load(code,name,r){const m={exports:{}};new Function('require','module','exports',transpile(code,name))(r,m,m.exports);return m.exports;}
const util=load(utilSrc,'util.ts',native);
const bind=name=>name.endsWith('/util')?util:name.endsWith('/draw')?draw:name.endsWith('/fx')?fx:name.endsWith('/core')?{}:native(name);
const smallMod=load(fs.readFileSync(new URL('../src/skills/v2-independent.ts',import.meta.url),'utf8'),'v2-independent.ts',bind);
const fusionMod=load(fs.readFileSync(new URL('../src/skills/v2-fusion.ts',import.meta.url),'utf8'),'v2-fusion.ts',bind);
const entries=[...smallMod.independentSkills(),...fusionMod.v2FusionSkills()];
assert.equal(entries.length,51);
assert.equal(new Set(entries.map(e=>e.id)).size,51);
assert.equal(new Set(entries.map(e=>e.name)).size,51);
let totalContacts=0,totalBursts=0,calledAtStart=0,totalEmit=0;
const summary=[];
for (const skill of entries){
 let strikes=0,bursts=0,emits=0,shocks=0,flashes=0,linesBefore=primitives;
 const c={L:{mark:{},glow:{},act:{},front:{},dark:{},add:{},sky:{}},enemies:[],caster:{x:0,y:0,tx:0,ty:0,trail:0},cues:[],handlers:[],segs:[],ents:[],
   ent(life,fn){this.ents.push({begin:this.t??0,life,fn});},
   layout(pts){this.enemies=pts.map(([x,y])=>({x,y,pin(px,py){this.x=px;this.y=py;}}));},
   at(t,fn){this.cues.push({t,fn,done:false});},each(fn){this.handlers.push(fn);},seg(t0,t1,fn,e){this.segs.push({t0,t1,fn,e});},
   burst(){bursts++;},emit(){emits++;},strike(e,a,p){assert.ok(Number.isFinite(e.x)&&Number.isFinite(e.y)&&Number.isFinite(a)&&p>0);strikes++;},
   shock(){shocks++;},flash(){flashes++;},shake(){},distort(){},darken(){},lens(){},silhouette(){},sprite(){},
 };
 skill.setup(c);
 assert.ok(c.cues.length>=3,`${skill.id}: no opening/contact/outro`);
 assert.ok(c.handlers.length>=1,`${skill.id}: no VFX renderer`);
 assert.ok(c.segs.length>=1,`${skill.id}: no caster movement`);
 const timestep=1/30;
 for (let t=0;t<=skill.dur+1e-6;t+=timestep){
   for(const cue of c.cues)if(!cue.done&&cue.t<=t+0.0001){cue.done=true;cue.fn();}
   for(const part of c.segs)if(t>=part.t0){const u=util.clamp((t-part.t0)/(part.t1-part.t0));const pos=part.fn(part.e?part.e(u):u);assert.ok(pos.every(Number.isFinite),`${skill.id}: invalid caster path ${pos}`);c.caster.x=pos[0];c.caster.y=pos[1];}
   c.t=t;for(const fn of c.handlers)fn(t,timestep);
   for(const ent of c.ents)if(t>=ent.begin&&t<ent.begin+ent.life)ent.fn(t-ent.begin,(t-ent.begin)/ent.life,timestep);
 }
 assert.ok(strikes>=1,`${skill.id}: no synchronized enemy contact`);
 assert.ok(bursts>=1,`${skill.id}: no transient effects`);
 assert.ok(primitives-linesBefore>25,`${skill.id}: no constructed visual geometry`);
 assert.ok(c.cues.every(v=>v.done),`${skill.id}: unresolved event after playback`);
 totalContacts+=strikes;totalBursts+=bursts;totalEmit+=emits;if(c.cues[0].t<=0.2)calledAtStart++;
 summary.push({id:skill.id,name:skill.name,contacts:strikes,geometryCalls:primitives-linesBefore,bursts,emits,shocks,flashes});
}
assert.equal(badGeometry,0,'nonfinite or malformed geometry path encountered');
assert.equal(calledAtStart,51,'missing opening cue');
assert.equal(entries.filter(x=>x.kind==='minor').length,20);
assert.equal(entries.filter(x=>x.kind==='major').length,20);
assert.equal(entries.filter(x=>x.kind==='fusion').length,11);
// Legacy #301 retained exactly; camera and density unchanged.
const core=fs.readFileSync(new URL('../src/engine/core.ts',import.meta.url),'utf8');
assert.match(core,/cameraZoom = 0\.5/);assert.match(core,/const DENS = 2\.1/);
const remixes=fs.readFileSync(new URL('../src/skills/remixes.ts',import.meta.url),'utf8');
assert.match(remixes,/\['Corona of Shackled Kings', 1, 6, 0\.3, 6\.9, 0xffaa55\]/);
console.log(JSON.stringify({status:'PASS (logic & geometry calls, NOT rendered visual acceptance)',tested:entries.length,originalsPreserved:20,legacyFusionPreserved:301,contacts:totalContacts,bursts:totalBursts,emits:totalEmit,drawPrimitives:primitives,badGeometry,cameraZoom:0.5,density:2.1,results:summary},null,2));
