// Runtime analysis: measures the REAL running frames (no visual inspection needed).
//  · frame stats  – lit coverage, saturated (blown-out) coverage, unique quantised colours, mean luma
//  · motion stats – per-step velocity/acceleration continuity for the caster and every enemy
// usage: node scripts/analyze.mjs <ids|all> [frames=24]
import { chromium } from 'playwright';
import { createServer } from 'vite';
import fs from 'fs';

const arg = process.argv[2] ?? 'all';
const N = parseInt(process.argv[3] ?? '24');
const server = await createServer({ server: { port: 5199 }, logLevel: 'error' });
await server.listen();
const browser = await chromium.launch({ env: { ...process.env }, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 900, height: 600 } });
const errs = [];
page.on('pageerror', (e) => errs.push(String(e.stack || e).slice(0, 300)));
page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 200)); });
await page.goto('http://localhost:5199/?paused');
await page.waitForFunction(() => window.__lab && window.__lab.skill, null, { timeout: 60000 });
const ids = arg === 'all' ? Array.from({ length: 20 }, (_, i) => i + 1) : arg.split(',').map(Number);
const out = [];
for (const id of ids) {
  const r = await page.evaluate(async ({ id, N }) => {
    const lab = window.__lab, s = lab.skills.find((k) => k.id === id);
    lab.showcase = false; lab.load(s, false);
    const cv = document.createElement('canvas'); cv.width = 480; cv.height = 270;
    const g2 = cv.getContext('2d', { willReadFrequently: true });
    const steps = Math.floor(s.dur * 60);
    const every = Math.max(1, Math.floor(steps / N));
    const frames = [];
    // motion sampling every step
    const cp = [], ep = [];
    let maxParts = 0;
    for (let i = 0; i < steps; i++) {
      lab.ctx.step(1 / 60);
      if (i % 12 === 0) lab.draw();               // keep the trail buffer alive
      cp.push([lab.ctx.caster.x, lab.ctx.caster.y, lab.ctx.caster.z]);
      ep.push(lab.ctx.enemies.map((e) => [e.x, e.y, e.z]));
      maxParts = Math.max(maxParts, lab.ctx.count());
      if (i % every === 0) {
        lab.draw();
        g2.clearRect(0, 0, 480, 270);
        g2.drawImage(lab.app.canvas, 0, 0);
        const d = g2.getImageData(0, 0, 480, 270).data;
        let lit = 0, sat = 0, sum = 0; const cols = new Set();
        for (let p = 0; p < d.length; p += 4) {
          const l = (d[p] * 0.299 + d[p + 1] * 0.587 + d[p + 2] * 0.114) / 255;
          sum += l;
          if (l > 0.12) lit++;
          if (l > 0.94) sat++;
          cols.add(((d[p] >> 3) << 10) | ((d[p + 1] >> 3) << 5) | (d[p + 2] >> 3));
        }
        const n = d.length / 4;
        frames.push({ t: +(i / 60).toFixed(2), lit: +(lit / n).toFixed(3), sat: +(sat / n).toFixed(4), luma: +(sum / n).toFixed(3), colors: cols.size });
      }
    }
    // afterglow: does the trail buffer fully settle after the skill ends?
    for (let i = 0; i < 100; i++) { lab.ctx.step(1 / 60); if (i % 12 === 0) lab.draw(); }
    lab.draw();
    g2.clearRect(0, 0, 480, 270); g2.drawImage(lab.app.canvas, 0, 0);
    const da = g2.getImageData(0, 0, 480, 270).data;
    let alit = 0, asat = 0;
    for (let p = 0; p < da.length; p += 4) { const l = (da[p] * 0.299 + da[p + 1] * 0.587 + da[p + 2] * 0.114) / 255; if (l > 0.12) alit++; if (l > 0.94) asat++; }
    const after = { lit: +(alit / (da.length / 4)).toFixed(3), sat: +(asat / (da.length / 4)).toFixed(4) };
    // continuity: velocity then acceleration, in px per frame
    const acc = (arr) => {
      const a = []; for (let i = 2; i < arr.length; i++) a.push(Math.hypot(arr[i][0] - 2 * arr[i - 1][0] + arr[i - 2][0], arr[i][1] - 2 * arr[i - 1][1] + arr[i - 2][1]));
      a.sort((x, y) => x - y);
      return { p50: +(a[a.length >> 1] || 0).toFixed(2), p99: +(a[Math.floor(a.length * 0.99)] || 0).toFixed(2), max: +(a[a.length - 1] || 0).toFixed(2) };
    };
    const eAcc = [];
    for (let e = 0; e < ep[0].length; e++) eAcc.push(acc(ep.map((f) => f[e])));
    const worst = eAcc.reduce((m, x) => ({ p50: Math.max(m.p50, x.p50), p99: Math.max(m.p99, x.p99), max: Math.max(m.max, x.max) }), { p50: 0, p99: 0, max: 0 });
    const avg = (k) => +(frames.reduce((s, f) => s + f[k], 0) / frames.length).toFixed(3);
    return {
      id, frames, maxParts,
      mean: { lit: avg('lit'), sat: avg('sat'), luma: avg('luma'), colors: Math.round(frames.reduce((s, f) => s + f.colors, 0) / frames.length) },
      peakSat: Math.max(...frames.map((f) => f.sat)), peakLuma: Math.max(...frames.map((f) => f.luma)),
      after, casterAcc: acc(cp), enemyAcc: worst,
    };
  }, { id, N });
  out.push(r);
  console.log(
    `#${String(r.id).padStart(2)} parts=${String(r.maxParts).padStart(4)} lit=${r.mean.lit} sat=${r.mean.sat} peakSat=${r.peakSat} luma=${r.mean.luma} peak=${r.peakLuma} cols=${r.mean.colors} after=${r.after.lit}/${r.after.sat} | casterAcc p50/p99/max=${r.casterAcc.p50}/${r.casterAcc.p99}/${r.casterAcc.max} enemyAcc=${r.enemyAcc.p50}/${r.enemyAcc.p99}/${r.enemyAcc.max}`,
  );
}
fs.mkdirSync('captures', { recursive: true });
// merge with previous runs so the record accumulates across batches
let prev = { errors: [], skills: [] };
try { prev = JSON.parse(fs.readFileSync('captures/analysis.json', 'utf8')); } catch { /* first run */ }
const byId = new Map((prev.skills ?? []).map((s) => [s.id, s]));
for (const r of out) byId.set(r.id, r);
const merged = { errors: [...(prev.errors ?? []), ...errs].slice(0, 20), skills: [...byId.values()].sort((a, b) => a.id - b.id) };
fs.writeFileSync('captures/analysis.json', JSON.stringify(merged, null, 1));
console.log('errors:', errs.length ? errs.slice(0, 3).join('\n') : 'none');
await browser.close(); await server.close();
