// V2 aliases to the current complete skill verification.
import './check-v2.mjs';
