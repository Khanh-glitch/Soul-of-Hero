// Smoke test for the production bundle: serves dist/index.html and checks the lab boots + plays + seeks.
import { chromium } from 'playwright';
import { createServer } from 'http';
import { readFileSync } from 'fs';

const html = readFileSync('dist/index.html');
const srv = createServer((_q, res) => { res.writeHead(200, { 'Content-Type': 'text/html' }); res.end(html); });
await new Promise((r) => srv.listen(5211, r));
const browser = await chromium.launch({ env: { ...process.env }, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 1000, height: 700 } });
const errs = [];
page.on('pageerror', (e) => errs.push(String(e.stack || e).slice(0, 300)));
page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 200)); });
await page.goto('http://localhost:5211/', { timeout: 30000 });
await page.waitForFunction(() => window.__lab && window.__lab.skill, null, { timeout: 60000 });
const r = await page.evaluate(async () => {
  const lab = window.__lab;
  const out = { skills: lab.skills.length, booted: !!lab.skill };
  // play for a real second of wall-clock time
  lab.load(lab.skills[19], true);
  await new Promise((res) => setTimeout(res, 1200));
  out.played = +lab.ctx.t.toFixed(2);
  out.liveParticles = lab.liveParticles;
  // scrub backwards and forwards
  lab.seek(3); out.afterSeek = +lab.ctx.t.toFixed(2);
  lab.advance(9); out.afterAdvance = +lab.ctx.t.toFixed(2);
  // every skill must at least initialise and survive one step
  out.failures = [];
  out.kinds = { original: 0, minor: 0, major: 0, fusion: 0 };
  for (const s of lab.skills) {
    out.kinds[s.kind ?? 'original']++;
    try { lab.load(s, false); if (!Number.isFinite(lab.displayTime)) throw new Error('invalid time'); }
    catch (e) { out.failures.push(s.id + ': ' + String(e).slice(0, 120)); }
  }
  out.zoom = lab.cameraZoom;
  out.fullDensity = lab.ctx.dens;
  // Representative render-time seeks for one original, one minor, one grand, one fusion.
  out.samples = [];
  for (const id of [1, 101, 201, 301]) {
    try {
      const s = lab.skills.find(x => x.id === id);
      lab.load(s, false); lab.seek(s.dur * 0.5);
      out.samples.push({ id, t: lab.displayTime, particles: lab.liveParticles });
    } catch (e) { out.failures.push(id + ': seek ' + String(e).slice(0, 120)); }
  }
  return out;
});
console.log(JSON.stringify(r, null, 1));
console.log('errors:', errs.length ? errs.slice(0, 3).join('\n') : 'none');
await browser.close(); srv.close();
