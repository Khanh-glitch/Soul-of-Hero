// Profiling helper: separates simulation cost from render cost for one skill.
import { chromium } from 'playwright';
import { createServer } from 'vite';
const server = await createServer({ server: { port: 5199 }, logLevel: 'error' });
await server.listen();
const browser = await chromium.launch({ env: { ...process.env }, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const page = await browser.newPage({ viewport: { width: 900, height: 600 } });
await page.goto('http://localhost:5199/?paused');
await page.waitForFunction(() => window.__lab && window.__lab.skill, null, { timeout: 60000 });
const r = await page.evaluate(async (id) => {
  const lab = window.__lab, s = lab.skills.find((k) => k.id === id);
  lab.load(s, false);
  let t0 = performance.now(), parts = 0;
  for (let i = 0; i < 240; i++) { lab.ctx.step(1 / 60); parts = Math.max(parts, lab.ctx.count()); }
  const sim = (performance.now() - t0) / 240;
  lab.load(s, false); lab.advance(s.dur * 0.55);
  t0 = performance.now(); for (let i = 0; i < 12; i++) { lab.ctx.step(1 / 60); lab.draw(); }
  const full = (performance.now() - t0) / 12;
  t0 = performance.now(); for (let i = 0; i < 12; i++) lab.draw();
  const drawOnly = (performance.now() - t0) / 12;
  return { simPerStep: +sim.toFixed(2), fullFrame: +full.toFixed(2), drawOnly: +drawOnly.toFixed(2), parts };
}, Number(process.argv[2] || 1));
console.log(JSON.stringify(r));
await browser.close(); await server.close();
