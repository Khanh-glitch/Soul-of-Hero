import { BAYER, Field, Layer, P, Rng, TAU, bubble, clamp, glow, hash, lerp, mix, nz1, nz2, shard, smooth, type Col, type Mat } from './pixel';
import type { Enemy, HitOpts, World } from './world';

export interface Gfx { s: Layer; l: Layer; f: Field; t: number; W: number; H: number; k: number }

export class Hits {
  m = new Map<number, { t: number; n: number }>();
  ok(e: Enemy, now: number, cd = Infinity, max = Infinity) {
    const r = this.m.get(e.id);
    if (r) { if (r.n >= max || now - r.t < cd) return false; r.t = now; r.n++; return true; }
    this.m.set(e.id, { t: now, n: 1 }); return true;
  }
  n(e: Enemy) { return this.m.get(e.id)?.n ?? 0; }
}

export abstract class Fx {
  dead = false; age = 0; x = 0; y = 0; r = 0; sy = 0;
  tank = false; hp = 0; maxHp = 0; push = false; kind = 'fx'; resid = false; hf = 0;
  upd(_w: World, _dt: number) { /* override */ }
  gnd?(g: Gfx, w: World): void;
  shd?(g: Gfx, w: World): void;
  up?(g: Gfx, w: World): void;
  air?(g: Gfx, w: World): void;
  lit?(g: Gfx, w: World): void;
  hurt(_w: World, amt: number) { this.hp -= amt; this.hf = 0.12; }
}

// ---------------- particles ----------------
export type PK = 'drop' | 'shard' | 'chip' | 'bubble' | 'spore' | 'steam' | 'spark' | 'petal' | 'dust' | 'ember' | 'mote';
export interface Part {
  k: PK; x: number; y: number; z: number; vx: number; vy: number; vz: number; age: number; max: number; size: number;
  rot: number; vr: number; grav: number; drag: number; c1: Col; c2: Col; c3: Col; land: number; seed: number; glow: number;
  fn?: (p: Part, w: World, dt: number) => void; bounce: number; trail: number;
}
export type PO = Partial<Part> & { k: PK };

export class Particles {
  list: Part[] = [];
  n = 0;
  add(o: PO): Part | null {
    if (this.list.length > 4200) return null;
    const p: Part = {
      x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, age: 0, max: 1, size: 1, rot: 0, vr: 0, grav: 0, drag: 0,
      c1: P.c1, c2: P.c3, c3: P.e1, land: 0, seed: ++this.n, glow: 0, bounce: 0, trail: 0, ...o,
    };
    this.list.push(p);
    return p;
  }
  clear() { this.list.length = 0; this.n = 0; }
  update(w: World, dt: number) {
    const L = this.list;
    for (let i = L.length - 1; i >= 0; i--) {
      const p = L[i];
      p.age += dt;
      let dead = p.age >= p.max;
      if (p.fn) p.fn(p, w, dt);
      p.vz -= p.grav * dt;
      if (p.drag) { const k = Math.max(0, 1 - p.drag * dt); p.vx *= k; p.vy *= k; if (p.k !== 'drop') p.vz *= k; }
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.rot += p.vr * dt;
      if (p.land && p.z <= 0 && p.vz < 0 && !dead) {
        p.z = 0;
        if (p.land === 3 && p.bounce < 2) { p.vz = -p.vz * 0.4; p.vx *= 0.55; p.vy *= 0.55; p.bounce++; p.vr *= 0.5; }
        else {
          dead = true;
          if (p.land === 1) w.add(new Splash(p.x, p.y, Math.max(2, p.size * 1.3), p.c1, p.c2));
          else if (p.land === 2) w.add(new Embed(p.x, p.y, p.size, p.c1, p.c2, p.c3, 5 + (p.seed % 4)));
          else if (p.land === 4) w.add(new Splash(p.x, p.y, Math.max(2, p.size * 1.3), p.c1, p.c2));
        }
      }
      if (p.k === 'bubble' && p.age >= p.max) {
        w.parts.add({ k: 'spark', x: p.x, y: p.y, z: p.z + 1, vx: 12, vy: -6, vz: 8, max: 0.2, c1: p.c3 });
        w.parts.add({ k: 'spark', x: p.x, y: p.y, z: p.z + 1, vx: -12, vy: -5, vz: 8, max: 0.2, c1: p.c3 });
      }
      if (dead) { L[i] = L[L.length - 1]; L.pop(); }
    }
  }
  shadows(g: Gfx) {
    const L = g.s; L.dl = 6;
    for (const p of this.list) if (p.z > 2 && (p.k === 'drop' || p.k === 'chip' || p.k === 'shard')) L.dot(p.x, p.y, P.bk);
    L.dl = 16;
  }
  draw(g: Gfx) {
    const L = g.s;
    for (const p of this.list) {
      const a = p.age / p.max, px = p.x, py = p.y - p.z;
      switch (p.k) {
        case 'drop': {
          const s = p.size;
          if (p.trail && Math.abs(p.vz) > 35) {
            const tl = Math.min(4, Math.floor(Math.abs(p.vz) * 0.02));
            for (let i = 1; i <= tl; i++) { L.dl = 12 - i * 2; L.dot(px, py - (p.vz < 0 ? -i * 1.2 : i * 1.2), p.c3); }
            L.dl = 16;
          }
          if (s <= 1.2) L.dot(px, py, p.c1);
          else if (s <= 2.2) { L.disc(px, py, s * 0.5, p.c1); L.dot(px, py - 0.4, p.c2); }
          else if (s <= 3.2) { L.disc(px, py, s * 0.5, p.c3); L.disc(px, py, s * 0.35, p.c1); L.dot(px - 0.5, py - 0.5, p.c2); }
          else { L.disc(px, py, s * 0.55, p.c3); L.disc(px, py, s * 0.4, p.c1); L.dot(px - 0.6, py - 0.6, p.c2); L.dot(px + 0.2, py - 0.6, p.c2); }
          break;
        }
        case 'shard': shard(L, px, py, p.rot, p.size, p.size * 0.42, p.c1, p.c2, p.c3); break;
        case 'chip': {
          const s = Math.max(1.5, p.size);
          const ca = Math.cos(p.rot), sa = Math.sin(p.rot);
          L.poly([px - ca * s - sa * s * 0.6, py - sa * s + ca * s * 0.6, px + ca * s - sa * s * 0.6, py + sa * s + ca * s * 0.6, px + ca * s + sa * s * 0.6, py + sa * s - ca * s * 0.6, px - ca * s + sa * s * 0.6, py - sa * s - ca * s * 0.6], p.c1);
          L.line(px - ca * s - sa * s * 0.6, py - sa * s + ca * s * 0.6, px + ca * s - sa * s * 0.6, py + sa * s + ca * s * 0.6, p.c3);
          L.dot(px, py, p.c2);
          break;
        }
        case 'bubble': {
          const wob = Math.sin(p.age * 6 + p.seed) * 0.8;
          bubble(L, px + wob, py, p.size, p.c1, p.c2, p.c3);
          break;
        }
        case 'spore': {
          L.dot(px, py, p.c1);
          if (p.size > 1) { L.dot(px + 0.8, py, p.c2); L.dot(px - 0.8, py, p.c2); L.dot(px, py + 0.8, p.c2); L.dot(px, py - 0.8, p.c2); }
          break;
        }
        case 'steam': {
          const r = p.size * (0.5 + a * 0.9);
          L.dl = Math.max(1, Math.round(9 * (1 - a))); L.disc(px, py, r, p.c1);
          L.dl = Math.max(1, Math.round(7 * (1 - a))); L.disc(px - r * 0.3, py - r * 0.35, r * 0.55, p.c2); L.dl = 16;
          break;
        }
        case 'dust': {
          const r = p.size * (0.6 + a * 0.8);
          L.dl = Math.max(1, Math.round(10 * (1 - a))); L.disc(px, py, r, p.c1);
          L.dl = Math.max(1, Math.round(6 * (1 - a))); L.disc(px - 0.8, py - 0.8, r * 0.6, p.c2); L.dl = 16;
          break;
        }
        case 'spark': {
          L.dot(px, py, p.c1);
          if (a < 0.7) L.dot(p.x - p.vx * 0.03, p.y - p.vy * 0.03 - p.z + p.vz * 0.03, p.c2 ? mix(p.c1, P.k0, 0.5) : p.c1);
          break;
        }
        case 'petal': {
          const c = Math.cos(p.rot) * p.size, s = Math.sin(p.rot) * p.size * 0.6;
          L.poly([px - c, py - s, px, py - s * 0.5 - 1, px + c, py + s, px, py + s * 0.5 + 1], p.c1);
          L.dot(px, py, p.c2);
          break;
        }
        case 'ember': { L.dot(px, py, p.c1); L.dot(px, py + 0.8, p.c2); break; }
        case 'mote': { L.dot(px, py, p.c1); if (a < 0.5) L.dot(px + 0.8, py, p.c2); break; }
      }
    }
  }
  glows(g: Gfx) {
    const L = g.l; L.add = true; L.a = 70;
    for (const p of this.list) if (p.glow > 0) { L.disc(p.x, p.y - p.z, p.glow, p.c1); }
    L.add = false; L.a = 255;
  }
}

// ---------------- ground fx ----------------
export class Splash extends Fx {
  constructor(x: number, y: number, public rad: number, public c1: Col, public c2: Col) { super(); this.x = x; this.y = y; }
  upd(_w: World, _dt: number) { if (this.age > 0.34) this.dead = true; }
  gnd(g: Gfx) {
    const a = this.age / 0.34, L = g.s, r = this.rad * (0.5 + a * 1.4);
    L.dl = Math.round(14 * (1 - a * 0.8));
    const n = 8;
    for (let i = 0; i < n; i++) {
      const an = (i / n) * TAU + hash(i + this.x) * 0.5;
      const rr = r * (0.8 + hash(i * 7 + this.y) * 0.4);
      const px = this.x + Math.cos(an) * rr, py = this.y + Math.sin(an) * rr * 0.8;
      L.dot(px, py, a < 0.5 ? this.c2 : this.c1);
      if (a < 0.6) L.dot(this.x + Math.cos(an) * rr * 0.6, this.y + Math.sin(an) * rr * 0.5 - (1 - a) * 3, this.c1);
    }
    L.ring(this.x, this.y, r * 0.8, 0.8, this.c1);
    L.dl = 16;
  }
}

export class Embed extends Fx {
  constructor(x: number, y: number, public sz: number, public litC: Col, public dark: Col, public edge: Col, public life: number) { super(); this.x = x; this.y = y; this.sy = y; }
  upd(_w: World, _dt: number) { if (this.age > this.life) this.dead = true; }
  up(g: Gfx) {
    const fade = this.life - this.age < 0.8 ? (this.life - this.age) / 0.8 : 1;
    const L = g.s; L.dl = Math.round(16 * fade);
    const s = Math.max(2, this.sz);
    const lean = (hash(this.x * 3 + this.y) - 0.5) * 3;
    const h = s * 1.4 + 1, x = this.x, y = this.y;
    L.poly([x - 1.5, y, x + lean, y - h, x + 1.5, y], this.litC);
    L.poly([x, y, x + lean, y - h, x + 1.5, y], this.dark);
    L.dot(x + lean, y - h, this.edge);
    L.line(x - 1, y, x + lean * 0.8, y - h * 0.8, this.edge);
    L.dl = 16;
  }
}

export class Flash extends Fx {
  constructor(x: number, y: number, public rad: number, public col: Col, public dur = 0.22, public z = 0) { super(); this.x = x; this.y = y; }
  upd(_w: World, _dt: number) { if (this.age > this.dur) this.dead = true; }
  air(g: Gfx) {
    const a = this.age / this.dur, L = g.s, r = this.rad * (1 - a * 0.5);
    const y = this.y - this.z;
    L.dl = Math.round(16 * (1 - a)); L.disc(this.x, y, r * 0.55, P.w); L.dl = Math.round(12 * (1 - a)); L.disc(this.x, y, r * 0.8, this.col);
    L.dl = 16;
  }
  lit(g: Gfx) { glow(g.l, this.x, this.y - this.z, this.rad * 2.2 * (1 - this.age / this.dur * 0.4), this.col, 0.4 * (1 - this.age / this.dur), 5); }
}

export interface RingHit { h: Hits; amt: number; opts: Omit<HitOpts, 'kx' | 'ky'>; knock?: number; stagger?: number; cd?: number; max?: number }
export class Ring extends Fx {
  cur: number; col: [Col, Col, Col];
  constructor(x: number, y: number, public r1: number, public dur: number, public o: { r0?: number; w?: number; cols?: [Col, Col, Col]; hit?: RingHit; fill?: boolean; ease?: number; dust?: boolean } = {}) {
    super(); this.x = x; this.y = y; this.cur = o.r0 ?? 0; this.col = o.cols ?? [P.c3, P.c1, P.e2];
  }
  upd(w: World, _dt: number) {
    const t = clamp(this.age / this.dur, 0, 1), e = 1 - Math.pow(1 - t, this.o.ease ?? 2);
    const prev = this.cur;
    this.cur = (this.o.r0 ?? 0) + (this.r1 - (this.o.r0 ?? 0)) * e;
    const h = this.o.hit;
    if (h) {
      for (const en of w.enemies) {
        if (en.dying > 0) continue;
        const dx = en.x - this.x, dy = en.y - this.y, d = Math.hypot(dx, dy);
        if ((d - en.r <= this.cur && d + en.r >= prev - 4) || (d - en.r <= this.cur && this.o.fill)) {
          if (!h.h.ok(en, w.time, h.cd ?? Infinity, h.max ?? Infinity)) continue;
          const k = h.knock ?? 0, nx = d > 0.1 ? dx / d : 1, ny = d > 0.1 ? dy / d : 0;
          w.hit(en, h.amt, { ...h.opts, kx: nx * k, ky: ny * k, stagger: h.stagger, at: [en.x - nx * en.r, en.y - ny * en.r] });
        }
      }
    }
    if (this.o.dust && Math.floor(this.age * 60) % 2 === 0) {
      const a = w.rng.next() * TAU;
      w.parts.add({ k: 'dust', x: this.x + Math.cos(a) * this.cur, y: this.y + Math.sin(a) * this.cur, z: 1, vx: Math.cos(a) * 12, vy: Math.sin(a) * 12 - 4, max: 0.5, size: 3, c1: P.i3, c2: P.i2 });
    }
    if (this.age >= this.dur) this.dead = true;
  }
  gnd(g: Gfx) {
    const t = this.age / this.dur, L = g.s, w = Math.max(1, (this.o.w ?? 3) * (1 - t * 0.7));
    if (this.o.fill) { L.dl = Math.round(3 * (1 - t)); L.disc(this.x, this.y, this.cur, this.col[2]); L.dl = 16; }
    L.dl = Math.round(16 * (1 - t * t)) || 1;
    L.ring(this.x, this.y, Math.max(0.5, this.cur - 1), w + 1, this.col[2]);
    L.ring(this.x, this.y, this.cur, Math.max(0.8, w - 1), this.col[1]);
    L.ring(this.x, this.y, this.cur + 1, 0.8, this.col[0]);
    L.dl = 16;
  }
  lit(g: Gfx) { const L = g.l; L.add = true; L.a = Math.round(90 * (1 - this.age / this.dur)); L.ring(this.x, this.y, this.cur, 2, this.col[1]); L.add = false; L.a = 255; }
}

// persistent puddle / pool with bubbles
export interface PoolOpts { seed?: number; blobs?: number; grow?: number; tick?: { every: number; amt: number; opts: Omit<HitOpts, 'kx' | 'ky'>; h: Hits; max?: number }; boil?: number; resid?: boolean; flowX?: number; flowY?: number; sinks?: boolean }
export class Pool extends Fx {
  blobs: { dx: number; dy: number; r: number }[] = [];
  nt = 0; seed: number;
  constructor(x: number, y: number, public rad: number, public mat: Mat, public life: number, public o: PoolOpts = {}) {
    super(); this.x = x; this.y = y; this.sy = y; this.seed = o.seed ?? Math.floor(hash(x * 13 + y) * 1000); this.resid = o.resid !== false; this.kind = 'pool'; this.r = rad;
    const r = new Rng(this.seed + 5), n = o.blobs ?? 5;
    this.blobs.push({ dx: 0, dy: 0, r: rad * 0.62 });
    for (let i = 0; i < n; i++) { const a = r.range(0, TAU), d = rad * r.range(0.25, 0.62); this.blobs.push({ dx: Math.cos(a) * d, dy: Math.sin(a) * d * 0.9, r: rad * r.range(0.28, 0.5) }); }
  }
  upd(w: World, dt: number) {
    const o = this.o;
    if (this.age > this.life) { this.dead = true; return; }
    const gs = smooth(this.age / (o.grow ?? 0.3));
    if (o.boil && w.rng.next() < o.boil * dt * 60 * 0.1) {
      const a = w.rng.range(0, TAU), d = w.rng.range(0, this.rad * 0.7 * gs);
      w.parts.add({ k: 'bubble', x: this.x + Math.cos(a) * d, y: this.y + Math.sin(a) * d * 0.8, z: 0, vz: w.rng.range(5, 12), max: w.rng.range(0.4, 0.9), size: w.rng.range(1.5, 3.2), c1: this.mat.ramp[3], c2: this.mat.rim, c3: this.mat.hi });
    }
    if (o.tick) {
      this.nt -= dt;
      if (this.nt <= 0 && gs > 0.6) {
        this.nt += o.tick.every;
        for (const e of w.enemies) {
          if (e.dying > 0) continue;
          if (Math.hypot(e.x - this.x, (e.y - this.y) * 1.1) < this.rad * 0.85 * gs + e.r * 0.6 && o.tick.h.ok(e, w.time, o.tick.every * 0.8, o.tick.max ?? Infinity))
            w.hit(e, o.tick.amt, { ...o.tick.opts, at: [e.x, e.y] });
        }
      }
    }
  }
  gnd(g: Gfx) {
    const gs = smooth(this.age / (this.o.grow ?? 0.3)), rem = this.life - this.age;
    const f = g.f; f.reset();
    const sh = rem < 1 ? 0 : 1;
    for (const b of this.blobs) f.disc(this.x + b.dx * gs, this.y + b.dy * gs, b.r * gs * (1 + Math.sin(g.t * 3 + b.dx) * 0.03), 0.25);
    const dl = rem < 1 ? Math.max(2, Math.round(16 * rem)) : sh ? 16 : 16;
    f.shade(g.s, this.mat, g.t, { seed: this.seed, fx: this.o.flowX ?? this.mat.fx, fy: this.o.flowY ?? this.mat.fy, dl });
  }
  lit(g: Gfx) { const gs = smooth(this.age / (this.o.grow ?? 0.3)); const rem = this.life - this.age; glow(g.l, this.x, this.y, this.rad * 1.3 * gs, this.mat.ramp[3], 0.18 * clamp(rem, 0, 1), 3); }
}

// ---------------- glowing decals ----------------
export type DecalKind = 'pits' | 'cracks' | 'veins' | 'crater' | 'crescent' | 'scorch';
interface DPx { x: number; y: number; c: Col; g: number }
export class Decal extends Fx {
  pxs: DPx[] = [];
  glowCol: Col;
  constructor(x: number, y: number, kind: DecalKind, public size: number, public life: number, seed: number, public cols: { a: Col; b: Col; c: Col }, ang = 0, public pulse = 1.2) {
    super(); this.x = x; this.y = y; this.glowCol = cols.c;
    const r = new Rng(seed * 7 + 3);
    const push = (px: number, py: number, c: Col, g = -1) => this.pxs.push({ x: px, y: py, c, g });
    if (kind === 'veins') {
      const branch = (bx: number, by: number, a: number, len: number, depth: number, d0: number) => {
        let x0 = bx, y0 = by, a0 = a;
        for (let i = 0; i < len; i++) {
          a0 += r.range(-0.45, 0.45); x0 += Math.cos(a0); y0 += Math.sin(a0) * 0.9;
          const g = d0 + i;
          push(x0 + 1, y0, cols.a); push(x0, y0 + 1, cols.a); push(x0 - 1, y0, cols.a);
          push(x0, y0, cols.b, g);
          if (depth < 3 && i > 3 && r.next() < 0.12) branch(x0, y0, a0 + r.sign() * r.range(0.6, 1.2), Math.floor(len * 0.55), depth + 1, g);
        }
      };
      const n = 4 + Math.floor(size / 14);
      for (let i = 0; i < n; i++) branch(0, 0, (i / n) * TAU + r.range(-0.3, 0.3), Math.floor(size * r.range(0.5, 1)), 0, 0);
      this.pxs.sort((p, q) => (p.g < 0 ? 0 : 1) - (q.g < 0 ? 0 : 1));
    } else if (kind === 'cracks') {
      const n = 5 + Math.floor(size / 10);
      for (let i = 0; i < n; i++) {
        let x0 = 0, y0 = 0, a0 = (i / n) * TAU + r.range(-0.3, 0.3);
        const len = size * r.range(0.4, 1);
        for (let k = 0; k < len; k++) { a0 += r.range(-0.4, 0.4); x0 += Math.cos(a0); y0 += Math.sin(a0) * 0.9; push(x0, y0, cols.a); if (k % 3 === 0) push(x0 + 1, y0 + 1, cols.b); if (k % 7 === 0) push(x0, y0, cols.c, k); }
      }
    } else if (kind === 'pits') {
      const n = Math.floor(size * 0.9);
      for (let i = 0; i < n; i++) {
        const a = r.range(0, TAU), d = Math.sqrt(r.next()) * size, pr = r.range(0.8, 2.4);
        const px = Math.cos(a) * d, py = Math.sin(a) * d * 0.9;
        for (let dy = -2; dy <= 2; dy++) for (let dx = -3; dx <= 3; dx++) { const q = Math.hypot(dx / 1.3, dy) ; if (q < pr) push(px + dx, py + dy, cols.a); else if (q < pr + 1) push(px + dx, py + dy, cols.b, r.next() < 0.3 ? i * 3 : -1); }
      }
    } else if (kind === 'crater') {
      for (let a = 0; a < TAU; a += 0.04) {
        const rr = size * (0.92 + hash(Math.floor(a * 9) + seed) * 0.12);
        push(Math.cos(a) * rr, Math.sin(a) * rr * 0.85 - 1, cols.b); push(Math.cos(a) * (rr + 1.4), Math.sin(a) * (rr + 1.4) * 0.85 - 1, a > 3.5 && a < 5.6 ? cols.c : cols.b);
        push(Math.cos(a) * (rr - 1.3), Math.sin(a) * (rr - 1.3) * 0.85, cols.a);
      }
      for (let i = 0; i < size * 1.4; i++) { const a = r.range(0, TAU), d = r.range(size * 0.2, size * 0.88); push(Math.cos(a) * d, Math.sin(a) * d * 0.85, i % 4 === 0 ? cols.c : cols.a, i % 4 === 0 ? i * 2 : -1); }
    } else if (kind === 'crescent') {
      for (let k = -1; k <= 1; k++) for (let a = -1.15; a <= 1.15; a += 0.03) {
        const rr = size + k * 1.1 + Math.cos(a * 1.3) * 0;
        const c = k === 0 ? cols.c : k < 0 ? cols.b : cols.a;
        const px = Math.cos(a + ang) * rr, py = Math.sin(a + ang) * rr * 0.9;
        const thick = (1 - Math.abs(a) / 1.3) * 2.3;
        for (let t = 0; t < thick; t++) push(px - Math.cos(a + ang) * t * 0.9, py - Math.sin(a + ang) * t * 0.9, c, k === 0 ? Math.round((a + 1.2) * 20) : -1);
      }
    } else if (kind === 'scorch') {
      for (let i = 0; i < size * 2.4; i++) { const a = r.range(0, TAU), d = Math.sqrt(r.next()) * size; push(Math.cos(a) * d, Math.sin(a) * d * 0.85, i % 9 === 0 ? cols.b : cols.a); }
    }
  }
  upd(_w: World, _dt: number) { if (this.age > this.life) this.dead = true; }
  gnd(g: Gfx) {
    const rem = this.life - this.age, vis = clamp(this.age / 0.12, 0, 1);
    const L = g.s, fade = rem < 1.2 ? rem / 1.2 : 1;
    const t = g.t * 22 * this.pulse;
    for (let i = 0; i < this.pxs.length; i++) {
      const p = this.pxs[i];
      if (fade < 1 && hash(i * 3 + 7) > fade) continue;
      if (vis < 1 && hash(i * 5 + 1) > vis) continue;
      let c = p.c;
      if (p.g >= 0) { const ph = ((t - p.g) % 44 + 44) % 44; if (ph < 7) c = ph < 2.5 ? P.w : mix(this.cols.b, P.w, 0.5); }
      L.dot(this.x + p.x, this.y + p.y, c);
    }
  }
  lit(g: Gfx) {
    const rem = this.life - this.age, fade = rem < 1.2 ? rem / 1.2 : 1;
    const L = g.l; L.add = true; L.a = Math.round(60 * fade); const t = g.t * 22 * this.pulse;
    for (let i = 0; i < this.pxs.length; i += 2) { const p = this.pxs[i]; if (p.g < 0) continue; const ph = ((t - p.g) % 44 + 44) % 44; if (ph < 7) L.dot(this.x + p.x, this.y + p.y, this.glowCol); }
    L.add = false; L.a = 255;
  }
}

// ---------------- billowing volumetric vapor ----------------
export function puff(L: Layer, cx: number, cy: number, r: number, ramp: Col[], dl: number, t: number, seed: number, outline = false) {
  const k = L.k;
  const gcx = Math.round(cx * k), gcy = Math.round(cy * k), gr = r * k;
  const ri = Math.ceil(gr), R = gr + 0.4, sd = L.dl;
  for (let dy = -ri; dy <= ri; dy++) for (let dx = -ri; dx <= ri; dx++) {
    const q = (dx * dx + dy * dy) / (R * R);
    if (q > 1) continue;
    const gx = gcx + dx, gy = gcy + dy;
    const wx = gx / k, wy = gy / k;
    const n = nz1(wx * 0.22 + seed * 7 + t * 2.2, wy * 0.22 + t * 1.3) / 255, n2 = nz2(wx * 0.5 - t * 3 + seed, wy * 0.5) / 255;
    const s = -(dx / R) * 0.55 - (dy / R) * 0.65 + (n - 0.5) * 0.9 + (n2 - 0.5) * 0.3 - q * 0.3;
    const idx = s < -0.45 ? 0 : s < -0.05 ? 1 : s < 0.38 ? 2 : 3;
    const keep = dl * (1 - q * q * 0.75) + (n2 - 0.5) * 4;
    if (BAYER[((gy & 3) << 2) | (gx & 3)] >= keep) continue;
    L.dl = 16;
    L.rawPx(gx, gy, outline && q > 0.8 ? ramp[0] : ramp[Math.min(idx, ramp.length - 1)]);
  }
  L.dl = sd;
}

export interface Puff { x: number; y: number; r: number; ph: number; sp: number; orb: number; sq?: number; lay?: number }
export class Cloud extends Fx {
  vx = 0; vy = 0; fade = 1; dens = 11; nt = 0; shrink = 1; heightOff = 0; grow?: { from: number; to: number; dur: number };
  tickInfo?: { every: number; amt: number; opts: Omit<HitOpts, 'kx' | 'ky'>; h: Hits; max?: number; rad?: number; mark?: string; poison?: [number, number, number] };
  constructor(x: number, y: number, public puffs: Puff[], public ramp: Col[], public life: number, public seed = 1) { super(); this.x = x; this.y = y; this.sy = y; this.kind = 'cloud'; this.resid = true; }
  pos(p: Puff, t: number) {
    const a = p.ph + t * p.sp;
    return { x: this.x + (p.x + Math.cos(a) * p.orb) * this.shrink, y: this.y + (p.y + Math.sin(a) * p.orb * (p.sq ?? 0.6)) * this.shrink };
  }
  upd(w: World, dt: number) {
    this.x += this.vx * dt; this.y += this.vy * dt;
    if (this.grow) this.shrink = lerp(this.grow.from, this.grow.to, smooth(this.age / this.grow.dur));
    if (this.age > this.life) { this.dead = true; return; }
    const ti = this.tickInfo;
    if (ti) {
      this.nt -= dt;
      if (this.nt <= 0) {
        this.nt += ti.every;
        for (const e of w.enemies) {
          if (e.dying > 0 || !this.covers(e.x, e.y, e.r * 0.5)) continue;
          if (ti.mark) w.mark(e, ti.mark as 'miasma', ti.every * 2.2);
          if (ti.h.ok(e, w.time, ti.every * 0.9, ti.max ?? Infinity)) w.hit(e, ti.amt, { ...ti.opts, at: [e.x, e.y] });
        }
      }
    }
  }
  covers(x: number, y: number, pad = 0): boolean {
    const t = this.age;
    for (const p of this.puffs) { const q = this.pos(p, t); if (Math.hypot(x - q.x, (y - q.y)) < p.r * this.shrink * 0.85 * this.fade + pad) return true; }
    return false;
  }
  air(g: Gfx) {
    const L = g.s, t = this.age;
    const list = this.puffs.map((p, i) => { const q = this.pos(p, t); return { p, q, i, d: Math.sin(p.ph + t * p.sp) * 0.5 + (p.lay ?? 0) }; });
    list.sort((a, b) => a.d - b.d);
    const rem = this.life - this.age, f = rem < 1.2 ? rem / 1.2 : 1;
    for (const o of list) {
      const rr = o.p.r * this.shrink * (0.9 + 0.1 * Math.sin(t * 2 + o.i)) * (0.4 + 0.6 * f) * Math.min(1, this.age * 2.2 + 0.2);
      if (rr < 1.5) continue;
      puff(L, o.q.x, o.q.y - this.heightOff, rr, this.ramp, this.dens * f * this.fade, g.t, this.seed + o.i);
    }
  }
  lit(g: Gfx) { const rem = this.life - this.age; glow(g.l, this.x, this.y, this.puffs.reduce((m, p) => Math.max(m, Math.hypot(p.x, p.y) + p.r), 10) * 0.8, this.ramp[3], 0.1 * clamp(rem, 0, 1), 2); }
}

// ---------------- projectiles ----------------
export class Proj extends Fx {
  x0: number; y0: number; z = 0;
  constructor(x: number, y: number, public tx: number, public ty: number, public dur: number, public arc: number,
    public draw: (g: Gfx, x: number, y: number, z: number, a: number, p: Proj) => void,
    public onEnd: (w: World, p: Proj) => void, public onTick?: (w: Proj['_w'], p: Proj, a: number) => void, public shadow = 2) {
    super(); this.x = x; this.y = y; this.x0 = x; this.y0 = y; this.kind = 'proj';
  }
  _w!: World;
  upd(w: World, _dt: number) {
    const a = clamp(this.age / this.dur, 0, 1);
    this.x = lerp(this.x0, this.tx, a); this.y = lerp(this.y0, this.ty, a);
    this.z = 4 * this.arc * a * (1 - a) + 6;
    this.onTick?.(w, this, a);
    if (a >= 1) { this.dead = true; this.z = 0; this.onEnd(w, this); }
  }
  air(g: Gfx) {
    const a = clamp(this.age / this.dur, 0, 1), L = g.s;
    L.dl = 6; L.ellipse(this.x, this.y, this.shadow, this.shadow * 0.6, P.bk); L.dl = 16;
    this.draw(g, this.x, this.y - this.z, this.z, a, this);
  }
}

// ballistic shot with real collision
export class Shot extends Fx {
  z: number; vx: number; vy: number; vz: number; hitsDone = new Set<number>();
  constructor(x: number, y: number, z: number, vx: number, vy: number, vz: number, public grav: number, public hr: number,
    public drawFn: (g: Gfx, x: number, y: number, z: number, s: Shot) => void,
    public onHit: ((w: World, s: Shot, e: Enemy) => boolean) | null, public onLand: ((w: World, s: Shot) => void) | null, public life = 3, public hz = 12, public trailFn?: (w: World, s: Shot) => void) {
    super(); this.x = x; this.y = y; this.z = z; this.vx = vx; this.vy = vy; this.vz = vz; this.kind = 'shot';
  }
  upd(w: World, dt: number) {
    this.vz -= this.grav * dt; this.x += this.vx * dt; this.y += this.vy * dt; this.z += this.vz * dt;
    this.trailFn?.(w, this);
    if (this.onHit && this.z < this.hz) {
      for (const e of w.enemies) {
        if (e.dying > 0 || this.hitsDone.has(e.id)) continue;
        if (Math.hypot(e.x - this.x, e.y - this.y) < e.r + this.hr) { this.hitsDone.add(e.id); if (this.onHit(w, this, e)) { this.dead = true; return; } }
      }
    }
    if (this.z <= 0 && this.vz < 0) { this.dead = true; this.z = 0; this.onLand?.(w, this); return; }
    if (this.age > this.life) this.dead = true;
  }
  air(g: Gfx) {
    const L = g.s; L.dl = 6; L.ellipse(this.x, this.y, 2, 1, P.bk); L.dl = 16;
    this.drawFn(g, this.x, this.y - this.z, this.z, this);
  }
}

export class Custom extends Fx {
  constructor(x: number, y: number, public life: number, public fns: { gnd?: (g: Gfx, a: number, f: Custom) => void; up?: (g: Gfx, a: number, f: Custom) => void; air?: (g: Gfx, a: number, f: Custom) => void; lit?: (g: Gfx, a: number, f: Custom) => void; upd?: (w: World, dt: number, f: Custom) => void }, sy?: number) {
    super(); this.x = x; this.y = y; this.sy = sy ?? y; this.kind = 'custom';
  }
  upd(w: World, dt: number) { this.fns.upd?.(w, dt, this); if (this.age >= this.life) this.dead = true; }
  gnd(g: Gfx) { this.fns.gnd?.(g, this.age / this.life, this); }
  up(g: Gfx) { this.fns.up?.(g, this.age / this.life, this); }
  air(g: Gfx) { this.fns.air?.(g, this.age / this.life, this); }
  lit(g: Gfx) { this.fns.lit?.(g, this.age / this.life, this); }
}

// ---------------- segmented body helper ----------------
export class Chain {
  s: { x: number; y: number }[] = [];
  constructor(x: number, y: number, public n: number, public gap: number, ang = 0) {
    for (let i = 0; i < n; i++) this.s.push({ x: x - Math.cos(ang) * gap * i, y: y - Math.sin(ang) * gap * i });
  }
  move(x: number, y: number) {
    this.s[0].x = x; this.s[0].y = y;
    for (let i = 1; i < this.n; i++) {
      const a = this.s[i - 1], b = this.s[i];
      const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1;
      b.x = a.x + (dx / d) * this.gap; b.y = a.y + (dy / d) * this.gap;
    }
  }
}

// ---------------- burst helpers ----------------
export function drops(w: World, x: number, y: number, n: number, sp: number, c1: Col, c2: Col, c3: Col, o: { z?: number; size?: [number, number]; up?: number; land?: number; glow?: number; max?: number; ang?: number; spread?: number } = {}) {
  for (let i = 0; i < n; i++) {
    const a = o.ang !== undefined ? o.ang + (w.rng.next() - 0.5) * (o.spread ?? TAU) : w.rng.next() * TAU, s = sp * (0.35 + w.rng.next() * 0.65);
    w.parts.add({ k: 'drop', x, y, z: o.z ?? 2, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.85, vz: (o.up ?? 60) * (0.4 + w.rng.next() * 0.9), grav: 230, size: w.rng.range(o.size?.[0] ?? 1.2, o.size?.[1] ?? 3), c1, c2, c3, land: o.land ?? 1, max: o.max ?? 2, glow: o.glow ?? 0, trail: 1 });
  }
}
export function shards(w: World, x: number, y: number, n: number, sp: number, c1: Col, c2: Col, c3: Col, o: { z?: number; size?: [number, number]; up?: number; land?: number; ang?: number; spread?: number } = {}) {
  for (let i = 0; i < n; i++) {
    const a = o.ang !== undefined ? o.ang + (w.rng.next() - 0.5) * (o.spread ?? TAU) : w.rng.next() * TAU, s = sp * (0.3 + w.rng.next() * 0.7);
    w.parts.add({ k: 'shard', x, y, z: o.z ?? 3, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.85, vz: (o.up ?? 70) * (0.4 + w.rng.next()), grav: 240, size: w.rng.range(o.size?.[0] ?? 3, o.size?.[1] ?? 6), rot: w.rng.range(0, TAU), vr: w.rng.range(-12, 12), c1, c2, c3, land: o.land ?? 2, max: 3 });
  }
}
export function chips(w: World, x: number, y: number, n: number, sp: number, c1: Col, c2: Col, c3: Col, o: { z?: number; size?: [number, number]; up?: number; ang?: number; spread?: number } = {}) {
  for (let i = 0; i < n; i++) {
    const a = o.ang !== undefined ? o.ang + (w.rng.next() - 0.5) * (o.spread ?? TAU) : w.rng.next() * TAU, s = sp * (0.3 + w.rng.next() * 0.7);
    w.parts.add({ k: 'chip', x, y, z: o.z ?? 3, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.85, vz: (o.up ?? 80) * (0.4 + w.rng.next()), grav: 260, size: w.rng.range(o.size?.[0] ?? 1.8, o.size?.[1] ?? 3.8), rot: w.rng.range(0, 3), vr: w.rng.range(-14, 14), c1, c2, c3, land: 3, max: 3.5 });
  }
}
export function steam(w: World, x: number, y: number, n: number, sp: number, c1: Col, c2: Col, size = 4, o: { z?: number; vz?: number; max?: number } = {}) {
  for (let i = 0; i < n; i++) {
    const a = w.rng.next() * TAU, s = sp * w.rng.next();
    w.parts.add({ k: 'steam', x, y, z: o.z ?? 2, vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.7, vz: (o.vz ?? 14) * (0.5 + w.rng.next()), size: size * (0.7 + w.rng.next() * 0.6), max: (o.max ?? 0.9) * (0.7 + w.rng.next() * 0.6), c1, c2, drag: 1.5 });
  }
}
export function dust(w: World, x: number, y: number, n: number, sp: number, size = 4) { steam(w, x, y, n, sp, P.i3, P.i2, size, { vz: 4, max: 0.6 }); }
