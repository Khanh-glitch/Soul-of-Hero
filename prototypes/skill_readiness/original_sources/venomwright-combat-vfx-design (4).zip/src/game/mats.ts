import { P, hex, pal, type Col, type Mat } from './pixel';

const B = { vw: 0, hiT: 0.35, hiW: 5, dl: 16 };
export const MAT: Record<'acid' | 'venom' | 'leech' | 'verd' | 'merc' | 'bile' | 'rot' | 'brine' | 'magenta' | 'ink', Mat> = {
  acid: { ...B, outline: P.k0, rim: P.c1, rimLit: P.c3, ramp: [P.e0, P.e1, P.e2, P.e3, P.c0, P.c1], hi: P.c3, sh: P.e0, vein: P.c2, vw: 5, dep: 7, sc: 0.17, fx: 7, fy: 3, amp: 0.55, hiT: 0.3 },
  venom: { ...B, outline: P.k0, rim: P.e3, rimLit: P.c1, ramp: [P.k0, P.k1, P.e0, P.e1, P.e2, P.e3], hi: P.c0, sh: P.k0, vein: P.c0, vw: 4, dep: 8, sc: 0.15, fx: 5, fy: 2, amp: 0.6, hiT: 0.3 },
  leech: { ...B, outline: P.k0, rim: P.n3, rimLit: P.y0, ramp: [P.k0, P.n0, P.n1, P.n2, P.n3, P.v0, P.e1], hi: P.y1, sh: P.k0, vein: P.y0, vw: 3, dep: 6, sc: 0.2, fx: 9, fy: 2, amp: 0.55, hiT: 0.3 },
  verd: { ...B, outline: P.k0, rim: P.v2, rimLit: P.v3, ramp: [P.e0, P.e1, P.v0, P.v1, P.v2, P.g1, P.g2], hi: P.v3, sh: P.e0, vein: P.g2, vw: 5, dep: 7, sc: 0.15, fx: 8, fy: 4, amp: 0.7, hiT: 0.3 },
  merc: { ...B, outline: hex('#06181a'), rim: P.y1, rimLit: P.w, ramp: [hex('#0a2a2c'), hex('#15484a'), hex('#3c8582'), hex('#8fc9c3'), hex('#d6fff8')], hi: P.w, sh: hex('#06181a'), vein: 0, vw: 0, dep: 4, sc: 0.12, fx: 4, fy: 2, amp: 0.3, hiT: 0.15, hiW: 6 },
  bile: { ...B, outline: P.e0, rim: P.c3, rimLit: P.w, ramp: [P.g0, P.g1, P.g2, P.c2, P.c3], hi: P.w, sh: P.g0, vein: P.c3, vw: 3, dep: 6, sc: 0.14, fx: 3, fy: 2, amp: 0.5, hiT: 0.3 },
  rot: { ...B, outline: P.k0, rim: P.e1, rimLit: P.c0, ramp: [P.k0, P.k1, P.n0, P.e0, P.n1, P.e1], hi: P.c0, sh: P.k0, vein: P.m1, vw: 3, dep: 7, sc: 0.16, fx: 4, fy: 2, amp: 0.6, hiT: 0.3 },
  brine: { ...B, outline: P.k0, rim: P.v1, rimLit: P.v3, ramp: [P.k0, P.k1, P.n0, P.v0, P.e0, P.v1], hi: P.v3, sh: P.k0, vein: P.y1, vw: 3, dep: 6, sc: 0.18, fx: 10, fy: 1, amp: 0.6, hiT: 0.3 },
  magenta: { ...B, outline: P.k0, rim: P.m2, rimLit: P.w, ramp: [P.n0, P.m0, P.m1, P.m2, P.c2], hi: P.w, sh: P.n0, vein: P.c2, vw: 3, dep: 6, sc: 0.16, fx: 6, fy: 3, amp: 0.6, hiT: 0.3 },
  ink: { ...B, outline: P.k0, rim: P.n2, rimLit: P.v1, ramp: [P.k0, P.k0, P.k1, P.n0, P.n1], hi: P.n3, sh: P.k0, vein: P.e2, vw: 2, dep: 6, sc: 0.2, fx: 6, fy: 2, amp: 0.5, hiT: 0.4 },
};

export const VAP: Record<'green' | 'dark' | 'pale' | 'steam' | 'dust' | 'indigo' | 'gold', Col[]> = {
  green: [P.e0, P.e1, P.e2, P.c0],
  dark: [P.k0, P.k1, P.e0, P.e1],
  pale: [P.e2, P.c0, P.c2, P.c3],
  steam: [P.v0, P.v2, P.v3, P.y2],
  dust: [P.i3, P.i2, P.i1, P.i0],
  indigo: [P.n0, P.n1, P.n2, P.n3],
  gold: [P.g0, P.g1, P.c2, P.g2],
};

export const PAL = {
  glass: pal(hex('#0b2d2e'), P.v0, P.v1, P.v2, P.v3),
  glassHi: pal(hex('#0b2d2e'), P.v1, P.v2, P.v3, P.y2),
  chitin: pal(P.k0, P.n1, P.n2, P.n3, P.c1),
  chitinHot: pal(P.k0, hex('#2a1d12'), hex('#6a4a1c'), P.g1, P.g2),
  cer: pal(hex('#26242e'), P.i2, P.i1, P.i0, P.w),
  cerB: pal(P.n0, hex('#2f3f80'), hex('#4f6bc0'), hex('#9fb8f0'), P.w),
  copper: pal(P.u0, P.u0, P.u1, P.u2, P.g2),
  toad: pal(P.k0, P.e0, P.e1, P.e2, P.c1),
  toadSac: pal(P.e0, hex('#8fb04a'), hex('#c8d878'), hex('#eef2b0'), P.w),
  leech: pal(P.k0, P.n0, P.n1, P.m0, P.m2),
  seed: pal(hex('#3a3326'), P.i2, P.i1, P.i0, P.w),
  liquid: pal(P.k0, P.e1, P.e3, P.c1, P.c3),
  gold: pal(P.u0, P.g0, P.g1, P.g2, P.w),
  merc: pal(hex('#06181a'), hex('#15484a'), hex('#4c8f8a'), hex('#b5e6df'), P.w),
  rot: pal(P.k0, P.k1, P.e0, P.e1, P.c0),
  crys: pal(hex('#0b2d3a'), P.v0, P.y0, P.y1, P.y2),
  iron: pal(P.k0, hex('#3a3a46'), hex('#5d5d70'), hex('#8d8da3'), P.w),
  imp: pal(hex('#1a0b10'), P.r0, P.r1, P.r2, P.r3),
  crab: pal(hex('#1a0f08'), P.u0, P.u1, P.u2, P.g2),
  bone: pal(hex('#14110d'), P.i3, P.i2, P.i1, P.i0),
  hood: pal(hex('#0b0a10'), hex('#1b1a28'), hex('#2b2940'), hex('#46436a'), hex('#7a76b0')),
  stone: pal(P.k0, hex('#2a2420'), hex('#4a403a'), hex('#7a6a5a'), P.i1),
  brute: pal(hex('#150808'), P.r0, hex('#7a2b2b'), hex('#b0473a'), P.r3),
};
