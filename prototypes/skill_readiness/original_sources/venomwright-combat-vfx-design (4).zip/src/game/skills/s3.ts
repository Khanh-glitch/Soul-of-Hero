import { Cloud, Custom, Decal, Embed, Flash, Fx, Hits, Pool, Proj, Ring, Shot, Splash, chips, drops, dust, shards, steam, type Gfx } from '../fx';
import { P, TAU, ball, bubble, clamp, crystalPrism, glow, hash, lerp, mix, pal, shard, smooth, wormBody, type Col, type Seg } from '../pixel';
import { MAT, PAL, VAP } from '../mats';
import type { Enemy, World } from '../world';
import { F, FlowNet, castAnim, handPos, hitE, mkBranch, mkPuffs, ringAt, throwArc, ticks, visRing, wavyPath, type Cast, type SkillDef } from './lib';
import { plume } from './s2';

const alive = (e: Enemy | null | undefined): e is Enemy => !!e && e.dying <= 0;
function hxn(n: number): Col { return (0xff000000 | ((n & 255) << 16) | (n & 0xff00) | ((n >> 16) & 255)) >>> 0; }

// =============== 11 UNSEALED CATALYST ===============
function* catalyst(c: Cast) {
  const w = c.w, p = w.player;
  p.cast = 0.5; p.castMax = 0.5;
  w.add(new Custom(p.x, p.y, 0.47, {
    air: (g, a) => {
      const L = g.s, t = g.t, x = p.x + 1, y = p.y - 26 - Math.sin(a * 3) * 1.5, k = a;
      ball(L, x, y, 7, PAL.glassHi, 7);
      // fluid rotating against the container
      L.dl = 16; ball(L, x, y + 1, 5, PAL.liquid, 4.5);
      const ang = -t * 9; for (let i = 0; i < 3; i++) { const aa = ang + i * 2.1; L.disc(x + Math.cos(aa) * 3, y + 1 + Math.sin(aa) * 2.6, 0.9, i === 0 ? P.w : P.c2); }
      L.arc(x, y + 1, 3.6, 1, ang, ang + 1.6, P.c3, 3.2);
      L.arc(x, y, 6, 1, t * 3, t * 3 + 1.2, P.w);
      for (let i = 0; i < 4; i++) { const aa = t * 2 + i * 1.57; shard(L, x + Math.cos(aa) * 8, y - 9 + Math.sin(aa) * 2, aa + 1, 3.2, 1, P.y2, P.v1, P.w); }
      // luminous strands assembling into a pattern
      const n = 6, rad = 13;
      for (let i = 0; i < n; i++) { const a0 = (i / n) * TAU + t, a1 = ((i + 2) / n) * TAU + t; if (i / n < k * 1.3) L.line(x + Math.cos(a0) * rad, y + Math.sin(a0) * rad * 0.8, x + Math.cos(a1) * rad, y + Math.sin(a1) * rad * 0.8, P.c1); L.disc(x + Math.cos(a0) * rad, y + Math.sin(a0) * rad * 0.8, 1, i / n < k * 1.3 ? P.c3 : P.e3); }
      L.rect(Math.round(x) - 2, Math.round(y) - 9, 5, 2, P.u1); L.px(Math.round(x), Math.round(y) - 10, P.u2);
    },
    lit: (g, a) => glow(g.l, p.x, p.y - 26, 12 + a * 10, P.c1, 0.3 + a * 0.3, 4),
  }));
  yield 0.45;
  // seal breaks
  w.add(new Flash(p.x, p.y - 26, 22, P.w, 0.3, 0)); w.screenFlash(P.c2, 0.4, 0.2); w.shake(3, 0.3);
  p.form = 'venom'; p.venomT = 14; p.cat = 0;
  shards(w, p.x, p.y - 26, 12, 90, P.v2, P.v1, P.y2, { z: 26, up: 40, land: 3, size: [2, 4] }); drops(w, p.x, p.y - 26, 20, 80, P.c1, P.c3, P.e2, { z: 26, up: 60, glow: 2 });
  // existing summons / residues react to the release
  for (const f of w.fx) { if (f.kind === 'summon') { w.add(new Flash(f.x, f.y - 10, 16, P.c1, 0.6, 6)); w.add(new Ring(f.x, f.y, 18, 0.5, { w: 2, cols: [P.c3, P.c1, P.e2] })); } else if (f.resid) w.add(new Flash(f.x, f.y, 8, P.c2, 0.45)); }
  const pulse = new Hits();
  // translucent sheets rise and wrap the body
  const dur = 0.85;
  w.add(new Custom(p.x, p.y, dur, {
    air: (g, a) => {
      const L = g.s, t = g.t, rise = smooth(Math.min(1, a * 1.3)), con = smooth(clamp((a - 0.65) / 0.35, 0, 1));
      for (let r = 0; r < 3; r++) {
        const pts: Seg[] = [];
        for (let i = 0; i < 18; i++) { const u = i / 17, an = r * 2.09 + u * 5.5 + t * 7, rad = (9 + 4 * Math.sin(u * 3 + t * 5)) * (1 - con * 0.85), h = u * (8 + 30 * rise) * (1 - con * 0.5); pts.push({ x: p.x + Math.cos(an) * rad, y: p.y - 3 - h + Math.sin(an) * rad * 0.45, r: (2.6 - u * 1.2) * (1 - con * 0.4) }); }
        L.dl = 12; wormBody(L, pts, PAL.liquid, { stripe: P.c3, stripeT: t + r }); L.dl = 16;
      }
    },
    lit: (g, a) => glow(g.l, p.x, p.y - 10, 22 + a * 8, P.c1, 0.4, 4),
  }));
  yield 0.32;
  // contraction, then eruption
  yield 0.12;
  w.screenFlash(P.w, 0.55, 0.2); w.shake(6, 0.45); w.shock(p.x, p.y, 100, 0.5, 4.5);
  ringAt(c, p.x, p.y, 92, 0.45, 80, { kind: 'acid', knock: 150, stag: 0.4, h: pulse, cols: [P.w, P.c1, P.e2], w: 5, dust: false });
  visRing(w, p.x, p.y, 60, 0.38, [P.c3, P.c0, P.e1], 3);
  w.add(new Flash(p.x, p.y - 8, 40, P.c3, 0.4, 8));
  w.add(new Decal(p.x, p.y, 'veins', 82, 14, c.id, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.4));
  w.add(new Decal(p.x - 36, p.y + 14, 'veins', 36, 13, c.id + 1, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.4)); w.add(new Decal(p.x + 40, p.y - 12, 'veins', 36, 13, c.id + 2, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.4));
  for (let i = 0; i < 28; i++) { const a = c.rng.range(0, TAU), d = c.rng.range(8, 78); w.parts.add({ k: 'bubble', x: p.x + Math.cos(a) * d, y: p.y + Math.sin(a) * d * 0.8, z: 0, vz: c.rng.range(10, 34), max: c.rng.range(0.6, 1.8), size: c.rng.range(2, 5), c1: P.e3, c2: P.c1, c3: P.c3, glow: 0 }); }
  drops(w, p.x, p.y, 30, 120, P.c1, P.c3, P.e2, { z: 8, up: 120, glow: 2, size: [1, 3] });
  for (let i = 0; i < 6; i++) steam(w, p.x + c.rng.range(-14, 14), p.y + c.rng.range(-6, 6), 1, 14, P.e1, P.c0, 5, { z: 4, vz: 18, max: 1.4 });
  yield 0.9;
}

// =============== 12 VERDIGRIS WAKE ===============
function* wake(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c);
  const dx = Math.cos(c.ang), dy = Math.sin(c.ang);
  yield 0.04;
  const [hx, hy] = handPos(w), ix = clamp(p.x + dx * 48, 12, w.W - 12), iy = clamp(p.y + dy * 48, 14, w.H - 12);
  throwArc(w, 'vial', hx, hy, ix, iy, 0.1, 6, () => 0, 22);
  yield 0.1;
  w.add(new Splash(ix, iy, 8, P.v2, P.c3)); w.add(new Flash(ix, iy - 3, 10, P.v3, 0.2, 3)); shards(w, ix, iy, 6, 70, P.v2, P.v1, P.y2, { z: 4, land: 3, size: [2, 3] });
  const net = new FlowNet(MAT.verd, 5.4), tickH = new Hits(), front = new Hits(), burst = new Hits(), vap = new Hits();
  const mainPts = wavyPath(ix, iy, c.ang, 150, 0.3, 7, c.id, 0.002 * c.rng.sign());
  const main = net.add(mkBranch(mainPts, 5, 0, 320, 1));
  const sides: ReturnType<typeof mkBranch>[] = [];
  [[38, 0.8, 70], [70, -0.9, 80], [100, 0.75, 62], [125, -0.7, 54]].forEach(([d, a, len], i) => {
    const q = net.pointAt(main, d); const b = mkBranch(wavyPath(q.x, q.y, q.ang + a, len, 0.4, 7, c.id + i + 3), 3.4, d / 320 + 0.04, 270, i + 2); sides.push(b); net.add(b);
    if (i === 0) { const q2 = net.pointAt(b, 40); net.add(mkBranch(wavyPath(q2.x, q2.y, q2.ang - 0.8, 36, 0.4, 6, c.id + 40), 2.4, d / 320 + 0.2, 220, 9)); }
  });
  net.tick = { every: 0.5, amt: c.d(25), opts: { kind: 'acid', src: c.def.id, stagger: 0.1 }, h: tickH, max: 2, mark: 'corrode', markDur: 2.6 };
  net.onTouch = (ww, e) => { if (front.ok(e, ww.time)) { hitE(c, e, 70, { kind: 'acid', k: 100, from: [ix, iy], stag: 0.3, at: [e.x, e.y] }); ww.mark(e, 'corrode', 3.2, 3); drops(ww, e.x, e.y, 6, 60, P.v2, P.c3, P.e2, { z: 6, glow: 1 }); ww.add(new Splash(e.x, e.y, 6, P.v2, P.v3)); } };
  w.add(net);
  // the alchemist glides along the advancing current, sweeping a branch sideways
  yield 0.06;
  const g0 = net.pointAt(main, 30), g1 = net.pointAt(main, 62), g2 = net.pointAt(main, 92);
  w.glide([{ x: g0.x, y: g0.y }, { x: g1.x - dy * 8, y: g1.y + dx * 8 }, { x: g2.x, y: g2.y }], 0.5);
  yield 0.26;
  const sa = c.ang + 0.95 * c.rng.sign(), sq = { x: p.x, y: p.y };
  net.add(mkBranch(wavyPath(sq.x, sq.y, sa, 70, 0.35, 7, c.id + 55), 3.8, net.age + 0.02, 300, 11));
  for (let i = 0; i < 12; i++) { const a = sa + (i / 11 - 0.5) * 1.4; w.parts.add({ k: 'drop', x: sq.x, y: sq.y, z: 8, vx: Math.cos(a) * 90, vy: Math.sin(a) * 90 * 0.8, vz: 40, grav: 200, size: 2, c1: P.v2, c2: P.v3, c3: P.e2, land: 1, max: 1, glow: 1 }); }
  w.shake(1.5, 0.15);
  // surface oxidises: dark residue along the edges while bright currents remain
  const T0 = w.time;
  while (w.time - T0 < 1.9) { net.crust = clamp((w.time - T0 - 0.2) / 1.5, 0, 1); yield F; }
  // final gesture: branches swell and rupture in sequence
  p.cast = 0.4; p.castMax = 0.4; w.shake(1, 0.1);
  const all = net.br.slice().sort((a, b) => a.start - b.start);
  for (const b of all) {
    w.run((function* () {
      for (const k of ticks(0.34)) { b.wm = 1 + k * 0.9; const hd = net.pointAt(b, b.len); net.discs = net.discs.filter(d => d.x !== hd.x); yield F; }
      const pts = [net.pointAt(b, b.len), net.pointAt(b, b.len * 0.55), net.pointAt(b, b.len * 0.2)];
      pts.forEach((q, i) => {
        ringAt(c, q.x, q.y, 24, 0.22, 30, { kind: 'acid', knock: 100, stag: 0.3, h: burst, max: 2, cols: [P.v3, P.v2, P.e2], w: 3 });
        drops(w, q.x, q.y, 12, 90, P.v2, P.c3, P.e2, { z: 6, up: 100, glow: 2, size: [2, 4] }); shards(w, q.x, q.y, 6, 80, P.c1, P.e3, P.c3, { z: 4, up: 90, land: 1, size: [1, 3] });
        w.add(new Flash(q.x, q.y - 3, 10, P.v3, 0.2, 3)); w.add(new Splash(q.x, q.y, 8, P.v2, P.v3)); w.shake(2, 0.12); w.shock(q.x, q.y, 26, 0.25, 1.5);
        const cl = new Cloud(q.x, q.y, mkPuffs(c.rng, 5, 7, 6, 11, 4, 1.8), VAP.green, 2.2, c.id + i); cl.vx = Math.cos(q.ang + 1.57) * 14; cl.vy = Math.sin(q.ang + 1.57) * 10; cl.grow = { from: 0.4, to: 1.5, dur: 1 };
        cl.tickInfo = { every: 0.5, amt: c.d(10), opts: { kind: 'acid', src: c.def.id }, h: vap, max: 4, mark: 'miasma' }; w.add(cl);
        if (i === 0) w.add(new Pool(q.x, q.y, 9, MAT.verd, 3, { blobs: 4, boil: 1.6 }));
      });
      b.wm = 0.45;
    })());
    yield 0.16;
  }
  net.life = net.age + 1.4;
  yield 1.8;
}

// =============== 13 MERCURY GARDEN ===============
const MERC_DARK = { ...MAT.merc, ramp: [P.k0, hxn(0x06181a), hxn(0x0a2a2c), hxn(0x15484a), hxn(0x2c6663)], rim: hxn(0x3c8582), rimLit: hxn(0x8fc9c3) };
class Flower extends Fx {
  g = 0; open = 0; blade = 0; ph: number; per: number; lean: number;
  constructor(public bx: number, public by: number, public H: number, ph: number, public start: number) { super(); this.x = bx; this.y = by; this.sy = by; this.ph = ph; this.per = 1.5 + hash(ph * 7) * 1.1; this.lean = (hash(ph * 3) - 0.5) * 7; this.kind = 'summon'; }
  upd() { this.sy = this.by; }
  top() { const gr = smooth(this.g); return { x: this.bx + this.lean * gr, y: this.by - this.H * gr }; }
  up(g: Gfx) {
    const L = g.s, t = g.t, gr = smooth(this.g); if (gr < 0.03) return;
    const N = 7, pts: Seg[] = [];
    for (let i = 0; i <= N; i++) { const u = i / N; pts.push({ x: this.bx + this.lean * u * gr + Math.sin(t * 1.4 + this.ph + u * 3) * 1.6 * u, y: this.by - this.H * gr * u, r: lerp(2.7, 1.5, u) }); }
    wormBody(L, pts.slice().reverse(), PAL.merc, { stripe: P.w, stripeT: t * 0.6 });
    for (const s of [-1, 1]) { const q = pts[3]; shard(L, q.x, q.y, -0.5 + (s > 0 ? 0 : Math.PI + 1), 7 * gr, 2, P.y1, P.v0, P.w); }
    const tp = pts[N], o = this.open, bl = this.blade;
    const rings: [number, number, number][] = [[6, 6 + 8 * o + bl * 8, 2.3 - bl * 1.0], [5, 4 + 5 * o + bl * 6, 1.8 - bl * 0.7]];
    rings.forEach(([n, len, wd], ri) => {
      const items = Array.from({ length: n }, (_, k) => ({ k, a: (k / n) * TAU + (ri ? TAU / (2 * n) : 0) + this.ph })).sort((a, b) => Math.sin(a.a) - Math.sin(b.a));
      for (const { k, a } of items) {
        const ex = Math.cos(a) * len, ey = Math.sin(a) * len * 0.55 - o * 2 - ri * 1.5 - bl * 3, back = Math.sin(a) < 0;
        const sh = Math.sin(t * 1.7 + k * 1.3 + this.ph + ri), lit = sh > 0.55 ? P.w : sh > 0.05 ? P.y1 : P.v1, dk = sh > 0 ? P.v0 : hxn(0x0a2a2c);
        shard(L, tp.x + ex * 0.12, tp.y + ey * 0.12 - 1 - ri, Math.atan2(ey, ex), Math.hypot(ex, ey) * (1 + bl * 0.2), wd + o * 1.2, back ? mix(lit, dk, 0.4) : lit, dk, P.w);
        const sp = (t * 1.1 + k * 0.3) % 1; L.px(Math.round(tp.x + ex * sp * 0.9), Math.round(tp.y + ey * sp * 0.9 - 1 - ri), P.w);
      }
    });
    ball(L, tp.x, tp.y - 1, 2.2, PAL.merc);
  }
  lit(g: Gfx) { const tp = this.top(); glow(g.l, tp.x, tp.y - 2, 8 + this.open * 4, P.y1, 0.15 + this.open * 0.15, 3); }
}
function* garden(c: Cast) {
  const w = c.w; castAnim(w, c);
  const cx = c.tx, cy = c.ty;
  w.add(new Custom(cx, cy, 0.34, {
    air: (g, a) => { const L = g.s, z = (1 - a) * (1 - a) * 120 + 4; ball(L, cx, cy - z, 2.4, PAL.merc); L.px(Math.round(cx - 1), Math.round(cy - z - 1), P.w); for (let i = 1; i < 4; i++) { L.dl = 12 - i * 3; L.px(Math.round(cx), Math.round(cy - z - i * 3), P.y1); } L.dl = 16; },
    gnd: (g, a) => { const L = g.s; L.dl = Math.round(5 + a * 6); L.ellipse(cx, cy, 2 + a * 5, 1 + a * 2.5, P.bk); L.dl = 16; },
  }));
  yield 0.34;
  const bursts = new Hits(), blades = new Hits(), pool = new Hits();
  ringAt(c, cx, cy, 20, 0.2, 24, { kind: 'impact', knock: 100, stag: 0.3, h: bursts, max: 5, cols: [P.w, P.y1, P.v1], w: 2 }); w.shock(cx, cy, 30, 0.3, 2); w.shake(2, 0.15); w.add(new Flash(cx, cy, 12, P.w, 0.2, 2));
  drops(w, cx, cy, 14, 80, P.y1, P.w, P.v1, { z: 3, up: 70, glow: 1 });
  const merc = w.add(new Pool(cx, cy, 30, MAT.merc, 7.4, { grow: 0.9, blobs: 7, boil: 0.4, resid: true, tick: { every: 1, amt: c.d(10), opts: { kind: 'acid', src: c.def.id }, h: pool, max: 1 } }));
  const fl: Flower[] = [];
  const spots: [number, number, number][] = [[0, 0, 36]];
  for (let i = 0; i < 7; i++) { const a = (i / 7) * TAU + 0.3, d = 26 + hash(i * 5 + c.id) * 34; spots.push([Math.cos(a) * d, Math.sin(a) * d * 0.85, 20 + hash(i) * 12]); }
  spots.forEach(([dx, dy, h], i) => { const f = new Flower(clamp(cx + dx, 10, w.W - 10), clamp(cy + dy, 16, w.H - 10), h, i * 1.9 + 0.4, 0.15 + i * 0.2); fl.push(f); w.add(f); });
  const prev = fl.map(() => 0);
  const flowerBurst = (f: Flower, i: number) => {
    const tp = f.top(), mx = tp.x, my = tp.y;
    ringAt(c, f.bx, f.by, 22, 0.22, 24, { kind: 'impact', knock: 100, stag: 0.3, h: bursts, max: 5, cols: [P.w, P.y1, P.v1], w: 2 });
    w.add(new Flash(mx, my, 7, P.w, 0.14, 0));
    for (let k = 0; k < 8; k++) {
      const a = c.rng.range(0, TAU), sp = c.rng.range(30, 80);
      w.parts.add({ k: 'drop', x: mx, y: my + 3, z: 2, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.7, vz: c.rng.range(50, 100), grav: 150, size: 2, c1: P.y1, c2: P.w, c3: P.v1, max: 1.6, glow: 1,
        fn: (q, ww) => { if (q.age > 0.5 && q.k === 'drop') { q.k = 'shard'; q.size = 3; q.c1 = P.y1; q.c2 = P.v1; q.c3 = P.w; q.vr = 12; q.glow = 2; }
          if (q.age > 0.8) { const t2 = f.top(), dx = t2.x - q.x, dy = t2.y - (q.y - q.z), d = Math.hypot(dx, dy) || 1; q.vx += (dx / d) * 260 * (1 / 60); q.vy += (dy / d) * 260 * (1 / 60); q.vz *= 0.9; q.grav = 0; q.z += (-q.z) * 0 ; if (d < 4) q.age = q.max; } void ww; } });
    }
    void i;
  };
  let tm = 0; const T_COL = 4.6;
  for (; tm < T_COL; tm += F) {
    fl.forEach((f, i) => {
      f.g = clamp((tm - f.start) / 0.8, 0, 1);
      f.open = f.g > 0.8 ? smooth(0.5 + 0.5 * Math.sin(tm * TAU / f.per + f.ph)) : f.g * 0.4;
      if (f.g > 0.9 && f.open > 0.88 && prev[i] <= 0.88 && tm > 0.5) flowerBurst(f, i);
      prev[i] = f.open;
    });
    yield F;
  }
  // structural collapse: petals fold into liquid-metal blades and burst outward
  for (const k of ticks(0.3)) { fl.forEach(f => { f.blade = smooth(k); f.open = lerp(f.open, 0.2, 0.2); }); yield F; }
  w.screenFlash(P.w, 0.3, 0.12); w.shake(5, 0.35); w.shock(cx, cy, 90, 0.4, 3);
  fl.forEach((f, i) => {
    const tp = f.top(), n = 6;
    for (let k = 0; k < n; k++) {
      const a = (k / n) * TAU + i * 0.5, sp = 200;
      w.add(new Shot(tp.x, tp.y + 2, 5, Math.cos(a) * sp, Math.sin(a) * sp * 0.85, 0, 0, 4,
        (g, x, y, _z, s) => { const L = g.s, an = Math.atan2(s.vy, s.vx); shard(L, x, y, an, 10, 2.2, P.w, P.y1, P.w); shard(L, x - Math.cos(an) * 4, y - Math.sin(an) * 4, an, 6, 1.6, P.y1, P.v1, P.w); L.dl = 8; L.px(Math.round(x - Math.cos(an) * 9), Math.round(y - Math.sin(an) * 9), P.y1); L.dl = 16; },
        (ww, s, e) => { if (blades.ok(e, ww.time, 0, 3)) { hitE(c, e, 50, { kind: 'pierce', k: 130, ang: Math.atan2(s.vy, s.vx), stag: 0.3, at: [e.x, e.y] }); shards(ww, e.x, e.y, 5, 70, P.y1, P.v1, P.w, { z: 6, size: [2, 4] }); ww.add(new Flash(e.x, e.y - 4, 7, P.w, 0.12, 0)); } return false; },
        null, 0.52, 14));
    }
    shards(w, tp.x, tp.y, 8, 90, P.y1, P.v1, P.w, { z: 8, up: 90, land: 3, size: [2, 5] }); drops(w, tp.x, tp.y, 8, 70, P.y1, P.w, P.v1, { z: 6, glow: 1 });
    f.dead = true;
  });
  merc.age = merc.life - 3.4;
  w.add(new Pool(cx, cy, 34, MERC_DARK, 3.4, { grow: 0.2, blobs: 8, resid: true }));
  for (let i = 0; i < 12; i++) w.run((function* () { yield i * 0.22; steam(w, cx + c.rng.range(-30, 30), cy + c.rng.range(-18, 18), 1, 6, P.v2, P.y2, 4, { z: 2, vz: 16, max: 1.4 }); })());
  yield 3.2;
}

// =============== 14 REACTION CASCADE ===============
class Frag extends Fx {
  vx: number; vy: number; arrived = false; trailT = 0;
  constructor(x: number, y: number, ang: number, public tgt: Enemy, public gen: number, public kindR: number) { super(); this.x = x; this.y = y; this.vx = Math.cos(ang) * 120; this.vy = Math.sin(ang) * 120; this.kind = 'frag'; }
  upd(w: World, dt: number) {
    if (!alive(this.tgt)) { const n = w.nearest(this.x, this.y, 140); if (n) this.tgt = n; else { this.dead = true; this.arrived = true; return; } }
    const e = this.tgt, dx = e.x - this.x, dy = e.y - this.y, d = Math.hypot(dx, dy) || 1, sp = 190;
    const want = Math.atan2(dy, dx), cur = Math.atan2(this.vy, this.vx);
    let da = want - cur; da = ((da + Math.PI) % TAU + TAU) % TAU - Math.PI;
    const na = cur + clamp(da, -6.5 * dt, 6.5 * dt), s = Math.min(sp, Math.hypot(this.vx, this.vy) + 420 * dt);
    this.vx = Math.cos(na) * s; this.vy = Math.sin(na) * s;
    this.x += this.vx * dt; this.y += this.vy * dt;
    if (this.age * 60 % 1 < 1) w.parts.add({ k: 'drop', x: this.x, y: this.y, z: 5, vx: -this.vx * 0.05 + (hash(this.age * 60) - 0.5) * 8, vy: -this.vy * 0.05, vz: 6, grav: 80, size: 2, c1: this.kindR === 2 ? P.y1 : this.kindR === 3 ? P.c3 : P.c1, c2: P.w, c3: P.e2, max: 0.4, glow: 1 });
    if (d < e.r + 2) { this.arrived = true; this.dead = true; }
  }
  air(g: Gfx) { const L = g.s, cols = [P.c1, P.m2, P.y1, P.g2][this.kindR]; ball(L, this.x, this.y - 5, 2.6, PAL.liquid); L.disc(this.x, this.y - 5, 1.2, cols); L.px(Math.round(this.x - 1), Math.round(this.y - 6), P.w); }
  lit(g: Gfx) { glow(g.l, this.x, this.y - 5, 7, [P.c1, P.m1, P.y1, P.g1][this.kindR], 0.4, 3); }
}
function* cascade(c: Cast) {
  const w = c.w; castAnim(w, c);
  yield 0.04;
  const tgt = c.target ?? w.nearest(c.tx, c.ty, 100);
  if (!tgt) return;
  const [hx, hy] = handPos(w);
  const dur = clamp(Math.hypot(tgt.x - hx, tgt.y - hy) / 780, 0.08, 0.2);
  const pr = new Proj(hx, hy, tgt.x, tgt.y, dur, 5, (g, x, y, _z, a) => { vialSpriteG(g, x, y, a); }, () => 0);
  pr.lit = (g) => glow(g.l, pr.x, pr.y - pr.z, 8, P.c2, 0.45, 3); w.add(pr);
  yield dur;
  const reached = new Set<number>([tgt.id]), react = new Hits(), fin = new Hits();
  let last: Enemy = tgt, ri = 0;
  const contact = (e: Enemy, big = false) => {
    w.add(new Flash(e.x, e.y - 4, big ? 22 : 14, P.w, 0.22, 4)); visRing(w, e.x, e.y, big ? 30 : 16, 0.2, [P.w, P.c2, P.e2], 2); w.shock(e.x, e.y, 26, 0.25, 1.5); w.shake(big ? 3 : 1.5, 0.12);
    drops(w, e.x, e.y, 10, 90, P.c1, P.c3, P.e2, { z: 6, up: 90, glow: 2 });
  };
  hitE(c, tgt, 60, { kind: 'burst', k: 90, from: [hx, hy], stag: 0.3, at: [tgt.x, tgt.y] }); contact(tgt, true);
  const frags: Frag[] = [];
  const launch = (from: Enemy, gen: number, n: number) => {
    const cand = w.enemies.filter(e => e.dying <= 0 && !reached.has(e.id) && !frags.some(f => f.tgt === e && !f.dead)).map(e => ({ e, d: Math.hypot(e.x - from.x, e.y - from.y) })).filter(o => o.d < 125).sort((a, b) => a.d - b.d).slice(0, n);
    cand.forEach((o, i) => { const f = new Frag(from.x, from.y, Math.atan2(o.e.y - from.y, o.e.x - from.x) + (i % 2 ? 1 : -1) * 1.0 + c.rng.range(-0.3, 0.3), o.e, gen, (ri + i) % 4); frags.push(f); w.add(f); });
  };
  launch(tgt, 1, 3);
  const reaction = (e: Enemy, type: number) => {
    const X = e.x, Y = e.y;
    const pop = () => ringAt(c, X, Y, 24, 0.22, 55, { kind: type === 2 ? 'crystal' : 'burst', knock: 110, stag: 0.35, h: react, max: 1, cols: [P.w, [P.c1, P.m2, P.y1, P.c3][type], P.e2], w: 3 });
    if (type === 0) { // swelling fluid
      w.add(new Custom(X, Y, 0.4, { up: (g, a) => { const r = 3 + a * 14 * (1 + Math.sin(a * 40) * 0.05); ball(g.s, X, Y - 6, r, PAL.liquid, r * 0.9); g.s.dl = 8; g.s.disc(X + 1, Y - 5, r * 0.5, P.c2); g.s.dl = 16; }, lit: (g, a) => glow(g.l, X, Y - 6, 10 + a * 14, P.c1, 0.4, 3) }, Y + 2));
      w.run((function* () { yield 0.38; pop(); drops(w, X, Y, 16, 100, P.c1, P.c3, P.e2, { z: 8, up: 100, glow: 2 }); w.add(new Splash(X, Y, 9, P.c1, P.c3)); w.add(new Pool(X, Y, 8, MAT.acid, 2, { blobs: 4, boil: 1 })); })());
    } else if (type === 1) { // rupturing membranes
      w.add(new Custom(X, Y, 0.42, { up: (g, a) => { const r = 4 + a * 15; g.s.dl = 8; g.s.disc(X, Y - 8, r, P.m1); g.s.dl = 16; g.s.ring(X, Y - 8, r, 1, P.m2); g.s.ring(X, Y - 8, r * 0.6, 1, P.c3); g.s.px(Math.round(X - r * 0.5), Math.round(Y - 8 - r * 0.5), P.w); if (a > 0.7) for (let i = 0; i < 4; i++) { const an = i * 1.7; g.s.line(X + Math.cos(an) * r * 0.4, Y - 8 + Math.sin(an) * r * 0.4, X + Math.cos(an) * r, Y - 8 + Math.sin(an) * r, P.k0); } }, lit: (g, a) => glow(g.l, X, Y - 8, 12 + a * 10, P.m1, 0.4, 3) }, Y + 2));
      w.run((function* () { yield 0.4; pop(); for (let i = 0; i < 10; i++) { const a = c.rng.range(0, TAU); w.parts.add({ k: 'petal', x: X, y: Y, z: 8, vx: Math.cos(a) * 60, vy: Math.sin(a) * 50, vz: c.rng.range(30, 80), grav: 80, drag: 1.2, size: 3, rot: a, vr: 7, c1: P.m1, c2: P.m2, max: 1.4, fn: (q) => { if (q.z < 0) { q.z = 0; q.vz = 0; } } }); } drops(w, X, Y, 10, 80, P.m2, P.w, P.m1, { z: 8, glow: 1 }); })());
    } else if (type === 2) { // crystalline growth
      w.mark(e, 'crystal', 0.8, 0.5);
      w.add(new Custom(X, Y, 0.55, { up: (g, a) => { const k = smooth(Math.min(1, a * 2)), L = g.s; if (a > 0.9) return; for (let i = 0; i < 4; i++) crystalPrism(L, X + (i - 1.5) * 4, Y + 3 + (i % 2) * 2, (6 + (i % 3) * 5) * k, 1.8, (i - 1.5), P.v2, P.v0, P.y2, P.k1, g.t); }, lit: (g, a) => glow(g.l, X, Y - 6, 10, P.y1, 0.3 * (1 - a), 3) }, Y + 4));
      w.run((function* () { yield 0.45; pop(); shards(w, X, Y, 12, 100, P.y1, P.v1, P.y2, { z: 6, up: 100, land: 2, size: [3, 6] }); })());
    } else { // boiling vapour
      w.run((function* () { for (let i = 0; i < 6; i++) { steam(w, X + c.rng.range(-5, 5), Y, 2, 20, P.e2, P.c3, 5, { z: 3, vz: 40 }); drops(w, X, Y, 2, 50, P.g2, P.c3, P.c1, { z: 4, up: 90, glow: 1 }); yield 0.05; } pop(); plume(w, X, Y, 22, 0.9, VAP.pale, 9, ri + 3); })());
    }
    ri++;
  };
  let idle = 0;
  for (let tm = 0; tm < 6; tm += F) {
    for (const f of frags) {
      if (!f.arrived || (f as Frag & { done?: boolean }).done) continue;
      (f as Frag & { done?: boolean }).done = true;
      const e = f.tgt;
      if (!alive(e)) continue;
      reached.add(e.id); last = e;
      hitE(c, e, 45, { kind: 'burst', k: 70, ang: Math.atan2(f.vy, f.vx), stag: 0.3, at: [e.x, e.y] });
      contact(e); reaction(e, f.kindR);
      launch(e, f.gen + 1, f.gen >= 3 ? 0 : f.gen === 1 ? 2 : 2);
    }
    const pending = frags.some(f => !f.arrived);
    idle = pending ? 0 : idle + F;
    if (idle > 0.5) break;
    yield F;
  }
  // final target: the accumulated energy detonates
  const X = last.x, Y = last.y;
  w.hitstop = 0.05; w.screenFlash(P.w, 0.5, 0.2); w.shake(8, 0.5); w.shock(X, Y, 110, 0.5, 4);
  w.add(new Flash(X, Y - 6, 44, P.w, 0.4, 6));
  ringAt(c, X, Y, 66, 0.4, 140, { kind: 'burst', knock: 180, stag: 0.5, h: fin, cols: [P.w, P.c2, P.m1], w: 5, dust: false });
  visRing(w, X, Y, 46, 0.35, [P.c3, P.c1, P.e2], 3);
  w.add(new Custom(X, Y, 1.0, { air: (g, a) => {
    const L = g.s, t = g.t;
    for (let arm = 0; arm < 4; arm++) { const pts: Seg[] = []; for (let i = 0; i < 16; i++) { const u = i / 15, an = arm * 1.571 + u * 2.6 + t * 3.5, rr = u * 62 * smooth(Math.min(1, a * 1.6)); pts.push({ x: X + Math.cos(an) * rr, y: Y - 4 + Math.sin(an) * rr * 0.8, r: (3.4 - u * 2) * (1 - a * 0.6) }); } L.dl = Math.max(3, Math.round(14 * (1 - a))); wormBody(L, pts, PAL.liquid, { stripe: P.c3, stripeT: t }); L.dl = 16; }
  }, lit: (g, a) => glow(g.l, X, Y, 50, P.c1, 0.3 * (1 - a), 4) }, Y + 8));
  for (let i = 0; i < 30; i++) { const a = (i / 30) * TAU + c.rng.range(-0.1, 0.1), sp = c.rng.range(100, 160); if (i % 2) w.parts.add({ k: 'chip', x: X, y: Y, z: 8, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.8, vz: 60, grav: 200, size: 3, c1: P.g2, c2: P.g0, c3: P.w, land: 3, max: 2.4, rot: 0, vr: 9, glow: 2 }); else w.parts.add({ k: 'drop', x: X, y: Y, z: 8, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.8, vz: 80, grav: 200, size: 3, c1: P.c1, c2: P.c3, c3: P.e2, land: 1, max: 2.4, glow: 2 }); }
  w.add(new Pool(X, Y, 20, MAT.acid, 4, { blobs: 6, boil: 1.4 }));
  yield 1.4;
}
function vialSpriteG(g: Gfx, x: number, y: number, a: number) { const L = g.s, pu = Math.sin(a * 60) > 0; ball(L, x, y, 3.6, PAL.liquid); L.disc(x + 1, y + 1, 1.5, P.k0); L.px(Math.round(x - 2), Math.round(y - 2), pu ? P.w : P.c3); if (pu) L.px(Math.round(x + 2), Math.round(y - 1), P.m2); }

// =============== 15 BREATH OF THE VAT ===============
function* vat(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c, true, 0.4);
  const dx = Math.cos(c.ang), dy = Math.sin(c.ang);
  yield 0.05;
  const [hx, hy] = handPos(w), ox = clamp(p.x + dx * 36, 20, w.W - 20), oy = clamp(p.y + dy * 36, 24, w.H - 20);
  w.add(new Flash(hx, hy, 12, P.c2, 0.25, 2)); drops(w, hx, hy, 12, 60, P.c1, P.c3, P.e2, { z: 6, glow: 1 });
  const ticks_ = new Hits(), er = new Hits();
  const mk = (ramp: Col[], n: number, R: number, r0: number, r1: number, lay: number, life: number) => { const cl = new Cloud(ox, oy, mkPuffs(c.rng, n, R, r0, r1, 8, 1.9, lay), ramp, life, c.id + lay); cl.vx = dx * 38; cl.vy = dy * 38; cl.grow = { from: 0.3, to: 1, dur: 0.7 }; cl.dens = 12 - lay; return cl; };
  const A = mk(VAP.dark, 18, 36, 17, 25, 0, 7), B = mk(VAP.green, 16, 30, 12, 19, 1, 7), C = mk(VAP.pale, 12, 26, 9, 14, 2, 7);
  // leading boundary folds over itself: front puffs roll along elongated orbits
  for (const cl of [A, B, C]) cl.puffs.forEach(pf => { if (pf.x * dx + pf.y * dy > 8) { pf.orb = 8 + Math.abs(pf.x) * 0.1; pf.sp = Math.abs(pf.sp) * 1.5; } });
  A.tickInfo = { every: 0.5, amt: c.d(18), opts: { kind: 'acid', src: c.def.id, stagger: 0.1 }, h: ticks_, max: 6, mark: 'miasma' }; A.dens = 11;
  w.add(A); w.add(B); w.add(C);
  const side = c.rng.sign(); let tm = 0, glided = false, erupted = 0;
  const all = [A, B, C];
  for (; tm < 7; tm += F) {
    if (tm > 1.2 && tm < 2.6) { const rot = 0.5 * side * F / 1.4, ca = Math.cos(rot), sa = Math.sin(rot); for (const cl of all) { const vx = cl.vx * ca - cl.vy * sa, vy = cl.vx * sa + cl.vy * ca; cl.vx = vx; cl.vy = vy; } }
    if (tm > 1.15 && !glided) { glided = true; const px = A.x + (-dy * side) * 38, py = A.y + dx * side * 38; w.glide([{ x: px, y: py }, { x: px + dx * 36 + dx * 0, y: py + dy * 36 }], 0.55); w.add(new Ring(p.x, p.y, 16, 0.3, { w: 2, cols: [P.c3, P.c1, P.e2] })); }
    if (tm > 3.3 && tm < 4.3) { const k = smooth((tm - 3.3) / 1.0); for (const cl of all) { cl.shrink = lerp(1, 0.6, k); } if (Math.floor(tm * 60) % 4 === 0) w.parts.add({ k: 'spark', x: A.x + c.rng.range(-18, 18), y: A.y + c.rng.range(-12, 12), z: 6, vx: 0, vy: 0, vz: 20, max: 0.3, c1: P.c3 }); }
    if (Math.floor(tm * 60) % 8 === 0) for (const e of w.enemies) if (e.dying <= 0 && e.st.miasma && c.rng.next() < 0.5) w.parts.add({ k: 'mote', x: e.x + c.rng.range(-4, 4), y: e.y, z: e.r + 2, vx: c.rng.range(-8, 8), vy: -4, vz: 22, max: 0.9, c1: P.c3, c2: P.c1, glow: 1 });
    if (tm > 4.4 && erupted < 4 && tm > 4.4 + erupted * 0.3) {
      erupted++;
      const pf = A.puffs[Math.floor(c.rng.next() * A.puffs.length)], q = A.pos(pf, A.age), X = q.x, Y = q.y;
      ringAt(c, X, Y, 30, 0.26, 41.75, { kind: 'burst', knock: 130, stag: 0.4, h: er, max: 4, cols: [P.w, P.c2, P.e2], w: 3 });
      w.add(new Flash(X, Y - 4, 22, P.c3, 0.3, 6)); w.shake(4, 0.25); w.shock(X, Y, 50, 0.3, 2.5); if (erupted === 4) w.screenFlash(P.c2, 0.25, 0.1);
      drops(w, X, Y, 14, 100, P.c1, P.c3, P.e2, { z: 8, up: 110, glow: 2 }); chips(w, X, Y, 6, 90, P.k3, P.k1, P.e1, { z: 8, up: 90, size: [2, 4] });
      const ex = new Cloud(X, Y, mkPuffs(c.rng, 7, 12, 9, 14, 6, 2, 1), erupted % 2 ? VAP.pale : VAP.green, 2.6, c.id + erupted * 3); ex.grow = { from: 0.3, to: 1.8, dur: 0.9 }; ex.vx = A.vx * 0.5; ex.vy = A.vy * 0.5; w.add(ex);
      A.shrink = Math.min(A.shrink, 0.6);
    }
    if (tm > 5.6) { for (const cl of all) cl.life = Math.min(cl.life, cl.age + 1.4); }
    yield F;
  }
  yield 1.6;
}

// =============== 16 CRYSTAL ROT ===============
export class Cluster extends Fx {
  g = 0; swell = 1; fr = 0; pulse = -1; sizes: number[];
  constructor(public bx: number, public by: number, seed: number, public big: number) { super(); this.x = bx; this.y = by; this.sy = by; this.sizes = [0, 1, 2, 3, 4].map(i => (10 + hash(seed * 7 + i * 3) * 14) * big); this.kind = 'summon'; this.resid = false; }
  upd() { this.sy = this.by + 3; }
  gnd(g: Gfx) { if (this.g < 0.05) return; const L = g.s; L.dl = 9; L.ellipse(this.bx, this.by + 2, 12 * this.g, 5 * this.g, P.k0); L.dl = 16; for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU; L.px(Math.round(this.bx + Math.cos(a) * 12 * this.g), Math.round(this.by + 2 + Math.sin(a) * 5 * this.g), P.v1); } }
  up(g: Gfx) {
    const L = g.s, t = g.t, gr = smooth(this.g); if (gr < 0.02) return;
    const order = [0, 3, 1, 4, 2];
    for (const i of order) {
      const ox = (i - 2) * 4.2 * this.big, h = this.sizes[i] * gr * (1 + (this.swell - 1) * 0.5), w2 = (2.8 + i % 2) * this.swell * this.big * 0.7, lean = (i - 2) * 1.4;
      const hot = this.pulse >= 0 && Math.abs(this.pulse * 1.4 - (i / 4)) < 0.28;
      crystalPrism(L, this.bx + ox, this.by + 2 - (i === 2 ? 2 : 0) + (i % 2) * 2, h, w2, lean, hot ? P.v3 : P.v2, hot ? P.v1 : P.v0, hot ? P.w : P.y2, hot ? P.c1 : P.k1, t);
      if (this.fr > 0.05) for (let k = 0; k < Math.floor(this.fr * 4); k++) { const yy = this.by + 2 - h * (0.25 + k * 0.2); L.line(this.bx + ox - w2, yy, this.bx + ox + w2, yy - 2, P.w); }
    }
  }
  lit(g: Gfx) { glow(g.l, this.bx, this.by - 8 * this.g, 12 + this.swell * 4, this.pulse >= 0 ? P.c2 : P.y1, 0.14 + (this.pulse >= 0 ? 0.35 : 0) + this.fr * 0.2, 3); }
}
function* rot(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c);
  yield 0.04;
  const tgt = c.target ?? w.nearest(c.tx, c.ty, 110);
  if (!tgt) return;
  const [hx, hy] = handPos(w);
  const dur = clamp(Math.hypot(tgt.x - hx, tgt.y - hy) / 560, 0.1, 0.26);
  throwArc(w, 'crystal', hx, hy, tgt.x, tgt.y, dur, 8, () => 0, 16);
  yield dur;
  const growH = new Hits(), fin = new Hits();
  hitE(c, tgt, 80, { kind: 'crystal', k: 90, from: [hx, hy], stag: 0.4, at: [tgt.x, tgt.y] });
  w.poison(tgt, c.d(60), 3, c.id, c.def.id); w.add(new Flash(tgt.x, tgt.y - 4, 12, P.y2, 0.2, 4));
  shards(w, tgt.x, tgt.y, 8, 70, P.y1, P.v1, P.y2, { z: 6, size: [2, 4] });
  const cx = tgt.x, cy = tgt.y, clusters: Cluster[] = [];
  const spots = [[-26, 8, 1], [24, -10, 1.15], [4, 26, 0.9], [-8, -26, 1]];
  const edges: [number, number, number, number][] = [];
  w.add(new Custom(cx, cy, 8.5, { gnd: (g) => { const L = g.s, t = g.t; for (const [a, b, c2, d] of edges) { const n = Math.ceil(Math.hypot(c2 - a, d - b) / 2); for (let i = 0; i <= n; i++) { const u = i / n, X = Math.round(lerp(a, c2, u)), Y = Math.round(lerp(b, d, u) + Math.sin(u * 8) * 1.2); L.px(X, Y, P.k0); L.px(X, Y + 1, P.v0); const hot = clusters.some(k => k.pulse >= 0) && Math.abs(((t * 2.2) % 1) - u) < 0.08; if (hot) L.px(X, Y, P.c3); else if (i % 6 === 0) L.px(X, Y, P.v2); } } } }));
  // growth spreads across the silhouette (branching, translucent, dark interior) – drawn by the enemy overlay
  const t0 = w.time; let ci = 0;
  for (let tm = 0; tm < 1.3; tm += F) {
    const k = clamp((w.time - t0) / 0.9, 0, 1);
    if (alive(tgt)) w.mark(tgt, 'crystal', 3, k);
    if (ci < spots.length && tm > 0.25 + ci * 0.13) {
      const [dx, dy, s] = spots[ci], cl = new Cluster(clamp(cx + dx, 14, w.W - 14), clamp(cy + dy, 24, w.H - 10), c.id + ci * 3, s); clusters.push(cl); w.add(cl);
      edges.push([tgt.x, tgt.y, cl.bx, cl.by]); ci++;
      ringAt(c, cl.bx, cl.by, 20, 0.2, 40, { kind: 'crystal', knock: 110, stag: 0.35, h: growH, max: 2, cols: [P.y2, P.y1, P.v1], w: 2, dust: true });
      dust(w, cl.bx, cl.by, 4, 20, 4); chips(w, cl.bx, cl.by, 4, 60, P.k3, P.k2, P.v1, { z: 2, size: [2, 3] }); w.shake(1.5, 0.12);
    }
    clusters.forEach(cl => { cl.g = clamp(cl.g + F * 2.2, 0, 1); });
    yield F;
  }
  // the alchemist relocates and fires a second reagent
  const sd = c.rng.sign(), px = clamp(p.x - Math.sin(c.ang) * 44 * sd, 12, w.W - 12), py = clamp(p.y + Math.cos(c.ang) * 44 * sd, 14, w.H - 12);
  w.glide([{ x: px, y: py }], 0.34);
  yield 0.36; castAnim(w, c, false, 0.3); p.face = Math.atan2(cy - p.y, cx - p.x);
  yield 0.06;
  const [h2x, h2y] = handPos(w);
  let hitCore = false;
  throwArc(w, 'crystal', h2x, h2y, cx, cy, 0.28, 14, () => { hitCore = true; }, 18);
  yield 0.28; void hitCore;
  w.add(new Flash(cx, cy - 6, 14, P.c3, 0.3, 6));
  // luminous pulse travels through the connected formation, crystals swell and crack
  for (const k of ticks(0.7)) {
    clusters.forEach((cl, i) => { cl.pulse = clamp(k * 1.5 - i * 0.12, 0, 1.2); cl.swell = 1 + smooth(k) * 0.45; cl.fr = k; if (cl.pulse > 0.99 && Math.floor(k * 60) % 3 === 0) w.parts.add({ k: 'spark', x: cl.bx + c.rng.range(-8, 8), y: cl.by, z: c.rng.range(2, 18), vx: 0, vy: 0, vz: 0, max: 0.25, c1: P.w }); });
    if (alive(tgt)) w.mark(tgt, 'crystal', 1, 1);
    w.shock(cx, cy, 20 + k * 40, 0.15, 0.8);
    yield F;
  }
  // synchronised detonation
  w.hitstop = 0.06; w.screenFlash(P.y2, 0.5, 0.2); w.shake(8, 0.55);
  for (const cl of clusters) {
    const X = cl.bx, Y = cl.by; cl.dead = true;
    ringAt(c, X, Y, 46, 0.3, 155, { kind: 'crystal', knock: 190, stag: 0.5, h: fin, max: 1, cols: [P.w, P.y1, P.v1], w: 4, dust: false });
    w.shock(X, Y, 60, 0.35, 3); w.add(new Flash(X, Y - 10, 22, P.w, 0.3, 4));
    shards(w, X, Y, 22, 190, P.c3, P.v2, P.w, { z: 12, up: 200, land: 2, size: [3, 8] }); shards(w, X, Y, 12, 130, P.y1, P.v0, P.y2, { z: 8, up: 150, land: 2, size: [2, 5] });
    const dcl = new Cloud(X, Y, mkPuffs(c.rng, 6, 10, 8, 13, 5, 1.8), [P.v0, P.v1, P.c0, P.c3], 2.6, c.id + 5); dcl.grow = { from: 0.4, to: 1.7, dur: 1 }; dcl.dens = 9; w.add(dcl);
    w.add(new Decal(X, Y, 'cracks', 18, 6, Math.floor(X), { a: P.k0, b: P.v1, c: P.y1 }, 0, 1)); steam(w, X, Y, 3, 14, P.v1, P.y2, 5, { z: 6, vz: 20 });
  }
  shards(w, cx, cy, 10, 120, P.y1, P.v0, P.w, { z: 8, up: 120, land: 2 });
  for (const e of w.enemies) if (e.st.crystal && e.dying <= 0) { shards(w, e.x, e.y, 10, 100, P.y1, P.v1, P.w, { z: e.r, up: 100, size: [2, 5] }); w.add(new Flash(e.x, e.y - 4, 10, P.y2, 0.2, 2)); delete e.st.crystal; }
  yield 1.4;
}

export const defs3: Pick<SkillDef, 'id' | 'run'>[] = [
  { id: 11, run: catalyst }, { id: 12, run: wake }, { id: 13, run: garden }, { id: 14, run: cascade }, { id: 15, run: vat }, { id: 16, run: rot },
];
void bubble; void pal; void Embed; void Shot; void Fx; void Ring; void Cloud;
