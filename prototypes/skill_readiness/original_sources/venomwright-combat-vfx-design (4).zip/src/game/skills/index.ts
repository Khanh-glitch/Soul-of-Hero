import { P } from '../pixel';
import type { SkillDef } from './lib';
import { defs1 } from './s1';
import { defs2 } from './s2';
import { defs3 } from './s3';
import { defs4 } from './s4';

type Meta = Omit<SkillDef, 'run'>;
const META: Meta[] = [
  { id: 1, name: 'Glassfang Hunt', sub: 'Living vessel · hunting glass predator', form: 'vessel', tier: 1, slot: 'basic', aim: { kind: 'target', range: 190 }, cd: 10, cast: 0.1, first: 0.25, total: 205, dur: 5, col: [P.v2, P.c1],
    desc: 'A cracked vessel releases a segmented glass hunter that leaps, bites, circles and lunges from new angles before shattering into plates and erupting luminous fluid.', hits: '4 bites ×30 · final strike 55 · 3 bubbling pools ×10' },
  { id: 2, name: 'Blooming Parasite', sub: 'Fungal colony · spore currents', form: 'vessel', tier: 2, slot: 'basic', aim: { kind: 'ground', range: 170, radius: 62 }, cd: 15, cast: 0.15, first: 0.4, total: 265, dur: 8, col: [P.c0, P.g2],
    desc: 'A pale seed opens into a colony of flower-mouths. Tendrils lash intruders, ground eruptions stagger them and infection spreads, until the colony contracts and ruptures in a spore pulse.', hits: 'seed 15 · 3 lashes ×15 · 2 eruptions ×25 · infection 55 · pulse 100' },
  { id: 3, name: 'Leechwater Rush', sub: 'Slide · swarm currents · life drain', form: 'vessel', tier: 1, slot: 'basic', aim: { kind: 'cone', range: 150, angle: 1.24 }, cd: 11, cast: 0.08, first: 0.18, total: 195, dur: 6, col: [P.y0, P.m1],
    desc: 'Slide along an advancing edge of dark water carrying coordinated swarms. They become leeches, drain life back to you (15% healing), then regroup into a twisting mass and collapse.', hits: 'contact 50 · 6 drains ×15 (15% heal) · collapse 55' },
  { id: 4, name: 'Porcelain Bastion', sub: 'Ceramic guardian · pressure rupture', form: 'vessel', tier: 3, slot: 'basic', aim: { kind: 'ground', range: 160, radius: 44 }, cd: 23, cast: 0.2, first: 0.5, total: 360, dur: 12, col: [P.i0, P.c1],
    desc: 'Heavy plates assemble around a turbulent poison reservoir and unfold into a four-legged guardian that slams enemies. Fractures spread until pressure ruptures it into a contaminated crater.', hits: 'emerge 40 · 4 slams ×35 · rupture 120 · crater pool 3×20' },
  { id: 5, name: 'Bellows Toad', sub: 'Inhale · vapour blast · inflation', form: 'vessel', tier: 2, slot: 'basic', aim: { kind: 'cone', range: 140, angle: 0.96 }, cd: 16, cast: 0.08, first: 0.3, total: 255, dur: 6, col: [P.e2, P.c1],
    desc: 'A grotesque toad crawls from a puddle, inhales debris, and blasts rolling vapour with heavy globules. A final exaggerated inflation bursts into a ring of toxic liquid.', hits: 'puddle 15 · vapour 3×18 · 2 globules ×30 · poison 36 · burst 90' },
  { id: 6, name: 'Graft Caravan', sub: 'Flask-bearing beetles · curved route', form: 'vessel', tier: 3, slot: 'basic', aim: { kind: 'path', range: 230, width: 26 }, cd: 21, cast: 0.2, first: 0.45, total: 345, dur: 8, col: [P.u2, P.c1],
    desc: 'Armoured beetles carry sloshing flasks along a curved path, charging, turning and climbing debris. Each shatters its flask on contact; the last carries an unstable vessel that detonates in layers.', hits: '3 flask hits ×50 · pools 3×15 · final blast 100 · vapour 2×25' },
  { id: 7, name: 'Hatchery Fall', sub: 'Cocoon · flocking brood · insect form', form: 'vessel', tier: 2, slot: 'basic', aim: { kind: 'ground', range: 170, radius: 80 }, cd: 17, cast: 0.2, first: 0.5, total: 280, dur: 10, col: [P.g1, P.n3],
    desc: 'A living cocoon lands, unfolds and pulses open, releasing swarming hatchlings that hunt on curved paths, then return and fuse into an insect-like colossus that collapses explosively.', hits: 'impact 40 · 6 bites ×14 · collapse 110 · residue 3×15.3' },
  { id: 8, name: 'Brine Serpents', sub: 'Emerging streams · coil · lunge · rupture', form: 'vessel', tier: 2, slot: 'basic', aim: { kind: 'multi', range: 200, n: 3 }, cd: 18, cast: 0.1, first: 0.35, total: 290, dur: 8, col: [P.v2, P.y1],
    desc: 'Three streams of dark liquid reveal scaled serpents that weave between enemies. One coils, one lunges, one links targets; then they rise and burst along their length into poison ribbons.', hits: '2 bites ×40 · coil 3×20 · ribbons 2×50 · poison 50' },
  { id: 9, name: 'Molting Harvester', sub: 'Scythe colossus · molt · cleave', form: 'vessel', tier: 3, slot: 'basic', aim: { kind: 'dir', range: 230, width: 34 }, cd: 25, cast: 0.2, first: 0.4, total: 400, dur: 9, col: [P.g2, P.c1],
    desc: 'A chitin harvester claws out of the ground, sweeping crescents into the floor. Its shell cracks and molts violently, exposing brighter limbs for rapid slashes and a gigantic final cleave.', hits: 'emerge 30 · 4 sweeps ×30 · 2 debris ×25 · 3 slashes ×30 · cleave 110' },
  { id: 10, name: 'The Walking Crucible', sub: 'Ultimate · monumental walking laboratory', form: 'vessel', tier: 4, slot: 'ult', aim: { kind: 'ground', range: 200, radius: 110 }, cd: 85, cast: 0.3, first: 0.75, total: 800, dur: 15, col: [P.i0, P.c2],
    desc: 'A colossal ceramic laboratory assembles and strides through the enemy ranks, shoving foes aside while venting acid streams, bubbles and vapour. It overheats, plants all limbs and erupts in a catastrophe.', hits: 'steps 5×15 · streams 5×20 · bubbles 3×33 · vapour 6×13 · finale 448' },
  { id: 11, name: 'Unsealed Catalyst', sub: 'Transformation · enter Venomcraft', form: 'trans', tier: 2, slot: 'trans', aim: { kind: 'self', range: 90 }, cd: 49, cast: 0.45, first: 0.45, total: 80, dur: 4, col: [P.c1, P.c3],
    desc: 'Break the seal on an unstable living substance. It rises around you in poison sheets, summons react, then erupts in a transformation wave. Venomcraft lasts 14s; requires 100 Catalyst.', hits: 'transformation pulse 80 · 14s duration · 35s cooldown after ending' },
  { id: 12, name: 'Verdigris Wake', sub: 'Oxidising stream · branching rupture', form: 'venom', tier: 1, slot: 'basic', aim: { kind: 'path', range: 200, width: 24 }, cd: 10, cast: 0.08, first: 0.2, total: 220, dur: 8, col: [P.v2, P.g2],
    desc: 'A vial spills a branching stream of oxidising liquid. Glide along the current and sweep part of it aside; it corrodes enemies, crusts over, then swells and ruptures branch by branch.', hits: 'front 70 · 2 ticks ×25 · 2 bursts ×30 · vapour 4×10' },
  { id: 13, name: 'Mercury Garden', sub: 'Liquid-metal flowers · blade collapse', form: 'venom', tier: 2, slot: 'basic', aim: { kind: 'ground', range: 180, radius: 70 }, cd: 16, cast: 0.1, first: 0.35, total: 280, dur: 9, col: [P.y1, P.w],
    desc: 'A silvery droplet blooms into metallic flowers whose petals shift between reflection and shadow. They burst droplets that crystallise and return, then collapse into outward-flying liquid blades.', hits: '5 bursts ×24 · 3 blade hits ×50 · pool 10' },
  { id: 14, name: 'Reaction Cascade', sub: 'Chain reagent · coherent fragments', form: 'venom', tier: 2, slot: 'basic', aim: { kind: 'target', range: 220 }, cd: 17, cast: 0.08, first: 0.22, total: 300, dur: 6, col: [P.c2, P.m1],
    desc: 'An unstable globule erupts on contact; fragments with real momentum fly to neighbours, each triggering a different reaction. The last target detonates in curling sheets and a ring of glowing debris.', hits: 'primary 60 · fragment 45 · reaction 55 · final 140' },
  { id: 15, name: 'Breath of the Vat', sub: 'Rolling toxic mass · internal eruptions', form: 'venom', tier: 2, slot: 'basic', aim: { kind: 'dir', range: 170, width: 70 }, cd: 15, cast: 0.1, first: 0.3, total: 275, dur: 9, col: [P.e3, P.c2],
    desc: 'A layered vapour mass rolls across the arena and turns on command. Enemies glow with toxic overlays inside; as pressure builds the cloud contracts and tears apart in internal eruptions.', hits: 'vapour 6×18 · 4 eruptions ×41.75' },
  { id: 16, name: 'Crystal Rot', sub: 'Branching growth · synchronised shatter', form: 'venom', tier: 3, slot: 'basic', aim: { kind: 'target', range: 200 }, cd: 22, cast: 0.1, first: 0.3, total: 375, dur: 7, col: [P.y1, P.v2],
    desc: 'A reagent seeds branching crystal across the target and the ground beneath. A second throw pulses through the connected formation until everything swells, fractures and explodes in a shard storm.', hits: 'contact 80 · 2 growths ×40 · infection 60 · shatter 155' },
  { id: 17, name: 'Reverse Extraction', sub: 'Vortex · vessel compression · burst', form: 'venom', tier: 2, slot: 'basic', aim: { kind: 'dir', range: 200, width: 90 }, cd: 18, cast: 0.1, first: 0.25, total: 285, dur: 7, col: [P.c1, P.g2],
    desc: 'A vortex hauls residue, droplets and enemies inward, then is compressed into a vessel and released as a violent directional wave of corrosive fluid that leaves glowing residue.', hits: 'pull 4×25 (minor heal) · wave 140 · residue 2×22.5' },
  { id: 18, name: 'Bitter Rain', sub: 'Arcing vessels · droplet storm · boil', form: 'venom', tier: 3, slot: 'basic', aim: { kind: 'ground', range: 190, radius: 86 }, cd: 23, cast: 0.15, first: 0.55, total: 370, dur: 9, col: [P.e3, P.c2],
    desc: 'Vessels arc overhead and rupture into dark clouds. Heavy drops fall first, then turbulent small ones, linking glowing puddles that finally boil into towering columns of luminous vapour.', hits: '3 big drops ×30 · 10 small ×6 · puddles 3×20 · 3 columns ×53' },
  { id: 19, name: 'False Remedy', sub: 'Healing lacework turns hostile', form: 'venom', tier: 2, slot: 'basic', aim: { kind: 'target', range: 190 }, cd: 16, cast: 0.1, first: 0.28, total: 295, dur: 7, col: [P.g2, P.c1],
    desc: 'A golden healing-like substance spreads in delicate membranes, then darkens: membranes curl, poison veins surface, and a second vial makes the infection contract and rupture.', hits: 'contact 40 · delayed poison 6×20 · rupture 135' },
  { id: 20, name: 'Plague Cartography', sub: 'Drag a route · flooding channel network', form: 'venom', tier: 3, slot: 'basic', aim: { kind: 'drag', range: 300, radius: 14 }, cd: 25, cast: 0.1, first: 0.35, total: 405, dur: 9, col: [P.v2, P.c2],
    desc: 'Dash between locations laying reagent along your actual route. The streams widen into foaming channels; intersections become reservoirs that fire in sequence before a flood tears through.', hits: 'channel 5×22 · 2 reservoirs ×55 · 2 waves ×30 · flood 125' },
  { id: 21, name: 'The Last Distillation', sub: 'Ultimate · distil the battlefield', form: 'venom', tier: 4, slot: 'ult', aim: { kind: 'ground', range: 220, radius: 130 }, cd: 95, cast: 0.3, first: 0.75, total: 850, dur: 14, col: [P.c3, P.v2],
    desc: 'All residue spirals into a rising alchemical chamber of layered liquids, crystals and dark matter. Release the seal, collapse it to one bright droplet, and a multistage catastrophe tears across the arena.', hits: 'pull 6×20 · blast 120 · sheets 2×110 · crystals 140 · vapour 4×27.5 · fragments 4×25 · aftershock 2×20' },
];
const RUN: Record<number, SkillDef['run']> = {};
for (const d of [...defs1, ...defs2, ...defs3, ...defs4]) RUN[d.id] = d.run;
export const SKILLS: SkillDef[] = META.map(m => ({ ...m, run: RUN[m.id] }));
export const SKILL_BY_ID: Record<number, SkillDef> = Object.fromEntries(SKILLS.map(s => [s.id, s]));
export const ULT: Record<'vessel' | 'venom', number> = { vessel: 10, venom: 21 };
export const TIER_NAME = ['', 'T1 · Fast', 'T2 · Utility', 'T3 · High impact', 'T4 · Ultimate'];
export type { SkillDef };
