import { Fx, Hits, Proj, Puff, Ring, type Gfx } from '../fx';
import { P, Rng, TAU, ball, clamp, glow, hash, lerp, mix, nz1, shard, type Col, type Layer, type Mat, type Pal } from '../pixel';
import { PAL } from '../mats';
import { ATK, type DmgKind, type Enemy, type StKey, type World } from '../world';

export const F = 1 / 60;
export function* ticks(sec: number): Generator<number> { const n = Math.max(1, Math.round(sec * 60)); for (let i = 1; i <= n; i++) yield i / n; }

export type AimKind = 'self' | 'dir' | 'cone' | 'ground' | 'target' | 'path' | 'multi' | 'drag';
export interface Aim { kind: AimKind; range: number; radius?: number; width?: number; angle?: number; n?: number }
export interface Cast {
  w: World; id: number; def: SkillDef; ox: number; oy: number; ang: number; tx: number; ty: number;
  target: Enemy | null; targets: Enemy[]; route: { x: number; y: number }[]; rng: Rng;
  d(frac: number): number; dx: number; dy: number;
}
export interface SkillDef {
  id: number; name: string; sub: string; form: 'vessel' | 'venom' | 'trans'; tier: 1 | 2 | 3 | 4; slot: 'basic' | 'ult' | 'trans';
  aim: Aim; cd: number; cast: number; first: number; total: number; desc: string; hits: string; dur: number; col: [Col, Col];
  run: (c: Cast) => Generator<number | void>;
}

export const dist = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);
export const hitE = (c: Cast, e: Enemy, frac: number, o: { kind?: DmgKind; k?: number; ang?: number; from?: [number, number]; stag?: number; at?: [number, number]; big?: boolean; heal?: number; quiet?: boolean } = {}) => {
  let kx = 0, ky = 0;
  if (o.k) {
    let a = o.ang ?? 0;
    if (o.from) a = Math.atan2(e.y - o.from[1], e.x - o.from[0]);
    kx = Math.cos(a) * o.k; ky = Math.sin(a) * o.k;
  }
  return c.w.hit(e, c.d(frac), { kind: o.kind ?? 'impact', src: c.def.id, kx, ky, stagger: o.stag, at: o.at, big: o.big, heal: o.heal, quiet: o.quiet });
};
export function ringAt(c: Cast, x: number, y: number, r1: number, dur: number, frac: number, o: { kind?: DmgKind; knock?: number; stag?: number; cols?: [Col, Col, Col]; w?: number; h?: Hits; max?: number; fill?: boolean; dust?: boolean; r0?: number; ease?: number; cd?: number } = {}) {
  const h = o.h ?? new Hits();
  return c.w.add(new Ring(x, y, r1, dur, { r0: o.r0, w: o.w, cols: o.cols, fill: o.fill, dust: o.dust, ease: o.ease, hit: { h, amt: c.d(frac), opts: { kind: o.kind ?? 'impact', src: c.def.id }, knock: o.knock, stagger: o.stag, max: o.max, cd: o.cd } }));
}
export function visRing(w: World, x: number, y: number, r1: number, dur: number, cols: [Col, Col, Col], wd = 3, o: { fill?: boolean; dust?: boolean; r0?: number } = {}) { return w.add(new Ring(x, y, r1, dur, { w: wd, cols, ...o })); }
export const mkPuffs = (rng: Rng, n: number, R: number, rmin: number, rmax: number, orb: number, sp: number, lay = 0): Puff[] => {
  const a: Puff[] = [];
  for (let i = 0; i < n; i++) { const ang = rng.range(0, TAU), d = Math.sqrt(rng.next()) * R; a.push({ x: Math.cos(ang) * d, y: Math.sin(ang) * d * 0.8, r: rng.range(rmin, rmax), ph: rng.range(0, TAU), sp: rng.range(0.5, sp) * rng.sign(), orb: rng.range(1, orb), lay }); }
  return a;
};

// ---------- flask with sloshing liquid with meniscus and bubbles ----------
export function drawFlask(L: Layer, cx: number, cy: number, r: number, fill: number, tilt: number, liq: [Col, Col, Col, Col], t: number, glass: Pal = PAL.glassHi, bubbles = true) {
  const sd = L.dl;
  L.dl = 7; L.disc(cx, cy, r, glass.b); L.dl = sd;
  const lvl = (1 - fill * 2) * (r - 1);
  const rr = (r - 0.6) * (r - 0.6);
  for (let dx = -Math.floor(r) + 1; dx <= Math.floor(r) - 1; dx += 0.5) {
    const yb = Math.floor(Math.sqrt(Math.max(0, rr - dx * dx)));
    const ys = Math.max(-yb, Math.round(lvl + tilt * dx));
    for (let y = ys; y <= yb; y += 0.5) {
      const d = y - ys, n = nz1((cx + dx) * 0.22 + t * 3, (cy + y) * 0.22 - t * 2) / 255;
      const c = d <= 0.6 ? liq[3] : d < 2.2 ? liq[2] : n > 0.62 ? liq[2] : n > 0.3 ? liq[1] : liq[0];
      L.dot(cx + dx, cy + y, c);
    }
  }
  L.ring(cx, cy, r, 0.9, glass.d);
  L.arc(cx, cy, Math.max(1, r - 0.8), 0.8, Math.PI * 1.08, Math.PI * 1.55, glass.s);
  L.dot(cx + r * 0.52, cy + r * 0.52, glass.l);
  if (bubbles && r > 2.8) for (let i = 0; i < 3; i++) {
    const ph = (t * (0.6 + i * 0.25) + i * 0.37) % 1, bx = cx + Math.sin(i * 2.4 + t) * (r * 0.45), by = cy + r * 0.6 - ph * r * 1.1;
    if (by > cy + lvl + tilt * (bx - cx) + 0.8) L.dot(bx, by, liq[3]);
  }
}
export const LIQ: Record<string, [Col, Col, Col, Col]> = {
  acid: [P.e1, P.e2, P.c0, P.c2], gold: [P.g0, P.g1, P.g2, P.c3], cyan: [P.v0, P.v1, P.v2, P.y2], mag: [P.m0, P.m1, P.m2, P.w], dark: [P.k1, P.e0, P.e1, P.e3], merc: [hexn(0x15484a), hexn(0x4c8f8a), hexn(0xb5e6df), P.w],
};
function hexn(n: number): Col { return (0xff000000 | ((n & 255) << 16) | (n & 0xff00) | ((n >> 16) & 255)) >>> 0; }

// ---------- thrown vessels ----------
export function vialSprite(g: Gfx, x: number, y: number, kind: string, rot: number, a = 0) {
  const L = g.s;
  switch (kind) {
    case 'vial':
      ball(L, x, y, 2.4, PAL.glassHi);
      L.rect(x - 1, y, 3, 2, P.c1);
      L.dot(x - 1, y - 1, P.w);
      L.dot(x + Math.cos(rot) * 3, y + Math.sin(rot) * 3, P.u1);
      break;
    case 'flask':
      ball(L, x, y, 3.2, PAL.glassHi);
      L.rect(x - 2, y, 5, 3, P.c1);
      L.dot(x - 1, y - 1, P.w);
      L.dot(x + Math.cos(rot) * 4, y + Math.sin(rot) * 4, P.u2);
      break;
    case 'seed':
      ball(L, x, y, 2.8, PAL.seed, 3.4);
      L.dot(x, y - 1, P.c2);
      L.dot(x + Math.cos(rot), y + Math.sin(rot), P.e3);
      break;
    case 'cocoon':
      ball(L, x, y, 6.5, PAL.chitin, 8.5);
      for (let i = -1; i <= 1; i++) L.line(x + i * 3, y - 6, x + i * 2, y + 6, P.g1);
      L.dot(x - 2, y - 3, P.c2); L.dot(x + 2, y + 1, P.c2);
      break;
    case 'bead':
      ball(L, x, y, 2.4, PAL.merc);
      L.dot(x - 1, y - 1, P.w);
      break;
    case 'crystal':
      shard(L, x, y, rot, 4.2, 1.8, P.y1, P.v1, P.y2);
      break;
    case 'gold':
      ball(L, x, y, 2.6, PAL.gold);
      L.dot(x - 1, y - 1, P.w);
      L.rect(x - 1, y, 3, 1.2, P.c3);
      break;
    case 'globule': {
      const pu = Math.sin(a * 40) > 0;
      ball(L, x, y, 3.8, PAL.liquid);
      L.disc(x + 1, y + 1, 1.5, P.k0);
      L.dot(x - 2, y - 2, pu ? P.w : P.c3);
      if (pu) L.dot(x + 2, y - 1, P.m2);
      break;
    }
    case 'heavy':
      ball(L, x, y, 3.2, PAL.glass);
      L.rect(x - 2, y, 5, 3, P.e3);
      L.dot(x - 1, y - 1, P.w);
      break;
  }
}
const GLOW: Record<string, Col> = { vial: P.c1, flask: P.c1, seed: P.c2, cocoon: P.g1, bead: P.y1, crystal: P.y1, gold: P.g2, globule: P.c2, heavy: P.c1 };
export function throwArc(w: World, kind: string, x0: number, y0: number, x1: number, y1: number, dur: number, arc: number, onEnd: (w: World, p: Proj) => void, spin = 14) {
  const p = new Proj(x0, y0, x1, y1, dur, arc, (g, x, y, _z, a) => vialSprite(g, x, y, kind, a * spin, a), onEnd, undefined, kind === 'cocoon' ? 6 : 2.5);
  p.lit = (g) => glow(g.l, p.x, p.y - p.z, kind === 'cocoon' ? 9 : 6, GLOW[kind] ?? P.c1, 0.4, 3);
  w.add(p);
  return p;
}
export const handPos = (w: World): [number, number] => { const p = w.player; return [p.x + Math.cos(p.face) * 8, p.y - 7 + Math.sin(p.face) * 5]; };
export function castAnim(w: World, c: Cast, face = true, t = 0.32) { const p = w.player; p.cast = t; p.castMax = t; if (face) p.face = c.ang; }

// ---------- branching fluid network ----------
export interface Branch { pts: { x: number; y: number }[]; cum: number[]; len: number; w: number; start: number; speed: number; drawn: number; seed: number; wm?: number }
export function mkBranch(pts: { x: number; y: number }[], w: number, start: number, speed: number, seed = 1): Branch {
  const cum = [0];
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
  return { pts, cum, len: cum[cum.length - 1], w, start, speed, drawn: 0, seed, wm: 1 };
}
export function wavyPath(x: number, y: number, ang: number, len: number, wob: number, step = 7, seed = 1, curve = 0): { x: number; y: number }[] {
  const pts = [{ x, y }]; let a = ang, px = x, py = y;
  for (let d = step; d <= len; d += step) {
    a += curve * step + (hash(Math.floor(d / step) * 3 + seed * 17) - 0.5) * wob; px += Math.cos(a) * step; py += Math.sin(a) * step * 0.95; pts.push({ x: px, y: py });
  }
  return pts;
}
export class FlowNet extends Fx {
  br: Branch[] = []; discs: { x: number; y: number; r: number }[] = []; wmul = 1; crust = 0; seedN = 1;
  touched = new Set<number>();
  tick?: { every: number; amt: number; opts: { kind?: DmgKind; src: number; stagger?: number }; h: Hits; max?: number; mark?: StKey; markDur?: number; poison?: [number, number, number] };
  onTouch?: (w: World, e: Enemy) => void;
  nt = 0; dash = true; flowK = 1; crustMat?: Mat;
  constructor(public mat: Mat, public life: number) { super(); this.kind = 'flow'; this.resid = true; }
  add(b: Branch) { this.br.push(b); return b; }
  pointAt(b: Branch, d: number) {
    d = clamp(d, 0, b.len); let i = 1; while (i < b.cum.length - 1 && b.cum[i] < d) i++;
    const a = b.pts[i - 1], c = b.pts[i], s = b.cum[i] - b.cum[i - 1] || 1, u = clamp((d - b.cum[i - 1]) / s, 0, 1);
    return { x: lerp(a.x, c.x, u), y: lerp(a.y, c.y, u), ang: Math.atan2(c.y - a.y, c.x - a.x) };
  }
  halfW(b: Branch, d: number, t: number) { const tp = clamp((b.drawn - d) / 12 + 0.45, 0.35, 1); return b.w * (b.wm ?? 1) * this.wmul * tp * (1 + 0.1 * Math.sin(d * 0.25 - t * 4 + b.seed)); }
  covers(x: number, y: number, pad: number): boolean {
    for (const b of this.br) {
      for (let i = 1; i < b.pts.length && b.cum[i - 1] < b.drawn; i++) {
        if (b.cum[i - 1] > b.drawn) break;
        const hw = b.w * (b.wm ?? 1) * this.wmul;
        const bx = b.pts[i].x, by = b.pts[i].y;
        if (Math.abs(bx - x) > hw + pad + 12 || Math.abs(by - y) > hw + pad + 12) continue;
        if (this.segd(x, y, b.pts[i - 1], b.pts[i]) <= hw + pad) return true;
      }
    }
    for (const d of this.discs) if (Math.hypot(x - d.x, y - d.y) < d.r + pad) return true;
    return false;
  }
  private segd(px: number, py: number, a: { x: number; y: number }, b: { x: number; y: number }) {
    const vx = b.x - a.x, vy = b.y - a.y, l2 = vx * vx + vy * vy || 1, t = clamp(((px - a.x) * vx + (py - a.y) * vy) / l2, 0, 1);
    return Math.hypot(px - (a.x + vx * t), py - (a.y + vy * t));
  }
  upd(w: World, dt: number) {
    for (const b of this.br) b.drawn = clamp((this.age - b.start) * b.speed, 0, b.len);
    if (this.age > this.life) { this.dead = true; return; }
    for (const e of w.enemies) {
      if (e.dying > 0 || this.touched.has(e.id)) continue;
      if (this.covers(e.x, e.y, e.r * 0.6)) { this.touched.add(e.id); this.onTouch?.(w, e); }
    }
    const tk = this.tick;
    if (tk) {
      this.nt -= dt;
      if (this.nt <= 0) {
        this.nt += tk.every;
        for (const e of w.enemies) {
          if (e.dying > 0 || !this.covers(e.x, e.y, e.r * 0.5)) continue;
          if (tk.mark) w.mark(e, tk.mark, tk.markDur ?? 2.5, 2);
          if (tk.h.ok(e, w.time, tk.every * 0.9, tk.max ?? Infinity)) { w.hit(e, tk.amt, { ...tk.opts, at: [e.x, e.y] }); if (tk.poison) w.poison(e, tk.poison[0], tk.poison[1], tk.poison[2], tk.opts.src); }
        }
      }
    }
  }
  gnd(g: Gfx) {
    const f = g.f, L = g.s, t = g.t, rem = this.life - this.age, fade = rem < 1 ? Math.max(0.1, rem) : 1;
    const stamp = (extra: number, wmul: number) => {
      for (const b of this.br) {
        if (b.drawn < 1) continue;
        let prev = b.pts[0], pd = 0;
        for (let i = 1; i < b.pts.length; i++) {
          if (b.cum[i - 1] >= b.drawn) break;
          const end = Math.min(b.cum[i], b.drawn);
          const q = end < b.cum[i] ? this.pointAt(b, end) : b.pts[i];
          f.capsule(prev.x, prev.y, q.x, q.y, this.halfW(b, pd, t) * wmul + extra, this.halfW(b, end, t) * wmul + extra);
          prev = q; pd = end;
        }
        const hd = this.pointAt(b, b.drawn);
        if (b.drawn < b.len) f.disc(hd.x, hd.y, b.w * (b.wm ?? 1) * this.wmul * 1.1 * wmul + extra, 0.2);
      }
      for (const d of this.discs) f.disc(d.x, d.y, d.r * wmul + extra, 0.3);
    };
    if (this.crust > 0.02) {
      f.reset(); stamp(this.crust * 2.4, 1);
      f.shade(L, this.crustMat ?? crustMat, t, { dl: Math.round(14 * fade) });
    }
    f.reset(); stamp(0, 1);
    f.shade(L, this.mat, t, { seed: this.seedN, fx: this.mat.fx * this.flowK, dl: fade < 1 ? Math.max(2, Math.round(16 * fade)) : 16 });
    // foaming edges + directional current dashes
    const fl = Math.floor(t * 7);
    for (const b of this.br) {
      for (let d = 3; d < b.drawn; d += 4) {
        const q = this.pointAt(b, d), hw = this.halfW(b, d, t) + 0.5, nx = -Math.sin(q.ang), ny = Math.cos(q.ang);
        for (const s of [-1, 1]) if (hash(Math.floor(d) * 7 + (s > 0 ? 3 : 0) + fl * 13 + b.seed * 31) > 0.45) L.dot(q.x + nx * hw * s, q.y + ny * hw * s, hash(Math.floor(d) + fl) > 0.5 ? this.mat.rimLit : this.mat.rim);
      }
      if (this.dash) for (let k2 = 0; k2 < b.drawn; k2 += 12) {
        const d = (k2 + t * b.speed * 0.25 * this.flowK) % Math.max(14, b.drawn), q = this.pointAt(b, d), off = Math.sin(d * 0.4 + b.seed) * this.halfW(b, d, t) * 0.4;
        L.dot(q.x - Math.sin(q.ang) * off, q.y + Math.cos(q.ang) * off, this.mat.hi);
        L.dot(q.x + Math.cos(q.ang) * 0.8 - Math.sin(q.ang) * off, q.y + Math.sin(q.ang) * 0.8 + Math.cos(q.ang) * off, this.mat.vein);
      }
      if (b.drawn < b.len && b.drawn > 2) { const h = this.pointAt(b, b.drawn); const hw = b.w * this.wmul; if (hash(fl * 5 + b.seed) > 0.3) L.dot(h.x + Math.cos(h.ang) * hw, h.y + Math.sin(h.ang) * hw, this.mat.rimLit); }
    }
  }
  lit(g: Gfx) {
    const rem = this.life - this.age; if (rem < 0) return;
    for (const b of this.br) for (let d = 0; d < b.drawn; d += 16) { const q = this.pointAt(b, d); glow(g.l, q.x, q.y, this.halfW(b, d, g.t) * 1.8, this.mat.ramp[this.mat.ramp.length - 2], 0.1 * clamp(rem, 0, 1), 2); }
    for (const d of this.discs) glow(g.l, d.x, d.y, d.r * 1.6, this.mat.ramp[this.mat.ramp.length - 1], 0.18, 3);
  }
}
const crustMat: Mat = { outline: P.k0, rim: hexn(0x1f5e57), rimLit: P.v0, ramp: [P.k0, hexn(0x0b1f1a), hexn(0x123a30), hexn(0x1f5e57)], hi: P.v0, sh: P.k0, vein: P.k1, vw: 0, dep: 4, sc: 0.3, fx: 0, fy: 0, amp: 0.8, hiT: 0.4, hiW: 3, dl: 16 };
export { mix, glow };
export const rotate = (x: number, y: number, a: number): [number, number] => [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
export const ATKV = ATK;
