import { Cloud, Custom, Decal, Embed, Flash, Fx, Hits, Pool, Proj, Ring, Shot, Splash, chips, drops, dust, shards, steam, type Gfx } from '../fx';
import { BAYER, P, TAU, ball, bubble, clamp, crystalPrism, glow, hash, lerp, mix, nz1, smooth, wormBody, type Col, type Seg } from '../pixel';
import { MAT, PAL, VAP } from '../mats';
import type { Enemy, World } from '../world';
import { F, FlowNet, castAnim, handPos, hitE, mkBranch, mkPuffs, ringAt, throwArc, ticks, visRing, wavyPath, type Branch, type Cast, type SkillDef } from './lib';
import { plume } from './s2';
import { Cluster } from './s3';

const alive = (e: Enemy | null | undefined): e is Enemy => !!e && e.dying <= 0;

// =============== 17 REVERSE EXTRACTION ===============
function* extraction(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c, true, 0.5);
  const dx = Math.cos(c.ang), dy = Math.sin(c.ang);
  yield 0.04;
  const vx = clamp(p.x + dx * 78, 30, w.W - 30), vy = clamp(p.y + dy * 78, 34, w.H - 24), R = 74;
  const pull = new Hits(), wave = new Hits(), res = new Hits();
  const vort = { k: 0, core: 0, spin: 0, collapse: 0 };
  w.add(new Custom(vx, vy, 6, {
    gnd: (g, _a, f) => {
      const L = g.s, fld = g.f, t = g.t, k = vort.k * (1 - vort.collapse);
      if (k < 0.02) return;
      fld.reset();
      for (let arm = 0; arm < 4; arm++) { let pv: [number, number] | null = null; for (let i = 0; i <= 15; i++) { const u = i / 15, an = arm * 1.571 + u * 4.6 * (1 - vort.collapse * 0.5) - t * (4 + vort.spin * 3), rr = (5 + u * u * R * 0.62 + u * 12) * k, X = vx + Math.cos(an) * rr, Y = vy + Math.sin(an) * rr * 0.9; if (pv) fld.capsule(pv[0], pv[1], X, Y, (4.2 - u * 3) * k + 0.6, (4.2 - (u + 1 / 15) * 3) * k + 0.6); pv = [X, Y]; } }
      fld.disc(vx, vy, 11 * k, 0.2);
      fld.shade(L, MAT.acid, t, { fx: -16, fy: 8, seed: 2 });
      fld.reset(); fld.disc(vx, vy, (3 + vort.core * 9) * k, 0); fld.shade(L, MAT.ink, t, { fx: 5, fy: 2 });
      for (let i = 0; i < 18; i++) { const an = i * 0.35 - t * 6 + i, rr = (14 + (i % 6) * 5) * k; L.px(Math.round(vx + Math.cos(an) * rr), Math.round(vy + Math.sin(an) * rr * 0.9), i % 3 ? P.c3 : P.g2); }
      void f;
    },
    lit: (g) => glow(g.l, vx, vy, 30 * vort.k * (1 - vort.collapse * 0.6), P.c1, 0.25 + vort.core * 0.3, 4),
  }));
  const feed = (cnt: number, mult = 1) => {
    const res_ = w.fx.filter(f => f.resid && Math.hypot(f.x - vx, f.y - vy) < 150);
    for (let i = 0; i < cnt; i++) {
      const src = res_.length && c.rng.next() < 0.7 ? res_[c.rng.int(res_.length)] : null;
      const a0 = src ? Math.atan2(src.y - vy, src.x - vx) : c.rng.range(0, TAU), r0 = src ? Math.hypot(src.x - vx, src.y - vy) : c.rng.range(62, 105), sp = c.rng.range(0.9, 1.3) * mult;
      w.parts.add({ k: 'drop', x: vx, y: vy, z: 2, max: 0.9 / sp, size: c.rng.range(1, 3.5) | 0, c1: P.c1, c2: P.c3, c3: P.e2, glow: 1, fn: (q) => { const u = q.age / q.max, rr = r0 * Math.pow(1 - u, 1.4), an = a0 + u * u * 6.5 + u * 1.5; q.x = vx + Math.cos(an) * rr; q.y = vy + Math.sin(an) * rr * 0.9; q.z = 2 + Math.sin(u * Math.PI) * 7 * (1 - u); } });
    }
    for (const f of res_) { const d = Math.hypot(f.x - vx, f.y - vy); if (d < 7) { f.dead = true; w.add(new Splash(vx, vy, 5, P.c1, P.c3)); } else { const s = (2.2 + vort.k * 2) / 60 * 60 / 60; f.x += (vx - f.x) * s * 0.08; f.y += (vy - f.y) * s * 0.08; } }
  };
  // the vortex forms and draws the battlefield in
  let tm = 0, nt = 0, healAcc = 0;
  for (; tm < 2.1; tm += F) {
    vort.k = smooth(tm / 0.4); vort.core = smooth(tm / 1.8); vort.spin = tm / 2;
    if (Math.floor(tm * 60) % 3 === 0) feed(2 + Math.floor(tm));
    nt -= F;
    for (const e of w.enemies) {
      if (e.dying > 0) continue;
      const ex = vx - e.x, ey = vy - e.y, d = Math.hypot(ex, ey);
      if (d < R + e.r && d > 5) { const s = (26 + 34 * (1 - d / R)) * F * (e.kind === 'boss' ? 0.2 : e.kind === 'elite' ? 0.6 : 1); e.x += ex / d * s; e.y += ey / d * s; if (e.st.corrode === undefined) w.mark(e, 'corrode', 0.5, 1); }
      if (nt <= 0 && tm > 0.25 && d < R * 0.8 && pull.ok(e, w.time, 0.4, 4)) { hitE(c, e, 25, { kind: 'acid', stag: 0.12, heal: 0.06, at: [e.x, e.y] }); healAcc++; w.parts.add({ k: 'mote', x: e.x, y: e.y, z: 6, max: 0.5, c1: P.c2, c2: P.c1, glow: 1, fn: (q) => { const u = q.age / q.max; q.x = lerp(e.x, p.x, u); q.y = lerp(e.y, p.y - 6, u) - Math.sin(u * Math.PI) * 10; } }); }
    }
    if (nt <= 0) nt = 0.4;
    yield F;
  }
  // everything is drawn into a small vessel
  const [hx, hy] = handPos(w); p.cast = 0.8; p.castMax = 0.8;
  w.add(new Custom(vx, vy, 0.5, { air: (g, a) => {
    const L = g.s, t = g.t;
    for (let s = 0; s < 3; s++) { const pts: Seg[] = []; for (let i = 0; i < 14; i++) { const u = i / 13, tt = clamp(u + a * 0.2, 0, 1), X = lerp(vx, hx, tt) + Math.sin(u * 6 + s * 2 + t * 10) * 7 * (1 - tt) * (1 - a), Y = lerp(vy, hy, tt) + Math.cos(u * 5 + s) * 5 * (1 - tt) - Math.sin(tt * Math.PI) * 8; pts.push({ x: X, y: Y, r: (2.4 - u * 1.4) * (1 - a * 0.5) }); } L.dl = 13; wormBody(L, pts, PAL.liquid, { stripe: P.c3, stripeT: t }); L.dl = 16; }
  } }));
  for (const k of ticks(0.5)) { vort.collapse = smooth(k); vort.core = 1; if (Math.floor(k * 60) % 2 === 0) feed(2, 1.7); yield F; }
  vort.k = 0;
  // compressed vessel: impossible concentration of liquid and light
  const hold = w.add(new Custom(hx, hy, 0.4, { air: (g, a) => { const L = g.s, [X, Y] = handPos(w); ball(L, X, Y - 3, 3.2, PAL.glassHi); L.disc(X, Y - 3, 2, P.w); const r = 2 + Math.sin(a * 40) * 0.6; L.ring(X, Y - 3, 4 + a * 3, 1, P.c3); L.px(Math.round(X), Math.round(Y - 3), P.c2); void r; for (let i = 0; i < 6; i++) { const an = i * 1.05 + g.t * 8; L.px(Math.round(X + Math.cos(an) * (7 - a * 4)), Math.round(Y - 3 + Math.sin(an) * (7 - a * 4)), P.c3); } }, lit: (g, a) => { const [X, Y] = handPos(w); glow(g.l, X, Y - 3, 12 + a * 14, P.w, 0.6, 5); } }));
  void hold; yield 0.4;
  // violent directional burst
  const [ox, oy] = [p.x, p.y];
  w.screenFlash(P.c3, 0.5, 0.18); w.shake(6, 0.45); w.shock(ox + dx * 24, oy + dy * 24, 80, 0.4, 3.5);
  const reach = 200, start = w.time, sp = 420;
  const ang = c.ang;
  const front = () => Math.min(reach, (w.time - start) * sp + 8), hw = (d: number) => 9 + d * 0.3;
  w.add(new Custom(ox, oy, 2.2, {
    gnd: (g, _a, f) => {
      const fr = front(), fld = g.f, L = g.s, t = g.t; fld.reset();
      const fade = f.age > 1.4 ? clamp((2.2 - f.age) / 0.8, 0.1, 1) : 1;
      for (let layer = 0; layer < 3; layer++) { let pv: [number, number] | null = null; for (let d = 6; d <= fr; d += 7) { const off = Math.sin(d * 0.07 + t * 5 + layer * 2) * (layer ? 3.5 : 0) * (1 + d * 0.01), X = ox + dx * d - dy * off, Y = oy + dy * d + dx * off, r = hw(d) * (1 - layer * 0.28) * clamp((fr - d) / 14 + 0.5, 0.45, 1); if (pv) fld.capsule(pv[0], pv[1], X, Y, r, r); pv = [X, Y]; } }
      const hd = hw(fr); fld.disc(ox + dx * fr, oy + dy * fr, hd * 1.0, 0.25);
      fld.shade(L, MAT.acid, t, { fx: 60, fy: 5, dl: Math.round(16 * fade), seed: 4 });
      for (let d = 10; d < fr; d += 5) { const h = hw(d); for (const s of [-1, 1]) if (hash(Math.floor(d) * 3 + Math.floor(t * 8) + (s > 0 ? 9 : 0)) > 0.5) L.px(Math.round(ox + dx * d - dy * h * s), Math.round(oy + dy * d + dx * h * s), P.c3); }
    },
    lit: (g, a) => { const fr = front(); for (let d = 10; d < fr; d += 24) glow(g.l, ox + dx * d, oy + dy * d, hw(d) * 1.6, P.c1, 0.16 * (1 - a), 3); },
  }));
  const hit = new Set<number>(); let lastPool = 0;
  for (let t2 = 0; t2 < 0.55; t2 += F) {
    const fr = front();
    for (const e of w.enemies) {
      if (e.dying > 0 || hit.has(e.id)) continue;
      const rx = e.x - ox, ry = e.y - oy, along = rx * dx + ry * dy, lat = Math.abs(-rx * dy + ry * dx);
      if (along > -4 && along - e.r < fr && lat < hw(Math.max(0, along)) + e.r) { hit.add(e.id); if (wave.ok(e, w.time)) { hitE(c, e, 140, { kind: 'acid', k: 200, ang, stag: 0.5, big: true, heal: 0.04, at: [e.x, e.y] }); drops(w, e.x, e.y, 10, 90, P.c1, P.c3, P.e2, { z: 6, glow: 1, ang, spread: 2 }); w.mark(e, 'corrode', 3, 2); } }
    }
    while (lastPool + 30 < fr) { lastPool += 30; const X = ox + dx * lastPool + c.rng.range(-8, 8), Y = oy + dy * lastPool + c.rng.range(-8, 8); w.add(new Pool(X, Y, 9 + c.rng.range(0, 3), MAT.acid, 5.5, { blobs: 4, boil: 1.4, grow: 0.3, tick: { every: 0.9, amt: c.d(22.5), opts: { kind: 'acid', src: c.def.id }, h: res, max: 2 } })); w.add(new Decal(X, Y, 'pits', 8, 5, Math.floor(X * 3), { a: P.k0, b: P.e3, c: P.c1 }, 0, 1)); }
    if (Math.floor(t2 * 60) % 2 === 0) { const d = fr, h = hw(d); drops(w, ox + dx * d, oy + dy * d, 3, 110, P.c1, P.c3, P.e2, { z: 6, up: 90, glow: 1, ang, spread: 1.4 }); chips(w, ox + dx * d - dy * h, oy + dy * d + dx * h, 1, 60, P.k3, P.k1, P.e1, { z: 5 }); }
    yield F;
  }
  void healAcc; yield 1.5;
}

// =============== 18 BITTER RAIN ===============
function* rain(c: Cast) {
  const w = c.w; castAnim(w, c);
  const cx = c.tx, cy = c.ty, R = 86;
  yield 0.05;
  const [hx, hy] = handPos(w);
  const big = new Hits(), small = new Hits(), col = new Hits(), pud = new Hits();
  const puddles: { x: number; y: number; r: number; t0: number }[] = [];
  let boil = 0;
  // glowing puddle network
  const netFx = w.add(new Custom(cx, cy, 11, {
    gnd: (g, _a, f) => {
      const fld = g.f, L = g.s; if (!puddles.length) return; fld.reset();
      for (const q of puddles) { const k = smooth((g.t - q.t0) / 0.3); fld.disc(q.x, q.y, q.r * k * (1 + boil * 0.12 * Math.sin(g.t * 9 + q.x)), 0.3); }
      for (let i = 0; i < puddles.length; i++) for (let j = i + 1; j < puddles.length; j++) { const a = puddles[i], b = puddles[j], d = Math.hypot(a.x - b.x, a.y - b.y); if (d < 30) fld.capsule(a.x, a.y, b.x, b.y, 1.4 + boil * 0.8, 1.4 + boil * 0.8); }
      const rem = f.life - f.age;
      fld.shade(L, MAT.acid, g.t, { fx: 5 + boil * 18, fy: 3, dl: rem < 1 ? Math.max(2, Math.round(16 * rem)) : 16, seed: 6 });
    },
    lit: (g) => { for (let i = 0; i < puddles.length; i += 2) glow(g.l, puddles[i].x, puddles[i].y, puddles[i].r * 1.5, P.c1, 0.1 + boil * 0.2, 2); },
  }));
  netFx.resid = true; netFx.kind = 'pool';
  const addPuddle = (x: number, y: number, r: number) => { puddles.push({ x, y, r, t0: w.time }); if (puddles.length > 70) puddles.shift(); };
  // vessels follow readable arcs; their ground shadows show where they will land
  const targets: [number, number][] = [[0, 0], [-40, -14], [38, -18], [-26, 30], [30, 28]];
  targets.forEach(([dx, dy], i) => {
    const ex = clamp(cx + dx, 14, w.W - 14), ey = clamp(cy + dy, 20, w.H - 12);
    const pr = new Proj(hx, hy, ex, ey, 0.46 + i * 0.03, 120, (g, x, y, _z, a) => { vialS(g, x, y, a, i); }, () => 0, undefined, 3);
    pr.lit = (g) => glow(g.l, pr.x, pr.y - pr.z, 7, P.c1, 0.4, 3);
    w.add(pr);
    w.add(new Custom(ex, ey, 0.5 + i * 0.03, { gnd: (g, a) => { const L = g.s; L.dl = 8; L.ring(ex, ey, 7 + Math.sin(a * 20) * 1, 1, P.c1); L.dl = 5; L.disc(ex, ey, 6, P.k0); L.dl = 16; } }));
    w.run((function* () {
      yield (0.46 + i * 0.03) * 0.62;
      const bx = pr.x, by = pr.y, bz = pr.z; pr.dead = true;
      w.add(new Flash(bx, by - bz, 12, P.c2, 0.3, 0)); drops(w, bx, by, 16, 70, P.c1, P.c3, P.e2, { z: bz, up: 20, glow: 1 }); shards(w, bx, by, 6, 60, P.v2, P.v1, P.y2, { z: bz, size: [2, 4], land: 1 });
    })());
  });
  yield 0.22;
  // suspended clouds of poisonous droplets
  const cl1 = new Cloud(cx, cy, mkPuffs(c.rng, 14, 52, 16, 24, 6, 1.2, 0), VAP.dark, 3.6, c.id); cl1.heightOff = 66; cl1.grow = { from: 0.3, to: 1.1, dur: 0.6 }; cl1.dens = 11;
  const cl2 = new Cloud(cx, cy, mkPuffs(c.rng, 10, 44, 12, 19, 6, 1.4, 1), VAP.green, 3.6, c.id + 1); cl2.heightOff = 70; cl2.grow = { from: 0.3, to: 1.1, dur: 0.6 }; cl2.dens = 9;
  w.add(cl1); w.add(cl2); w.shake(2.5, 0.3); w.shock(cx, cy - 40, 80, 0.4, 2);
  const landDrop = (x: number, y: number, rad: number, pct: number, hh: Hits, cap: number, puddleR: number) => {
    for (const e of w.enemies) { if (e.dying > 0) continue; if (Math.hypot(e.x - x, e.y - y) < e.r + rad && hh.ok(e, w.time, 0, cap)) { hitE(c, e, pct, { kind: 'acid', k: pct > 10 ? 60 : 20, from: [x, y], stag: pct > 10 ? 0.25 : 0.06, at: [e.x, e.y - e.r * 0.6] }); drops(w, e.x, e.y, pct > 10 ? 7 : 2, 60, P.c1, P.c3, P.e2, { z: 6, glow: 1 }); w.mark(e, 'wet', 1.5); } }
    if (puddleR > 0) { addPuddle(x, y, puddleR); w.add(new Splash(x, y, puddleR * 0.9, P.c1, P.c3)); if (puddleR > 4) { visRing(w, x, y, puddleR + 4, 0.2, [P.c3, P.c1, P.e2], 1); drops(w, x, y, 4, 40, P.c1, P.c3, P.e2, { z: 2, up: 50, glow: 1 }); } }
  };
  const drop = (x: number, y: number, z: number, sz: number, bigDrop: boolean) => {
    w.add(new Shot(x, y, z, c.rng.range(-3, 3), c.rng.range(-3, 3), -75 - c.rng.range(0, 50), 240, bigDrop ? 6 : 3,
      (g, X, Y, _z, s) => { const L = g.s; for (let i = 1; i <= (bigDrop ? 4 : 2); i++) { L.dl = 12 - i * 2; L.px(Math.round(X), Math.round(Y - i * 2), P.e3); } L.dl = 16; if (sz >= 4) { L.disc(X, Y, 2, P.e2); L.disc(X - 0.4, Y - 0.4, 1.4, P.c1); L.px(Math.round(X - 1), Math.round(Y - 1), P.c3); } else if (sz >= 2) { L.rect(Math.round(X), Math.round(Y), 2, 2, P.c1); L.px(Math.round(X), Math.round(Y), P.c3); } else L.px(Math.round(X), Math.round(Y), P.c2); void s; },
      (ww, s, e) => { if (big.n(e) >= 3 && bigDrop) return false; if (!bigDrop && small.n(e) >= 10) return false; landDrop(s.x, s.y, 0, 0, bigDrop ? big : small, 0, 0); if ((bigDrop ? big : small).ok(e, ww.time, 0, bigDrop ? 3 : 10)) { hitE(c, e, bigDrop ? 30 : 6, { kind: 'acid', k: bigDrop ? 70 : 20, from: [s.x, s.y], stag: bigDrop ? 0.25 : 0.06, at: [e.x, e.y - e.r * 0.8] }); drops(ww, e.x, e.y, bigDrop ? 7 : 2, 60, P.c1, P.c3, P.e2, { z: 8, glow: 1 }); ww.add(new Splash(e.x, e.y, bigDrop ? 8 : 4, P.c1, P.c3)); } return true; },
      (ww, s) => { landDrop(s.x, s.y, bigDrop ? 6 : 3, bigDrop ? 0 : 0, bigDrop ? big : small, bigDrop ? 3 : 10, bigDrop ? 5 + c.rng.range(0, 3) : sz > 1 ? 2.5 : 0); void ww; }, 3, 12));
  };
  // large drops fall first, then turbulent clusters of small ones
  w.run((function* () {
    for (let i = 0; i < 26; i++) { const a = c.rng.range(0, TAU), d = Math.sqrt(c.rng.next()) * R * 0.95; drop(cx + Math.cos(a) * d, cy + Math.sin(a) * d * 0.85, 66, 4, true); yield 0.035; }
  })());
  yield 0.25;
  w.run((function* () {
    for (let k = 0; k < 14; k++) { const a = c.rng.range(0, TAU), d = c.rng.range(0, R * 0.8), ccx = cx + Math.cos(a) * d, ccy = cy + Math.sin(a) * d * 0.85; for (let i = 0; i < 6; i++) drop(ccx + c.rng.range(-9, 9), ccy + c.rng.range(-7, 7), 60 + c.rng.range(0, 12), c.rng.next() < 0.4 ? 2 : 1, false); yield 0.11; }
  })());
  // puddle network deals damage over time
  const t0 = w.time; let nt = 0.2;
  const p = w.player; let moved = false;
  while (w.time - t0 < 3.2) {
    nt -= F;
    if (nt <= 0) { nt = 0.8; for (const e of w.enemies) { if (e.dying > 0) continue; if (puddles.some(q => Math.hypot(e.x - q.x, e.y - q.y) < q.r * 0.9 + e.r * 0.4 && w.time - q.t0 > 0.3)) { w.mark(e, 'corrode', 1.8, 1); if (pud.ok(e, w.time, 0.7, 3)) hitE(c, e, 20, { kind: 'acid', stag: 0.08, at: [e.x, e.y] }); } } }
    if (w.time - t0 > 1.8 && !moved) { moved = true; const a0 = Math.atan2(p.y - cy, p.x - cx), pts: { x: number; y: number }[] = []; for (let i = 1; i <= 6; i++) pts.push({ x: cx + Math.cos(a0 + i * 0.4) * (R + 14), y: cy + Math.sin(a0 + i * 0.4) * (R + 14) * 0.85 }); w.glide(pts, 1.1); }
    boil = clamp((w.time - t0 - 2.0) / 1.2, 0, 1);
    if (boil > 0 && Math.floor(w.time * 60) % 2 === 0 && puddles.length) { const q = puddles[c.rng.int(puddles.length)]; w.parts.add({ k: 'bubble', x: q.x + c.rng.range(-q.r, q.r) * 0.6, y: q.y, z: 0, vz: c.rng.range(14, 32), max: c.rng.range(0.5, 1), size: c.rng.range(1.5, 3.2), c1: P.e3, c2: P.c1, c3: P.c3 }); }
    yield F;
  }
  // puddles boil and throw up towering columns of luminous vapour
  w.screenFlash(P.c2, 0.2, 0.1);
  const cols: { x: number; y: number }[] = [];
  const cand = puddles.slice().sort((a, b) => hash(a.x * 7 + a.y) - hash(b.x * 7 + b.y));
  for (const q of cand) { if (cols.length >= 3) break; if (cols.every(o => Math.hypot(o.x - q.x, o.y - q.y) > 38)) cols.push({ x: q.x, y: q.y }); }
  while (cols.length < 3) cols.push({ x: cx + c.rng.range(-50, 50), y: cy + c.rng.range(-40, 40) });
  for (let i = 0; i < cols.length; i++) {
    const q = cols[i];
    ringAt(c, q.x, q.y, 28, 0.26, 53.33, { kind: 'burst', knock: 140, stag: 0.45, h: col, max: 3, cols: [P.w, P.c2, P.e2], w: 3 });
    plume(w, q.x, q.y, 70, 2.0, VAP.pale, 13, i + 3); plume(w, q.x + 4, q.y + 2, 54, 1.8, VAP.green, 15, i + 8, 0.05);
    w.add(new Custom(q.x, q.y, 1.6, { up: (g, a) => { const L = g.s, h = 56 * smooth(Math.min(1, a * 4)); L.dl = Math.round(12 * (1 - a)); L.rect(Math.round(q.x) - 1, Math.round(q.y - h), 3, Math.round(h), P.c3); L.dl = 16; }, lit: (g, a) => { for (let k = 0; k < 4; k++) glow(g.l, q.x, q.y - 14 * k * smooth(Math.min(1, a * 4)), 10, P.c2, 0.25 * (1 - a), 3); } }, q.y + 4));
    drops(w, q.x, q.y, 22, 110, P.c1, P.c3, P.e2, { z: 6, up: 190, glow: 2, size: [2, 4] }); chips(w, q.x, q.y, 5, 80, P.k3, P.k1, P.e1, { z: 8, up: 150, size: [2, 4] });
    w.add(new Flash(q.x, q.y - 6, 18, P.c3, 0.3, 4)); w.shake(3.5, 0.25); w.shock(q.x, q.y, 50, 0.3, 2.5);
    yield 0.28;
  }
  boil = 1; yield 1.8;
  boil = 0;
}
function vialS(g: Gfx, x: number, y: number, a: number, i: number) { const L = g.s, X = Math.round(x), Y = Math.round(y); ball(L, X, Y, 2.8, PAL.glassHi); L.rect(X - 2, Y, 5, 2, i % 2 ? P.c1 : P.c2); L.px(X - 1, Y - 1, P.w); L.rect(X - 1, Y - 5, 3, 2, P.u1); if (Math.sin(a * 30 + i) > 0.3) L.px(X + 3, Y - 2, P.c3); }

// =============== 19 FALSE REMEDY ===============
function* remedy(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c);
  yield 0.04;
  const tgt = c.target ?? w.nearest(c.tx, c.ty, 110);
  if (!tgt) return;
  const [hx, hy] = handPos(w), dur = clamp(Math.hypot(tgt.x - hx, tgt.y - hy) / 520, 0.1, 0.24);
  throwArc(w, 'gold', hx, hy, tgt.x, tgt.y, dur, 10, () => 0, 12);
  yield dur;
  const rup = new Hits();
  hitE(c, tgt, 40, { kind: 'acid', k: 40, from: [hx, hy], stag: 0.25, at: [tgt.x, tgt.y] });
  const st = { k: 0, shrink: 0, imp: 0 }; const cx0 = tgt.x, cy0 = tgt.y;
  w.add(new Flash(tgt.x, tgt.y - 6, 16, P.g2, 0.3, 0)); drops(w, tgt.x, tgt.y, 12, 60, P.g2, P.c3, P.c1, { z: 8, glow: 1 });
  const seeds = Array.from({ length: 11 }, (_, i) => ({ a: hash(i * 5 + c.id) * TAU, d: 4 + hash(i * 9 + c.id) * 22 }));
  const veins: { a: number; len: number; ph: number }[] = Array.from({ length: 7 }, (_, i) => ({ a: (i / 7) * TAU + 0.2, len: 16 + hash(i + c.id) * 14, ph: i }));
  w.add(new Custom(cx0, cy0, 6, {
    gnd: (g, a, f) => {
      const L = g.s, t = g.t, e = tgt, cx = alive(e) ? e.x : cx0, cy = alive(e) ? e.y : cy0, k = st.k, sc = (1 - st.shrink) * smooth(Math.min(1, f.age * 4)), R = 28 * sc * (1 - k * 0.25);
      if (sc < 0.04) return;
      const pts = seeds.map(s => ({ x: cx + Math.cos(s.a + t * 0.3 * (1 - k)) * s.d * sc * (1 - k * 0.45), y: cy + Math.sin(s.a + t * 0.3 * (1 - k)) * s.d * 0.85 * sc * (1 - k * 0.45) }));
      const wall = mix(P.g2, P.e2, k), wall2 = mix(P.c3, P.k1, k), inner = mix(P.g1, P.e0, k);
      for (let y = Math.floor(cy - R); y <= cy + R; y++) for (let x = Math.floor(cx - R); x <= cx + R; x++) {
        const ddx = x - cx, ddy = (y - cy) / 0.85, rr = Math.hypot(ddx, ddy);
        if (rr > R) continue;
        let d1 = 1e9, d2 = 1e9;
        for (const q of pts) { const d = Math.hypot(x - q.x, (y - q.y) / 0.85); if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d; }
        const edge = d2 - d1;
        if (BAYER[((y & 3) << 2) | (x & 3)] > 16 - (rr / R) * 10 - 2) continue;
        if (edge < 1.7) L.px(x, y, rr > R - 1.5 ? wall2 : wall);
        else if (BAYER[((y & 3) << 2) | (x & 3)] < 6) L.px(x, y, inner);
      }
      if (k > 0.15) for (const v of veins) { let vx = cx, vy = cy, an = v.a; const len = v.len * Math.min(1, (k - 0.15) * 1.6) * sc; for (let s = 0; s < len; s++) { an += (hash(s + v.ph * 9) - 0.5) * 0.7; vx += Math.cos(an); vy += Math.sin(an) * 0.85; L.px(Math.round(vx), Math.round(vy), P.k0); L.px(Math.round(vx), Math.round(vy) + 1, P.m0); if (Math.sin(t * 5 - s * 0.5 + v.ph) > 0.4) L.px(Math.round(vx), Math.round(vy), P.c1); } }
      if (k < 0.3) for (let i = 0; i < 4; i++) { const sx = Math.round(cx + Math.cos(i * 1.7 + t) * 14), sy = Math.round(cy - ((t * 12 + i * 8) % 22)); L.rect(sx - 1, sy, 3, 1, P.c3); L.rect(sx, sy - 1, 1, 3, P.c3); }
      void a;
    },
    lit: (g) => { const e = tgt; if (alive(e)) glow(g.l, e.x, e.y - 4, 22 * (1 - st.shrink), mix(P.g2, P.c1, st.k), 0.28 * (1 - st.k * 0.4), 4); },
  }));
  // it looks restorative for a moment…
  w.mark(tgt, 'remedy', 6, 0);
  for (const _k of ticks(0.7)) { void _k; if (alive(tgt)) w.mark(tgt, 'remedy', 6, 0); yield F; }
  // …then its internal structure changes
  const T0 = w.time; let poisoned = false, moved = false, thrown = false;
  while (w.time - T0 < 1.5) {
    const k = clamp((w.time - T0) / 0.8, 0, 1); st.k = smooth(k);
    if (alive(tgt)) w.mark(tgt, 'remedy', 6, st.k);
    if (k > 0.4 && !poisoned) { poisoned = true; if (alive(tgt)) w.poison(tgt, c.d(120), 3, c.id, c.def.id); }
    if (w.time - T0 > 0.55 && !moved) { moved = true; const a = c.ang + Math.PI; w.glide([{ x: p.x + Math.cos(a) * 40, y: p.y + Math.sin(a) * 40 }], 0.35); }
    if (w.time - T0 > 1.0 && !thrown) { thrown = true; w.run((function* () { castAnim(w, c, false, 0.3); p.face = Math.atan2(tgt.y - p.y, tgt.x - p.x); yield 0.08; const [x1, y1] = handPos(w); throwArc(w, 'vial', x1, y1, alive(tgt) ? tgt.x : cx0, alive(tgt) ? tgt.y : cy0, 0.3, 14, () => 0, 16); })()); }
    yield F;
  }
  yield 0.12;
  const X = alive(tgt) ? tgt.x : cx0, Y = alive(tgt) ? tgt.y : cy0;
  for (const k of ticks(0.28)) { st.shrink = smooth(k) * 0.85; if (Math.floor(k * 60) % 2 === 0) for (let i = 0; i < 2; i++) { const a = c.rng.range(0, TAU); w.parts.add({ k: 'mote', x: X + Math.cos(a) * 24, y: Y + Math.sin(a) * 18, z: 4, max: 0.25, c1: P.c1, c2: P.e3, glow: 1, fn: (q) => { const u = q.age / q.max; q.x = lerp(X + Math.cos(a) * 24, X, u); q.y = lerp(Y + Math.sin(a) * 18, Y, u); } }); } yield F; }
  st.shrink = 1;
  w.hitstop = 0.04; w.screenFlash(P.c1, 0.3, 0.14); w.shake(6, 0.4); w.shock(X, Y, 70, 0.4, 3);
  ringAt(c, X, Y, 40, 0.3, 135, { kind: 'burst', knock: 170, stag: 0.5, h: rup, cols: [P.c3, P.e3, P.k1], w: 4, dust: false });
  w.add(new Flash(X, Y - 6, 26, P.c2, 0.3, 4));
  w.add(new Pool(X, Y, 26, MAT.rot, 4.5, { blobs: 6, boil: 1.2, grow: 0.2 })); w.add(new Pool(X + 5, Y - 2, 17, MAT.venom, 4.2, { blobs: 5, boil: 1.4, grow: 0.25 })); w.add(new Pool(X - 4, Y + 3, 10, MAT.acid, 3.8, { blobs: 4, boil: 1.4, grow: 0.3 }));
  shards(w, X, Y, 18, 150, P.c0, P.e1, P.c3, { z: 8, up: 160, land: 2, size: [3, 7] }); shards(w, X, Y, 8, 110, P.m2, P.m0, P.w, { z: 8, up: 130, land: 2, size: [2, 4] });
  drops(w, X, Y, 30, 130, P.e3, P.c1, P.k1, { z: 8, up: 130, size: [2, 4], glow: 1 });
  const cl = new Cloud(X, Y, mkPuffs(c.rng, 8, 16, 10, 15, 6, 1.8), VAP.dark, 3, c.id); cl.grow = { from: 0.4, to: 1.8, dur: 1 }; cl.dens = 12; w.add(cl);
  plume(w, X, Y, 34, 1.2, VAP.green, 11, 4);
  if (alive(tgt)) delete tgt.st.remedy;
  for (const e of w.enemies) if (e.st.remedy && e !== tgt) delete e.st.remedy;
  yield 1.5;
}

// =============== 20 PLAGUE CARTOGRAPHY ===============
class Pulse extends Fx {
  hit = new Set<number>();
  constructor(public b: Branch, public net: FlowNet, public d0: number, public dir: number, public cc: Cast, public wh: Hits) { super(); this.kind = 'pulse'; this.update_(); }
  d = 0; update_() { this.d = this.d0; }
  upd(w: World) {
    this.d += this.dir * 230 * (1 / 60);
    if (this.d < 0 || this.d > this.b.len) { this.dead = true; return; }
    const q = this.net.pointAt(this.b, this.d); this.x = q.x; this.y = q.y;
    for (const e of w.enemies) { if (e.dying > 0 || this.hit.has(e.id)) continue; if (Math.hypot(e.x - q.x, e.y - q.y) < 10 + e.r * 0.6 && this.wh.ok(e, w.time, 0, 2)) { this.hit.add(e.id); hitE(this.cc, e, 30, { kind: 'acid', k: 80, ang: q.ang, stag: 0.3, at: [e.x, e.y] }); drops(w, e.x, e.y, 6, 60, P.c1, P.c3, P.e2, { z: 5, glow: 1 }); } }
    if (Math.floor(this.age * 60) % 2 === 0) w.parts.add({ k: 'drop', x: q.x, y: q.y, z: 3, vx: 0, vy: 0, vz: 30, grav: 160, size: 1, c1: P.c3, c2: P.w, c3: P.c1, land: 1, max: 0.6, glow: 1 });
  }
  gnd(g: Gfx) { const L = g.s; L.dl = 12; L.disc(this.x, this.y, 5, P.c1); L.dl = 16; L.disc(this.x, this.y, 3, P.c3); L.px(Math.round(this.x), Math.round(this.y), P.w); }
  lit(g: Gfx) { glow(g.l, this.x, this.y, 12, P.c2, 0.4, 3); }
}
function* cartography(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c, true, 0.3);
  let route = c.route.length >= 2 ? c.route.slice(0, 7) : [];
  if (route.length < 2) {
    const cx = c.tx, cy = c.ty, r = 70, a0 = c.ang;
    const idx = [0, 2, 4, 1, 3];
    route = idx.map(i => ({ x: clamp(cx + Math.cos(a0 + (i / 5) * TAU) * r, 16, w.W - 16), y: clamp(cy + Math.sin(a0 + (i / 5) * TAU) * r * 0.85, 22, w.H - 14) }));
  }
  route = route.map(q => ({ x: clamp(q.x, 14, w.W - 14), y: clamp(q.y, 20, w.H - 12) }));
  const closing = route[0];
  const net = new FlowNet(MAT.verd, 12), chan = new Hits(), res = new Hits(), wv = new Hits(), flood = new Hits();
  net.onTouch = (ww, e) => { if (chan.ok(e, ww.time, 0.36, 5)) { hitE(c, e, 22, { kind: 'acid', k: 40, from: [p.x, p.y], stag: 0.15, at: [e.x, e.y] }); ww.mark(e, 'corrode', 2.2, 2); } };
  net.tick = { every: 0.4, amt: c.d(22), opts: { kind: 'acid', src: c.def.id, stagger: 0.08 }, h: chan, max: 5, mark: 'corrode', markDur: 2.2 };
  w.add(net);
  const pts = [{ x: p.x, y: p.y }, ...route];
  let total = 0; for (let i = 1; i < pts.length; i++) total += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  total += Math.hypot(closing.x - route[route.length - 1].x, closing.y - route[route.length - 1].y);
  const dur = clamp(total / 210, 1.0, 2.0);
  yield 0.04;
  w.glide(route, dur);
  // the streams are laid down along the alchemist's actual movement
  const branches: Branch[] = []; let cur: Branch | null = null; let nextWp = 0;
  const startBranch = () => { cur = mkBranch([{ x: p.x, y: p.y }, { x: p.x + 0.1, y: p.y + 0.1 }], 1.6, 0, 1e9, branches.length + 1); net.add(cur); branches.push(cur); };
  startBranch();
  const nodes: { x: number; y: number }[] = [{ x: p.x, y: p.y }];
  let lastX = p.x, lastY = p.y;
  while (p.path) {
    if (Math.hypot(p.x - lastX, p.y - lastY) > 5 && cur) {
      lastX = p.x; lastY = p.y; const b: Branch = cur; b.pts.push({ x: p.x + Math.sin(b.pts.length * 1.7) * 0.8, y: p.y + Math.cos(b.pts.length * 1.3) * 0.8 }); const n = b.pts.length;
      b.cum.push(b.cum[n - 2] + Math.hypot(b.pts[n - 1].x - b.pts[n - 2].x, b.pts[n - 1].y - b.pts[n - 2].y)); b.len = b.cum[n - 1]; b.w = Math.min(3.4, 1.4 + branches.length * 0.45);
    }
    if (nextWp < route.length && Math.hypot(p.x - route[nextWp].x, p.y - route[nextWp].y) < 7) { nodes.push({ x: route[nextWp].x, y: route[nextWp].y }); nextWp++; if (nextWp < route.length) startBranch(); }
    if (Math.floor(w.time * 60) % 3 === 0) { drops(w, p.x, p.y, 2, 30, P.v2, P.c3, P.e2, { z: 3, up: 30, glow: 1 }); }
    yield F;
  }
  // final connection closes the loop
  const lastP = route[route.length - 1];
  const cb = mkBranch(wavyPath(lastP.x, lastP.y, Math.atan2(closing.y - lastP.y, closing.x - lastP.x), Math.hypot(closing.x - lastP.x, closing.y - lastP.y), 0.15, 7, c.id + 5), 2.4, net.age, 380, 8);
  cb.pts[cb.pts.length - 1] = { x: closing.x, y: closing.y }; net.add(cb); branches.push(cb);
  yield cb.len / 380 + 0.05;
  w.add(new Flash(closing.x, closing.y, 12, P.v3, 0.3, 0));
  // channels widen into thick flowing currents with foaming edges and branching offshoots
  const offs: Branch[] = [];
  branches.forEach((b, i) => { const q = net.pointAt(b, b.len * (0.35 + 0.3 * hash(i + c.id))), nb = mkBranch(wavyPath(q.x, q.y, q.ang + (i % 2 ? 1 : -1) * 1.0, 24 + hash(i * 3) * 16, 0.4, 6, c.id + i + 9), 2.2, net.age + 0.05, 160, 20 + i); offs.push(nb); net.add(nb); });
  for (const k of ticks(0.55)) { for (const b of branches) b.w = lerp(b.w, 5.2, 0.08); yield F; void k; }
  net.life = net.age + 9;
  // intersections become turbulent mixing reservoirs
  const segs: [number, number, number, number][] = []; for (let i = 0; i < pts.length - 1; i++) segs.push([pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y]); segs.push([lastP.x, lastP.y, closing.x, closing.y]);
  const inter: { x: number; y: number }[] = [];
  for (let i = 0; i < segs.length; i++) for (let j = i + 2; j < segs.length; j++) { const [a, b, c2, d] = segs[i], [e, f, g2, h] = segs[j], den = (c2 - a) * (h - f) - (d - b) * (g2 - e); if (Math.abs(den) < 1e-6) continue; const u = ((e - a) * (h - f) - (f - b) * (g2 - e)) / den, v = ((e - a) * (d - b) - (f - b) * (c2 - a)) / den; if (u > 0.04 && u < 0.96 && v > 0.04 && v < 0.96) inter.push({ x: a + u * (c2 - a), y: b + u * (d - b) }); }
  const reservoirs = [...nodes.slice(1), ...inter].slice(0, 12);
  const discsIdx = reservoirs.map(q => { const d = { x: q.x, y: q.y, r: 2 }; net.discs.push(d); return d; });
  reservoirs.forEach((q, i) => { w.run((function* () { yield i * 0.3; const d = discsIdx[i]; for (const k of ticks(0.35)) { d.r = 2 + 9 * smooth(k); yield F; if (Math.floor(k * 60) % 3 === 0) w.parts.add({ k: 'bubble', x: q.x + c.rng.range(-5, 5), y: q.y + c.rng.range(-3, 3), z: 0, vz: 24, max: 0.6, size: 2, c1: P.v1, c2: P.c3, c3: P.w }); } })()); });
  yield 0.5;
  // the reservoirs activate in sequence, sending new waves along the channels
  for (let i = 0; i < reservoirs.length; i++) {
    const q = reservoirs[i], d = discsIdx[i];
    ringAt(c, q.x, q.y, 28, 0.24, 55, { kind: 'burst', knock: 130, stag: 0.4, h: res, max: 2, cols: [P.w, P.c2, P.e2], w: 3 });
    w.add(new Flash(q.x, q.y - 3, 18, P.c3, 0.28, 3)); drops(w, q.x, q.y, 14, 100, P.c1, P.c3, P.e2, { z: 6, up: 120, glow: 2 }); w.shake(2.5, 0.15); w.shock(q.x, q.y, 36, 0.25, 2); plume(w, q.x, q.y, 24, 0.9, VAP.pale, 8, i);
    let best: { b: Branch; d: number } | null = null, bd = 12;
    for (const b of net.br) for (let s = 0; s <= b.len; s += 6) { const o = net.pointAt(b, s), dd = Math.hypot(o.x - q.x, o.y - q.y); if (dd < bd) { bd = dd; best = { b, d: s }; } }
    if (best) { w.add(new Pulse(best.b, net, best.d, 1, c, wv)); w.add(new Pulse(best.b, net, best.d, -1, c, wv)); }
    for (const kk of ticks(0.12)) { d.r = lerp(11, 6, kk); yield F; }
    yield 0.1;
  }
  yield 0.4;
  // sweeping flood
  w.screenFlash(P.v3, 0.3, 0.14); w.shake(7, 0.5);
  net.crust = 0;
  for (const k of ticks(0.5)) { for (const b of net.br) b.w = lerp(b.w, 15, 0.12); for (const d of discsIdx) d.r = lerp(d.r, 22, 0.1); if (Math.floor(k * 60) % 4 === 0) w.shake(4, 0.1); yield F; void k; }
  for (const q of reservoirs) {
    ringAt(c, q.x, q.y, 62, 0.5, 125, { kind: 'acid', knock: 150, stag: 0.5, h: flood, max: 1, cols: [P.v3, P.v2, P.e2], w: 6, fill: true, ease: 1.8 });
    shards(w, q.x, q.y, 10, 130, P.v3, P.v1, P.y2, { z: 8, up: 130, land: 2, size: [3, 6] }); chips(w, q.x, q.y, 3, 80, P.k3, P.k1, P.v1, { z: 8, up: 100 });
    const cl = new Cloud(q.x, q.y, mkPuffs(c.rng, 6, 12, 9, 15, 6, 1.8), VAP.green, 3.2, c.id + 3); cl.grow = { from: 0.4, to: 1.7, dur: 1.2 }; cl.vx = c.rng.range(-14, 14); cl.vy = c.rng.range(-10, 10); w.add(cl);
    w.shock(q.x, q.y, 80, 0.5, 2.5);
    if (reservoirs.indexOf(q) % 2 === 0) w.add(new Pool(q.x, q.y, 22, MAT.verd, 4, { blobs: 5, boil: 2 }));
  }
  net.life = net.age + 2.2; yield 2.6;
}

// =============== 21 THE LAST DISTILLATION ===============
class Column extends Fx {
  merge = 0; g = 0; cry = 0;
  constructor(public bx: number, public by: number, public H: number, public cx: number, public cy: number, public ph: number, public cols: number) { super(); this.x = bx; this.y = by; this.sy = by; this.kind = 'summon'; }
  pos() { const m = smooth(this.merge); return { x: lerp(this.bx, this.cx, m), y: lerp(this.by, this.cy, m) }; }
  upd() { const q = this.pos(); this.sy = q.y + 2; }
  up(g: Gfx) {
    const L = g.s, t = g.t, gr = smooth(this.g) * (1 - smooth(this.merge)), q = this.pos(); if (gr < 0.03) return;
    const H = Math.round(this.H * gr), r = 5 + gr * 2, lay = [[P.v1, P.y0, P.v3], [P.e1, P.e3, P.c0], [P.g0, P.g1, P.g2], [P.n1, P.n2, P.m0]];
    const sd = L.dl; L.dl = 13;
    for (let y = 0; y < H; y++) {
      const u = y / Math.max(1, H), wd = Math.round(r * (0.85 + 0.15 * Math.sin(y * 0.14 + t * 1.6 + this.ph)) * (y < 3 ? 0.6 + y * 0.13 : 1) * (y > H - 4 ? 0.7 : 1)), band = Math.floor((1 - u) * 4 + this.cols) % 4, ramp = lay[band];
      const n = nz1(q.x + y * 0.5, y * 0.4 - t * 6 + this.ph * 5) / 255, c1 = n > 0.66 ? ramp[2] : n > 0.33 ? ramp[1] : ramp[0];
      L.hline(Math.round(q.x - wd), Math.round(q.x + wd), Math.round(q.y - y), c1);
      L.px(Math.round(q.x - wd), Math.round(q.y - y), P.v0); L.px(Math.round(q.x + wd), Math.round(q.y - y), P.v0);
    }
    L.dl = 16;
    for (let y = 2; y < H - 1; y += 2) { L.px(Math.round(q.x - r + 1), Math.round(q.y - y), P.y2); }
    for (let i = 0; i < 4; i++) { const ph = (t * (0.5 + i * 0.2) + i * 0.3 + this.ph) % 1; bubble(L, q.x + Math.sin(i * 2 + this.ph) * (r - 2), q.y - ph * H, 1 + (i % 2), P.y0, P.v3, P.w); }
    L.ellipse(q.x, q.y - H, r, 2, P.v3); L.ellipse(q.x, q.y - H, r - 1, 1, P.y2);
    L.ellipse(q.x, q.y, r + 1, 2.5, P.v0); L.ellipse(q.x, q.y, r - 1, 1.5, P.v2);
    if (this.cry > 0.05) for (let i = 0; i < 3; i++) crystalPrism(L, q.x + (i - 1) * 3, q.y - 1, (3 + i * 2) * this.cry * 2, 1.6, i - 1, P.v2, P.v0, P.y2, P.k1, t);
    L.dl = sd;
  }
  lit(g: Gfx) { const q = this.pos(), gr = smooth(this.g) * (1 - smooth(this.merge)); if (gr > 0.05) glow(g.l, q.x, q.y - this.H * gr * 0.5, 14, [P.y0, P.c1, P.g1, P.m1][this.cols % 4], 0.18 * gr, 3); }
}
class Chamber extends Fx {
  rad = 0; cry = 0; boil = 0; sep = 0; bright = 0; cyc: number; fall = 0;
  constructor(x: number, public gy: number, public h: number) { super(); this.x = x; this.y = gy; this.cyc = gy - h; this.sy = gy + 20; this.kind = 'summon'; this.resid = false; }
  shd(g: Gfx) { g.s.dl = 8; g.s.ellipse(this.x, this.gy + 8, this.rad * 1.05, this.rad * 0.38, P.bk); g.s.dl = 16; }
  rings(g: Gfx, front: boolean) {
    const L = g.s, t = g.t, R = this.rad; if (R < 6) return;
    for (let i = 0; i < 3; i++) { const rx = R * (1.16 + i * 0.06), ry = R * (0.2 + i * 0.1), tilt = t * (0.5 + i * 0.2) * (i % 2 ? -1 : 1); for (let a = 0; a < TAU; a += 0.04) { const front_ = Math.sin(a + tilt) > 0; if (front_ !== front) continue; const x = this.x + Math.cos(a + tilt) * rx, y = this.cyc + Math.sin(a + tilt) * ry - R * 0.1 + (i - 1) * R * 0.5; L.px(Math.round(x), Math.round(y), front ? (i % 2 ? P.u2 : P.u1) : P.u0); L.px(Math.round(x), Math.round(y) + 1, front ? P.u0 : P.k0); } }
  }
  up(g: Gfx) {
    const L = g.s, t = g.t, R = Math.round(this.rad); if (R < 2) { if (this.rad > 0.3) { L.disc(this.x, this.cyc, 2, P.w); } return; }
    this.rings(g, false);
    const cx = Math.round(this.x), cy = Math.round(this.cyc), L1 = -0.28 - this.sep * 0.3 + Math.sin(t * 1.3) * 0.05, L2 = 0.28 + this.sep * 0.28 + Math.sin(t * 1.1) * 0.05;
    const ramps: Col[][] = [[P.v0, P.v1, P.y0, P.y1, P.v3], [P.e0, P.e1, P.e2, P.e3, P.c0, P.c1], [P.k0, P.k1, P.n0, P.e0, P.n1]];
    for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) {
      const q = dx * dx + dy * dy; if (q > R * R) continue;
      const rr = Math.sqrt(q), edge = R - rr, x = cx + dx, y = cy + dy, ny = dy / R;
      let c: Col;
      if (edge < 1) c = P.k0;
      else if (edge < 2.4) c = dx + dy < 0 ? P.v3 : dx + dy < R * 0.3 ? P.v1 : P.v0;
      else {
        const wob = Math.sin(t * 1.4 + dx * 0.09) * 0.06, layer = ny < L1 + wob ? 0 : ny < L2 - wob ? 1 : 2, rp = ramps[layer], nn = nz1(x * 0.14 + t * (layer === 0 ? 2 : layer === 1 ? -3 : 1), y * 0.14 + t * 1.6 + layer * 9) / 255;
        let k = Math.floor((nn * 0.8 + (1 - Math.abs(ny)) * 0.2 - ((dx * 0.55 + dy * 0.65) / R) * 0.18) * rp.length + (BAYER[((y & 3) << 2) | (x & 3)] - 7.5) * 0.04); k = k < 0 ? 0 : k >= rp.length ? rp.length - 1 : k;
        c = rp[k];
        if (Math.abs(ny - (L1 + wob)) < 0.03 || Math.abs(ny - (L2 - wob)) < 0.03) c = P.g2;
        if (this.bright > 0) c = mix(c, P.w, this.bright);
      }
      L.px(x, y, c);
    }
    // dark biological matter drifting inside
    for (let i = 0; i < 5; i++) { const a = t * 0.3 + i * 1.3, bx = cx + Math.cos(a) * R * 0.45 * (i % 2 ? 1 : -1), by = cy + R * 0.25 + Math.sin(a * 1.3) * R * 0.3; ball(L, bx, by, 2.5 + (i % 3), PAL.rot, 2 + (i % 3)); L.px(Math.round(bx + 1), Math.round(by - 1), P.m1); }
    // crystalline precipitates
    if (this.cry > 0.02) for (let i = 0; i < 6; i++) { const ang = Math.PI * (0.18 + i * 0.13), bx = cx + Math.cos(ang) * R * 0.78, by = cy + Math.sin(ang) * R * 0.78; crystalPrism(L, bx, by, (4 + (i % 3) * 3) * this.cry * (R / 30), 2, (i - 2.5) * 0.7, P.v2, P.v0, P.y2, P.k1, t); }
    // dense bubbles, plus giant boiling ones
    for (let i = 0; i < 26; i++) { const sp = 0.18 + hash(i * 3) * 0.35, ph = (t * sp + hash(i)) % 1, bx = cx + (hash(i * 7) - 0.5) * R * 1.4 + Math.sin(t * 2 + i) * 2, by = cy + R * 0.9 - ph * R * 1.8; if (Math.hypot(bx - cx, by - cy) < R - 3) bubble(L, bx, by, 1 + Math.floor(hash(i * 5) * 3), P.y0, P.y2, P.w); }
    for (let i = 0; i < Math.floor(this.boil * 4); i++) { const ph = (t * 0.5 + i * 0.27) % 1, bx = cx + (i - 1.5) * R * 0.35, br = 4 + ph * 6; bubble(L, bx, cy - R * 0.5 - ph * R * 0.3, br, P.c1, P.c3, P.w); }
    L.arc(cx, cy, R - 3, 1, Math.PI * 1.05, Math.PI * 1.55, P.w); L.arc(cx, cy, R - 5, 1, Math.PI * 1.15, Math.PI * 1.35, P.y2);
    this.rings(g, true);
  }
  lit(g: Gfx) { const R = this.rad; if (R < 1) return; glow(g.l, this.x, this.cyc, R * 1.5 + 6, mix(P.c1, P.w, this.bright), 0.28 + this.bright * 0.5, 5); if (R < 8) glow(g.l, this.x, this.cyc, 26, P.w, 0.9, 6); }
}
function* distillation(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c, true, 0.5);
  const cx = c.tx, cy = c.ty, gy = clamp(cy + 14, 80, w.H - 20), H = 52;
  const pullH = new Hits(), A = new Hits(), sheets = new Hits(), cry = new Hits(), vap = new Hits(), frag = new Hits(), after = new Hits();
  yield 0.06;
  const residues = w.fx.filter(f => f.resid && !f.dead && Math.hypot(f.x - cx, f.y - cy) < 360);
  // gather poisonous matter from across the battlefield (or erupt an underground reservoir)
  w.add(new Decal(cx, gy, 'cracks', 56, 16, c.id, { a: P.k0, b: P.i3, c: P.c1 }, 0, 1)); w.add(new Decal(cx, gy, 'veins', 70, 15, c.id + 1, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.2));
  w.add(new Pool(cx, gy, 28, MAT.venom, 9, { grow: 1.2, blobs: 7, boil: 2.4, resid: false })); w.shake(3, 0.8);
  const streamFrom = (sx: number, sy: number, n: number, dly: number) => {
    for (let i = 0; i < n; i++) {
      const a0 = Math.atan2(sy - gy, sx - cx), r0 = Math.hypot(sx - cx, (sy - gy) / 0.9), sp = c.rng.range(0.8, 1.3), del = dly + i * 0.03;
      w.parts.add({ k: 'drop', x: sx, y: sy, z: 2, max: 1.4 / sp + del, size: c.rng.range(1, 3.5) | 0, c1: i % 3 === 0 ? P.c3 : P.c1, c2: P.w, c3: P.e2, glow: 1, fn: (q) => { const u = clamp((q.age - del) / (1.4 / sp), 0, 1); const rr = r0 * Math.pow(1 - u, 1.5), an = a0 + u * u * 9 + u * 2; q.x = cx + Math.cos(an) * rr; q.y = gy + Math.sin(an) * rr * 0.9; q.z = 3 + Math.sin(u * Math.PI) * 14 * (1 - u * 0.5) + u * 20 * (u > 0.8 ? 1 : 0); if (u === 0) q.z = -50; } });
    }
  };
  const gathered = residues.slice(0, 14);
  gathered.forEach((f, i) => { streamFrom(f.x, f.y, 14, i * 0.05); w.add(new Flash(f.x, f.y, 8, P.c2, 0.3)); { const lf = (f as unknown as { life?: number }).life; if (lf) f.age = Math.max(f.age, lf - 1.2); else f.dead = true; } });
  const virtual = Math.max(0, 7 - gathered.length);
  for (let i = 0; i < virtual; i++) { const a = (i / 7) * TAU, d = 60 + hash(i * 3 + c.id) * 70; streamFrom(cx + Math.cos(a) * d, gy + Math.sin(a) * d * 0.85, 14, i * 0.06); }
  for (let i = 0; i < 4; i++) { steam(w, cx + c.rng.range(-18, 18), gy, 2, 14, P.e2, P.c0, 6, { z: 2, vz: 40 }); }
  // immense transparent fluid structures rise around the gathering point
  const cols: Column[] = [];
  for (let i = 0; i < 5; i++) { const a = (i / 5) * TAU + 0.3, d = 54, col = new Column(cx + Math.cos(a) * d, gy + Math.sin(a) * d * 0.55, 56 + (i % 2) * 14, cx, gy - H, i * 1.7, i); cols.push(col); w.add(col); }
  const chamber = new Chamber(cx, gy, H); w.add(chamber);
  let tm = 0, nt = 0.5, nextDeco = 0, gest = 0, gestT = 0.9, circled = false;
  const T_SEAL = 5.6;
  for (; tm < T_SEAL; tm += F) {
    cols.forEach((col, i) => { col.g = clamp((tm - 0.5 - i * 0.18) / 0.9, 0, 1); col.merge = clamp((tm - 2.4 - i * 0.12) / 1.5, 0, 1); col.cry = clamp((tm - 2.2) / 1.6, 0, 1) * (i % 2); });
    chamber.rad = 40 * smooth(clamp((tm - 2.4) / 1.8, 0, 1)); chamber.cry = clamp((tm - 3.2) / 2.2, 0, 1) * (gest > 0 ? 1 : 0.4); chamber.boil = clamp((tm - 3.8) / 1.5, 0, 1);
    chamber.sep = clamp((tm - 3.0) / 1.5, 0, 1) * 0.8;
    // the alchemist glides around the structure, triggering reactions with rapid gestures
    if (tm > 1.6 && !circled) { circled = true; const pts: { x: number; y: number }[] = []; const a0 = Math.atan2(p.y - gy, p.x - cx); for (let i = 1; i <= 10; i++) pts.push({ x: cx + Math.cos(a0 + i * 0.55) * 74, y: gy + Math.sin(a0 + i * 0.55) * 74 * 0.6 }); w.glide(pts, 3.6); }
    gestT -= F;
    if (tm > 2.4 && gestT <= 0) {
      gestT = 0.62; gest++; p.cast = 0.25; p.castMax = 0.25; p.face = Math.atan2(chamber.cyc - p.y, cx - p.x);
      const [hx, hy] = handPos(w), tx = cx + c.rng.range(-18, 18), ty = chamber.cyc + c.rng.range(-18, 18);
      w.add(new Custom(hx, hy, 0.28, { air: (g, a) => { const L = g.s; const n = 14; for (let i = 0; i < n; i++) { const u = i / n; if (u > a * 1.6 + 0.2) break; L.px(Math.round(lerp(hx, tx, u) + Math.sin(u * 20 + g.t * 30) * 2), Math.round(lerp(hy, ty, u) + Math.cos(u * 16) * 2), i % 2 ? P.c3 : P.w); } }, lit: (g, a) => glow(g.l, tx, ty, 10, P.c2, 0.4 * (1 - a), 3) }));
      w.add(new Flash(tx, ty, 12, [P.y1, P.c2, P.m2][gest % 3], 0.25, 0)); w.shake(1.5, 0.12);
      if (gest % 3 === 0) chamber.bright = 0.5; if (gest % 3 === 1) { drops(w, cx, chamber.cyc - 30, 8, 60, P.c1, P.c3, P.e2, { z: 0, up: 60, glow: 1 }); }
    }
    chamber.bright = Math.max(0, chamber.bright - F * 2);
    // enemies beneath are pulled toward the unstable centre
    nt -= F;
    for (const e of w.enemies) {
      if (e.dying > 0) continue; const ex = cx - e.x, ey = gy - e.y, d = Math.hypot(ex, ey);
      if (d < 150 && d > 6 && tm > 0.3) { const s = (22 + Math.min(1, tm / 5) * 40) * F * (e.kind === 'boss' ? 0.2 : e.kind === 'elite' ? 0.6 : 1); e.x += ex / d * s; e.y += ey / d * s; }
      if (nt <= 0 && d < 120 && tm > 0.4 && pullH.ok(e, w.time, 0.45, 6)) { hitE(c, e, 20, { kind: 'acid', stag: 0.1, at: [e.x, e.y] }); w.mark(e, 'corrode', 1.4, 2); }
    }
    if (nt <= 0) nt = 0.5;
    // ground becomes increasingly contaminated
    if (tm > nextDeco) { nextDeco = tm + 0.3; const a = c.rng.range(0, TAU), d = c.rng.range(20, 60 + tm * 12), X = cx + Math.cos(a) * d, Y = gy + Math.sin(a) * d * 0.8; if (X > 12 && X < w.W - 12 && Y > 16 && Y < w.H - 10) { if (c.rng.next() < 0.5) w.add(new Decal(X, Y, 'veins', 22 + tm * 3, 16, Math.floor(X + Y), { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.3)); else w.add(new Pool(X, Y, 8 + c.rng.range(0, 5), MAT.venom, 12, { blobs: 3, boil: 1.4, resid: false })); } }
    if (Math.floor(tm * 60) % 7 === 0 && chamber.rad > 20) w.parts.add({ k: 'mote', x: cx + c.rng.range(-40, 40), y: chamber.cyc + c.rng.range(-40, 40), z: 0, vz: 10, max: 0.8, c1: P.c3, c2: P.c1, glow: 1 });
    yield F;
  }
  // the final seal is released: the whole structure compresses into one impossibly bright droplet
  for (const k of ticks(0.55)) { chamber.rad = lerp(40, 1.5, k * k); chamber.bright = k * k; cols.forEach(cl => { cl.g = 0; }); chamber.cyc = lerp(chamber.cyc, gy - H - 4, 0.05); w.shock(cx, chamber.cyc, 30 + (1 - k) * 60, 0.15, 1); if (Math.floor(k * 60) % 3 === 0) w.parts.add({ k: 'spark', x: cx + c.rng.range(-30, 30), y: chamber.cyc + c.rng.range(-30, 30), z: 0, vx: 0, vy: 0, vz: 0, max: 0.2, c1: P.w, fn: (q) => { const u = q.age / q.max; q.x = lerp(q.x, cx, u * 0.4); } }); yield F; }
  chamber.rad = 0.5; w.hitstop = 0.5;
  w.add(new Custom(cx, chamber.cyc, 0.5, { air: (g) => { g.s.disc(cx, chamber.cyc, 1.5, P.w); g.s.px(Math.round(cx), Math.round(chamber.cyc), P.c3); }, lit: (g, a) => { glow(g.l, cx, chamber.cyc, 24 + a * 10, P.w, 1, 6); glow(g.l, cx, chamber.cyc, 50, P.c3, 0.5, 5); } }));
  yield 0.6;
  // multistage catastrophe
  const X = cx, Y = gy; chamber.dead = true; cols.forEach(cl => { cl.dead = true; });
  w.screenFlash(P.w, 0.95, 0.4); w.shake(14, 1.0); w.shock(X, Y - 20, 190, 0.9, 6); w.hitstop = 0.05;
  w.add(new Flash(X, Y - 36, 80, P.w, 0.6, 0));
  ringAt(c, X, Y, 135, 0.5, 120, { kind: 'burst', knock: 240, stag: 0.7, h: A, cols: [P.w, P.c3, P.c1], w: 7, dust: true, fill: true });
  visRing(w, X, Y, 80, 0.45, [P.w, P.y1, P.v2], 4);
  chips(w, X, Y - 30, 50, 220, P.i0, P.i2, P.w, { z: 30, up: 200, size: [3, 6] }); drops(w, X, Y - 30, 80, 220, P.c1, P.c3, P.c0, { z: 30, up: 240, glow: 2, size: [2, 5], max: 3 });
  w.run((function* () {
    yield 0.15; w.shake(8, 0.6);
    ringAt(c, X, Y, 230, 0.9, 110, { kind: 'acid', knock: 180, stag: 0.5, h: sheets, max: 2, cols: [P.c3, P.c1, P.e2], w: 12, fill: true, ease: 1.7 });
    w.add(new Pool(X, Y, 62, MAT.acid, 12, { blobs: 11, boil: 3, grow: 0.7 }));
    yield 0.3;
    ringAt(c, X, Y, 250, 1.0, 110, { kind: 'acid', knock: 170, stag: 0.5, h: sheets, max: 2, cols: [P.y1, P.v2, P.v0], w: 10, fill: true, ease: 1.7 }); w.shock(X, Y, 260, 1.0, 4);
    // massive crystalline structures erupt and shatter
    const cls: Cluster[] = [];
    for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU + 0.4, d = 60 + (i % 2) * 40, cl = new Cluster(clamp(X + Math.cos(a) * d, 16, w.W - 16), clamp(Y + Math.sin(a) * d * 0.8, 40, w.H - 10), c.id + i * 5, 1.6); cl.g = 0; cls.push(cl); w.add(cl); }
    for (const k of ticks(0.45)) { cls.forEach(cl => { cl.g = smooth(k); cl.swell = 1 + k * 0.4; cl.fr = k; }); yield F; }
    w.shake(9, 0.5); w.screenFlash(P.y2, 0.35, 0.14);
    for (const cl of cls) {
      cl.dead = true; ringAt(c, cl.bx, cl.by, 44, 0.32, 140, { kind: 'crystal', knock: 190, stag: 0.5, h: cry, max: 1, cols: [P.w, P.y1, P.v1], w: 4 }); w.shock(cl.bx, cl.by, 64, 0.35, 3);
      shards(w, cl.bx, cl.by, 22, 200, P.c3, P.v2, P.w, { z: 14, up: 220, land: 2, size: [3, 9] }); shards(w, cl.bx, cl.by, 10, 130, P.y1, P.v0, P.y2, { z: 8, up: 150, land: 2, size: [2, 5] });
      w.add(new Flash(cl.bx, cl.by - 10, 22, P.w, 0.3, 0)); w.add(new Decal(cl.bx, cl.by, 'cracks', 20, 12, Math.floor(cl.bx), { a: P.k0, b: P.v1, c: P.y1 }, 0, 1));
    }
    // dense chemical vapour bursts upward
    const big = new Cloud(X, Y, mkPuffs(c.rng, 22, 80, 16, 26, 8, 1.4), VAP.green, 6.5, c.id + 9); big.grow = { from: 0.3, to: 1.8, dur: 1.6 }; big.dens = 12;
    big.tickInfo = { every: 0.75, amt: c.d(27.5), opts: { kind: 'acid', src: c.def.id }, h: vap, max: 4, mark: 'miasma' }; w.add(big);
    for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU + 0.2, d = 30 + (i % 3) * 30; plume(w, X + Math.cos(a) * d, Y + Math.sin(a) * d * 0.7, 62 + (i % 3) * 10, 2.2, i % 2 ? VAP.pale : VAP.green, 14, i, i * 0.06); }
    w.add(new Decal(X, Y, 'crater', 56, 14, c.id + 3, { a: P.k0, b: P.i2, c: P.c1 }, 0, 1.3)); w.add(new Decal(X, Y, 'veins', 104, 13, c.id + 4, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.6)); w.add(new Decal(X, Y, 'scorch', 70, 12, c.id + 5, { a: P.k0, b: P.k3, c: P.c1 }, 0, 1));
  })());
  // thick fluid fragments strike in staggered impacts
  w.run((function* () {
    yield 0.35;
    for (let i = 0; i < 30; i++) {
      const a = c.rng.range(0, TAU), d = c.rng.range(30, 210), lx = clamp(X + Math.cos(a) * d, 10, w.W - 10), ly = clamp(Y + Math.sin(a) * d * 0.7, 18, w.H - 8), T = c.rng.range(0.7, 1.2);
      w.add(new Shot(X, Y - 30, 40, (lx - X) / T, (ly - Y) / T, (T * 280 / 2) - 40 * 0 + 60, 280, 5, (g, x, y, _z, s) => { ball(g.s, x, y, 3.2, PAL.liquid); g.s.px(Math.round(x - 1), Math.round(y - 1), P.w); g.s.dl = 8; g.s.px(Math.round(x - s.vx * 0.04), Math.round(y - s.vy * 0.04 + 2), P.c1); g.s.dl = 16; }, (ww, s, e) => { if (frag.ok(e, ww.time, 0, 4)) { hitE(c, e, 25, { kind: 'acid', k: 90, from: [s.x, s.y], stag: 0.3, at: [e.x, e.y] }); drops(ww, e.x, e.y, 7, 70, P.c1, P.c3, P.e2, { z: 6, glow: 1 }); ww.add(new Splash(e.x, e.y, 7, P.c1, P.c3)); } return true; },
        (ww, s) => { ww.add(new Splash(s.x, s.y, 8, P.c1, P.c3)); ww.add(new Pool(s.x, s.y, 7, MAT.acid, 5, { blobs: 3, boil: 1.4 })); drops(ww, s.x, s.y, 6, 70, P.c1, P.c3, P.e2, { z: 3, up: 70, glow: 1 }); visRing(ww, s.x, s.y, 12, 0.2, [P.c3, P.c1, P.e2], 1); ww.shake(1.5, 0.1);
          for (const e of ww.enemies) if (e.dying <= 0 && Math.hypot(e.x - s.x, e.y - s.y) < e.r + 8 && frag.ok(e, ww.time, 0, 4)) hitE(c, e, 25, { kind: 'acid', k: 90, from: [s.x, s.y], stag: 0.3, at: [e.x, e.y] }); }, 4, 14));
      yield 0.04;
    }
  })());
  yield 2.2;
  // the alchemist emerges from the receding cloud, surrounded by luminous droplets
  for (let i = 0; i < 16; i++) w.parts.add({ k: 'drop', x: p.x, y: p.y, z: 8, vx: 0, vy: 0, vz: 0, max: 3, size: 2, c1: P.c1, c2: P.c3, c3: P.e2, glow: 1, fn: (q) => { const a = q.age * 2 + i * 0.4, r = 9 + Math.sin(q.age * 3 + i) * 3; q.x = p.x + Math.cos(a) * r; q.y = p.y + Math.sin(a) * r * 0.5; q.z = 6 + Math.sin(a * 1.3) * 4 + i % 4; } });
  w.add(new Ring(p.x, p.y, 22, 0.5, { w: 2, cols: [P.c3, P.c1, P.e2] }));
  // the battlefield keeps reacting: aftershock bursts at the pools
  for (let i = 0; i < 9; i++) {
    const pools = w.fx.filter(f => f.kind === 'pool' && !f.dead), q = pools.length ? pools[c.rng.int(pools.length)] : null; const X2 = q ? q.x : X + c.rng.range(-80, 80), Y2 = q ? q.y : Y + c.rng.range(-60, 60);
    ringAt(c, X2, Y2, 18, 0.2, 20, { kind: 'acid', knock: 80, stag: 0.2, h: after, max: 2, cols: [P.c3, P.c1, P.e2], w: 2 });
    drops(w, X2, Y2, 9, 70, P.c1, P.c3, P.e2, { z: 4, up: 100, glow: 1 }); w.add(new Flash(X2, Y2 - 3, 10, P.c2, 0.2, 2)); w.shake(1.5, 0.1); steam(w, X2, Y2, 2, 12, P.e2, P.c0, 4, { z: 3, vz: 20 });
    yield 0.4;
  }
  yield 1.2;
}

export const defs4: Pick<SkillDef, 'id' | 'run'>[] = [
  { id: 17, run: extraction }, { id: 18, run: rain }, { id: 19, run: remedy }, { id: 20, run: cartography }, { id: 21, run: distillation },
];
void Embed; void Fx; void Ring; void dust; void mix;
