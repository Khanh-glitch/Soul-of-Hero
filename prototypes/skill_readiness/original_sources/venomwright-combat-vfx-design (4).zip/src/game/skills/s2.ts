import { Chain, Cloud, Custom, Decal, Embed, Flash, Fx, Hits, Pool, Proj, Ring, Shot, Splash, chips, drops, dust, puff, shards, steam, type Gfx } from '../fx';
import { P, TAU, angDiff, ball, clamp, glow, hash, lerp, mix, shard, smooth, wormBody, type Col, type Pal, type Seg } from '../pixel';
import { MAT, PAL, VAP } from '../mats';
import type { Enemy, World } from '../world';
import { F, FlowNet, LIQ, castAnim, drawFlask, handPos, hitE, mkBranch, mkPuffs, ringAt, throwArc, ticks, visRing, type Cast, type SkillDef } from './lib';

const alive = (e: Enemy | null | undefined): e is Enemy => !!e && e.dying > 0 === false;
export function plume(w: World, x: number, y: number, h: number, life: number, ramp: Col[], r: number, seed = 1, delay = 0) {
  return w.add(new Custom(x, y, life + delay, { up: (g, _a, f) => {
    const t = f.age - delay; if (t < 0) return;
    const k = Math.min(1, t / 0.35), fade = clamp((life - t) / 0.6, 0, 1), L = g.s;
    for (let i = 0; i < 7; i++) { const u = i / 6, rr = (r * (1 - u * 0.35)) * (0.5 + 0.5 * k); puff(L, x + Math.sin(g.t * 3 + i * 1.3 + seed) * 3 * u, y - u * h * k - 2, rr, ramp, 12 * fade, g.t + i * 0.3, seed + i); }
  }, lit: (g, _a, f) => { const t = f.age - delay; if (t > 0) glow(g.l, x, y - h * 0.4, r * 1.4, ramp[3], 0.12 * clamp((life - t) / 0.6, 0, 1), 3); } }, y + 6));
}
const chitinDark: Pal = PAL.chitin;

// =============== 06 GRAFT CARAVAN ===============
class Beetle extends Fx {
  hd: number; z = 0; flask = true; fade = 1; tilt = 0; legT = 0; sc: number; spd = 0; u = 0; climb = 0; ruptured = false; role: number; vx = 0; vy = 0;
  constructor(x: number, y: number, hd: number, public big: boolean, role: number) { super(); this.x = x; this.y = y; this.hd = hd; this.sc = big ? 1.55 : 1; this.r = 5 * this.sc; this.kind = 'summon'; this.role = role; this.sy = y; }
  upd() { this.sy = this.y; }
  shd(g: Gfx) { g.s.dl = Math.round(8 * this.fade); g.s.ellipse(this.x, this.y + 2, 7 * this.sc, 3.4 * this.sc, P.bk); g.s.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, sc = this.sc, fx = Math.cos(this.hd), fy = Math.sin(this.hd), qx = -fy, qy = fx, x = this.x, y = this.y - this.z;
    L.dl = Math.round(16 * this.fade); if (L.dl < 1) return;
    for (let i = 0; i < 3; i++) for (const s of [-1, 1]) {
      const ph = Math.sin(this.legT * 1.8 + (i % 2 ? Math.PI : 0) + (s > 0 ? Math.PI : 0)), sx = x + fx * (i - 1) * 3.4 * sc + qx * 3 * sc * s, sy = y + fy * (i - 1) * 3 * sc + qy * 3 * sc * s * 0.8 - 2;
      const kx = sx + qx * s * 3 * sc, ky = sy + qy * s * 2.4 * sc - 2, ex = kx + qx * s * 2.4 * sc + fx * ph * 2.6 * sc, ey = ky + 4 + qy * s * 1.5 * sc + Math.max(0, -ph) * -1;
      L.line(sx, sy, kx, ky, P.n1); L.line(kx, ky, ex, ey, P.n3); L.px(Math.round(ex), Math.round(ey), P.e3);
    }
    ball(L, x - fx * 4 * sc, y - 4 * sc - fy * 2 * sc, 5.6 * sc, chitinDark, 4.8 * sc);
    ball(L, x - fx * 3.4 * sc, y - 6.2 * sc - fy * 1.6 * sc, 3.4 * sc, PAL.cer, 2.8 * sc); L.line(x - fx * 6 * sc, y - 4.6 * sc, x, y - 5.2 * sc, P.n3);
    ball(L, x + fx * 2.4 * sc, y - 3.6 * sc + fy * 1.4 * sc, 3.6 * sc, chitinDark, 3.2 * sc); ball(L, x + fx * 2.2 * sc, y - 5.5 * sc, 2 * sc, PAL.cer, 1.6 * sc);
    const hx = x + fx * 6 * sc, hy = y - 3 * sc + fy * 2.5 * sc;
    ball(L, hx, hy, 2.5 * sc, chitinDark, 2.2 * sc);
    for (const s of [-1, 1]) { shard(L, hx + fx * 2 * sc + qx * s * 1.2, hy + fy * 2 * sc + qy * s * 1.2, this.hd + s * 0.5, 3.4 * sc, 0.9, P.i0, P.i2, P.w); L.px(Math.round(hx + qx * s * 1.6 + fx), Math.round(hy + qy * s * 1.6 - 1), P.c1); L.line(hx + fx * sc, hy - 1, hx + fx * 5 * sc + qx * s * 2, hy - 2 + fy * 3 * sc + Math.sin(t * 9 + s) * 1.2, P.n3); }
    const fx0 = x - fx * 3 * sc, fy0 = y - 11.5 * sc;
    if (this.flask) {
      drawFlask(L, fx0, fy0, 4.6 * sc, 0.68, this.tilt, this.big ? LIQ.mag : LIQ.acid, t * 1.4);
      L.rect(Math.round(fx0 - 1), Math.round(fy0 - 5.4 * sc), 3, 2, P.u1); L.px(Math.round(fx0), Math.round(fy0 - 6.4 * sc), P.u2);
      if (this.big && Math.sin(t * 22) > 0) { L.px(Math.round(fx0 + 4), Math.round(fy0 - 3), P.m2); L.px(Math.round(fx0 - 4), Math.round(fy0 + 1), P.w); }
    } else { L.poly([fx0 - 4, fy0 + 3, fx0 - 3, fy0 - 2, fx0 - 1, fy0 + 1, fx0, fy0 - 3, fx0 + 2, fy0 + 1, fx0 + 4, fy0 - 1, fx0 + 4, fy0 + 3], P.v1); L.px(Math.round(fx0), Math.round(fy0 - 3), P.v3); }
    L.dl = 16;
  }
  lit(g: Gfx) { if (this.flask) glow(g.l, this.x - Math.cos(this.hd) * 3, this.y - this.z - 11, 7 * this.sc, this.big ? P.m1 : P.c1, 0.28, 3); }
}
function* caravan(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c, true, 0.4);
  const ox = p.x, oy = p.y, dx = Math.cos(c.ang), dy = Math.sin(c.ang), nx = -dy, ny = dx;
  const R = Math.min(230, c.def.aim.range), side = c.rng.sign();
  const p0 = { x: ox + dx * 16, y: oy + dy * 16 }, p3 = { x: clamp(ox + dx * R, 12, w.W - 12), y: clamp(oy + dy * R, 14, w.H - 12) };
  const p1 = { x: lerp(p0.x, p3.x, 0.33) + nx * 70 * side, y: lerp(p0.y, p3.y, 0.33) + ny * 70 * side }, p2 = { x: lerp(p0.x, p3.x, 0.66) - nx * 70 * side, y: lerp(p0.y, p3.y, 0.66) - ny * 70 * side };
  const bez = (u: number) => { const a = (1 - u) ** 3, b = 3 * (1 - u) ** 2 * u, cc = 3 * (1 - u) * u * u, d = u ** 3; return { x: a * p0.x + b * p1.x + cc * p2.x + d * p3.x, y: a * p0.y + b * p1.y + cc * p2.y + d * p3.y }; };
  const L0 = (() => { let l = 0, q = bez(0); for (let i = 1; i <= 30; i++) { const n = bez(i / 30); l += Math.hypot(n.x - q.x, n.y - q.y); q = n; } return l; })();
  yield 0.04;
  const roles = [0, 1, 2, 0, 1, 0], delays = [0, 0.3, 0.6, 0.9, 1.2, 1.75];
  const beetles: Beetle[] = [], hits = new Hits(), pools = new Hits(), fin = new Hits(), vap = new Hits();
  const debris: { x: number; y: number }[] = [];
  const done = new Set<Beetle>(); let finalDone = false;
  const rupture = (b: Beetle, e: Enemy | null) => {
    b.ruptured = true; b.flask = false;
    const fx = b.x, fy = b.y;
    if (e && hits.ok(e, w.time, 0, 3)) { hitE(c, e, 50, { kind: 'acid', k: 100, from: [b.x, b.y], stag: 0.3, at: [e.x, e.y] }); w.mark(e, 'corrode', 2.5, 2); }
    w.add(new Pool(fx + b.vx * 0.05, fy, 10, MAT.acid, 3.4, { blobs: 5, boil: 1.4, tick: { every: 0.75, amt: c.d(15), opts: { kind: 'acid', src: c.def.id }, h: pools, max: 3 } }));
    w.add(new Splash(fx, fy, 8, P.c1, P.c3)); w.add(new Flash(fx, fy - 6, 10, P.c2, 0.2, 6));
    drops(w, fx, fy, 14, 80, P.c1, P.c3, P.e2, { z: 8, up: 100, glow: 2, ang: b.hd, spread: 4.5 }); shards(w, fx, fy, 6, 70, P.v2, P.v1, P.y2, { z: 8, land: 2, size: [2, 4] });
    chips(w, fx, fy, 4, 60, P.i0, P.i2, P.w, { z: 6 }); debris.push({ x: fx, y: fy }); w.shake(1.5, 0.12);
    w.add(new Custom(fx, fy, 7, { gnd: (g) => { const L = g.s; for (let i = 0; i < 6; i++) { L.px(Math.round(fx + (hash(i) - 0.5) * 12), Math.round(fy + (hash(i * 3) - 0.5) * 8), i % 2 ? P.i1 : P.i3); L.px(Math.round(fx + (hash(i * 5) - 0.5) * 12), Math.round(fy + (hash(i * 7) - 0.5) * 8), P.v2); } } }));
  };
  const detonate = (b: Beetle) => {
    finalDone = true; b.dead = true; const X = b.x, Y = b.y;
    w.hitstop = 0.05; w.screenFlash(P.m2, 0.45, 0.18); w.shake(8, 0.5); w.shock(X, Y, 110, 0.5, 4);
    w.add(new Flash(X, Y - 8, 40, P.w, 0.35, 8));
    ringAt(c, X, Y, 66, 0.34, 100, { kind: 'burst', knock: 170, stag: 0.4, h: fin, cols: [P.w, P.m2, P.c1], w: 5, dust: true });
    visRing(w, X, Y, 46, 0.3, [P.c3, P.c1, P.e2], 3);
    for (let i = 0; i < 4; i++) { const a = (i / 4) * TAU + 0.5; plume(w, X + Math.cos(a) * 12, Y + Math.sin(a) * 8, 30 + i * 4, 1.3, i % 2 ? VAP.green : VAP.pale, 11, i, i * 0.06); }
    const cl = new Cloud(X, Y, mkPuffs(c.rng, 13, 28, 11, 19, 7, 1.6), VAP.green, 3.6, c.id); cl.grow = { from: 0.4, to: 1.7, dur: 1.2 }; cl.dens = 12;
    cl.tickInfo = { every: 0.55, amt: c.d(25), opts: { kind: 'acid', src: c.def.id }, h: vap, max: 2, mark: 'miasma' }; w.add(cl);
    w.add(new Pool(X, Y, 30, MAT.acid, 5, { blobs: 7, boil: 2.4, tick: { every: 0.75, amt: c.d(15), opts: { kind: 'acid', src: c.def.id }, h: pools, max: 3 } }));
    drops(w, X, Y, 46, 150, P.c1, P.c3, P.e2, { z: 10, up: 170, glow: 2, size: [2, 4], max: 2.4 }); chips(w, X, Y, 14, 110, P.i0, P.i2, P.w, { z: 10, up: 140, size: [2, 4] });
    for (let i = 0; i < 22; i++) w.run((function* () { yield 0.15 + i * 0.045; const a = c.rng.range(0, TAU), d = c.rng.range(5, 52); w.parts.add({ k: 'shard', x: X + Math.cos(a) * d, y: Y + Math.sin(a) * d * 0.8, z: 90, vx: 0, vy: 0, vz: -40, grav: 120, size: c.rng.range(3, 6), rot: c.rng.range(0, TAU), vr: c.rng.range(-8, 8), c1: P.v2, c2: P.v1, c3: P.y2, land: 2, max: 3 }); })());
    w.add(new Decal(X, Y, 'pits', 34, 6, c.id, { a: P.k0, b: P.e3, c: P.c1 }, 0, 1));
  };
  let tm = 0;
  for (; tm < 6.5; tm += F) {
    for (let i = 0; i < 6; i++) if (!beetles[i] && tm >= delays[i]) {
      const big = i === 5, q = bez(0.01), b = new Beetle(q.x, q.y, Math.atan2(dy, dx), big, roles[i]);
      b.spd = big ? 90 : 150 + i * 6; beetles[i] = b; w.add(b); dust(w, q.x, q.y, 3, 14, 3);
      w.add(new Splash(q.x, q.y, 4, P.i2, P.i0));
    }
    for (const b of beetles) {
      if (!b || b.dead || done.has(b)) continue;
      const q = bez(Math.min(1, b.u + 0.06));
      let tx = q.x, ty = q.y, react: Enemy | null = null;
      if (!b.ruptured || b.big) {
        let bd = b.role === 1 ? 78 : b.role === 0 ? 64 : 52;
        for (const e of w.enemies) { if (e.dying > 0) continue; const d = Math.hypot(e.x - b.x, e.y - b.y) - e.r; if (d < bd && (b.big ? true : true)) { bd = d; react = e; } }
        if (react && (b.role === 2 ? hash(b.x) > 0.3 : true) && (b.big ? tm > delays[5] + 0.55 : true)) { tx = react.x; ty = react.y; } else react = null;
      }
      const want = Math.atan2(ty - b.y, tx - b.x), turn = (b.role === 1 && react ? 11 : 5) * F;
      b.hd += clamp(angDiff(b.hd, want), -turn, turn);
      const climbing = debris.some(d => Math.hypot(d.x - b.x, d.y - b.y) < 7 && !b.ruptured === false) && b.climb <= 0;
      if (climbing) b.climb = 0.01;
      if (b.climb > 0) { b.climb += F; b.z = Math.sin(clamp(b.climb / 0.42, 0, 1) * Math.PI) * 4.5; if (b.climb > 0.42) { b.climb = 0; b.z = 0; } }
      const sp = b.spd * (react && b.role === 0 ? 1.25 : 1) * (b.climb > 0 ? 0.5 : 1);
      const ox2 = b.x, oy2 = b.y;
      b.x += Math.cos(b.hd) * sp * F; b.y += Math.sin(b.hd) * sp * F; b.vx = (b.x - ox2) / F; b.vy = (b.y - oy2) / F;
      b.u = clamp(b.u + (sp * F / L0) * clamp(Math.cos(angDiff(b.hd, Math.atan2(q.y - b.y, q.x - b.x))) + 0.2, 0.2, 1), 0, 1);
      b.legT += sp * F * 0.5; b.tilt = lerp(b.tilt, clamp(-Math.sin(angDiff(Math.atan2(b.vy, b.vx), b.hd)) * 0.9 + Math.sin(b.legT * 0.9) * 0.2, -0.7, 0.7), 0.2);
      if (hash(Math.floor(tm * 60) + b.u * 100) > 0.9) w.parts.add({ k: 'dust', x: b.x - Math.cos(b.hd) * 5, y: b.y + 2, z: 0, vz: 6, max: 0.35, size: 2, c1: P.i3, c2: P.i2 });
      for (const e of w.enemies) {
        if (e.dying > 0) continue;
        const d = Math.hypot(e.x - b.x, e.y - b.y);
        if (d < e.r + b.r) {
          if (b.big && !finalDone) { detonate(b); break; }
          if (!b.big && !b.ruptured) { rupture(b, e); }
          else if (!b.big) w.push(e, b.x, b.y, 18);
        }
      }
      if (b.u >= 0.995 || b.x < 8 || b.x > w.W - 8 || b.y < 10 || b.y > w.H - 8) {
        if (b.big && !finalDone) detonate(b); else if (!b.big) { done.add(b); }
      }
    }
    for (const b of done) { if (b.dead) continue; b.fade -= F * 2.2; if (b.fade <= 0) { b.dead = true; chips(w, b.x, b.y, 5, 50, P.i0, P.i2, P.w, { z: 4 }); dust(w, b.x, b.y, 4, 14, 3); } }
    if (finalDone) break;
    yield F;
  }
  for (const b of beetles) if (b) { if (!b.dead) b.dead = true; }
  yield 1.4;
}

// =============== 07 HATCHERY FALL ===============
class Cocoon extends Fx {
  open = 0; pulseY = -1; ruptured = [false, false, false]; trans = 0; glowAdd = 0; shake = 0; grow = 1; z = 0; vis = 1;
  constructor(x: number, y: number) { super(); this.x = x; this.y = y; this.r = 12; this.push = true; this.kind = 'summon'; this.sy = y; }
  upd() { this.sy = this.y; }
  shd(g: Gfx) { g.s.dl = 9; g.s.ellipse(this.x + 2, this.y + 5, 14 * this.grow, 6, P.bk); g.s.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, x = this.x + (this.shake > 0 ? Math.sin(t * 80) * this.shake : 0), cy = this.y - 14 - this.z, op = this.open;
    if (this.trans > 0.05) { this.drawInsect(g, x, cy); if (this.trans > 0.6) return; }
    const sc = (1 - smooth((this.trans - 0.05) * 3)) * this.grow;
    if (sc <= 0.05) return;
    L.dl = Math.round(16 * this.vis);
    ball(L, x, cy, 12 * sc + op * 1.5, PAL.chitin, 15 * sc);
    for (let i = -3; i <= 3; i++) {
      const a = i / 3 * 1.15, px = x + Math.sin(a) * 12 * sc * (1 + op * 0.5), top = cy - Math.cos(a) * 15 * sc, bot = cy + Math.cos(a) * 15 * sc;
      const seam = (Math.sin(t * 4 + i) + 1) / 2, rup = this.ruptured[i < -1 ? 0 : i < 2 ? 1 : 2] && op > 0.3;
      const col = rup ? P.k0 : mix(P.e3, i % 2 ? P.g2 : P.c2, seam * 0.8 + this.glowAdd);
      L.line(px, top + 2, px + (a > 0 ? 1 : -1) * op * 2, bot - 2, col);
      L.px(Math.round(px + 1), Math.round(cy - 4 + i), P.k0);
      for (let k = 0; k < 4; k++) L.px(Math.round(px + (a > 0 ? -1 : 1)), Math.round(lerp(top, bot, (k + 1) / 5)), mix(P.n2, P.n3, k / 4));
    }
    for (let i = 0; i < 3; i++) { // organisms growing inside
      const ox = (i - 1) * 5 * sc, oy = (i % 2 ? -1 : 1) * 4 * sc, s = (0.6 + 0.4 * Math.sin(t * 2 + i * 2)) * Math.min(1, this.age * 0.5 + 0.4);
      L.arc(x + ox, cy + oy, 3 * s * sc + 0.5, 1.5, 0.4 + i, 4.2 + i, P.g1); L.px(Math.round(x + ox + 2), Math.round(cy + oy - 1), P.c3);
    }
    if (this.pulseY >= 0) { const py = cy + 15 * sc - this.pulseY * 30 * sc; for (let dx = -10; dx <= 10; dx++) { const q = Math.sqrt(Math.max(0, 1 - ((py - cy) / (15 * sc)) ** 2)) * 12 * sc; if (Math.abs(dx) < q) { L.px(Math.round(x + dx), Math.round(py), P.c3); if (Math.abs(dx) % 2) L.px(Math.round(x + dx), Math.round(py - 1), P.g2); } } }
    for (const s of [-1, 1]) L.poly([x + s * 6 * sc, cy - 12 * sc, x + s * (11 + op * 7) * sc, cy - 11 * sc - op * 2, x + s * (9 + op * 8) * sc, cy - 4 * sc, x + s * 4 * sc, cy - 9 * sc], P.n1);
    L.dl = 16;
  }
  drawInsect(g: Gfx, x: number, cy: number) {
    const L = g.s, t = g.t, k = smooth(Math.min(1, this.trans)), s = k, y = cy + 4 - k * 4;
    const hot = PAL.chitinHot, pc = mix(P.c1, P.g2, 0.3);
    for (const sd of [-1, 1]) { // wings
      L.dl = 9; L.poly([x + sd * 4 * s, y - 8 * s, x + sd * 22 * s, y - 24 * s, x + sd * 26 * s, y - 10 * s, x + sd * 10 * s, y - 2 * s], pc); L.dl = 16;
      for (let i = 0; i < 4; i++) L.line(x + sd * 5 * s, y - 7 * s, x + sd * (14 + i * 4) * s, y - (20 - i * 3) * s, P.g1);
    }
    for (let i = 0; i < 3; i++) for (const sd of [-1, 1]) { const ph = Math.sin(t * 6 + i + sd) * 2; L.line(x + sd * 6 * s, y + (i - 1) * 5 * s, x + sd * (13 + i * 2) * s, y + (i - 1) * 8 * s + 6 + ph, P.n3, 2); L.line(x + sd * (13 + i * 2) * s, y + (i - 1) * 8 * s + 6 + ph, x + sd * (16 + i * 2) * s, y + (i - 1) * 8 * s + 12, P.n2); }
    ball(L, x, y - 7 * s, 11 * s, PAL.chitin, 12 * s); for (let i = 0; i < 4; i++) L.arc(x, y - 7 * s, (4 + i * 2.2) * s, 1, 0.3, 2.84, mix(P.e3, P.g2, (Math.sin(t * 5 - i) + 1) / 2), (5 + i * 2.2) * s);
    ball(L, x, y + 6 * s, 8 * s, hot, 7 * s);
    for (const sd of [-1, 1]) { // scythe arms
      const ex = x + sd * 13 * s, ey = y + 4 * s, tx = ex + sd * 5 * s, ty = ey + 18 * s;
      L.line(x + sd * 6 * s, y + 3 * s, ex, ey, P.n1, 4); ball(L, ex, ey, 3 * s, hot);
      shard(L, ex, ey, Math.atan2(ty - ey, tx - ex), 20 * s, 3.2 * s, P.g2, P.g0, P.w);
      for (let i = 1; i < 6; i++) L.px(Math.round(lerp(ex, tx, i / 6) - sd * 2), Math.round(lerp(ey, ty, i / 6)), P.k0);
    }
    ball(L, x, y + 14 * s, 5.5 * s, hot, 5 * s);
    for (const sd of [-1, 1]) { shard(L, x + sd * 3 * s, y + 18 * s, Math.PI / 2 + sd * 0.55, 6 * s, 1.5, P.i0, P.i2, P.w); L.disc(x + sd * 2.6 * s, y + 13 * s, 1.2 * s, P.c1); L.px(Math.round(x + sd * 2.6 * s), Math.round(y + 13 * s), P.w); }
  }
  lit(g: Gfx) { glow(g.l, this.x, this.y - 14, 16 + this.trans * 22, this.trans > 0.1 ? P.g2 : P.c1, 0.18 + this.glowAdd * 0.5 + this.trans * 0.35, 4); }
}
class Hatchling extends Fx {
  hd: number; vx = 0; vy = 0; z = 0; cd = 0; tgt: Enemy | null = null; idx: number; recoil = 0; ph: number; absorb = false;
  constructor(x: number, y: number, hd: number, idx: number) { super(); this.x = x; this.y = y; this.hd = hd; this.idx = idx; this.r = 3; this.kind = 'summon'; this.sy = y; this.ph = hash(idx * 9) * TAU; }
  upd() { this.sy = this.y; }
  shd(g: Gfx) { g.s.dl = 8; g.s.ellipse(this.x, this.y + 2, 4, 2, P.bk); g.s.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, fx = Math.cos(this.hd), fy = Math.sin(this.hd), qx = -fy, qy = fx, y = this.y - this.z - 2, w2 = Math.sin(t * 22 + this.ph) * 0.8;
    for (let i = 0; i < 2; i++) for (const s of [-1, 1]) { const ph = Math.sin(t * 28 + i * 2 + (s > 0 ? 1.6 : 0)); L.line(this.x - fx * i * 2 + qx * s, y + 1 - fy * i * 1.5 + qy * s * 0.6, this.x - fx * i * 2 + qx * s * 4 + fx * ph * 1.5, y + 3 + qy * s * 2, P.n3); }
    const segs: Seg[] = [{ x: this.x - fx * 5 - qx * w2 * 1.4, y: y - fy * 4, r: 2.4 }, { x: this.x - fx * 2.6 + qx * w2, y: y - fy * 2, r: 2.5 }, { x: this.x + fx * 0.6, y: y + fy * 0.4, r: 2.3 }];
    wormBody(L, segs, PAL.chitin, {});
    L.px(Math.round(segs[0].x), Math.round(segs[0].y - 1), Math.sin(t * 8 + this.ph) > 0 ? P.c3 : P.c1);
    const hx = this.x + fx * 3.2, hy = y + fy * 2;
    ball(L, hx, hy, 1.9, PAL.chitin); L.px(Math.round(hx + qx), Math.round(hy + qy - 1), P.g2); L.px(Math.round(hx - qx), Math.round(hy - qy - 1), P.g2);
    shard(L, hx + fx, hy + fy, this.hd + 0.4, 2.6, 0.7, P.i0, P.i2, P.w); shard(L, hx + fx, hy + fy, this.hd - 0.4, 2.6, 0.7, P.i0, P.i2, P.w);
  }
  lit(g: Gfx) { glow(g.l, this.x, this.y - 3, 3.5, P.c1, 0.22, 2); }
}
function* hatchery(c: Cast) {
  const w = c.w; castAnim(w, c);
  yield 0.04;
  const [hx, hy] = handPos(w), cx = c.tx, cy = c.ty;
  throwArc(w, 'cocoon', hx, hy, cx, cy, 0.42, 38, () => 0, 5);
  yield 0.42;
  const cocoon = new Cocoon(cx, cy); w.add(cocoon);
  const impact = new Hits(), bites = new Hits(), fin = new Hits(), res = new Hits();
  ringAt(c, cx, cy, 34, 0.28, 40, { kind: 'impact', knock: 150, stag: 0.4, h: impact, cols: [P.w, P.g1, P.n3], w: 3, dust: true });
  w.shake(5, 0.3); w.shock(cx, cy, 42, 0.3, 2.5); w.add(new Decal(cx, cy, 'cracks', 24, 9, c.id, { a: P.k0, b: P.n3, c: P.g1 }, 0, 1)); chips(w, cx, cy, 10, 90, P.n2, P.n0, P.g1, { z: 4, up: 90 }); dust(w, cx, cy, 8, 30, 5);
  for (const k of ticks(0.45)) { cocoon.open = smooth(k); cocoon.z = Math.sin(k * Math.PI) * -1; yield F; }
  const swarm: Hatchling[] = []; let released = 0, tm = 0;
  const release = (sec: number) => {
    cocoon.ruptured[sec] = true; cocoon.glowAdd = 0.3; w.shake(1.5, 0.12);
    for (let i = 0; i < 4; i++) {
      const a = (sec - 1) * 1.0 + (i - 1.5) * 0.7 + Math.PI / 2, hh = new Hatchling(cx + Math.cos(a) * 9, cy - 4 + Math.sin(a) * 4, a, released++);
      hh.vx = Math.cos(a) * 60; hh.vy = Math.sin(a) * 50; hh.z = 10; swarm.push(hh); w.add(hh);
    }
    drops(w, cx + (sec - 1) * 8, cy - 8, 12, 70, P.g2, P.c3, P.c1, { z: 10, glow: 1, up: 80 }); shards(w, cx, cy - 8, 3, 60, P.n2, P.n0, P.g1, { z: 12, land: 3, size: [2, 4] });
    w.add(new Flash(cx + (sec - 1) * 8, cy - 12, 10, P.g2, 0.25, 8));
  };
  const pulseT = [0.15, 0.7, 1.25], T_RET = 4.6, T_END = 5.7;
  let phase = 0;
  for (; tm < T_END; tm += F) {
    for (let s = 0; s < 3; s++) { const q = tm - pulseT[s]; if (q >= 0 && q < 0.4) cocoon.pulseY = q / 0.4; if (q >= 0.4 && q < 0.4 + F && !cocoon.ruptured[s]) { release(s); } }
    if (tm > 1.8 && cocoon.pulseY >= 0 && tm - pulseT[2] > 0.4) cocoon.pulseY = -1;
    if (tm > T_RET && phase === 0) phase = 1;
    // flock steering
    const live = swarm.filter(h => !h.dead && !h.absorb);
    let gx = 0, gy = 0; for (const h of live) { gx += h.x; gy += h.y; } if (live.length) { gx /= live.length; gy /= live.length; }
    for (const h of live) {
      h.z = Math.max(0, h.z - 90 * F); h.cd -= F; h.recoil -= F;
      if (phase === 0 && (!alive(h.tgt))) {
        const cand = w.enemies.filter(e => e.dying <= 0).map(e => ({ e, d: Math.hypot(e.x - h.x, e.y - h.y) })).sort((a, b) => a.d - b.d);
        h.tgt = cand.length ? cand[Math.min(cand.length - 1, h.idx % 3)].e : null;
      }
      let tx = h.x, ty = h.y;
      if (phase === 1) { tx = cx; ty = cy - 4; } else if (h.tgt) { tx = h.tgt.x; ty = h.tgt.y; } else { tx = cx; ty = cy; }
      const d = Math.hypot(tx - h.x, ty - h.y) || 1;
      let ux = (tx - h.x) / d, uy = (ty - h.y) / d;
      const sw = Math.sin(tm * 3.2 + h.ph) * (phase === 0 ? 0.8 : 0.5) * clamp(d / 40, 0.2, 1);
      let vx = ux - uy * sw, vy = uy + ux * sw;
      let sx = 0, sy = 0, ax = 0, ay = 0, n = 0;
      for (const o of live) { if (o === h) continue; const dx = h.x - o.x, dy = h.y - o.y, dd = Math.hypot(dx, dy); if (dd < 7 && dd > 0.1) { sx += dx / dd * (7 - dd) * 0.25; sy += dy / dd * (7 - dd) * 0.25; } if (dd < 32) { ax += o.vx; ay += o.vy; n++; } }
      if (n) { vx += (ax / n / 90) * 0.35; vy += (ay / n / 90) * 0.35; }
      vx += sx; vy += sy; vx += ((gx - h.x) / 100) * 0.12; vy += ((gy - h.y) / 100) * 0.12;
      const vl = Math.hypot(vx, vy) || 1, spd = (h.recoil > 0 ? -35 : phase === 1 ? 105 : 88) * (1 + 0.1 * Math.sin(h.ph));
      h.vx += (vx / vl * spd - h.vx) * 0.14; h.vy += (vy / vl * spd - h.vy) * 0.14;
      h.x += h.vx * F; h.y += h.vy * F; h.hd += angDiff(h.hd, Math.atan2(h.vy, h.vx)) * 0.25 * (h.recoil > 0 ? 0 : 1);
      h.x = clamp(h.x, 6, w.W - 6); h.y = clamp(h.y, 8, w.H - 6);
      if (phase === 1 && Math.hypot(h.x - cx, h.y - cy + 4) < 7) { h.absorb = true; h.dead = true; cocoon.glowAdd = Math.min(1, cocoon.glowAdd + 0.1); w.add(new Flash(cx, cy - 10, 8, P.g2, 0.15, 4)); }
      if (phase === 1 && Math.floor(tm * 60) % 3 === 0) w.parts.add({ k: 'mote', x: h.x, y: h.y, z: 3, max: 0.3, c1: P.c2, c2: P.g1, glow: 1 });
      if (phase === 0) for (const e of w.enemies) {
        if (e.dying > 0 || h.cd > 0) continue;
        if (Math.hypot(e.x - h.x, e.y - h.y) < e.r + 3.5 && bites.ok(e, w.time, 0.2, 6)) {
          hitE(c, e, 14, { kind: 'bite', k: 40, from: [h.x, h.y], stag: 0.12, at: [h.x, h.y] }); h.cd = 0.55; h.recoil = 0.14;
          w.parts.add({ k: 'spark', x: h.x, y: h.y, z: 4, vx: h.vx * 0.3, vy: -10, vz: 20, max: 0.2, c1: P.g2 });
        }
      }
    }
    if (phase === 1 && live.length === 0 && tm > T_RET + 0.3) break;
    yield F;
  }
  for (const h of swarm) if (!h.dead) { h.dead = true; w.add(new Flash(h.x, h.y, 5, P.g2, 0.15, 3)); }
  // fuse into a briefly recognisable insect, then collapse
  for (const k of ticks(1.0)) { cocoon.trans = k; cocoon.shake = 0.4 + k * 1.4; cocoon.z = k * 4; if (Math.floor(k * 60) % 4 === 0) { w.parts.add({ k: 'spark', x: cx + c.rng.range(-16, 16), y: cy - 14 + c.rng.range(-14, 14), z: 2, vx: 0, vy: 0, vz: 20, max: 0.3, c1: P.g2 }); } yield F; }
  yield 0.35;
  for (const k of ticks(0.22)) { cocoon.trans = 1 - k * 0.2; cocoon.shake = 3; yield F; }
  cocoon.dead = true; cocoon.push = false;
  w.screenFlash(P.g2, 0.45, 0.18); w.shake(7, 0.5); w.shock(cx, cy - 10, 100, 0.5, 4); w.hitstop = 0.05;
  ringAt(c, cx, cy, 82, 0.42, 110, { kind: 'burst', knock: 190, stag: 0.5, h: fin, cols: [P.w, P.g2, P.c1], w: 5, dust: true });
  w.add(new Flash(cx, cy - 12, 38, P.c3, 0.4, 10));
  chips(w, cx, cy - 12, 38, 170, P.n2, P.n0, P.g1, { z: 14, up: 180, size: [3, 7] }); chips(w, cx, cy - 12, 12, 130, P.g2, P.g0, P.w, { z: 14, up: 150, size: [3, 5] });
  drops(w, cx, cy - 12, 46, 150, P.c1, P.c3, P.e2, { z: 14, up: 170, glow: 2, size: [2, 4], max: 2.4 });
  for (let i = 0; i < 24; i++) w.parts.add({ k: 'mote', x: cx, y: cy - 10, z: 12, vx: c.rng.range(-80, 80), vy: c.rng.range(-60, 60), vz: c.rng.range(20, 100), grav: 40, max: c.rng.range(1.2, 2.4), c1: P.c2, c2: P.g1, glow: 2, drag: 1.2 });
  w.add(new Pool(cx, cy, 28, MAT.acid, 6, { blobs: 7, boil: 2, tick: { every: 0.85, amt: c.d(15.33), opts: { kind: 'acid', src: c.def.id }, h: res, max: 3 } }));
  w.add(new Decal(cx, cy, 'crater', 20, 8, c.id, { a: P.k0, b: P.n3, c: P.g1 }, 0, 1.2));
  for (let i = 0; i < 4; i++) { const a = (i / 4) * TAU; plume(w, cx + Math.cos(a) * 14, cy + Math.sin(a) * 9, 24, 1.0, VAP.gold, 9, i, i * 0.05); }
  yield 1.1;
}

// =============== 08 BRINE SERPENTS ===============
const SERP: Pal = { o: P.k0, d: hxn(0x0d2b2a), b: P.v0, l: P.v1, s: P.v3 };
function hxn(n: number): Col { return (0xff000000 | ((n & 255) << 16) | (n & 0xff00) | ((n >> 16) & 255)) >>> 0; }
class Serpent extends Fx {
  ch: Chain; z = 0; hd: number; reveal = 0; n = 16; gone = 0; trail: { x: number; y: number }[] = []; mode = 'seek'; tgt: Enemy | null = null; aux = 0; auxT = 0; seq: Enemy[] = []; si = 0; bitten = false;
  constructor(x: number, y: number, hd: number, public role: number, public ph: number) { super(); this.x = x; this.y = y; this.hd = hd; this.ch = new Chain(x, y, 16, 3.1, hd); this.kind = 'summon'; this.sy = y; }
  upd() { this.ch.move(this.x, this.y); this.sy = this.y; const l = this.trail[this.trail.length - 1]; if (!l || Math.hypot(l.x - this.x, l.y - this.y) > 3) { this.trail.push({ x: this.x, y: this.y }); if (this.trail.length > 18) this.trail.shift(); } }
  rad(i: number) { const u = i / this.n; return (i === 0 ? 3.1 : 3.5 * (1 - u * 0.75) + 0.6) * (1 - this.z * 0.015); }
  gnd(g: Gfx) {
    const f = g.f, s = this.ch.s; f.reset(); const k = clamp(1 - this.z / 9, 0, 1), gn = this.gone;
    for (let i = 0; i < this.n - 1; i++) { if (i < gn) continue; f.capsule(s[i].x, s[i].y + this.z * 0.6, s[i + 1].x, s[i + 1].y + this.z * 0.6, (this.rad(i) + 0.8) * k, (this.rad(i + 1) + 0.8) * k); }
    for (let i = 0; i < this.trail.length - 1; i++) { const r = 1 + (i / this.trail.length) * 1.6; f.capsule(this.trail[i].x, this.trail[i].y, this.trail[i + 1].x, this.trail[i + 1].y, r * k, (r + 0.4) * k); }
    f.shade(g.s, MAT.brine, g.t, { seed: this.ph, fx: 18 });
  }
  up(g: Gfx) {
    const L = g.s, t = g.t, s = this.ch.s, vis = Math.floor(this.reveal * this.n);
    if (vis < 1) return;
    const pts: Seg[] = [];
    for (let i = this.n - 1; i >= 0; i--) { if (i < this.gone || i > vis) continue; pts.push({ x: s[i].x, y: s[i].y - 2 - this.z, r: this.rad(i) }); }
    if (!pts.length) return;
    wormBody(L, pts, SERP, { stripe: P.y1, stripeT: t * 0.6 });
    for (let i = 0; i < this.n; i++) {
      if (i < this.gone || i > vis) continue;
      const q = s[i], nxt = s[Math.min(this.n - 1, i + 1)], a = Math.atan2(q.y - nxt.y, q.x - nxt.x), px = -Math.sin(a), py = Math.cos(a), r = this.rad(i), yy = q.y - 2 - this.z;
      L.px(Math.round(q.x + px * r * 0.8), Math.round(yy + py * r * 0.8), P.v3); L.px(Math.round(q.x - px * r * 0.8), Math.round(yy - py * r * 0.8), P.v0);
      if (i > 0 && i % 2 === 1) shard(L, q.x, yy - r + 0.5, -Math.PI / 2 + Math.sin(i + t * 2) * 0.2, 2.4 - i * 0.07, 0.9, P.y2, P.v2, P.w);
      if (i % 3 === 0 && this.reveal > 0.7) L.px(Math.round(q.x), Math.round(yy), P.c2);
    }
    if (vis >= 1) {
      const h = s[0], a = this.hd, fx = Math.cos(a), fy = Math.sin(a), qx = -fy, qy = fx, hy = h.y - 2 - this.z, op = this.mode === 'lunge' ? 0.8 : 0.3 + 0.2 * Math.sin(t * 6);
      for (const sd of [-1, 1]) shard(L, h.x + fx * 2.5 + qx * sd, hy + fy * 2.5 + qy * sd, a + sd * op, 4.8, 1.2, P.y2, P.v2, P.w);
      L.px(Math.round(h.x + qx * 1.6 + fx), Math.round(hy + qy * 1.6 - 1), P.c3); L.px(Math.round(h.x - qx * 1.6 + fx), Math.round(hy - qy * 1.6 - 1), P.c3);
    }
  }
  lit(g: Gfx) { const h = this.ch.s[0]; glow(g.l, h.x, h.y - 3 - this.z, 7, P.y1, 0.2 * this.reveal, 3); if (this.reveal > 0.5) glow(g.l, this.ch.s[6].x, this.ch.s[6].y - 3 - this.z, 5, P.v2, 0.1, 2); }
}
class Ribbon extends Fx {
  len = 0; w0 = 2; hit = new Set<number>();
  constructor(x: number, y: number, public a: number, public L: number, public cc: Cast, public hh: Hits, public pz: Hits, public pool = MAT.brine) { super(); this.x = x; this.y = y; this.kind = 'ribbon'; }
  upd(w: World) {
    const k = clamp(this.age / 0.3, 0, 1); this.len = this.L * (1 - (1 - k) ** 2); this.w0 = 2 + 5 * k * (1 - clamp((this.age - 0.7) / 0.7, 0, 1));
    if (this.age > 1.4) { this.dead = true; return; }
    const ex = this.x + Math.cos(this.a) * this.len, ey = this.y + Math.sin(this.a) * this.len * 0.9;
    for (const e of w.enemies) { if (e.dying > 0) continue; if (w.segDist(e.x, e.y, this.x, this.y, ex, ey) < this.w0 + e.r * 0.7 && this.hh.ok(e, w.time, 0, 2)) { hitE(this.cc, e, 50, { kind: 'acid', k: 110, ang: this.a, stag: 0.3, at: [e.x, e.y] }); if (this.pz.ok(e, w.time)) w.poison(e, this.cc.d(50), 3, this.cc.id, this.cc.def.id); } }
  }
  gnd(g: Gfx) { const f = g.f; f.reset(); const ex = this.x + Math.cos(this.a) * this.len, ey = this.y + Math.sin(this.a) * this.len * 0.9; f.capsule(this.x, this.y, ex, ey, this.w0, this.w0 * 0.7); f.disc(ex, ey, this.w0 * 0.9, 0.2); f.shade(g.s, MAT.acid, g.t, { seed: Math.floor(this.x), dl: this.age > 1 ? Math.max(2, Math.round(16 * (1.4 - this.age) / 0.4)) : 16 }); }
}
function* serpents(c: Cast) {
  const w = c.w; castAnim(w, c);
  yield 0.04;
  const [hx, hy] = handPos(w);
  let tg = c.targets.filter(e => e.dying <= 0);
  if (tg.length < 3) { const more = w.enemies.filter(e => e.dying <= 0 && !tg.includes(e)).sort((a, b) => Math.hypot(a.x - c.tx, a.y - c.ty) - Math.hypot(b.x - c.tx, b.y - c.ty)); tg = tg.concat(more).slice(0, 3); }
  while (tg.length && tg.length < 3) tg.push(tg[tg.length - 1]);
  const ox = lerp(hx, c.tx, 0.4), oy = lerp(hy, c.ty, 0.4);
  throwArc(w, 'flask', hx, hy, ox, oy, 0.1, 5, () => 0, 22);
  yield 0.1;
  w.add(new Flash(ox, oy, 10, P.v3, 0.2, 5)); shards(w, ox, oy, 8, 80, P.v2, P.v1, P.y2, { z: 6, land: 3, size: [2, 4] }); drops(w, ox, oy, 12, 70, P.n3, P.v2, P.k1, { z: 6, up: 80 });
  const bites = new Hits(), ribs = new Hits(), pz = new Hits(), tick = new Hits();
  const S: Serpent[] = [];
  for (let i = 0; i < 3; i++) { const s = new Serpent(ox, oy, c.ang + (i - 1) * 0.9, i, i * 2.1); s.tgt = tg[i] ?? null; s.seq = i === 2 ? [tg[2], tg[0], tg[1]].filter(Boolean) : []; S.push(s); w.add(s); }
  let tm = 0;
  const T_RISE = 3.5, T_RUP = 4.3;
  const centroid = () => { let x = 0, y = 0, n = 0; for (const e of tg) if (e && e.dying <= 0) { x += e.x; y += e.y; n++; } return n ? { x: x / n, y: y / n } : { x: ox, y: oy }; };
  const bite = (s: Serpent, e: Enemy, pct: number, k: number) => {
    const a = Math.atan2(e.y - s.y, e.x - s.x);
    if (bites.ok(e, w.time, 0.3, 2)) { hitE(c, e, pct, { kind: 'bite', k, ang: a, stag: 0.35, at: [e.x - Math.cos(a) * e.r, e.y - Math.sin(a) * e.r] }); }
    else { drops(w, e.x, e.y, 4, 40, P.n3, P.v2, P.k1, { z: 5 }); }
    w.add(new Splash(e.x, e.y, 5, P.v2, P.y1));
  };
  for (; tm < T_RUP; tm += F) {
    for (const s of S) {
      s.reveal = clamp((tm - 0.1) / 0.8 + s.role * -0.05, 0, 1);
      if (tm < T_RISE) {
        // role behaviours
        let e = s.tgt; if (!alive(e)) { e = w.nearest(s.x, s.y, 220); s.tgt = e; }
        if (s.mode === 'seek' && e) {
          const dx = e.x - s.x, dy = e.y - s.y, d = Math.hypot(dx, dy) || 1, want = Math.atan2(dy, dx) + Math.sin(tm * 5.5 + s.ph) * 0.62 * clamp(d / 50, 0.1, 1);
          s.hd += clamp(angDiff(s.hd, want), -7 * F, 7 * F); const sp = s.role === 1 ? 200 : 150; s.x += Math.cos(s.hd) * sp * F; s.y += Math.sin(s.hd) * sp * F;
          if (d < e.r + 6) {
            if (s.role === 0) { s.mode = 'coil'; s.auxT = 0; s.aux = 0; }
            else if (s.role === 1) { s.mode = 'lunge'; s.auxT = 0; bite(s, e, 40, 130); }
            else { s.mode = 'visit'; s.auxT = 0; bite(s, e, 40, 70); }
          }
        } else if (s.mode === 'coil' && e) {
          s.auxT += F; const th = s.auxT * 7 + s.ph, rr = e.r + 4.5;
          s.x = e.x + Math.cos(th) * rr; s.y = e.y + Math.sin(th) * rr * 0.9; s.hd = th + Math.PI / 2; w.mark(e, 'coil', 0.2, 1); e.kx *= 0.5; e.ky *= 0.5;
          if (s.auxT > 0.2 * (s.aux + 1) && s.aux < 3) { s.aux++; if (tick.ok(e, w.time, 0.3, 3)) hitE(c, e, 20, { kind: 'pierce', stag: 0.1, at: [e.x, e.y] }); w.add(new Splash(e.x + Math.cos(th) * rr, e.y + Math.sin(th) * rr, 4, P.v2, P.y1)); }
          if (s.auxT > 1.5) s.mode = 'free';
        } else if (s.mode === 'lunge' && e) {
          s.auxT += F; const a = Math.atan2(e.y - s.y, e.x - s.x); if (s.auxT < 0.2) { s.x += Math.cos(s.hd) * 230 * F; s.y += Math.sin(s.hd) * 230 * F; } else { s.hd += 8 * F; s.x += Math.cos(s.hd) * 120 * F; s.y += Math.sin(s.hd) * 120 * F; } void a;
          if (s.auxT > 1.0) { s.mode = 'seek'; s.tgt = tg[(s.si++) % 3] ?? null; }
        } else if (s.mode === 'visit') {
          s.auxT += F; s.hd += 6 * F; s.x += Math.cos(s.hd) * 110 * F; s.y += Math.sin(s.hd) * 110 * F;
          if (s.auxT > 0.35) { s.mode = 'seek'; s.si++; s.tgt = s.seq[s.si % s.seq.length] ?? null; }
        } else if (s.mode === 'free') {
          const cc = centroid(); s.hd += clamp(angDiff(s.hd, Math.atan2(cc.y - s.y, cc.x - s.x) + 1.2), -6 * F, 6 * F); s.x += Math.cos(s.hd) * 90 * F; s.y += Math.sin(s.hd) * 90 * F;
        } else { s.hd += 3 * F; s.x += Math.cos(s.hd) * 60 * F; s.y += Math.sin(s.hd) * 60 * F; }
        s.x = clamp(s.x, 8, w.W - 8); s.y = clamp(s.y, 10, w.H - 8);
        if (Math.floor(tm * 60) % 5 === 0 && s.reveal > 0.2) w.parts.add({ k: 'drop', x: s.x, y: s.y, z: 3, vx: c.rng.range(-10, 10), vy: c.rng.range(-8, 8), vz: 30, grav: 200, size: 1, c1: P.v2, c2: P.y1, c3: P.n3, land: 1, max: 1 });
      } else {
        // rise and tighten into a coil
        const k = clamp((tm - T_RISE) / (T_RUP - T_RISE), 0, 1), cc = centroid();
        s.z = smooth(k) * 9; s.ch.gap = lerp(3.1, 2.0, smooth(k)); s.mode = 'tight';
        const th = tm * 6 + s.ph, rr = lerp(14, 8, k), ccx = s.role === 0 && alive(s.tgt) ? s.tgt!.x : cc.x + (s.role - 1) * 18, ccy = s.role === 0 && alive(s.tgt) ? s.tgt!.y : cc.y;
        s.x = lerp(s.x, ccx + Math.cos(th) * rr, 0.14); s.y = lerp(s.y, ccy + Math.sin(th) * rr * 0.8, 0.14); s.hd = th + Math.PI / 2;
      }
    }
    yield F;
  }
  // rupture along the length, head to tail
  w.screenFlash(P.v3, 0.25, 0.12); w.shake(5, 0.4);
  let released = 0;
  for (let i = 0; i < 16; i++) {
    for (const s of S) {
      const q = s.ch.s[i], nx = s.ch.s[Math.min(15, i + 1)], a = Math.atan2(q.y - nx.y, q.x - nx.x) + Math.PI / 2;
      s.gone = i + 1;
      drops(w, q.x, q.y, 3, 60, P.v2, P.y1, P.n3, { z: 6 + s.z, up: 90, glow: 1 }); shards(w, q.x, q.y, 2, 80, P.y1, P.v1, P.y2, { z: 6 + s.z, land: 1, size: [2, 4] });
      if (i % 2 === 0) { w.add(new Ribbon(q.x, q.y, a + (i % 4 ? 0 : Math.PI) + c.rng.range(-0.25, 0.25), c.rng.range(30, 46), c, ribs, pz)); w.add(new Ribbon(q.x, q.y, a + Math.PI + (i % 4 ? 0 : Math.PI) + c.rng.range(-0.25, 0.25), c.rng.range(26, 40), c, ribs, pz)); released++; }
      if (i % 4 === 0) { w.add(new Flash(q.x, q.y - 4 - s.z, 7, P.y2, 0.18, 4)); w.shock(q.x, q.y, 26, 0.2, 1.5); }
    }
    if (i % 2 === 0) w.shake(3, 0.12);
    yield 0.045;
  }
  for (const s of S) { s.dead = true; w.add(new Pool(s.ch.s[0].x, s.ch.s[0].y, 9, MAT.brine, 2.5, { blobs: 4, resid: true, boil: 1 })); }
  void released;
  yield 1.4;
}

// =============== 09 MOLTING HARVESTER ===============
class Harvester extends Fx {
  hd: number; z = 0; stage = 0; rise = 0; armA = [0, 0]; arm = 1; raise = 0; plates: boolean[] = [true, true, true, true, true, true, true, true]; crack = 0; fade = 1; shake = 0; legT = 0; moving = false; flash = 0;
  constructor(x: number, y: number, hd: number) { super(); this.x = x; this.y = y; this.hd = hd; this.r = 11; this.push = true; this.kind = 'summon'; this.sy = y; }
  upd() { this.sy = this.y; }
  shd(g: Gfx) { g.s.dl = Math.round(9 * this.fade); g.s.ellipse(this.x + 2, this.y + 6, 22 * this.rise, 9 * this.rise, P.bk); g.s.dl = 16; }
  armGeo(i: number) {
    const f = this.hd, fx = Math.cos(f), fy = Math.sin(f), qx = -fy, qy = fx, sd = i === 0 ? -1 : 1, y0 = this.y - 8 - this.z - (1 - this.rise) * 14;
    const sx = this.x + fx * 4 + qx * 9 * sd, sy = y0 + fy * 3.2 + qy * 7 * sd - 3;
    const ang = f + sd * 1.0 + this.armA[i] * -sd * 1, ex = sx + Math.cos(ang) * 9, ey = sy + Math.sin(ang) * 7;
    const bang = ang + sd * -0.55 - sd * this.raise * 0.5, bl = 20 * this.arm, tx = ex + Math.cos(bang) * bl, ty = ey + Math.sin(bang) * bl * 0.8;
    return { sx, sy, ex, ey, tx, ty, bang, ang };
  }
  up(g: Gfx) {
    const L = g.s, t = g.t, f = this.hd, fx = Math.cos(f), fy = Math.sin(f), qx = -fy, qy = fx, sh = this.shake > 0 ? Math.sin(t * 85) * this.shake : 0;
    if (this.rise <= 0.02) return;
    const x = this.x + sh, y = this.y - 8 - this.z - (1 - this.rise) * 14, mol = this.stage === 1;
    const pal = mol ? PAL.chitinHot : PAL.chitin, lc = mol ? P.g2 : P.c1, flash = this.flash > 0;
    L.dl = Math.round(16 * this.fade); if (L.dl < 1) return;
    const at = (fw: number, sd: number, up: number): [number, number] => [x + fx * fw + qx * sd, y + fy * fw * 0.8 + qy * sd * 0.8 - up];
    for (let i = 0; i < 2; i++) for (const s of [-1, 1]) {
      const ph = Math.sin(this.legT + i * 2.2 + (s > 0 ? Math.PI : 0)) * (this.moving ? 1 : 0.2), [hx, hy] = at(-3 + i * -7, s * 7, 1), [kx, ky] = at(-3 + i * -7 + ph * 2, s * 15, 6), [ex, ey] = at(-5 + i * -7 + ph * 4, s * 21, -3);
      L.line(hx, hy, kx, ky, P.k0, 4); L.line(kx, ky, ex, ey, P.k0, 3); L.line(hx, hy, kx, ky, mol ? P.u1 : P.n2, 2); L.line(kx, ky, ex, ey, mol ? P.u2 : P.n3, 1); L.px(Math.round(kx), Math.round(ky - 1), lc);
    }
    const [abx, aby] = at(-14, 0, 2);
    ball(L, abx, aby, 12, flash ? { ...pal, b: P.w } : pal, 9.5);
    for (let i = 0; i < 5; i++) { const pu = (Math.sin(t * 5 - i * 0.9) + 1) / 2; L.arc(abx, aby, 3 + i * 2, 1, f + Math.PI * 0.6, f + Math.PI * 1.4, mix(mol ? P.g0 : P.e1, lc, pu * (0.4 + (mol ? 0.5 : 0.2))), 2.5 + i * 1.7); }
    L.line(abx + fx * 4, aby + fy * 3, abx - fx * 10, aby - fy * 8, lc);
    this.plates.forEach((on, i) => { if (!on) return; const a = f + Math.PI + (i - 3.5) * 0.36, px = abx + Math.cos(a) * 9, py = aby + Math.sin(a) * 7.2; ball(L, px, py - 1, 3.2, PAL.chitin, 2.6); L.px(Math.round(px - 1), Math.round(py - 3), P.e3); });
    const [thx, thy] = at(0, 0, 3); ball(L, thx, thy, 8, pal, 6.6); L.line(thx - 4, thy - 3, thx + 4, thy - 3, lc);
    for (const s of [0, 1]) { const A = this.armGeo(s); L.line(A.sx, A.sy, A.ex, A.ey, P.k0, 5); L.line(A.sx, A.sy, A.ex, A.ey, mol ? P.u1 : P.n2, 3); ball(L, A.ex, A.ey, 3, pal); shard(L, A.ex, A.ey, Math.atan2(A.ty - A.ey, A.tx - A.ex), 20 * this.arm, 3.6, mol ? P.g2 : P.i1, mol ? P.g0 : P.i3, P.w);
      for (let k = 1; k < 7; k++) L.px(Math.round(lerp(A.ex, A.tx, k / 7) - Math.sin(A.bang) * 2), Math.round(lerp(A.ey, A.ty, k / 7) + Math.cos(A.bang) * 2), P.k0); }
    const [hdx, hdy] = at(10, 0, 4); ball(L, hdx, hdy, 5.2, pal, 4.6);
    for (const s of [-1, 1]) { shard(L, hdx + fx * 4 + qx * 2 * s, hdy + fy * 3 + qy * 2 * s, f + s * 0.45, 6.5, 1.6, P.i0, P.i2, P.w); L.disc(hdx + fx * 2 + qx * 2.6 * s, hdy + fy * 1.4 + qy * 2.6 * s - 1, 1.3, lc); L.px(Math.round(hdx + fx * 2 + qx * 2.6 * s), Math.round(hdy + fy * 1.4 + qy * 2.6 * s - 1), P.w); }
    for (let i = 0; i < Math.floor(this.crack * 8); i++) { let cx = abx + (hash(i * 5) - 0.5) * 14, cy = aby + (hash(i * 9) - 0.5) * 10, a = hash(i * 3) * TAU; for (let s = 0; s < 5 + this.crack * 5; s++) { a += (hash(s + i * 13) - 0.5) * 0.9; cx += Math.cos(a); cy += Math.sin(a) * 0.8; L.px(Math.round(cx), Math.round(cy), s % 2 ? P.c2 : P.c3); } }
    L.dl = 16;
  }
  lit(g: Gfx) { glow(g.l, this.x, this.y - 12, 22, this.stage ? P.g2 : P.c1, (this.stage ? 0.28 : 0.15) * this.rise * this.fade, 4); if (this.flash > 0) glow(g.l, this.x, this.y - 12, 34, P.w, 0.4, 4); }
}
class Cleave extends Fx {
  hit = new Hits(); cx: number; cy: number;
  constructor(x: number, y: number, public a: number, public cc: Cast) { super(); this.x = x; this.y = y; this.cx = x; this.cy = y; this.kind = 'cleave'; }
  rad() { return 22 + this.age * 60; }
  upd(w: World) {
    this.cx = this.x + Math.cos(this.a) * this.age * 270; this.cy = this.y + Math.sin(this.a) * this.age * 270 * 0.9;
    if (this.age > 0.55) { this.dead = true; return; }
    const R = this.rad();
    for (const e of w.enemies) {
      if (e.dying > 0) continue; const dx = e.x - this.cx, dy = e.y - this.cy, d = Math.hypot(dx, dy);
      if (d < R + e.r && d > R - 14 - e.r && Math.abs(angDiff(this.a, Math.atan2(dy, dx))) < 1.1 && this.hit.ok(e, w.time)) hitE(this.cc, e, 110, { kind: 'pierce', k: 220, ang: this.a, stag: 0.5, big: true, at: [e.x, e.y] });
    }
    if (Math.floor(this.age * 60) % 2 === 0) { const R2 = this.rad(), aa = this.a + (hash(this.age * 100) - 0.5) * 2; shards(w, this.cx + Math.cos(aa) * R2, this.cy + Math.sin(aa) * R2, 1, 60, P.g2, P.g0, P.w, { z: 5, ang: aa, spread: 0.6, size: [3, 6], land: 3 }); drops(w, this.cx + Math.cos(aa) * R2, this.cy + Math.sin(aa) * R2, 2, 80, P.c1, P.c3, P.e2, { z: 6, ang: aa, spread: 0.6, glow: 1 }); }
  }
  gnd(g: Gfx) {
    const L = g.s, R = this.rad(), k = 1 - this.age / 0.55;
    for (let i = 0; i < 5; i++) { L.dl = Math.max(1, Math.round((i === 0 ? 16 : 14 - i * 3) * k)); L.arc(this.cx - Math.cos(this.a) * i * 5, this.cy - Math.sin(this.a) * i * 5 * 0.9, R - i * 5, i === 0 ? 4 : 3, this.a - 1.05, this.a + 1.05, [P.w, P.c3, P.c1, P.e3, P.e1][i], (R - i * 5) * 0.9); }
    L.dl = 16;
  }
  lit(g: Gfx) { glow(g.l, this.cx + Math.cos(this.a) * this.rad(), this.cy + Math.sin(this.a) * this.rad() * 0.9, 28, P.c2, 0.3 * (1 - this.age / 0.55), 4); }
}
function* harvester(c: Cast) {
  const w = c.w; castAnim(w, c, true, 0.4);
  const p = w.player, sx = clamp(p.x + Math.cos(c.ang) * 54, 24, w.W - 24), sy = clamp(p.y + Math.sin(c.ang) * 54, 24, w.H - 24);
  const hv = new Harvester(sx, sy, c.ang); w.add(hv);
  const emerge = new Hits(), deb = new Hits(), cleave = new Hits();
  w.add(new Decal(sx, sy, 'cracks', 30, 8, c.id, { a: P.k0, b: P.n3, c: P.c1 }, 0, 1));
  for (const k of ticks(0.38)) { hv.rise = smooth(k); hv.z = (1 - k) * -10; hv.shake = (1 - k) * 2; if (Math.floor(k * 60) % 3 === 0) { dust(w, sx + c.rng.range(-16, 16), sy + c.rng.range(-4, 8), 1, 18, 4); chips(w, sx + c.rng.range(-12, 12), sy, 1, 50, P.n2, P.n0, P.n3, { z: 2, up: 80 }); } yield F; }
  hv.z = 0; hv.rise = 1; hv.shake = 0;
  ringAt(c, sx, sy, 30, 0.24, 30, { kind: 'impact', knock: 150, stag: 0.4, h: emerge, cols: [P.w, P.i1, P.n3], w: 3, dust: true }); w.shake(4, 0.3); w.shock(sx, sy, 40, 0.3, 2.5);
  let swing = 0;
  const sweep = function* (i: number, dur: number, amp: number, pct: number, hh: Hits) {
    const sw = new Hits(); const dir = i === 0 ? 1 : -1;
    for (const k of ticks(dur)) {
      hv.armA[i] = lerp(-amp, amp, smooth(k)) * dir;
      const A = hv.armGeo(i);
      for (const e of w.enemies) { if (e.dying > 0) continue; const d = Math.min(w.segDist(e.x, e.y, A.ex, A.ey, A.tx, A.ty), w.segDist(e.x, e.y, A.sx, A.sy, A.ex, A.ey)); if (d < e.r + 3.5 && sw.ok(e, w.time) && hh.ok(e, w.time, 0, 99)) hitE(c, e, pct, { kind: 'pierce', k: 150, from: [A.sx, A.sy], stag: 0.35, at: [e.x, e.y] }); }
      if (Math.floor(k * 60) % 3 === 0) { shards(w, A.tx, A.ty + 2, 1, 40, P.n3, P.n1, P.c1, { z: 3, size: [2, 3], land: 3 }); w.parts.add({ k: 'spark', x: A.tx, y: A.ty + 3, z: 2, vx: 0, vy: 0, vz: 10, max: 0.2, c1: P.c2 }); }
      yield F;
    }
    const A = hv.armGeo(i); w.add(new Decal(hv.x + Math.cos(hv.hd) * 24, hv.y + Math.sin(hv.hd) * 22, 'crescent', 20, 5.5, c.id + swing++, { a: P.k0, b: P.e1, c: P.c1 }, hv.hd + (i ? 0.2 : -0.2), 1)); w.shake(1.5, 0.1); dust(w, A.tx, A.ty + 3, 3, 20, 4);
  };
  const walk = function* (dur: number, sp: number) { hv.moving = true; for (const _ of ticks(dur)) { hv.x = clamp(hv.x + Math.cos(c.ang) * sp * F, 18, w.W - 18); hv.y = clamp(hv.y + Math.sin(c.ang) * sp * F, 20, w.H - 18); hv.legT += sp * F * 0.4; hv.z = Math.abs(Math.sin(hv.legT)) * 0.8; yield F; } hv.moving = false; };
  const sweeps = new Hits();
  // pre-molt: walk + alternating cutting sweeps (hits capped by per-sweep contact)
  const sweepHits = [new Hits(), new Hits(), new Hits(), new Hits()];
  const sweepCap = new Map<number, number>();
  for (let s = 0; s < 4; s++) {
    w.run((function* () { yield* sweep(s % 2, 0.34, 1.0, 30, { ok: (e: Enemy) => { const n = sweepCap.get(e.id) ?? 0; if (n >= 4) return false; sweepCap.set(e.id, n + 1); return true; } } as unknown as Hits); })());
    yield* walk(0.36, 62); hv.crack = (s + 1) / 5; void sweepHits;
  }
  // violent molt
  hv.crack = 1; for (const k of ticks(0.5)) { hv.shake = 1 + k * 2.5; if (Math.floor(k * 60) % 3 === 0) w.parts.add({ k: 'spark', x: hv.x + c.rng.range(-14, 14), y: hv.y - 10 + c.rng.range(-8, 8), z: 3, vx: 0, vy: -20, vz: 40, grav: 90, max: 0.35, c1: P.c3 }); yield F; }
  hv.stage = 1; hv.crack = 0; hv.shake = 0; hv.arm = 1.35; hv.flash = 0.2; w.screenFlash(P.c3, 0.2, 0.09); w.shake(5, 0.35);
  hv.plates.forEach((_, i) => {
    hv.plates[i] = false;
    const a = hv.hd + Math.PI + (i - 3.5) * 0.5, px = hv.x + Math.cos(a) * 12, py = hv.y + Math.sin(a) * 8, sp = c.rng.range(70, 120), va = a + c.rng.range(-0.4, 0.4);
    const mk = (x: number, y: number, vx: number, vy: number, vz: number, sz: number, bounce: number) => w.add(new Shot(x, y, 10, vx, vy, vz, 300, 0, (g, X, Y, _z, s) => { ball(g.s, X, Y, sz, PAL.chitin, sz * 0.8); g.s.px(Math.round(X - sz * 0.4), Math.round(Y - sz * 0.6), P.e3); void s; }, null,
      (ww, s) => { ww.add(new Ring(s.x, s.y, 15 + sz, 0.2, { w: 2, cols: [P.i0, P.i2, P.n3], hit: { h: deb, amt: c.d(25), opts: { kind: 'impact', src: c.def.id }, knock: 90, stagger: 0.3, max: 2 } })); dust(ww, s.x, s.y, 3, 22, 4); chips(ww, s.x, s.y, 4, 70, P.n2, P.n0, P.n3, { z: 3 }); ww.shake(1.5, 0.12); ww.add(new Decal(s.x, s.y, 'cracks', 7, 5, Math.floor(s.x), { a: P.k0, b: P.n3, c: P.c1 }, 0, 1));
        if (bounce > 0) mk(s.x, s.y, s.vx * 0.5, s.vy * 0.5, 120, sz * 0.8, bounce - 1); }, 4, 12));
    mk(px, py, Math.cos(va) * sp, Math.sin(va) * sp * 0.8, c.rng.range(120, 200), c.rng.range(3, 5), i % 3 === 0 ? 1 : 0);
  });
  chips(w, hv.x, hv.y - 8, 18, 130, P.n2, P.n0, P.e3, { z: 10, up: 130, size: [2, 5] }); drops(w, hv.x, hv.y - 8, 20, 100, P.g2, P.c3, P.c1, { z: 10, glow: 2, up: 120 });
  for (const _ of ticks(0.3)) { hv.flash -= F; yield F; } hv.flash = 0;
  // newly exposed limbs: rapid attacks
  const rapid = { ok: (() => { const m = new Map<number, number>(); return (e: Enemy) => { const n = m.get(e.id) ?? 0; if (n >= 3) return false; m.set(e.id, n + 1); return true; }; })() } as unknown as Hits;
  for (let s = 0; s < 3; s++) { w.run((function* () { yield* sweep(s % 2, 0.16, 1.15, 30, rapid); })()); yield* walk(0.19, 66); }
  yield* walk(0.12, 50);
  // gigantic cleave
  for (const k of ticks(0.38)) { hv.raise = smooth(k); hv.armA[0] = lerp(0, -0.6, k); hv.armA[1] = lerp(0, 0.6, k); hv.shake = k * 1.2; hv.z = k * 3; yield F; }
  hv.shake = 0;
  for (const k of ticks(0.12)) { hv.raise = lerp(1, -0.4, k); hv.armA[0] = lerp(-0.6, 1.1, k); hv.armA[1] = lerp(0.6, -1.1, k); hv.z = lerp(3, 0, k); yield F; }
  w.add(new Cleave(hv.x + Math.cos(hv.hd) * 14, hv.y + Math.sin(hv.hd) * 12, hv.hd, c)); void cleave;
  w.shake(7, 0.4); w.shock(hv.x + Math.cos(hv.hd) * 30, hv.y + Math.sin(hv.hd) * 26, 90, 0.4, 4); w.screenFlash(P.c2, 0.25, 0.1);
  w.add(new Decal(hv.x + Math.cos(hv.hd) * 34, hv.y + Math.sin(hv.hd) * 30, 'crescent', 38, 7, c.id + 99, { a: P.k0, b: P.e1, c: P.c1 }, hv.hd, 1));
  chips(w, hv.x + Math.cos(hv.hd) * 30, hv.y + Math.sin(hv.hd) * 26, 24, 160, P.n2, P.n0, P.g1, { z: 8, up: 100, ang: hv.hd, spread: 1.6, size: [3, 6] });
  yield 0.5;
  for (const k of ticks(0.6)) { hv.fade = 1 - k; hv.z = k * -6; if (Math.floor(k * 60) % 4 === 0) dust(w, hv.x + c.rng.range(-14, 14), hv.y + 4, 1, 14, 4); yield F; }
  hv.dead = true; void sweeps;
  drops(w, hv.x, hv.y, 14, 70, P.c1, P.c3, P.e2, { z: 6, glow: 1 }); w.add(new Pool(hv.x, hv.y, 14, MAT.acid, 2.4, { blobs: 4, boil: 1 }));
}

// =============== 10 THE WALKING CRUCIBLE ===============
class Crucible extends Fx {
  asm = 0; z = 0; heat = 0; shake = 0; swell = 1; cs = 1; compress = 0; spread = 1; face = 0; tilt = 0; crouch = 0; steps: number[] = [0, 0, 0, 0, 0, 0];
  foot: { x: number; y: number; tx: number; ty: number; lift: number; from: { x: number; y: number } }[] = [];
  static HIP: [number, number][] = [[-22, -9], [0, -13], [22, -9], [-22, 9], [0, 13], [22, 9]];
  static REST: [number, number][] = [[-38, -22], [0, -32], [38, -22], [-38, 22], [0, 32], [38, 22]];
  constructor(x: number, y: number) { super(); this.x = x; this.y = y; this.r = 28; this.push = true; this.tank = true; this.hp = this.maxHp = 5000; this.kind = 'summon'; this.sy = y; for (let i = 0; i < 6; i++) { const [rx, ry] = Crucible.REST[i]; this.foot.push({ x: x + rx, y: y + ry, tx: x + rx, ty: y + ry, lift: 0, from: { x: x + rx, y: y + ry } }); } }
  upd() { this.sy = this.y; }
  chamber(i: number): [number, number] { const s = i % 2 ? 1 : -1, r = i < 2 ? -1 : 1; return [this.x + s * 30, this.y - (28 + this.z - this.crouch) + 4 + r * 2 + (i < 2 ? -4 : 6)]; }
  shd(g: Gfx) { g.s.dl = 9; g.s.ellipse(this.x + 4, this.y + 8, 44 * this.asm, 18 * this.asm, P.bk); g.s.dl = 16; }
  gnd(g: Gfx) { if (this.asm < 1) return; g.s.dl = 5; g.s.ellipse(this.x, this.y + 4, 38, 14, P.k0); g.s.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, asm = this.asm; if (asm <= 0.01) return;
    const sh = this.shake > 0 ? Math.sin(t * 88) * this.shake : 0, bx = this.x + sh, by = this.y - (30 + this.z - this.crouch) + (1 - asm) * 50, heat = this.heat;
    const hot = mix(P.c1, mix(P.g2, P.w, heat), heat);
    const leg = (i: number) => {
      const [hx0, hy0] = Crucible.HIP[i], hx = bx + hx0, hy = by + hy0 * 0.5 + 6, f = this.foot[i], fy = f.y - Math.sin(f.lift * Math.PI) * 11, fx = f.x;
      const dxl = fx - hx, kx = (hx + fx) / 2 + (hx0 < 0 ? -1 : hx0 > 0 ? 1 : 0) * 6, ky = Math.min(hy, fy) - 10 + Math.abs(dxl) * 0.15;
      L.line(hx, hy, kx, ky, P.k0, 7); L.line(kx, ky, fx, fy, P.k0, 7); L.line(hx, hy, kx, ky, P.i1, 5); L.line(kx, ky, fx, fy, P.i2, 5); L.line(hx - 1, hy - 1, kx - 1, ky - 1, P.i0); L.line(kx - 1, ky - 1, fx - 1, fy - 1, P.i0);
      ball(L, hx, hy, 3.4, PAL.iron); ball(L, kx, ky, 3.6, PAL.iron); L.disc(kx, ky, 1, mix(P.u1, hot, heat)); L.ellipse(fx, fy + 1, 6, 3.2, P.k0); L.ellipse(fx, fy, 5.2, 2.7, P.i1); L.ellipse(fx - 1, fy - 1, 3, 1.4, P.i0);
    };
    for (let i = 0; i < 3; i++) leg(i);
    // platform body
    const rx = 28, ry = 14;
    L.poly([bx - rx, by, bx - rx * 0.5, by - ry, bx + rx * 0.5, by - ry, bx + rx, by, bx + rx * 0.5, by + ry, bx - rx * 0.5, by + ry], P.n0);
    L.poly([bx - rx + 2, by, bx - rx * 0.5 + 1, by - ry + 2, bx + rx * 0.5 - 1, by - ry + 2, bx + rx - 2, by, bx + rx * 0.5 - 1, by + ry - 2, bx - rx * 0.5 + 1, by + ry - 2], P.i1);
    L.poly([bx - rx + 6, by, bx - rx * 0.5 + 2, by - ry + 5, bx + rx * 0.5 - 2, by - ry + 5, bx + rx - 6, by, bx + rx * 0.5 - 2, by + ry - 5, bx - rx * 0.5 + 2, by + ry - 5], P.i0);
    L.poly([bx - rx, by, bx - rx * 0.5, by + ry, bx + rx * 0.5, by + ry, bx + rx, by, bx + rx, by + 7, bx + rx * 0.5, by + ry + 7, bx - rx * 0.5, by + ry + 7, bx - rx, by + 7], P.i3);
    L.line(bx - rx * 0.5, by + ry + 7, bx + rx * 0.5, by + ry + 7, P.k0); L.line(bx - rx, by + 7, bx - rx * 0.5, by + ry + 7, P.k0); L.line(bx + rx, by + 7, bx + rx * 0.5, by + ry + 7, P.k0);
    for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU; const x0 = bx + Math.cos(a) * 22, y0 = by + Math.sin(a) * 10; L.px(Math.round(x0), Math.round(y0), P.u0); L.px(Math.round(x0) + 1, Math.round(y0), P.u2); }
    // heat channels between chambers and the main reservoir
    const ctr: [number, number] = [bx, by - 14];
    for (let i = 0; i < 4; i++) {
      const [cx0, cy0] = this.chamber(i), cx = cx0 + sh;
      const mid = [(cx + ctr[0]) / 2, Math.max(cy0, ctr[1]) + 8];
      const path = (u: number): [number, number] => [lerp(lerp(cx, mid[0], u), lerp(mid[0], ctr[0], u), u), lerp(lerp(cy0, mid[1], u), lerp(mid[1], ctr[1], u), u)];
      let pv = path(0); for (let k = 1; k <= 12; k++) { const q = path(k / 12); L.line(pv[0], pv[1], q[0], q[1], P.u0, 3); L.line(pv[0], pv[1], q[0], q[1], P.u1, 1); pv = q; }
      const flow = this.compress > 0 ? 1 - ((t * 1.6 + i * 0.25) % 1) : (t * (0.6 + heat) + i * 0.25) % 1;
      for (let k = 0; k < 3; k++) { const u = (flow + k / 3) % 1, q = path(u); L.disc(q[0], q[1], 1, hot); L.px(Math.round(q[0]), Math.round(q[1]), P.w); }
    }
    // central reservoir + four chambers
    const rr = 14 * this.swell * (1 + heat * 0.08);
    drawFlask(L, bx, by - 20, rr, 0.5 + heat * 0.35, Math.sin(t * 2 + this.tilt) * 0.3 + this.tilt, LIQ.acid, t * (1 + heat * 3), PAL.glassHi);
    L.ring(bx, by - 20, rr + 1, 1, P.u1); L.rect(Math.round(bx) - 5, Math.round(by - 20 - rr) - 3, 10, 3, P.u1); L.rect(Math.round(bx) - 5, Math.round(by - 20 - rr) - 3, 10, 1, P.u2);
    for (let i = 0; i < Math.floor(heat * 14); i++) { let x = bx + (hash(i * 7) - 0.5) * rr * 1.2, y = by - 20 + (hash(i * 11) - 0.5) * rr * 1.2, a = hash(i * 3) * TAU; for (let s = 0; s < 5 + heat * 7; s++) { a += (hash(s + i * 20) - 0.5) * 0.9; x += Math.cos(a); y += Math.sin(a) * 0.8; L.px(Math.round(x), Math.round(y), s % 2 ? P.w : P.g2); } }
    for (let i = 0; i < 4; i++) {
      const [cx0, cy0] = this.chamber(i), cx = cx0 + sh, r = 7.5 * this.cs;
      if (r < 1.5) continue;
      L.line(cx, cy0 + r, cx, cy0 + r + 5, P.u0, 3); drawFlask(L, cx, cy0, r, 0.55 + heat * 0.3, this.tilt * 0.8 + Math.sin(t * 2.4 + i) * 0.35, i % 2 ? LIQ.mag : i === 2 ? LIQ.cyan : LIQ.acid, t * (1 + heat * 2) + i, PAL.glassHi);
      L.ring(cx, cy0, r + 1, 1, P.u1); L.rect(Math.round(cx) - 2, Math.round(cy0 - r) - 2, 5, 2, P.u2);
      if (heat > 0.5) for (let k = 0; k < Math.floor((heat - 0.5) * 8); k++) { const a = hash(k + i * 5) * TAU; L.line(cx + Math.cos(a) * 2, cy0 + Math.sin(a) * 2, cx + Math.cos(a + 0.6) * r * 0.9, cy0 + Math.sin(a + 0.6) * r * 0.9, P.w); }
    }
    for (let i = 3; i < 6; i++) leg(i);
  }
  lit(g: Gfx) { const by = this.y - (30 + this.z - this.crouch); glow(g.l, this.x, by - 20, 28 * this.swell, mix(P.c1, P.g2, this.heat), 0.22 + this.heat * 0.4, 5); for (let i = 0; i < 4; i++) { const [cx, cy] = this.chamber(i); glow(g.l, cx, cy, 11 * this.cs, i % 2 ? P.m1 : P.c1, 0.2 + this.heat * 0.2, 3); } }
}
function* crucible(c: Cast) {
  const w = c.w; castAnim(w, c, true, 0.45);
  const cx = c.tx, cy = c.ty, cr = new Crucible(cx, cy); cr.face = c.ang;
  const steps = new Hits(), streams = new Hits(), bubs = new Hits(), vaps = new Hits(), shock1 = new Hits(), sheets = new Hits(), chunks = new Hits(), fvap = new Hits();
  w.add(new Decal(cx, cy, 'cracks', 52, 14, c.id, { a: P.k0, b: P.i3, c: P.c1 }, 0, 1)); w.add(new Decal(cx, cy, 'veins', 40, 12, c.id + 1, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1));
  w.add(cr);
  const stomp = (x: number, y: number, big = false) => {
    ringAt(c, x, y, big ? 40 : 17, big ? 0.3 : 0.18, big ? 15 : 15, { kind: 'impact', knock: big ? 150 : 110, stag: 0.3, h: steps, max: 5, cols: [P.w, P.i1, P.i3], w: 2, dust: false });
    dust(w, x, y, big ? 8 : 3, big ? 30 : 16, big ? 5 : 3); w.shake(big ? 5 : 1.6, big ? 0.35 : 0.14); if (big) w.shock(x, y, 48, 0.3, 3);
    w.add(new Decal(x, y, 'cracks', big ? 18 : 8, 5, Math.floor(x * 7 + y), { a: P.k0, b: P.i3, c: P.c1 }, 0, 1)); chips(w, x, y, big ? 6 : 2, 60, P.i0, P.i2, P.w, { z: 2, size: [2, 3] });
  };
  for (const k of ticks(0.75)) {
    cr.asm = smooth(k); cr.z = (1 - smooth(k)) * 0; cr.shake = (1 - k) * 1.8;
    if (Math.floor(k * 60) % 3 === 0) { dust(w, cx + c.rng.range(-36, 36), cy + c.rng.range(-6, 12), 1, 20, 5); chips(w, cx + c.rng.range(-30, 30), cy + c.rng.range(-4, 10), 1, 40, P.i0, P.i2, P.w, { z: 0, up: 100, size: [2, 4] }); }
    yield F;
  }
  cr.asm = 1; cr.shake = 0; for (let i = 0; i < 6; i++) { const f = cr.foot[i]; f.x = cx + Crucible.REST[i][0]; f.y = cy + Crucible.REST[i][1]; }
  stomp(cx, cy + 4, true);
  const T_WALK = 8.4; let tm = 0, mode = 0, nextAtk = 0.9, shed = 0;
  const findCluster = () => { let bx = 0, by = 0, bn = -1; for (const e of w.enemies) { if (e.dying > 0) continue; let n = 0; for (const o of w.enemies) if (o.dying <= 0 && Math.hypot(o.x - e.x, o.y - e.y) < 60) n++; if (n > bn) { bn = n; bx = e.x; by = e.y; } } return bn >= 0 ? { x: bx, y: by } : { x: cx + 80, y: cy }; };
  let goal = findCluster(), gT = 0;
  for (; tm < T_WALK; tm += F) {
    cr.heat = clamp((tm - 0.8) / (T_WALK - 0.8), 0, 1); cr.tilt = Math.sin(tm * 2.2) * 0.25;
    gT -= F; if (gT <= 0) { goal = findCluster(); gT = 1; }
    const dx = goal.x - cr.x, dy = goal.y - cr.y, d = Math.hypot(dx, dy) || 1;
    if (d > 38) { cr.x = clamp(cr.x + (dx / d) * 24 * F, 30, w.W - 30); cr.y = clamp(cr.y + (dy / d) * 24 * F, 36, w.H - 20); cr.face = Math.atan2(dy, dx); }
    cr.z = Math.abs(Math.sin(tm * 3.1)) * 1.4;
    // tripod gait: feet re-plant toward their rest position
    for (let i = 0; i < 6; i++) {
      const f = cr.foot[i], rx = cr.x + Crucible.REST[i][0] * cr.spread, ry = cr.y + Crucible.REST[i][1] * cr.spread;
      if (f.lift > 0) { f.lift += F * 2.6; f.x = lerp(f.from.x, f.tx, smooth(f.lift)); f.y = lerp(f.from.y, f.ty, smooth(f.lift)); if (f.lift >= 1) { f.lift = 0; f.x = f.tx; f.y = f.ty; stomp(f.x, f.y); } }
      else if (Math.hypot(f.x - rx, f.y - ry) > 20 && !cr.foot.some((o, j) => o.lift > 0 && (j % 2) !== (i % 2))) { f.lift = 0.001; f.from = { x: f.x, y: f.y }; f.tx = rx + (dx / d) * 8; f.ty = ry + (dy / d) * 5; }
    }
    // chamber attacks in rotation
    if (tm > nextAtk) {
      nextAtk = tm + 0.82; const ch = Math.floor(tm / 0.82) % 4, [sx, sy] = cr.chamber(ch);
      const tg = w.nearest(goal.x, goal.y, 200) ?? null, tx = tg ? tg.x : goal.x, ty = tg ? tg.y : goal.y, ang = Math.atan2(ty - sy, tx - sx);
      const m = mode++ % 3;
      if (m === 0) {
        const net = new FlowNet(MAT.acid, 1.4), len = Math.min(90, Math.hypot(tx - sx, ty - sy) + 20), ex = sx + Math.cos(ang) * len, ey = sy + Math.sin(ang) * len * 0.8 + 18;
        net.add(mkBranch([{ x: sx, y: sy + 12 }, { x: lerp(sx, ex, 0.5), y: lerp(sy + 12, ey, 0.5) - 10 }, { x: ex, y: ey }].flatMap((q, i, a) => i === 0 ? [q] : [{ x: (a[i - 1].x + q.x) / 2, y: (a[i - 1].y + q.y) / 2 }, q]), 5, 0, 300, ch));
        net.tick = { every: 0.28, amt: c.d(20), opts: { kind: 'acid', src: c.def.id }, h: streams, max: 5, mark: 'corrode', markDur: 2.5 }; w.add(net);
        drops(w, sx, sy + 8, 8, 60, P.c1, P.c3, P.e2, { z: 14, ang, spread: 1, glow: 1 });
      } else if (m === 1) {
        const bub = new Proj(sx, sy, tx, ty, 0.55, 22, (g, x, y, _z, a) => { const r = 4 + a * 3; bubbleBig(g, x, y, r); }, (ww, pr) => {
          ww.add(new Custom(pr.tx, pr.ty, 0.5, { up: (g, a) => { const sw = 1 + Math.sin(a * 30) * 0.06 * a; bubbleBig(g, pr.tx, pr.ty - 5 - a * 2, 7 * sw); }, lit: (g, a) => glow(g.l, pr.tx, pr.ty - 6, 12, P.c1, 0.2 + a * 0.3, 3) }, pr.ty));
          ww.run((function* () { yield 0.5; const X = pr.tx, Y = pr.ty; ringAt(c, X, Y - 2, 26, 0.24, 33, { kind: 'burst', knock: 120, stag: 0.35, h: bubs, max: 3, cols: [P.w, P.c1, P.e2], w: 3 }); drops(ww, X, Y, 16, 90, P.c1, P.c3, P.e2, { z: 8, up: 110, glow: 1 }); ww.add(new Flash(X, Y - 5, 16, P.c3, 0.2, 5)); ww.add(new Splash(X, Y, 8, P.c1, P.c3)); ww.shake(2, 0.15); ww.add(new Pool(X, Y, 8, MAT.acid, 2, { blobs: 3, boil: 1 })); })());
        }, undefined, 4);
        w.add(bub);
      } else {
        const cl = new Cloud(sx, sy + 8, mkPuffs(c.rng, 7, 10, 8, 13, 5, 1.6), VAP.green, 3.4, c.id + ch); cl.vx = Math.cos(ang) * 30; cl.vy = Math.sin(ang) * 26; cl.grow = { from: 0.5, to: 1.5, dur: 1.6 }; cl.tickInfo = { every: 0.5, amt: c.d(13), opts: { kind: 'acid', src: c.def.id }, h: vaps, max: 6, mark: 'miasma' }; w.add(cl);
      }
    }
    // overheating: shed armor and glass
    if (cr.heat > 0.35 && tm > shed) { shed = tm + 0.55; const a = c.rng.range(0, TAU); const [px, py] = [cr.x + Math.cos(a) * 26, cr.y - 34 + Math.sin(a) * 12]; chips(w, px, py, 2, 30, P.i0, P.i2, P.w, { z: 22, up: 20, size: [2, 4] }); shards(w, px, py, 2, 20, P.v2, P.v1, P.y2, { z: 24, up: 10, land: 2, size: [2, 4] }); drops(w, px, py, 2, 20, P.c1, P.c3, P.e2, { z: 22, up: 0, glow: 1 }); if (cr.heat > 0.6) steam(w, cr.x + c.rng.range(-10, 10), cr.y - 60, 1, 8, P.v2, P.y2, 4, { z: 6, vz: 18 }); }
    yield F;
  }
  // plant all limbs and compress the reservoirs into one central chamber
  for (let i = 0; i < 6; i++) { const f = cr.foot[i]; f.lift = 0; }
  for (const k of ticks(1.2)) {
    cr.heat = 1; cr.compress = k; cr.spread = lerp(1, 1.3, smooth(k)); cr.crouch = smooth(k) * 6; cr.cs = lerp(1, 0.3, smooth(k)); cr.swell = lerp(1, 1.75, smooth(k * k)); cr.shake = 0.8 + k * 2.4;
    for (let i = 0; i < 6; i++) { const f = cr.foot[i], tx = cr.x + Crucible.REST[i][0] * cr.spread, ty = cr.y + Crucible.REST[i][1] * cr.spread; f.x = lerp(f.x, tx, 0.1); f.y = lerp(f.y, ty, 0.1); }
    if (Math.floor(k * 60) % 3 === 0) { w.parts.add({ k: 'spark', x: cr.x + c.rng.range(-26, 26), y: cr.y - 40 + c.rng.range(-20, 10), z: 2, vx: 0, vy: -30, vz: 30, grav: 80, max: 0.4, c1: P.w }); }
    if (Math.floor(k * 60) % 8 === 0) w.shock(cr.x, cr.y - 30, 70, 0.4, 1.2);
    yield F;
  }
  w.hitstop = 0.2; cr.shake = 4; yield 0.25;
  const X = cr.x, Y = cr.y; cr.dead = true; cr.tank = false; cr.push = false;
  w.screenFlash(P.w, 0.7, 0.3); w.shake(10, 0.8); w.shock(X, Y - 20, 150, 0.7, 5);
  w.add(new Flash(X, Y - 36, 60, P.w, 0.5, 20));
  ringAt(c, X, Y, 125, 0.45, 120, { kind: 'burst', knock: 220, stag: 0.6, h: shock1, cols: [P.w, P.c2, P.e2], w: 6, dust: true, fill: true });
  chips(w, X, Y - 30, 50, 200, P.i0, P.i2, P.w, { z: 24, up: 220, size: [3, 8] }); shards(w, X, Y - 30, 24, 170, P.v2, P.v1, P.y2, { z: 24, up: 200, land: 2, size: [4, 8] });
  drops(w, X, Y - 30, 70, 190, P.c1, P.c3, P.c0, { z: 24, up: 220, glow: 2, size: [2, 5], max: 3 });
  w.run((function* () {
    yield 0.28; w.shake(7, 0.5); w.shock(X, Y, 190, 0.7, 4);
    ringAt(c, X, Y, 165, 0.6, 85, { kind: 'acid', knock: 160, stag: 0.4, h: sheets, max: 2, cols: [P.c3, P.c1, P.e2], w: 10, fill: true, ease: 1.6 });
    w.add(new Pool(X, Y, 44, MAT.acid, 8, { blobs: 9, boil: 3, grow: 0.5 }));
    yield 0.3; w.shake(6, 0.4); w.shock(X, Y, 210, 0.7, 3.5);
    ringAt(c, X, Y, 185, 0.65, 85, { kind: 'acid', knock: 160, stag: 0.4, h: sheets, max: 2, cols: [P.y1, P.v2, P.v0], w: 9, fill: true, ease: 1.6 });
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * TAU + 0.3, d = 50 + c.rng.range(0, 40), lx = X + Math.cos(a) * d, ly = Y + Math.sin(a) * d * 0.8;
      w.add(new Shot(lx, ly, 120, 0, 0, -20, 260, 0, (g, x, y) => { ball(g.s, x, y, 6, PAL.cer, 5); L1(g.s, x, y); }, null, (ww, s) => {
        ringAt(c, s.x, s.y, 24, 0.22, 35, { kind: 'impact', knock: 140, stag: 0.4, h: chunks, max: 2, cols: [P.w, P.i1, P.i3], w: 3, dust: true }); ww.shake(4, 0.25); ww.shock(s.x, s.y, 32, 0.25, 2); chips(ww, s.x, s.y, 12, 100, P.i0, P.i2, P.w, { z: 4, size: [2, 5] }); dust(ww, s.x, s.y, 5, 28, 5); ww.add(new Decal(s.x, s.y, 'crater', 9, 8, i + c.id, { a: P.k0, b: P.i2, c: P.c1 }, 0, 1)); ww.add(new Embed(s.x, s.y, 5, P.i0, P.i3, P.w, 9));
      }, 4, 0));
      yield 0.05;
    }
    const big = new Cloud(X, Y, mkPuffs(c.rng, 18, 54, 14, 24, 8, 1.4), VAP.green, 5, c.id + 77); big.grow = { from: 0.3, to: 1.9, dur: 1.5 }; big.dens = 12; big.tickInfo = { every: 0.7, amt: c.d(22), opts: { kind: 'acid', src: c.def.id }, h: fvap, max: 4, mark: 'miasma' }; w.add(big);
    for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU; plume(w, X + Math.cos(a) * 36, Y + Math.sin(a) * 26, 44 + (i % 3) * 8, 1.8, i % 2 ? VAP.pale : VAP.green, 13, i, i * 0.05); }
    w.add(new Decal(X, Y, 'crater', 50, 12, c.id + 3, { a: P.k0, b: P.i2, c: P.c1 }, 0, 1.2)); w.add(new Decal(X, Y, 'veins', 90, 11, c.id + 4, { a: P.e0, b: P.e3, c: P.c2 }, 0, 1.5));
    for (let i = 0; i < 12; i++) w.add(new Embed(X + c.rng.range(-70, 70), Y + c.rng.range(-50, 50), c.rng.range(3, 6), P.v2, P.v0, P.y2, 10));
  })());
  yield 3.0;
}
function L1(L: import('../pixel').Layer, x: number, y: number) { L.line(x - 3, y - 1, x + 2, y + 2, P.n3); L.px(Math.round(x - 2), Math.round(y - 3), P.w); }
function bubbleBig(g: Gfx, x: number, y: number, r: number) {
  const L = g.s; L.dl = 6; L.disc(x, y, r - 1, P.c1); L.dl = 9; L.disc(x + 1, y + 1, r * 0.6, P.e3); L.dl = 16; L.ring(x, y, r, 1, P.c3);
  L.px(Math.round(x - r * 0.5), Math.round(y - r * 0.55), P.w); L.px(Math.round(x - r * 0.5) + 1, Math.round(y - r * 0.55), P.w); L.px(Math.round(x + r * 0.5), Math.round(y + r * 0.45), P.c2);
}

export const defs2: Pick<SkillDef, 'id' | 'run'>[] = [
  { id: 6, run: caravan }, { id: 7, run: hatchery }, { id: 8, run: serpents }, { id: 9, run: harvester }, { id: 10, run: crucible },
];
void steam; void dust; void lerp; void hxn;
