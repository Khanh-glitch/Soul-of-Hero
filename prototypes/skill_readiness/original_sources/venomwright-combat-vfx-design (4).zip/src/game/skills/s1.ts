import { Chain, Custom, Decal, Embed, Flash, Fx, Hits, Cloud, Pool, Ring, Shot, Splash, chips, drops, dust, shards, steam, type Gfx } from '../fx';
import { P, TAU, angDiff, ball, clamp, glow, hash, lerp, mix, pal, shard, smooth, wormBody, type Seg } from '../pixel';
import { MAT, PAL, VAP } from '../mats';
import type { Enemy, World } from '../world';
import { F, castAnim, drawFlask, handPos, hitE, mkPuffs, ringAt, throwArc, ticks, visRing, LIQ, type Cast, type SkillDef } from './lib';

const MEMB = pal(P.e0, P.e1, P.e2, P.c0, P.c2);
const MEMB_MAT = { ...MAT.acid, dl: 12, rim: P.c0, ramp: [P.e0, P.e1, P.e2, P.e3, P.c0], vw: 4 };
const alive = (e: Enemy | null | undefined): e is Enemy => !!e && e.dying <= 0;

// =============== 01 GLASSFANG HUNT ===============
const FR = [4.6, 4.0, 4.4, 4.1, 3.6, 3.0, 2.2, 1.4];
class Fang extends Fx {
  ch: Chain; z = 0; heading: number; open = 0.2; scale = 1;
  constructor(x: number, y: number, ang: number) { super(); this.x = x; this.y = y; this.heading = ang; this.ch = new Chain(x, y, 8, 4.2, ang); this.kind = 'summon'; this.sy = y; }
  upd() { this.ch.move(this.x, this.y); this.sy = this.y; }
  shd(g: Gfx) { const L = g.s; L.dl = 8; for (let i = 0; i < 8; i += 2) { const q = this.ch.s[i]; L.ellipse(q.x, q.y + 2, FR[i] * 0.9, FR[i] * 0.45, P.bk); } L.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, s = this.ch.s, n = s.length;
    const pts: Seg[] = s.map((q, i) => ({ x: q.x, y: q.y - this.z - 3 + Math.sin(t * 14 - i * 0.9) * 0.5, r: FR[i] * this.scale }));
    for (let i = 1; i <= 4; i++) {
      const a = Math.atan2(s[i - 1].y - s[i].y, s[i - 1].x - s[i].x), px = -Math.sin(a), py = Math.cos(a);
      for (const sd of [-1, 1]) {
        const sw = Math.sin(t * 20 + i * 1.5 + sd * 1.6) * 2.2, bx = pts[i].x + px * FR[i] * sd, by = pts[i].y + py * FR[i] * sd + 1;
        const kx = bx + px * 3 * sd + Math.cos(a) * sw * 0.5, ky = by + py * 3 * sd * 0.8 - 1, fx = bx + px * 4.5 * sd + Math.cos(a) * sw, fy = by + 3 + py * 2 * sd;
        L.line(bx, by, kx, ky, P.v1); L.line(kx, ky, fx, fy, P.v3);
      }
    }
    wormBody(L, pts.slice().reverse(), PAL.glass, {});
    for (let i = 0; i < n; i++) if (i === 2 || i === 4) { L.disc(pts[i].x + 0.5, pts[i].y + 0.5, 1.3, P.e0); L.px(Math.round(pts[i].x), Math.round(pts[i].y), P.k0); }
    const pi = Math.floor((t * 11) % (n + 2));
    for (let k = 0; k < 3; k++) { const i = pi - k; if (i >= 0 && i < n) L.disc(pts[i].x, pts[i].y, 1.6 - k * 0.5, k === 0 ? P.c3 : k === 1 ? P.c1 : P.c0); }
    for (let i = 1; i < 6; i++) shard(L, pts[i].x, pts[i].y - FR[i] + 0.5, -Math.PI / 2 + Math.sin(i + t * 3) * 0.2, 2.8, 0.9, P.y2, P.v2, P.w);
    const h = pts[0], a = this.heading, fx = Math.cos(a), fy = Math.sin(a), qx = -fy, qy = fx, op = this.open * 0.55 + 0.2;
    for (const sd of [-1, 1]) shard(L, h.x + fx * 3 + qx * sd * 1.2, h.y + fy * 3 + qy * sd * 1.2, a + sd * op, 5.4, 1.4, P.y2, P.v1, P.w);
    L.px(Math.round(h.x + fx + qx * 1.6), Math.round(h.y + fy + qy * 1.6 - 1), P.c2); L.px(Math.round(h.x + fx - qx * 1.6), Math.round(h.y + fy - qy * 1.6 - 1), P.c2);
  }
  lit(g: Gfx) { const h = this.ch.s[0]; glow(g.l, h.x, h.y - this.z - 3, 8, P.c1, 0.3, 3); glow(g.l, this.ch.s[3].x, this.ch.s[3].y - this.z - 3, 6, P.c1, 0.15, 2); }
}
function* glassfang(c: Cast) {
  const w = c.w; castAnim(w, c);
  yield 0.05;
  let tgt: Enemy | null = c.target ?? w.nearest(c.tx, c.ty, 110);
  const [hx, hy] = handPos(w);
  const tx = tgt ? tgt.x : c.tx, ty = tgt ? tgt.y : c.ty, ang = Math.atan2(ty - hy, tx - hx);
  const cx = lerp(hx, tx, 0.55), cy = lerp(hy, ty, 0.55);
  throwArc(w, 'vial', hx, hy, cx, cy, 0.08, 4, () => 0, 22);
  yield 0.08;
  w.add(new Flash(cx, cy, 9, P.c2, 0.2, 8));
  shards(w, cx, cy, 9, 80, P.v2, P.v1, P.y2, { z: 8, size: [2, 4], land: 3 });
  drops(w, cx, cy, 8, 60, P.c1, P.c3, P.e2, { z: 8, glow: 2 });
  const fang = w.add(new Fang(cx, cy, ang)); fang.z = 8; fang.open = 1;
  const poolHits = new Hits();
  const trail = (x: number, y: number) => { w.add(new Splash(x, y, 4, P.c1, P.c3)); w.add(new Pool(x, y, 4, MAT.acid, 0.9, { blobs: 2, grow: 0.1, resid: false })); shards(w, x, y, 3, 40, P.v2, P.v1, P.y2, { z: 3, size: [2, 3], land: 1 }); };
  const bite = (e: Enemy, pct: number, final = false) => {
    const a = Math.atan2(e.y - fang.y, e.x - fang.x), px = e.x - Math.cos(a) * e.r, py = e.y - Math.sin(a) * e.r;
    hitE(c, e, pct, { kind: 'bite', k: final ? 160 : 80, ang: a, stag: 0.3, at: [px, py], big: final });
    shards(w, px, py, 7, 80, P.y1, P.v1, P.y2, { z: 6, size: [2, 5], ang: a, spread: 2.8, land: 3 });
    visRing(w, px, py, 10, 0.2, [P.w, P.y1, P.v1], 2); w.add(new Flash(px, py, 6, P.y2, 0.14, 6)); w.shake(final ? 3 : 1.5, 0.14);
    if (!final) w.mark(e, 'crystal', 0.45, 0.4);
  };
  const leap = function* (gx: number, gy: number, dur: number, arcH: number) {
    const x0 = fang.x, y0 = fang.y, z0 = fang.z; trail(x0, y0);
    let i = 0;
    for (const k of ticks(dur)) {
      fang.x = lerp(x0, gx, k); fang.y = lerp(y0, gy, k); fang.z = lerp(z0, 0, k) + 4 * arcH * k * (1 - k);
      fang.heading = Math.atan2(gy - y0, gx - x0); fang.open = k > 0.55 ? 1 : 0.4;
      if (i++ % 3 === 0) shards(w, fang.x, fang.y, 1, 20, P.v2, P.v1, P.y2, { z: fang.z, size: [2, 3], land: 1 });
      yield F;
    }
    fang.z = 0; trail(gx, gy);
  };
  // first leap lands on the target (~0.25s after cast)
  const contact = (e: Enemy, off = 0) => { const a = Math.atan2(fang.y - e.y, fang.x - e.x); return [e.x + Math.cos(a + off) * (e.r + 3), e.y + Math.sin(a + off) * (e.r + 3)]; };
  if (tgt) { const [gx, gy] = contact(tgt); yield* leap(gx, gy, 0.1, 10); }
  for (let i = 0; i < 4; i++) {
    if (!alive(tgt)) { tgt = w.nearest(fang.x, fang.y, 150); if (tgt) { const [gx, gy] = contact(tgt); yield* leap(gx, gy, 0.16, 12); } }
    if (!tgt) break;
    fang.open = 1; bite(tgt, 30);
    const a = Math.atan2(tgt.y - fang.y, tgt.x - fang.x);
    for (const k of ticks(0.12)) { fang.x -= Math.cos(a) * 70 * F * (1 - k); fang.y -= Math.sin(a) * 70 * F * (1 - k); fang.z = 6 * Math.sin(k * Math.PI); fang.open = 0.2; yield F; }
    if (!alive(tgt)) continue;
    // circle round the target to a new angle, then lunge
    const t0 = Math.atan2(fang.y - tgt.y, fang.x - tgt.x), t1 = t0 + c.rng.sign() * c.rng.range(1.8, 2.4), rr = tgt.r + 13;
    for (const k of ticks(0.26)) {
      const th = lerp(t0, t1, smooth(k)), rad = lerp(Math.hypot(fang.x - tgt.x, fang.y - tgt.y), rr, 0.3);
      fang.x = tgt.x + Math.cos(th) * rad; fang.y = tgt.y + Math.sin(th) * rad; fang.heading = th + Math.PI + c.rng.range(-0.1, 0.1) * 0; fang.open = 0.3; fang.z = 0;
      if (Math.floor(k * 12) % 4 === 0) w.parts.add({ k: 'spark', x: fang.x, y: fang.y, z: 2, vx: 0, vy: 0, vz: 10, max: 0.2, c1: P.c2 });
      yield F;
    }
    const [gx, gy] = contact(tgt, 0); yield* leap(gx, gy, 0.17, 13);
  }
  // final strike: the glass body fractures into plates, the luminous core erupts across the target
  const fin = alive(tgt) ? tgt : null;
  if (fin) bite(fin, 55, true);
  const fx0 = fang.x, fy0 = fang.y;
  shards(w, fx0, fy0, 11, 105, P.v2, P.v1, P.y2, { z: 6, size: [5, 9], up: 110, land: 2 });
  shards(w, fx0, fy0, 6, 70, P.y1, P.v0, P.w, { z: 8, size: [3, 5], up: 90, land: 2 });
  drops(w, fx0, fy0, 28, 110, P.c2, P.c3, P.c1, { z: 8, up: 120, glow: 2, size: [1, 4], max: 1.6 });
  w.add(new Flash(fx0, fy0, 22, P.c3, 0.3, 8)); visRing(w, fx0, fy0, 34, 0.35, [P.w, P.c2, P.c0], 3); w.screenFlash(P.c3, 0.25, 0.12); w.shock(fx0, fy0, 40, 0.3, 2);
  fang.dead = true;
  if (fin) {
    w.mark(fin, 'corrode', 2.2, 1);
    w.add(new Custom(fin.x, fin.y, 0.7, {
      up: (g, a) => { const e = fin, L = g.s; if (!e) return; const x = e.x, y = e.y - e.r - 2, k = 1 - a; L.dl = Math.round(14 * k + 2); L.disc(x, y, 6 * k + 2, P.c1); L.dl = Math.round(10 * k + 2); L.disc(x - 1, y - 1, 4 * k + 1, P.c3); L.dl = 16; for (let i = 0; i < 5; i++) L.px(Math.round(x - 4 + i * 2), Math.round(y + 4 + a * (6 + i * 3)), P.c2); },
      lit: (g, a) => glow(g.l, fin.x, fin.y - 6, 14 * (1 - a) + 4, P.c2, 0.5 * (1 - a), 4),
    }, fin.y + 1));
  }
  for (let i = 0; i < 3; i++) {
    const a = c.rng.range(0, TAU), d = c.rng.range(8, 22), px = (fin?.x ?? fx0) + Math.cos(a) * d, py = (fin?.y ?? fy0) + Math.sin(a) * d * 0.8;
    w.add(new Pool(px, py, 6.5, MAT.acid, 4.2, { boil: 2, tick: { every: 0.7, amt: c.d(10), opts: { kind: 'acid', src: c.def.id }, h: poolHits, max: 3 }, blobs: 3 }));
    w.add(new Embed(px + 1, py - 1, 4 + i, P.v2, P.v0, P.y2, 6));
  }
  yield 0.6;
}

// =============== 02 BLOOMING PARASITE ===============
class Growth extends Fx {
  g = 0; open = 0; hm = 1; ign = 0; lean: number; ph: number; bx0: number; by0: number; start: number; mw = 1;
  constructor(public bx: number, public by: number, public H: number, ph: number, start: number) { super(); this.bx0 = bx; this.by0 = by; this.x = bx; this.y = by; this.sy = by; this.ph = ph; this.lean = (hash(ph * 100) - 0.5) * 8; this.start = start; this.kind = 'summon'; }
  upd() { this.x = this.bx; this.y = this.by; this.sy = this.by; }
  gnd(g: Gfx) { const L = g.s, gr = smooth(this.g); if (gr < 0.05) return; L.disc(this.bx, this.by + 1, 4 * gr + 1, P.k0); L.ring(this.bx, this.by + 1, 4 * gr + 1, 1, P.e2); L.dl = 8; L.ring(this.bx, this.by + 1, 6 * gr + 2, 1, P.c0); L.dl = 16; }
  top() { const gr = smooth(this.g) * this.hm; return { x: this.bx + this.lean * gr, y: this.by - this.H * gr }; }
  up(g: Gfx) {
    const L = g.s, t = g.t, gr = smooth(this.g) * this.hm; if (gr < 0.03) return;
    const N = 8, H = this.H * gr, pts: Seg[] = [];
    for (let i = 0; i <= N; i++) { const u = i / N, sway = Math.sin(t * 1.5 + this.ph + u * 3) * 2.2 * u; pts.push({ x: this.bx + sway + this.lean * u * gr, y: this.by - H * u, r: lerp(3, 1.6, u) * (0.6 + 0.4 * gr) }); }
    ball(L, this.bx, this.by, 4 * gr + 1, MEMB, 3 * gr + 1);
    wormBody(L, pts.slice().reverse(), MEMB, { stripe: P.c2, stripeT: t, spec: false });
    for (let i = 1; i < N; i += 2) { const pu = this.ign > 0 && this.ign * 8 > i ? 1 : 0; L.disc(pts[i].x + 1, pts[i].y, 0.9, pu ? P.w : P.c1); if (Math.sin(t * 4 + i + this.ph) > 0.5 || pu) L.px(Math.round(pts[i].x + 1), Math.round(pts[i].y), P.c3); }
    for (const s of [-1, 1]) { const cx0 = this.bx + s * 4, cy0 = this.by - 1; L.arc(cx0, cy0 - 2, 3, 1, s > 0 ? -1.5 : 1.7, s > 0 ? 1.6 : 4.8, P.e3); L.px(Math.round(cx0 + s * 3), Math.round(cy0 - 2), P.c2); }
    const tp = pts[N], o = this.open * gr, len = (3.4 + 5.5 * o) * (0.5 + 0.5 * gr);
    const order = [0, 1, 2, 3, 4, 5, 6].map(k => ({ k, a: (k / 7) * TAU + this.ph + t * 0.25 })).sort((a, b) => Math.sin(a.a) - Math.sin(b.a));
    for (const { a } of order) {
      const back = Math.sin(a) < 0, ex = Math.cos(a) * len, ey = Math.sin(a) * len * 0.55 - o * 1.6 - (back ? 1 : 0);
      L.dl = 14; shard(L, tp.x + ex * 0.15, tp.y + ey * 0.15 - 1, Math.atan2(ey, ex), len, 1.7 + o * 1.4, back ? P.e3 : P.c0, back ? P.e2 : P.e3, P.c2); L.dl = 16;
    }
    L.ellipse(tp.x, tp.y - 1, 2 + o * 2, 1 + o * 1.4, P.k0);
    L.px(Math.round(tp.x), Math.round(tp.y - 1), Math.sin(t * 6 + this.ph) > 0 ? P.c3 : P.c1);
    if (o > 0.6) for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU; L.px(Math.round(tp.x + Math.cos(a) * (2 + o * 2)), Math.round(tp.y - 1 + Math.sin(a) * (1 + o * 1.4)), P.i0); }
  }
  lit(g: Gfx) { const tp = this.top(); glow(g.l, tp.x, tp.y - 1, 6 + this.open * 4, P.c1, 0.2 + this.ign * 0.5, 3); if (this.ign > 0.1) glow(g.l, tp.x, tp.y + 2, 10, P.c3, this.ign * 0.4, 3); }
}
function* parasite(c: Cast) {
  const w = c.w; castAnim(w, c);
  yield 0.05;
  const [hx, hy] = handPos(w), cx = c.tx, cy = c.ty, R = 62;
  throwArc(w, 'seed', hx, hy, cx, cy, 0.33, 28, () => 0, 9);
  yield 0.33;
  const seedHits = new Hits(), touch = new Hits(), erupt = new Hits(), pulse = new Hits(), inf = new Hits();
  w.add(new Ring(cx, cy, 16, 0.2, { w: 2, cols: [P.c3, P.c1, P.e2], hit: { h: seedHits, amt: c.d(15), opts: { kind: 'impact', src: c.def.id }, knock: 70, stagger: 0.25 } }));
  w.add(new Flash(cx, cy, 10, P.c2, 0.25)); dust(w, cx, cy, 6, 18, 3); w.shake(1.5, 0.15);
  // seed halves split, pale shell with glowing cells
  w.add(new Custom(cx, cy, 0.7, { up: (g, a) => { const L = g.s, k = smooth(a * 1.6); for (const s of [-1, 1]) { ball(L, cx + s * (1 + k * 5), cy - 2 - Math.sin(k * 3) * 2, 2.6 - k * 0.6, PAL.seed, 3.2); } L.dl = Math.round(16 * (1 - a)); L.disc(cx, cy - 3, 2 + k * 5, P.c1); L.disc(cx, cy - 3, 1 + k * 3, P.c3); L.dl = 16; }, lit: (g, a) => glow(g.l, cx, cy - 3, 14, P.c2, 0.5 * (1 - a), 4) }, cy + 3));
  const growths: Growth[] = [];
  const spots: [number, number, number][] = [[0, 0, 40]];
  for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU + 0.4, d = 26 + hash(i * 3 + c.id) * 26; spots.push([Math.cos(a) * d, Math.sin(a) * d * 0.85, 26 + hash(i) * 8]); }
  spots.forEach(([dx, dy, h], i) => { const gr = new Growth(clamp(cx + dx, 10, w.W - 10), clamp(cy + dy, 14, w.H - 10), h, i * 1.7 + 0.5, 0.05 + i * 0.16); growths.push(gr); w.add(gr); });
  // translucent mycelial membrane connecting the colony
  const mem = w.add(new Custom(cx, cy, 8, { gnd: (g) => {
    const f = g.f; f.reset(); const k = smooth(g.t - startT > 0 ? (g.t - startT) / 1.2 : 0);
    f.disc(cx, cy, 15 * k, 0.2);
    for (const gr of growths) { f.capsule(cx, cy, gr.bx, gr.by + 1, 2.4 * k, 3 * k); f.disc(gr.bx, gr.by + 1, (7 + 2 * Math.sin(g.t * 2 + gr.ph)) * smooth(gr.g) * gr.mw, 0.2); }
    f.shade(g.s, MEMB_MAT, g.t, { seed: 3 });
  } }));
  const startT = w.time; void mem;
  w.add(new Decal(cx, cy, 'veins', 46, 7.2, c.id, { a: P.e0, b: P.e3, c: P.c2 }, 0, 0.8));
  const sporeFn = (cxx: number, cyy: number) => (p: { x: number; y: number; vx: number; vy: number; vz: number; z: number; seed: number }, _w: World, dt: number) => {
    const dx = p.x - cxx, dy = p.y - cyy, d = Math.hypot(dx, dy) || 1, sw = 24 + (p.seed % 7) * 2;
    p.vx += ((-dy / d) * sw - p.vx) * dt * 2.2 + ((R * 0.7 - d) / R) * (dx / d) * 20 * dt; p.vy += ((dx / d) * sw * 0.8 - p.vy) * dt * 2.2 + ((R * 0.7 - d) / R) * (dy / d) * 14 * dt;
    p.vz += ((8 + (p.seed % 5) * 2 - p.z) * 3 - p.vz) * dt;
  };
  const nextE = growths.map((_, i) => 1.1 + i * 0.4), lash = growths.map(() => 0);
  const lashFx = (gr: Growth, e: Enemy) => {
    w.add(new Custom(gr.bx, gr.by, 0.34, { up: (g, a) => {
      const L = g.s, tp = gr.top(), ex = e.x, ey = e.y - e.r, k = Math.min(1, a * 3), pts: Seg[] = [];
      for (let i = 0; i <= 8; i++) { const u = i / 8 * k, wob = Math.sin(u * 9 + g.t * 25) * (1 - a) * 3 * Math.sin(u * Math.PI); pts.push({ x: lerp(tp.x, ex, u) - (ey - tp.y) * 0.0 + wob * 0.3, y: lerp(tp.y, ey, u) + wob, r: lerp(1.8, 1, i / 8) }); }
      wormBody(L, pts, MEMB, { spec: false }); L.disc(pts[8].x, pts[8].y, 1.8, P.c1); L.px(Math.round(pts[8].x), Math.round(pts[8].y), P.c3);
    } }, e.y + 2));
  };
  let tm = 0;
  const T_PULSE = 5.4;
  for (; tm < T_PULSE; tm += F) {
    growths.forEach((gr, i) => {
      gr.g = clamp((tm - gr.start) / 0.7, 0, 1);
      gr.open = gr.g > 0.6 ? 0.5 + 0.5 * Math.sin(tm * 2.4 + gr.ph) : gr.g * 0.5;
      if (gr.g > 0.8 && Math.floor(tm * 60) % 6 === i % 6 && gr.open > 0.6) { const tp = gr.top(); for (let k = 0; k < 2; k++) w.parts.add({ k: 'spore', x: tp.x + c.rng.range(-2, 2), y: tp.y + 3, z: 4, vx: c.rng.range(-8, 8), vy: c.rng.range(-4, 4), vz: 10, max: c.rng.range(1.6, 2.6), c1: P.c1, c2: P.e3, size: k, glow: 2, fn: sporeFn(cx, cy) as never }); }
      lash[i] -= F;
      if (gr.g > 0.85 && lash[i] <= 0) {
        let best: Enemy | null = null, bd = 40;
        for (const e of w.enemies) { if (e.dying > 0) continue; const d = Math.hypot(e.x - gr.bx, e.y - gr.by) - e.r; if (d < bd && touch.n(e) < 3) { bd = d; best = e; } }
        if (best) { lash[i] = 0.8; if (touch.ok(best, w.time, 0.4, 3)) { hitE(c, best, 15, { kind: 'pierce', k: 40, from: [gr.bx, gr.by], stag: 0.22, at: [best.x, best.y - best.r] }); lashFx(gr, best); w.mark(best, 'infect', 4.2, 1); if (inf.ok(best, w.time)) w.poison(best, c.d(55), 3.5, c.id, c.def.id); } }
      }
      if (gr.g > 0.9 && tm >= nextE[i]) {
        nextE[i] += 2.2;
        ringAt(c, gr.bx, gr.by, 17, 0.22, 25, { kind: 'impact', knock: 90, stag: 0.3, h: erupt, max: 2, cols: [P.c3, P.c1, P.e2], w: 2 });
        drops(w, gr.bx, gr.by, 9, 60, P.c1, P.c3, P.e2, { z: 4, up: 90, glow: 2 }); steam(w, gr.bx, gr.by, 3, 14, P.e2, P.c0, 4); w.shake(1, 0.1);
      }
    });
    yield F;
  }
  // contraction: cells ignite in sequence
  for (const k of ticks(0.75)) {
    growths.forEach((gr, i) => { gr.hm = lerp(1, 0.45, smooth(k)); gr.bx = lerp(gr.bx0, cx, smooth(k) * 0.55); gr.by = lerp(gr.by0, cy, smooth(k) * 0.55); gr.ign = clamp(k * 1.8 - i * 0.13, 0, 1); gr.open = lerp(gr.open, 0, 0.1); gr.mw = 1 - smooth(k) * 0.2; });
    if (Math.floor(k * 60) % 5 === 0) w.parts.add({ k: 'spark', x: cx + c.rng.range(-20, 20), y: cy + c.rng.range(-10, 10), z: c.rng.range(2, 20), vx: 0, vy: 0, vz: 0, max: 0.2, c1: P.c3 });
    yield F;
  }
  // pulse + rupture
  w.add(new Flash(cx, cy, 36, P.c3, 0.4, 8)); w.screenFlash(P.c2, 0.4, 0.18); w.shake(5, 0.4); w.shock(cx, cy, R + 24, 0.5, 3);
  ringAt(c, cx, cy, R + 14, 0.38, 100, { kind: 'burst', knock: 150, stag: 0.4, h: pulse, cols: [P.w, P.c1, P.e2], w: 4, dust: true });
  visRing(w, cx, cy, R * 0.6, 0.3, [P.c3, P.c0, P.e2], 3);
  for (const gr of growths) {
    const tp = gr.top(); gr.dead = true;
    for (let i = 0; i < 9; i++) { const a = c.rng.range(0, TAU), sp = c.rng.range(30, 100); w.parts.add({ k: 'petal', x: tp.x, y: tp.y, z: 14, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.7, vz: c.rng.range(30, 110), grav: 70, drag: 1.1, size: c.rng.range(2, 4), rot: c.rng.range(0, TAU), vr: c.rng.range(-8, 8), c1: i % 3 === 0 ? P.g2 : P.c0, c2: P.c3, max: 1.9, fn: ((p: { z: number; vz: number; vx: number; vy: number }) => { if (p.z < 0) { p.z = 0; p.vz = 0; p.vx *= 0.9; p.vy *= 0.9; } }) as never }); }
    chips(w, tp.x, tp.y, 5, 90, P.e2, P.e0, P.c1, { z: 10, up: 100, size: [2, 4] });
    chips(w, gr.bx, gr.by, 2, 60, P.i1, P.i3, P.i0, { z: 4 });
    drops(w, gr.bx, gr.by, 8, 70, P.c1, P.c3, P.e2, { z: 6, glow: 2, up: 100 });
  }
  // structured toxic cloud: three spiral arms
  for (let arm = 0; arm < 3; arm++) for (let i = 0; i < 30; i++) {
    const a0 = (arm / 3) * TAU, d0 = i * 0.045;
    w.parts.add({ k: 'spore', x: cx, y: cy, z: 6, max: 1.9 + d0, c1: i % 4 === 0 ? P.c3 : P.c1, c2: P.e3, size: i % 6 === 0 ? 2 : 1, glow: 2, seed: i, fn: ((p: { x: number; y: number; z: number; age: number }) => { const a = p.age; const r = 6 + a * 58 + i * 0.7, an = a0 + a * 2.1 + i * 0.1 - d0; p.x = cx + Math.cos(an) * r; p.y = cy + Math.sin(an) * r * 0.85; p.z = 5 + Math.sin(a * 5 + i) * 3 + a * 6; }) as never });
  }
  const cl = new Cloud(cx, cy, mkPuffs(c.rng, 9, 24, 10, 17, 6, 1.4), VAP.pale, 2.4, c.id); cl.grow = { from: 0.4, to: 1.6, dur: 1.2 }; cl.dens = 9; w.add(cl);
  yield 1.2;
}

// =============== 03 LEECHWATER RUSH ===============
function* leechwater(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c, true, 0.4);
  const ox = p.x, oy = p.y, dirx = Math.cos(c.ang), diry = Math.sin(c.ang), R = 150, half = 0.62;
  yield 0.03;
  w.glide([{ x: ox + dirx * 66, y: oy + diry * 66 }], 0.42);
  const lanes = 5, laneAng: number[] = [];
  for (let i = 0; i < lanes; i++) laneAng.push(c.ang + (i / (lanes - 1) - 0.5) * 2 * half * 0.85);
  const start = w.time, front = () => Math.min(R, (w.time - start) * 440 + 14);
  const laneAt = (i: number, s: number, t: number) => { const a = laneAng[i] + Math.sin(s * 0.045 + i * 1.7 + t * 1.2) * 0.1; return { x: ox + Math.cos(a) * s + dirx * 6, y: oy + Math.sin(a) * s * 0.96 + diry * 6, a }; };
  const orgs: { l: number; k: number; ph: number; rs: number; rn: number; sp: number }[] = [];
  for (let i = 0; i < 260; i++) orgs.push({ l: i % lanes, k: Math.floor(i / lanes) % 7, ph: hash(i * 3 + c.id) * TAU, rs: 2 + hash(i) * 7, rn: 1 + hash(i * 5) * 3.2, sp: 4 + hash(i * 7) * 5 });
  let mass: { x: number; y: number; mode: number; k: number } | null = null;
  const contact = new Hits(), drain = new Hits(), burst = new Hits();
  const attached = new Map<number, number>();
  const sw = w.add(new Custom(ox, oy, 6.5, {
    gnd: (g, _a, f) => {
      const L = g.s, fr = front(), t = g.t - start, fld = g.f;
      fld.reset();
      for (let i = 0; i < lanes; i++) { let prev = laneAt(i, 4, t); for (let s = 10; s <= fr; s += 8) { const q = laneAt(i, s, t), wd = (4.2 + 2.6 * Math.sin(s * 0.06 + i)) * clamp((fr - s) / 12 + 0.5, 0.4, 1) * (mass ? Math.max(0, 1 - mass.k) : 1); fld.capsule(prev.x, prev.y, q.x, q.y, wd, wd); prev = q; } }
      fld.disc(ox + dirx * 8, oy + diry * 8, 6 * (mass ? 1 - mass.k : 1), 0.2);
      fld.shade(L, MAT.leech, g.t, { fx: 14, fy: 3, seed: 5 });
      const fade = f.age > 5.6 ? clamp((6.5 - f.age) / 0.9, 0, 1) : 1;
      for (const o of orgs) {
        if (mass && mass.mode > 0) continue;
        const s0 = (o.k / 7) * R + ((t * 40 + o.k * 31) % (R * 0.9)) * 0.5, sc = (s0 + Math.sin(t * 2 + o.k) * 5) % R, ang = o.ph + t * o.sp * 0.5;
        const s = clamp(sc + Math.cos(ang) * o.rs, 4, fr), q = laneAt(o.l, s, t), nx = -Math.sin(q.a), ny = Math.cos(q.a);
        if (s > fr - 1) continue;
        const X = Math.round(q.x + nx * Math.sin(ang) * o.rn), Y = Math.round(q.y + ny * Math.sin(ang) * o.rn);
        if (hash(Math.floor(o.ph * 100) + f.age * 0) > fade) continue;
        const bright = Math.sin(t * 7 + o.ph * 3) > 0.45;
        L.px(X, Y, bright ? P.w : o.k % 3 === 0 ? P.y2 : P.y1);
        if (o.k % 2 === 0) { L.dl = 9; L.px(Math.round(X - Math.cos(q.a)), Math.round(Y - Math.sin(q.a)), P.y0); L.dl = 16; }
      }
    },
    lit: (g) => { const fr = front(); for (let i = 0; i < lanes; i++) for (let s = 14; s < fr; s += 22) { const q = laneAt(i, s, g.t - start); glow(g.l, q.x, q.y, 6, P.y0, 0.1, 2); } },
  }));
  void sw;
  const lifeStream = (e: Enemy) => {
    for (let i = 0; i < 4; i++) {
      const sx = e.x + c.rng.range(-3, 3), sy = e.y - e.r * 0.8, off = c.rng.range(-26, 26), delay = i * 0.04;
      w.parts.add({ k: 'mote', x: sx, y: sy, z: 0, max: 0.65 + delay, c1: i % 2 ? P.m2 : P.c2, c2: P.m1, glow: 2, fn: ((q: { x: number; y: number; age: number; max: number }) => { const u = clamp((q.age - delay) / 0.6, 0, 1); const px = lerp(sx, p.x, u) + Math.sin(u * Math.PI) * off * 0.6, py = lerp(sy, p.y - 6, u) - Math.sin(u * Math.PI) * 14 + Math.sin(u * Math.PI) * off * 0.2; q.x = px; q.y = py; if (u >= 1) q.age = q.max; }) as never });
    }
  };
  let regroup = false; const mcx = ox + dirx * 98, mcy = oy + diry * 98;
  const leechOn = (e: Enemy) => {
    // organisms transform into leech forms that crawl up and attach
    for (let i = 0; i < 4; i++) {
      const a = i * 1.7 + hash(e.id) * 6, sx = e.x + Math.cos(a) * 18, sy = e.y + Math.sin(a) * 12;
      w.add(new Custom(sx, sy, 0.38, { up: (g, a2) => { const L = g.s, u = smooth(a2), X = lerp(sx, e.x + Math.cos(i * 2.4 + 1) * e.r * 0.85, u), Y = lerp(sy, e.y - e.r * 0.8 + Math.sin(i * 2.4 + 1) * 4, u) - Math.sin(u * Math.PI) * 5; wormBody(L, [{ x: X, y: Y, r: 1.5 }, { x: X - Math.cos(a) * 2, y: Y - Math.sin(a) * 1.5 + Math.sin(g.t * 30) * 0.8, r: 1.4 }, { x: X - Math.cos(a) * 4, y: Y - Math.sin(a) * 3, r: 1 }], PAL.leech, { spec: false }); L.px(Math.round(X), Math.round(Y), P.m2); } }, e.y + 2));
    }
  };
  let tm = 0;
  for (; tm < 2.9; tm += F) {
    const fr = front();
    for (const e of w.enemies) {
      if (e.dying > 0 || attached.has(e.id)) continue;
      const dx = e.x - ox, dy = e.y - oy, d = Math.hypot(dx, dy);
      if (d - e.r > fr) continue;
      let da = Math.abs(angDiff(c.ang, Math.atan2(dy, dx)));
      da = Math.max(0, da - Math.asin(Math.min(1, e.r / Math.max(d, e.r + 1))));
      if (d > e.r + 4 && da > half) continue;
      if (contact.ok(e, w.time)) {
        hitE(c, e, 50, { kind: 'bite', k: 60, from: [ox, oy], stag: 0.25 });
        attached.set(e.id, w.time); w.mark(e, 'leech', 3.0, 4); w.mark(e, 'infect', 3.0, 1); leechOn(e);
        drops(w, e.x, e.y, 5, 40, P.y1, P.y2, P.n3, { z: 4, glow: 1 });
      }
    }
    for (const e of w.enemies) {
      const t0 = attached.get(e.id);
      if (t0 === undefined || e.dying > 0) continue;
      const k = Math.floor((w.time - t0 - 0.35) / 0.4);
      if (k >= 0 && k < 6 && drain.ok(e, w.time, 0.38, 6)) { hitE(c, e, 15, { kind: 'bite', heal: 0.15, stag: 0.05, at: [e.x, e.y - e.r] }); lifeStream(e); w.mark(e, 'leech', 1.0, 4); }
    }
    if (tm > 2.45 && !regroup) {
      regroup = true; mass = { x: mcx, y: mcy, mode: 0, k: 0 };
      w.add(new Pool(mcx, mcy, 16, MAT.leech, 1.7, { grow: 0.5, blobs: 4, resid: false }));
      for (const e of w.enemies) if (e.st.leech) { const sx = e.x, sy = e.y - e.r; delete e.st.leech; delete e.st.infect;
        for (let i = 0; i < 3; i++) w.add(new Custom(sx, sy, 0.55, { up: (g, a) => { const L = g.s, u = smooth(a), X = lerp(sx, mcx, u) + Math.sin(u * 6 + i) * 4, Y = lerp(sy, mcy - 8, u) - Math.sin(u * Math.PI) * 16; wormBody(L, [{ x: X, y: Y, r: 1.4 }, { x: X - 2, y: Y + 1, r: 1.3 }, { x: X - 4, y: Y + 1.5, r: 1 }], PAL.leech, { spec: false }); L.px(Math.round(X), Math.round(Y), P.m2); } }, sy)); }
    }
    if (mass) mass.k = clamp((tm - 2.45) / 0.9, 0, 1.4);
    yield F;
  }
  // regrouped twisting mass → violent collapse
  if (mass) {
    const m = mass;
    w.add(new Custom(mcx, mcy, 0.85, { up: (g, a) => {
      const L = g.s, t = g.t, pts: Seg[] = [];
      for (let i = 0; i < 26; i++) { const u = i / 25, an = u * TAU * 2.6 + t * 9, rad = (3 + 9 * Math.sin(u * Math.PI)) * (1 - a * 0.3); pts.push({ x: mcx + Math.cos(an) * rad, y: mcy - 4 - u * 26 + Math.sin(an) * rad * 0.4, r: 2.2 + Math.sin(u * Math.PI) * 2 }); }
      wormBody(L, pts, PAL.leech, { stripe: P.y1, stripeT: t });
      for (let i = 0; i < 24; i++) { const an = i * 0.9 + t * 6, rd = 8 + (i % 5) * 2.2; L.px(Math.round(mcx + Math.cos(an) * rd), Math.round(mcy - 6 - (i * 1.2) % 24 + Math.sin(an) * rd * 0.4), i % 3 ? P.y1 : P.w); }
    }, lit: (g, a) => glow(g.l, mcx, mcy - 14, 14 + a * 6, P.y0, 0.3, 4) }, mcy + 4));
    void m;
  }
  yield 0.85;
  w.screenFlash(P.y2, 0.45, 0.2); w.shake(5, 0.35); w.shock(mcx, mcy, 70, 0.4, 3);
  ringAt(c, mcx, mcy, 62, 0.34, 55, { kind: 'burst', knock: 150, stag: 0.4, h: burst, cols: [P.y2, P.y0, P.n2], w: 4 });
  w.add(new Flash(mcx, mcy, 30, P.y2, 0.35, 10)); w.add(new Pool(mcx, mcy, 26, MAT.leech, 3.4, { blobs: 6, boil: 1.5, grow: 0.25 }));
  drops(w, mcx, mcy, 36, 130, P.n3, P.y1, P.k1, { z: 8, up: 130, size: [2, 4] });
  shards(w, mcx, mcy, 14, 120, P.m1, P.n1, P.m2, { z: 10, up: 120, size: [3, 6], land: 1 });
  for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU; w.add(new Splash(mcx + Math.cos(a) * 30, mcy + Math.sin(a) * 26, 6, P.y1, P.y2)); }
  w.add(new Decal(mcx, mcy, 'pits', 30, 3.5, c.id, { a: P.k0, b: P.n3, c: P.y1 }, 0, 1));
  for (const e of w.enemies) { delete e.st.leech; delete e.st.infect; }
  yield 0.6;
}

// =============== 04 PORCELAIN BASTION ===============
class Bastion extends Fx {
  z = 0; face = 0; fr = 0; swell = 0; asm = 0; leg: { x: number; y: number; fx: number; fy: number; st: number; lift: number }[] = [];
  slam = -1; slamLeg = 0; spawnK = 0; shake = 0; plateOff = 0;
  constructor(x: number, y: number, public maxLife: number) {
    super(); this.x = x; this.y = y; this.r = 17; this.push = true; this.tank = true; this.hp = this.maxHp = 760; this.kind = 'summon'; this.sy = y;
    for (let i = 0; i < 4; i++) { const sx = i % 2 ? 1 : -1, sy = i < 2 ? -1 : 1; this.leg.push({ x: x + sx * 22, y: y + sy * 14, fx: sx * 22, fy: sy * 14, st: 1, lift: 0 }); }
  }
  upd() { this.sy = this.y; }
  legPos(i: number): [number, number] { const l = this.leg[i], ca = Math.cos(this.face), sa = Math.sin(this.face); return [this.x + l.fx * ca - l.fy * sa, this.y + l.fx * sa + l.fy * ca]; }
  shd(g: Gfx) { const L = g.s; L.dl = 9; L.ellipse(this.x + 3, this.y + 7, 27 * this.asm, 12 * this.asm, P.bk); L.dl = 16; }
  gnd(g: Gfx) { if (this.asm < 1) return; const L = g.s; L.dl = 6; L.ellipse(this.x, this.y + 4, 24, 10, P.k0); L.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, asm = this.asm; if (asm <= 0) return;
    const sh = this.shake > 0 ? Math.sin(t * 90) * this.shake : 0;
    const bx = this.x + sh, by = this.y - 12 - this.z + (1 - asm) * 16, fr = this.fr;
    const hurt = this.hf > 0;
    for (let i = 0; i < 4; i++) {
      const l = this.leg[i], [tx, ty] = this.legPos(i), ca = Math.cos(this.face), sa = Math.sin(this.face);
      const sx = i % 2 ? 1 : -1, hx = bx + (sx * 11) * ca - ((i < 2 ? -1 : 1) * 7) * sa, hy = by + 4 + ((i < 2 ? -1 : 1) * 7) * ca * 0.5;
      const fyy = ty - (l.lift > 0 ? Math.sin(l.lift * Math.PI) * (i === this.slamLeg && this.slam >= 0 ? 16 : 9) : 0), fxx = tx;
      const kx = (hx + fxx) / 2 + sx * 5, ky = Math.min(hy, fyy) - 6;
      L.line(hx, hy, kx, ky, P.k0, 5); L.line(kx, ky, fxx, fyy, P.k0, 5); L.line(hx, hy, kx, ky, P.i1, 3); L.line(kx, ky, fxx, fyy, P.i2, 3);
      L.line(hx - 1, hy - 1, kx - 1, ky - 1, P.i0); ball(L, kx, ky, 2.4, PAL.copper); ball(L, fxx, fyy, 3, PAL.cer, 2);
      L.px(Math.round(fxx - 1), Math.round(fyy - 1), P.w);
    }
    // body: layered ceramic plates around a transparent reservoir
    const spread = fr * 3 + this.plateOff;
    ball(L, bx, by + 2, 16, hurt ? { ...PAL.cer, b: P.w } : PAL.cer, 10);
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * TAU + 0.3, px = bx + Math.cos(a) * (10 + spread), py = by + 1 + Math.sin(a) * (6 + spread * 0.6);
      L.poly([bx + Math.cos(a - 0.35) * 5, by + Math.sin(a - 0.35) * 3, px + Math.cos(a - 0.3) * 4, py + Math.sin(a - 0.3) * 3, px + Math.cos(a + 0.3) * 4, py + Math.sin(a + 0.3) * 3, bx + Math.cos(a + 0.35) * 5, by + Math.sin(a + 0.35) * 3], i % 2 ? P.i0 : P.i1);
      L.line(bx + Math.cos(a) * 5, by + Math.sin(a) * 3, px, py, i % 2 ? P.n3 : P.u1, 1);
    }
    for (let i = 0; i < 7; i++) { const a = (i / 7) * TAU + 0.3; const vx = bx + Math.cos(a) * 12, vy = by + 1 + Math.sin(a) * 7; const pu = (Math.sin(t * 5 - i) + 1) / 2; L.line(bx + Math.cos(a) * 6, by + Math.sin(a) * 3.5, vx, vy, mix(P.e3, P.c2, pu)); }
    const rr = 7 + this.swell * 4;
    drawFlask(L, bx, by - 3, rr, 0.8, Math.sin(t * 3) * 0.25, LIQ.acid, t * (1 + fr * 2), PAL.glassHi);
    L.ring(bx, by - 3, rr + 1, 1, P.u1);
    for (let i = 0; i < Math.floor(fr * 9); i++) { // bright fracture lines
      let x = bx + (hash(i * 7) - 0.5) * 8, y = by - 3 + (hash(i * 11) - 0.5) * 5, a = hash(i * 3 + 1) * TAU;
      for (let s = 0; s < 6 + fr * 8; s++) { a += (hash(s + i * 20) - 0.5) * 0.9; x += Math.cos(a); y += Math.sin(a) * 0.7; L.px(Math.round(x), Math.round(y), Math.sin(t * 9 - s) > 0 ? P.w : P.g2); L.px(Math.round(x) + 1, Math.round(y), P.c1); }
    }
    ball(L, bx - 13, by - 4, 3.4, PAL.cerB, 3); ball(L, bx + 13, by - 4, 3.4, PAL.cerB, 3);
  }
  lit(g: Gfx) { const by = this.y - 12 - this.z; glow(g.l, this.x, by - 3, 16 + this.fr * 10, P.c1, 0.2 + this.fr * 0.35, 4); }
}
function* bastion(c: Cast) {
  const w = c.w; castAnim(w, c);
  const cx = c.tx, cy = c.ty;
  const b = new Bastion(cx, cy, 10); b.asm = 0.001;
  // telegraph: ground cracks, plates rising from beneath
  w.add(new Decal(cx, cy, 'cracks', 34, 9, c.id, { a: P.k0, b: P.i3, c: P.c1 }, 0, 1));
  w.add(b);
  const emerge = new Hits(), slams = new Hits(), rup = new Hits(), pool = new Hits();
  let k0 = 0;
  for (const k of ticks(0.5)) {
    b.asm = smooth(k); b.z = (1 - smooth(k)) * 10; b.plateOff = (1 - k) * 6; b.shake = (1 - k) * 1.5; k0 = k;
    if (Math.floor(k * 60) % 4 === 0) { dust(w, cx + c.rng.range(-18, 18), cy + 6, 1, 10, 3); w.parts.add({ k: 'chip', x: cx + c.rng.range(-16, 16), y: cy + c.rng.range(-4, 8), z: 0, vx: 0, vy: 0, vz: 60, grav: 240, size: 2, c1: P.i0, c2: P.i2, c3: P.w, land: 3, max: 1.2, rot: 0, vr: 5 }); }
    yield F;
  }
  void k0;
  b.z = 0; b.plateOff = 0; b.shake = 0;
  ringAt(c, cx, cy, 44, 0.3, 40, { kind: 'impact', knock: 150, stag: 0.4, h: emerge, cols: [P.w, P.i1, P.i3], w: 3, dust: true });
  w.shake(4, 0.3); w.shock(cx, cy, 50, 0.3, 2.5); chips(w, cx, cy, 14, 100, P.i0, P.i2, P.w, { z: 6, up: 110, size: [2, 4] }); dust(w, cx, cy, 8, 30, 5);
  let slamCd = 0.3, nextStep = 0;
  const maxLife = 10;
  let tm = 0;
  for (; tm < maxLife && b.hp > 0; tm += F) {
    b.fr = Math.max(1 - b.hp / b.maxHp, tm / maxLife * 0.9); b.swell = b.fr * b.fr;
    // target the nearest enemy and walk toward it
    const tgt = w.nearest(b.x, b.y, 170);
    if (tgt && b.slam < 0) {
      const dx = tgt.x - b.x, dy = tgt.y - b.y, d = Math.hypot(dx, dy);
      let da = Math.atan2(dy, dx) - b.face; da = ((da + Math.PI) % TAU + TAU) % TAU - Math.PI; b.face += da * 0.1;
      if (d > b.r + tgt.r + 14) { b.x += Math.cos(b.face) * 26 * F; b.y += Math.sin(b.face) * 26 * F; b.z = Math.abs(Math.sin(tm * 6)) * 0.8; }
      b.x = clamp(b.x, 26, w.W - 26); b.y = clamp(b.y, 24, w.H - 22);
      slamCd -= F;
      if (slamCd <= 0 && d < b.r + tgt.r + 30) {
        let bi = 0, bd = 1e9; for (let i = 0; i < 4; i++) { const [lx, ly] = b.legPos(i); const dd = Math.hypot(lx - tgt.x, ly - tgt.y); if (dd < bd) { bd = dd; bi = i; } }
        b.slamLeg = bi; b.slam = 0;
      }
    }
    for (let i = 0; i < 4; i++) { // gait: planted feet re-step when the body walks away
      const l = b.leg[i], [lx, ly] = b.legPos(i), cur = b.leg[i];
      if (l.lift > 0) { l.lift = Math.min(1, l.lift + F * 5); if (l.lift >= 1) { l.lift = 0; if (b.slam < 0 || i !== b.slamLeg) { visRingSmall(w, lx, ly); } } }
      void cur;
    }
    if (b.slam >= 0) {
      b.slam += F; const l = b.leg[b.slamLeg]; l.lift = clamp(b.slam / 0.3, 0, 0.5);
      if (b.slam > 0.3) {
        const [lx, ly] = b.legPos(b.slamLeg); l.lift = 0; b.slam = -1; slamCd = 0.85;
        ringAt(c, lx, ly, 30, 0.24, 35, { kind: 'impact', knock: 130, stag: 0.35, h: slams, max: 4, cols: [P.w, P.i1, P.n3], w: 3, dust: true });
        w.shake(3, 0.2); w.shock(lx, ly, 38, 0.25, 2); chips(w, lx, ly, 9, 90, P.i0, P.i2, P.w, { z: 4, up: 100, size: [2, 4] }); dust(w, lx, ly, 4, 25, 4);
        w.add(new Decal(lx, ly, 'cracks', 12, 4, tm * 100 + c.id, { a: P.k0, b: P.i3, c: P.c1 }, 0, 1));
      }
    } else if (tm > nextStep) { nextStep = tm + 0.55; const i = Math.floor(tm * 2) % 4; const l = b.leg[i]; if (l.lift <= 0) l.lift = 0.01; }
    yield F;
  }
  // pressure builds: fractures spread, reservoir swells, plates bend
  for (const k of ticks(0.75)) {
    b.fr = 1; b.swell = 0.4 + k * 1.1; b.plateOff = k * 4; b.shake = 0.6 + k * 1.6; b.asm = 1;
    if (Math.floor(k * 60) % 4 === 0) { w.parts.add({ k: 'spark', x: b.x + c.rng.range(-14, 14), y: b.y - 12 + c.rng.range(-8, 8), z: 4, vx: c.rng.range(-30, 30), vy: -10, vz: 30, grav: 100, max: 0.4, c1: P.g2 }); drops(w, b.x + c.rng.range(-10, 10), b.y - 8, 1, 30, P.c1, P.c3, P.e2, { z: 14, up: 40, glow: 1 }); }
    yield F;
  }
  const bx = b.x, by = b.y; b.dead = true; b.tank = false; b.push = false;
  w.screenFlash(P.c3, 0.5, 0.2); w.shake(8, 0.55); w.shock(bx, by - 8, 100, 0.55, 4); w.hitstop = 0.06;
  ringAt(c, bx, by, 72, 0.4, 120, { kind: 'burst', knock: 190, stag: 0.5, h: rup, cols: [P.w, P.c2, P.e2], w: 5, dust: true });
  w.add(new Flash(bx, by - 10, 36, P.c3, 0.4, 8));
  chips(w, bx, by - 8, 36, 170, P.i0, P.i2, P.w, { z: 14, up: 190, size: [3, 7] }); chips(w, bx, by - 8, 14, 120, PAL.cerB.b, P.n0, P.w, { z: 10, up: 150, size: [3, 5] });
  shards(w, bx, by - 8, 12, 140, P.v2, P.v1, P.y2, { z: 12, up: 160, size: [3, 6], land: 2 });
  drops(w, bx, by - 8, 44, 150, P.c1, P.c3, P.c0, { z: 12, up: 180, glow: 2, size: [2, 4], max: 2.4 });
  w.add(new Decal(bx, by, 'crater', 24, 9, c.id, { a: P.k0, b: P.i2, c: P.c1 }, 0, 1.4));
  w.add(new Pool(bx, by, 26, MAT.acid, 6, { blobs: 6, boil: 1.8, tick: { every: 0.8, amt: c.d(20), opts: { kind: 'acid', src: c.def.id }, h: pool, max: 3 } }));
  for (let i = 0; i < 5; i++) { const a = c.rng.range(0, TAU), d = c.rng.range(18, 40); w.add(new Splash(bx + Math.cos(a) * d, by + Math.sin(a) * d * 0.8, 5, P.c1, P.c3)); w.add(new Embed(bx + Math.cos(a) * d, by + Math.sin(a) * d * 0.8, 3 + i % 3, P.i0, P.i3, P.w, 7)); }
  yield 1.2;
}
function visRingSmall(w: World, x: number, y: number) { dust(w, x, y, 2, 14, 3); w.parts.add({ k: 'spark', x, y, z: 1, vx: 0, vy: 0, vz: 10, max: 0.15, c1: P.i0 }); }

// =============== 05 BELLOWS TOAD ===============
class Toad extends Fx {
  z = 0; f: number; sq = 0; inf = 0; vis = 0;
  constructor(x: number, y: number, f: number) { super(); this.x = x; this.y = y; this.f = f; this.kind = 'summon'; this.sy = y; }
  upd() { this.sy = this.y; }
  mouth(): [number, number] { return [this.x + Math.cos(this.f) * 9, this.y - this.z - 4 + Math.sin(this.f) * 4]; }
  shd(g: Gfx) { g.s.dl = 8; g.s.ellipse(this.x, this.y + 3, 10 * (1 + this.inf * 0.15), 5, P.bk); g.s.dl = 16; }
  up(g: Gfx) {
    const L = g.s, t = g.t, fx = Math.cos(this.f), fy = Math.sin(this.f), qx = -fy, base = this.y - this.z;
    const sx = 1 + this.sq * 0.28 + this.inf * 0.18, sy = 1 - this.sq * 0.38 - this.inf * 0.08;
    L.dl = Math.round(this.vis * 16); if (L.dl < 1) return;
    for (const s of [-1, 1]) { ball(L, this.x - fx * 5 + qx * 8 * s, base - 1 - fy * 2, 3.6, PAL.toad, 2.4); ball(L, this.x + fx * 5 + qx * 6 * s, base - 1 + fy * 2, 2.4, PAL.toad, 1.8); L.rect(Math.round(this.x + qx * 10 * s - fx * 6), Math.round(base + 1), 3, 1, P.k0); }
    ball(L, this.x, base - 6 * sy, 9 * sx, PAL.toad, 6.5 * sy);
    L.dl = Math.round(this.vis * 8); L.disc(this.x, base - 6 * sy, 4.5 * sx, P.c1); L.dl = Math.round(this.vis * 16);
    for (let i = 0; i < 2; i++) L.arc(this.x - fx * 2, base - 7 * sy, 4 + i * 2.2, 1, Math.atan2(-fy, -fx) - 1.1, Math.atan2(-fy, -fx) + 1.1, P.k0, 3 + i * 1.6);
    for (let i = 0; i < 6; i++) { const a = hash(i * 3) * TAU, d = 2 + hash(i * 7) * 5; L.disc(this.x + Math.cos(a) * d * sx, base - 7 * sy + Math.sin(a) * d * 0.6, 0.9, P.e0); }
    for (const s of [-1, 1]) { const ex = this.x + fx * 3 + qx * 4.2 * s, ey = base - 11 * sy + fy * 1.5; ball(L, ex, ey, 2.4, PAL.toad); L.disc(ex + fx * 0.8, ey + fy * 0.6, 1.1, P.g2); L.px(Math.round(ex + fx * 0.8), Math.round(ey + fy * 0.6), P.k0); }
    if (this.inf > 0.02) {
      const [mx, my] = this.mouth(), r = 3 + this.inf * 8.5, sx2 = this.x + fx * (7 + this.inf * 6.5), sy2 = base - 3 + fy * (4 + this.inf * 4);
      void mx; void my;
      ball(L, sx2, sy2, r, PAL.toadSac, r * 0.85);
      for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU + 0.4; L.line(sx2, sy2, sx2 + Math.cos(a) * (r - 1), sy2 + Math.sin(a) * (r * 0.85 - 1), i % 2 ? P.c2 : P.e3); }
      const bx = sx2 + Math.sin(t * 7) * r * 0.35, by = sy2 + Math.cos(t * 5) * r * 0.3;
      L.dl = 9; L.disc(bx, by, r * 0.4, P.c1); L.dl = 6; L.disc(bx - 1, by - 1, r * 0.22, P.c3); L.dl = Math.round(this.vis * 16);
      L.px(Math.round(sx2 - r * 0.5), Math.round(sy2 - r * 0.5), P.w); L.px(Math.round(sx2 - r * 0.5 + 1), Math.round(sy2 - r * 0.5), P.w);
    }
    L.dl = 16;
  }
  lit(g: Gfx) { if (this.inf > 0.1) { const fx = Math.cos(this.f), r = 3 + this.inf * 8.5; glow(g.l, this.x + fx * (7 + this.inf * 6.5), this.y - this.z - 3, r * 1.3, P.c1, 0.3 * this.inf, 3); } }
}
function* toad(c: Cast) {
  const w = c.w, p = w.player; castAnim(w, c);
  yield 0.06;
  const sd = c.ang + Math.PI / 2, sxp = clamp(p.x + Math.cos(sd) * 22, 14, w.W - 14), syp = clamp(p.y + Math.sin(sd) * 22, 16, w.H - 14);
  const puddle = new Hits(), vap = new Hits(), glob = new Hits(), fin = new Hits();
  w.add(new Pool(sxp, syp, 14, MAT.acid, 5, { grow: 0.3, blobs: 5, boil: 1.4 }));
  ringAt(c, sxp, syp, 38, 0.24, 15, { kind: 'acid', knock: 70, stag: 0.2, h: puddle, cols: [P.c3, P.c1, P.e2], w: 2 });
  const toad = new Toad(sxp, syp, c.ang); w.add(toad);
  for (const k of ticks(0.12)) { toad.vis = k; toad.z = (1 - k) * -6 + Math.sin(k * Math.PI) * 6; yield F; }
  toad.vis = 1; toad.z = 0; drops(w, sxp, syp, 10, 50, P.c1, P.c3, P.e2, { z: 4, up: 90, glow: 1 });
  // hop toward the target
  const tx = c.tx, ty = c.ty, face = Math.atan2(ty - syp, tx - sxp), hop = Math.min(46, Math.hypot(tx - sxp, ty - syp) * 0.5 + 10);
  toad.f = face;
  const x0 = toad.x, y0 = toad.y;
  for (const k of ticks(0.16)) { toad.x = x0 + Math.cos(face) * hop * k; toad.y = y0 + Math.sin(face) * hop * k; toad.z = Math.sin(k * Math.PI) * 14; toad.sq = k < 0.15 ? -0.3 : 0; yield F; }
  toad.z = 0; toad.sq = 0.5; w.add(new Splash(toad.x, toad.y, 6, P.c1, P.c3)); dust(w, toad.x, toad.y, 3, 14, 3); w.shake(1, 0.1);
  // compress and inhale: debris is drawn toward the open mouth
  for (const k of ticks(0.3)) {
    toad.sq = 0.5 + k * 0.4; toad.inf = smooth(k) * 1.0;
    const [mx, my] = toad.mouth();
    for (let i = 0; i < 2; i++) {
      const a = c.rng.range(-1.1, 1.1) + face, d = c.rng.range(26, 52), sx = mx + Math.cos(a) * d, sy = my + 4 + Math.sin(a) * d * 0.7, kind = c.rng.int(3);
      w.parts.add({ k: kind === 0 ? 'chip' : kind === 1 ? 'drop' : 'dust', x: sx, y: sy, z: 1, vx: 0, vy: 0, vz: 0, size: kind === 2 ? 2 : kind === 1 ? 2 : 2, max: 0.4, c1: kind === 0 ? P.i2 : kind === 1 ? P.c1 : P.i3, c2: kind === 0 ? P.i3 : P.c3, c3: P.w, rot: 0, vr: 6,
        fn: ((q: { x: number; y: number; z: number; age: number; max: number }) => { const u = Math.pow(q.age / q.max, 1.7), sw = Math.sin(u * 3) * 6; q.x = lerp(sx, mx, u) - Math.sin(face) * sw; q.y = lerp(sy, my, u) + Math.cos(face) * sw; q.z = lerp(1, 5, u); }) as never });
    }
    yield F;
  }
  // violent forward blast: rolling vapour layers + heavy globules
  const [mx, my] = toad.mouth();
  w.shake(3, 0.25); w.shock(mx, my, 40, 0.3, 2); w.add(new Flash(mx, my, 12, P.c3, 0.2, 4));
  const cos = Math.cos(face), sin = Math.sin(face);
  const layers: [typeof VAP.green, number, number, number][] = [[VAP.dark, 26, 14, 0], [VAP.green, 21, 11, 1], [VAP.pale, 14, 8, 2]];
  for (const [ramp, , rad, lay] of layers) {
    const pf = Array.from({ length: 11 }, (_, i) => ({ x: (i % 4) * 7 - 3, y: (c.rng.next() - 0.5) * 12, r: rad * c.rng.range(0.7, 1.1), ph: c.rng.range(0, TAU), sp: c.rng.range(0.8, 2.2) * c.rng.sign(), orb: c.rng.range(2, 5), lay }));
    const cl = new Cloud(mx, my + 2, pf, ramp, 2.3, c.id + lay); cl.vx = cos * (130 - lay * 10); cl.vy = sin * (130 - lay * 10); cl.grow = { from: 0.5, to: 2.0, dur: 1.3 }; cl.dens = 12 - lay;
    if (lay === 0) cl.tickInfo = { every: 0.36, amt: c.d(18), opts: { kind: 'acid', src: c.def.id, stagger: 0.12 }, h: vap, max: 3, mark: 'miasma' };
    w.add(cl);
    const fn = (cl2: Cloud) => { const dec = () => { cl2.vx *= 0.975; cl2.vy *= 0.975; }; return dec; };
    w.run((function* () { const d = fn(cl); for (let i = 0; i < 140; i++) { d(); yield F; } })());
  }
  for (let i = 0; i < 6; i++) {
    const a = face + (i - 2.5) * 0.14 + c.rng.range(-0.03, 0.03), sp = 150 + c.rng.range(-20, 30);
    w.add(new Shot(mx, my, 6, Math.cos(a) * sp, Math.sin(a) * sp, 18, 90, 5,
      (g, x, y, _z, s) => { const L = g.s; ball(L, x, y, 3.2, PAL.liquid); L.px(Math.round(x - 1), Math.round(y - 1), P.w); L.dl = 8; L.px(Math.round(x - s.vx * 0.05), Math.round(y - s.vy * 0.05), P.e3); L.px(Math.round(x - s.vx * 0.09), Math.round(y - s.vy * 0.09), P.e2); L.dl = 16; },
      (ww, s, e) => { if (!glob.ok(e, ww.time, 0, 2)) return false; hitE(c, e, 30, { kind: 'acid', k: 60, ang: Math.atan2(s.vy, s.vx), stag: 0.25, at: [s.x, s.y] }); ww.poison(e, c.d(36), 3, c.id, c.def.id); ww.mark(e, 'wet', 2);
        ww.add(new Pool(e.x, e.y, 9, MAT.acid, 2, { blobs: 4, seed: i * 7, boil: 1 })); drops(ww, e.x, e.y, 9, 70, P.c1, P.c3, P.e2, { z: 6, up: 80, glow: 1 }); ww.add(new Splash(e.x, e.y, 7, P.c1, P.c3)); return true; },
      (ww, s) => { ww.add(new Pool(s.x, s.y, 7, MAT.acid, 1.8, { blobs: 3, seed: i, boil: 1 })); drops(ww, s.x, s.y, 5, 50, P.c1, P.c3, P.e2, { z: 2, up: 60 }); }, 1.4, 14));
  }
  for (const k of ticks(0.28)) { toad.inf = lerp(1, 0.1, k); toad.sq = lerp(0.9, 0.1, k); yield F; }
  yield 0.3;
  // last exaggerated inflation, then burst
  for (const k of ticks(0.8)) { toad.inf = lerp(0.1, 1.9, smooth(k)); toad.sq = -0.35 * k; toad.x += Math.sin(k * 60) * 0.25; if (Math.floor(k * 60) % 6 === 0) steam(w, toad.x, toad.y, 1, 10, P.e2, P.c0, 3, { z: 8 }); yield F; }
  const ex = toad.x, ey = toad.y; toad.dead = true;
  w.screenFlash(P.c2, 0.3, 0.14); w.shake(6, 0.4); w.shock(ex, ey, 80, 0.45, 3.5);
  ringAt(c, ex, ey, 62, 0.36, 90, { kind: 'burst', knock: 160, stag: 0.4, h: fin, cols: [P.c3, P.c1, P.e1], w: 5, dust: false, fill: false });
  visRing(w, ex, ey, 44, 0.3, [P.w, P.c2, P.e2], 3);
  w.add(new Flash(ex, ey - 6, 28, P.c3, 0.35, 8));
  drops(w, ex, ey, 40, 130, P.c1, P.c3, P.e2, { z: 8, up: 130, glow: 2, size: [2, 4] });
  for (let i = 0; i < 20; i++) { const a = c.rng.range(0, TAU), sp = c.rng.range(40, 120); w.parts.add({ k: 'petal', x: ex, y: ey, z: 10, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.8, vz: c.rng.range(30, 100), grav: 80, drag: 1.2, size: c.rng.range(2, 4), rot: c.rng.range(0, TAU), vr: c.rng.range(-9, 9), c1: i % 2 ? PAL.toadSac.b : P.e2, c2: P.c3, max: 1.8, fn: ((q: { z: number; vz: number; vx: number; vy: number }) => { if (q.z < 0) { q.z = 0; q.vz = 0; q.vx *= 0.9; q.vy *= 0.9; } }) as never }); }
  w.add(new Pool(ex, ey, 18, MAT.acid, 3.2, { blobs: 6, boil: 1.4 })); w.add(new Decal(ex, ey, 'pits', 20, 3.5, c.id, { a: P.k0, b: P.e3, c: P.c1 }, 0, 1));
  yield 0.5;
}

export const defs1: Pick<SkillDef, 'id' | 'run'>[] = [
  { id: 1, run: glassfang }, { id: 2, run: parasite }, { id: 3, run: leechwater }, { id: 4, run: bastion }, { id: 5, run: toad },
];
void smooth; void mix; void Embed; void hash;
