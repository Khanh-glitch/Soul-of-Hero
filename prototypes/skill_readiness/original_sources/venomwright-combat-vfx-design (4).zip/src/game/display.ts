import { Application, Filter, GlProgram, Sprite, Texture, UniformGroup } from 'pixi.js';
import { Layer } from './pixel';

export class Frame {
  cv: HTMLCanvasElement; ctx: CanvasRenderingContext2D; img: ImageData; d: Uint32Array; L: Layer;
  constructor(public W: number, public H: number, public k: number = 1) {
    this.cv = document.createElement('canvas'); this.cv.width = W; this.cv.height = H;
    this.ctx = this.cv.getContext('2d', { willReadFrequently: false })!;
    this.img = this.ctx.createImageData(W, H);
    this.d = new Uint32Array(this.img.data.buffer);
    this.L = new Layer(this.d, W, H, k);
  }
  upload() { this.ctx.putImageData(this.img, 0, 0); }
}

const VERT = `
in vec2 aPosition;
out vec2 vTextureCoord;
uniform vec4 uInputSize;
uniform vec4 uOutputFrame;
uniform vec4 uOutputTexture;
vec4 filterVertexPosition( void ){
  vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;
  position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;
  position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;
  return vec4(position, 0.0, 1.0);
}
vec2 filterTextureCoord( void ){ return aPosition * (uOutputFrame.zw * uInputSize.zw); }
void main(void){ gl_Position = filterVertexPosition(); vTextureCoord = filterTextureCoord(); }
`;

const FRAG = `
in vec2 vTextureCoord;
out vec4 finalColor;
uniform sampler2D uTexture;
uniform sampler2D uGlow;
uniform vec2 uRes;
uniform float uTime;
uniform vec2 uShake;
uniform vec4 uShock[4];
uniform vec4 uFlash;
uniform vec4 uGrade; // x: dim, y: vignette, z: desat, w: glow gain
float bayer4(vec2 p) {
  float x = mod(p.x, 4.0), y = mod(p.y, 4.0);
  float a = mod(x, 2.0), b = mod(floor(x / 2.0), 2.0), c = mod(y, 2.0), d = mod(floor(y / 2.0), 2.0);
  return (8.0 * abs(a - c) + 4.0 * c + 2.0 * abs(b - d) + d) / 16.0;
}
void main(void){
  vec2 px = floor(vTextureCoord * uRes);
  vec2 p = px + 0.5;
  vec2 off = vec2(0.0);
  for (int i = 0; i < 4; i++) {
    vec4 s = uShock[i];
    if (s.w > 0.0) {
      vec2 d = p - s.xy; float r = length(d);
      float band = exp(-pow((r - s.z) / 9.0, 2.0));
      if (r > 0.5) off += d / r * band * s.w;
    }
  }
  p = floor(p + off + uShake) + 0.5;
  p = clamp(p, vec2(0.5), uRes - 0.5);
  vec2 uv = p / uRes;
  vec3 sc = texture(uTexture, uv).rgb;
  vec3 g = texture(uGlow, uv).rgb;
  vec2 o2 = vec2(2.0) / uRes, o5 = vec2(5.0, -5.0) / uRes;
  vec3 h = (texture(uGlow, uv + vec2(o2.x, 0.)).rgb + texture(uGlow, uv - vec2(o2.x, 0.)).rgb + texture(uGlow, uv + vec2(0., o2.y)).rgb + texture(uGlow, uv - vec2(0., o2.y)).rgb) * 0.25;
  vec3 h2 = (texture(uGlow, uv + o5.xx).rgb + texture(uGlow, uv - o5.xx).rgb + texture(uGlow, uv + o5.xy).rgb + texture(uGlow, uv + o5.yx).rgb) * 0.25;
  vec3 col = sc + (g + h * 0.5 + h2 * 0.4) * uGrade.w;
  float l = dot(col, vec3(0.3, 0.55, 0.15));
  col = mix(col, vec3(l), uGrade.z);
  // stepped vignette
  vec2 q = (px / uRes - 0.5) * vec2(1.0, 0.9);
  float vg = smoothstep(0.38, 0.78, length(q)) * uGrade.y;
  float bt = bayer4(px);
  col *= 1.0 - 0.55 * step(bt + 0.001, vg) - 0.2 * step(bt + 0.001, vg * 0.55);
  col *= 1.0 - uGrade.x;
  if (uFlash.a > 0.0) col = mix(col, uFlash.rgb, step(bt, uFlash.a) * min(1.0, uFlash.a * 1.4));
  // gentle 5-bit quantisation keeps the palette crunchy
  col = floor(clamp(col, 0.0, 1.0) * 31.0 + 0.5) / 31.0;
  finalColor = vec4(col, 1.0);
}
`;

export class Display {
  app!: Application;
  scene!: Frame; glowF!: Frame;
  uni!: UniformGroup;
  sceneTex!: Texture; glowTex!: Texture;
  W = 0; H = 0; scale = 3; k = 1;
  host!: HTMLElement;
  sprite!: Sprite;

  async init(host: HTMLElement, W: number, H: number, scale: number, k = 1) {
    this.host = host; this.W = W; this.H = H; this.scale = scale; this.k = k;
    this.app = new Application();
    await this.app.init({ width: W, height: H, antialias: false, resolution: 1, autoDensity: false, backgroundColor: 0x000000, preference: 'webgl', autoStart: false });
    host.appendChild(this.app.canvas);
    this.build(W, H, scale, k);
  }

  private build(W: number, H: number, scale: number, k = 1) {
    this.scene = new Frame(W, H, k); this.glowF = new Frame(W, H, k);
    this.sceneTex = Texture.from(this.scene.cv); this.glowTex = Texture.from(this.glowF.cv);
    this.sceneTex.source.scaleMode = 'nearest'; this.glowTex.source.scaleMode = 'nearest';
    this.uni = new UniformGroup({
      uRes: { value: new Float32Array([W, H]), type: 'vec2<f32>' },
      uTime: { value: 0, type: 'f32' },
      uShake: { value: new Float32Array([0, 0]), type: 'vec2<f32>' },
      uShock: { value: new Float32Array(16), type: 'vec4<f32>', size: 4 },
      uFlash: { value: new Float32Array([0, 0, 0, 0]), type: 'vec4<f32>' },
      uGrade: { value: new Float32Array([0, 1, 0, 1]), type: 'vec4<f32>' },
    });
    const filter = new Filter({
      glProgram: GlProgram.from({ vertex: VERT, fragment: FRAG, name: 'venomwright-composite' }),
      resources: { uGlow: this.glowTex.source, uGlowSampler: this.glowTex.source.style, vfx: this.uni },
    });
    this.app.stage.removeChildren();
    this.sprite = new Sprite(this.sceneTex);
    this.sprite.filters = [filter];
    this.app.stage.addChild(this.sprite);
    this.fit(scale);
  }

  fit(scale: number) {
    this.scale = scale;
    const c = this.app.canvas;
    c.style.width = '100%';
    c.style.height = '100%';
    c.style.objectFit = 'fill';
    c.style.imageRendering = 'pixelated';
    c.style.display = 'block';
  }

  resize(W: number, H: number, scale: number, k = 1) {
    if (W === this.W && H === this.H && k === this.k) { this.fit(scale); return; }
    this.W = W; this.H = H; this.k = k;
    this.app.renderer.resize(W, H);
    this.sceneTex.destroy(true); this.glowTex.destroy(true);
    this.build(W, H, scale, k);
  }

  present(time: number, shake: [number, number], shocks: number[], flash: number[], grade: number[]) {
    this.scene.upload(); this.glowF.upload();
    this.sceneTex.source.update(); this.glowTex.source.update();
    const u = this.uni.uniforms as any;
    u.uTime = time;
    u.uShake[0] = shake[0] * this.k; u.uShake[1] = shake[1] * this.k;
    for (let i = 0; i < 16; i++) {
      if (i % 4 === 0) u.uShock[i] = (shocks[i] || 0) * this.k;
      else if (i % 4 === 1) u.uShock[i] = (shocks[i] || 0) * this.k;
      else if (i % 4 === 2) u.uShock[i] = (shocks[i] || 0) * this.k;
      else u.uShock[i] = (shocks[i] || 0) * this.k;
    }
    for (let i = 0; i < 4; i++) u.uFlash[i] = flash[i] || 0;
    for (let i = 0; i < 4; i++) u.uGrade[i] = grade[i];
    this.uni.update();
    this.app.render();
  }

  destroy() { this.app.destroy(true, { children: true }); }
}
