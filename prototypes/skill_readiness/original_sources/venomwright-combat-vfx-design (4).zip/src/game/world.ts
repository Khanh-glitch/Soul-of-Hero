import { Fx, Particles, Pool, Ring, Splash, chips, drops, shards, steam, type Gfx } from './fx';
import { P, Rng, TAU, clamp, hash, text, textW, type Col } from './pixel';
import { drawEnemy, drawEnemyBars, drawPlayer, enemyShadow, playerGlow } from './actors';
import { MAT } from './mats';

export const ATK = 100;
export type DmgKind = 'poison' | 'impact' | 'crystal' | 'acid' | 'burst' | 'bite' | 'pierce';
export interface HitOpts { kind?: DmgKind; src: number; kx?: number; ky?: number; stagger?: number; at?: [number, number]; quiet?: boolean; heal?: number; big?: boolean }
export type StKey = 'corrode' | 'infect' | 'leech' | 'crystal' | 'miasma' | 'remedy' | 'spores' | 'coil' | 'wet' | 'marked';
export interface St { t: number; max: number; k: number }
interface PoisonStack { key: number; rem: number; tick: number; per: number; max: number; src: number }

let EID = 1;
export function resetIds() { EID = 1; }
export class Enemy {
  id = EID++;
  x = 0; y = 0; kx = 0; ky = 0; r = 6; hp = 100; maxHp = 100; speed = 30; face = Math.PI / 2; walk = 0;
  flash = 0; tint = 0; squash = 0; stagger = 0; spawn = 0.5; dying = 0; dyT = 0; dyKind: DmgKind = 'impact'; dyDir = 0;
  des = 40; orb = 1; atkT = 0.6; lunge = 0; slow = 0; lastHurt = -99; hover = false; pull = 0;
  st: Partial<Record<StKey, St>> = {};
  poison: PoisonStack[] = [];
  constructor(public kind: 'grunt' | 'elite' | 'boss', public variant: number) {
    if (kind === 'grunt') { this.r = 6; this.hp = this.maxHp = 260; this.speed = 26 + (variant * 3); }
    else if (kind === 'elite') { this.r = 9.5; this.hp = this.maxHp = 900; this.speed = 22; }
    else { this.r = 22; this.hp = this.maxHp = 8000; this.speed = 12; }
  }
  get poisonLeft() { let m = 0; for (const p of this.poison) if (p.rem > m) m = p.rem; return m; }
  get poisonMax() { let m = 0; for (const p of this.poison) if (p.max > m) m = p.max; return m; }
}

export class Player {
  x = 0; y = 0; vx = 0; vy = 0; face = 0; hp = 1000; maxHp = 1000; form: 'vessel' | 'venom' = 'vessel';
  cat = 0; venomT = 0; walk = 0; cast = 0; castMax = 0.3; castKind = 0; speed = 88;
  path: { pts: { x: number; y: number }[]; len: number[]; total: number; t: number; dur: number } | null = null;
  mt: { x: number; y: number } | null = null; hurtT = 0; trail = 0; shimmer = 0; aura = 0;
}

export interface Task { gen: Generator<number | void>; wait: number; name?: string }
interface Num { x: number; y: number; vy: number; t: number; txt: string; c: Col; big: boolean }

export class World {
  time = 0; frame = 0; rng: Rng; seed = 1;
  enemies: Enemy[] = []; player = new Player(); fx: Fx[] = []; parts = new Particles();
  nums: Num[] = []; tasks: Task[] = [];
  shocks: { x: number; y: number; r: number; max: number; t: number; dur: number; amp: number }[] = [];
  shakeT = 0; shakeM = 0; flashC: Col = 0; flashA = 0; flashT = 0; flashD = 1; hitstop = 0; dim = 0; dimTo = 0;
  stats = { total: 0, kills: 0, hits: 0, ev: [] as { t: number; a: number }[] };
  cfg = { density: 16, boss: false, wave: false, respawn: true };
  respawnQ: number[] = []; nextWave = 0; bossT = 0;
  input = { x: 0, y: 0 };
  uid = 1; overlay: ((g: Gfx) => void) | null = null; lab = false;
  lastHeal = 0; castLog: { t: number; id: number }[] = [];

  constructor(public W: number, public H: number) { this.rng = new Rng(1); this.reset(1); }

  // ---------- setup ----------
  reset(seed: number, formation = false) {
    this.seed = seed; this.rng = new Rng(seed);
    this.enemies = []; this.fx = []; this.parts.clear(); this.nums = []; this.tasks = []; this.shocks = [];
    this.time = 0; this.frame = 0; this.respawnQ = []; this.shakeT = 0; this.flashA = 0; this.hitstop = 0; this.dim = 0; this.nextWave = 6; this.bossT = 0;
    const p = this.player;
    p.x = formation ? this.W * 0.3 : this.W / 2; p.y = this.H * 0.55; p.vx = p.vy = 0; p.face = 0; p.path = null; p.mt = null; p.cast = 0;
    p.hp = p.maxHp; p.form = 'vessel'; p.venomT = 0;
    this.fillEnemies(formation);
  }
  count() { return this.enemies.filter(e => e.dying <= 0 && e.kind !== 'boss').length; }
  hasBoss() { return this.enemies.some(e => e.kind === 'boss' && e.dying <= 0); }
  fillEnemies(formation: boolean) {
    const n = this.cfg.density, elites = Math.max(1, Math.round(n / 8));
    for (let i = 0; i < n; i++) {
      const e = new Enemy(i < elites ? 'elite' : 'grunt', Math.floor(this.rng.next() * 3));
      this.place(e, formation);
      e.spawn = formation ? 0 : this.rng.range(0.1, 0.9);
      this.enemies.push(e);
    }
    if (this.cfg.boss) { const b = new Enemy('boss', 0); this.place(b, formation); b.spawn = 0.8; this.enemies.push(b); }
  }
  place(e: Enemy, formation: boolean, edge = false) {
    const p = this.player, r = this.rng;
    e.des = e.kind === 'boss' ? 70 : e.kind === 'elite' ? 40 + r.next() * 40 : 28 + r.next() * 110;
    e.orb = r.sign();
    for (let tries = 0; tries < 20; tries++) {
      if (edge) {
        const s = r.int(4);
        e.x = s === 0 ? 10 : s === 1 ? this.W - 10 : r.range(10, this.W - 10); e.y = s === 2 ? 10 : s === 3 ? this.H - 10 : r.range(10, this.H - 10);
      } else if (formation) {
        const a = r.range(-1.0, 1.0), d = r.range(70, Math.min(this.W * 0.62, 260));
        e.x = p.x + Math.cos(a) * d; e.y = p.y + Math.sin(a) * d * 0.9;
      } else { e.x = r.range(16, this.W - 16); e.y = r.range(16, this.H - 16); }
      e.x = clamp(e.x, 12, this.W - 12); e.y = clamp(e.y, 12, this.H - 12);
      if (Math.hypot(e.x - p.x, e.y - p.y) < 55) continue;
      let ok = true;
      for (const o of this.enemies) if (Math.hypot(o.x - e.x, o.y - e.y) < o.r + e.r + 1) { ok = false; break; }
      if (ok) break;
    }
    e.face = Math.atan2(p.y - e.y, p.x - e.x);
  }
  setDensity(n: number) { this.cfg.density = n; }

  // ---------- helpers ----------
  add<T extends Fx>(f: T): T { this.fx.push(f); return f; }
  run(gen: Generator<number | void>, name?: string) { this.tasks.push({ gen, wait: 0, name }); }
  alive(): Enemy[] { return this.enemies.filter(e => e.dying <= 0 && e.spawn <= 0.2); }
  near(x: number, y: number, r: number): Enemy[] { return this.enemies.filter(e => e.dying <= 0 && Math.hypot(e.x - x, e.y - y) < r + e.r); }
  nearest(x: number, y: number, maxD = 1e9, ex?: Set<number>): Enemy | null {
    let b: Enemy | null = null, bd = maxD;
    for (const e of this.enemies) { if (e.dying > 0 || (ex && ex.has(e.id))) continue; const d = Math.hypot(e.x - x, e.y - y) - e.r; if (d < bd) { bd = d; b = e; } }
    return b;
  }
  inCone(x: number, y: number, ang: number, range: number, half: number): Enemy[] {
    return this.enemies.filter(e => {
      if (e.dying > 0) return false;
      const dx = e.x - x, dy = e.y - y, d = Math.hypot(dx, dy);
      if (d - e.r > range) return false;
      if (d < e.r + 3) return true;
      let da = Math.atan2(dy, dx) - ang; da = Math.abs(((da + Math.PI) % TAU + TAU) % TAU - Math.PI);
      return da <= half + Math.asin(Math.min(1, e.r / d));
    });
  }
  segDist(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
    const vx = bx - ax, vy = by - ay, l2 = vx * vx + vy * vy || 1;
    const t = clamp(((px - ax) * vx + (py - ay) * vy) / l2, 0, 1);
    return Math.hypot(px - (ax + vx * t), py - (ay + vy * t));
  }
  shake(m: number, d = 0.25) { if (m >= this.shakeM || this.shakeT <= 0) { this.shakeM = m; this.shakeT = d; this.shakeD = d; } }
  shakeD = 0.25;
  shock(x: number, y: number, max: number, dur: number, amp = 3) { if (this.shocks.length < 4) this.shocks.push({ x, y, r: 0, max, t: 0, dur, amp }); }
  screenFlash(c: Col, a: number, dur = 0.2) { this.flashC = c; this.flashA = a; this.flashT = dur; this.flashD = dur; }
  mark(e: Enemy, key: StKey, dur: number, k = 1) {
    const s = e.st[key];
    if (s) { s.t = Math.max(s.t, dur); s.max = Math.max(s.max, dur); s.k = k; } else e.st[key] = { t: dur, max: dur, k };
  }
  stk(e: Enemy, key: StKey) { return e.st[key]; }
  push(e: Enemy, x: number, y: number, v: number) { const d = Math.hypot(e.x - x, e.y - y) || 1; const w = e.kind === 'boss' ? 0.12 : e.kind === 'elite' ? 0.5 : 1; e.kx += ((e.x - x) / d) * v * w; e.ky += ((e.y - y) / d) * v * w; }
  healPlayer(a: number) { const p = this.player; p.hp = Math.min(p.maxHp, p.hp + a); this.lastHeal = this.time; if (a >= 2) this.nums.push({ x: p.x, y: p.y - 22, vy: -14, t: 0.8, txt: '+' + Math.round(a), c: P.c1, big: false }); }

  poison(e: Enemy, total: number, dur: number, key: number, src: number, every = 0.5) {
    if (e.dying > 0) return;
    const n = Math.max(1, Math.round(dur / every));
    const ex = e.poison.find(p => p.key === key);
    if (ex) { ex.rem = Math.max(ex.rem, dur); ex.max = Math.max(ex.max, dur); return; }
    e.poison.push({ key, rem: dur, max: dur, tick: every, per: total / n, src });
    (e as Enemy & { pEvery?: number }).pEvery = every;
  }

  hit(e: Enemy, amt: number, o: HitOpts): boolean {
    if (e.dying > 0) return false;
    amt = Math.max(1, Math.round(amt));
    const kind = o.kind ?? 'impact', poison = kind === 'poison';
    e.hp -= amt; e.lastHurt = this.time;
    this.stats.total += amt; this.stats.hits++; this.stats.ev.push({ t: this.time, a: amt });
    const pl = this.player;
    pl.cat = Math.min(100, pl.cat + (pl.form === 'vessel' ? amt / 55 : 0));
    if (o.heal) this.healPlayer(amt * o.heal);
    const w = e.kind === 'boss' ? 0.12 : e.kind === 'elite' ? 0.5 : 1;
    if (o.kx || o.ky) { e.kx += (o.kx ?? 0) * w; e.ky += (o.ky ?? 0) * w; e.dyDir = Math.atan2(o.ky ?? 0, o.kx ?? 0); }
    if (poison) e.tint = 1; else { e.flash = 1; e.squash = 0.14; }
    if (!poison) e.stagger = Math.max(e.stagger, (o.stagger ?? 0.1) * (e.kind === 'boss' ? 0.2 : e.kind === 'elite' ? 0.6 : 1));
    const ex = o.at?.[0] ?? e.x, ey = o.at?.[1] ?? e.y;
    if (!o.quiet) this.contact(e, kind, ex, ey, o);
    this.nums.push({ x: e.x + (hash(this.frame * 7 + e.id) - 0.5) * 8, y: e.y - e.r - 8, vy: -22, t: poison ? 0.7 : 0.9, txt: String(amt), c: kind === 'poison' ? P.c1 : kind === 'crystal' ? P.y1 : kind === 'acid' ? P.c2 : kind === 'burst' ? P.g2 : P.i0, big: amt >= 70 || !!o.big });
    if (this.nums.length > 90) this.nums.shift();
    if (e.hp <= 0) { this.kill(e, kind); return true; }
    return false;
  }
  contact(e: Enemy, kind: DmgKind, x: number, y: number, o: HitOpts) {
    const r = this.rng, z = e.r * 0.7;
    switch (kind) {
      case 'poison': if (r.next() < 0.7) drops(this, e.x, e.y, 2, 22, P.c1, P.c3, P.e1, { z, up: 20, size: [1, 2] }); break;
      case 'acid': drops(this, x, y, 4, 40, P.c1, P.c3, P.e2, { z, up: 40, size: [1, 3] }); break;
      case 'crystal': shards(this, x, y, 4, 60, P.y1, P.v1, P.y2, { z, size: [2, 4], up: 50 }); break;
      case 'burst': drops(this, x, y, 5, 70, P.g2, P.c3, P.c1, { z, up: 60 }); chips(this, x, y, 2, 50, P.i1, P.i3, P.i0, { z }); break;
      case 'bite': { const a = Math.atan2(o.ky ?? 0, o.kx ?? 1); shards(this, x, y, 3, 60, P.y1, P.v2, P.y2, { z, ang: a, spread: 2, size: [2, 3] }); this.add(new Splash(x, y, 4, P.c1, P.c3)); break; }
      case 'pierce': shards(this, x, y, 3, 50, P.c2, P.e2, P.c3, { z, size: [2, 3] }); break;
      default: chips(this, x, y, 3, 55, P.i1, P.i3, P.i0, { z, size: [2, 3] }); drops(this, x, y, 2, 40, P.c1, P.c3, P.e1, { z, up: 40, size: [1, 2] });
    }
  }
  kill(e: Enemy, kind: DmgKind) {
    e.dying = kind === 'poison' || kind === 'acid' ? 0.75 : kind === 'crystal' ? 0.38 : 0.16; e.dyT = 0; e.dyKind = kind; e.hp = 0;
    this.stats.kills++;
    this.player.cat = Math.min(100, this.player.cat + (this.player.form === 'vessel' ? 3 : 0));
    this.respawnQ.push(this.time + 1.4 + this.rng.next() * 0.8);
    e.poison.length = 0;
    this.nums.push({ x: e.x, y: e.y - e.r - 16, vy: -12, t: 0.9, txt: 'x', c: P.r3, big: false });
  }
  deathFx(e: Enemy) {
    const k = e.dyKind, z = e.r * 0.6;
    if (k === 'poison' || k === 'acid') {
      this.add(new Pool(e.x, e.y, e.r * 1.1 + 2, MAT.acid, 2.6, { blobs: 3, resid: true, boil: 0.8 }));
      steam(this, e.x, e.y, 3, 8, P.e2, P.c1, 3, { vz: 18 });
    } else if (k === 'crystal') {
      shards(this, e.x, e.y, 10 + (e.kind !== 'grunt' ? 8 : 0), 90, P.y1, P.v1, P.y2, { z, up: 90, size: [3, 7] });
      shards(this, e.x, e.y, 4, 40, P.w, P.y1, P.y2, { z, up: 50, size: [2, 4], land: 3 });
      this.add(new Ring(e.x, e.y, e.r * 2.4, 0.3, { w: 2, cols: [P.w, P.y1, P.v1] }));
    } else {
      chips(this, e.x, e.y, 6, 85, P.r2, P.r0, P.r3, { z, up: 90, size: [2, 4], ang: e.dyDir, spread: 3.5 });
      chips(this, e.x, e.y, 3, 60, P.i1, P.i3, P.i0, { z });
      drops(this, e.x, e.y, 7, 80, P.r3, P.g2, P.r2, { z, up: 90, ang: e.dyDir, spread: 3.5, size: [1, 3] });
      this.add(new Ring(e.x, e.y, e.r * 2, 0.22, { w: 2, cols: [P.i0, P.r3, P.r1] }));
    }
    if (e.kind === 'boss') { this.shake(5, 0.5); this.add(new Ring(e.x, e.y, 70, 0.6, { w: 4, cols: [P.i0, P.g2, P.r1] })); chips(this, e.x, e.y, 30, 120, P.i1, P.i3, P.i0, { z: 10, up: 120, size: [3, 6] }); }
  }

  // ---------- simulation ----------
  step(dt: number) {
    if (this.shakeT > 0) this.shakeT -= dt;
    if (this.flashT > 0) this.flashT -= dt;
    if (this.hitstop > 0) { this.hitstop -= dt; this.dim += (0.35 - this.dim) * 0.3; for (const s of this.shocks) s.t += dt * 0.1; return; }
    this.dim += (0 - this.dim) * Math.min(1, dt * 6);
    this.time += dt; this.frame++;
    for (let i = this.tasks.length - 1; i >= 0; i--) {
      const t = this.tasks[i]; t.wait -= dt;
      let n = 0;
      while (t.wait < -1e-6 && n++ < 60) { const r = t.gen.next(); if (r.done) { this.tasks.splice(i, 1); break; } t.wait += (r.value as number) || 1 / 60; }
    }
    this.updatePlayer(dt);
    this.updateEnemies(dt);
    for (const f of this.fx) { f.age += dt; if (f.hf) f.hf = Math.max(0, f.hf - dt); f.upd(this, dt); }
    for (let i = this.fx.length - 1; i >= 0; i--) if (this.fx[i].dead) this.fx.splice(i, 1);
    this.parts.update(this, dt);
    for (const n of this.nums) { n.t -= dt; n.y += n.vy * dt; n.vy *= 0.94; }
    this.nums = this.nums.filter(n => n.t > 0);
    for (const s of this.shocks) { s.t += dt; s.r = s.max * clamp(s.t / s.dur, 0, 1); }
    this.shocks = this.shocks.filter(s => s.t < s.dur);
    const ev = this.stats.ev; while (ev.length && ev[0].t < this.time - 5) ev.shift();
    this.spawnLogic();
    const p = this.player;
    if (p.form === 'venom') { p.venomT -= dt; if (p.venomT <= 0) { p.form = 'vessel'; p.venomT = 0; this.formEnded = this.time; } }
    else p.cat = Math.min(100, p.cat + dt * 1.2);
  }
  formEnded = -999;

  updatePlayer(dt: number) {
    const p = this.player;
    p.cast = Math.max(0, p.cast - dt); p.hurtT = Math.max(0, p.hurtT - dt); p.aura += dt;
    if (p.path) {
      const q = p.path; q.t += dt;
      const f = clamp(q.t / q.dur, 0, 1), e = f < 0.5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2, dist = (0.2 * f + 0.8 * e) * q.total;
      let i = 1; while (i < q.len.length - 1 && q.len[i] < dist) i++;
      const a = q.pts[i - 1], b = q.pts[i], seg = q.len[i] - q.len[i - 1] || 1, u = clamp((dist - q.len[i - 1]) / seg, 0, 1);
      const nx = a.x + (b.x - a.x) * u, ny = a.y + (b.y - a.y) * u;
      const dx = nx - p.x, dy = ny - p.y;
      if (Math.hypot(dx, dy) > 0.2) p.face = Math.atan2(dy, dx);
      p.vx = dx / dt; p.vy = dy / dt; p.x = nx; p.y = ny; p.walk += dt * 14; p.trail = 1;
      if (q.t >= q.dur) p.path = null;
    } else {
      let mx = this.input.x, my = this.input.y;
      if (!mx && !my && p.mt) {
        const dx = p.mt.x - p.x, dy = p.mt.y - p.y, d = Math.hypot(dx, dy);
        if (d < 3) p.mt = null; else { mx = dx / d; my = dy / d; }
      } else if (mx || my) p.mt = null;
      const l = Math.hypot(mx, my) || 1, sp = p.speed * (p.form === 'venom' ? 1.1 : 1);
      p.vx += ((mx / l) * (mx || my ? sp : 0) - p.vx) * Math.min(1, dt * 14);
      p.vy += ((my / l) * (mx || my ? sp : 0) - p.vy) * Math.min(1, dt * 14);
      p.x = clamp(p.x + p.vx * dt, 8, this.W - 8); p.y = clamp(p.y + p.vy * dt, 10, this.H - 8);
      if (Math.hypot(p.vx, p.vy) > 6) { p.walk += dt * Math.hypot(p.vx, p.vy) * 0.14; if (p.cast <= 0) p.face = Math.atan2(p.vy, p.vx); }
      p.trail = Math.max(0, p.trail - dt * 4);
    }
    // push away from solid summons
    for (const f of this.fx) if (f.push) { const dx = p.x - f.x, dy = p.y - f.y, d = Math.hypot(dx, dy), m = f.r + 5; if (d < m && d > 0.1) { p.x += (dx / d) * (m - d); p.y += (dy / d) * (m - d); } }
    if (p.form === 'venom' && this.frame % 9 === 0) {
      const a = this.rng.range(0, TAU);
      this.parts.add({ k: 'steam', x: p.x + Math.cos(a) * 6, y: p.y + Math.sin(a) * 3, z: 6, vx: Math.cos(a) * 4, vy: -2, vz: 10, size: 3, max: 0.9, c1: P.e1, c2: P.c0, drag: 1 });
    }
  }
  glide(pts: { x: number; y: number }[], dur: number) {
    const p = this.player, all = [{ x: p.x, y: p.y }, ...pts.map(q => ({ x: clamp(q.x, 10, this.W - 10), y: clamp(q.y, 12, this.H - 10) }))];
    const len = [0];
    for (let i = 1; i < all.length; i++) len.push(len[i - 1] + Math.hypot(all[i].x - all[i - 1].x, all[i].y - all[i - 1].y));
    p.path = { pts: all, len, total: Math.max(1, len[len.length - 1]), t: 0, dur }; p.mt = null;
  }

  updateEnemies(dt: number) {
    const p = this.player, list = this.enemies;
    const tanks = this.fx.filter(f => f.tank && !f.dead);
    for (let i = list.length - 1; i >= 0; i--) {
      const e = list[i];
      e.flash = Math.max(0, e.flash - dt * 7); e.tint = Math.max(0, e.tint - dt * 3.5); e.squash = Math.max(0, e.squash - dt);
      e.lunge = Math.max(0, e.lunge - dt * 3); e.hover = false;
      for (const k in e.st) { const s = e.st[k as StKey]!; s.t -= dt; if (s.t <= 0) delete e.st[k as StKey]; }
      if (e.dying > 0) {
        e.dyT += dt; e.dying -= dt;
        e.x += e.kx * dt * 0.5; e.y += e.ky * dt * 0.5; e.kx *= 0.9; e.ky *= 0.9;
        if (e.dying <= 0) { this.deathFx(e); list.splice(i, 1); }
        continue;
      }
      // poison ticks
      if (e.poison.length) {
        const ev = (e as Enemy & { pEvery?: number }).pEvery ?? 0.5;
        for (let k = e.poison.length - 1; k >= 0; k--) {
          const s = e.poison[k]; s.rem -= dt; s.tick -= dt;
          if (s.tick <= 0) { s.tick += ev; if (this.hit(e, s.per, { kind: 'poison', src: s.src, quiet: true })) break; }
          if (s.rem <= 0) e.poison.splice(k, 1);
        }
        if (e.dying > 0) continue;
        if (this.frame % 20 === i % 20) drops(this, e.x + this.rng.range(-3, 3), e.y, 1, 6, P.c1, P.c3, P.e1, { z: e.r + 2, up: -10, size: [1, 2], land: 1, max: 1 });
      }
      if (e.spawn > 0) { e.spawn -= dt; if (e.spawn > 0.1 && this.frame % 4 === 0) dustAt(this, e.x, e.y); continue; }
      e.x += e.kx * dt; e.y += e.ky * dt; const kd = Math.max(0, 1 - 5.5 * dt); e.kx *= kd; e.ky *= kd;
      if (e.stagger > 0) { e.stagger -= dt; }
      const bound = e.st.coil;
      if (e.stagger <= 0 && !bound) {
        // choose target: nearest tank summon in reach, else player
        let tx = p.x, ty = p.y, tank: Fx | null = null, td = 1e9;
        for (const t of tanks) { const d = Math.hypot(t.x - e.x, t.y - e.y) - t.r; if (d < 70 && d < td) { td = d; tank = t; } }
        if (tank) { tx = tank.x; ty = tank.y; }
        const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy) || 1;
        const reach = (tank ? tank.r : 5) + e.r + 3;
        const slow = e.slow > 0 ? 0.4 : 1; if (e.slow > 0) e.slow -= dt;
        const sp = e.speed * slow * (e.st.miasma ? 0.8 : 1);
        let mx = 0, my = 0;
        if (d > Math.max(e.des, reach)) { mx = dx / d; my = dy / d; }
        else if (d > reach + 2) { mx = (-dy / d) * e.orb * 0.35 + (dx / d) * 0.1; my = (dx / d) * e.orb * 0.35 + (dy / d) * 0.1; }
        e.x += mx * sp * dt; e.y += my * sp * dt;
        if (mx || my) e.walk += dt * sp * 0.22;
        const fa = Math.atan2(dy, dx); let da = fa - e.face; da = ((da + Math.PI) % TAU + TAU) % TAU - Math.PI; e.face += da * Math.min(1, dt * 8);
        if (d < reach + 2) {
          e.atkT -= dt;
          if (e.atkT <= 0) {
            e.atkT = e.kind === 'boss' ? 1.6 : 1.1 + hash(e.id) * 0.4; e.lunge = 1;
            if (tank) { tank.hurt(this, e.kind === 'boss' ? 30 : e.kind === 'elite' ? 12 : 5); this.parts.add({ k: 'spark', x: tank.x - (tank.x - e.x) * 0.1, y: e.y, z: 6, vx: 0, vy: -10, vz: 20, max: 0.2, c1: P.i0 }); }
            else if (p.hp > 1) { p.hp = Math.max(1, p.hp - (e.kind === 'boss' ? 25 : e.kind === 'elite' ? 8 : 3)); p.hurtT = 0.12; }
          }
        }
      }
      // keep away from solid summons
      for (const f of this.fx) if (f.push) { const dx = e.x - f.x, dy = e.y - f.y, d = Math.hypot(dx, dy), m = f.r + e.r; if (d < m && d > 0.1) { e.x += (dx / d) * (m - d); e.y += (dy / d) * (m - d); } }
      e.x = clamp(e.x, e.r, this.W - e.r); e.y = clamp(e.y, e.r + 3, this.H - e.r);
    }
    // soft separation
    for (let i = 0; i < list.length; i++) {
      const a = list[i]; if (a.dying > 0) continue;
      for (let j = i + 1; j < list.length; j++) {
        const b = list[j]; if (b.dying > 0) continue;
        const dx = b.x - a.x, dy = b.y - a.y, m = (a.r + b.r) * 0.95;
        if (Math.abs(dx) > m || Math.abs(dy) > m) continue;
        const d = Math.hypot(dx, dy);
        if (d < m && d > 0.01) {
          const k = (m - d) * 0.5, wa = b.r / (a.r + b.r), wb = a.r / (a.r + b.r);
          a.x -= (dx / d) * k * 2 * wa * 0.5; a.y -= (dy / d) * k * 2 * wa * 0.5; b.x += (dx / d) * k * 2 * wb * 0.5; b.y += (dy / d) * k * 2 * wb * 0.5;
        }
      }
    }
  }
  spawnLogic() {
    while (this.respawnQ.length && this.respawnQ[0] <= this.time) {
      this.respawnQ.shift();
      if (!this.cfg.respawn || this.cfg.wave) continue;
      if (this.count() < this.cfg.density) this.spawnOne(false);
    }
    if (this.cfg.wave && this.time > this.nextWave && this.count() <= Math.ceil(this.cfg.density * 0.3)) {
      this.nextWave = this.time + 5;
      const need = this.cfg.density - this.count(), side = this.rng.int(4);
      for (let i = 0; i < need; i++) this.spawnOne(true, side);
    }
    if (this.cfg.boss && !this.hasBoss() && this.respawnQ.length === 0) {
      this.bossT += 1 / 60;
      if (this.bossT > 6) { this.bossT = 0; const b = new Enemy('boss', 0); this.place(b, false, true); b.spawn = 1; this.enemies.push(b); }
    }
  }
  spawnOne(edge: boolean, side = -1) {
    const elites = this.enemies.filter(e => e.kind === 'elite' && e.dying <= 0).length;
    const e = new Enemy(elites < Math.max(1, Math.round(this.cfg.density / 8)) ? 'elite' : 'grunt', this.rng.int(3));
    this.place(e, false, edge || true);
    if (side >= 0) { const r = this.rng; e.x = side === 0 ? 8 : side === 1 ? this.W - 8 : r.range(30, this.W - 30); e.y = side === 2 ? 10 : side === 3 ? this.H - 10 : r.range(30, this.H - 30); }
    e.spawn = 0.7; this.enemies.push(e);
  }
  setBoss(on: boolean) {
    this.cfg.boss = on;
    if (on && !this.hasBoss()) { const b = new Enemy('boss', 0); this.place(b, false, true); b.spawn = 0.8; this.enemies.push(b); }
    if (!on) for (const e of this.enemies) if (e.kind === 'boss' && e.dying <= 0) { e.dying = 0.3; e.dyKind = 'burst'; }
  }
  killAll() { for (const e of this.enemies) if (e.dying <= 0) { e.dying = 0.1; e.dyKind = 'burst'; } this.respawnQ.length = 0; }

  // ---------- drawing ----------
  shakeOff(): [number, number] {
    if (this.shakeT <= 0) return [0, 0];
    const k = Math.min(1, this.shakeT / this.shakeD) * this.shakeM, f = this.frame;
    return [Math.round((hash(f * 3) - 0.5) * 2 * k), Math.round((hash(f * 5 + 9) - 0.5) * 2 * k)];
  }
  draw(g: Gfx) {
    g.t = this.time;
    const L = g.s;
    for (const f of this.fx) f.gnd?.(g, this);
    if (this.overlay) this.overlay(g);
    for (const e of this.enemies) enemyShadow(g, e);
    enemyShadow(g, this.player as unknown as Enemy, true);
    { const pl = this.player; g.s.dl = 7; g.s.ring(pl.x, pl.y + 3, 10, 1, this.player.form === 'venom' ? P.c1 : P.v2); g.s.dl = 16; }
    for (const f of this.fx) f.shd?.(g, this);
    this.parts.shadows(g);
    const items: { y: number; f: () => void }[] = [];
    for (const e of this.enemies) items.push({ y: e.y, f: () => drawEnemy(g, e, this) });
    items.push({ y: this.player.y, f: () => drawPlayer(g, this.player, this) });
    for (const f of this.fx) if (f.up) items.push({ y: f.sy || f.y, f: () => f.up!(g, this) });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) it.f();
    for (const f of this.fx) f.air?.(g, this);
    this.parts.draw(g);
    for (const e of this.enemies) drawEnemyBars(g, e, this);
    for (const n of this.nums) {
      const sc = n.big ? 2 : 1, w = textW(n.txt, sc);
      L.dl = n.t < 0.25 ? Math.round(n.t * 64) : 16;
      text(L, n.x - w / 2, n.y, n.txt, n.c, P.bk, sc);
      L.dl = 16;
    }
    const gl = g.l;
    for (const f of this.fx) f.lit?.(g, this);
    this.parts.glows(g);
    playerGlow(g, this.player, this);
    for (const e of this.enemies) if (e.st.crystal || e.poison.length) { /* enemy-bound glow */ }
    gl.reset();
  }
  grade(): number[] { return [this.dim, 1, this.player.form === 'venom' ? 0.0 : 0, 1]; }
  shockArr(): number[] { const a: number[] = []; for (const s of this.shocks) a.push(s.x, s.y, s.r, s.amp * (1 - s.t / s.dur)); return a; }
  flashArr(): number[] {
    if (this.flashT <= 0) return [0, 0, 0, 0];
    const c = this.flashC;
    return [(c & 255) / 255, ((c >> 8) & 255) / 255, ((c >> 16) & 255) / 255, this.flashA * (this.flashT / this.flashD)];
  }
  dps(): number {
    const ev = this.stats.ev; if (!ev.length) return 0;
    let s = 0; const t0 = this.time - 3;
    for (const e of ev) if (e.t >= t0) s += e.a;
    return s / 3;
  }
}

function dustAt(w: World, x: number, y: number) { w.parts.add({ k: 'dust', x: x + (w.rng.next() - 0.5) * 8, y: y + 2, z: 0, vx: 0, vy: 0, vz: 10, size: 3, max: 0.5, c1: P.i3, c2: P.i2 }); }
