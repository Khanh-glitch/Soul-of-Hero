import { Layer, P, TAU, ball, crystalPrism, hash, mix, shard, wormBody, type Col, type Seg } from './pixel';
import { PAL } from './mats';
import { drawFlask, LIQ } from './skills/lib';
import { SKILL_BY_ID } from './skills';

const cache = new Map<number, string>();
const hx = (n: number): Col => (0xff000000 | ((n & 255) << 16) | (n & 0xff00) | ((n >> 16) & 255)) >>> 0;

function motif(L: Layer, id: number) {
  const C = 12;
  switch (id) {
    case 1: { const pts: Seg[] = []; for (let i = 0; i < 7; i++) pts.push({ x: 4 + i * 2.6, y: 16 - Math.sin(i * 0.9) * 4 - i * 0.4, r: i === 6 ? 3.3 : 2.9 - i * 0.2 }); wormBody(L, pts, PAL.glass); L.px(19, 11, P.c2); shard(L, 19, 13, -0.6, 5, 1.4, P.y2, P.v1, P.w); shard(L, 19, 15, 0.7, 5, 1.4, P.y2, P.v1, P.w); L.disc(9, 14, 1, P.c1); break; }
    case 2: { L.line(C, 20, C, 11, P.e2, 2); for (let k = 0; k < 6; k++) { const a = (k / 6) * TAU; shard(L, C + Math.cos(a) * 2, 9 + Math.sin(a), a, 7, 2, P.c0, P.e3, P.c2); } L.disc(C, 9, 2, P.k0); L.px(C, 9, P.c3); L.px(5, 19, P.c1); L.px(19, 18, P.c1); break; }
    case 3: { L.dl = 9; L.disc(C, 14, 9, P.n2); L.dl = 16; wormBody(L, [{ x: 6, y: 16, r: 2 }, { x: 10, y: 13, r: 2.4 }, { x: 14, y: 12, r: 2.6 }, { x: 18, y: 14, r: 2.2 }], PAL.leech); for (let i = 0; i < 8; i++) L.px(4 + Math.floor(hash(i) * 16), 7 + Math.floor(hash(i + 9) * 14), P.y1); L.arc(C, 18, 8, 1, 0.2, 2.9, P.y0); break; }
    case 4: { for (const s of [-1, 1]) { L.line(C + s * 5, 12, C + s * 8, 20, P.k0, 3); L.line(C + s * 5, 12, C + s * 8, 20, P.i2, 1); } ball(L, C, 14, 7.5, PAL.cer, 5); drawFlask(L, C, 9, 5, 0.75, 0.2, LIQ.acid, 1.3); L.line(C - 4, 16, C + 4, 13, P.g2); break; }
    case 5: { ball(L, C, 15, 8, PAL.toad, 6); ball(L, C + 5, 10, 4.5, PAL.toadSac, 4); L.disc(C - 3, 8, 2, P.g2); L.px(C - 3, 8, P.k0); L.disc(C + 1, 7, 2, P.g2); L.px(C + 1, 7, P.k0); break; }
    case 6: { ball(L, C - 1, 17, 6, PAL.chitin, 4.5); ball(L, C + 5, 16, 3, PAL.chitin); drawFlask(L, C - 2, 10, 5, 0.65, 0.35, LIQ.acid, 1); L.line(C - 5, 21, C - 7, 23, P.n3); L.line(C, 21, C, 23, P.n3); L.line(C + 4, 21, C + 6, 23, P.n3); break; }
    case 7: { ball(L, C, 12, 6.5, PAL.chitin, 9); for (let i = -1; i <= 1; i++) L.line(C + i * 3, 5, C + i * 2.2, 19, P.g1); L.px(C - 2, 10, P.c3); L.px(C + 2, 13, P.c3); L.disc(C + 7, 19, 1.5, P.g2); L.disc(C - 7, 20, 1.2, P.g2); break; }
    case 8: { const pts: Seg[] = []; for (let i = 0; i < 12; i++) pts.push({ x: 3 + i * 1.6, y: 12 + Math.sin(i * 0.8) * 5, r: i === 11 ? 2.8 : 2.4 - i * 0.07 }); wormBody(L, pts, { o: P.k0, d: hx(0x0d2b2a), b: P.v0, l: P.v1, s: P.v3 }); for (let i = 1; i < 10; i += 2) shard(L, pts[i].x, pts[i].y - 2, -1.57, 3, 1, P.y2, P.v2, P.w); L.px(21, 10, P.c3); break; }
    case 9: { ball(L, C, 15, 6, PAL.chitinHot, 5); for (const s of [-1, 1]) shard(L, C + s * 5, 12, -1.0 - (s > 0 ? 0.6 : -0.3) + (s > 0 ? 0 : 0), 11, 3, P.g2, P.g0, P.w); L.px(C - 2, 12, P.c1); L.px(C + 2, 12, P.c1); break; }
    case 10: { for (const s of [-1, 1]) for (let k = 0; k < 2; k++) { L.line(C + s * 4, 14, C + s * (8 + k), 21, P.k0, 3); L.line(C + s * 4, 14, C + s * (8 + k), 21, P.i1, 1); } L.rect(C - 7, 13, 14, 4, P.i1); L.rect(C - 7, 13, 14, 1, P.i0); drawFlask(L, C, 8, 6.5, 0.7, 0.2, LIQ.acid, 2); L.px(C + 9, 7, P.c2); break; }
    case 11: { drawFlask(L, C, 13, 8, 0.7, 0, LIQ.acid, 1); L.arc(C, 13, 4, 1, 0, 4.5, P.c3, 3); for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU; L.px(Math.round(C + Math.cos(a) * 11), Math.round(13 + Math.sin(a) * 11), P.c2); } L.rect(C - 2, 2, 5, 2, P.u1); break; }
    case 12: { const br: [number, number, number, number][] = [[3, 20, 12, 13], [12, 13, 21, 8], [12, 13, 17, 20], [8, 16, 5, 9]]; for (const [a, b, c, d] of br) L.line(a, b, c, d, P.v1, 4); for (const [a, b, c, d] of br) L.line(a, b, c, d, P.v2, 2); for (const [a, b, c, d] of br) L.line(a, b, c, d, P.g2, 1); L.disc(21, 8, 2, P.v3); L.px(14, 14, P.w); break; }
    case 13: { L.line(C, 22, C, 11, P.y0, 2); for (let k = 0; k < 6; k++) { const a = (k / 6) * TAU; shard(L, C + Math.cos(a) * 1.5, 9 + Math.sin(a) * 1.5, a, 8, 2.2, k % 2 ? P.w : P.y1, P.v1, P.w); } ball(L, C, 9, 2, PAL.merc); break; }
    case 14: { const pts = [[4, 18], [10, 9], [19, 7], [20, 18]]; for (let i = 0; i < 3; i++) L.line(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], P.c1); for (const [x, y] of pts) ball(L, x, y, 2.6, PAL.liquid); L.disc(4, 18, 4, P.w); L.disc(4, 18, 2, P.g2); L.px(20, 18, P.m2); break; }
    case 15: { L.dl = 12; L.disc(8, 14, 6, P.e2); L.disc(15, 12, 6, P.e1); L.disc(12, 17, 5, P.c0); L.dl = 16; for (const [x, y, r] of [[8, 14, 6], [15, 12, 6], [12, 17, 5]]) L.arc(x - 1, y - 1, r - 1, 1, 3.4, 5.2, P.c3); drawFlask(L, 6, 5, 3, 0.6, 0.3, LIQ.acid, 1); break; }
    case 16: { crystalPrism(L, 7, 21, 12, 3, -1, P.v2, P.v0, P.y2, P.k1, 0); crystalPrism(L, 13, 21, 17, 3.4, 0, P.v2, P.v0, P.y2, P.k1, 0); crystalPrism(L, 18, 21, 10, 2.6, 1, P.v2, P.v0, P.y2, P.k1, 0); L.px(12, 6, P.w); break; }
    case 17: { for (let arm = 0; arm < 3; arm++) { let px = C, py = C; for (let i = 1; i <= 16; i++) { const a = arm * 2.09 + i * 0.4, r = i * 0.62, x = C + Math.cos(a) * r, y = C + Math.sin(a) * r; L.line(px, py, x, y, i > 8 ? P.c1 : P.c2, 2); px = x; py = y; } } L.disc(C, C, 2, P.k0); L.px(C, C, P.g2); break; }
    case 18: { L.dl = 12; L.disc(8, 8, 5, P.k3); L.disc(14, 7, 6, P.e0); L.disc(18, 9, 4, P.k3); L.dl = 16; for (let i = 0; i < 7; i++) { const x = 5 + i * 2.3, y = 13 + ((i * 5) % 7); L.px(Math.round(x), Math.round(y), P.c1); L.px(Math.round(x), Math.round(y) + 1, P.c3); } L.ellipse(8, 21, 4, 1.5, P.e3); L.ellipse(16, 20, 5, 1.5, P.e3); break; }
    case 19: { L.dl = 10; L.disc(C, C, 9, P.g1); L.dl = 16; L.ring(C, C, 9, 1, P.g2); L.rect(C - 1, 6, 3, 13, P.c3); L.rect(6, C - 1, 13, 3, P.c3); for (let i = 0; i < 4; i++) L.line(C, C, C + Math.cos(i * 1.7 + 4) * 8, C + Math.sin(i * 1.7 + 4) * 8, P.m0); L.arc(C, C, 9, 2, 1.0, 3.0, P.k0); break; }
    case 20: { const n = [[4, 18], [12, 5], [20, 18], [3, 9], [21, 9]]; const order = [0, 1, 2, 3, 4, 0]; for (let i = 0; i < 5; i++) L.line(n[order[i]][0], n[order[i]][1], n[order[i + 1]][0], n[order[i + 1]][1], P.v1, 3); for (let i = 0; i < 5; i++) L.line(n[order[i]][0], n[order[i]][1], n[order[i + 1]][0], n[order[i + 1]][1], P.c2, 1); for (const [x, y] of n) { L.disc(x, y, 2.5, P.v2); L.px(x, y, P.w); } break; }
    case 21: { L.ring(C, C, 10, 1, P.u1); L.dl = 16; for (let dy = -8; dy <= 8; dy++) for (let dx = -8; dx <= 8; dx++) { const q = dx * dx + dy * dy; if (q > 64) continue; const ny = dy / 8; L.px(C + dx, C + dy, ny < -0.25 ? mix(P.v1, P.y1, (dx + 8) / 16) : ny < 0.3 ? mix(P.e2, P.c1, (dy + 3) / 12) : mix(P.k1, P.n1, 0.5)); } L.ring(C, C, 8, 1, P.v0); L.arc(C, C, 6, 1, 3.4, 4.7, P.w); L.px(C - 3, C + 4, P.v2); L.px(C + 3, C + 5, P.y2); L.px(C + 1, C - 4, P.c3); break; }
  }
}

export function iconURL(id: number): string {
  const hit = cache.get(id); if (hit) return hit;
  const W = 24, cv = document.createElement('canvas'); cv.width = W; cv.height = W;
  const ctx = cv.getContext('2d')!, img = ctx.createImageData(W, W), d = new Uint32Array(img.data.buffer), L = new Layer(d, W, W);
  const def = SKILL_BY_ID[id];
  for (let y = 0; y < W; y++) for (let x = 0; x < W; x++) L.px(x, y, mix(P.k1, P.k3, (x + y) / (W * 2)));
  L.dl = 5; L.disc(12, 12, 11, def.col[0]); L.dl = 3; L.disc(12, 12, 7, def.col[1]); L.dl = 16;
  motif(L, id);
  for (let i = 0; i < W; i++) { L.px(i, 0, P.k0); L.px(i, W - 1, P.k0); L.px(0, i, P.k0); L.px(W - 1, i, P.k0); }
  L.rect(1, 1, W - 2, 1, mix(def.col[0], P.k0, 0.35)); L.rect(1, W - 2, W - 2, 1, mix(def.col[0], P.k0, 0.6)); L.rect(1, 1, 1, W - 2, mix(def.col[0], P.k0, 0.4)); L.rect(W - 2, 1, 1, W - 2, mix(def.col[0], P.k0, 0.6));
  ctx.putImageData(img, 0, 0);
  const url = cv.toDataURL(); cache.set(id, url); return url;
}
