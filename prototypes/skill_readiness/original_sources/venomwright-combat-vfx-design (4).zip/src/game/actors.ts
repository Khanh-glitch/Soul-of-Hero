import type { Gfx } from './fx';
import { P, TAU, ball, crystalPrism, glow, hash, mix, wormBody, type Col, type Pal } from './pixel';
import { PAL } from './mats';
import type { Enemy, Player, World } from './world';

type CF = (c: Col) => Col;
const ID: CF = c => c;
const tp = (p: Pal, C: CF): Pal => ({ o: C(p.o), d: C(p.d), b: C(p.b), l: C(p.l), s: C(p.s) });

function tintFn(e: Enemy, w: World): CF {
  const t = w.time;
  const pk = e.poison.length ? 0.16 + e.tint * 0.45 : e.tint * 0.45;
  const cry = e.st.crystal, mia = e.st.miasma, rem = e.st.remedy;
  const ck = cry ? Math.min(0.7, cry.k * 0.7) : 0;
  const mk = mia ? 0.22 + 0.14 * Math.sin(t * 7 + e.id) : 0;
  const rk = rem ? 0.45 : 0, rcol = rem ? mix(P.g2, P.e1, rem.k) : 0;
  const fl = e.flash;
  if (!pk && !ck && !mk && !rk && !fl) return ID;
  return c => {
    if (pk) c = mix(c, P.c0, pk);
    if (mk) c = mix(c, P.c1, mk);
    if (ck) c = mix(c, P.y1, ck);
    if (rk) c = mix(c, rcol, rk);
    if (fl) c = mix(c, P.w, Math.min(1, fl * 1.2));
    return c;
  };
}

export function enemyShadow(g: Gfx, e: Enemy, isPlayer = false) {
  const L = g.s, r = isPlayer ? 6.5 : e.r;
  if (!isPlayer && e.dying > 0 && e.dyKind !== 'poison' && e.dyKind !== 'acid' && e.dyKind !== 'crystal') return;
  const sp = isPlayer ? 1 : e.spawn > 0 ? Math.max(0, 1 - e.spawn / 0.7) : 1;
  L.dl = 8; L.ellipse(e.x, e.y + r * 0.55, r * 1.1 * sp, r * 0.52 * sp, P.bk); L.dl = 16;
}

export function drawEnemy(g: Gfx, e: Enemy, w: World) {
  const L = g.s, t = w.time;
  let C = tintFn(e, w);
  let sink = 0, dl = 16, sy = 1;
  if (e.spawn > 0) { const k = Math.min(1, e.spawn / 0.7); sink = k * 8; dl = Math.round(16 * (1 - k * 0.8)); }
  if (e.dying > 0) {
    const k = e.dyT;
    if (e.dyKind === 'poison' || e.dyKind === 'acid') { const m = k / 0.75; sy = 1 - m * 0.75; dl = Math.round(16 * (1 - m * m)); const b = C; C = c => mix(b(c), P.e1, 0.4 + m * 0.5); }
    else if (e.dyKind === 'crystal') { const b = C; C = c => mix(b(c), P.y1, 0.75); if (k > 0.3) return; }
    else { C = c => mix(c, P.i0, 0.8); }
  }
  const f = e.face, fx = Math.cos(f), fy = Math.sin(f), lg = e.lunge;
  const sq = e.squash > 0 ? e.squash / 0.14 : 0, h = (1 - sq * 0.22) * sy;
  const bx = e.x + fx * lg * 3 + (e.stagger > 0 ? Math.sin(t * 60) * 0.8 : 0), by = e.y + sink + fy * lg * 1.5 + (sy < 1 ? (1 - sy) * 8 : 0);
  L.dl = dl;
  const sw = Math.sin(e.walk) * 1.8;
  const showFace = fy > -0.35;
  if (e.kind === 'grunt') {
    if (e.variant === 0) { // Imp
      const p = tp(PAL.imp, C), as = Math.sin(e.walk + 1) * 2.2;
      L.rect(bx - 3.5, by + sw, 2.5, 2.5, C(P.r0)); L.rect(bx + 1, by - sw, 2.5, 2.5, C(P.r0));
      L.line(bx - 4, by - 4 * h, bx - 6.5 + fx * lg * 2, by - 1 + as, C(P.r1), 1.2);
      L.line(bx + 4, by - 4 * h, bx + 6.5 + fx * lg * 2, by - 1 - as, C(P.r1), 1.2);
      ball(L, bx, by - 3.5 * h, 4.8, p, 4.2 * h);
      const hx = bx + fx * 1.8, hy = by - 8.5 * h + fy;
      ball(L, hx, hy, 3.5, tp(PAL.imp, c => C(mix(c, P.r3, 0.18))), 3.2 * h);
      L.line(hx - 2, hy - 2, hx - 3.5, hy - 5.5, C(P.i0)); L.line(hx + 2, hy - 2, hx + 3.5, hy - 5.5, C(P.i0));
      if (showFace) {
        L.dot(hx - 1.2 + fx, hy + fy * 0.6, C(P.g2)); L.dot(hx + 1.2 + fx, hy + fy * 0.6, C(P.g2));
        L.dot(hx - 1.2 + fx, hy + fy * 0.6 - 0.5, C(P.w)); L.dot(hx + 1.2 + fx, hy + fy * 0.6 - 0.5, C(P.w));
      }
    } else if (e.variant === 1) { // Armored Beetle Crab
      const p = tp(PAL.crab, C);
      for (let i = 0; i < 3; i++) for (const s of [-1, 1]) {
        const ph = Math.sin(e.walk + i * 2.1 + (s > 0 ? 3 : 0));
        L.line(bx + s * 3, by - 2 + (i - 1) * 2, bx + s * (7.5 + ph), by - 1 + (i - 1) * 3 + Math.cos(e.walk + i) * 0.7, C(P.u0));
        L.dot(bx + s * 5.2, by - 2 + (i - 1) * 2.5, C(P.u1));
      }
      ball(L, bx, by - 3.5 * h, 6.2, p, 4 * h);
      L.line(bx - 3.5, by - 5.8 * h, bx + 3.5, by - 5.8 * h, C(P.u2));
      for (const s of [-1, 1]) {
        const cx = bx + s * 5.5 + fx * 3, cy = by - 2 + fy * 2 - lg * 1;
        L.line(bx + s * 4, by - 3, cx, cy, C(P.u1)); ball(L, cx, cy, 2, tp(PAL.bone, C));
        L.dot(cx + fx, cy + fy, C(P.k0));
      }
      if (showFace) {
        L.dot(bx - 1.6 + fx * 2, by - 6.8 * h + fy, C(P.g2)); L.dot(bx + 1.6 + fx * 2, by - 6.8 * h + fy, C(P.g2));
      }
    } else { // Bone Cultist
      const p = tp(PAL.bone, C), as = Math.sin(e.walk) * 2.5;
      L.rect(bx - 2.5, by + sw * 0.6, 2, 2.5, C(P.i4)); L.rect(bx + 0.5, by - sw * 0.6, 2, 2.5, C(P.i4));
      L.line(bx - 3, by - 8 * h, bx - 5.5 + fx * lg * 3, by + 1 + as, C(P.i2)); L.line(bx + 3, by - 8 * h, bx + 5.5 + fx * lg * 3, by + 1 - as, C(P.i2));
      L.dot(bx - 5.5 + fx * lg * 3, by + 1 + as, C(P.i0)); L.dot(bx + 5.5 + fx * lg * 3, by + 1 - as, C(P.i0));
      ball(L, bx, by - 5.2 * h, 3.8, p, 5.4 * h);
      const hx = bx + fx, hy = by - 12 * h + fy;
      ball(L, hx, hy, 3.3, tp(PAL.hood, C), 3.2 * h);
      if (showFace) {
        L.dot(hx - 1.2 + fx, hy + 0.5, C(P.r3)); L.dot(hx + 1.2 + fx, hy + 0.5, C(P.r3));
        L.dot(hx - 1.2 + fx, hy, C(P.r2)); L.dot(hx + 1.2 + fx, hy, C(P.r2));
      }
    }
  } else if (e.kind === 'elite') { // Armored Iron Brute
    const p = tp(PAL.brute, C), iron = tp(PAL.iron, C), as = Math.sin(e.walk) * 2.8;
    L.rect(bx - 5.5, by + 1 + sw, 4.5, 3.5, C(P.r0)); L.rect(bx + 1, by + 1 - sw, 4.5, 3.5, C(P.r0));
    for (const s of [-1, 1]) {
      L.line(bx + s * 8, by - 9 * h, bx + s * 11 + fx * lg * 3, by - 2 + as * s, C(P.r1), 2.2);
      ball(L, bx + s * 11 + fx * lg * 3, by - 1 + as * s, 3, p);
    }
    ball(L, bx, by - 6.5 * h, 8.5, p, 7.5 * h);
    for (let i = -1; i <= 1; i++) {
      const sx = bx + i * 3.8, sy2 = by - 13.5 * h;
      L.tri(sx - 1.6, sy2 + 1, sx, sy2 - 3.2, sx + 1.6, sy2 + 1, C(P.i1));
      L.dot(sx, sy2 - 2, C(P.i0));
    }
    ball(L, bx - 8.5, by - 10.5 * h, 3.6, iron); ball(L, bx + 8.5, by - 10.5 * h, 3.6, iron);
    const hx = bx + fx * 2, hy = by - 15.5 * h + fy * 1.5;
    ball(L, hx, hy, 4.8, iron, 4.2 * h);
    L.line(hx - 4.2, hy - 2, hx - 6.5, hy - 6.5, C(P.i0)); L.line(hx + 4.2, hy - 2, hx + 6.5, hy - 6.5, C(P.i0));
    if (showFace) {
      L.rect(Math.round(hx - 2.5 + fx), Math.round(hy), 5.5, 1.2, C(P.k0));
      L.dot(hx - 1.2 + fx, hy, C(P.r3)); L.dot(hx + 1.2 + fx, hy, C(P.r3));
      L.dot(hx - 1.2 + fx, hy - 0.5, C(P.r2)); L.dot(hx + 1.2 + fx, hy - 0.5, C(P.r2));
    }
    if (fy > -0.5) {
      const pu = 0.5 + 0.5 * Math.sin(t * 4 + e.id);
      L.disc(bx, by - 6.5 * h, 2.2, C(mix(P.r2, P.g2, pu)));
      L.dot(bx, by - 6.5 * h, C(P.w));
    }
  } else { // Boss: Monolithic Stone Titan
    const p = tp(PAL.stone, C), sw2 = Math.sin(e.walk * 0.7) * 3.2;
    L.rect(bx - 13, by - 6 + sw2, 10, 10, C(P.k2)); L.rect(bx + 3, by - 6 - sw2, 10, 10, C(P.k2));
    L.rect(bx - 13, by - 6 + sw2, 10, 2.5, C(P.i3)); L.rect(bx + 3, by - 6 - sw2, 10, 2.5, C(P.i3));
    for (const s of [-1, 1]) {
      L.line(bx + s * 20, by - 22 * h, bx + s * 24 + fx * lg * 4, by - 6 + sw2 * s * 0.5, C(P.k3), 6.5);
      ball(L, bx + s * 24 + fx * lg * 4, by - 3 + sw2 * s * 0.5, 7.5, p);
    }
    ball(L, bx, by - 18 * h, 20, p, 16 * h);
    const lava = 0.5 + 0.5 * Math.sin(t * 2.5);
    const lc = C(mix(P.r2, P.g2, lava));
    for (let i = 0; i < 7; i++) {
      const a0 = -2.6 + i * 0.48, r0 = 4 + hash(i) * 6;
      L.line(bx + Math.cos(a0) * r0, by - 18 * h + Math.sin(a0) * r0 * 0.8, bx + Math.cos(a0 + 0.3) * (r0 + 8), by - 18 * h + Math.sin(a0 + 0.3) * (r0 + 7) * 0.8, lc, 1.2);
    }
    ball(L, bx - 18, by - 29 * h, 5.5, p); ball(L, bx + 18, by - 29 * h, 5.5, p);
    for (const s of [-1, 1]) for (let k = 0; k < 2; k++) {
      L.tri(bx + s * (15 + k * 4) - 2.5, by - 32 * h, bx + s * (17 + k * 4), by - 40 * h - k * 2, bx + s * (15 + k * 4) + 2.5, by - 32 * h, C(P.i1));
    }
    const hx = bx + fx * 2, hy = by - 36 * h + fy;
    ball(L, hx, hy, 9.5, p, 8.5 * h);
    for (let i = -2; i <= 2; i++) {
      L.tri(hx + i * 3.6 - 1.6, hy - 6, hx + i * 3.6, hy - 13 - (2 - Math.abs(i)) * 2.5, hx + i * 3.6 + 1.6, hy - 6, C(P.i1));
    }
    if (showFace) {
      L.disc(hx - 3.2 + fx, hy + fy * 0.5, 1.8, lc); L.disc(hx + 3.2 + fx, hy + fy * 0.5, 1.8, lc);
      L.dot(hx - 3.2 + fx, hy, C(P.w)); L.dot(hx + 3.2 + fx, hy, C(P.w));
    }
    glow(g.l, bx, by - 18, 24, P.r2, 0.14 + lava * 0.09, 3);
  }
  L.dl = 16;
  if (e.dying <= 0 && e.spawn <= 0.1) overlays(g, e, w, e.x, e.y, e.kind === 'boss' ? 46 : e.kind === 'elite' ? 20 : 12);
  if (e.hover) {
    const hh = e.kind === 'boss' ? 46 : e.kind === 'elite' ? 20 : 13, rr = e.r + 3, cy = e.y - hh * 0.4;
    for (const [sx, sy2] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      L.rect(e.x + sx * rr - (sx > 0 ? 2 : 0), cy + sy2 * (rr * 0.9) - (sy2 > 0 ? 0 : 0), 3, 1, P.g2);
      L.rect(e.x + sx * rr - (sx > 0 ? 0 : 0), cy + sy2 * (rr * 0.9) - (sy2 > 0 ? 2 : 0), 1, 3, P.g2);
    }
  }
}

function overlays(g: Gfx, e: Enemy, w: World, x: number, y: number, H: number) {
  const L = g.s, t = w.time, cy = y - H * 0.45, rx = e.r * 0.85, ry = H * 0.42;
  const pos = (i: number, s: number): [number, number] => { const a = hash(e.id * 13 + i + s * 101) * TAU, d = Math.sqrt(hash(e.id * 7 + i * 3 + s * 53)); return [x + Math.cos(a) * rx * d, cy + Math.sin(a) * ry * d]; };
  const cor = e.st.corrode;
  if (cor) {
    const k = Math.min(1, cor.t / 1.0), n = 3 + Math.round(cor.k * 5);
    for (let i = 0; i < n; i++) {
      if (hash(i * 3 + e.id) > k) continue;
      const [px, py] = pos(i, 1), X = Math.round(px), Y = Math.round(py);
      L.rect(X - 1, Y, 3, 2, P.k0); L.dot(X - 1.5, Y, P.c0); L.dot(X + 1.5, Y, P.c0); L.dot(X, Y - 1, P.c1); L.dot(X - 1, Y + 1.5, P.e2); L.dot(X + 1, Y + 1.5, P.e2);
      if (Math.sin(t * 8 + i * 2) > 0.45) L.dot(X, Y, P.c2);
      if (i % 2 === 0) { L.dl = 8; L.dot(X, Y - 2 - Math.floor((t * 7 + i * 2) % 5), P.e3); L.dl = 16; }
    }
  }
  const inf = e.st.infect;
  if (inf) {
    const k = Math.min(1, inf.t / 1.0), n = 4 + Math.round(inf.k * 3);
    for (let i = 0; i < n; i++) {
      if (hash(i + e.id) > k) continue;
      const a = (i / n) * TAU + 0.3, X = Math.round(x + Math.cos(a) * (rx + 1)), Y = Math.round(cy + Math.sin(a) * (ry + 1)), pu = Math.sin(t * 5 + i * 1.7) > 0;
      L.line(X, Y, x + Math.cos(a) * rx * 0.4, cy + Math.sin(a) * ry * 0.4, P.e1);
      L.disc(X, Y, 1, P.e3); L.dot(X, Y, pu ? P.c3 : P.c1);
    }
  }
  const lee = e.st.leech;
  if (lee) {
    const n = Math.round(lee.k);
    for (let i = 0; i < n; i++) {
      const a = i * 2.4 + 1, bx = x + Math.cos(a) * (rx + 0.5), by = cy + Math.sin(a) * (ry + 0.5), wg = Math.sin(t * 10 + i * 2) * 1.2;
      const dx = Math.cos(a), dy = Math.sin(a) * 0.7;
      wormBody(L, [{ x: bx, y: by, r: 1.5 }, { x: bx + dx * 2 + wg * -dy, y: by + dy * 2 + wg * dx, r: 1.4 }, { x: bx + dx * 4 - wg * -dy, y: by + dy * 4 - wg * dx, r: 1.1 }], PAL.leech, { spec: false });
      if (Math.sin(t * 6 + i) > 0.1) L.dot(bx, by, P.m2);
    }
  }
  const cry = e.st.crystal;
  if (cry && cry.k > 0.02) {
    const lv = cry.k, n = 4 + Math.round(lv * 5);
    for (let i = 0; i < n; i++) {
      if (hash(i * 11 + e.id) > lv * 1.6) continue;
      const [px, py] = pos(i, 3), hh = Math.max(2, lv * (5 + hash(i + e.id * 3) * 9) * (e.kind === 'boss' ? 2 : 1)), lean = (hash(i * 5 + e.id) - 0.5) * 6;
      crystalPrism(L, px, py + 2, hh, 1.6 + lv * 1.4, lean, P.v2, P.v0, P.y2, P.k1, t);
    }
    for (let i = 0; i < 3; i++) {
      let bx = x + (hash(i + e.id) - 0.5) * rx * 1.4, by = cy + (hash(i * 3 + e.id) - 0.5) * ry, a = -1.57 + (hash(i * 9 + e.id) - 0.5) * 2;
      for (let s = 0; s < lv * 9; s++) { a += (hash(s + i * 20 + e.id) - 0.5) * 0.9; bx += Math.cos(a); by += Math.sin(a); L.dot(bx, by, s % 3 === 0 ? P.y2 : P.y1); L.dot(bx + 0.8, by, P.v0); }
    }
  }
  const rem = e.st.remedy;
  if (rem) {
    const k = rem.k, n = 9, col = mix(P.g2, P.e2, k), col2 = mix(P.c3, P.k1, k);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + t * 0.4 * (1 - k), rr = 1 + (1 - k * 0.9) * 3;
      const X = x + Math.cos(a) * (rx + rr), Y = cy + Math.sin(a) * (ry + rr);
      L.arc(X, Y, 1.8 - k * 0.4, 1, a + 1.2, a + 4.2, col); L.dot(X, Y, col2);
    }
    if (k < 0.25 && Math.sin(t * 4 + e.id) > 0.3) { const X = x + Math.sin(t * 2) * 3, Y = cy - H * 0.55 - ((t * 10) % 7); L.rect(X - 1, Y, 3, 1, P.c3); L.rect(X, Y - 1, 1, 3, P.c3); }
    if (k > 0.2) {
      for (let i = 0; i < 5; i++) {
        let vx = x, vy = cy, a = (i / 5) * TAU + 0.6; const len = (rx + 2) * Math.min(1, (k - 0.2) * 1.4);
        for (let s = 0; s < len; s++) { a += (hash(s + i * 9 + e.id) - 0.5) * 0.7; vx += Math.cos(a); vy += Math.sin(a) * 0.8; L.dot(vx, vy, P.k0); L.dot(vx, vy + 1, P.m0); if (s % 3 === 0 && Math.sin(t * 5 - s * 0.5 + i) > 0.3) L.dot(vx, vy, P.c1); }
      }
    }
  }
  const mia = e.st.miasma;
  if (mia) for (let i = 0; i < 3; i++) { const X = x + (hash(i + e.id) - 0.5) * rx * 2, Y = cy - ry - ((t * 9 + i * 5) % 12); L.dot(X, Y, P.c2); if (i === 0) L.dot(X + 1, Y, P.c3); }
}

export function drawEnemyBars(g: Gfx, e: Enemy, w: World) {
  if (e.dying > 0 || e.spawn > 0.3) return;
  const L = g.s;
  const recent = w.time - e.lastHurt < 5;
  if (!(recent || e.poison.length || e.kind !== 'grunt')) return;
  const W = e.kind === 'boss' ? 46 : e.kind === 'elite' ? 22 : 14, H = e.kind === 'boss' ? 58 : e.kind === 'elite' ? 26 : 16;
  const x0 = e.x - W / 2, y0 = e.y - H - 3, pct = Math.max(0, e.hp / e.maxHp);
  L.rect(x0 - 1, y0 - 1, W + 2, 4, P.bk); L.rect(x0, y0, W, 2, P.r0);
  const fw = Math.max(pct > 0 ? 1 : 0, W * pct);
  L.rect(x0, y0, fw, 2, pct > 0.5 ? P.r2 : pct > 0.25 ? P.g1 : P.r1); L.rect(x0, y0, fw, 1, pct > 0.5 ? P.r3 : P.g2);
  if (e.poison.length) {
    const rem = e.poisonLeft, mx = e.poisonMax || 1, pw = Math.max(1, W * (rem / mx));
    L.rect(x0 - 1, y0 + 3, W + 2, 3, P.bk); L.rect(x0, y0 + 4, W, 1, P.e0); L.rect(x0, y0 + 4, pw, 1, e.tint > 0.3 ? P.c3 : P.c1);
    L.dot(x0 - 3, y0 + 4, P.c1); L.dot(x0 - 3, y0 + 3, P.c3); L.rect(x0 - 4, y0 + 4, 3, 1, P.e3);
    if (e.poison.length > 1) for (let i = 0; i < Math.min(5, e.poison.length); i++) L.dot(x0 + W - 1 - i * 2, y0 + 6, P.c1);
  }
  const bits: Col[] = [];
  if (e.st.corrode) bits.push(P.c0); if (e.st.crystal) bits.push(P.y1); if (e.st.leech) bits.push(P.m1); if (e.st.infect) bits.push(P.e3); if (e.st.remedy) bits.push(P.g2); if (e.st.miasma) bits.push(P.c2);
  bits.forEach((c, i) => { L.rect(x0 + i * 3, y0 - 3, 2, 2, c); });
}

// ---------------- The Venomwright ----------------
export function drawPlayer(g: Gfx, p: Player, w: World) {
  const L = g.s, t = w.time, f = p.face, fx = Math.cos(f), fy = Math.sin(f), qx = -fy, qy = fx;
  const venom = p.form === 'venom';
  const moving = Math.hypot(p.vx, p.vy) > 10;
  const bob = moving ? Math.abs(Math.sin(p.walk)) * 1.2 : Math.sin(t * 2) * 0.4;
  const x = p.x, y = p.y, cy = y - 5 - bob;
  const ck = p.cast > 0 ? p.cast / p.castMax : 0;
  const CF = (c: Col) => (p.hurtT > 0 ? mix(c, P.r3, 0.6) : c);
  const at = (fw: number, sd: number, up: number): [number, number] => [x + fx * fw + qx * sd, cy + fy * fw * 0.8 + qy * sd * 0.8 - up];
  const coat = venom ? P.e0 : P.n1, coatL = venom ? P.e1 : P.n2, coatD = venom ? P.k1 : P.n0;
  // boots
  const sw = Math.sin(p.walk) * 3;
  for (const s of [-1, 1]) L.rect(x + qx * 2 * s + fx * sw * s - 1, y + qy * 2 * s + fy * sw * s * 0.6 + 0, 3, 2, CF(P.u0));
  // cloak tail with rich flowing silhouette
  const sway = Math.sin(t * 4 + p.walk * 0.5) * 1.5 + (moving ? Math.sin(p.walk * 2) * 1.2 : 0), ext = 9 + (moving ? 3 : 0) + (p.path ? 6 : 0);
  const [t0x, t0y] = at(-1, 5.2, 1), [t1x, t1y] = at(-1, -5.2, 1), [tx, ty] = at(-ext, sway, -2);
  L.poly([t0x, t0y, t1x, t1y, tx + qx * 3 - fx, ty + qy * 2, tx - qx * 3 - fx, ty - qy * 2], CF(coatD));
  const [a0x, a0y] = at(-1, 4.2, 1), [a1x, a1y] = at(-1, -4.2, 1);
  L.poly([a0x, a0y, a1x, a1y, tx + qx * 1.5, ty + qy, tx - qx * 1.5, ty - qy], CF(coat));
  L.line(t0x, t0y, tx + qx * 3 - fx, ty + qy * 2, CF(P.u1)); L.line(t1x, t1y, tx - qx * 3 - fx, ty - qy * 2, CF(P.u1));
  // backpack rack of bubbling alchemical flasks
  const [bpx, bpy] = at(-5.5, 0, 4);
  L.rect(bpx - 3, bpy - 2, 7, 5, CF(P.u0)); L.rect(bpx - 3, bpy - 2, 7, 1, CF(P.u1));
  const fc = [venom ? P.c1 : P.c1, P.y1, P.g2];
  for (let i = 0; i < 3; i++) {
    const fxp = bpx - 2 + i * 2.5, fyp = bpy - 4 - (i === 1 ? 1 : 0);
    L.rect(fxp, fyp, 2, 3, CF(P.v1)); L.dot(fxp, fyp + 1, fc[i]); L.dot(fxp + 1, fyp + 2, fc[i]); L.dot(fxp, fyp, P.v3);
    if (Math.sin(t * 4 + i * 2) > 0.7) L.dot(fxp, fyp - 1 - Math.floor((t * 6) % 3), fc[i]);
  }
  // torso with articulated garments
  const torso = (rr: number, ry: number, c: Col) => { const pts: number[] = []; for (let k = 0; k < 12; k++) { const a = (k / 12) * TAU, sd = Math.cos(a) * rr, fw = Math.sin(a) * ry; pts.push(x + qx * sd + fx * fw, cy + 1 + (qy * sd + fy * fw) * 0.8); } L.poly(pts, c); };
  torso(6.6, 5, CF(coatD)); torso(5.6, 4.1, CF(coat));
  torso(3.8, 2.8, CF(coatL));
  L.line(...at(1, -3, 0), ...at(1, 3, 0), CF(P.u1)); // belt
  for (let i = 0; i < 2; i++) { const [vx, vy] = at(1.5, i ? 3.6 : -3.6, -1); L.dot(vx, vy, i ? P.c1 : P.y1); L.dot(vx, vy + 1, P.v1); }
  if (venom) for (let i = 0; i < 3; i++) { const [sx, sy] = at(-1 + i, -3 + i * 2, 1); const pu = Math.sin(t * 5 + i * 1.5) > -0.2; L.line(sx, sy, sx + qx * 2 + fx, sy + qy * 1.5 + fy, pu ? P.c1 : P.e3); }
  // shoulders
  for (const s of [-1, 1]) { const [sx, sy] = at(0, s * 5.8, 3); ball(L, sx, sy, 2.2, PAL.copper); }
  // left arm
  { const [sx, sy] = at(0, -5.5, 3), [hx2, hy2] = at(4, -5.5, 1); L.line(sx, sy, hx2, hy2, CF(coat), 2); L.dot(hx2, hy2, CF(P.i1)); }
  // head: hat, plague mask, polished bone beak
  const [hx, hy] = at(0.5, 0, 7.5);
  L.disc(hx, hy + 1, 6.4, CF(P.n0)); L.disc(hx, hy + 1, 5.4, CF(P.n1)); L.ring(hx, hy + 1, 5.4, 1, CF(P.n2));
  L.disc(hx - 0.4, hy - 0.4, 3.4, CF(P.n2)); L.disc(hx - 1, hy - 1, 2, CF(P.n3));
  L.ring(hx, hy + 0.5, 3.8, 1, CF(P.g1)); L.dot(hx - 3, hy - 1, P.g2);
  { const [bx0, by0] = at(2.5, 0, 6.2), [bt, byt] = at(10, 0, 4.8), [b1x, b1y] = at(3, 2.3, 6.3), [b2x, b2y] = at(3, -2.3, 6.3);
    L.poly([b1x, b1y, bt, byt, bx0, by0], CF(P.i0)); L.poly([b2x, b2y, bt, byt, bx0, by0], CF(P.i2)); L.line(b1x, b1y, bt, byt, CF(P.i4)); L.line(b2x, b2y, bt, byt, CF(P.i4)); L.dot(bt, byt, CF(P.i3)); }
  if (fy > -0.5) for (const s of [-1, 1]) { const [gx, gy] = at(3.4, s * 1.9, 6.4); const pu = 0.5 + 0.5 * Math.sin(t * 3); L.disc(gx, gy, 0.8, venom ? P.c1 : mix(P.y0, P.y1, pu)); L.dot(gx, gy, P.w); }
  // casting arm + vial
  {
    const ext2 = 4.5 + ck * 5, [sx, sy] = at(0, 5.5, 3), [vx, vy] = at(ext2, 5.6 - ck * 1.5, 2 + ck * 3);
    L.line(sx, sy, vx, vy, CF(coat), 2); L.dot(vx, vy, CF(P.i1));
    if (venom) { ball(L, vx + fx, vy + fy - 1, 2.6, PAL.liquid); L.dot(vx + fx + 1, vy + fy + 3, P.c1); }
    else { ball(L, vx + fx, vy + fy - 1, 2.3, PAL.glassHi); L.rect(vx + fx - 1, vy + fy - 1, 3, 2, P.c1); L.dot(vx + fx - 1, vy + fy - 2, P.w); L.rect(vx + fx - 1, vy + fy - 4, 2, 1, P.u1); }
  }
  // venom orbitals
  if (venom) for (let i = 0; i < 3; i++) {
    const a = t * 2.2 + i * 2.09, X = x + Math.cos(a) * 11, Y = cy + 4 + Math.sin(a) * 5 - 2 - Math.sin(t * 3 + i) * 1.5;
    ball(L, X, Y, 1.8, PAL.liquid); if (Math.sin(a) > 0.2) L.dot(X - 0.5, Y - 0.5, P.w);
  }
}
export function playerGlow(g: Gfx, p: Player, w: World) {
  const venom = p.form === 'venom', t = w.time;
  if (venom) glow(g.l, p.x, p.y - 6, 18 + Math.sin(t * 4) * 1.5, P.c0, 0.24, 4);
  else glow(g.l, p.x, p.y - 6, 11, P.v2, 0.12, 3);
  const f = p.face, ck = p.cast > 0 ? p.cast / p.castMax : 0;
  glow(g.l, p.x + Math.cos(f) * (5 + ck * 5), p.y - 5 + Math.sin(f) * 4 - 2, 6 + ck * 3, venom ? P.c2 : P.c1, 0.35, 3);
}
