// Software pixel framebuffer + pixel-art primitives + distance-field material shading.
// Decoupled world coordinates from raster resolution for crisp, high-detail pixel art.

export type Col = number; // packed 0xAABBGGRR (little endian RGBA)
export const rgb = (r: number, g: number, b: number): Col => (0xff000000 | (b << 16) | (g << 8) | r) >>> 0;
export const hex = (s: string): Col => {
  const n = parseInt(s.slice(1), 16);
  return rgb((n >> 16) & 255, (n >> 8) & 255, n & 255);
};
export const mix = (a: Col, b: Col, t: number): Col => {
  if (t <= 0) return a;
  if (t >= 1) return b;
  return rgb(
    (a & 255) + ((b & 255) - (a & 255)) * t,
    ((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t,
    ((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t,
  );
};
export const cssOf = (c: Col) => `rgb(${c & 255},${(c >> 8) & 255},${(c >> 16) & 255})`;

export const P = {
  k0: hex('#040908'), k1: hex('#081510'), k2: hex('#0e221b'), k3: hex('#153227'),
  e0: hex('#0a2e22'), e1: hex('#124d35'), e2: hex('#1a6f47'), e3: hex('#279a52'),
  c0: hex('#6fb522'), c1: hex('#a6ea30'), c2: hex('#d4fa58'), c3: hex('#eeffa0'),
  g0: hex('#967422'), g1: hex('#c8a432'), g2: hex('#f2d658'),
  i0: hex('#eee5cf'), i1: hex('#cebf9b'), i2: hex('#9e8f6e'), i3: hex('#6e624c'), i4: hex('#3e362a'),
  v0: hex('#184e49'), v1: hex('#267d71'), v2: hex('#52b8a0'), v3: hex('#95e4cc'),
  u0: hex('#4e2717'), u1: hex('#965227'), u2: hex('#ca7c3e'),
  n0: hex('#090716'), n1: hex('#14102c'), n2: hex('#221c48'), n3: hex('#372d68'),
  y0: hex('#42a5b6'), y1: hex('#8ee0eb'), y2: hex('#d4f7fc'),
  m0: hex('#78125e'), m1: hex('#c22295'), m2: hex('#f86fc8'),
  w: hex('#ffffff'), bk: hex('#020406'),
  r0: hex('#3e1414'), r1: hex('#763122'), r2: hex('#b4522e'), r3: hex('#e28c4a'),
};

// ---------- deterministic helpers ----------
export const hash = (n: number): number => {
  n = n | 0;
  n = (n ^ 61) ^ (n >>> 16);
  n = (n + (n << 3)) | 0;
  n = n ^ (n >>> 4);
  n = Math.imul(n, 0x27d4eb2d);
  n = n ^ (n >>> 15);
  return (n >>> 0) / 4294967296;
};
export class Rng {
  s: number;
  constructor(seed: number) { this.s = seed >>> 0; }
  next(): number {
    this.s = (this.s + 0x6d2b79f5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number) { return a + (b - a) * this.next(); }
  int(n: number) { return Math.floor(this.next() * n); }
  sign() { return this.next() < 0.5 ? -1 : 1; }
  pick<T>(a: T[]): T { return a[this.int(a.length)]; }
}
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
export const TAU = Math.PI * 2;
export const angDiff = (a: number, b: number) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };

export const BAYER = new Uint8Array([0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5]);

function mkNoise(cells: number, seed: number) {
  const lat = new Float32Array(cells * cells);
  const r = new Rng(seed);
  for (let i = 0; i < lat.length; i++) lat[i] = r.next();
  const out = new Uint8Array(4096);
  const cs = 64 / cells;
  for (let y = 0; y < 64; y++) for (let x = 0; x < 64; x++) {
    const gx = x / cs, gy = y / cs;
    const x0 = Math.floor(gx), y0 = Math.floor(gy);
    let fx = gx - x0, fy = gy - y0;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    const a = lat[(y0 % cells) * cells + (x0 % cells)], b = lat[(y0 % cells) * cells + ((x0 + 1) % cells)];
    const c = lat[((y0 + 1) % cells) * cells + (x0 % cells)], d = lat[((y0 + 1) % cells) * cells + ((x0 + 1) % cells)];
    out[y * 64 + x] = Math.floor((a + (b - a) * fx + (c - a + (d - c - (b - a)) * fx) * fy) * 255);
  }
  return out;
}
const NZ1 = mkNoise(8, 11), NZ2 = mkNoise(16, 29);
export const nz1 = (x: number, y: number) => NZ1[((Math.floor(y) & 63) << 6) | (Math.floor(x) & 63)];
export const nz2 = (x: number, y: number) => NZ2[((Math.floor(y) & 63) << 6) | (Math.floor(x) & 63)];

// ---------- Layer ----------
export class Layer {
  d: Uint32Array;
  W: number; H: number;
  k: number = 1; // raster scaling factor
  a = 255; dl = 16; add = false;
  constructor(d: Uint32Array, W: number, H: number, k = 1) { this.d = d; this.W = W; this.H = H; this.k = k; }
  reset() { this.a = 255; this.dl = 16; this.add = false; return this; }

  // raw pixel write in raster buffer coordinates
  rawPx(gx: number, gy: number, c: Col) {
    if (gx < 0 || gy < 0 || gx >= this.W || gy >= this.H) return;
    if (this.dl < 16 && BAYER[((gy & 3) << 2) | (gx & 3)] >= this.dl) return;
    const i = gy * this.W + gx;
    if (this.add) {
      const d = this.d[i], k = this.a;
      let r = (d & 255) + (((c & 255) * k) >> 8), g = ((d >> 8) & 255) + ((((c >> 8) & 255) * k) >> 8), b = ((d >> 16) & 255) + ((((c >> 16) & 255) * k) >> 8);
      if (r > 255) r = 255; if (g > 255) g = 255; if (b > 255) b = 255;
      this.d[i] = 0xff000000 | (b << 16) | (g << 8) | r;
    } else if (this.a === 255) this.d[i] = c;
    else {
      const d = this.d[i], a = this.a, ia = 255 - a;
      const r = (((c & 255) * a + (d & 255) * ia) / 255) | 0, g = ((((c >> 8) & 255) * a + ((d >> 8) & 255) * ia) / 255) | 0, b = ((((c >> 16) & 255) * a + ((d >> 16) & 255) * ia) / 255) | 0;
      this.d[i] = 0xff000000 | (b << 16) | (g << 8) | r;
    }
  }

  // world-space pixel write
  px(x: number, y: number, c: Col) {
    const k = this.k;
    const gx = Math.round(x * k), gy = Math.round(y * k);
    this.rawPx(gx, gy, c);
    if (k >= 1.8) {
      // when in high-detail mode, draw clean sub-pixel cluster if desired or leave as ultra-sharp raster pin
      this.rawPx(gx + 1, gy, c);
      this.rawPx(gx, gy + 1, c);
      this.rawPx(gx + 1, gy + 1, c);
    }
  }

  // precise raster dot (single native raster pixel)
  dot(x: number, y: number, c: Col) {
    this.rawPx(Math.round(x * this.k), Math.round(y * this.k), c);
  }

  rawHline(x0: number, x1: number, y: number, c: Col) {
    if (!(y >= 0 && y < this.H) || !(x0 <= x1)) return;
    if (x0 < 0) x0 = 0; if (x1 >= this.W) x1 = this.W - 1;
    if (x0 > x1) return;
    if (this.a === 255 && this.dl === 16 && !this.add) { this.d.fill(c, y * this.W + x0, y * this.W + x1 + 1); return; }
    for (let x = x0; x <= x1; x++) this.rawPx(x, y, c);
  }

  hline(x0: number, x1: number, y: number, c: Col) {
    const k = this.k;
    const gy = Math.round(y * k), gx0 = Math.round(x0 * k), gx1 = Math.round(x1 * k);
    const sz = Math.max(1, Math.round(k));
    for (let j = 0; j < sz; j++) this.rawHline(gx0, gx1, gy + j, c);
  }

  rect(x: number, y: number, w: number, h: number, c: Col) {
    const k = this.k;
    const gx = Math.round(x * k), gy = Math.round(y * k), gw = Math.max(1, Math.round(w * k)), gh = Math.max(1, Math.round(h * k));
    for (let j = 0; j < gh; j++) this.rawHline(gx, gx + gw - 1, gy + j, c);
  }

  disc(cx: number, cy: number, r: number, c: Col) {
    const k = this.k;
    const gcx = Math.round(cx * k), gcy = Math.round(cy * k), gr = r * k;
    const R = gr + 0.35, ri = Math.ceil(gr);
    for (let dy = -ri; dy <= ri; dy++) {
      const w = Math.floor(Math.sqrt(Math.max(0, R * R - dy * dy)));
      this.rawHline(gcx - w, gcx + w, gcy + dy, c);
    }
  }

  ellipse(cx: number, cy: number, rx: number, ry: number, c: Col) {
    const k = this.k;
    const gcx = Math.round(cx * k), gcy = Math.round(cy * k), grx = rx * k, gry = ry * k;
    const RY = gry + 0.35, iy = Math.ceil(gry);
    for (let dy = -iy; dy <= iy; dy++) {
      const q = 1 - (dy * dy) / (RY * RY);
      if (q < 0) continue;
      const w = Math.floor((grx + 0.35) * Math.sqrt(q));
      this.rawHline(gcx - w, gcx + w, gcy + dy, c);
    }
  }

  ring(cx: number, cy: number, r: number, w: number, c: Col) {
    const k = this.k;
    const gcx = Math.round(cx * k), gcy = Math.round(cy * k), gr = r * k, gw = Math.max(1, w * k);
    const ro = gr + 0.35, rin = Math.max(0, gr - gw + 0.35), ri = Math.ceil(gr);
    for (let dy = -ri; dy <= ri; dy++) {
      const wo = Math.floor(Math.sqrt(Math.max(0, ro * ro - dy * dy)));
      const tt = rin * rin - dy * dy - 0.01;
      if (Math.abs(dy) < rin && tt > 0) {
        const wi = Math.floor(Math.sqrt(tt));
        this.rawHline(gcx - wo, gcx - wi - 1, gcy + dy, c);
        this.rawHline(gcx + wi + 1, gcx + wo, gcy + dy, c);
      } else this.rawHline(gcx - wo, gcx + wo, gcy + dy, c);
    }
  }

  arc(cx: number, cy: number, r: number, w: number, a0: number, a1: number, c: Col, ry = r) {
    const k = this.k;
    const gcx = Math.round(cx * k), gcy = Math.round(cy * k), gr = r * k, gry = ry * k, gw = Math.max(1, w * k);
    const ri = Math.ceil(gr), span = ((a1 - a0) % TAU + TAU) % TAU || TAU;
    const steps = Math.max(12, Math.ceil(span * Math.max(gr, gry) * 1.4));
    for (let i = 0; i <= steps; i++) {
      const a = a0 + (span * i) / steps;
      const x = gcx + Math.cos(a) * gr, y = gcy + Math.sin(a) * gry;
      if (gw <= 1.2) this.rawPx(Math.round(x), Math.round(y), c);
      else {
        const rad = gw / 2 - 0.2;
        const rri = Math.ceil(rad);
        for (let dy = -rri; dy <= rri; dy++) {
          const ww = Math.floor(Math.sqrt(Math.max(0, rad * rad - dy * dy)));
          this.rawHline(Math.round(x) - ww, Math.round(x) + ww, Math.round(y) + dy, c);
        }
      }
    }
    return ri;
  }

  line(x0: number, y0: number, x1: number, y1: number, c: Col, w = 1) {
    const k = this.k;
    let gx0 = Math.round(x0 * k), gy0 = Math.round(y0 * k), gx1 = Math.round(x1 * k), gy1 = Math.round(y1 * k);
    const gw = Math.max(1, Math.round(w * k));
    const dx = Math.abs(gx1 - gx0), dy = -Math.abs(gy1 - gy0), sx = gx0 < gx1 ? 1 : -1, sy = gy0 < gy1 ? 1 : -1;
    let err = dx + dy, n = 0;
    for (;;) {
      if (gw <= 1) this.rawPx(gx0, gy0, c);
      else if (gw <= 2) { this.rawPx(gx0, gy0, c); this.rawPx(gx0 + 1, gy0, c); this.rawPx(gx0, gy0 + 1, c); this.rawPx(gx0 + 1, gy0 + 1, c); }
      else {
        const rad = gw / 2 - 0.2; const rri = Math.ceil(rad);
        for (let j = -rri; j <= rri; j++) {
          const ww = Math.floor(Math.sqrt(Math.max(0, rad * rad - j * j)));
          this.rawHline(gx0 - ww, gx0 + ww, gy0 + j, c);
        }
      }
      if (gx0 === gx1 && gy0 === gy1) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; gx0 += sx; }
      if (e2 <= dx) { err += dx; gy0 += sy; }
      if (++n > 2400) break;
    }
  }

  poly(pts: number[], c: Col) {
    const k = this.k;
    const gpts: number[] = [];
    for (let i = 0; i < pts.length; i += 2) {
      gpts.push(pts[i] * k, pts[i + 1] * k);
    }
    let mn = 1e9, mx = -1e9;
    const n = gpts.length / 2;
    for (let i = 0; i < n; i++) { const y = gpts[i * 2 + 1]; if (y < mn) mn = y; if (y > mx) mx = y; }
    const xs: number[] = [];
    for (let y = Math.ceil(mn - 0.5); y <= Math.floor(mx - 0.5); y++) {
      const ys = y + 0.5; xs.length = 0;
      for (let i = 0; i < n; i++) {
        const j = (i + 1) % n;
        const ay = gpts[i * 2 + 1], by = gpts[j * 2 + 1];
        if ((ay <= ys && ys < by) || (by <= ys && ys < ay)) xs.push(gpts[i * 2] + ((ys - ay) / (by - ay)) * (gpts[j * 2] - gpts[i * 2]));
      }
      xs.sort((a, b) => a - b);
      for (let k2 = 0; k2 + 1 < xs.length; k2 += 2) this.rawHline(Math.ceil(xs[k2] - 0.5), Math.ceil(xs[k2 + 1] - 0.5) - 1, y, c);
    }
  }

  tri(ax: number, ay: number, bx: number, by: number, cx: number, cy: number, c: Col) { this.poly([ax, ay, bx, by, cx, cy], c); }
}

// ---------- crisp pixel font ----------
const GL: Record<string, string> = {
  '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111', '4': '101101111001001',
  '5': '111100111001111', '6': '111100111101111', '7': '111001001001001', '8': '111101111101111', '9': '111101111001111',
  '+': '000010111010000', '-': '000000111000000', '.': '000000000000010', '%': '101001010100101', 'x': '000101010101000',
  '!': '010010010000010', ':': '000010000010000', ' ': '000000000000000', 'F': '111100110100100', 's': '111100111001111',
};
export function text(L: Layer, x: number, y: number, s: string, c: Col, outline: Col | 0 = 0, sc = 1) {
  const k = L.k;
  const gx = Math.round(x * k), gy = Math.round(y * k), gsc = Math.max(1, Math.round(sc * Math.max(1, k * 0.95)));
  const draw = (ox: number, oy: number, col: Col) => {
    let cx = gx + ox;
    for (const ch of s) {
      const g = GL[ch] ?? GL[' '];
      for (let i = 0; i < 15; i++) if (g[i] === '1') {
        const px = cx + (i % 3) * gsc, py = gy + oy + Math.floor(i / 3) * gsc;
        for (let dy = 0; dy < gsc; dy++) L.rawHline(px, px + gsc - 1, py + dy, col);
      }
      cx += 4 * gsc;
    }
  };
  if (outline) { for (const [ox, oy] of [[-1, 0], [1, 0], [0, -1], [0, 1], [1, 1], [-1, -1]]) draw(ox, oy, outline); }
  draw(0, 0, c);
}
export const textW = (s: string, sc = 1) => s.length * 4 * sc - sc;

// ---------- lit pixel sphere / ellipsoid with bevel highlights ----------
export interface Pal { o: Col; d: Col; b: Col; l: Col; s: Col }
export const pal = (o: Col, d: Col, b: Col, l: Col, s: Col): Pal => ({ o, d, b, l, s });
export function ball(L: Layer, cx: number, cy: number, r: number, p: Pal, ry = r, outline = true) {
  const k = L.k;
  const gcx = Math.round(cx * k), gcy = Math.round(cy * k), grx = (r + 0.35) * k, gry = (ry + 0.35) * k;
  const ir = Math.ceil(r * k), iy = Math.ceil(ry * k), mn = Math.min(grx, gry);
  for (let dy = -iy; dy <= iy; dy++) for (let dx = -ir; dx <= ir; dx++) {
    const nx = dx / grx, ny = dy / gry, q = nx * nx + ny * ny;
    if (q > 1) continue;
    let c: Col;
    if (outline && (1 - Math.sqrt(q)) * mn < Math.max(1, 0.9 * k)) c = p.o;
    else {
      const I = -nx * 0.45 - ny * 0.55 + Math.sqrt(1 - q) * 0.72 + (BAYER[(((gcy + dy) & 3) << 2) | ((gcx + dx) & 3)] - 7.5) * 0.014;
      c = I < 0.22 ? p.d : I < 0.62 ? p.b : I < 0.92 ? p.l : p.s;
    }
    L.rawPx(gcx + dx, gcy + dy, c);
  }
}

export function shard(L: Layer, x: number, y: number, ang: number, len: number, wid: number, lit: Col, dark: Col, edge: Col) {
  if (len < 1.5) { L.px(x, y, lit); return; }
  const ca = Math.cos(ang), sa = Math.sin(ang);
  const tx = x + ca * len, ty = y + sa * len, bx = x - ca * len * 0.4, by = y - sa * len * 0.4;
  const mx = x + ca * len * 0.1, my = y + sa * len * 0.1;
  const lx = mx - sa * wid, ly = my + ca * wid, rx = mx + sa * wid, ry = my - ca * wid;
  L.tri(tx, ty, lx, ly, bx, by, lit);
  L.tri(tx, ty, rx, ry, bx, by, dark);
  L.line(tx, ty, lx, ly, edge);
  L.line(tx, ty, bx, by, mix(edge, lit, 0.5));
}

// bubble: outline ring + translucent body + specular glint
export function bubble(L: Layer, x: number, y: number, r: number, tint: Col, edge: Col, hi: Col) {
  if (r < 1.0) { L.dot(x, y, hi); return; }
  const sa = L.a, sd = L.dl;
  L.dl = 7; L.disc(x, y, Math.max(0.4, r - 0.8), tint); L.dl = sd;
  L.ring(x, y, r, 0.8, edge);
  L.dot(x - r * 0.45, y - r * 0.5, hi);
  if (r > 2.2) {
    L.dot(x - r * 0.45 + 0.5, y - r * 0.5, hi);
    L.dot(x + r * 0.38, y + r * 0.42, edge);
  }
  L.a = sa;
}

// worm / tendril / serpent body: outline pass, base pass, light pass, specular stripe
export interface Seg { x: number; y: number; r: number }
export function wormBody(L: Layer, s: Seg[], p: Pal, opts: { lightOff?: number; stripe?: Col; stripeT?: number; spec?: boolean } = {}) {
  const lo = opts.lightOff ?? 0.28;
  for (let i = s.length - 1; i >= 0; i--) L.disc(s[i].x, s[i].y, s[i].r + 1, p.o);
  for (let i = s.length - 1; i >= 0; i--) L.disc(s[i].x, s[i].y, s[i].r, p.d);
  for (let i = s.length - 1; i >= 0; i--) L.disc(s[i].x - s[i].r * lo * 0.6, s[i].y - s[i].r * lo, s[i].r * 0.78, p.b);
  for (let i = s.length - 1; i >= 0; i--) if (s[i].r > 1.2) L.disc(s[i].x - s[i].r * lo, s[i].y - s[i].r * lo * 1.5, s[i].r * 0.44, p.l);
  if (opts.stripe !== undefined) {
    const T = opts.stripeT ?? 0;
    for (let i = 0; i < s.length; i++) {
      const k = Math.cos((i / s.length) * 9 - T * 7);
      if (k > 0.45) L.disc(s[i].x, s[i].y, Math.max(0.4, s[i].r * 0.4 * k), opts.stripe);
    }
  }
  if (opts.spec !== false) for (let i = 0; i < s.length; i += 2) if (s[i].r > 1.8) L.dot(s[i].x - s[i].r * 0.45, s[i].y - s[i].r * 0.55, p.s);
}

// ---------- distance-field fluids ----------
export interface Mat {
  outline: Col; rim: Col; rimLit: Col; ramp: Col[]; hi: Col; sh: Col; vein: Col; vw: number;
  dep: number; sc: number; fx: number; fy: number; amp: number; hiT: number; hiW: number; dl: number;
}
export class Field {
  h: Float32Array; W: number; H: number; k: number = 1;
  x0 = 1e9; y0 = 1e9; x1 = -1; y1 = -1;
  constructor(W: number, H: number, k = 1) { this.W = W; this.H = H; this.k = k; this.h = new Float32Array(W * H); }
  reset() {
    if (this.x1 < 0) return;
    for (let y = this.y0; y <= this.y1; y++) this.h.fill(0, y * this.W + this.x0, y * this.W + this.x1 + 1);
    this.x0 = 1e9; this.y0 = 1e9; this.x1 = -1; this.y1 = -1;
  }
  private box(a: number, b: number, c: number, d: number): boolean {
    a = Math.max(2, Math.floor(a)); b = Math.max(2, Math.floor(b)); c = Math.min(this.W - 3, Math.ceil(c)); d = Math.min(this.H - 3, Math.ceil(d));
    if (a > c || b > d) return false;
    if (a < this.x0) this.x0 = a; if (b < this.y0) this.y0 = b; if (c > this.x1) this.x1 = c; if (d > this.y1) this.y1 = d;
    return true;
  }
  disc(cx: number, cy: number, r: number, goo = 0) {
    const k = this.k;
    const gcx = cx * k, gcy = cy * k, gr = r * k;
    if (gr <= 0 || !this.box(gcx - gr - 1, gcy - gr - 1, gcx + gr + 1, gcy + gr + 1)) return;
    const { W, h } = this;
    const x0 = Math.max(2, Math.floor(gcx - gr - 1)), x1 = Math.min(W - 3, Math.ceil(gcx + gr + 1)), y0 = Math.max(2, Math.floor(gcy - gr - 1)), y1 = Math.min(this.H - 3, Math.ceil(gcy + gr + 1));
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const dx = x + 0.5 - gcx, dy = y + 0.5 - gcy;
      const v = gr - Math.sqrt(dx * dx + dy * dy) + 0.5;
      if (v <= 0) continue;
      const i = y * W + x, o = h[i];
      if (goo && o > 0) h[i] = Math.max(o, v) + goo * Math.min(o, v); else if (v > o) h[i] = v;
    }
  }
  ellipse(cx: number, cy: number, rx: number, ry: number) {
    const k = this.k;
    const gcx = cx * k, gcy = cy * k, grx = rx * k, gry = ry * k;
    if (!this.box(gcx - grx - 1, gcy - gry - 1, gcx + grx + 1, gcy + gry + 1)) return;
    const { W, h } = this, m = Math.min(grx, gry);
    for (let y = Math.max(2, Math.floor(gcy - gry - 1)); y <= Math.min(this.H - 3, Math.ceil(gcy + gry + 1)); y++)
      for (let x = Math.max(2, Math.floor(gcx - grx - 1)); x <= Math.min(W - 3, Math.ceil(gcx + grx + 1)); x++) {
        const nx = (x + 0.5 - gcx) / grx, ny = (y + 0.5 - gcy) / gry, q = Math.sqrt(nx * nx + ny * ny);
        const v = (1 - q) * m + 0.5;
        if (v > 0 && v > h[y * W + x]) h[y * W + x] = v;
      }
  }
  capsule(ax: number, ay: number, bx: number, by: number, ra: number, rb = ra) {
    const k = this.k;
    const gax = ax * k, gay = ay * k, gbx = bx * k, gby = by * k, gra = ra * k, grb = rb * k;
    const mr = Math.max(gra, grb);
    if (mr <= 0 || !this.box(Math.min(gax, gbx) - mr - 1, Math.min(gay, gby) - mr - 1, Math.max(gax, gbx) + mr + 1, Math.max(gay, gby) + mr + 1)) return;
    const { W, h } = this;
    const vx = gbx - gax, vy = gby - gay, l2 = vx * vx + vy * vy || 1;
    for (let y = Math.max(2, Math.floor(Math.min(gay, gby) - mr - 1)); y <= Math.min(this.H - 3, Math.ceil(Math.max(gay, gby) + mr + 1)); y++)
      for (let x = Math.max(2, Math.floor(Math.min(gax, gbx) - mr - 1)); x <= Math.min(W - 3, Math.ceil(Math.max(gax, gbx) + mr + 1)); x++) {
        const px = x + 0.5 - gax, py = y + 0.5 - gay;
        const t = clamp((px * vx + py * vy) / l2, 0, 1);
        const dx = px - vx * t, dy = py - vy * t;
        const v = gra + (grb - gra) * t - Math.sqrt(dx * dx + dy * dy) + 0.5;
        if (v > 0 && v > h[y * W + x]) h[y * W + x] = v;
      }
  }
  // liquid shading: outline, glossy rim, flowing density bands, caustic veins, lit/shadowed bevels
  shade(L: Layer, m: Mat, t: number, o: { fx?: number; fy?: number; seed?: number; dep?: number; dl?: number } = {}) {
    if (this.x1 < 0) return;
    const { W, h, k: rk } = this, ramp = m.ramp, nR = ramp.length;
    const fx = (o.fx ?? m.fx) * t, fy = (o.fy ?? m.fy) * t, sd = (o.seed ?? 0) * 13, dep = (o.dep ?? m.dep) * rk;
    const sdl = L.dl; const dl = o.dl ?? m.dl;
    L.dl = dl;
    const sc = m.sc / rk;
    const hiW = m.hiW * rk;
    for (let y = this.y0; y <= this.y1; y++) for (let x = this.x0; x <= this.x1; x++) {
      const i = y * W + x, v = h[i];
      if (v <= 0) continue;
      let c: Col;
      if (v < 1 * rk) c = m.outline;
      else {
        const lit = -((h[i + 1] - h[i - 1]) * -0.7 + (h[i + W] - h[i - W]) * -0.7) * 0.5;
        if (v < 2 * rk) c = lit > 0.25 ? m.rimLit : m.rim;
        else {
          const sx = x * sc + sd, sy = y * sc;
          const wp = (nz2(sx * 1.9 - fy * 0.6, sy * 1.9 + fx * 0.6) - 128) * 0.05;
          const n = nz1(sx + fx + wp * 9, sy + fy + wp * 9) / 255;
          const dn = clamp((v - 2 * rk) / dep, 0, 1);
          const q = (1 - dn) * (1 - m.amp) + n * m.amp;
          let k = Math.floor(q * nR + (BAYER[((y & 3) << 2) | (x & 3)] - 7.5) * 0.05);
          k = k < 0 ? 0 : k >= nR ? nR - 1 : k;
          c = ramp[k];
          if (v < hiW) { if (lit > m.hiT) c = m.hi; else if (lit < -m.hiT) c = m.sh; }
          if (m.vw > 0) { const n2 = nz2(sx * 1.3 + fx * 1.5, sy * 1.3 + fy * 1.5 + 5); if (Math.abs(n2 - 128) < m.vw && v > 3 * rk) c = m.vein; }
        }
      }
      L.rawPx(x, y, c);
    }
    L.dl = sdl;
  }
  // vapor: noisy density with dark cavities, rolling lit edges, dithered translucency
  vapor(L: Layer, m: Mat, t: number, o: { fx?: number; fy?: number; seed?: number; dens?: number } = {}) {
    if (this.x1 < 0) return;
    const { W, h, k: rk } = this, nR = m.ramp.length;
    const fx = (o.fx ?? m.fx) * t, fy = (o.fy ?? m.fy) * t, sd = (o.seed ?? 0) * 13, dens = o.dens ?? 1;
    const sdl = L.dl;
    const sc = m.sc / rk;
    for (let y = this.y0; y <= this.y1; y++) for (let x = this.x0; x <= this.x1; x++) {
      const i = y * W + x, v = h[i];
      if (v <= 0) continue;
      const sx = x * sc + sd, sy = y * sc;
      const wp = (nz2(sx * 1.7 + fy * 0.5, sy * 1.7 - fx * 0.5) - 128) * 0.05;
      const n = nz1(sx + fx + wp * 8, sy + fy + wp * 8) / 255;
      const n2 = nz2(sx * 2.1 - fx * 0.7, sy * 2.1 - fy * 0.7) / 255;
      const d = clamp(v / (m.dep * rk), 0, 1) * 0.55 + n * 0.55 + (n2 - 0.5) * 0.25;
      if (d < 0.28) continue;
      const lit = -((h[i + 1] - h[i - 1]) * -0.7 + (h[i + W] - h[i - W]) * -0.7) * 0.5;
      let k = Math.floor(d * nR * 0.95 + (lit > 0.3 ? 1 : 0) - (lit < -0.3 ? 1 : 0));
      k = k < 0 ? 0 : k >= nR ? nR - 1 : k;
      L.dl = Math.round(clamp((m.dl - 4 + d * 8) * dens, 0, 16));
      L.rawPx(x, y, v < 1.2 * rk && d > 0.45 ? m.rim : m.ramp[k]);
    }
    L.dl = sdl;
  }
}

// glow layer helper: stepped (banded) additive halos
export function glow(L: Layer, cx: number, cy: number, r: number, c: Col, k = 0.5, bands = 4) {
  L.add = true;
  const n = Math.max(2, Math.min(bands, Math.ceil((r * L.k) / 2.5)));
  L.a = Math.round((255 * k) / n);
  for (let i = 0; i < n; i++) L.disc(cx, cy, r * (1 - i / n), c);
  L.add = false; L.a = 255;
}

export function crystalPrism(L: Layer, x: number, y: number, h: number, w: number, lean: number, lit: Col, dark: Col, edge: Col, core: Col, t = 0) {
  // upright hexagonal-ish prism with multifaceted bevels and contaminated core
  const tipx = x + lean, tipy = y - h, sh = h * 0.18 + 1;
  L.poly([x - w, y, x - w + lean * 0.2, y - h + sh, tipx, tipy, tipx, y, x, y + 1], lit);
  L.poly([x, y + 1, tipx, y, tipx, tipy, x + w + lean * 0.2, y - h + sh, x + w, y], dark);
  L.line(x - w, y, x - w + lean * 0.2, y - h + sh, edge);
  L.line(x - w + lean * 0.2, y - h + sh, tipx, tipy, edge);
  L.line(tipx, tipy, x, y, mix(edge, lit, 0.6));
  L.line(tipx, tipy, x + w + lean * 0.2, y - h + sh, mix(edge, dark, 0.4));
  if (h > 6) {
    const cx = x + lean * 0.5, cy = y - h * 0.45;
    L.line(cx, cy - h * 0.22, cx, cy + h * 0.25, core);
    if (Math.sin(t * 5 + x) > 0.1) L.dot(cx, cy - h * 0.1 + Math.sin(t * 3 + y) * h * 0.15, edge);
  }
}

// ---------- ground generation ----------
export function makeGround(L: Layer, seed: number) {
  const { W, H, k } = L; const r = new Rng(seed);
  const base = [P.k1, P.k2, hex('#13251f'), hex('#0e1e1b'), hex('#173429')];
  const tw = Math.round(28 * k), th = Math.round(20 * k);
  for (let ty = -1; ty * th < H + th; ty++) {
    const off = (ty & 1) * (tw / 2);
    for (let tx = -1; tx * tw < W + tw; tx++) {
      const x0 = tx * tw + off, y0 = ty * th;
      const tone = base[Math.floor(hash(tx * 73 + ty * 131 + seed) * base.length)];
      for (let j = 0; j < th; j++) L.rawHline(x0, x0 + tw - 1, y0 + j, tone);
      L.rawHline(x0, x0 + tw - 1, y0, hex('#1f3a30'));
      for (let j = 0; j < th; j++) L.rawPx(x0, y0 + j, hex('#1b3329'));
      L.rawHline(x0, x0 + tw - 1, y0 + th - 1, P.k0);
      for (let j = 0; j < th; j++) L.rawPx(x0 + tw - 1, y0 + j, P.k0);
      for (let k2 = 0; k2 < 7; k2++) {
        const px = x0 + 2 + Math.floor(hash(tx * 5 + ty * 17 + k2 * 3) * (tw - 4)), py = y0 + 2 + Math.floor(hash(tx * 11 + ty * 7 + k2 * 9) * (th - 4));
        L.rawPx(px, py, hash(k2 + tx) > 0.5 ? hex('#1e3d31') : P.k0);
      }
    }
  }
  // moss & dark soil patches via noise dither
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const n = nz1((x / k) * 0.11 + 3, (y / k) * 0.11) / 255, n2 = nz2((x / k) * 0.3, (y / k) * 0.3) / 255;
    const b = BAYER[((y & 3) << 2) | (x & 3)] / 16;
    if (n > 0.62 && n2 + b * 0.5 > 0.8) L.rawPx(x, y, hex('#143a2a'));
    else if (n < 0.25 && n2 + b * 0.4 > 0.9) L.rawPx(x, y, hex('#0b1713'));
    if (n > 0.72 && n2 > 0.58 && b > 0.65) L.rawPx(x, y, hex('#1c5238'));
  }
  // cracks
  for (let k2 = 0; k2 < Math.floor((W * H) / (12000 * k * k)); k2++) {
    let x = r.range(0, W), y = r.range(0, H), a = r.range(0, TAU);
    for (let i = 0; i < (r.int(40) + 25) * k; i++) {
      L.rawPx(Math.round(x), Math.round(y), P.k0);
      if (i % 5 === 0) L.rawPx(Math.round(x) + 1, Math.round(y) + 1, hex('#1f3a30'));
      a += r.range(-0.45, 0.45); x += Math.cos(a); y += Math.sin(a);
    }
  }
  // faint central alchemical sigil
  const cx = W / 2, cy = H / 2, rr = Math.min(W, H) * 0.34;
  const rune = hex('#1d4a3b'), rune2 = hex('#16372c');
  const drawRingRaw = (cx: number, cy: number, r: number, c: Col) => {
    const ri = Math.ceil(r);
    for (let dy = -ri; dy <= ri; dy++) {
      const wo = Math.floor(Math.sqrt(Math.max(0, (r + 0.35) ** 2 - dy * dy)));
      L.rawPx(cx - wo, cy + dy, c); L.rawPx(cx + wo, cy + dy, c);
    }
  };
  drawRingRaw(cx, cy, rr, rune2);
  drawRingRaw(cx, cy, rr - 6 * k, rune);
  drawRingRaw(cx, cy, rr * 0.55, rune2);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    const x0 = cx + Math.cos(a) * (rr - 6 * k), y0 = cy + Math.sin(a) * (rr - 6 * k), x1 = cx + Math.cos(a + 0.5) * rr * 0.55, y1 = cy + Math.sin(a + 0.5) * rr * 0.55;
    const steps = Math.ceil(Math.hypot(x1 - x0, y1 - y0));
    for (let s = 0; s <= steps; s += 2) L.rawPx(Math.round(x0 + ((x1 - x0) * s) / steps), Math.round(y0 + ((y1 - y0) * s) / steps), rune2);
  }
  // stepped vignette at the screen edges
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const e = Math.min(x, y, W - 1 - x, H - 1 - y);
    if (e < 14 * k) { const b = BAYER[((y & 3) << 2) | (x & 3)]; if (b > (e / k) + 3) L.rawPx(x, y, P.k0); }
  }
}
