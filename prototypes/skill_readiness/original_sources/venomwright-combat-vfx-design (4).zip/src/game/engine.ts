import { Display } from './display';
import { Custom, type Gfx } from './fx';
import { Field, Layer, P, Rng, TAU, clamp, makeGround, text } from './pixel';
import { ATK, World, resetIds, type Enemy } from './world';
import { SKILLS, SKILL_BY_ID, ULT, type SkillDef } from './skills';
import type { Cast } from './skills/lib';

export type Form = 'vessel' | 'venom';
export type QualityMode = 'ultra' | 'high' | 'classic' | 'auto';
const F = 1 / 60;
export const SLOW = [1, 0.5, 0.25, 0.1];
interface Aim { def: SkillDef; src: 'key' | 'drag'; key: string }
interface Resolved { ang: number; tx: number; ty: number; target: Enemy | null; targets: Enemy[]; route: { x: number; y: number }[]; ok: boolean }
export interface Snapshot {
  form: Form; cat: number; venomT: number; hp: number; maxHp: number; kills: number; dps: number; total: number; alive: number; poisoned: number; poisonMax: number;
  quick: boolean; paused: boolean; slow: number; wasd: boolean; density: number; boss: boolean; wave: boolean; respawn: boolean;
  quality: QualityMode; renderScale: number;
  cds: Record<number, number>; loadout: Record<Form, (number | null)[]>; slotKeys: string[]; aim: { id: number; key: string } | null;
  stage: { n: number; id: number } | null; showcase: { on: boolean; id: number } | null; frame: number; seed: number; hits: number; time: number; lastCastId: number | null; catFull: boolean; formLeft: number;
}

export const WORLD_W = 600;
export const WORLD_H = 340;

export class Game {
  display = new Display();
  world!: World; gfx!: Gfx; ground!: Uint32Array;
  W = WORLD_W; H = WORLD_H; // logical arena world dimensions
  rW = WORLD_W; rH = WORLD_H; // raster buffer dimensions
  renderScale = 2; // pixel density multiplier
  quality: QualityMode = 'ultra';
  displayScale = 2.5; host!: HTMLElement;
  cd: Record<number, number> = {};
  loadout: Record<Form, (number | null)[]> = { vessel: [1, 2, 5], venom: [12, 13, 14] };
  quick = false; paused = false; slowIdx = 0; wasd = false; acc = 0; last = 0; stepReq = 0;
  aim: Aim | null = null; mouse = { x: 0, y: 0, over: false }; dragPts: { x: number; y: number }[] = []; mouseDown = false;
  keys = new Set<string>();
  stage: { n: number; id: number; seed: number; castN: number; manual: boolean } | null = null;
  showcase: { on: boolean; idx: number; t: number } = { on: false, idx: 0, t: 0 };
  lastCastId: number | null = null;
  toastFn: (m: string) => void = () => 0;
  private raf = 0; private destroyed = false; private cleanup: (() => void)[] = []; private ro?: ResizeObserver;
  private fld!: Field;

  async init(host: HTMLElement) {
    this.host = host;
    this.calcLayout();
    await this.display.init(host, this.rW, this.rH, this.displayScale, this.renderScale);
    if (this.destroyed) { this.display.destroy(); return; }
    this.world = new World(this.W, this.H);
    this.buildGfx();
    this.world.reset(Math.floor(Math.random() * 1e6));
    this.bind();
    this.ro = new ResizeObserver(() => this.onResize()); this.ro.observe(host);
    this.last = performance.now();
    const loop = (now: number) => { if (this.destroyed) return; this.raf = requestAnimationFrame(loop); this.frame(now); };
    this.raf = requestAnimationFrame(loop);
  }

  calcLayout() {
    const vw = Math.max(320, this.host.clientWidth), vh = Math.max(240, this.host.clientHeight);
    const aspect = clamp(vw / vh, 1.4, 2.1);
    this.H = WORLD_H;
    this.W = Math.round(WORLD_H * aspect);

    // determine raster density
    let k = 2;
    if (this.quality === 'classic') k = 1;
    else if (this.quality === 'high') k = 1.5;
    else if (this.quality === 'ultra') k = 2;
    else {
      // auto mode
      if (vw >= 2400) k = 2.25;
      else if (vw >= 1600) k = 2;
      else if (vw >= 1100) k = 1.5;
      else k = 1;
    }
    this.renderScale = k;
    this.rW = Math.round(this.W * k);
    this.rH = Math.round(this.H * k);
    this.displayScale = vw / this.rW;
  }

  setQuality(q: QualityMode) {
    this.quality = q;
    this.onResize(true);
  }

  buildGfx() {
    const d = this.display;
    this.fld = new Field(this.rW, this.rH, this.renderScale);
    this.gfx = { s: d.scene.L, l: d.glowF.L, f: this.fld, t: 0, W: this.rW, H: this.rH, k: this.renderScale };
    this.ground = new Uint32Array(this.rW * this.rH);
    makeGround(new Layer(this.ground, this.rW, this.rH, this.renderScale), 17);
  }

  onResize(force = false) {
    if (this.destroyed || !this.world) return;
    const prevRW = this.rW, prevRH = this.rH, prevK = this.renderScale;
    this.calcLayout();
    if (!force && prevRW === this.rW && prevRH === this.rH && prevK === this.renderScale) {
      this.display.fit(this.displayScale);
      return;
    }
    this.display.resize(this.rW, this.rH, this.displayScale, this.renderScale);
    this.buildGfx();
    this.world.W = this.W; this.world.H = this.H;
    for (const e of this.world.enemies) { e.x = clamp(e.x, 10, this.W - 10); e.y = clamp(e.y, 10, this.H - 10); }
    this.world.player.x = clamp(this.world.player.x, 10, this.W - 10); this.world.player.y = clamp(this.world.player.y, 10, this.H - 10);
  }

  destroy() {
    this.destroyed = true; cancelAnimationFrame(this.raf); this.ro?.disconnect();
    for (const f of this.cleanup) f();
    try { if (this.display.app) this.display.destroy(); } catch { /* noop */ }
  }

  // ---------- input ----------
  slotKeys() { return ['Q', this.wasd ? 'Z' : 'W', 'E']; }
  toWorld(cx: number, cy: number) {
    const r = this.display.app.canvas.getBoundingClientRect();
    return { x: ((cx - r.left) * this.W) / r.width, y: ((cy - r.top) * this.H) / r.height };
  }
  bind() {
    const cv = this.display.app.canvas, on = (t: EventTarget, n: string, f: (e: never) => void, o?: AddEventListenerOptions) => { t.addEventListener(n, f as EventListener, o); this.cleanup.push(() => t.removeEventListener(n, f as EventListener)); };
    on(cv, 'contextmenu', ((e: Event) => e.preventDefault()) as never);
    on(cv, 'pointermove', ((e: PointerEvent) => { const m = this.toWorld(e.clientX, e.clientY); this.mouse.x = m.x; this.mouse.y = m.y; this.mouse.over = true; this.dragSample(); }) as never);
    on(cv, 'pointerleave', (() => { this.mouse.over = false; }) as never);
    on(cv, 'pointerdown', ((e: PointerEvent) => {
      const m = this.toWorld(e.clientX, e.clientY); this.mouse.x = m.x; this.mouse.y = m.y;
      if (e.button === 2) { if (this.aim) { this.aim = null; this.dragPts = []; } else this.moveTo(m.x, m.y); }
      else if (e.button === 0) { this.mouseDown = true; if (this.aim?.def.id === 20 && !this.dragPts.length) this.dragPts = []; }
    }) as never);
    on(window, 'pointerup', ((e: PointerEvent) => { if (e.button === 0) this.mouseDown = false; }) as never);
    on(window, 'blur', (() => { this.aim = null; this.keys.clear(); }) as never);
    on(window, 'keydown', ((e: KeyboardEvent) => this.keyDown(e)) as never);
    on(window, 'keyup', ((e: KeyboardEvent) => this.keyUp(e)) as never);
  }
  isTyping(e: KeyboardEvent) { const t = e.target as HTMLElement | null; return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable); }
  slotOf(k: string): number | 'R' | 'F' | null {
    if (k === 'q') return 0; if (k === 'e') return 2; if (k === 'r') return 'R'; if (k === 'f') return 'F';
    if (!this.wasd && k === 'w') return 1; if (this.wasd && k === 'z') return 1;
    return null;
  }
  defOf(slot: number | 'R' | 'F'): SkillDef | null {
    const f = this.world.player.form;
    if (slot === 'R') return SKILL_BY_ID[ULT[f]];
    if (slot === 'F') return SKILL_BY_ID[11];
    const id = this.loadout[f][slot]; return id ? SKILL_BY_ID[id] : null;
  }
  keyDown(e: KeyboardEvent) {
    if (this.isTyping(e) || e.ctrlKey || e.metaKey) return;
    const k = e.key.toLowerCase();
    if (e.key === 'Escape') { this.aim = null; this.dragPts = []; return; }
    if (k === ' ') { e.preventDefault(); this.paused = !this.paused; return; }
    if (k === 'tab') { e.preventDefault(); this.toggleForm(); return; }
    if (k === 'n' || k === '.') { this.paused = true; this.stepReq++; return; }
    if (k === 't') { this.slowIdx = (this.slowIdx + 1) % SLOW.length; return; }
    if (k === 'enter') { this.replayLast(); return; }
    if (this.keys.has(k) && !['arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) return;
    this.keys.add(k);
    this.syncMove();
    const slot = this.slotOf(k);
    if (slot === null) return;
    e.preventDefault();
    this.beginAim(slot, k);
  }
  keyUp(e: KeyboardEvent) {
    const k = e.key.toLowerCase(); this.keys.delete(k); this.syncMove();
    if (this.aim && this.aim.src === 'key' && this.aim.key === k) this.fireAim();
  }
  syncMove() {
    const K = this.keys, up = K.has('arrowup') || (this.wasd && K.has('w')), dn = K.has('arrowdown') || K.has('s'), lf = K.has('arrowleft') || K.has('a'), rt = K.has('arrowright') || K.has('d');
    const w = this.world; if (!w) return;
    w.input.x = (rt ? 1 : 0) - (lf ? 1 : 0); w.input.y = (dn ? 1 : 0) - (up ? 1 : 0);
    if (w.input.x || w.input.y) this.manual();
  }
  moveTo(x: number, y: number) {
    this.manual();
    const w = this.world; w.player.mt = { x: clamp(x, 8, this.W - 8), y: clamp(y, 10, this.H - 8) };
    const mx = w.player.mt.x, my = w.player.mt.y;
    w.add(new Custom(mx, my, 0.5, { gnd: (g, a) => { const L = g.s, r = 8 - a * 6; L.dl = Math.round(14 * (1 - a)); L.ring(mx, my, r, 1, P.c2); L.rect(mx - 1, my, 3, 1, P.c3); L.dl = 16; } }));
  }
  manual() { if (this.stage) { this.stage = null; this.showcase.on = false; } }
  toggleForm() {
    const p = this.world.player; this.manual();
    if (p.form === 'vessel') { p.form = 'venom'; p.venomT = 14; this.toast('Venomcraft · 14s'); } else { p.form = 'vessel'; p.venomT = 0; this.toast('Vesselcraft'); }
    this.aim = null;
    this.world.add(new Custom(p.x, p.y, 0.5, { gnd: (g, a) => { g.s.dl = Math.round(14 * (1 - a)); g.s.ring(p.x, p.y, 6 + a * 30, 2, p.form === 'venom' ? P.c1 : P.v2); g.s.dl = 16; }, lit: (g, a) => { g.l.add = true; g.l.a = 90 * (1 - a) | 0; g.l.disc(p.x, p.y, 10 + a * 20, p.form === 'venom' ? P.c1 : P.v2); g.l.add = false; g.l.a = 255; } }));
  }
  toast(m: string) { this.toastFn(m); }
  dragSample() {
    if (!this.aim || this.aim.def.id !== 20 || !this.mouseDown) return;
    const p = this.world.player, last = this.dragPts[this.dragPts.length - 1] ?? { x: p.x, y: p.y };
    if (Math.hypot(this.mouse.x - last.x, this.mouse.y - last.y) > 26 && this.dragPts.length < 6) { const l = this.routeLen(this.dragPts.concat([{ x: this.mouse.x, y: this.mouse.y }])); if (l <= this.aim.def.aim.range) this.dragPts.push({ x: this.mouse.x, y: this.mouse.y }); }
  }
  routeLen(r: { x: number; y: number }[]) { const p = this.world.player; let l = 0, px = p.x, py = p.y; for (const q of r) { l += Math.hypot(q.x - px, q.y - py); px = q.x; py = q.y; } return l; }

  // ---------- casting ----------
  ready(def: SkillDef) { return (this.cd[def.id] ?? 0) <= 0; }
  beginAim(slot: number | 'R' | 'F', key: string) {
    const def = this.defOf(slot); if (!def) return;
    const p = this.world.player;
    if (def.id === 11) {
      if (p.form === 'venom') { this.toast('Venomcraft is already active'); return; }
      if (!this.ready(def)) { this.toast('Unsealed Catalyst cooling down'); return; }
      if (p.cat < 100) { this.toast(`Requires 100 Catalyst (${Math.floor(p.cat)})`); return; }
      this.manual(); this.cast(def, this.resolve(def, p.x, p.y), false); return;
    }
    if (!this.ready(def)) { this.toast(`${def.name} on cooldown · ${this.cd[def.id].toFixed(1)}s`); return; }
    if (this.quick) { const r = this.resolve(def, this.mouse.x, this.mouse.y); this.manual(); this.cast(def, r, false); return; }
    this.aim = { def, src: 'key', key }; this.dragPts = [];
  }
  fireAim() {
    const a = this.aim; if (!a) return;
    const r = this.resolve(a.def, this.mouse.x, this.mouse.y);
    this.aim = null;
    if (a.src === 'key') { this.manual(); this.cast(a.def, r, false); }
    this.dragPts = [];
  }
  resolve(def: SkillDef, mx: number, my: number): Resolved {
    const w = this.world, p = w.player, ai = def.aim;
    const dx = mx - p.x, dy = my - p.y, d = Math.hypot(dx, dy) || 1, ang = Math.atan2(dy, dx), dd = Math.min(d, ai.range);
    const r: Resolved = { ang, tx: p.x + (dx / d) * dd, ty: p.y + (dy / d) * dd, target: null, targets: [], route: [], ok: true };
    const alive = w.enemies.filter(e => e.dying <= 0);
    if (ai.kind === 'target') {
      let best: Enemy | null = null, bd = 1e9;
      for (const e of alive) { const dm = Math.hypot(e.x - mx, e.y - my) - e.r; if (dm < bd && dm < 26) { bd = dm; best = e; } }
      if (best && Math.hypot(best.x - p.x, best.y - p.y) - best.r > ai.range + 4) best = null;
      r.target = best; r.ok = !!best;
    } else if (ai.kind === 'multi') {
      r.targets = alive.filter(e => Math.hypot(e.x - p.x, e.y - p.y) - e.r < ai.range).sort((a, b) => Math.hypot(a.x - mx, a.y - my) - Math.hypot(b.x - mx, b.y - my)).slice(0, ai.n ?? 3);
      r.ok = r.targets.length > 0;
    } else if (ai.kind === 'dir' || ai.kind === 'path' || ai.kind === 'cone') { r.tx = p.x + Math.cos(ang) * ai.range; r.ty = p.y + Math.sin(ang) * ai.range; }
    else if (ai.kind === 'drag') { r.route = this.dragPts.slice(); r.tx = mx; r.ty = my; }
    else if (ai.kind === 'self') { r.tx = p.x; r.ty = p.y; }
    return r;
  }
  autoAim(def: SkillDef): Resolved {
    const w = this.world, p = w.player, alive = w.enemies.filter(e => e.dying <= 0);
    let cx = p.x + 120, cy = p.y;
    if (alive.length) {
      let bn = -1, bi = 0;
      alive.forEach((e, i) => { let n = 0; for (const o of alive) if (Math.hypot(o.x - e.x, o.y - e.y) < 55) n++; if (n > bn) { bn = n; bi = i; } });
      const c0 = alive[bi]; let sx = 0, sy = 0, n = 0;
      for (const o of alive) if (Math.hypot(o.x - c0.x, o.y - c0.y) < 55) { sx += o.x; sy += o.y; n++; }
      cx = sx / n; cy = sy / n;
    }
    const dist = Math.hypot(cx - p.x, cy - p.y);
    if (def.aim.kind === 'ground' && dist > def.aim.range) { const k = def.aim.range / dist; cx = p.x + (cx - p.x) * k; cy = p.y + (cy - p.y) * k; }
    return this.resolve(def, cx, cy);
  }
  castSlotAuto(slot: number | 'R' | 'F') {
    const def = this.defOf(slot); if (!def) return;
    if (def.id === 11) { this.beginAim('F', 'f'); return; }
    if (!this.ready(def)) { this.toast(`${def.name} on cooldown · ${this.cd[def.id].toFixed(1)}s`); return; }
    this.manual(); this.cast(def, this.autoAim(def), false);
  }
  castTest(id: number) { const def = SKILL_BY_ID[id]; this.manual(); this.cast(def, this.autoAim(def), true); }
  cast(def: SkillDef, r: Resolved, test: boolean) {
    const w = this.world, p = w.player;
    if (!r.ok && def.aim.kind === 'target') { this.toast('No target under cursor'); return false; }
    if (!r.ok && def.aim.kind === 'multi') { this.toast('No targets in range'); return false; }
    const id = w.uid++;
    const rng = new Rng((w.seed * 1315423911 + id * 2654435761 + def.id * 97) >>> 0);
    const c: Cast = { w, id, def, ox: p.x, oy: p.y, ang: r.ang, tx: r.tx, ty: r.ty, target: r.target, targets: r.targets, route: r.route, rng, d: (pct: number) => (ATK * pct) / 100, dx: Math.cos(r.ang), dy: Math.sin(r.ang) };
    p.face = r.ang; p.cast = def.cast + 0.15; p.castMax = p.cast;
    w.run(def.run(c), def.name);
    w.castLog.push({ t: w.time, id: def.id });
    this.lastCastId = def.id;
    if (!test) this.cd[def.id] = def.cd;
    return true;
  }

  // ---------- loadouts ----------
  equip(slot: number, id: number): boolean {
    const def = SKILL_BY_ID[id];
    if (def.slot !== 'basic') { this.toast(def.slot === 'ult' ? 'Ultimates are bound to R automatically' : 'Catalyst is bound to F'); return false; }
    const form = this.world.player.form;
    if (def.form !== form) { this.toast(`${def.name} belongs to ${def.form === 'vessel' ? 'Vesselcraft' : 'Venomcraft'} — switch form (Tab / F)`); return false; }
    const lo = this.loadout[form], prev = lo.indexOf(id);
    if (prev >= 0 && prev !== slot) lo[prev] = lo[slot];
    lo[slot] = id; return true;
  }
  swapSlots(a: number, b: number) { const lo = this.loadout[this.world.player.form]; [lo[a], lo[b]] = [lo[b], lo[a]]; }
  clearSlot(a: number) { this.loadout[this.world.player.form][a] = null; }

  // UI drag from library
  uiDragOver(id: number, cx: number, cy: number) {
    const m = this.toWorld(cx, cy); this.mouse.x = m.x; this.mouse.y = m.y; this.mouse.over = true;
    this.aim = { def: SKILL_BY_ID[id], src: 'drag', key: '' };
  }
  uiDragEnd() { if (this.aim?.src === 'drag') this.aim = null; this.mouse.over = false; }
  uiDrop(id: number, cx: number, cy: number) {
    const m = this.toWorld(cx, cy); this.mouse.x = m.x; this.mouse.y = m.y;
    const def = SKILL_BY_ID[id]; this.aim = null; this.manual();
    this.cast(def, this.resolve(def, m.x, m.y), true);
  }

  // ---------- arena controls ----------
  resetArena() {
    this.manual(); const w = this.world; w.reset(Math.floor(Math.random() * 1e6)); w.stats = { total: 0, kills: 0, hits: 0, ev: [] }; w.player.cat = 0; this.cd = {}; this.aim = null;
  }
  setDensity(n: number) { this.world.cfg.density = n; const w = this.world; w.enemies = w.enemies.filter(e => e.kind === 'boss'); w.respawnQ.length = 0; w.fillEnemies(false); }
  setBoss(on: boolean) { this.world.setBoss(on); }
  setWave(on: boolean) { this.world.cfg.wave = on; }
  setRespawn(on: boolean) { this.world.cfg.respawn = on; }
  clearEnemies() { this.world.killAll(); }
  fillCatalyst() { this.world.player.cat = 100; }
  togglePause() { this.paused = !this.paused; }
  cycleSlow() { this.slowIdx = (this.slowIdx + 1) % SLOW.length; }
  step(n = 1) { this.paused = true; this.stepReq += n; }

  // ---------- deterministic stage / replay / showcase ----------
  startStage(id: number, seed = 7, auto = true) {
    const def = SKILL_BY_ID[id], w = this.world;
    resetIds(); w.uid = 1; w.reset(seed, true); w.lab = true;
    w.stats = { total: 0, kills: 0, hits: 0, ev: [] };
    const p = w.player; p.form = def.form === 'venom' ? 'venom' : 'vessel'; p.venomT = 999; p.cat = 100; if (def.form !== 'venom') p.venomT = 0;
    this.aim = null; this.dragPts = [];
    this.stage = { n: 0, id, seed, castN: 18, manual: false }; if (!auto) this.stage.castN = -1;
    this.lastCastId = id;
  }
  replayLast() { const id = this.stage?.id ?? this.lastCastId; if (id) { this.showcase.on = false; this.startStage(id); this.paused = false; } }
  seek(n: number) {
    if (!this.stage) return; const { id, seed } = this.stage; this.startStage(id, seed);
    const wasPaused = this.paused; for (let i = 0; i < n; i++) this.simStep(); this.paused = wasPaused;
  }
  startShowcase() { this.showcase = { on: true, idx: 0, t: 0 }; this.startShow(); }
  startShow() { const def = SKILLS[this.showcase.idx]; this.startStage(def.id, 7); this.showcase.t = def.dur + 0.6; this.paused = false; }
  stopShowcase() { this.showcase.on = false; }
  nextShow(d = 1) { if (!this.showcase.on) return; this.showcase.idx = (this.showcase.idx + d + SKILLS.length) % SKILLS.length; this.startShow(); }

  // ---------- loop ----------
  frame(now: number) {
    const dtReal = Math.min(0.05, (now - this.last) / 1000); this.last = now;
    if (!this.paused) this.acc += dtReal * SLOW[this.slowIdx];
    let guard = 0;
    while (this.acc >= F && guard++ < 6) { this.simStep(); this.acc -= F; }
    while (this.stepReq > 0) { this.simStep(); this.stepReq--; }
    this.render();
  }
  simStep() {
    const w = this.world, p = w.player;
    w.step(F);
    for (const k in this.cd) { this.cd[k] = Math.max(0, this.cd[k] - F); }
    if (p.form === 'vessel' && (this.cd[11] ?? 0) > 35 && w.time - w.formEnded < 0.1) this.cd[11] = 35;
    if (this.stage) {
      this.stage.n++;
      if (this.stage.n === this.stage.castN) { const def = SKILL_BY_ID[this.stage.id]; this.cast(def, this.autoAim(def), true); }
      if (this.showcase.on) { this.showcase.t -= F; if (this.showcase.t <= 0) { this.showcase.idx = (this.showcase.idx + 1) % SKILLS.length; this.startShow(); } }
    }
  }
  snapshot(): Snapshot {
    const w = this.world, p = w.player;
    let poisoned = 0, pm = 0, alive = 0;
    for (const e of w.enemies) { if (e.dying > 0) continue; alive++; if (e.poison.length) { poisoned++; pm = Math.max(pm, e.poisonLeft); } }
    return {
      form: p.form, cat: p.cat, venomT: p.venomT, hp: p.hp, maxHp: p.maxHp, kills: w.stats.kills, dps: w.dps(), total: w.stats.total, alive, poisoned, poisonMax: pm,
      quick: this.quick, paused: this.paused, slow: SLOW[this.slowIdx], wasd: this.wasd, density: w.cfg.density, boss: w.cfg.boss, wave: w.cfg.wave, respawn: w.cfg.respawn,
      quality: this.quality, renderScale: this.renderScale,
      cds: { ...this.cd }, loadout: { vessel: [...this.loadout.vessel], venom: [...this.loadout.venom] }, slotKeys: this.slotKeys(), aim: this.aim ? { id: this.aim.def.id, key: this.aim.key } : null,
      stage: this.stage ? { n: this.stage.n, id: this.stage.id } : null, showcase: this.showcase.on ? { on: true, id: SKILLS[this.showcase.idx].id } : null,
      frame: w.frame, seed: w.seed, hits: w.stats.hits, time: w.time, lastCastId: this.lastCastId, catFull: p.cat >= 100, formLeft: p.form === 'venom' ? p.venomT : 0,
    };
  }

  // ---------- render ----------
  render() {
    const g = this.gfx, w = this.world, d = this.display;
    g.s.d.set(this.ground); g.l.d.fill(0xff000000); g.s.reset(); g.l.reset();
    for (const e of w.enemies) e.hover = false;
    if (this.aim) { const r = this.resolve(this.aim.def, this.mouse.x, this.mouse.y); if (r.target) r.target.hover = true; for (const e of r.targets) e.hover = true; }
    w.overlay = this.aim ? (gg: Gfx) => this.drawAim(gg) : null;
    w.draw(g);
    if (this.mouse.over) {
      const x = this.mouse.x, y = this.mouse.y, L = g.s;
      L.dot(x, y - 3, P.i0); L.dot(x, y + 3, P.i0); L.dot(x - 3, y, P.i0); L.dot(x + 3, y, P.i0); L.dot(x, y, P.g2);
    }
    if (this.stage && this.paused) {
      const L = g.s, s = `F${this.stage.n}`;
      text(L, 8, 8, s, P.g2, P.bk, 1);
    }
    d.present(w.time, w.shakeOff(), w.shockArr(), w.flashArr(), w.grade());
  }

  drawAim(g: Gfx) {
    const a = this.aim!, def = a.def, ai = def.aim, w = this.world, p = w.player, L = g.s, t = w.time;
    const r = this.resolve(def, this.mouse.x, this.mouse.y), pulse = 0.5 + 0.5 * Math.sin(t * 8);
    const col = r.ok ? P.c2 : P.r3, col2 = P.g2;
    const px = p.x, py = p.y;
    const dotted = (x0: number, y0: number, x1: number, y1: number, c: number) => {
      const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 3.5);
      for (let i = 0; i <= n; i += 2) L.dot(x0 + ((x1 - x0) * i) / n, y0 + ((y1 - y0) * i) / n, c);
    };
    if (ai.kind !== 'self') {
      L.dl = 7; L.ring(px, py, ai.range, 1, col2); L.dl = 16;
      for (let i = 0; i < 4; i++) { const an = (i / 4) * TAU + t * 0.3; L.dot(p.x + Math.cos(an) * ai.range, p.y + Math.sin(an) * ai.range, P.w); }
    }
    const ca = Math.cos(r.ang), sa = Math.sin(r.ang);
    switch (ai.kind) {
      case 'self': L.dl = 8; L.ring(px, py, 18 + pulse * 3, 1, col); L.dl = 16; break;
      case 'ground': {
        const rad = ai.radius ?? 40;
        L.dl = 3; L.disc(r.tx, r.ty, rad, col);
        L.dl = 12; L.ring(r.tx, r.ty, rad, 1, col);
        L.dl = 16; L.ring(r.tx, r.ty, rad * (0.55 + pulse * 0.05), 1, col2);
        L.dot(r.tx, r.ty, P.w); L.dot(r.tx + 2, r.ty, col2); L.dot(r.tx - 2, r.ty, col2); L.dot(r.tx, r.ty + 2, col2); L.dot(r.tx, r.ty - 2, col2);
        dotted(p.x, p.y, r.tx, r.ty, col2); break;
      }
      case 'dir': case 'path': {
        const hw = (ai.width ?? 24) / 2, nx = -sa * hw, ny = ca * hw, x1 = p.x + ca * ai.range, y1 = p.y + sa * ai.range;
        L.dl = 3; L.poly([p.x + nx, p.y + ny, x1 + nx, y1 + ny, x1 - nx, y1 - ny, p.x - nx, p.y - ny], col); L.dl = 16;
        dotted(p.x + nx, p.y + ny, x1 + nx, y1 + ny, col); dotted(p.x - nx, p.y - ny, x1 - nx, y1 - ny, col);
        L.line(x1 + nx, y1 + ny, x1 - nx, y1 - ny, col2, 1.2);
        if (ai.kind === 'path') {
          let pxx = p.x, pyy = p.y;
          for (let i = 1; i <= 20; i++) {
            const u = i / 20, off = Math.sin(u * Math.PI * 2) * 22;
            const qx = p.x + ca * ai.range * u - sa * off, qy = p.y + sa * ai.range * u + ca * off;
            if (i % 2) L.line(pxx, pyy, qx, qy, col2);
            pxx = qx; pyy = qy;
          }
        }
        break;
      }
      case 'cone': {
        const half = (ai.angle ?? 1) / 2;
        for (let k = 0; k <= 20; k++) { const an = r.ang - half + (k / 20) * half * 2; L.dl = 3; L.line(p.x, p.y, p.x + Math.cos(an) * ai.range, p.y + Math.sin(an) * ai.range, col); }
        L.dl = 16; L.line(p.x, p.y, p.x + Math.cos(r.ang - half) * ai.range, p.y + Math.sin(r.ang - half) * ai.range, col2); L.line(p.x, p.y, p.x + Math.cos(r.ang + half) * ai.range, p.y + Math.sin(r.ang + half) * ai.range, col2);
        L.arc(p.x, p.y, ai.range, 1, r.ang - half, r.ang + half, col2); break;
      }
      case 'target': case 'multi': {
        const list = ai.kind === 'target' ? (r.target ? [r.target] : []) : r.targets;
        list.forEach((e, i) => {
          dotted(p.x, p.y - 4, e.x, e.y - 4, col);
          L.ring(e.x, e.y + 1, e.r + 3 + pulse, 1.2, col2);
          if (ai.kind === 'multi') text(L, e.x - 1, e.y - e.r - 14, String(i + 1), P.g2, P.bk);
        });
        if (!list.length) {
          const x = this.mouse.x, y = this.mouse.y;
          L.line(x - 3, y - 3, x + 3, y + 3, P.r3); L.line(x - 3, y + 3, x + 3, y - 3, P.r3);
        }
        break;
      }
      case 'drag': {
        let pxx = p.x, pyy = p.y; const pts = a.src === 'key' ? this.dragPts : [];
        pts.forEach((q, i) => {
          L.line(pxx, pyy, q.x, q.y, col2, 1.2);
          L.disc(q.x, q.y, 2.5, P.c2);
          text(L, q.x + 3, q.y - 7, String(i + 1), P.g2, P.bk);
          pxx = q.x; pyy = q.y;
        });
        const used = this.routeLen(pts); dotted(pxx, pyy, this.mouse.x, this.mouse.y, col);
        const left = Math.max(0, ai.range - used);
        L.rect(px - 12, py + 12, 24, 2.5, P.bk);
        L.rect(px - 11, py + 12, (22 * left) / ai.range, 1.5, left > 20 ? P.c2 : P.r3);
        if (!pts.length) text(L, px - 26, py + 17, 'DRAG TO DRAW', P.g2, P.bk);
        break;
      }
    }
  }
}
