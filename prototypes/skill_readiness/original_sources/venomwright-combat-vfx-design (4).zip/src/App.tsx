import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, SLOW, type QualityMode, type Snapshot } from './game/engine';
import { SKILLS, SKILL_BY_ID, TIER_NAME, ULT } from './game/skills';
import { iconURL } from './game/icons';

type From = { kind: 'lib' } | { kind: 'slot'; idx: number };
interface DragState { id: number; from: From; sx: number; sy: number; active: boolean }
const AIM_LABEL: Record<string, string> = { target: 'Target lock', multi: 'Multi-target lock', ground: 'Ground-targeted', cone: 'Directional cone', dir: 'Directional', path: 'Movement path', drag: 'Drag-defined path', self: 'Self-cast' };
const TIER_COL = ['', '#7fe0e8', '#b6f03a', '#f6df7a', '#ff7fd8'];
const num = (id: number) => String(id).padStart(2, '0');
const fmt = (v: number) => (v >= 10 ? Math.ceil(v) + '' : v.toFixed(1));

function Icon({ id, size = 48, dim = false }: { id: number; size?: number; dim?: boolean }) {
  return <img className="px-img block" draggable={false} src={iconURL(id)} width={size} height={size} style={{ width: size, height: size, opacity: dim ? 0.62 : 1, filter: dim ? 'grayscale(.45)' : undefined }} alt="" />;
}

function Tooltip({ id, x, y }: { id: number; x: number; y: number }) {
  const d = SKILL_BY_ID[id], ai = d.aim;
  const left = Math.min(x + 18, window.innerWidth - 380), top = Math.max(8, Math.min(y - 20, window.innerHeight - 380));
  return (
    <div className="panel ui-scalable fixed z-50 w-[320px] p-3.5 pointer-events-none" style={{ left, top }}>
      <div className="flex items-start gap-2.5">
        <Icon id={id} size={46} />
        <div className="min-w-0 flex-1">
          <div className="text-[13.5px] font-bold leading-tight text-[#eaffb0]">{num(id)} · {d.name}</div>
          <div className="text-[10.5px] text-[#8fd4a0]">{d.sub}</div>
          <div className="mt-1 flex flex-wrap gap-1 text-[9.5px] uppercase tracking-wider">
            <span className="px-1.5 py-[0.5px] border" style={{ borderColor: TIER_COL[d.tier], color: TIER_COL[d.tier] }}>{TIER_NAME[d.tier]}</span>
            <span className="px-1.5 py-[0.5px] border border-[#2a6a50] text-[#9fe0b0]">{d.form === 'vessel' ? 'Vesselcraft' : d.form === 'venom' ? 'Venomcraft' : 'Transformation'}</span>
            <span className="px-1.5 py-[0.5px] border border-[#5a4a2a] text-[#f0d890]">{d.slot === 'ult' ? 'R · ultimate' : d.slot === 'trans' ? 'F' : 'Q/W/E'}</span>
          </div>
        </div>
      </div>
      <div className="mt-2.5 grid grid-cols-3 gap-x-2 gap-y-1.5 text-[10.5px]">
        <Stat k="Targeting" v={AIM_LABEL[ai.kind]} /><Stat k="Range" v={ai.kind === 'self' ? '—' : `${(ai.range / 20).toFixed(1)} m`} /><Stat k={ai.radius ? 'Radius' : ai.width ? 'Width' : ai.angle ? 'Cone' : 'Area'} v={ai.radius ? `${(ai.radius / 20).toFixed(1)} m` : ai.width ? `${(ai.width / 20).toFixed(1)} m` : ai.angle ? `${Math.round((ai.angle * 180) / Math.PI)}°` : '—'} />
        <Stat k="Cast time" v={`${d.cast.toFixed(2)}s`} /><Stat k="First hit" v={`${d.first.toFixed(2)}s`} /><Stat k="Cooldown" v={`${d.cd}s`} />
      </div>
      <div className="mt-2 border-t border-[#1c4a38] pt-2 text-[10.5px]"><span className="text-[#b6f03a] font-bold">{d.total}% ATK</span> <span className="text-[#8fb8a0]">max single-target (ATK 100 → {d.total} dmg)</span></div>
      <div className="mt-1 text-[10px] text-[#c9bd98] font-mono">{d.hits}</div>
      <div className="mt-2 text-[11px] leading-snug text-[#c6e6cf]">{d.desc}</div>
    </div>
  );
}
const Stat = ({ k, v }: { k: string; v: string }) => <div><div className="text-[8.5px] uppercase tracking-wider text-[#5f9a80]">{k}</div><div className="text-[#e6f7dc] font-medium">{v}</div></div>;

function Bar({ v, max, col, h = 8, label }: { v: number; max: number; col: string; h?: number; label?: string }) {
  return (
    <div className="relative" style={{ height: h + 2 }}>
      <div className="absolute inset-0 bg-[#02080a] border border-[#1c4a38]" />
      <div className="absolute left-[1px] top-[1px] bottom-[1px]" style={{ width: `calc(${Math.max(0, Math.min(1, v / max)) * 100}% - 2px)`, background: col }} />
      {label && <div className="absolute inset-0 flex items-center justify-center text-[8.5px] font-bold text-white tracking-wide" style={{ textShadow: '0 0 2px #000, 0 0 2px #000' }}>{label}</div>}
    </div>
  );
}

export default function App() {
  const host = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [tip, setTip] = useState<{ id: number; x: number; y: number } | null>(null);
  const [toast, setToast] = useState<{ m: string; k: number } | null>(null);
  const [dragView, setDragView] = useState<{ id: number; x: number; y: number } | null>(null);
  const [tab, setTab] = useState<'all' | 'vessel' | 'venom'>('all');
  const [libOpen, setLibOpen] = useState(true), [ctlOpen, setCtlOpen] = useState(true), [help, setHelp] = useState(false);
  const dragRef = useRef<DragState | null>(null);
  const toastT = useRef(0);

  useEffect(() => {
    const g = new Game(); gameRef.current = g; (window as unknown as { __game: Game; __defs: unknown }).__game = g; (window as unknown as { __defs: unknown }).__defs = SKILL_BY_ID;
    g.toastFn = (m) => { setToast({ m, k: Math.random() }); clearTimeout(toastT.current); toastT.current = window.setTimeout(() => setToast(null), 2200); };
    g.init(host.current!).catch(e => console.error(e));
    const iv = window.setInterval(() => { if (g.world) setSnap(g.snapshot()); }, 80);
    return () => { clearInterval(iv); g.destroy(); };
  }, []);

  useEffect(() => {
    const move = (e: PointerEvent) => {
      const d = dragRef.current; if (!d) return;
      if (!d.active && Math.hypot(e.clientX - d.sx, e.clientY - d.sy) > 5) d.active = true;
      if (d.active) {
        setDragView({ id: d.id, x: e.clientX, y: e.clientY });
        const el = document.elementFromPoint(e.clientX, e.clientY);
        if (el?.closest('[data-arena]')) gameRef.current?.uiDragOver(d.id, e.clientX, e.clientY); else gameRef.current?.uiDragEnd();
      }
    };
    const up = (e: PointerEvent) => {
      const d = dragRef.current; dragRef.current = null; if (!d) return;
      setDragView(null);
      const g = gameRef.current; if (!g) return;
      if (!d.active) return;
      const el = document.elementFromPoint(e.clientX, e.clientY), slotEl = el?.closest('[data-slot]') as HTMLElement | null;
      if (slotEl) { const idx = Number(slotEl.dataset.slot); if (d.from.kind === 'slot') { if (d.from.idx !== idx) g.swapSlots(d.from.idx, idx); } else g.equip(idx, d.id); }
      else if (el?.closest('[data-arena]')) g.uiDrop(d.id, e.clientX, e.clientY);
      else if (d.from.kind === 'slot' && el?.closest('[data-lib]')) g.clearSlot(d.from.idx);
      g.uiDragEnd();
    };
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
  }, []);

  const startDrag = useCallback((e: React.PointerEvent, id: number, from: From) => {
    if (e.button !== 0) return; dragRef.current = { id, from, sx: e.clientX, sy: e.clientY, active: false }; setTip(null);
  }, []);
  const g = () => gameRef.current!;
  const S = snap;
  const tipOn = (id: number) => (e: React.MouseEvent) => { if (!dragRef.current) setTip({ id, x: e.clientX, y: e.clientY }); };

  const slotBox = (label: string, id: number | null, idx: number | 'R' | 'F', aimKey: string) => {
    const def = id ? SKILL_BY_ID[id] : null, rem = def && S ? S.cds[def.id] ?? 0 : 0, frac = def ? Math.min(1, rem / def.cd) : 0;
    const isF = idx === 'F', droppable = typeof idx === 'number';
    const aiming = !!S?.aim && S.aim.key === aimKey.toLowerCase() && S.aim.id === id;
    const venom = S?.form === 'venom';
    const fReady = isF && S && !venom && S.catFull && rem <= 0;
    return (
      <div key={label} {...(droppable ? { 'data-slot': idx } : {})} className={`relative h-[60px] w-[60px] ${droppable ? '' : 'h-[54px] w-[54px]'} border bg-[#050d0b] ${aiming ? 'aiming' : ''}`}
        style={{ borderColor: aiming ? '#b6f03a' : fReady ? '#b6f03a' : def ? '#2a7a58' : '#1c3a30', borderStyle: def ? 'solid' : 'dashed', boxShadow: fReady ? '0 0 12px rgba(182,240,58,.6)' : undefined }}
        onMouseEnter={def ? tipOn(def.id) : undefined} onMouseMove={def ? tipOn(def.id) : undefined} onMouseLeave={() => setTip(null)}
        onPointerDown={def && droppable ? (e) => startDrag(e, def.id, { kind: 'slot', idx: idx as number }) : undefined}
        onClick={def && !dragRef.current?.active ? () => g().castSlotAuto(idx) : undefined}>
        {def ? <div className="m-[2px]"><Icon id={def.id} size={typeof idx === 'number' ? 54 : 48} dim={rem > 0} /></div> : <div className="flex h-full items-center justify-center text-[8.5px] text-[#3a6a55] uppercase text-center leading-tight">drop<br />skill</div>}
        <div className="absolute left-0 top-0 bg-[#02080a] px-[3.5px] text-[10.5px] font-bold text-[#eaffb0] border-r border-b border-[#1c4a38]">{label}</div>
        {def && frac > 0 && <div className="absolute inset-x-[2px] bottom-[2px]" style={{ height: `${frac * 100}%`, background: 'rgba(2,8,10,.72)' }} />}
        {def && rem > 0 && <div className="absolute inset-0 flex items-center justify-center text-[13.5px] font-bold text-white" style={{ textShadow: '0 0 3px #000, 1px 1px 0 #000' }}>{fmt(rem)}</div>}
        {isF && venom && <div className="absolute inset-0 flex items-center justify-center text-[10.5px] font-bold text-[#b6f03a]" style={{ textShadow: '0 0 3px #000' }}>{fmt(S!.formLeft)}s</div>}
        {isF && !venom && rem <= 0 && S && !S.catFull && <div className="absolute inset-x-0 bottom-0 bg-[#02080a]/85 text-center text-[8.5px] font-semibold text-[#9fc]">{Math.floor(S.cat)}/100</div>}
        {def && <div className="absolute right-0 bottom-0 bg-[#02080a]/85 px-[2.5px] text-[8.5px] font-semibold" style={{ color: TIER_COL[def.tier] }}>T{def.tier}</div>}
      </div>
    );
  };

  const form = S?.form ?? 'vessel';
  const lo = S?.loadout[form] ?? [null, null, null];
  const keys = S?.slotKeys ?? ['Q', 'W', 'E'];
  const libList = SKILLS.filter(s => tab === 'all' || (tab === 'vessel' ? s.form === 'vessel' : s.form !== 'vessel'));
  const D = [8, 16, 32, 48];
  const QMODES: { k: QualityMode; l: string }[] = [
    { k: 'ultra', l: 'Ultra 2×' },
    { k: 'high', l: 'High 1.5×' },
    { k: 'classic', l: 'Classic 1×' },
    { k: 'auto', l: 'Auto' },
  ];
  const tb = (on: boolean | undefined, label: string, fn: () => void, cls = '') => <button className={`btn ${on ? 'on' : ''} ${cls}`} onClick={fn}>{label}</button>;

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#04070a]">
      <div ref={host} data-arena className="absolute inset-0 overflow-hidden" />

      {/* top HUD */}
      <div className="pointer-events-none ui-scalable absolute left-3 top-3 flex items-stretch gap-2.5">
        <div className="panel pointer-events-auto w-[246px] p-2.5">
          <div className="flex items-center justify-between">
            <div className="text-[12px] font-bold tracking-[.14em] text-[#eaffb0]">THE VENOMWRIGHT</div>
            <div className="px-2 py-[1.5px] text-[9.5px] font-bold uppercase tracking-wider" style={{ background: form === 'venom' ? '#2f6a10' : '#10405a', color: form === 'venom' ? '#eaffb0' : '#bff0ff', border: `1px solid ${form === 'venom' ? '#b6f03a' : '#4fb7c9'}` }}>{form === 'venom' ? 'Venomcraft' : 'Vesselcraft'}</div>
          </div>
          <div className="mt-2 space-y-1.5">
            <Bar v={S?.hp ?? 0} max={S?.maxHp ?? 1} col="linear-gradient(#e0603a,#a8301a)" label={`HP ${Math.floor(S?.hp ?? 0)}`} h={8} />
            {form === 'vessel' ? (
              <Bar v={S?.cat ?? 0} max={100} col={S?.catFull ? 'linear-gradient(#f1ffb0,#b6f03a)' : 'linear-gradient(#2fa85a,#145c3e)'} label={S?.catFull ? 'CATALYST READY · F' : `CATALYST ${Math.floor(S?.cat ?? 0)}/100`} h={8} />
            ) : (
              <Bar v={S?.formLeft ?? 0} max={14} col="linear-gradient(#f6df7a,#a8862a)" label={`VENOMCRAFT ${fmt(S?.formLeft ?? 0)}s`} h={8} />
            )}
          </div>
        </div>
        <div className="panel pointer-events-auto grid grid-cols-5 gap-3.5 px-3.5 py-2.5 text-center items-center">
          {[['Kills', S?.kills ?? 0, '#f0a05a'], ['DPS', Math.round(S?.dps ?? 0), '#b6f03a'], ['Total dmg', S?.total ?? 0, '#f6df7a'], ['Enemies', S?.alive ?? 0, '#a4ecf5'], ['Poisoned', S?.poisoned ? `${S.poisoned} · ${(S.poisonMax).toFixed(1)}s` : 0, '#7fc22a']].map(([k, v, c]) => (
            <div key={k as string}><div className="text-[8.5px] uppercase tracking-wider text-[#5f9a80]">{k}</div><div className="text-[14.5px] font-bold leading-tight font-mono" style={{ color: c as string }}>{v}</div></div>
          ))}
        </div>
      </div>

      {/* showcase caption */}
      {S?.showcase && (
        <div className="absolute left-1/2 top-[74px] -translate-x-1/2 panel ui-scalable flex items-center gap-3 px-4 py-2">
          <Icon id={S.showcase.id} size={32} />
          <div><div className="text-[9.5px] uppercase tracking-[.2em] text-[#8fd4a0]">Auto showcase</div><div className="text-[14px] font-bold text-[#eaffb0]">{num(S.showcase.id)} · {SKILL_BY_ID[S.showcase.id].name}</div></div>
          <button className="btn" onClick={() => g().nextShow(-1)}>◀</button><button className="btn" onClick={() => g().nextShow(1)}>▶</button><button className="btn warn" onClick={() => g().stopShowcase()}>Stop</button>
        </div>
      )}
      {toast && <div key={toast.k} className="toast absolute left-1/2 top-[22px] z-40 -translate-x-1/2 border border-[#d98c4a] bg-[#1a0f08]/95 px-3.5 py-1.5 text-[11.5px] font-medium text-[#ffd8a8]">{toast.m}</div>}

      {/* skill library */}
      <div data-lib className="pointer-events-none ui-scalable absolute left-3 top-[116px] bottom-[96px] flex">
        {libOpen ? (
          <div className="panel pointer-events-auto flex w-[246px] flex-col p-2.5">
            <div className="mb-1.5 flex items-center justify-between"><div className="panel-hd">Skill library · 21</div><button className="btn !px-1.5" onClick={() => setLibOpen(false)}>—</button></div>
            <div className="mb-2 flex gap-1">{([['all', 'All'], ['vessel', 'Vessel 01–10'], ['venom', 'Venom 11–21']] as const).map(([k, l]) => <button key={k} className={`btn flex-1 !px-1 ${tab === k ? 'on' : ''}`} onClick={() => setTab(k)}>{l}</button>)}</div>
            <div className="scroll grid flex-1 grid-cols-4 content-start gap-1.5 overflow-y-auto pr-1">
              {libList.map(s => {
                const locked = s.slot === 'basic' && s.form !== form;
                return (
                  <div key={s.id} className="card" onPointerDown={(e) => startDrag(e, s.id, { kind: 'lib' })} onMouseEnter={tipOn(s.id)} onMouseMove={tipOn(s.id)} onMouseLeave={() => setTip(null)} onDoubleClick={() => { const slot = (S?.loadout[form] ?? []).findIndex(x => !x); g().equip(slot < 0 ? 0 : slot, s.id); }}>
                    <div className="border border-[#1c4a38]" style={{ borderColor: S?.lastCastId === s.id ? '#b6f03a' : undefined }}><Icon id={s.id} size={48} dim={locked} /></div>
                    <div className="absolute left-0 top-0 bg-[#02080a]/90 px-[3px] text-[9.5px] font-bold text-[#eaffb0]">{num(s.id)}</div>
                    <div className="absolute right-0 top-0 h-[6px] w-[6px]" style={{ background: TIER_COL[s.tier] }} />
                    <button className="absolute bottom-0 right-0 hidden bg-[#02080a]/95 px-[3.5px] text-[10.5px] leading-4 text-[#b6f03a] hover:bg-[#1d5a3c] [.card:hover_&]:block font-bold" title="Cast at cluster" onPointerDown={(e) => e.stopPropagation()} onClick={() => g().castTest(s.id)}>▶</button>
                    {s.slot !== 'basic' && <div className="absolute bottom-0 left-0 bg-[#02080a]/90 px-[3px] text-[8.5px] text-[#f6df7a] font-bold">{s.slot === 'ult' ? 'R' : 'F'}</div>}
                  </div>
                );
              })}
            </div>
            <div className="mt-2 text-[9.5px] leading-snug text-[#7fa890]">Drag to Q/W/E to equip · drag onto arena to test · ▶ auto-casts · double-click equips.</div>
          </div>
        ) : <button className="btn pointer-events-auto h-fit" onClick={() => setLibOpen(true)}>Skills ▸</button>}
      </div>

      {/* controls */}
      <div className="pointer-events-none ui-scalable-tr absolute right-3 top-3 flex flex-col items-end gap-2">
        <div className="panel pointer-events-auto w-[256px] p-2.5">
          <div className="flex items-center justify-between"><div className="panel-hd">Laboratory</div><div className="flex gap-1"><button className="btn !px-1.5" onClick={() => setHelp(!help)}>?</button><button className="btn !px-1.5" onClick={() => setCtlOpen(!ctlOpen)}>{ctlOpen ? '—' : '+'}</button></div></div>
          {ctlOpen && (
            <div className="mt-2 space-y-2">
              <div><div className="mb-1 text-[8.5px] uppercase tracking-wider text-[#5f9a80]">Detail / Raster mode</div><div className="flex gap-1">{QMODES.map(q => tb(S?.quality === q.k, q.l, () => g().setQuality(q.k), 'flex-1 !px-0.5'))}</div></div>
              <div><div className="mb-1 text-[8.5px] uppercase tracking-wider text-[#5f9a80]">Monster density</div><div className="flex gap-1">{D.map(n => tb(S?.density === n, String(n), () => g().setDensity(n), 'flex-1'))}</div></div>
              <div className="flex flex-wrap gap-1">{tb(S?.boss, 'Boss', () => g().setBoss(!S?.boss))}{tb(S?.wave, 'Auto-waves', () => g().setWave(!S?.wave))}{tb(S?.respawn, 'Respawn', () => g().setRespawn(!S?.respawn))}{tb(false, 'Reset', () => g().resetArena(), 'warn')}{tb(false, 'Clear', () => g().clearEnemies(), 'warn')}</div>
              <div><div className="mb-1 text-[8.5px] uppercase tracking-wider text-[#5f9a80]">Time · inspect</div><div className="flex flex-wrap gap-1">{tb(S?.paused, S?.paused ? 'Resume' : 'Pause', () => g().togglePause())}{tb(false, `Slow ${S ? SLOW.indexOf(S.slow) === 0 ? '1×' : S.slow + '×' : ''}`, () => g().cycleSlow())}{tb(false, 'Step ▸|', () => g().step(1))}{tb(false, 'Step ×5', () => g().step(5))}</div></div>
              <div><div className="mb-1 text-[8.5px] uppercase tracking-wider text-[#5f9a80]">Replay · showcase</div><div className="flex flex-wrap gap-1">{tb(false, '↻ Replay last', () => g().replayLast())}{tb(!!S?.showcase, 'Showcase 21', () => (S?.showcase ? g().stopShowcase() : g().startShowcase()))}</div></div>
              <div className="flex flex-wrap gap-1">{tb(S?.quick, 'Quick cast', () => (g().quick = !g().quick))}{tb(S?.wasd, 'WASD move', () => { g().wasd = !g().wasd; })}{tb(false, 'Form ⇄ (Tab)', () => g().toggleForm())}{tb(false, 'Fill catalyst', () => g().fillCatalyst())}</div>
            </div>
          )}
        </div>
        {help && (
          <div className="panel pointer-events-auto w-[256px] p-2.5 text-[10.5px] leading-relaxed text-[#c6e6cf]">
            <div className="panel-hd mb-1">Controls</div>
            <div><b className="text-[#eaffb0]">Hold Q/{S?.wasd ? 'Z' : 'W'}/E/R</b> to aim, move mouse, <b>release</b> to cast. <b>RMB / Esc</b> cancels. R = ultimate of current form, F = Catalyst transformation (needs 100).</div>
            <div className="mt-1"><b className="text-[#eaffb0]">Move:</b> right-click, arrows, A/S/D{S?.wasd ? ' + W' : ''}. <b>Tab</b> toggles form, <b>Space</b> pause, <b>T</b> slow-mo, <b>N</b> step frame, <b>Enter</b> replay last cast.</div>
            <div className="mt-1"><b className="text-[#eaffb0]">Plague Cartography:</b> hold key, drag mouse across arena to draw channel route.</div>
            <div className="mt-1 text-[#8fb8a0]">Replays are deterministic: same seed, same formation, same cast — scrub frame by frame with the timeline.</div>
          </div>
        )}
      </div>

      {/* replay timeline */}
      {S?.stage && (
        <div className="panel ui-scalable-br absolute bottom-[96px] right-3 w-[256px] p-2.5">
          <div className="flex items-center justify-between"><div className="panel-hd">Frame inspector · {num(S.stage.id)}</div><div className="text-[10.5px] font-mono text-[#f6df7a]">F{S.stage.n} · {(S.stage.n / 60).toFixed(2)}s</div></div>
          <input type="range" min={0} max={900} value={Math.min(900, S.stage.n)} className="mt-1.5 w-full" onChange={(e) => { g().paused = true; g().seek(Number(e.target.value)); }} />
          <div className="mt-1.5 flex gap-1"><button className="btn flex-1" onClick={() => g().seek(Math.max(0, S.stage!.n - 10))}>◀◀ 10</button><button className="btn flex-1" onClick={() => g().seek(Math.max(0, S.stage!.n - 1))}>◀ 1</button><button className="btn flex-1" onClick={() => g().step(1)}>1 ▶</button><button className="btn flex-1" onClick={() => g().step(10)}>10 ▶▶</button></div>
        </div>
      )}

      {/* hotbar */}
      <div className="pointer-events-none ui-scalable-bottom absolute bottom-3 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1.5">
        <div className="panel pointer-events-auto flex items-end gap-2.5 px-3.5 py-2.5">
          {[0, 1, 2].map(i => slotBox(keys[i], lo[i], i, keys[i]))}
          <div className="mx-1 h-12 w-px bg-[#1c4a38]" />
          {slotBox('R', ULT[form], 'R', 'r')}
          {slotBox('F', 11, 'F', 'f')}
        </div>
        <div className="text-[9.5px] tracking-wider text-[#7fa890] font-medium">HOLD {keys.join('/')}/R TO AIM · RELEASE TO CAST · RMB / ESC CANCEL · {S?.quick ? 'QUICK CAST ON' : 'QUICK CAST OFF'}</div>
      </div>

      {/* drag ghost + tooltip */}
      {dragView && <div className="pointer-events-none fixed z-[60] opacity-90" style={{ left: dragView.x - 24, top: dragView.y - 24, filter: 'drop-shadow(0 0 8px #b6f03a)' }}><Icon id={dragView.id} size={48} /></div>}
      {tip && !dragView && <Tooltip {...tip} />}
    </div>
  );
}
